(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  944966,
  (t) => {
    "use strict";
    let e = [
      "animate",
      "circle",
      "defs",
      "desc",
      "ellipse",
      "g",
      "image",
      "line",
      "filter",
      "marker",
      "mask",
      "metadata",
      "path",
      "pattern",
      "polygon",
      "polyline",
      "rect",
      "stop",
      "switch",
      "symbol",
      "svg",
      "text",
      "tspan",
      "use",
      "view",
    ];
    t.s(
      [
        "isSVGComponent",
        0,
        function (t) {
          if ("string" != typeof t || t.includes("-"));
          else if (e.indexOf(t) > -1 || /[A-Z]/u.test(t)) return !0;
          return !1;
        },
      ],
      944966,
    );
  },
  368e3,
  746833,
  962118,
  (t) => {
    "use strict";
    var e = t.i(965566),
      i = t.i(763074),
      s = t.i(260830),
      r = t.i(794581),
      n = t.i(930551),
      a = t.i(414229),
      o = t.i(779294),
      l = t.i(635474),
      u = t.i(153396),
      h = t.i(997307);
    function p(t) {
      let { type: e, ...i } = t;
      return (0, h.isGenerator)(e) && (0, u.supportsLinearEasing)()
        ? e.applyToOptions(i)
        : (i.duration ?? (i.duration = 300), i.ease ?? (i.ease = "easeOut"), i);
    }
    t.s(["applyGeneratorOptions", 0, p], 746833);
    class c extends o.WithPromise {
      constructor(t) {
        if ((super(), (this.finishedTime = null), (this.isStopped = !1), (this.manualStartTime = null), !t))
          return;
        const {
          element: i,
          name: s,
          keyframes: n,
          pseudoElement: o,
          allowFlatten: u = !1,
          finalKeyframe: h,
          onComplete: c,
        } = t;
        ((this.isPseudoElement = !!o),
          (this.allowFlatten = u),
          (this.options = t),
          (0, e.invariant)(
            "string" != typeof t.type,
            'Mini animate() doesn\'t support "type" as a string.',
            "mini-spring",
          ));
        const d = p(t);
        ((this.animation = (0, l.startWaapiAnimation)(i, s, n, d, o)),
          !1 === d.autoplay && this.animation.pause(),
          (this.animation.onfinish = () => {
            if (((this.finishedTime = this.time), !o)) {
              let t = (0, a.getFinalKeyframe)(n, this.options, h, this.speed);
              (this.updateMotionValue && this.updateMotionValue(t),
                (0, r.setStyle)(i, s, t),
                this.animation.cancel());
            }
            (c?.(), this.notifyFinished());
          }));
      }
      play() {
        this.isStopped ||
          ((this.manualStartTime = null),
          this.animation.play(),
          "finished" === this.state && this.updateFinished());
      }
      pause() {
        this.animation.pause();
      }
      complete() {
        this.animation.finish?.();
      }
      cancel() {
        try {
          this.animation.cancel();
        } catch (t) {}
      }
      stop() {
        if (this.isStopped) return;
        this.isStopped = !0;
        let { state: t } = this;
        "idle" !== t &&
          "finished" !== t &&
          (this.updateMotionValue ? this.updateMotionValue() : this.commitStyles(),
          this.isPseudoElement || this.cancel());
      }
      commitStyles() {
        let t = this.options?.element;
        !this.isPseudoElement && t?.isConnected && this.animation.commitStyles?.();
      }
      get duration() {
        let t = this.animation.effect?.getComputedTiming?.().duration || 0;
        return (0, i.millisecondsToSeconds)(Number(t));
      }
      get iterationDuration() {
        let { delay: t = 0 } = this.options || {};
        return this.duration + (0, i.millisecondsToSeconds)(t);
      }
      get time() {
        return (0, i.millisecondsToSeconds)(Number(this.animation.currentTime) || 0);
      }
      set time(t) {
        let e = null !== this.finishedTime;
        ((this.manualStartTime = null),
          (this.finishedTime = null),
          (this.animation.currentTime = (0, i.secondsToMilliseconds)(t)),
          e && this.animation.pause());
      }
      get speed() {
        return this.animation.playbackRate;
      }
      set speed(t) {
        (t < 0 && (this.finishedTime = null), (this.animation.playbackRate = t));
      }
      get state() {
        return null !== this.finishedTime ? "finished" : this.animation.playState;
      }
      get startTime() {
        return this.manualStartTime ?? Number(this.animation.startTime);
      }
      set startTime(t) {
        this.manualStartTime = this.animation.startTime = t;
      }
      attachTimeline(t) {
        let { timeline: e, rangeStart: i, rangeEnd: r, observe: a } = t;
        return (this.allowFlatten && this.animation.effect?.updateTiming({ easing: "linear" }),
        (this.animation.onfinish = null),
        e && (0, n.supportsScrollTimeline)())
          ? ((this.animation.timeline = e),
            i && (this.animation.rangeStart = i),
            r && (this.animation.rangeEnd = r),
            s.noop)
          : a(this);
      }
    }
    t.s(["NativeAnimation", 0, c], 368e3);
    let d = new Set(["opacity", "clipPath", "filter", "transform", "backgroundColor"]);
    t.s(["acceleratedValues", 0, d], 962118);
  },
  997307,
  (t) => {
    "use strict";
    t.s([
      "isGenerator",
      0,
      function (t) {
        return "function" == typeof t && "applyToOptions" in t;
      },
    ]);
  },
  921012,
  (t) => {
    "use strict";
    var e = t.i(411485),
      i = t.i(44493),
      s = t.i(287022);
    let r = new Set(),
      n = !1,
      a = !1,
      o = !1;
    function l() {
      if (a) {
        let t = Array.from(r).filter((t) => t.needsMeasurement),
          e = new Set(t.map((t) => t.element)),
          s = new Map();
        (e.forEach((t) => {
          let e = (0, i.removeNonTranslationalTransform)(t);
          e.length && (s.set(t, e), t.render());
        }),
          t.forEach((t) => t.measureInitialState()),
          e.forEach((t) => {
            t.render();
            let e = s.get(t);
            e &&
              e.forEach((e) => {
                let [i, s] = e;
                t.getValue(i)?.set(s);
              });
          }),
          t.forEach((t) => t.measureEndState()),
          t.forEach((t) => {
            void 0 !== t.suspendedScrollY && window.scrollTo(0, t.suspendedScrollY);
          }));
      }
      ((a = !1), (n = !1), r.forEach((t) => t.complete(o)), r.clear());
    }
    function u() {
      r.forEach((t) => {
        (t.readKeyframes(), t.needsMeasurement && (a = !0));
      });
    }
    t.s([
      "KeyframeResolver",
      0,
      class {
        constructor(t, e, i, s, r, n = !1) {
          ((this.state = "pending"),
            (this.isAsync = !1),
            (this.needsMeasurement = !1),
            (this.unresolvedKeyframes = [...t]),
            (this.onComplete = e),
            (this.name = i),
            (this.motionValue = s),
            (this.element = r),
            (this.isAsync = n));
        }
        scheduleResolve() {
          ((this.state = "scheduled"),
            this.isAsync
              ? (r.add(this), n || ((n = !0), s.frame.read(u), s.frame.resolveKeyframes(l)))
              : (this.readKeyframes(), this.complete()));
        }
        readKeyframes() {
          let { unresolvedKeyframes: t, name: i, element: s, motionValue: r } = this;
          if (null === t[0]) {
            let e = r?.get(),
              n = t[t.length - 1];
            if (void 0 !== e) t[0] = e;
            else if (s && i) {
              let e = s.readValue(i, n);
              null != e && (t[0] = e);
            }
            (void 0 === t[0] && (t[0] = n), r && void 0 === e && r.set(t[0]));
          }
          (0, e.fillWildcards)(t);
        }
        setFinalKeyframe() {}
        measureInitialState() {}
        renderEndStyles() {}
        measureEndState() {}
        complete() {
          let t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
          ((this.state = "complete"),
            this.onComplete(this.unresolvedKeyframes, this.finalKeyframe, t),
            r.delete(this));
        }
        cancel() {
          "scheduled" === this.state && (r.delete(this), (this.state = "pending"));
        }
        resume() {
          "pending" === this.state && this.scheduleResolve();
        }
      },
      "flushKeyframeResolvers",
      0,
      function () {
        ((o = !0), u(), l(), (o = !1));
      },
    ]);
  },
  414229,
  779294,
  (t) => {
    "use strict";
    let e = (t) => null !== t;
    (t.s(
      [
        "getFinalKeyframe",
        0,
        function (t, i, s) {
          let { repeat: r, repeatType: n = "loop" } = i,
            a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1,
            o = t.filter(e),
            l = a < 0 || (r && "loop" !== n && r % 2 == 1) ? 0 : o.length - 1;
          return l && void 0 !== s ? s : o[l];
        },
      ],
      414229,
    ),
      t.s(
        [
          "WithPromise",
          0,
          class {
            constructor() {
              this.updateFinished();
            }
            get finished() {
              return this._finished;
            }
            updateFinished() {
              this._finished = new Promise((t) => {
                this.resolve = t;
              });
            }
            notifyFinished() {
              this.resolve();
            }
            then(t, e) {
              return this.finished.then(t, e);
            }
          },
        ],
        779294,
      ));
  },
  411485,
  381296,
  (t) => {
    "use strict";
    t.s(
      [
        "fillWildcards",
        0,
        function (t) {
          for (let e = 1; e < t.length; e++) t[e] ?? (t[e] = t[e - 1]);
        },
      ],
      411485,
    );
    let e = (t) => (180 * t) / Math.PI,
      i = (t) => r(e(Math.atan2(t[1], t[0]))),
      s = {
        x: 4,
        y: 5,
        translateX: 4,
        translateY: 5,
        scaleX: 0,
        scaleY: 3,
        scale: (t) => (Math.abs(t[0]) + Math.abs(t[3])) / 2,
        rotate: i,
        rotateZ: i,
        skewX: (t) => e(Math.atan(t[1])),
        skewY: (t) => e(Math.atan(t[2])),
        skew: (t) => (Math.abs(t[1]) + Math.abs(t[2])) / 2,
      },
      r = (t) => ((t %= 360) < 0 && (t += 360), t),
      n = (t) => Math.sqrt(t[0] * t[0] + t[1] * t[1]),
      a = (t) => Math.sqrt(t[4] * t[4] + t[5] * t[5]),
      o = {
        x: 12,
        y: 13,
        z: 14,
        translateX: 12,
        translateY: 13,
        translateZ: 14,
        scaleX: n,
        scaleY: a,
        scale: (t) => (n(t) + a(t)) / 2,
        rotateX: (t) => r(e(Math.atan2(t[6], t[5]))),
        rotateY: (t) => r(e(Math.atan2(-t[2], t[0]))),
        rotateZ: i,
        rotate: i,
        skewX: (t) => e(Math.atan(t[4])),
        skewY: (t) => e(Math.atan(t[1])),
        skew: (t) => (Math.abs(t[1]) + Math.abs(t[4])) / 2,
      };
    function l(t) {
      return +!!t.includes("scale");
    }
    function u(t, e) {
      let i, r;
      if (!t || "none" === t) return l(e);
      let n = t.match(/^matrix3d\(([-\d.e\s,]+)\)$/u);
      if (n) ((i = o), (r = n));
      else {
        let e = t.match(/^matrix\(([-\d.e\s,]+)\)$/u);
        ((i = s), (r = e));
      }
      if (!r) return l(e);
      let a = i[e],
        u = r[1].split(",").map(h);
      return "function" == typeof a ? a(u) : u[a];
    }
    function h(t) {
      return parseFloat(t.trim());
    }
    t.s(
      [
        "defaultTransformValue",
        0,
        l,
        "parseValueFromTransform",
        0,
        u,
        "readTransformValue",
        0,
        (t, e) => {
          let { transform: i = "none" } = getComputedStyle(t);
          return u(i, e);
        },
      ],
      381296,
    );
  },
  44493,
  (t) => {
    "use strict";
    var e = t.i(381296),
      i = t.i(157788),
      s = t.i(76307),
      r = t.i(265091);
    let n = new Set(["x", "y", "z"]),
      a = i.transformPropOrder.filter((t) => !n.has(t)),
      o = {
        width: (t, e) => {
          let { x: i } = t,
            { paddingLeft: s = "0", paddingRight: r = "0", boxSizing: n } = e,
            a = i.max - i.min;
          return "border-box" === n ? a : a - parseFloat(s) - parseFloat(r);
        },
        height: (t, e) => {
          let { y: i } = t,
            { paddingTop: s = "0", paddingBottom: r = "0", boxSizing: n } = e,
            a = i.max - i.min;
          return "border-box" === n ? a : a - parseFloat(s) - parseFloat(r);
        },
        top: (t, e) => {
          let { top: i } = e;
          return parseFloat(i);
        },
        left: (t, e) => {
          let { left: i } = e;
          return parseFloat(i);
        },
        bottom: (t, e) => {
          let { y: i } = t,
            { top: s } = e;
          return parseFloat(s) + (i.max - i.min);
        },
        right: (t, e) => {
          let { x: i } = t,
            { left: s } = e;
          return parseFloat(s) + (i.max - i.min);
        },
        x: (t, i) => {
          let { transform: s } = i;
          return (0, e.parseValueFromTransform)(s, "x");
        },
        y: (t, i) => {
          let { transform: s } = i;
          return (0, e.parseValueFromTransform)(s, "y");
        },
      };
    ((o.translateX = o.x),
      (o.translateY = o.y),
      t.s([
        "isNumOrPxType",
        0,
        (t) => t === s.number || t === r.px,
        "positionalValues",
        0,
        o,
        "removeNonTranslationalTransform",
        0,
        function (t) {
          let e = [];
          return (
            a.forEach((i) => {
              let s = t.getValue(i);
              void 0 !== s && (e.push([i, s.get()]), s.set(+!!i.startsWith("scale")));
            }),
            e
          );
        },
      ]));
  },
  535043,
  (t) => {
    "use strict";
    var e = t.i(793787);
    let i = "framerAppearId",
      s = "data-" + (0, e.camelToDash)(i);
    t.s(["optimizedAppearDataAttribute", 0, s, "optimizedAppearDataId", 0, i]);
  },
  19928,
  (t) => {
    "use strict";
    let e = (t) => (e) => "string" == typeof e && e.startsWith(t),
      i = e("--"),
      s = e("var(--"),
      r = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu;
    t.s([
      "containsCSSVariable",
      0,
      function (t) {
        return "string" == typeof t && t.split("/*")[0].includes("var(--");
      },
      "isCSSVariableName",
      0,
      i,
      "isCSSVariableToken",
      0,
      (t) => !!s(t) && r.test(t.split("/*")[0].trim()),
    ]);
  },
  635474,
  116869,
  539435,
  20888,
  (t) => {
    "use strict";
    var e = t.i(960855),
      i = t.i(153396),
      s = t.i(756512);
    let r = (t) => {
      let [e, i, s, r] = t;
      return `cubic-bezier(${e}, ${i}, ${s}, ${r})`;
    };
    t.s(["cubicBezierAsString", 0, r], 116869);
    let n = {
      linear: "linear",
      ease: "ease",
      easeIn: "ease-in",
      easeOut: "ease-out",
      easeInOut: "ease-in-out",
      circIn: r([0, 0.65, 0.55, 1]),
      circOut: r([0.55, 0, 1, 0.45]),
      backIn: r([0.31, 0.01, 0.66, -0.59]),
      backOut: r([0.33, 1.53, 0.69, 0.99]),
    };
    function a(t, o) {
      if (t)
        return "function" == typeof t
          ? (0, i.supportsLinearEasing)()
            ? (0, s.generateLinearEasing)(t, o)
            : "ease-out"
          : (0, e.isBezierDefinition)(t)
            ? r(t)
            : Array.isArray(t)
              ? t.map((t) => a(t, o) || n.easeOut)
              : n[t];
    }
    (t.s(["supportedWaapiEasing", 0, n], 539435),
      t.s(["mapEasingToNativeEasing", 0, a], 20888),
      t.s(
        [
          "startWaapiAnimation",
          0,
          function (t, e, i) {
            let {
                delay: s = 0,
                duration: r = 300,
                repeat: n = 0,
                repeatType: o = "loop",
                ease: l = "easeOut",
                times: u,
              } = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {},
              h = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : void 0,
              p = { [e]: i };
            u && (p.offset = u);
            let c = a(l, r);
            Array.isArray(c) && (p.easing = c);
            let d = {
              delay: s,
              duration: r,
              easing: Array.isArray(c) ? "linear" : c,
              fill: "both",
              iterations: n + 1,
              direction: "reverse" === o ? "alternate" : "normal",
            };
            return (h && (d.pseudoElement = h), t.animate(p, d));
          },
        ],
        635474,
      ));
  },
  756512,
  (t) => {
    "use strict";
    t.s([
      "generateLinearEasing",
      0,
      function (t, e) {
        let i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 10,
          s = "",
          r = Math.max(Math.round(e / i), 2);
        for (let e = 0; e < r; e++) s += Math.round(1e4 * t(e / (r - 1))) / 1e4 + ", ";
        return `linear(${s.substring(0, s.length - 2)})`;
      },
    ]);
  },
  287022,
  260830,
  7127,
  651571,
  (t) => {
    "use strict";
    let e = (t) => t;
    t.s(["noop", 0, e], 260830);
    var i = t.i(846791);
    let s = ["setup", "read", "resolveKeyframes", "preUpdate", "update", "preRender", "render", "postRender"];
    function r(t, e) {
      let r = !1,
        n = !0,
        a = { delta: 0, timestamp: 0, isProcessing: !1 },
        o = () => (r = !0),
        l = s.reduce(
          (t, e) => (
            (t[e] = (function (t) {
              let e = new Set(),
                i = new Set(),
                s = !1,
                r = !1,
                n = new WeakSet(),
                a = { delta: 0, timestamp: 0, isProcessing: !1 };
              function o(e) {
                (n.has(e) && (l.schedule(e), t()), e(a));
              }
              let l = {
                schedule: function (t) {
                  let r = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                    a = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
                    o = a && s ? e : i;
                  return (r && n.add(t), o.add(t), t);
                },
                cancel: (t) => {
                  (i.delete(t), n.delete(t));
                },
                process: (t) => {
                  if (((a = t), s)) {
                    r = !0;
                    return;
                  }
                  s = !0;
                  let n = e;
                  ((e = i), (i = n), e.forEach(o), e.clear(), (s = !1), r && ((r = !1), l.process(t)));
                },
              };
              return l;
            })(o)),
            t
          ),
          {},
        ),
        {
          setup: u,
          read: h,
          resolveKeyframes: p,
          preUpdate: c,
          update: d,
          preRender: m,
          render: f,
          postRender: g,
        } = l,
        v = () => {
          let s = i.MotionGlobalConfig.useManualTiming,
            o = s ? a.timestamp : performance.now();
          ((r = !1),
            s || (a.delta = n ? 1e3 / 60 : Math.max(Math.min(o - a.timestamp, 40), 1)),
            (a.timestamp = o),
            (a.isProcessing = !0),
            u.process(a),
            h.process(a),
            p.process(a),
            c.process(a),
            d.process(a),
            m.process(a),
            f.process(a),
            g.process(a),
            (a.isProcessing = !1),
            r && e && ((n = !1), t(v)));
        };
      return {
        schedule: s.reduce((e, i) => {
          let s = l[i];
          return (
            (e[i] = function (e) {
              let i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                o = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
              return (!r && ((r = !0), (n = !0), a.isProcessing || t(v)), s.schedule(e, i, o));
            }),
            e
          );
        }, {}),
        cancel: (t) => {
          for (let e = 0; e < s.length; e++) l[s[e]].cancel(t);
        },
        state: a,
        steps: l,
      };
    }
    (t.s(["stepsOrder", 0, s], 7127), t.s(["createRenderBatcher", 0, r], 651571));
    let {
      schedule: n,
      cancel: a,
      state: o,
      steps: l,
    } = r("u" > typeof requestAnimationFrame ? requestAnimationFrame : e, !0);
    t.s(["cancelFrame", 0, a, "frame", 0, n, "frameData", 0, o, "frameSteps", 0, l], 287022);
  },
  560140,
  (t) => {
    "use strict";
    let { schedule: e, cancel: i } = (0, t.i(651571).createRenderBatcher)(queueMicrotask, !1);
    t.s(["cancelMicrotask", 0, i, "microtask", 0, e]);
  },
  496173,
  (t) => {
    "use strict";
    let e;
    var i = t.i(846791),
      s = t.i(287022);
    function r() {
      e = void 0;
    }
    let n = {
      now: () => (
        void 0 === e &&
          n.set(
            s.frameData.isProcessing || i.MotionGlobalConfig.useManualTiming
              ? s.frameData.timestamp
              : performance.now(),
          ),
        e
      ),
      set: (t) => {
        ((e = t), queueMicrotask(r));
      },
    };
    t.s(["time", 0, n]);
  },
  130162,
  (t) => {
    "use strict";
    let e = () => ({ translate: 0, scale: 1, origin: 0, originPoint: 0 }),
      i = () => ({ min: 0, max: 0 });
    t.s([
      "createAxis",
      0,
      i,
      "createAxisDelta",
      0,
      e,
      "createBox",
      0,
      () => ({ x: i(), y: i() }),
      "createDelta",
      0,
      () => ({ x: e(), y: e() }),
    ]);
  },
  91018,
  (t) => {
    "use strict";
    var e = t.i(265091);
    function i(t, e) {
      return e.max === e.min ? 0 : (t / (e.max - e.min)) * 100;
    }
    let s = {
      correct: (t, s) => {
        if (!s.target) return t;
        if ("string" == typeof t)
          if (!e.px.test(t)) return t;
          else t = parseFloat(t);
        let r = i(t, s.target.x),
          n = i(t, s.target.y);
        return `${r}% ${n}%`;
      },
    };
    t.s(["correctBorderRadius", 0, s, "pixelsToPercent", 0, i]);
  },
  617218,
  (t) => {
    "use strict";
    t.i(247167);
    var e = t.i(763074),
      i = t.i(172590),
      s = t.i(547507),
      r = t.i(570596),
      n = t.i(921012),
      a = t.i(368e3),
      o = t.i(962118),
      l = t.i(560140),
      u = t.i(496173),
      h = t.i(130162),
      p = t.i(486427),
      c = t.i(569577),
      d = t.i(775554),
      m = t.i(166538),
      f = t.i(83411),
      g = t.i(472094),
      v = t.i(587576),
      y = t.i(157788),
      b = t.i(458163),
      V = t.i(138544),
      x = t.i(386579),
      S = t.i(571164),
      T = t.i(287022);
    let M = [
        "AnimationStart",
        "AnimationComplete",
        "Update",
        "BeforeLayoutMeasure",
        "LayoutMeasure",
        "LayoutAnimationStart",
        "LayoutAnimationComplete",
      ],
      w = {};
    t.s([
      "VisualElement",
      0,
      class {
        scrapeMotionValuesFromProps(t, e, i) {
          return {};
        }
        constructor(
          {
            parent: t,
            props: e,
            presenceContext: i,
            reducedMotionConfig: s,
            skipAnimations: r,
            blockInitialAnimation: a,
            visualState: o,
          },
          l = {},
        ) {
          ((this.current = null),
            (this.children = new Set()),
            (this.isVariantNode = !1),
            (this.isControllingVariants = !1),
            (this.shouldReduceMotion = null),
            (this.shouldSkipAnimations = !1),
            (this.values = new Map()),
            (this.KeyframeResolver = n.KeyframeResolver),
            (this.features = {}),
            (this.valueSubscriptions = new Map()),
            (this.prevMotionValues = {}),
            (this.hasBeenMounted = !1),
            (this.events = {}),
            (this.propEventSubscriptions = {}),
            (this.notifyUpdate = () => this.notify("Update", this.latestValues)),
            (this.render = () => {
              this.current &&
                (this.triggerBuild(),
                this.renderInstance(this.current, this.renderState, this.props.style, this.projection));
            }),
            (this.renderScheduledAt = 0),
            (this.scheduleRender = () => {
              let t = u.time.now();
              this.renderScheduledAt < t &&
                ((this.renderScheduledAt = t), T.frame.render(this.render, !1, !0));
            }));
          const { latestValues: h, renderState: p } = o;
          ((this.latestValues = h),
            (this.baseTarget = { ...h }),
            (this.initialValues = e.initial ? { ...h } : {}),
            (this.renderState = p),
            (this.parent = t),
            (this.props = e),
            (this.presenceContext = i),
            (this.depth = t ? t.depth + 1 : 0),
            (this.reducedMotionConfig = s),
            (this.skipAnimationsConfig = r),
            (this.options = l),
            (this.blockInitialAnimation = !!a),
            (this.isControllingVariants = (0, v.isControllingVariants)(e)),
            (this.isVariantNode = (0, v.isVariantNode)(e)),
            this.isVariantNode && (this.variantChildren = new Set()),
            (this.manuallyAnimateOnMount = !!(t && t.current)));
          const { willChange: c, ...d } = this.scrapeMotionValuesFromProps(e, {}, this);
          for (const t in d) {
            const e = d[t];
            void 0 !== h[t] && (0, f.isMotionValue)(e) && e.set(h[t]);
          }
        }
        mount(t) {
          if (this.hasBeenMounted)
            for (let t in this.initialValues)
              (this.values.get(t)?.jump(this.initialValues[t]),
                (this.latestValues[t] = this.initialValues[t]));
          ((this.current = t),
            g.visualElementStore.set(t, this),
            this.projection && !this.projection.instance && this.projection.mount(t),
            this.parent &&
              this.isVariantNode &&
              !this.isControllingVariants &&
              (this.removeFromVariantTree = this.parent.addVariantChild(this)),
            this.values.forEach((t, e) => this.bindToMotionValue(e, t)),
            "never" === this.reducedMotionConfig
              ? (this.shouldReduceMotion = !1)
              : "always" === this.reducedMotionConfig
                ? (this.shouldReduceMotion = !0)
                : (S.hasReducedMotionListener.current || (0, V.initPrefersReducedMotion)(),
                  (this.shouldReduceMotion = S.prefersReducedMotion.current)),
            (this.shouldSkipAnimations = this.skipAnimationsConfig ?? !1),
            this.parent?.addChild(this),
            this.update(this.props, this.presenceContext),
            (this.hasBeenMounted = !0));
        }
        unmount() {
          for (let t in (this.projection && this.projection.unmount(),
          (0, T.cancelFrame)(this.notifyUpdate),
          (0, T.cancelFrame)(this.render),
          this.valueSubscriptions.forEach((t) => t()),
          this.valueSubscriptions.clear(),
          this.removeFromVariantTree && this.removeFromVariantTree(),
          this.parent?.removeChild(this),
          this.events))
            this.events[t].clear();
          for (let t in this.features) {
            let e = this.features[t];
            e && (e.unmount(), (e.isMounted = !1));
          }
          this.current = null;
        }
        addChild(t) {
          (this.children.add(t),
            this.enteringChildren ?? (this.enteringChildren = new Set()),
            this.enteringChildren.add(t));
        }
        removeChild(t) {
          (this.children.delete(t), this.enteringChildren && this.enteringChildren.delete(t));
        }
        bindToMotionValue(t, i) {
          let s;
          if (
            (this.valueSubscriptions.has(t) && this.valueSubscriptions.get(t)(),
            i.accelerate && o.acceleratedValues.has(t) && this.current instanceof HTMLElement)
          ) {
            let { factory: s, keyframes: r, times: n, ease: o, duration: l } = i.accelerate,
              u = new a.NativeAnimation({
                element: this.current,
                name: t,
                keyframes: r,
                times: n,
                ease: o,
                duration: (0, e.secondsToMilliseconds)(l),
              }),
              h = s(u);
            this.valueSubscriptions.set(t, () => {
              (h(), u.cancel());
            });
            return;
          }
          let r = y.transformProps.has(t);
          r && this.onBindTransform && this.onBindTransform();
          let n = i.on("change", (e) => {
            ((this.latestValues[t] = e),
              this.props.onUpdate && T.frame.preRender(this.notifyUpdate),
              r && this.projection && (this.projection.isTransformDirty = !0),
              this.scheduleRender());
          });
          ("u" > typeof window &&
            window.MotionCheckAppearSync &&
            (s = window.MotionCheckAppearSync(this, t, i)),
            this.valueSubscriptions.set(t, () => {
              (n(), s && s());
            }));
        }
        sortNodePosition(t) {
          return this.current && this.sortInstanceNodePosition && this.type === t.type
            ? this.sortInstanceNodePosition(this.current, t.current)
            : 0;
        }
        updateFeatures() {
          let t = "animation";
          for (t in w) {
            let e = w[t];
            if (!e) continue;
            let { isEnabled: i, Feature: s } = e;
            if (
              (!this.features[t] && s && i(this.props) && (this.features[t] = new s(this)), this.features[t])
            ) {
              let e = this.features[t];
              e.isMounted ? e.update() : (e.mount(), (e.isMounted = !0));
            }
          }
        }
        triggerBuild() {
          this.build(this.renderState, this.latestValues, this.props);
        }
        measureViewportBox() {
          return this.current
            ? this.measureInstanceViewportBox(this.current, this.props)
            : (0, h.createBox)();
        }
        getStaticValue(t) {
          return this.latestValues[t];
        }
        setStaticValue(t, e) {
          this.latestValues[t] = e;
        }
        update(t, e) {
          ((t.transformTemplate || this.props.transformTemplate) && this.scheduleRender(),
            (this.prevProps = this.props),
            (this.props = t),
            (this.prevPresenceContext = this.presenceContext),
            (this.presenceContext = e));
          for (let e = 0; e < M.length; e++) {
            let i = M[e];
            this.propEventSubscriptions[i] &&
              (this.propEventSubscriptions[i](), delete this.propEventSubscriptions[i]);
            let s = t["on" + i];
            s && (this.propEventSubscriptions[i] = this.on(i, s));
          }
          ((this.prevMotionValues = (0, b.updateMotionValuesFromProps)(
            this,
            this.scrapeMotionValuesFromProps(t, this.prevProps || {}, this),
            this.prevMotionValues,
          )),
            this.handleChildMotionValue && this.handleChildMotionValue());
        }
        getProps() {
          return this.props;
        }
        getVariant(t) {
          return this.props.variants ? this.props.variants[t] : void 0;
        }
        getDefaultTransition() {
          return this.props.transition;
        }
        getTransformPagePoint() {
          return this.props.transformPagePoint;
        }
        getClosestVariantNode() {
          return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0;
        }
        addVariantChild(t) {
          let e = this.getClosestVariantNode();
          if (e) return (e.variantChildren && e.variantChildren.add(t), () => e.variantChildren.delete(t));
        }
        addValue(t, e) {
          let i = this.values.get(t);
          e !== i &&
            (i && this.removeValue(t),
            this.bindToMotionValue(t, e),
            this.values.set(t, e),
            (this.latestValues[t] = e.get()));
        }
        removeValue(t) {
          this.values.delete(t);
          let e = this.valueSubscriptions.get(t);
          (e && (e(), this.valueSubscriptions.delete(t)),
            delete this.latestValues[t],
            this.removeValueFromRenderState(t, this.renderState));
        }
        hasValue(t) {
          return this.values.has(t);
        }
        getValue(t, e) {
          if (this.props.values && this.props.values[t]) return this.props.values[t];
          let i = this.values.get(t);
          return (
            void 0 === i &&
              void 0 !== e &&
              ((i = (0, p.motionValue)(null === e ? void 0 : e, { owner: this })), this.addValue(t, i)),
            i
          );
        }
        readValue(t, e) {
          let r =
            void 0 === this.latestValues[t] && this.current
              ? (this.getBaseTargetFromProps(this.props, t) ??
                this.readValueFromInstance(this.current, t, this.options))
              : this.latestValues[t];
          return (
            null != r &&
              ("string" == typeof r && ((0, i.isNumericalString)(r) || (0, s.isZeroValueString)(r))
                ? (r = parseFloat(r))
                : !(0, m.findValueType)(r) && c.complex.test(e) && (r = (0, d.getAnimatableNone)(t, e)),
              this.setBaseTarget(t, (0, f.isMotionValue)(r) ? r.get() : r)),
            (0, f.isMotionValue)(r) ? r.get() : r
          );
        }
        setBaseTarget(t, e) {
          this.baseTarget[t] = e;
        }
        getBaseTarget(t) {
          let e,
            { initial: i } = this.props;
          if ("string" == typeof i || "object" == typeof i) {
            let s = (0, x.resolveVariantFromProps)(this.props, i, this.presenceContext?.custom);
            s && (e = s[t]);
          }
          if (i && void 0 !== e) return e;
          let s = this.getBaseTargetFromProps(this.props, t);
          return void 0 === s || (0, f.isMotionValue)(s)
            ? void 0 !== this.initialValues[t] && void 0 === e
              ? void 0
              : this.baseTarget[t]
            : s;
        }
        on(t, e) {
          return (this.events[t] || (this.events[t] = new r.SubscriptionManager()), this.events[t].add(e));
        }
        notify(t) {
          for (var e = arguments.length, i = Array(e > 1 ? e - 1 : 0), s = 1; s < e; s++)
            i[s - 1] = arguments[s];
          this.events[t] && this.events[t].notify(...i);
        }
        scheduleRenderMicrotask() {
          l.microtask.render(this.render);
        }
      },
      "getFeatureDefinitions",
      0,
      function () {
        return w;
      },
      "setFeatureDefinitions",
      0,
      function (t) {
        w = t;
      },
    ]);
  },
  794581,
  134474,
  260900,
  583911,
  486902,
  930551,
  (t) => {
    "use strict";
    let e = (t) => t.startsWith("--");
    function i(t) {
      let e;
      return () => (void 0 === e && (e = t()), e);
    }
    (t.s(["isCSSVar", 0, e], 134474),
      t.s(
        [
          "setStyle",
          0,
          function (t, i, s) {
            e(i) ? t.style.setProperty(i, s) : (t.style[i] = s);
          },
        ],
        794581,
      ),
      t.s(["memo", 0, i], 260900));
    let s = {};
    function r(t, e) {
      let r = i(t);
      return () => s[e] ?? r();
    }
    (t.s(["supportsFlags", 0, s], 583911), t.s(["memoSupports", 0, r], 486902));
    let n = r(() => void 0 !== window.ScrollTimeline, "scrollTimeline"),
      a = r(() => void 0 !== window.ViewTimeline, "viewTimeline");
    t.s(["supportsScrollTimeline", 0, n, "supportsViewTimeline", 0, a], 930551);
  },
  793787,
  (t) => {
    "use strict";
    t.s([
      "camelToDash",
      0,
      function (t) {
        return t.replace(/([A-Z])/g, (t) => `-${t.toLowerCase()}`);
      },
    ]);
  },
  984049,
  (t) => {
    "use strict";
    var e = t.i(83411),
      i = t.i(130789);
    t.s([
      "scrapeMotionValuesFromProps",
      0,
      function (t, s, r) {
        let n = t.style,
          a = s?.style,
          o = {};
        if (!n) return o;
        for (let s in n)
          ((0, e.isMotionValue)(n[s]) ||
            (a && (0, e.isMotionValue)(a[s])) ||
            (0, i.isForcedMotionValue)(s, t) ||
            r?.getValue(s)?.liveStyle !== void 0) &&
            (o[s] = n[s]);
        return o;
      },
    ]);
  },
  472094,
  (t) => {
    "use strict";
    let e = new WeakMap();
    t.s(["visualElementStore", 0, e]);
  },
  181261,
  768545,
  544947,
  260778,
  399951,
  (t) => {
    "use strict";
    var e = t.i(446124),
      i = t.i(434929),
      s = t.i(157788),
      r = t.i(19928);
    let n = { x: "translateX", y: "translateY", z: "translateZ", transformPerspective: "perspective" },
      a = s.transformPropOrder.length;
    function o(t, r, o) {
      let l = "",
        u = !0;
      for (let h = 0; h < a; h++) {
        let a = s.transformPropOrder[h],
          p = t[a];
        if (void 0 === p) continue;
        let c = !0;
        if ("number" == typeof p) c = p === +!!a.startsWith("scale");
        else {
          let t = parseFloat(p);
          c = a.startsWith("scale") ? 1 === t : 0 === t;
        }
        if (!c || o) {
          let t = (0, e.getValueAsType)(p, i.numberValueTypes[a]);
          if (!c) {
            u = !1;
            let e = n[a] || a;
            l += `${e}(${t}) `;
          }
          o && (r[a] = t);
        }
      }
      let h = t.pathRotation;
      return (
        h && ((u = !1), (l += `rotate(${(0, e.getValueAsType)(h, i.numberValueTypes.pathRotation)}) `)),
        (l = l.trim()),
        o ? (l = o(r, u ? "" : l)) : u && (l = "none"),
        l
      );
    }
    function l(t, n, a) {
      let { style: l, vars: u, transformOrigin: h } = t,
        p = !1,
        c = !1;
      for (let t in n) {
        let a = n[t];
        if (s.transformProps.has(t)) {
          p = !0;
          continue;
        }
        if ((0, r.isCSSVariableName)(t)) {
          u[t] = a;
          continue;
        }
        {
          let s = (0, e.getValueAsType)(a, i.numberValueTypes[t]);
          t.startsWith("origin") ? ((c = !0), (h[t] = s)) : (l[t] = s);
        }
      }
      if (
        (!n.transform &&
          (p || a ? (l.transform = o(n, t.transform, a)) : l.transform && (l.transform = "none")),
        c)
      ) {
        let { originX: t = "50%", originY: e = "50%", originZ: i = 0 } = h;
        l.transformOrigin = `${t} ${e} ${i}`;
      }
    }
    (t.s(["buildTransform", 0, o], 768545), t.s(["buildHTMLStyles", 0, l], 544947));
    let u = { offset: "stroke-dashoffset", array: "stroke-dasharray" },
      h = { offset: "strokeDashoffset", array: "strokeDasharray" };
    function p(t, e) {
      let i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
        s = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
        r = !(arguments.length > 4) || void 0 === arguments[4] || arguments[4];
      t.pathLength = 1;
      let n = r ? u : h;
      ((t[n.offset] = `${-s}`), (t[n.array] = `${e} ${i}`));
    }
    t.s(["buildSVGPath", 0, p], 260778);
    let c = ["offsetDistance", "offsetPath", "offsetRotate", "offsetAnchor"];
    (t.s(
      [
        "buildSVGAttrs",
        0,
        function (t, e, i, s, r) {
          let {
            attrX: n,
            attrY: a,
            attrScale: o,
            pathLength: u,
            pathSpacing: h = 1,
            pathOffset: d = 0,
            ...m
          } = e;
          if ((l(t, m, s), i)) {
            t.style.viewBox && (t.attrs.viewBox = t.style.viewBox);
            return;
          }
          ((t.attrs = t.style), (t.style = {}));
          let { attrs: f, style: g } = t;
          for (let t of (f.transform && ((g.transform = f.transform), delete f.transform),
          (g.transform || f.transformOrigin) &&
            ((g.transformOrigin = f.transformOrigin ?? "50% 50%"), delete f.transformOrigin),
          g.transform && ((g.transformBox = r?.transformBox ?? "fill-box"), delete f.transformBox),
          c))
            void 0 !== f[t] && ((g[t] = f[t]), delete f[t]);
          (void 0 !== n && (f.x = n),
            void 0 !== a && (f.y = a),
            void 0 !== o && (f.scale = o),
            void 0 !== u && p(f, u, h, d, !1));
        },
      ],
      181261,
    ),
      t.s(["isSVGTag", 0, (t) => "string" == typeof t && "svg" === t.toLowerCase()], 399951));
  },
  767926,
  (t) => {
    "use strict";
    var e = t.i(83411),
      i = t.i(157788),
      s = t.i(984049);
    t.s([
      "scrapeMotionValuesFromProps",
      0,
      function (t, r, n) {
        let a = (0, s.scrapeMotionValuesFromProps)(t, r, n);
        for (let s in t)
          ((0, e.isMotionValue)(t[s]) || (0, e.isMotionValue)(r[s])) &&
            (a[
              -1 !== i.transformPropOrder.indexOf(s) ? "attr" + s.charAt(0).toUpperCase() + s.substring(1) : s
            ] = t[s]);
        return a;
      },
    ]);
  },
  885983,
  (t) => {
    "use strict";
    t.s([
      "isAnimationControls",
      0,
      function (t) {
        return null !== t && "object" == typeof t && "function" == typeof t.start;
      },
    ]);
  },
  587576,
  (t) => {
    "use strict";
    var e = t.i(885983),
      i = t.i(732525),
      s = t.i(706840);
    function r(t) {
      return (0, e.isAnimationControls)(t.animate) || s.variantProps.some((e) => (0, i.isVariantLabel)(t[e]));
    }
    t.s([
      "isControllingVariants",
      0,
      r,
      "isVariantNode",
      0,
      function (t) {
        return !!(r(t) || t.variants);
      },
    ]);
  },
  130789,
  909652,
  924463,
  (t) => {
    "use strict";
    var e = t.i(157788),
      i = t.i(19928),
      s = t.i(895051),
      r = t.i(91018),
      n = t.i(569577),
      a = t.i(100706);
    let o = {
      correct: (t, e) => {
        let { treeScale: i, projectionDelta: s } = e,
          r = n.complex.parse(t);
        if (r.length > 5) return t;
        let o = n.complex.createTransformer(t),
          l = +("number" != typeof r[0]),
          u = s.x.scale * i.x,
          h = s.y.scale * i.y;
        ((r[0 + l] /= u), (r[1 + l] /= h));
        let p = (0, a.mixNumber)(u, h, 0.5);
        return (
          "number" == typeof r[2 + l] && (r[2 + l] /= p),
          "number" == typeof r[3 + l] && (r[3 + l] /= p),
          o(r)
        );
      },
    };
    t.s(["correctBoxShadow", 0, o], 909652);
    let l = {
      borderRadius: { ...r.correctBorderRadius, applyTo: [...s.cornerRadiusProps] },
      borderTopLeftRadius: r.correctBorderRadius,
      borderTopRightRadius: r.correctBorderRadius,
      borderBottomLeftRadius: r.correctBorderRadius,
      borderBottomRightRadius: r.correctBorderRadius,
      boxShadow: o,
    };
    (t.s(
      [
        "addScaleCorrector",
        0,
        function (t) {
          for (let e in t) ((l[e] = t[e]), (0, i.isCSSVariableName)(e) && (l[e].isCSSVariable = !0));
        },
        "scaleCorrectors",
        0,
        l,
      ],
      924463,
    ),
      t.s(
        [
          "isForcedMotionValue",
          0,
          function (t, i) {
            let { layout: s, layoutId: r } = i;
            return (
              e.transformProps.has(t) ||
              t.startsWith("origin") ||
              ((s || void 0 !== r) && (!!l[t] || "opacity" === t))
            );
          },
        ],
        130789,
      ));
  },
  732525,
  706840,
  (t) => {
    "use strict";
    t.s(
      [
        "isVariantLabel",
        0,
        function (t) {
          return "string" == typeof t || Array.isArray(t);
        },
      ],
      732525,
    );
    let e = ["animate", "whileInView", "whileFocus", "whileHover", "whileTap", "whileDrag", "exit"],
      i = ["initial", ...e];
    t.s(["variantPriorityOrder", 0, e, "variantProps", 0, i], 706840);
  },
  157788,
  (t) => {
    "use strict";
    let e = [
        "transformPerspective",
        "x",
        "y",
        "z",
        "translateX",
        "translateY",
        "translateZ",
        "scale",
        "scaleX",
        "scaleY",
        "rotate",
        "rotateX",
        "rotateY",
        "rotateZ",
        "skew",
        "skewX",
        "skewY",
      ],
      i = new Set([...e, "pathRotation"]);
    t.s(["transformPropOrder", 0, e, "transformProps", 0, i]);
  },
  458163,
  (t) => {
    "use strict";
    var e = t.i(486427),
      i = t.i(83411);
    t.s([
      "updateMotionValuesFromProps",
      0,
      function (t, s, r) {
        for (let n in s) {
          let a = s[n],
            o = r[n];
          if ((0, i.isMotionValue)(a)) t.addValue(n, a);
          else if ((0, i.isMotionValue)(o)) t.addValue(n, (0, e.motionValue)(a, { owner: t }));
          else if (o !== a)
            if (t.hasValue(n)) {
              let e = t.getValue(n);
              !0 === e.liveStyle ? e.jump(a) : e.hasAnimated || e.set(a);
            } else {
              let i = t.getStaticValue(n);
              t.addValue(n, (0, e.motionValue)(void 0 !== i ? i : a, { owner: t }));
            }
        }
        for (let e in r) void 0 === s[e] && t.removeValue(e);
        return s;
      },
    ]);
  },
  386579,
  (t) => {
    "use strict";
    function e(t) {
      let e = [{}, {}];
      return (
        t?.values.forEach((t, i) => {
          ((e[0][i] = t.get()), (e[1][i] = t.getVelocity()));
        }),
        e
      );
    }
    t.s([
      "resolveVariantFromProps",
      0,
      function (t, i, s, r) {
        if ("function" == typeof i) {
          let [n, a] = e(r);
          i = i(void 0 !== s ? s : t.custom, n, a);
        }
        if (("string" == typeof i && (i = t.variants && t.variants[i]), "function" == typeof i)) {
          let [n, a] = e(r);
          i = i(void 0 !== s ? s : t.custom, n, a);
        }
        return i;
      },
    ]);
  },
  895051,
  (t) => {
    "use strict";
    t.s([
      "cornerRadiusProps",
      0,
      ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomRightRadius", "borderBottomLeftRadius"],
    ]);
  },
  100706,
  (t) => {
    "use strict";
    t.s(["mixNumber", 0, (t, e, i) => t + (e - t) * i]);
  },
  153396,
  (t) => {
    "use strict";
    let e = (0, t.i(486902).memoSupports)(() => {
      try {
        document.createElement("div").animate({ opacity: 0 }, { easing: "linear(0, 1)" });
      } catch (t) {
        return !1;
      }
      return !0;
    }, "linearEasing");
    t.s(["supportsLinearEasing", 0, e]);
  },
  486427,
  (t) => {
    "use strict";
    t.i(247167);
    var e = t.i(570596),
      i = t.i(325791),
      s = t.i(496173),
      r = t.i(287022);
    let n = { current: void 0 };
    class a {
      constructor(t, e = {}) {
        ((this.canTrackVelocity = null),
          (this.events = {}),
          (this.updateAndNotify = (t) => {
            let e = s.time.now();
            if (
              (this.updatedAt !== e && this.setPrevFrameValue(),
              (this.prev = this.current),
              this.setCurrent(t),
              this.current !== this.prev && (this.events.change?.notify(this.current), this.dependents))
            )
              for (let t of this.dependents) t.dirty();
          }),
          (this.hasAnimated = !1),
          this.setCurrent(t),
          (this.owner = e.owner));
      }
      setCurrent(t) {
        ((this.current = t),
          (this.updatedAt = s.time.now()),
          null === this.canTrackVelocity &&
            void 0 !== t &&
            (this.canTrackVelocity = !isNaN(parseFloat(this.current))));
      }
      setPrevFrameValue() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.current;
        ((this.prevFrameValue = t), (this.prevUpdatedAt = this.updatedAt));
      }
      onChange(t) {
        return this.on("change", t);
      }
      on(t, i) {
        this.events[t] || (this.events[t] = new e.SubscriptionManager());
        let s = this.events[t].add(i);
        return "change" === t
          ? () => {
              (s(),
                r.frame.read(() => {
                  this.events.change.getSize() || this.stop();
                }));
            }
          : s;
      }
      clearListeners() {
        for (let t in this.events) this.events[t].clear();
      }
      attach(t, e) {
        ((this.passiveEffect = t), (this.stopPassiveEffect = e));
      }
      set(t) {
        this.passiveEffect ? this.passiveEffect(t, this.updateAndNotify) : this.updateAndNotify(t);
      }
      setWithVelocity(t, e, i) {
        (this.set(e),
          (this.prev = void 0),
          (this.prevFrameValue = t),
          (this.prevUpdatedAt = this.updatedAt - i));
      }
      jump(t) {
        let e = !(arguments.length > 1) || void 0 === arguments[1] || arguments[1];
        (this.updateAndNotify(t),
          (this.prev = t),
          (this.prevUpdatedAt = this.prevFrameValue = void 0),
          e && this.stop(),
          this.stopPassiveEffect && this.stopPassiveEffect());
      }
      dirty() {
        this.events.change?.notify(this.current);
      }
      addDependent(t) {
        (this.dependents || (this.dependents = new Set()), this.dependents.add(t));
      }
      removeDependent(t) {
        this.dependents && this.dependents.delete(t);
      }
      get() {
        return (n.current && n.current.push(this), this.current);
      }
      getPrevious() {
        return this.prev;
      }
      getVelocity() {
        let t = s.time.now();
        if (!this.canTrackVelocity || void 0 === this.prevFrameValue || t - this.updatedAt > 30) return 0;
        let e = Math.min(this.updatedAt - this.prevUpdatedAt, 30);
        return (0, i.velocityPerSecond)(parseFloat(this.current) - parseFloat(this.prevFrameValue), e);
      }
      start(t) {
        return (
          this.stop(),
          new Promise((e) => {
            ((this.hasAnimated = !0),
              (this.animation = t(e)),
              this.events.animationStart && this.events.animationStart.notify());
          }).then(() => {
            (this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation());
          })
        );
      }
      stop() {
        (this.animation &&
          (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()),
          this.clearAnimation());
      }
      isAnimating() {
        return !!this.animation;
      }
      clearAnimation() {
        delete this.animation;
      }
      destroy() {
        (this.dependents?.clear(),
          this.events.destroy?.notify(),
          this.clearListeners(),
          this.stop(),
          this.stopPassiveEffect && this.stopPassiveEffect());
      }
    }
    t.s([
      "MotionValue",
      0,
      a,
      "collectMotionValues",
      0,
      n,
      "motionValue",
      0,
      function (t, e) {
        return new a(t, e);
      },
    ]);
  },
  463011,
  560720,
  530677,
  498106,
  766820,
  (t) => {
    "use strict";
    var e = t.i(476959),
      i = t.i(76307);
    let s = (t) => Math.round(1e5 * t) / 1e5;
    t.s(["sanitize", 0, s], 560720);
    let r = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu;
    t.s(["floatRegex", 0, r], 530677);
    let n =
        /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,
      a = (t, e) => (i) =>
        !!(
          ("string" == typeof i && n.test(i) && i.startsWith(t)) ||
          (e && null != i && Object.prototype.hasOwnProperty.call(i, e))
        ),
      o = (t, e, i) => (s) => {
        if ("string" != typeof s) return s;
        let [n, a, o, l] = s.match(r);
        return {
          [t]: parseFloat(n),
          [e]: parseFloat(a),
          [i]: parseFloat(o),
          alpha: void 0 !== l ? parseFloat(l) : 1,
        };
      };
    t.s(["isColorString", 0, a, "splitColor", 0, o], 498106);
    let l = { ...i.number, transform: (t) => Math.round((0, e.clamp)(0, 255, t)) },
      u = {
        test: a("rgb", "red"),
        parse: o("red", "green", "blue"),
        transform: (t) => {
          let { red: e, green: r, blue: n, alpha: a = 1 } = t;
          return (
            "rgba(" +
            l.transform(e) +
            ", " +
            l.transform(r) +
            ", " +
            l.transform(n) +
            ", " +
            s(i.alpha.transform(a)) +
            ")"
          );
        },
      };
    t.s(["rgbUnit", 0, l, "rgba", 0, u], 766820);
    let h = {
      test: a("#"),
      parse: function (t) {
        let e = "",
          i = "",
          s = "",
          r = "";
        return (
          t.length > 5
            ? ((e = t.substring(1, 3)),
              (i = t.substring(3, 5)),
              (s = t.substring(5, 7)),
              (r = t.substring(7, 9)))
            : ((e = t.substring(1, 2)),
              (i = t.substring(2, 3)),
              (s = t.substring(3, 4)),
              (r = t.substring(4, 5)),
              (e += e),
              (i += i),
              (s += s),
              (r += r)),
          {
            red: parseInt(e, 16),
            green: parseInt(i, 16),
            blue: parseInt(s, 16),
            alpha: r ? parseInt(r, 16) / 255 : 1,
          }
        );
      },
      transform: u.transform,
    };
    t.s(["hex", 0, h], 463011);
  },
  208792,
  719991,
  (t) => {
    "use strict";
    var e = t.i(569577),
      i = t.i(530677);
    let s = new Set(["brightness", "contrast", "saturate", "opacity"]);
    function r(t) {
      let [e, r] = t.slice(0, -1).split("(");
      if ("drop-shadow" === e) return t;
      let [n] = r.match(i.floatRegex) || [];
      if (!n) return t;
      let a = r.replace(n, ""),
        o = +!!s.has(e);
      return (n !== r && (o *= 100), e + "(" + o + a + ")");
    }
    let n = /\b([a-z-]*)\(.*?\)/gu,
      a = {
        ...e.complex,
        getAnimatableNone: (t) => {
          let e = t.match(n);
          return e ? e.map(r).join(" ") : t;
        },
      };
    t.s(["filter", 0, a], 208792);
    let o = {
      ...e.complex,
      getAnimatableNone: (t) => {
        let i = e.complex.parse(t);
        return e.complex.createTransformer(t)(
          i.map((t) => ("number" == typeof t ? 0 : "object" == typeof t ? { ...t, alpha: 1 } : t)),
        );
      },
    };
    t.s(["mask", 0, o], 719991);
  },
  569577,
  22660,
  279444,
  (t) => {
    "use strict";
    var e = t.i(463011),
      i = t.i(76307),
      s = t.i(265091),
      r = t.i(560720),
      n = t.i(498106);
    let a = {
      test: (0, n.isColorString)("hsl", "hue"),
      parse: (0, n.splitColor)("hue", "saturation", "lightness"),
      transform: (t) => {
        let { hue: e, saturation: n, lightness: a, alpha: o = 1 } = t;
        return (
          "hsla(" +
          Math.round(e) +
          ", " +
          s.percent.transform((0, r.sanitize)(n)) +
          ", " +
          s.percent.transform((0, r.sanitize)(a)) +
          ", " +
          (0, r.sanitize)(i.alpha.transform(o)) +
          ")"
        );
      },
    };
    t.s(["hsla", 0, a], 22660);
    var o = t.i(766820);
    let l = {
      test: (t) => o.rgba.test(t) || e.hex.test(t) || a.test(t),
      parse: (t) => (o.rgba.test(t) ? o.rgba.parse(t) : a.test(t) ? a.parse(t) : e.hex.parse(t)),
      transform: (t) =>
        "string" == typeof t ? t : t.hasOwnProperty("red") ? o.rgba.transform(t) : a.transform(t),
      getAnimatableNone: (t) => {
        let e = l.parse(t);
        return ((e.alpha = 0), l.transform(e));
      },
    };
    t.s(["color", 0, l], 279444);
    let u =
      /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;
    var h = t.i(530677);
    let p = "number",
      c = "color",
      d =
        /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;
    function m(t) {
      let e = t.toString(),
        i = [],
        s = { color: [], number: [], var: [] },
        r = [],
        n = 0,
        a = e
          .replace(
            d,
            (t) => (
              l.test(t)
                ? (s.color.push(n), r.push(c), i.push(l.parse(t)))
                : t.startsWith("var(")
                  ? (s.var.push(n), r.push("var"), i.push(t))
                  : (s.number.push(n), r.push(p), i.push(parseFloat(t))),
              ++n,
              "${}"
            ),
          )
          .split("${}");
      return { values: i, split: a, indexes: s, types: r };
    }
    function f(t) {
      let { split: e, types: i } = t,
        s = e.length;
      return (t) => {
        let n = "";
        for (let a = 0; a < s; a++)
          if (((n += e[a]), void 0 !== t[a])) {
            let e = i[a];
            e === p ? (n += (0, r.sanitize)(t[a])) : e === c ? (n += l.transform(t[a])) : (n += t[a]);
          }
        return n;
      };
    }
    t.s(
      [
        "analyseComplexValue",
        0,
        m,
        "complex",
        0,
        {
          test: function (t) {
            return (
              isNaN(t) &&
              "string" == typeof t &&
              (t.match(h.floatRegex)?.length || 0) + (t.match(u)?.length || 0) > 0
            );
          },
          parse: function (t) {
            return m(t).values;
          },
          createTransformer: function (t) {
            return f(m(t));
          },
          getAnimatableNone: function (t) {
            let e = m(t);
            return f(e)(
              e.values.map((t, i) =>
                ((t, e) =>
                  "number" == typeof t
                    ? e?.trim().endsWith("/")
                      ? t
                      : 0
                    : "number" == typeof t
                      ? 0
                      : l.test(t)
                        ? l.getAnimatableNone(t)
                        : t)(t, e.split[i]),
              ),
            );
          },
        },
      ],
      569577,
    );
  },
  277942,
  284061,
  (t) => {
    "use strict";
    var e = t.i(76307),
      i = t.i(265091);
    let s = (t) => (e) => e.test(t);
    t.s(["testValueType", 0, s], 284061);
    let r = [
      e.number,
      i.px,
      i.percent,
      i.degrees,
      i.vw,
      i.vh,
      { test: (t) => "auto" === t, parse: (t) => t },
    ];
    t.s(["dimensionValueTypes", 0, r, "findDimensionValueType", 0, (t) => r.find(s(t))], 277942);
  },
  203973,
  (t) => {
    "use strict";
    var e = t.i(279444),
      i = t.i(208792),
      s = t.i(719991);
    let r = {
      ...t.i(434929).numberValueTypes,
      color: e.color,
      backgroundColor: e.color,
      outlineColor: e.color,
      fill: e.color,
      stroke: e.color,
      borderColor: e.color,
      borderTopColor: e.color,
      borderRightColor: e.color,
      borderBottomColor: e.color,
      borderLeftColor: e.color,
      filter: i.filter,
      WebkitFilter: i.filter,
      mask: s.mask,
      WebkitMask: s.mask,
    };
    t.s(["defaultValueTypes", 0, r, "getDefaultValueType", 0, (t) => r[t]]);
  },
  434929,
  700848,
  (t) => {
    "use strict";
    var e = t.i(76307);
    let i = { ...e.number, transform: Math.round };
    var s = t.i(265091);
    let r = {
      rotate: s.degrees,
      pathRotation: s.degrees,
      rotateX: s.degrees,
      rotateY: s.degrees,
      rotateZ: s.degrees,
      scale: e.scale,
      scaleX: e.scale,
      scaleY: e.scale,
      scaleZ: e.scale,
      skew: s.degrees,
      skewX: s.degrees,
      skewY: s.degrees,
      distance: s.px,
      translateX: s.px,
      translateY: s.px,
      translateZ: s.px,
      x: s.px,
      y: s.px,
      z: s.px,
      perspective: s.px,
      transformPerspective: s.px,
      opacity: e.alpha,
      originX: s.progressPercentage,
      originY: s.progressPercentage,
      originZ: s.px,
    };
    t.s(["transformValueTypes", 0, r], 700848);
    let n = {
      borderWidth: s.px,
      borderTopWidth: s.px,
      borderRightWidth: s.px,
      borderBottomWidth: s.px,
      borderLeftWidth: s.px,
      borderRadius: s.px,
      borderTopLeftRadius: s.px,
      borderTopRightRadius: s.px,
      borderBottomRightRadius: s.px,
      borderBottomLeftRadius: s.px,
      width: s.px,
      maxWidth: s.px,
      height: s.px,
      maxHeight: s.px,
      top: s.px,
      right: s.px,
      bottom: s.px,
      left: s.px,
      inset: s.px,
      insetBlock: s.px,
      insetBlockStart: s.px,
      insetBlockEnd: s.px,
      insetInline: s.px,
      insetInlineStart: s.px,
      insetInlineEnd: s.px,
      padding: s.px,
      paddingTop: s.px,
      paddingRight: s.px,
      paddingBottom: s.px,
      paddingLeft: s.px,
      paddingBlock: s.px,
      paddingBlockStart: s.px,
      paddingBlockEnd: s.px,
      paddingInline: s.px,
      paddingInlineStart: s.px,
      paddingInlineEnd: s.px,
      margin: s.px,
      marginTop: s.px,
      marginRight: s.px,
      marginBottom: s.px,
      marginLeft: s.px,
      marginBlock: s.px,
      marginBlockStart: s.px,
      marginBlockEnd: s.px,
      marginInline: s.px,
      marginInlineStart: s.px,
      marginInlineEnd: s.px,
      fontSize: s.px,
      backgroundPositionX: s.px,
      backgroundPositionY: s.px,
      ...r,
      zIndex: i,
      fillOpacity: e.alpha,
      strokeOpacity: e.alpha,
      numOctaves: i,
    };
    t.s(["numberValueTypes", 0, n], 434929);
  },
  76307,
  (t) => {
    "use strict";
    var e = t.i(476959);
    let i = { test: (t) => "number" == typeof t, parse: parseFloat, transform: (t) => t },
      s = { ...i, transform: (t) => (0, e.clamp)(0, 1, t) },
      r = { ...i, default: 1 };
    t.s(["alpha", 0, s, "number", 0, i, "scale", 0, r]);
  },
  265091,
  (t) => {
    "use strict";
    let e = (t) => ({
        test: (e) => "string" == typeof e && e.endsWith(t) && 1 === e.split(" ").length,
        parse: parseFloat,
        transform: (e) => `${e}${t}`,
      }),
      i = e("deg"),
      s = e("%"),
      r = e("px"),
      n = e("vh"),
      a = e("vw"),
      o = { ...s, parse: (t) => s.parse(t) / 100, transform: (t) => s.transform(100 * t) };
    t.s(["degrees", 0, i, "percent", 0, s, "progressPercentage", 0, o, "px", 0, r, "vh", 0, n, "vw", 0, a]);
  },
  775554,
  (t) => {
    "use strict";
    var e = t.i(569577),
      i = t.i(208792),
      s = t.i(719991),
      r = t.i(203973);
    let n = new Set([i.filter, s.mask]);
    t.s([
      "getAnimatableNone",
      0,
      function (t, i) {
        let s = (0, r.getDefaultValueType)(t);
        return (n.has(s) || (s = e.complex), s.getAnimatableNone ? s.getAnimatableNone(i) : void 0);
      },
    ]);
  },
  166538,
  (t) => {
    "use strict";
    var e = t.i(279444),
      i = t.i(569577),
      s = t.i(277942),
      r = t.i(284061);
    let n = [...s.dimensionValueTypes, e.color, i.complex];
    t.s(["findValueType", 0, (t) => n.find((0, r.testValueType)(t))]);
  },
  446124,
  (t) => {
    "use strict";
    t.s(["getValueAsType", 0, (t, e) => (e && "number" == typeof t ? e.transform(t) : t)]);
  },
  83411,
  (t) => {
    "use strict";
    t.s(["isMotionValue", 0, (t) => !!(t && t.getVelocity)]);
  },
  476959,
  (t) => {
    "use strict";
    t.s(["clamp", 0, (t, e, i) => (i > e ? e : i < t ? t : i)]);
  },
  960855,
  (t) => {
    "use strict";
    t.s(["isBezierDefinition", 0, (t) => Array.isArray(t) && "number" == typeof t[0]]);
  },
  965566,
  82302,
  (t) => {
    "use strict";
    var e = t.i(247167);
    (t.s(
      [
        "formatErrorMessage",
        0,
        function (t, e) {
          return e
            ? `${t}. For more information and steps for solving, visit https://motion.dev/troubleshooting/${e}`
            : t;
        },
      ],
      82302,
    ),
      e.default,
      t.s(["invariant", 0, () => {}, "warning", 0, () => {}], 965566));
  },
  846791,
  (t) => {
    "use strict";
    t.s(["MotionGlobalConfig", 0, {}]);
  },
  172590,
  (t) => {
    "use strict";
    t.s(["isNumericalString", 0, (t) => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(t)]);
  },
  547507,
  (t) => {
    "use strict";
    t.s(["isZeroValueString", 0, (t) => /^0[^.\s]+$/u.test(t)]);
  },
  570596,
  133887,
  (t) => {
    "use strict";
    function e(t, e) {
      -1 === t.indexOf(e) && t.push(e);
    }
    function i(t, e) {
      let i = t.indexOf(e);
      i > -1 && t.splice(i, 1);
    }
    (t.s(
      [
        "addUniqueItem",
        0,
        e,
        "moveItem",
        0,
        function (t, e, i) {
          let [...s] = t,
            r = e < 0 ? s.length + e : e;
          if (r >= 0 && r < s.length) {
            let t = i < 0 ? s.length + i : i,
              [r] = s.splice(e, 1);
            s.splice(t, 0, r);
          }
          return s;
        },
        "removeItem",
        0,
        i,
      ],
      133887,
    ),
      t.s(
        [
          "SubscriptionManager",
          0,
          class {
            constructor() {
              this.subscriptions = [];
            }
            add(t) {
              return (e(this.subscriptions, t), () => i(this.subscriptions, t));
            }
            notify(t, e, i) {
              let s = this.subscriptions.length;
              if (s)
                if (1 === s) this.subscriptions[0](t, e, i);
                else
                  for (let r = 0; r < s; r++) {
                    let s = this.subscriptions[r];
                    s && s(t, e, i);
                  }
            }
            getSize() {
              return this.subscriptions.length;
            }
            clear() {
              this.subscriptions.length = 0;
            }
          },
        ],
        570596,
      ));
  },
  763074,
  (t) => {
    "use strict";
    t.s(["millisecondsToSeconds", 0, (t) => t / 1e3, "secondsToMilliseconds", 0, (t) => 1e3 * t]);
  },
  325791,
  (t) => {
    "use strict";
    t.s(["velocityPerSecond", 0, (t, e) => (e ? (1e3 / e) * t : 0)]);
  },
]);
