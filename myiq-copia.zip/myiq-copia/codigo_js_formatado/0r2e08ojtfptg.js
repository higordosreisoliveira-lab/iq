(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  354467,
  (t) => {
    "use strict";
    t.i(568267);
    var o = t.i(474734);
    t.s(["ButtonComponent", () => o.default]);
  },
  470280,
  function (t) {
    t.n(t.i(354467));
  },
]);
