(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  860278,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("book-open", [
      ["path", { d: "M12 7v14", key: "1akyts" }],
      [
        "path",
        {
          d: "M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",
          key: "ruj8y",
        },
      ],
    ]);
    e.s(["default", 0, t]);
  },
  810980,
  (e) => {
    "use strict";
    var t = e.i(860278);
    e.s(["BookOpen", () => t.default]);
  },
  354385,
  992163,
  244809,
  (e) => {
    "use strict";
    var t = e.i(475254);
    let a = (0, t.default)("clipboard-check", [
      ["rect", { width: "8", height: "4", x: "8", y: "2", rx: "1", ry: "1", key: "tgr4d6" }],
      [
        "path",
        { d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2", key: "116196" },
      ],
      ["path", { d: "m9 14 2 2 4-4", key: "df797q" }],
    ]);
    e.s(["ClipboardCheck", 0, a], 354385);
    let i = (0, t.default)("gamepad-2", [
      ["line", { x1: "6", x2: "10", y1: "11", y2: "11", key: "1gktln" }],
      ["line", { x1: "8", x2: "8", y1: "9", y2: "13", key: "qnk9ow" }],
      ["line", { x1: "15", x2: "15.01", y1: "12", y2: "12", key: "krot7o" }],
      ["line", { x1: "18", x2: "18.01", y1: "10", y2: "10", key: "1lcuu1" }],
      [
        "path",
        {
          d: "M17.32 5H6.68a4 4 0 0 0-3.978 3.59c-.006.052-.01.101-.017.152C2.604 9.416 2 14.456 2 16a3 3 0 0 0 3 3c1 0 1.5-.5 2-1l1.414-1.414A2 2 0 0 1 9.828 16h4.344a2 2 0 0 1 1.414.586L17 18c.5.5 1 1 2 1a3 3 0 0 0 3-3c0-1.545-.604-6.584-.685-7.258-.007-.05-.011-.1-.017-.151A4 4 0 0 0 17.32 5z",
          key: "mfqc10",
        },
      ],
    ]);
    e.s(["Gamepad2", 0, i], 992163);
    let l = (0, t.default)("house", [
      ["path", { d: "M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8", key: "5wwlr5" }],
      [
        "path",
        {
          d: "M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
          key: "1d0kgt",
        },
      ],
    ]);
    e.s(["House", 0, l], 244809);
  },
  32095,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("graduation-cap", [
      [
        "path",
        {
          d: "M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z",
          key: "j76jl0",
        },
      ],
      ["path", { d: "M22 10v6", key: "1lu8f3" }],
      ["path", { d: "M6 12.5V16a6 3 0 0 0 12 0v-3.5", key: "1r8lef" }],
    ]);
    e.s(["GraduationCap", 0, t], 32095);
  },
  477754,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("puzzle", [
      [
        "path",
        {
          d: "M15.39 4.39a1 1 0 0 0 1.68-.474 2.5 2.5 0 1 1 3.014 3.015 1 1 0 0 0-.474 1.68l1.683 1.682a2.414 2.414 0 0 1 0 3.414L19.61 15.39a1 1 0 0 1-1.68-.474 2.5 2.5 0 1 0-3.014 3.015 1 1 0 0 1 .474 1.68l-1.683 1.682a2.414 2.414 0 0 1-3.414 0L8.61 19.61a1 1 0 0 0-1.68.474 2.5 2.5 0 1 1-3.014-3.015 1 1 0 0 0 .474-1.68l-1.683-1.682a2.414 2.414 0 0 1 0-3.414L4.39 8.61a1 1 0 0 1 1.68.474 2.5 2.5 0 1 0 3.014-3.015 1 1 0 0 1-.474-1.68l1.683-1.682a2.414 2.414 0 0 1 3.414 0z",
          key: "w46dr5",
        },
      ],
    ]);
    e.s(["Puzzle", 0, t], 477754);
  },
  817886,
  974718,
  213101,
  422783,
  745165,
  357738,
  (e) => {
    "use strict";
    var t,
      a,
      i,
      l,
      n,
      s,
      r,
      o,
      c = e.i(271645);
    function m() {
      return (m = Object.assign.bind()).apply(null, arguments);
    }
    function d() {
      return (d = Object.assign.bind()).apply(null, arguments);
    }
    function p() {
      return (p = Object.assign.bind()).apply(null, arguments);
    }
    function x() {
      return (x = Object.assign.bind()).apply(null, arguments);
    }
    function h() {
      return (h = Object.assign.bind()).apply(null, arguments);
    }
    (e.s(
      [
        "default",
        0,
        (e) =>
          c.createElement(
            "svg",
            m({ xmlns: "http://www.w3.org/2000/svg", width: 31, height: 31, fill: "none" }, e),
            t ||
              (t = c.createElement("path", {
                fill: "#2C3345",
                fillRule: "evenodd",
                d: "m14.29 23.288-.082-.048zm-8.865-12.77-.373-.148a.7.7 0 0 1-.338.41l-.286.148a4.04 4.04 0 0 0-1.62 1.517 4.25 4.25 0 0 0 .068 4.469l.301.476.002.003a3 3 0 0 0 1.707 1.263 2.9 2.9 0 0 0 2.098-.214l.004-.002a.65.65 0 0 1 .513-.041c.17.057.314.183.399.355.084.173.1.374.041.559a.7.7 0 0 1-.344.418l-.376.197.22.364a3.3 3.3 0 0 0 1.082 1.101l.01.007a3.2 3.2 0 0 0 2.471.323l.008-.002 6.186-1.85h.001a.65.65 0 0 1 .51.058.7.7 0 0 1 .33.426.77.77 0 0 1-.063.555.7.7 0 0 1-.405.344l-1.54.461-.702.21.557.477c.358.306.688.564.991.802.957.749 1.659 1.297 2.19 2.528l.003.009.005.008a1 1 0 0 0 .929.568 1.02 1.02 0 0 0 .729-.315 1.06 1.06 0 0 0 .298-.742v-1.698a.76.76 0 0 1 .151-.45.7.7 0 0 1 .372-.254h.002l3.928-1.012c.398-.093.749-.326.993-.656s.367-.734.35-1.145a1.8 1.8 0 0 0-.5-1.237l-.005-.004-.634-.641-.207-.21-.261.136-.255.132a.66.66 0 0 1-.664-.026.732.732 0 0 1-.163-1.078.7.7 0 0 1 .208-.167h.001l.433-.224.008-.005.008-.004a3.83 3.83 0 0 0 1.412-1.427 4 4 0 0 0 .519-1.962c0-.42-.08-.835-.235-1.223a3.2 3.2 0 0 0-.67-1.04h-.001l-.328-.339-.002-.002a.8.8 0 0 1-.17-.282l-.07-.22a5.5 5.5 0 0 0-1.784-2.606 5.24 5.24 0 0 0-2.893-1.146l-.14-.01-.115.078a2.62 2.62 0 0 0-1.054 1.499 2.7 2.7 0 0 0 .168 1.837l.003.006a.73.73 0 0 1-.092.792.7.7 0 0 1-.204.165.66.66 0 0 1-.664-.025.7.7 0 0 1-.254-.285 4.2 4.2 0 0 1-.384-2.288 4.15 4.15 0 0 1 .884-2.134l.311-.388-.445-.221a4.85 4.85 0 0 0-3.834-.211l-.485.178.294.425q.203.292.357.616l.001.002.188.387v.003a.75.75 0 0 1-.092.805.656.656 0 0 1-.954.078.7.7 0 0 1-.166-.218l-.184-.396a3.02 3.02 0 0 0-1.334-1.434 2.9 2.9 0 0 0-1.92-.284h-.002A7.1 7.1 0 0 0 7.11 7.16a7.43 7.43 0 0 0-2.058 3.21zm21.38 6.333-.22.25.206.262.375.478.013.017.015.015c.382.392.66.88.807 1.42.146.539.155 1.108.025 1.652a3.26 3.26 0 0 1-.763 1.446 3.1 3.1 0 0 1-1.336.86l-3.104.802-.3.078v1.13c0 .665-.255 1.3-.706 1.768a2.35 2.35 0 0 1-1.69.725h-.005c-.454.005-.9-.126-1.285-.38a2.4 2.4 0 0 1-.882-1.05c-.775-1.796-2.034-2.538-3.47-3.386q-.322-.189-.654-.39l-.152-.093-.17.05-2.002.597h-.001c-.43.125-.876.184-1.323.178h-.01a4.4 4.4 0 0 1-2.339-.657l-.006-.004a4.53 4.53 0 0 1-1.88-2.193l-.101-.246-.266-.003a4.2 4.2 0 0 1-1.99-.532 4.36 4.36 0 0 1-1.529-1.434l-.002-.003-.316-.476a5.7 5.7 0 0 1-.835-2.16 5.8 5.8 0 0 1 .09-2.33 5.65 5.65 0 0 1 1.002-2.084 5.4 5.4 0 0 1 1.732-1.476l.131-.07.053-.14a8.9 8.9 0 0 1 2.499-3.566 8.44 8.44 0 0 1 3.836-1.882 4.3 4.3 0 0 1 2.636.356l.192.092.184-.108a6.2 6.2 0 0 1 3.363-.86 6.24 6.24 0 0 1 3.302 1.084l.431.298.094.064.114.006a6.54 6.54 0 0 1 3.704 1.388 6.9 6.9 0 0 1 2.309 3.318l.028.088.064.067.145.149a4.76 4.76 0 0 1 1.33 3.289 5.38 5.38 0 0 1-1.342 3.596",
                clipRule: "evenodd",
              })),
          ),
      ],
      974718,
    ),
      e.s(
        [
          "default",
          0,
          (e) =>
            c.createElement(
              "svg",
              d({ xmlns: "http://www.w3.org/2000/svg", width: 31, height: 31, fill: "currentColor" }, e),
              a ||
                (a = c.createElement("path", {
                  fill: "#fff",
                  fillRule: "evenodd",
                  d: "m27.814 16.724-.222.25.595.756.015.015c.382.392.66.881.807 1.42.146.539.155 1.108.025 1.652a3.26 3.26 0 0 1-.763 1.445 3.1 3.1 0 0 1-1.335.86l-3.404.88v1.13c0 .665-.255 1.3-.706 1.767a2.35 2.35 0 0 1-1.69.726h-.005c-.454.005-.9-.126-1.284-.38a2.4 2.4 0 0 1-.882-1.05c-.776-1.795-2.034-2.538-3.47-3.386a51 51 0 0 1-.653-.39l-.152-.092-2.172.646h-.001c-.431.125-.876.185-1.323.178h-.01a4.4 4.4 0 0 1-2.338-.656l-.003-.002-.004-.002a4.53 4.53 0 0 1-1.88-2.193l-.1-.246-.266-.003a4.2 4.2 0 0 1-1.99-.532 4.36 4.36 0 0 1-1.528-1.434l-.003-.003-.315-.475a5.7 5.7 0 0 1-.835-2.16 5.8 5.8 0 0 1 .09-2.329c.189-.76.53-1.471 1.001-2.084a5.4 5.4 0 0 1 1.732-1.476l.131-.07.054-.14A8.9 8.9 0 0 1 7.427 5.78a8.44 8.44 0 0 1 3.836-1.88 4.3 4.3 0 0 1 2.635.355l.192.092.184-.108a6.2 6.2 0 0 1 3.363-.86 6.24 6.24 0 0 1 3.301 1.084h.001l.524.362.114.006c1.34.066 2.63.549 3.704 1.387a6.9 6.9 0 0 1 2.308 3.318l.028.088.209.216a4.76 4.76 0 0 1 1.329 3.288 5.38 5.38 0 0 1-1.341 3.596m-12.74-9.072a.7.7 0 0 1-.166-.217l-.185-.396a3 3 0 0 0-1.334-1.433 2.9 2.9 0 0 0-1.919-.284h-.003a7.1 7.1 0 0 0-3.346 1.712 7.43 7.43 0 0 0-2.057 3.21.7.7 0 0 1-.338.41l-.285.147a4.04 4.04 0 0 0-1.621 1.517 4.252 4.252 0 0 0 .068 4.468l.301.477.002.003a3 3 0 0 0 1.707 1.263 2.9 2.9 0 0 0 2.098-.215L8 18.313a.65.65 0 0 1 .513-.04c.17.057.314.183.398.355s.1.373.042.558a.7.7 0 0 1-.344.418l-.377.197.22.364c.272.448.642.826 1.082 1.101l.005.003.005.004c.75.437 1.638.554 2.471.323l.004-.001 6.189-1.85a.65.65 0 0 1 .51.057c.157.09.278.241.33.426a.77.77 0 0 1-.062.555.7.7 0 0 1-.405.344l-2.242.672.557.476c.358.306.688.564.991.801.957.749 1.658 1.298 2.19 2.528l.003.009.004.008c.085.174.218.321.384.423.164.1.353.15.545.145a1.02 1.02 0 0 0 .729-.315 1.06 1.06 0 0 0 .298-.742v-1.698a.76.76 0 0 1 .151-.45.7.7 0 0 1 .373-.253l3.928-1.013c.398-.092.749-.325.993-.655s.367-.734.35-1.145a1.8 1.8 0 0 0-.5-1.236l-.004-.005-.841-.85-.517.267a.654.654 0 0 1-.664-.026.735.735 0 0 1-.163-1.078.7.7 0 0 1 .209-.166l.442-.229.008-.004a3.83 3.83 0 0 0 1.412-1.427 4 4 0 0 0 .518-1.962c0-.419-.08-.834-.235-1.222a3.2 3.2 0 0 0-.67-1.04l-.329-.34H26.5a.8.8 0 0 1-.169-.283l-.07-.22a5.5 5.5 0 0 0-1.784-2.606 5.24 5.24 0 0 0-2.893-1.146l-.139-.01-.115.078a2.62 2.62 0 0 0-1.054 1.5 2.7 2.7 0 0 0 .167 1.836l.003.006a.73.73 0 0 1-.091.792.7.7 0 0 1-.205.164.655.655 0 0 1-.664-.025.7.7 0 0 1-.253-.284 4.2 4.2 0 0 1-.384-2.288 4.15 4.15 0 0 1 .884-2.134l.31-.387-.444-.221a4.844 4.844 0 0 0-3.833-.211l-.486.178.294.425q.203.292.357.615l.189.39v.002a.75.75 0 0 1-.092.805.656.656 0 0 1-.954.078",
                  clipRule: "evenodd",
                })),
            ),
        ],
        213101,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            c.createElement(
              "svg",
              p({ xmlns: "http://www.w3.org/2000/svg", width: 47, height: 46, fill: "none" }, e),
              i ||
                (i = c.createElement("path", {
                  stroke: "#0070F3",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 3,
                  d: "M23.499 24.583a7.917 7.917 0 1 0 0-15.833 7.917 7.917 0 0 0 0 15.833",
                })),
              l ||
                (l = c.createElement("path", {
                  stroke: "#0070F3",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 3,
                  d: "M36.165 37.25a12.667 12.667 0 0 0-25.333 0",
                })),
            ),
        ],
        422783,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            c.createElement(
              "svg",
              x({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 47 46" }, e),
              n ||
                (n = c.createElement("path", {
                  stroke: "#0070F3",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2.6,
                  d: "M17.168 7.166v6.333m12.664-6.333v6.333",
                })),
              s ||
                (s = c.createElement("path", {
                  stroke: "#0070F3",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 3,
                  d: "M34.583 10.334H12.417a3.167 3.167 0 0 0-3.167 3.167v22.166a3.167 3.167 0 0 0 3.167 3.167h22.166a3.167 3.167 0 0 0 3.167-3.167V13.501a3.167 3.167 0 0 0-3.167-3.167",
                })),
              r ||
                (r = c.createElement("path", {
                  stroke: "#0070F3",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2.6,
                  d: "M9.25 19.834h28.5m-19 9.499 3.167 3.166 6.333-6.333",
                })),
            ),
        ],
        745165,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            c.createElement(
              "svg",
              h({ xmlns: "http://www.w3.org/2000/svg", width: 25, height: 24, viewBox: "0 0 8.13 8.12" }, e),
              o ||
                (o = c.createElement("path", {
                  fill: "currentColor",
                  d: "M7.34 4.9c-.73-.74-2.15-1.19-3.27-1.19S1.52 4.16.79 4.9c-.99.98-1.21 2.07.26 2.77.58.27 1.83.45 3.02.45 1.18 0 2.43-.18 3.01-.45 1.47-.71 1.25-1.79.26-2.77m-6.11.43c.62-.62 1.89-1 2.84-1s2.21.38 2.83 1c.67.67.97 1.28-.08 1.78-.5.24-1.67.39-2.75.39-1.09 0-2.26-.15-2.75-.39C.26 6.6.56 6 1.23 5.33M4.07 0c.48 0 .92.2 1.24.52.32.31.52.75.52 1.24s-.2.93-.52 1.24c-.32.32-.76.52-1.24.52-.49 0-.93-.2-1.25-.52-.32-.31-.51-.75-.51-1.24S2.5.83 2.82.52C3.14.2 3.58 0 4.07 0m.8.95a1.143 1.143 0 0 0-1.61 0c-.21.21-.33.5-.33.81s.12.6.33.8c.21.21.49.34.81.34.31 0 .6-.13.8-.34.21-.2.33-.49.33-.8s-.12-.6-.33-.81",
                  className: "user-ico_svg__fil0",
                })),
            ),
        ],
        357738,
      ),
      e.s([], 817886));
  },
  120848,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(948148),
      i = e.i(271645),
      l = e.i(335889),
      n = e.i(742214),
      s = e.i(157273),
      r = e.i(47252),
      o = e.i(382963),
      c = e.i(622963),
      m = e.i(86596),
      d = e.i(962607),
      p = e.i(444113),
      x = e.i(824511),
      h = e.i(861745),
      u = e.i(663615),
      g = e.i(335190),
      _ = e.i(19576);
    let v = (e) => {
        let { initialComplete: a, ...i } = e;
        return (0, t.jsx)("svg", {
          ...i,
          fill: "none",
          stroke: "currentColor",
          strokeWidth: 2,
          viewBox: "0 0 24 24",
          children: (0, t.jsx)(x.m.path, {
            animate: { pathLength: 1 },
            d: "M5 13l4 4L19 7",
            initial: { pathLength: +!!a },
            strokeLinecap: "round",
            strokeLinejoin: "round",
            transition: { delay: 0.2, type: "tween", ease: "easeOut", duration: 0.3 },
          }),
        });
      },
      f = (0, i.forwardRef)((e, a) => {
        let {
            steps: i = [],
            defaultStep: l = 0,
            onStepChange: n,
            currentStep: s,
            hideProgressBars: r = !1,
            stepClassName: o,
            navClassName: c,
            className: m,
            ...f
          } = e,
          [w, b] = (0, g.useControlledState)(s, l, n),
          k = (0, h.useLocale)();
        return (0, t.jsx)("nav", {
          "aria-label": "Progress",
          className: `w-full max-w-[520px] overflow-x-scroll ${c || ""}`,
          children: (0, t.jsx)("ol", {
            className: (0, u.cn)("flex flex-row flex-nowrap justify-center", m),
            children: i?.map((e, l) => {
              let n = w === l ? "active" : w < l ? "inactive" : "complete";
              return (0, t.jsx)(
                "li",
                {
                  className: "relative flex w-full max-w-[120px] items-center",
                  children: (0, t.jsxs)(
                    "button",
                    {
                      ref: a,
                      "aria-current": "active" === n ? "step" : void 0,
                      className: (0, u.cn)(
                        "group relative flex h-full w-full cursor-pointer flex-col-reverse items-center justify-center gap-y-2 rounded-large",
                        o,
                      ),
                      onClick: () => b(l),
                      ...f,
                      children: [
                        e.title &&
                          (0, t.jsx)("div", {
                            className: "max-w-[60px] flex-1 px-0.5 text-center",
                            children: (0, t.jsx)("div", {
                              className: (0, u.cn)(
                                "line-clamp-2 text-[10px] font-light leading-[1.15] text-default-foreground transition-[color,opacity] duration-300 group-active:opacity-80",
                              ),
                              children: e.title,
                            }),
                          }),
                        (0, t.jsxs)("div", {
                          className: "h-ful flex items-center",
                          children: [
                            (0, t.jsx)(p.LazyMotion, {
                              features: d.domAnimation,
                              children: (0, t.jsx)(x.m.div, {
                                animate: n,
                                className: "relative",
                                children: (0, t.jsx)(x.m.div, {
                                  className: (0, u.cn)(
                                    "relative flex h-[22px] w-[22px] items-center justify-center rounded-full border-medium font-light text-default-foreground text-large",
                                    { "shadow-lg": "complete" === n },
                                    { "!bg-[#E8F5FD]": "active" === n },
                                  ),
                                  transition: { duration: 0.25 },
                                  initial: "complete" === n && {
                                    backgroundColor: "hsl(var(--heroui-primary))",
                                    borderColor: "hsl(var(--heroui-primary))",
                                    color: "white",
                                  },
                                  variants: {
                                    inactive: {
                                      backgroundColor: "transparent",
                                      borderColor: "#AADDFF",
                                      color: "hsl(var(--heroui-default-300))",
                                    },
                                    active: {
                                      backgroundColor: "transparent",
                                      borderColor: "#AADDFF",
                                      color: "hsl(var(--heroui-primary)",
                                    },
                                    complete: {
                                      backgroundColor: "hsl(var(--heroui-primary)",
                                      borderColor: "hsl(var(--heroui-primary)",
                                    },
                                  },
                                  children: (0, t.jsx)("div", {
                                    className: "flex items-center justify-center",
                                    children:
                                      "complete" === n
                                        ? (0, t.jsx)(v, {
                                            className: "h-5 w-5 text-white",
                                            initialComplete: !0,
                                          })
                                        : "active" === n &&
                                          (0, t.jsx)("span", {
                                            className: "h-2 w-2 rounded-full",
                                            style: { backgroundColor: "hsl(var(--heroui-primary))" },
                                          }),
                                  }),
                                }),
                              }),
                            }),
                            l < i.length - 1 &&
                              !r &&
                              (0, t.jsx)("div", {
                                "aria-hidden": "true",
                                className: (0, u.cn)(
                                  `pointer-events-none absolute ${e.title ? "top-[23%]" : "top-[50%]"} flex w-[50%] -translate-y-1/2 items-center`,
                                  "rtl" === (0, _.getLocaleDirection)(k)
                                    ? "right-1/2 -translate-x-1/2"
                                    : "left-1/2 translate-x-1/2",
                                ),
                                style: { "--idx": l },
                                children: (0, t.jsx)("div", {
                                  className: (0, u.cn)(
                                    "relative h-0.5 w-full bg-[#AADDFF] transition-colors duration-300",
                                    "after:absolute after:block after:h-full after:w-0 after:bg-[var(--active-border-color)] after:transition-[width] after:duration-300 after:content-['']",
                                    { "after:w-full": l < w },
                                  ),
                                }),
                              }),
                          ],
                        }),
                      ],
                    },
                    `step-button-${l}`,
                  ),
                },
                `step-li-${l}`,
              );
            }),
          }),
        });
      });
    f.displayName = "StepperComponent";
    var w = e.i(60423),
      b = e.i(810980),
      k = e.i(354385),
      y = e.i(992163),
      j = e.i(32095),
      N = e.i(244809),
      C = e.i(477754);
    e.i(817886);
    var L = e.i(745165),
      L = L,
      M = e.i(422783),
      M = M;
    (e.s([], 100629),
      e.i(100629),
      e.s(
        [
          "CongratulationsIntroModalComponent",
          0,
          () => {
            let e,
              d = (0, m.useUserStore)((e) => e.user?.email),
              p = (0, a.useTranslations)(),
              { handleChangeModalStore: x, setIsIntroModalShowed: h } = (0, c.useModalStore)(),
              { trigger: u } = (0, o.useUpdateUserInDatabaseMutation)(),
              [g, _] = (0, i.useState)(0),
              v =
                ((e = (0, a.useTranslations)()),
                [
                  {
                    icon: (0, t.jsx)("p", {
                      className:
                        "mx-auto font-sans text-[42px] leading-[42px] [@media(max-height:500px)]:text-[30px] [@media(max-height:500px)]:leading-[30px]",
                      children: "🎉",
                    }),
                    title: e.raw("congratulations_page_intro_modal_title_1"),
                    description: e("congratulations_page_intro_modal_description_1"),
                    skipEventName: "skipButtonClicked",
                    continueEventName: "letsGoButtonClicked",
                  },
                  {
                    icon: (0, t.jsx)("div", {
                      className: "mx-auto",
                      children: (0, t.jsx)(k.ClipboardCheck, {
                        className:
                          "h-[42px] w-[42px] text-primary [@media(max-height:500px)]:h-[30px] [@media(max-height:500px)]:w-[30px]",
                      }),
                    }),
                    title: e.raw("congratulations_page_intro_modal_title_4_v2"),
                    description: e("congratulations_page_intro_modal_description_4_v2"),
                    continueEventName: "TestsTabContinueClicked",
                    skipEventName: "TestsTabSkipClicked",
                  },
                  {
                    icon: (0, t.jsx)("div", {
                      className: "mx-auto",
                      children: (0, t.jsx)(N.House, {
                        className:
                          "h-[42px] w-[42px] text-primary [@media(max-height:500px)]:h-[30px] [@media(max-height:500px)]:w-[30px]",
                      }),
                    }),
                    title: e.raw("congratulations_page_intro_modal_title_2_v2"),
                    description: e.raw("congratulations_page_intro_modal_description_2_v2"),
                    skipEventName: "LobbyTabSkipClicked",
                    continueEventName: "LobbyTabContinueClicked",
                  },
                  {
                    icon: (0, t.jsx)("div", {
                      className: "mx-auto",
                      children: (0, t.jsx)(y.Gamepad2, {
                        className:
                          "h-[42px] w-[42px] text-primary [@media(max-height:500px)]:h-[30px] [@media(max-height:500px)]:w-[30px]",
                      }),
                    }),
                    title: e.raw("congratulations_page_intro_modal_title_3"),
                    description: e("congratulations_page_intro_modal_description_3"),
                    skipEventName: "GamesTabSkipClicked",
                    continueEventName: "GameTabContinueClicked",
                  },
                  {
                    icon: (0, t.jsx)("div", {
                      className: "mx-auto",
                      children: (0, t.jsx)(b.BookOpen, {
                        className:
                          "h-[42px] w-[42px] text-primary [@media(max-height:500px)]:h-[30px] [@media(max-height:500px)]:w-[30px]",
                      }),
                    }),
                    title: e.raw("congratulations_page_intro_modal_title_5"),
                    description: e("congratulations_page_intro_modal_description_5"),
                    skipEventName: "CoursesTabSkipClicked",
                    continueEventName: "CoursesTabContinueClicked",
                  },
                ]),
              j = v[g],
              C = async () => {
                (w.accessLocalStorage.setItem(s.StorageKeys.IS_INTRO_MODAL_SHOWED, "true"),
                  h(!0),
                  d && u({ email: d, userInfo: { isIntroModalShowed: !0 } }));
              };
            return (0, t.jsxs)(n.ModalContent, {
              className:
                "flex min-h-[270px] max-w-[480px] flex-col items-center p-6 max-md:overflow-auto [@media(max-height:500px)]:my-0 [@media(max-height:500px)]:px-6 [@media(max-height:500px)]:pb-2 [@media(max-height:500px)]:pt-4",
              children: [
                (0, t.jsx)(f, {
                  navClassName: "!overflow-x-visible h-[30px]",
                  currentStep: g,
                  steps: v.map((e) => ({ ...e, title: "" })),
                  className: "pointer-events-none mb-4",
                }),
                (0, t.jsx)("div", { className: "mt-2", children: j.icon }),
                (0, t.jsx)("p", {
                  className:
                    "mt-3 w-full text-center text-lg font-semibold xs-s:text-[20px] xs-base:text-[24px] [@media(max-height:500px)]:mt-2 [@media(max-height:500px)]:text-lg",
                  dangerouslySetInnerHTML: { __html: (0, r.sanitizeTranslationHtml)(j.title) },
                }),
                (0, t.jsx)("p", {
                  className:
                    "mt-4 min-h-[108px] w-full text-pretty text-center xs-sm:text-lg md:min-h-[81px] [@media(max-height:500px)]:mt-2 [@media(max-height:500px)]:min-h-[70px] [@media(max-height:500px)]:text-base",
                  dangerouslySetInnerHTML: { __html: (0, r.sanitizeTranslationHtml)(j.description) },
                }),
                (0, t.jsxs)("div", {
                  className: "mt-6 grid w-full grid-cols-[2fr_4fr] gap-2.5 [@media(max-height:500px)]:mt-2",
                  children: [
                    (0, t.jsx)(l.Button, {
                      onPress: () => {
                        (C(), x({ isModalVisible: !1 }));
                      },
                      className:
                        "h-12 whitespace-pre-wrap rounded-xl bg-[#EFF2FD] text-[13px] font-semibold text-[#121620] xs-sm:text-sm md:text-base [&_div]:absolute",
                      variant: "flat",
                      children: p("btn_skip"),
                    }),
                    (0, t.jsx)(l.Button, {
                      onPress: () =>
                        g + 1 === v.length ? (C(), x({ isModalVisible: !1 })) : _((e) => e + 1),
                      className:
                        "h-12 !whitespace-normal rounded-xl bg-green-custom text-[13px] font-semibold text-white xs-sm:text-sm md:text-base",
                      variant: "flat",
                      children: p(0 === g ? "congratulations_page_intro_modal_go" : "btn_continue"),
                    }),
                  ],
                }),
              ],
            });
          },
          "CongratulationsIntroModalComponentV2",
          0,
          () => {
            let e,
              o = (0, a.useTranslations)(),
              { handleChangeModalStore: m } = (0, c.useModalStore)(),
              [d, p] = (0, i.useState)(0),
              x =
                ((e = (0, a.useTranslations)()),
                [
                  {
                    icon: (0, t.jsx)("p", {
                      className:
                        "mx-auto text-[42px] leading-[42px] [@media(max-height:500px)]:text-[30px] [@media(max-height:500px)]:leading-[30px]",
                      children: "🎉",
                    }),
                    title: e.raw("congratulations_page_intro_modal_title_1"),
                    description: e("congratulations_page_intro_modal_description_1"),
                  },
                  {
                    icon: (0, t.jsx)("div", {
                      className: "mx-auto",
                      children: (0, t.jsx)(L.default, {
                        className:
                          "h-[42px] w-[42px] text-primary [@media(max-height:500px)]:h-[30px] [@media(max-height:500px)]:w-[30px]",
                      }),
                    }),
                    title: e.raw("congratulations_page_intro_modal_title_2_v2"),
                    description: e("congratulations_page_intro_modal_description_2_v2"),
                  },
                  {
                    icon: (0, t.jsx)("div", {
                      className: "mx-auto",
                      children: (0, t.jsx)(y.Gamepad2, {
                        className: "h-[40] w-[40] text-primary sm:h-[46px] sm:w-[46px]",
                      }),
                    }),
                    title: e.raw("congratulations_page_intro_modal_title_3"),
                    description: e("congratulations_page_intro_modal_description_3"),
                  },
                  {
                    icon: (0, t.jsx)("div", {
                      className: "mx-auto",
                      children: (0, t.jsx)(j.GraduationCap, {
                        className:
                          "h-[42px] w-[42px] text-primary [@media(max-height:500px)]:h-[30px] [@media(max-height:500px)]:w-[30px]",
                      }),
                    }),
                    title: e.raw("congratulations_page_intro_modal_title_5"),
                    description: e("congratulations_page_intro_modal_description_5"),
                  },
                  {
                    icon: (0, t.jsx)("div", {
                      className: "mx-auto",
                      children: (0, t.jsx)(M.default, {
                        className:
                          "h-[42px] w-[42px] text-primary [@media(max-height:500px)]:h-[30px] [@media(max-height:500px)]:w-[30px]",
                      }),
                    }),
                    title: e.raw("congratulations_page_intro_modal_title_4_v2"),
                    description: e("congratulations_page_intro_modal_description_4_v2"),
                  },
                  {
                    icon: (0, t.jsx)("div", {
                      className: "mx-auto",
                      children: (0, t.jsx)(C.Puzzle, {
                        className:
                          "h-[42px] w-[42px] text-primary [@media(max-height:500px)]:h-[30px] [@media(max-height:500px)]:w-[30px]",
                      }),
                    }),
                    title: e.raw("congratulations_page_intro_modal_title_6_v2"),
                    description: e("congratulations_page_intro_modal_description_6_v2"),
                  },
                ]),
              h = x[d],
              u = async () => {
                w.accessLocalStorage.setItem(s.StorageKeys.IS_INTRO_MODAL_SHOWED, "true");
              };
            return (0, t.jsxs)(n.ModalContent, {
              className:
                "flex min-h-[270px] max-w-[480px] flex-col items-center p-6 max-md:overflow-auto [@media(max-height:500px)]:my-0 [@media(max-height:500px)]:px-6 [@media(max-height:500px)]:pb-2 [@media(max-height:500px)]:pt-4",
              children: [
                (0, t.jsx)(f, {
                  navClassName: "!overflow-x-visible h-[30px]",
                  currentStep: d,
                  steps: x.map((e) => ({ ...e, title: "" })),
                  className: "pointer-events-none mb-4",
                }),
                (0, t.jsx)("div", { className: "mt-6", children: h.icon }),
                (0, t.jsx)("p", {
                  className:
                    "mt-3 w-full text-center text-[24px] font-semibold [@media(max-height:500px)]:mt-2 [@media(max-height:500px)]:text-lg",
                  dangerouslySetInnerHTML: { __html: (0, r.sanitizeTranslationHtml)(h.title) },
                }),
                (0, t.jsx)("p", {
                  className:
                    "mt-4 min-h-[108px] w-full text-center text-base text-grey-dark sm:text-lg md:min-h-[81px] [@media(max-height:500px)]:mt-2 [@media(max-height:500px)]:min-h-[70px] [@media(max-height:500px)]:text-base",
                  dangerouslySetInnerHTML: { __html: (0, r.sanitizeTranslationHtml)(h.description) },
                }),
                (0, t.jsx)("div", {
                  className: "grid w-full gap-2.5 md:mt-6",
                  children: (0, t.jsx)(l.Button, {
                    onPress: () => (d + 1 === x.length ? (u(), m({ isModalVisible: !1 })) : p((e) => e + 1)),
                    className:
                      "h-12 !whitespace-normal rounded-xl bg-green-custom text-sm font-medium text-white text-medium md:text-base",
                    variant: "flat",
                    children: o(0 === d ? "congratulations_page_intro_modal_go" : "btn_continue"),
                  }),
                }),
              ],
            });
          },
        ],
        120848,
      ));
  },
  658353,
  function (e) {
    e.n(e.i(120848));
  },
  47252,
  (e) => {
    "use strict";
    let t = new Set(["span", "b", "strong", "em", "i", "u", "br", "sup", "sub", "small", "a"]),
      a = new Set(["br"]),
      i = /^<\s*(\/?)\s*([a-zA-Z][a-zA-Z0-9]*)([^>]*)>$/,
      l = /([^\s"'<>/=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g,
      n = /^[\w\s:.[\]/%#-]*$/,
      s = /^(\/(?![/\\])|#|https?:\/\/|mailto:)[^\s\p{Cc}]*$/iu,
      r = /^[a-z\s]*$/i,
      o = { amp: "&", quot: '"', apos: "'", lt: "<", gt: ">", nbsp: " " },
      c = (e) => e.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;"),
      m = (e, t, a) => {
        let i,
          l,
          c =
            ((i = !0),
            (l = a.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);?/gi, (e, t) => {
              if ("#" === t[0]) {
                let e = "x" === t[1].toLowerCase() ? parseInt(t.slice(2), 16) : parseInt(t.slice(1), 10);
                return Number.isFinite(e) && e <= 1114111 ? String.fromCodePoint(e) : "";
              }
              let a = o[t.toLowerCase()];
              return (void 0 === a && (i = !1), a ?? e);
            })),
            i ? l : null);
        return null === c
          ? null
          : "class" === t
            ? n.test(c)
              ? c
              : null
            : "a" !== e
              ? null
              : "href" === t
                ? s.test(c.trim())
                  ? c.trim()
                  : null
                : "target" === t
                  ? "_blank" === c
                    ? c
                    : null
                  : "rel" === t
                    ? r.test(c)
                      ? c
                      : null
                    : "title" === t
                      ? c
                      : null;
      },
      d = (e) => {
        let n = i.exec(e);
        if (!n) return e.replace(/</g, "&lt;");
        let [, s, r, o] = n,
          d = r.toLowerCase();
        if (!t.has(d)) return "";
        if (s) return a.has(d) ? "" : `</${d}>`;
        let p = [];
        for (let [, e, t, a, i] of o.matchAll(l)) {
          let l = e.toLowerCase(),
            n = m(d, l, t ?? a ?? i ?? "");
          null !== n && p.push(`${l}="${c(n)}"`);
        }
        return `<${[d, ...p].join(" ")}>`;
      };
    e.s([
      "sanitizeTranslationHtml",
      0,
      (e) => ("number" == typeof e ? String(e) : "string" != typeof e ? "" : e.replace(/<[^>]*>?/g, d)),
    ]);
  },
]);
