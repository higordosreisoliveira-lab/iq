(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  412012,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("chevron-left", [["path", { d: "m15 18-6-6 6-6", key: "1wnfg3" }]]);
    e.s(["default", 0, t]);
  },
  373375,
  (e) => {
    "use strict";
    var t = e.i(412012);
    e.s(["ChevronLeft", () => t.default]);
  },
  463059,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("chevron-right", [["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }]]);
    e.s(["ChevronRight", 0, t], 463059);
  },
  547930,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("star", [
      [
        "path",
        {
          d: "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",
          key: "r04s7s",
        },
      ],
    ]);
    e.s(["Star", 0, t], 547930);
  },
  431921,
  183429,
  (e) => {
    "use strict";
    var t = e.i(843476),
      s = e.i(373375),
      i = e.i(463059),
      a = e.i(948148),
      n = e.i(335889),
      l = e.i(663615);
    (e.s([], 431921),
      e.s(
        [
          "UpdatedPaginationComponent",
          0,
          (e) => {
            let {
                currentQuestionId: r,
                handleBackClick: m,
                handleNextClick: o,
                quizLength: c,
                isRTL: x = !1,
                showProgressBar: d = !1,
                funnel: u,
                hideQuestionCount: p = !1,
                displayLength: h,
                hideArrows: _ = !1,
                stickyBottom: g = !1,
                unstickyOnShortViewport: f = !1,
                unstickyOnNarrowViewport: b = !1,
              } = e,
              y = ((e) => {
                let { currentQuestionId: s, quizLength: i, t: a } = e;
                return (0, t.jsxs)(t.Fragment, {
                  children: [
                    (0, t.jsxs)("span", { className: "font-bold", children: [s, " "] }),
                    a("text_of"),
                    " ",
                    i,
                  ],
                });
              })({ currentQuestionId: r, quizLength: h ?? c, t: (0, a.useTranslations)() }),
              w = (r / c) * 100,
              j =
                "myiq" === u || "personality" === u || "depression" === u || "autism" === u
                  ? "bg-gray-50"
                  : "bg-default-200",
              v = p
                ? null
                : (0, t.jsx)("div", { className: "text-center text-base font-medium", children: y });
            return (0, t.jsxs)("div", {
              className: (0, l.cn)(
                "bottom-0 left-0 right-0 z-40 border-t bg-white",
                b ? (g ? "xs-base:sticky" : "xs-base:fixed") : g ? "xs-sm:sticky" : "xs-sm:fixed",
                f && "[@media(max-height:700px)]:!static",
              ),
              children: [
                d &&
                  (0, t.jsx)("div", {
                    className: "h-1 w-full overflow-hidden bg-[#e9e9ea]",
                    children: (0, t.jsx)("div", {
                      className: (0, l.cn)(
                        "h-1 w-full origin-left bg-teal-700 transition-transform duration-300 ease-out",
                        x && "origin-right",
                      ),
                      style: { transform: `scaleX(${w / 100})`, willChange: "transform" },
                    }),
                  }),
                (0, t.jsx)("div", {
                  className:
                    "relative mx-auto flex w-full max-w-[980px] flex-col items-center justify-center max-[1004px]:px-6 max-md:px-4",
                  children: (0, t.jsxs)("div", {
                    className: (0, l.cn)(
                      "relative flex w-full items-center",
                      _ ? "justify-center py-5" : "justify-between py-3",
                    ),
                    children: [
                      !_ &&
                        (0, t.jsx)(n.Button, {
                          type: "button",
                          disableRipple: !0,
                          variant: "flat",
                          isIconOnly: !0,
                          className: (0, l.cn)("flex items-center justify-center", j),
                          onPress: m,
                          isDisabled: 1 === r,
                          children: (0, t.jsx)(s.ChevronLeft, {
                            size: 20,
                            className: (0, l.cn)(x && "rotate-180"),
                          }),
                        }),
                      v,
                      !_ &&
                        (0, t.jsx)(n.Button, {
                          type: "button",
                          disableRipple: !0,
                          variant: "flat",
                          isIconOnly: !0,
                          className: (0, l.cn)("flex items-center justify-center", j),
                          onPress: o,
                          isDisabled: r === c,
                          children: (0, t.jsx)(i.ChevronRight, {
                            size: 20,
                            className: (0, l.cn)(x && "rotate-180"),
                          }),
                        }),
                    ],
                  }),
                }),
              ],
            });
          },
        ],
        183429,
      ));
  },
  163269,
  (e) => {
    "use strict";
    var t = e.i(843476),
      s = e.i(657688),
      i = e.i(861745),
      a = e.i(948148),
      n = e.i(271645),
      l = e.i(174080),
      r = e.i(663615);
    e.i(381069);
    var m = e.i(82709),
      o = e.i(477545),
      c = e.i(648430),
      x = e.i(468387);
    e.i(7028);
    var d = e.i(468749);
    let u = (e) => {
      let { onSelect: s, onFinish: i, isProfile: l, isLoading: r } = e,
        m = (0, a.useTranslations)(),
        o = (0, x.getUsUkAgeAnswers)(),
        [c, u] = (0, n.useState)(void 0),
        p = { title: m("what_is_your_age"), answers: o, id: 1, isDefaultColor: !0, answersNormalCase: !0 };
      return (0, t.jsx)("div", {
        className: "flex flex-col sm:flex-1 lg:min-h-[400px]",
        children: (0, t.jsx)(d.AdditionalQuestionsComponent, {
          question: p,
          handleAnswerClick: (e) => {
            u(e);
            let t = o.indexOf(e);
            s(x.US_UK_AGE_GROUPS_ORDER[t] ?? x.US_UK_DEFAULT_AGE_GROUP);
          },
          selectedOption: c,
          showResultButton: !!c,
          handleFinishQuiz: i,
          isProfile: l,
          isLoading: r,
        }),
      });
    };
    e.i(356037);
    var p = e.i(64802);
    e.i(301405);
    var h = e.i(189837),
      _ = e.i(76670),
      _ = _,
      g = e.i(567697),
      f = e.i(367148),
      b = e.i(480164),
      y = e.i(621306),
      w = e.i(775367),
      j = e.i(915113),
      v = e.i(75540);
    e.i(568267);
    var N = e.i(154692),
      C = e.i(369595);
    e.i(118360);
    var z = e.i(45180);
    let q = (e) => {
      let { currentQuestionId: s, onClick: i, user: l, questionLength: r, isBrainTrain: m } = e,
        o = (0, a.useTranslations)(),
        [c, x] = (0, n.useState)(20),
        [d, u] = (0, z.getMotivationQuestionIds)(r, m);
      return (
        (0, n.useEffect)(() => {
          x((0, z.getOrGeneratePercentage)(s, d, u, l));
        }, [s, d, u, l]),
        (0, t.jsxs)("div", {
          className:
            "mx-auto flex h-full min-h-[420px] w-full max-w-[438px] flex-col pb-1 pt-5 xs-s:min-h-[400px] xs-m:min-h-[480px] xs-m:pt-7 md:min-h-[500px]",
          children: [
            (0, t.jsx)("div", {
              className: "relative mx-auto mb-6 h-[140px] w-full xs-m:mb-8 xs-m:h-[180px] md:mb-[60px]",
              children: (0, z.getMotivationImage)(s, d, u, r),
            }),
            (0, t.jsxs)("div", {
              className: "xs-m:mb-auto md:my-auto",
              children: [
                (0, t.jsx)("h3", {
                  className: (0, v.clsx)(
                    "mb-2 select-none text-pretty break-keep text-[16px] font-extrabold leading-6 text-black xs-m:text-[22px] xs-m:leading-normal md:mb-2",
                  ),
                  children: (0, C.keepTrailingEmojiInline)(
                    (0, z.getMotivationalScreenTitle)(s, o, c, d, u, l, r, m),
                  ),
                }),
                (0, t.jsx)("p", {
                  className:
                    "select-none text-sm leading-snug text-love-grey xs-m:mb-auto xs-m:text-base xs-m:leading-normal",
                  children: (0, z.getMotivationalScreenDescription)(s, o, d, u, r, m),
                }),
              ],
            }),
            (0, t.jsx)(N.ButtonComponent, {
              onClick: i,
              className: (0, v.clsx)("my-2 whitespace-pre-wrap xs-m:my-0 xs-m:mt-7 md:mt-5"),
              dataNR: "motivational-screen-continue-btn",
              fullWidth: !0,
              size: "md",
              children: o("btn_continue"),
            }),
          ],
        })
      );
    };
    e.i(706152);
    var k = e.i(907139);
    e.i(415858);
    var E = e.i(446454),
      A = e.i(520837);
    let L = {
        wait: {
          circleClassName: "bg-gray-200",
          labelClassName: "text-gray-500",
          labelKey: "ab_myiq_quiz_reaction_tap_game_wait",
        },
        go: {
          circleClassName: "bg-[#2E9E63]",
          labelClassName: "text-green-custom",
          labelKey: "ab_myiq_quiz_reaction_tap_game_go",
        },
        early: {
          circleClassName: "bg-[#E9B4B4]",
          labelClassName: "text-[#B23B3B]",
          labelKey: "ab_myiq_quiz_reaction_tap_game_early",
        },
        done: {
          circleClassName: "bg-green-custom",
          labelClassName: "text-green-custom",
          labelKey: "ab_myiq_quiz_reaction_tap_game_result",
        },
      },
      R = (e) => {
        let { onComplete: s } = e,
          i = (0, a.useTranslations)(),
          [l, m] = (0, n.useState)("ready"),
          [o, c] = (0, n.useState)(0),
          [x, d] = (0, n.useState)(!1),
          u = (0, n.useRef)(0),
          p = (0, n.useRef)([]),
          h = () => {
            (p.current.forEach(clearTimeout), (p.current = []));
          },
          _ = (e, t) => {
            p.current.push(setTimeout(t, e));
          };
        ((0, n.useEffect)(() => h, []),
          (0, n.useEffect)(() => {
            if ("ready" !== l) return;
            let e = setInterval(() => d((e) => !e), 700);
            return () => clearInterval(e);
          }, [l]));
        let g = () => {
          (h(),
            m("wait"),
            _(1500 + 2e3 * Math.random(), () => {
              ((u.current = performance.now()), m("go"));
            }));
        };
        return (0, t.jsxs)("div", {
          className: "grid lg:px-5",
          children: [
            (0, t.jsx)(A.Card, {
              "data-cy": "question_image",
              className:
                "relative mx-auto aspect-[49/37] w-full max-w-[343px] max-xs-sm:aspect-[3/2] max-xs-sm:max-h-[160px] lg:max-w-[464px]",
              children:
                "ready" === l
                  ? (0, t.jsxs)("div", {
                      className:
                        "flex h-full w-full select-none flex-col items-center justify-center gap-4 max-xs-sm:gap-2",
                      children: [
                        (0, t.jsxs)("div", {
                          className: "flex items-start gap-5 max-xs-sm:gap-3",
                          children: [
                            (0, t.jsxs)("div", {
                              className: "flex flex-col items-center gap-2 max-xs-sm:gap-1",
                              children: [
                                (0, t.jsx)("span", {
                                  className: (0, r.cn)(
                                    "size-16 rounded-full bg-gray-200 transition-shadow duration-300 max-xs-sm:size-11",
                                    x ? "shadow-[0_0_0_0_#CBD2DA]" : "shadow-[0_0_0_4px_#CBD2DA]",
                                  ),
                                }),
                                (0, t.jsx)("span", {
                                  className: "text-sm font-medium text-gray-500",
                                  children: i("ab_myiq_quiz_reaction_tap_game_demo_wait"),
                                }),
                              ],
                            }),
                            (0, t.jsx)("svg", {
                              viewBox: "0 0 24 64",
                              fill: "none",
                              stroke: "#9CA3AF",
                              strokeWidth: "2",
                              strokeLinecap: "round",
                              strokeLinejoin: "round",
                              className: "h-16 w-6 max-xs-sm:h-11",
                              children: (0, t.jsx)("path", { d: "M4 32h16M14 26l6 6-6 6" }),
                            }),
                            (0, t.jsxs)("div", {
                              className: "flex flex-col items-center gap-2 max-xs-sm:gap-1",
                              children: [
                                (0, t.jsx)("span", {
                                  className: (0, r.cn)(
                                    "size-16 rounded-full bg-[#2E9E63] transition-shadow duration-300 max-xs-sm:size-11",
                                    x ? "shadow-[0_0_0_6px_#CFE7E2]" : "shadow-[0_0_0_0_#CFE7E2]",
                                  ),
                                }),
                                (0, t.jsxs)("span", {
                                  className: "text-sm font-semibold text-green-custom",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className: "lg:hidden",
                                      children: i("ab_myiq_quiz_reaction_tap_game_go"),
                                    }),
                                    (0, t.jsx)("span", {
                                      className: "hidden lg:inline",
                                      children: i("ab_myiq_quiz_reaction_tap_game_go_desktop"),
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          ],
                        }),
                        (0, t.jsx)("button", {
                          type: "button",
                          "data-nr": "additional-questions-answer-btn",
                          onClick: g,
                          className:
                            "mt-2 h-[52px] w-[240px] rounded-2xl bg-green-custom text-[17px] font-semibold text-white max-xs-sm:mt-0 max-xs-sm:h-10",
                          children: i("ab_myiq_quiz_reaction_tap_game_start"),
                        }),
                      ],
                    })
                  : (0, t.jsxs)("button", {
                      type: "button",
                      "data-nr": "go" === l ? "additional-questions-answer-btn" : "reaction-tap-game-stage",
                      onPointerDown: () => {
                        if ("wait" === l) {
                          (h(), m("early"), _(900, g));
                          return;
                        }
                        "go" === l &&
                          (h(), c(Math.round(performance.now() - u.current)), m("done"), _(700, s));
                      },
                      className:
                        "flex h-full w-full touch-manipulation select-none flex-col items-center justify-center gap-4 outline-none [-webkit-tap-highlight-color:transparent] max-xs-sm:gap-2.5",
                      children: [
                        (0, t.jsx)("span", {
                          className: (0, r.cn)(
                            "size-[120px] rounded-full transition-colors duration-100 max-xs-sm:size-[88px]",
                            L[l].circleClassName,
                          ),
                        }),
                        (0, t.jsx)("span", {
                          className: (0, r.cn)("px-4 text-center text-base font-medium", L[l].labelClassName),
                          children:
                            "go" === l
                              ? (0, t.jsxs)(t.Fragment, {
                                  children: [
                                    (0, t.jsx)("span", {
                                      className: "lg:hidden",
                                      children: i("ab_myiq_quiz_reaction_tap_game_go"),
                                    }),
                                    (0, t.jsx)("span", {
                                      className: "hidden lg:inline",
                                      children: i("ab_myiq_quiz_reaction_tap_game_go_desktop"),
                                    }),
                                  ],
                                })
                              : i(L[l].labelKey, { ms: String(o) }),
                        }),
                      ],
                    }),
            }),
            (0, t.jsx)("div", {
              className: "flex basis-full flex-col gap-1 px-0 pt-0 text-center",
              children: (0, t.jsxs)("p", {
                className:
                  "dark:text-foreground-700 lg:text-md mb-2 mt-4 select-none px-5 text-center max-xs-sm:mb-1 max-xs-sm:mt-2",
                children: [
                  (0, t.jsx)("span", {
                    className: "lg:hidden",
                    children: i("ab_myiq_quiz_reaction_tap_game_instruction"),
                  }),
                  (0, t.jsx)("span", {
                    className: "hidden lg:inline",
                    children: i("ab_myiq_quiz_reaction_tap_game_instruction_desktop"),
                  }),
                ],
              }),
            }),
          ],
        });
      };
    e.i(299649);
    var M = e.i(605766);
    e.i(629948);
    var T = e.i(695194),
      I = e.i(818605),
      I = I,
      S = e.i(523173);
    e.i(470366);
    var B = e.i(504001),
      Q = e.i(19576);
    e.i(431921);
    var F = e.i(183429);
    (e.i(50866), e.i(165037));
    var O = e.i(98636),
      D = e.i(527154);
    e.s(
      [
        "default",
        0,
        (e) => {
          let {
              isProfile: d = !1,
              userProfile: v,
              currentHour: C = new Date().getHours(),
              experiments: z = {},
              hasFunnelFooter: A,
              isBrainTrain: L,
              useRetakeQuestions: U,
              isUsUkTraffic: P,
            } = e,
            W = (0, i.useLocale)(),
            H = (0, a.useTranslations)(),
            K = "rtl" === (0, Q.getLocaleDirection)(W),
            {
              currentQuestionId: G,
              activeQuestion: V,
              allQuestions: X,
              showResultButton: Y,
              isShowMotivation: Z,
              isShowTestimonials: $,
              showHeroAfterTestimonials: J,
              showAgeQuestion: ee,
              handleAgeSelect: et,
              showSecondWordIntro: es,
              handleSecondWordIntroComplete: ei,
              showNumberRecallIntro: ea,
              handleNumberRecallIntroComplete: en,
              showReactionTapGame: el,
              handleReactionTapGameComplete: er,
              handleHeroAfterTestimonialsContinue: em,
              isLoading: eo,
              isMutatingQuizStarted: ec,
              selectedOption: ex,
              handleSelectOption: ed,
              handleShowResultsClick: eu,
              handleTestimonialsContinue: ep,
              handlePagination: eh,
              handleMotivationContinue: e_,
              userData: eg,
            } = (0, O.useQuizModuleService)({
              userProfile: v,
              isProfile: d,
              experiments: z,
              isBrainTrain: L,
              useRetakeQuestions: U,
              isUsUkTraffic: P,
            }),
            ef = (0, p.useIsHintAssistMobileViewport)(),
            { isShowUpdatedPagination: eb } = ((e) => {
              let {
                  currentQuestionId: t,
                  allQuestionsLength: s,
                  isShowMotivation: i,
                  isShowTestimonials: a,
                  showHeroAfterTestimonials: n,
                  showAgeQuestion: l,
                  showIntentQuestion: r,
                } = e,
                m = !i && !a && !n && !l && !r;
              return {
                progressTotal: s,
                progressCurrent: t,
                isShowUpdatedPagination: m,
                showHeaderQuestionCountWithMotivation: m || i,
              };
            })({
              isProfile: d,
              currentQuestionId: G,
              allQuestionsLength: X.length,
              isShowMotivation: Z,
              isShowTestimonials: $,
              showHeroAfterTestimonials: J,
              showAgeQuestion: ee,
            }),
            ey = !!(0, j.getIsMarketingSource)();
          (ey &&
            (0, b.getQuizHeroImages)().forEach((e) =>
              (0, l.preload)(e.src, { as: "image", fetchPriority: "high" }),
            ),
            (0, D.getQuizImageSrcs)(X).forEach((e) =>
              (0, l.preload)(e, { as: "image", fetchPriority: "low" }),
            ),
            h.MOTIVATIONAL_SCREEN_IMAGE_SRCS.forEach((e) =>
              (0, l.preload)(e, { as: "image", fetchPriority: "low" }),
            ));
          let ew =
              void 0 !== z.abMyiqQuizNumberRecall &&
              "fallback" !== z.abMyiqQuizNumberRecall &&
              "default_quiz_flow" !== z.abMyiqQuizNumberRecall,
            [ej, ev] = (0, n.useState)(() => (d || U ? "done" : "memorize")),
            eN = (0, n.useCallback)(() => {
              ev((e) => ("memorize" === e && ew ? "memorize_number_583" : "done"));
            }, [ew]),
            eC = $ || J,
            ez = (0, n.useCallback)(() => {
              ("with_analytics" === z.ftMemorizeContinueAnalytics &&
                (0, B.trackClientEvents)({
                  event: S.EAnalyticEvents.QUIZ_CONTINUE,
                  params: { question_number: G, screen_type: "memorize" },
                  user: eg,
                }),
                eN());
            }, [z.ftMemorizeContinueAnalytics, G, eg, eN]),
            eq = (0, n.useCallback)(() => {
              ("with_analytics" === z.ftMemorizeContinueAnalytics &&
                (0, B.trackClientEvents)({
                  event: S.EAnalyticEvents.QUIZ_CONTINUE,
                  params: { question_number: G, screen_type: "memorize" },
                  user: eg,
                }),
                eN());
            }, [z.ftMemorizeContinueAnalytics, G, eg, eN]),
            ek = "memorize" === ej && !Z && !eC,
            eE = "memorize_number_583" === ej && !Z && !eC,
            eA = el && !Z && !eC && !ek && !eE && !es && !ea,
            eL = X.length;
          return (
            (0, n.useEffect)(() => {
              let e = (e) => {
                Y || e.preventDefault();
              };
              return (
                window.addEventListener("beforeunload", e),
                () => window.removeEventListener("beforeunload", e)
              );
            }, [Y]),
            (0, t.jsxs)(M.ContainerComponent, {
              className: "!max-w-none select-none !px-0",
              children: [
                (0, t.jsx)(k.ProgressComponent, { currentQuestionId: G, questionLength: eL }),
                (0, t.jsxs)("div", {
                  className: (0, r.cn)(
                    "relative mx-auto max-w-xl px-4 pt-5 max-xs-sm:px-3 max-xs-sm:pt-3 sm:px-0 lg:max-w-5xl lg:pt-[60px]",
                    J ? "pb-0" : "pb-5",
                    eC ? "grid gap-16" : "flex flex-col",
                    Z || eC ? "" : "min-h-[calc(100dvh-64px)] lg:min-h-fit",
                    A && "!min-h-[calc(100dvh-64px)]",
                    Y && !eC ? "lg:gap-3" : "",
                    eb && !A && "xs-sm:pb-20",
                    eC && "w-full max-w-none bg-white",
                  ),
                  children: [
                    Z &&
                      (0, t.jsx)(q, {
                        user: eg,
                        onClick: e_,
                        currentQuestionId: G,
                        questionLength: X.length,
                        isBrainTrain: L,
                      }),
                    ek && (0, t.jsx)(_.default, { word: H(x.WORD_RECALL_INTRO_WORD) }),
                    eE &&
                      (0, t.jsx)(_.default, {
                        word: c.NUMBER_RECALL_583_NUMBER,
                        title: H("ab_myiq_quiz_number_recall_intro_title"),
                        subtitle: H("ab_myiq_quiz_number_recall_intro_subtitle"),
                        isDigits: !0,
                      }),
                    es &&
                      !Z &&
                      (0, t.jsx)(_.default, {
                        word: H(x.WORD_RECALL_2ND_WORD),
                        title: H("quiz_page_ab_myiq_word_recall_2nd_intro_title"),
                        subtitle: H("quiz_page_ab_myiq_word_recall_2nd_intro_subtitle"),
                      }),
                    ea &&
                      !Z &&
                      (0, t.jsx)(_.default, {
                        word: w.NUMBER_RECALL_NUMBER,
                        title: H("ab_myiq_number_recall_intro_title"),
                        subtitle: H("ab_myiq_number_recall_intro_subtitle"),
                        isDigits: !0,
                      }),
                    eA && (0, t.jsx)(R, { onComplete: er }),
                    ee &&
                      !Z &&
                      !eC &&
                      (0, t.jsx)(u, { onSelect: et, onFinish: eu, isProfile: d, isLoading: eo }),
                    !eC &&
                      !Z &&
                      !ek &&
                      !eE &&
                      !es &&
                      !ea &&
                      !eA &&
                      !ee &&
                      (0, t.jsx)("div", {
                        className: (0, r.cn)(
                          "flex flex-col",
                          Y ? "lg:min-h-[505px]" : "lg:min-h-[400px]",
                          Y && "pb-4 lg:pb-0",
                          "sm:flex-1",
                        ),
                        children: (0, t.jsx)(E.RenderCurrentStep, {
                          activeQuestion: V,
                          currentQuestionId: G,
                          isShowMotivation: Z,
                          isMutatingQuizStarted: ec,
                          showResultButton: Y,
                          handleSelectOption: ed,
                          handleFinishQuiz: eu,
                          selectedOption: ex,
                          isLoading: eo,
                          isProfile: d,
                          useRetakeQuestions: U,
                          abMyiqQuizChaosBlockQ1122: z.abMyiqQuizChaosBlockQ1122,
                          abMyiqQuizHintAssistCount: d || !ef ? void 0 : z.abMyiqQuizHintAssistCount,
                          abMyiqQuizFewerOptions: d ? void 0 : z.abMyiqQuizFewerOptions,
                        }),
                      }),
                    J && !Z && (0, t.jsx)(f.ChooseYourHeroComponent, { onContinue: em, user: eg }),
                    $ &&
                      !J &&
                      !Z &&
                      (P
                        ? (0, t.jsx)(T.TestimonialsComponent, {
                            handleContinue: ep,
                            currentHour: C,
                            countryName: (0, g.getCountryData)("name", eg),
                            countryCode: eg?.currency?.countryCode || "US",
                          })
                        : (0, t.jsxs)(t.Fragment, {
                            children: [
                              (0, t.jsx)("div", {
                                className: "md:hidden",
                                children: (0, t.jsx)(I.default, { handleContinue: ep, currentHour: C }),
                              }),
                              (0, t.jsx)("div", {
                                className: "hidden md:block",
                                children: (0, t.jsx)(T.TestimonialsComponent, {
                                  handleContinue: ep,
                                  currentHour: C,
                                  countryName: (0, g.getCountryData)("name", eg),
                                  countryCode: eg?.currency?.countryCode || "US",
                                }),
                              }),
                            ],
                          })),
                    $ &&
                      ey &&
                      (0, t.jsx)("div", {
                        className: "hidden",
                        "aria-hidden": "true",
                        children: (0, b.getQuizHeroImages)().map((e) =>
                          (0, t.jsx)(
                            s.default,
                            { src: e, width: 64, height: 64, alt: "", unoptimized: !0, priority: !0 },
                            e.src,
                          ),
                        ),
                      }),
                  ],
                }),
                ek &&
                  (0, t.jsx)("div", {
                    className: (0, r.cn)(
                      "fixed bottom-[var(--cookie-consent-h,0px)] left-0 right-0 z-40 border-t bg-white",
                      A ? "sticky" : "fixed",
                    ),
                    children: (0, t.jsx)("div", {
                      className:
                        "relative mx-auto flex w-full max-w-[980px] flex-col items-center justify-center py-3 max-[1004px]:px-6 max-md:px-4",
                      children: (0, t.jsx)(N.ButtonComponent, {
                        name: "word-recall-intro-continue-btn",
                        dataNR: "word-recall-intro-continue-btn",
                        text: H("btn_continue"),
                        size: "md",
                        className: (0, r.cn)("w-full max-w-[600px] select-none"),
                        onClick: ez,
                        fullWidth: !0,
                      }),
                    }),
                  }),
                eE &&
                  (0, t.jsx)("div", {
                    className: (0, r.cn)(
                      "fixed bottom-[var(--cookie-consent-h,0px)] left-0 right-0 z-40 border-t bg-white",
                      A ? "sticky" : "fixed",
                    ),
                    children: (0, t.jsx)("div", {
                      className:
                        "relative mx-auto flex w-full max-w-[980px] flex-col items-center justify-center py-3 max-[1004px]:px-6 max-md:px-4",
                      children: (0, t.jsx)(N.ButtonComponent, {
                        name: "number-recall-583-intro-continue-btn",
                        dataNR: "number-recall-583-intro-continue-btn",
                        text: H("btn_continue"),
                        size: "md",
                        className: (0, r.cn)("w-full max-w-[600px] select-none"),
                        onClick: eq,
                        fullWidth: !0,
                      }),
                    }),
                  }),
                es &&
                  !Z &&
                  (0, t.jsx)("div", {
                    className: (0, r.cn)(
                      "fixed bottom-[var(--cookie-consent-h,0px)] left-0 right-0 z-40 border-t bg-white",
                      A ? "sticky" : "fixed",
                    ),
                    children: (0, t.jsx)("div", {
                      className:
                        "relative mx-auto flex w-full max-w-[980px] flex-col items-center justify-center py-3 max-[1004px]:px-6 max-md:px-4",
                      children: (0, t.jsx)(N.ButtonComponent, {
                        name: "word-recall-2nd-continue-btn",
                        dataNR: "word-recall-2nd-continue-btn",
                        text: H("btn_continue"),
                        size: "md",
                        className: (0, r.cn)("w-full max-w-[600px] select-none"),
                        onClick: ei,
                        fullWidth: !0,
                      }),
                    }),
                  }),
                ea &&
                  !Z &&
                  (0, t.jsx)("div", {
                    className: (0, r.cn)(
                      "fixed bottom-[var(--cookie-consent-h,0px)] left-0 right-0 z-40 border-t bg-white",
                      A ? "sticky" : "fixed",
                    ),
                    children: (0, t.jsx)("div", {
                      className:
                        "relative mx-auto flex w-full max-w-[980px] flex-col items-center justify-center py-3 max-[1004px]:px-6 max-md:px-4",
                      children: (0, t.jsx)(N.ButtonComponent, {
                        name: "number-recall-continue-btn",
                        dataNR: "number-recall-continue-btn",
                        text: H("btn_continue"),
                        size: "md",
                        className: (0, r.cn)("w-full max-w-[600px] select-none"),
                        onClick: en,
                        fullWidth: !0,
                      }),
                    }),
                  }),
                eb &&
                  !ek &&
                  !eE &&
                  !es &&
                  !ea &&
                  !eA &&
                  (0, t.jsx)(F.UpdatedPaginationComponent, {
                    funnel: "myiq",
                    isProfile: d,
                    currentQuestionId: G,
                    handleBackClick: () => {
                      G > 1 && eh(G - 1);
                    },
                    handleNextClick: () => {
                      G < X.length && eh(G + 1);
                    },
                    quizLength: eL,
                    isRTL: K,
                    showProgressBar: !1,
                    hideQuestionCount: !1,
                    stickyBottom: A,
                    unstickyOnShortViewport: "v3_increased_image_size" === z.abMyiqQuizFewerOptions,
                    unstickyOnNarrowViewport:
                      (0, o.isFlagTriviaQuestion)(V?.baseId) || (0, m.isCountGridQuestion)(V?.baseId),
                    hideArrows: !0,
                  }),
                (0, t.jsxs)("div", {
                  className: "hidden",
                  children: [
                    y.SCIENCE_BASED_AFTER_MAIL.map((e, i) =>
                      (0, t.jsx)(
                        "div",
                        {
                          children: e.map((e) =>
                            (0, t.jsx)(
                              s.default,
                              { src: e.img, loading: "eager", alt: e.name, height: 35, width: e.width },
                              e.id,
                            ),
                          ),
                        },
                        i,
                      ),
                    ),
                    (0, t.jsx)(s.default, {
                      src: "/images/testimonials-woman.webp",
                      alt: "preload",
                      width: 56,
                      height: 56,
                      loading: "eager",
                    }),
                  ],
                }),
              ],
            })
          );
        },
      ],
      163269,
    );
  },
  655638,
  175761,
  (e) => {
    "use strict";
    var t = e.i(687296);
    (e.s([], 655638), e.s(["LogoScrollerComponent", () => t.default], 175761));
  },
  629948,
  818605,
  695194,
  (e) => {
    "use strict";
    var t,
      s = e.i(843476);
    let i = (0, e.i(475254).default)("users", [
      ["path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", key: "1yyitq" }],
      ["path", { d: "M16 3.128a4 4 0 0 1 0 7.744", key: "16gr8j" }],
      ["path", { d: "M22 21v-2a4 4 0 0 0-3-3.87", key: "kshegd" }],
      ["circle", { cx: "9", cy: "7", r: "4", key: "nufk8" }],
    ]);
    var a = e.i(948148),
      n = e.i(271645),
      l = e.i(663615),
      r = e.i(926654),
      m = e.i(266027),
      o = e.i(134404);
    e.i(531122);
    var c = e.i(81844);
    let x = async (e) => {
        let t = void 0 !== e ? e : new Date().getHours(),
          s = await c.httpInstance.get(`${o.EApiRoutes.PAYNEXT_SUBSCRIPTIONS}?hours=${t}`, {
            throwHttpErrors: !1,
            next: { revalidate: 3600 },
          }),
          i = await s.json();
        return i?.count ?? 7869;
      },
      d = (e) =>
        (0, m.useQuery)({
          queryKey: [o.EApiRoutes.PAYNEXT_SUBSCRIPTIONS, e],
          queryFn: () => x(e),
          staleTime: 6e5,
          gcTime: 9e5,
        });
    e.i(568267);
    var u = e.i(154692);
    function p() {
      return (p = Object.assign.bind()).apply(null, arguments);
    }
    let h = (e) =>
      n.createElement(
        "svg",
        p({ xmlns: "http://www.w3.org/2000/svg", "aria-hidden": "true", viewBox: "0 0 24 24" }, e),
        t ||
          (t = n.createElement("path", {
            fill: "none",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: 1.5,
            d: "M8 10h8m-8 4h4m0 8c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12c0 1.821.487 3.53 1.338 5L2.5 21.5l4.5-.838A9.96 9.96 0 0 0 12 22",
          })),
      );
    e.i(655638);
    var _ = e.i(175761);
    let g = function (e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "myiq",
          i = arguments.length > 2 ? arguments[2] : void 0;
        return "personality" === t
          ? {
              title: e.rich("testimonials_title_personality", {
                primary: (e) => (0, s.jsx)("span", { className: "font-bold text-primary", children: e }),
              }),
              reviewTitle: e("testimonials_review_title_personality"),
              reviewDescription: e("testimonials_review_description_personality"),
              testTaken: e.rich("testimonials_tests_taken_personality", {
                primary: (e) => (0, s.jsx)("span", { className: "font-bold text-foreground", children: e }),
                count: i?.toString() || "3495",
              }),
            }
          : {
              title: e.rich("quiz_page_testimonials_title", {
                primary: (e) => (0, s.jsx)("span", { className: "font-bold text-primary", children: e }),
              }),
              reviewTitle: e("quiz_page_testimonials_review_title"),
              reviewDescription: e("quiz_page_testimonials_review_description"),
              testTaken: e.rich("quiz_page_testimonials_tests_taken", {
                primary: (e) => (0, s.jsx)("span", { className: "font-bold text-foreground", children: e }),
                count: i?.toString() || "7869",
              }),
            };
      },
      f = (e) => {
        let { className: t } = e;
        return (0, s.jsx)("span", {
          className: "flex items-center",
          style: { gap: 3 },
          children: [void 0, void 0, void 0, void 0, void 0].map((e, i) =>
            (0, s.jsx)(
              "svg",
              {
                width: 20,
                height: 20,
                viewBox: "0 0 24 24",
                fill: "#F5B800",
                className: t,
                children: (0, s.jsx)("path", {
                  d: "M12 2 L14.9 8.6 L22 9.3 L16.5 14 L18.2 21 L12 17.3 L5.8 21 L7.5 14 L2 9.3 L9.1 8.6 Z",
                }),
              },
              i,
            ),
          ),
        });
      };
    (e.i(547930),
      e.s(
        [
          "default",
          0,
          (e) => {
            let { handleContinue: t, variant: m, logoScrollerClassName: o, currentHour: c } = e,
              x = (0, a.useTranslations)(),
              [p, b] = (0, n.useState)(!1),
              { data: y, isLoading: w, isFetching: j } = d(c),
              { title: v, testTaken: N } = g(x, m, y || 7869),
              [C, z] = (0, n.useState)(!0),
              q = (0, n.useRef)(null);
            (0, n.useEffect)(() => {
              let e = q.current;
              if (!e) return;
              let t = new IntersectionObserver(
                (e) => {
                  let [t] = e;
                  z(!t.isIntersecting && t.boundingClientRect.top > 0);
                },
                { rootMargin: "0px 0px -64px 0px", threshold: 0 },
              );
              return (t.observe(e), () => t.disconnect());
            }, []);
            let k = (0, s.jsx)(u.ButtonComponent, {
              name: "continue-btn",
              isLoading: p,
              onClick: () => {
                (b(!0), t());
              },
              className: (0, l.cn)("sm:max-w-full"),
              dataNR: "testimonial-continue-btn-v1",
              size: "sm",
              fullWidth: !0,
              children: x("btn_continue"),
            });
            return (0, s.jsxs)(s.Fragment, {
              children: [
                (0, s.jsx)("div", {
                  className:
                    "mx-auto box-border w-full min-w-0 max-w-sm justify-self-center max-sm:mt-4 max-xs-base:mt-0 sm:max-w-2xl sm:px-4",
                  children: (0, s.jsxs)("div", {
                    className:
                      "w-full min-w-0 overflow-x-hidden rounded-[20px] border-[#eaedf2] bg-white p-2 sm:border sm:p-7 sm:shadow-[0_24px_60px_-24px_rgba(14,27,43,0.18),0_2px_8px_rgba(14,27,43,0.04)]",
                    children: [
                      (0, s.jsx)("h2", {
                        className:
                          "text-center text-rd-h3 text-gray-900 max-xs-m:text-rd-body xs-base:text-rd-h2",
                        style: { textWrap: "balance" },
                        children: v,
                      }),
                      (0, s.jsxs)("div", {
                        className: "mt-6 rounded-xl border border-[#edf1f4] bg-white p-5",
                        children: [
                          (0, s.jsx)(f, { className: "max-xs-m:h-4 max-xs-m:w-4" }),
                          (0, s.jsx)("p", {
                            className:
                              "mt-3 text-rd-body-sm font-semibold text-gray-900 max-xs-m:text-rd-caption xs-base:text-rd-body",
                            children: x("quiz_page_testimonials_finding_my_iq_was"),
                          }),
                          (0, s.jsx)("p", {
                            className:
                              "mt-2 text-rd-caption text-gray-600 max-xs-m:text-rd-caption-sm xs-base:text-rd-body",
                            children: x("quiz_page_testimonials_been_many_many_years_since"),
                          }),
                          (0, s.jsxs)("div", {
                            className: "mt-4 flex items-baseline gap-1",
                            children: [
                              (0, s.jsxs)("p", {
                                className:
                                  "text-rd-caption text-gray-900 max-xs-m:text-rd-caption-sm xs-base:text-rd-body-sm",
                                children: [x("quiz_page_testimonials_author_name"), " "],
                              }),
                              (0, s.jsx)("span", {
                                className:
                                  "text-rd-caption text-gray-500 max-xs-m:text-rd-caption-sm xs-base:text-rd-body-sm",
                                children: "·",
                              }),
                              (0, s.jsx)("p", {
                                className:
                                  "text-rd-caption text-gray-500 max-xs-m:text-rd-caption-sm xs-base:text-rd-body-sm",
                                children: x("quiz_page_testimonials_verified_customer"),
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsxs)("div", {
                        className: "mt-6 flex flex-col gap-3",
                        children: [
                          (0, s.jsxs)("div", {
                            className: "flex items-center gap-3",
                            children: [
                              (0, s.jsx)("div", {
                                className:
                                  "flex min-h-8 min-w-8 items-center justify-center max-xs-m:min-h-7 max-xs-m:min-w-7",
                                children: (0, s.jsx)(i, {
                                  className: "stroke-[1.5px] max-xs-m:h-5 max-xs-m:w-5",
                                }),
                              }),
                              (0, s.jsx)(r.Skeleton, {
                                isLoaded: !w && !j,
                                children: (0, s.jsx)("span", {
                                  className:
                                    "text-rd-body-sm text-gray-900 max-xs-m:text-rd-caption xs-base:text-rd-body",
                                  children: N,
                                }),
                              }),
                            ],
                          }),
                          (0, s.jsxs)("div", {
                            className: "flex items-center gap-3",
                            children: [
                              (0, s.jsx)("div", {
                                className:
                                  "flex min-h-8 min-w-8 items-center justify-center max-xs-m:min-h-7 max-xs-m:min-w-7",
                                children: (0, s.jsx)(h, { className: "h-6 w-6 max-xs-m:h-5 max-xs-m:w-5" }),
                              }),
                              (0, s.jsx)("span", {
                                children: (0, s.jsx)("span", {
                                  className:
                                    "block text-rd-body-sm text-gray-900 max-xs-m:text-rd-caption xs-base:text-rd-body",
                                  children: x.rich("quiz_page_testimonials_trusted", {
                                    primary: (e) =>
                                      (0, s.jsxs)("span", { className: "font-semibold", children: [e, " "] }),
                                  }),
                                }),
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, s.jsx)("div", {
                        ref: q,
                        className: (0, l.cn)("mt-6", C && "h-12"),
                        children: !C && k,
                      }),
                      (0, s.jsxs)("div", {
                        className: (0, l.cn)("mt-8 w-full min-w-0 overflow-hidden", o),
                        children: [
                          (0, s.jsxs)("p", {
                            className:
                              "mb-3 text-center text-rd-body-sm text-gray-500 max-xs-m:text-rd-caption",
                            children: [x("logo_scroller_featured_in"), ":"],
                          }),
                          (0, s.jsx)("div", {
                            className: "opacity-55",
                            children: (0, s.jsx)(_.LogoScrollerComponent, { isBlue: !0 }),
                          }),
                        ],
                      }),
                    ],
                  }),
                }),
                C &&
                  (0, s.jsx)("div", {
                    className:
                      "fixed inset-x-0 bottom-[var(--cookie-consent-h,0px)] z-40 border-t border-[#eaedf2] bg-white pb-[env(safe-area-inset-bottom,0px)]",
                    children: (0, s.jsx)("div", {
                      className: "px-4 sm:px-0",
                      children: (0, s.jsx)("div", {
                        className: "mx-auto box-border w-full min-w-0 max-w-sm sm:max-w-2xl sm:px-4",
                        children: (0, s.jsx)("div", { className: "p-2 sm:p-7", children: k }),
                      }),
                    }),
                  }),
              ],
            });
          },
        ],
        818605,
      ),
      e.s([], 629948),
      e.s(
        [
          "TestimonialsComponent",
          0,
          (e) => {
            let { handleContinue: t, variant: m, logoScrollerClassName: o, currentHour: c } = e,
              x = (0, a.useTranslations)(),
              [p, b] = (0, n.useState)(!1),
              { data: y, isLoading: w, isFetching: j } = d(c),
              { title: v, testTaken: N } = g(x, m, y || 7869);
            return (0, s.jsx)(s.Fragment, {
              children: (0, s.jsx)("div", {
                className:
                  "mx-auto box-border w-full min-w-0 max-w-sm justify-self-center max-sm:mt-4 max-xs-base:mt-0 sm:max-w-2xl sm:px-4",
                children: (0, s.jsxs)("div", {
                  className:
                    "w-full min-w-0 overflow-x-hidden rounded-[20px] border-[#eaedf2] bg-white p-2 sm:border sm:p-7 sm:shadow-[0_24px_60px_-24px_rgba(14,27,43,0.18),0_2px_8px_rgba(14,27,43,0.04)]",
                  children: [
                    (0, s.jsx)("h2", {
                      className: "text-center text-lg font-semibold xs-base:text-2xl",
                      style: { textWrap: "balance" },
                      children: v,
                    }),
                    (0, s.jsxs)("div", {
                      className: "mt-5 rounded-xl border border-[#edf1f4] bg-white p-5",
                      children: [
                        (0, s.jsx)(f, {}),
                        (0, s.jsx)("p", {
                          className: "mt-3 text-sm font-medium text-inherit",
                          children: x("quiz_page_testimonials_finding_my_iq_was"),
                        }),
                        (0, s.jsx)("p", {
                          className: "mt-3 text-xs font-medium leading-snug",
                          children: x("quiz_page_testimonials_been_many_many_years_since"),
                        }),
                        (0, s.jsxs)("div", {
                          className: "flex items-baseline gap-1 pt-5",
                          children: [
                            (0, s.jsxs)("p", {
                              className: "text-inherittext-[#0e1b2b] text-xs font-medium",
                              children: [x("quiz_page_testimonials_author_name"), " "],
                            }),
                            (0, s.jsx)("span", {
                              className: "text-xs leading-[1.2] text-[#5f6f80]",
                              children: "·",
                            }),
                            (0, s.jsx)("p", {
                              className: "text-xs font-medium leading-[1.2] text-[#5f6f80]",
                              children: x("quiz_page_testimonials_verified_customer"),
                            }),
                          ],
                        }),
                      ],
                    }),
                    (0, s.jsxs)("div", {
                      className: "mt-3 flex flex-col gap-2 xs-base:mt-4",
                      children: [
                        (0, s.jsxs)("div", {
                          className: "flex items-center gap-1.5 xs-base:gap-2.5",
                          children: [
                            (0, s.jsx)("div", {
                              className: "flex min-h-8 min-w-8 items-center justify-center",
                              children: (0, s.jsx)(i, { className: "stroke-[1.5px]" }),
                            }),
                            (0, s.jsx)(r.Skeleton, {
                              isLoaded: !w && !j,
                              children: (0, s.jsx)("span", {
                                className:
                                  "text-sm leading-[1.3] text-[#0e1b2b] xs-base:text-[15px] sm:text-[15.5px]",
                                children: N,
                              }),
                            }),
                          ],
                        }),
                        (0, s.jsxs)("div", {
                          className: "flex items-center gap-1.5 xs-base:gap-2.5",
                          children: [
                            (0, s.jsx)("div", {
                              className: "flex min-h-8 min-w-8 items-center justify-center",
                              children: (0, s.jsx)(h, { className: "h-6 w-6" }),
                            }),
                            (0, s.jsx)("span", {
                              children: (0, s.jsx)("span", {
                                className:
                                  "block text-sm leading-[1.3] text-[#0e1b2b] xs-base:text-[15px] sm:mr-1.5 sm:inline sm:text-[15.5px]",
                                children: x.rich("quiz_page_testimonials_trusted", {
                                  primary: (e) =>
                                    (0, s.jsxs)("span", {
                                      className: "font-bold text-foreground",
                                      children: [e, " "],
                                    }),
                                }),
                              }),
                            }),
                          ],
                        }),
                      ],
                    }),
                    (0, s.jsx)(u.ButtonComponent, {
                      name: "continue-btn",
                      isLoading: p,
                      onClick: () => {
                        (b(!0), t());
                      },
                      className: (0, l.cn)(
                        "mt-4 h-[50px] rounded-[8px] !text-[15px] font-semibold xs-base:mt-5 xs-base:h-[52px] xs-base:!text-[15.5px] sm:max-w-full",
                      ),
                      dataNR: "testimonial-continue-btn",
                      size: "md",
                      fullWidth: !0,
                      children: x("btn_continue"),
                    }),
                    (0, s.jsxs)("div", {
                      className: (0, l.cn)("mt-6 w-full min-w-0 overflow-hidden", o),
                      children: [
                        (0, s.jsxs)("p", {
                          className: "mb-3 text-center text-sm font-semibold leading-normal text-grey-custom",
                          children: [x("logo_scroller_featured_in"), ":"],
                        }),
                        (0, s.jsx)("div", {
                          className: "opacity-55",
                          children: (0, s.jsx)(_.LogoScrollerComponent, { isBlue: !0 }),
                        }),
                      ],
                    }),
                  ],
                }),
              }),
            });
          },
        ],
        695194,
      ));
  },
  621306,
  (e) => {
    "use strict";
    e.s(
      [
        "SCIENCE_BASED_AFTER_MAIL",
        0,
        [
          [
            {
              id: "after_mail_1",
              name: "AFTER_MAIL_1",
              type: "AFTER_MAIL",
              img: "/images/after-mail/after_mail_1.png",
              width: 140,
            },
            {
              id: "after_mail_2",
              name: "AFTER_MAIL_2",
              type: "AFTER_MAIL",
              img: "/images/after-mail/after_mail_2.png",
              width: 101,
            },
          ],
          [
            {
              id: "after_mail_3",
              name: "AFTER_MAIL_3",
              type: "AFTER_MAIL",
              img: "/images/after-mail/after_mail_3.png",
              width: 164,
            },
            {
              id: "after_mail_4",
              name: "AFTER_MAIL_4",
              type: "AFTER_MAIL",
              img: "/images/after-mail/after_mail_4.png",
              width: 81,
            },
          ],
          [
            {
              id: "after_mail_5",
              name: "AFTER_MAIL_5",
              type: "AFTER_MAIL",
              img: "/images/after-mail/after_mail_5.png",
              width: 96.5,
            },
            {
              id: "after_mail_6",
              name: "AFTER_MAIL_6",
              type: "AFTER_MAIL",
              img: "/images/after-mail/after_mail_6.png",
              width: 117,
            },
          ],
        ],
      ],
      621306,
    );
  },
  869404,
  (e) => {
    "use strict";
    e.s(["getRandomInterval", 0, (e, t) => Math.floor(Math.random() * (t - e + 1)) + e]);
  },
]);
