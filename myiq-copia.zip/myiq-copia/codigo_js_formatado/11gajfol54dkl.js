(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  714060,
  (e) => {
    "use strict";
    var t = e.i(919477),
      _ = (0, e.i(984898).tv)({
        base: "shrink-0 bg-divider border-none",
        variants: { orientation: { horizontal: "w-full h-divider", vertical: "h-full w-divider" } },
        defaultVariants: { orientation: "horizontal" },
      }),
      i = e.i(271645),
      s = e.i(273830),
      n = e.i(843476),
      o = (0, s.forwardRef)((e, s) => {
        let { Component: o, getDividerProps: E } = (function (e) {
          var s;
          let n,
            o,
            { as: E, className: a, orientation: A, ...r } = e,
            l = E || "hr";
          "hr" === l && "vertical" === A && (l = "div");
          let { separatorProps: I } =
              ((s = { elementType: "string" == typeof l ? l : "hr", orientation: A }),
              (o = (0, t.filterDOMProps)(s, { enabled: "string" == typeof s.elementType })),
              ("vertical" === s.orientation && (n = "vertical"), "hr" !== s.elementType)
                ? { separatorProps: { ...o, role: "separator", "aria-orientation": n } }
                : { separatorProps: o }),
            u = (0, i.useMemo)(() => _({ orientation: A, className: a }), [A, a]);
          return {
            Component: l,
            getDividerProps: (0, i.useCallback)(
              function () {
                let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return { className: u, role: "separator", "data-orientation": A, ...I, ...r, ...e };
              },
              [u, A, I, r],
            ),
          };
        })({ ...e });
        return (0, n.jsx)(o, { ref: s, ...E() });
      });
    ((o.displayName = "HeroUI.Divider"), e.s(["Divider", 0, o], 714060));
  },
  608970,
  372546,
  (e) => {
    "use strict";
    var t = e.i(134404);
    (e.s(
      [
        "checkIsFooterExist",
        0,
        (e) =>
          !e.includes(t.EClientRoutes.START) &&
          !e.includes(t.EClientRoutes.QUIZ) &&
          !e.includes(t.EClientRoutes.QUIZ_ANALYZING) &&
          !e.includes(t.EClientRoutes.PUZZLES) &&
          !e.includes(t.EClientRoutes.BASE_PROFILE) &&
          !e.includes(`${t.EClientRoutes.COURSES}/`) &&
          e !== t.EClientRoutes.START &&
          e !== t.EClientRoutes.START_PROFILE &&
          e !== t.EClientRoutes.START_PERSONALITY &&
          e !== t.EClientRoutes.START_PERSONALITY_PROFILE &&
          e !== t.EClientRoutes.START_LOVE &&
          e !== t.EClientRoutes.START_LOVE_PROFILE &&
          e !== t.EClientRoutes.START_ADHD &&
          e !== t.EClientRoutes.START_ATTACHMENT &&
          e !== t.EClientRoutes.START_CAREERS &&
          e !== t.EClientRoutes.START_ANXIETY &&
          e !== t.EClientRoutes.START_CONFIDENCE &&
          e !== t.EClientRoutes.START_STRENGTHS &&
          e !== t.EClientRoutes.START_WORK &&
          e !== t.EClientRoutes.START_BURNOUT &&
          e !== t.EClientRoutes.START_EMOTIONAL &&
          e !== t.EClientRoutes.START_DEPRESSION &&
          e !== t.EClientRoutes.START_IMPOSTER_SYNDROME &&
          e !== t.EClientRoutes.START_PSYCHOLOGICAL_ARCHETYPES &&
          e !== t.EClientRoutes.START_TIME_MANAGEMENT &&
          e !== t.EClientRoutes.START_PROCRASTINATION &&
          e !== t.EClientRoutes.START_POLITICAL_COMPASS_PROFILE &&
          e !== t.EClientRoutes.QUIZ &&
          e !== t.EClientRoutes.QUIZ_ANXIETY &&
          e !== t.EClientRoutes.QUIZ_CONFIDENCE &&
          e !== t.EClientRoutes.QUIZ_STRENGTHS &&
          e !== t.EClientRoutes.QUIZ_PROFILE &&
          e !== t.EClientRoutes.QUIZ_PERSONALITY &&
          e !== t.EClientRoutes.QUIZ_PERSONALITY_PROFILE &&
          e !== t.EClientRoutes.QUIZ_CAREERS &&
          e !== t.EClientRoutes.QUIZ_WORK &&
          e !== t.EClientRoutes.QUIZ_BURNOUT &&
          e !== t.EClientRoutes.QUIZ_EMOTIONAL &&
          e !== t.EClientRoutes.QUIZ_DEPRESSION &&
          e !== t.EClientRoutes.QUIZ_LOVE &&
          e !== t.EClientRoutes.QUIZ_LOVE_PROFILE &&
          e !== t.EClientRoutes.QUIZ_ADHD &&
          e !== t.EClientRoutes.QUIZ_IMPOSTER_SYNDROME &&
          e !== t.EClientRoutes.QUIZ_PSYCHOLOGICAL_ARCHETYPES &&
          e !== t.EClientRoutes.QUIZ_TIME_MANAGEMENT &&
          e !== t.EClientRoutes.QUIZ_PROCRASTINATION &&
          e !== t.EClientRoutes.QUIZ_POLITICAL_COMPASS_PROFILE &&
          e !== t.EClientRoutes.EMAIL &&
          e !== t.EClientRoutes.ASK_NAME &&
          e !== t.EClientRoutes.EMAIL_VERIFICATION &&
          e !== t.EClientRoutes.CORRECT_EMAIL &&
          e !== t.EClientRoutes.EMAIL_PERSONALITY &&
          e !== t.EClientRoutes.EMAIL_ATTACHMENT &&
          e !== t.EClientRoutes.EMAIL_LOVE &&
          e !== t.EClientRoutes.EMAIL_ADHD &&
          e !== t.EClientRoutes.EMAIL_DEPRESSION_FUNNEL &&
          e !== t.EClientRoutes.QUIZ_ANALYZING &&
          e !== t.EClientRoutes.QUIZ_ANALYZING_PROFILE &&
          e !== t.EClientRoutes.QUIZ_ANALYZING_PERSONALITY &&
          e !== t.EClientRoutes.QUIZ_ANALYZING_PERSONALITY_PROFILE &&
          e !== t.EClientRoutes.QUIZ_ANALYZING_ANXIETY &&
          e !== t.EClientRoutes.QUIZ_ANALYZING_CONFIDENCE &&
          e !== t.EClientRoutes.QUIZ_ANALYZING_STRENGTHS &&
          e !== t.EClientRoutes.QUIZ_ATTACHMENT &&
          e !== t.EClientRoutes.QUIZ_ANALYZING_CAREERS &&
          e !== t.EClientRoutes.QUIZ_ANALYZING_WORK &&
          e !== t.EClientRoutes.QUIZ_ANALYZING_BURNOUT &&
          e !== t.EClientRoutes.QUIZ_ANALYZING_EMOTIONAL &&
          e !== t.EClientRoutes.QUIZ_ANALYZING_DEPRESSION &&
          e !== t.EClientRoutes.QUIZ_ANALYZING_LOVE &&
          e !== t.EClientRoutes.QUIZ_ANALYZING_LOVE_PROFILE &&
          e !== t.EClientRoutes.QUIZ_ANALYZING_ADHD &&
          e !== t.EClientRoutes.QUIZ_ANALYZING_IMPOSTER_SYNDROME &&
          e !== t.EClientRoutes.QUIZ_ANALYZING_PSYCHOLOGICAL_ARCHETYPES &&
          e !== t.EClientRoutes.QUIZ_ANALYZING_TIME_MANAGEMENT &&
          e !== t.EClientRoutes.QUIZ_ANALYZING_PROCRASTINATION &&
          e !== t.EClientRoutes.QUIZ_ANALYZING_ATTACHMENT &&
          e !== t.EClientRoutes.MEMORY_GRID &&
          e !== t.EClientRoutes.COLOR_MATCH &&
          e !== t.EClientRoutes.QUICK_SOLVE &&
          e !== t.EClientRoutes.SEQUENCE_RECALL &&
          e !== t.EClientRoutes.EQUATION_BUILDER &&
          !e.includes(t.EClientRoutes.PUZZLES) &&
          e !== t.EClientRoutes.VISUAL_RECALL &&
          e !== t.EClientRoutes.REPORT &&
          e !== t.EClientRoutes.REPORT_WORK &&
          e !== t.EClientRoutes.REPORT_CAREERS &&
          e !== t.EClientRoutes.REPORT_ADHD &&
          e !== t.EClientRoutes.REPORT_ATTACHMENT &&
          e !== t.EClientRoutes.REPORT_IMPOSTER_SYNDROME &&
          e !== t.EClientRoutes.REPORT_PSYCHOLOGICAL_ARCHETYPES &&
          e !== t.EClientRoutes.REPORT_TIME_MANAGEMENT &&
          e !== t.EClientRoutes.REPORT_PROCRASTINATION &&
          e !== t.EClientRoutes.REPORT_DEPRESSION &&
          e !== t.EClientRoutes.REPORT_ANXIETY &&
          e !== t.EClientRoutes.REPORT_CONFIDENCE &&
          e !== t.EClientRoutes.REPORT_STRENGTHS &&
          e !== t.EClientRoutes.REPORT_BURNOUT &&
          e !== t.EClientRoutes.REPORT_EMOTIONAL &&
          e !== t.EClientRoutes.REPORT_LOVE &&
          e !== t.EClientRoutes.REPORT_PERSONALITY &&
          e !== t.EClientRoutes.UPGRADE &&
          !e.includes(t.EClientRoutes.BASE_PROFILE) &&
          e !== t.EClientRoutes.INTRODUCTION &&
          e !== t.EClientRoutes.GAMES &&
          e !== t.EClientRoutes.PUZZLES &&
          e !== t.EClientRoutes.TESTS &&
          e !== t.EClientRoutes.COURSES &&
          e !== t.EClientRoutes.CANCELLATION &&
          !e.includes(`${t.EClientRoutes.COURSES}/`) &&
          e !== t.EClientRoutes.CERTIFICATE &&
          e !== t.EClientRoutes.DYNAMIC_CERTIFICATE &&
          e !== t.EClientRoutes.ADDITIONAL_QUIZ &&
          !e.includes(t.EClientRoutes.SURVEYS) &&
          !e.includes(t.EClientRoutes.DEPRESSION_RESULT_SHARE + "/"),
        "checkIsFooterProfileStaticExist",
        0,
        (e) =>
          e.includes(`${t.EClientRoutes.HELP}`) ||
          e === t.EClientRoutes.TERMS ||
          e === t.EClientRoutes.PRIVACY ||
          e === t.EClientRoutes.COOKIE ||
          e === t.EClientRoutes.TERMS_EU,
        "checkIsMyiqFunnelPage",
        0,
        (e) =>
          e === t.EClientRoutes.START ||
          e === t.EClientRoutes.START_PERSONALITY ||
          e === t.EClientRoutes.START_LOVE ||
          e === t.EClientRoutes.START_AUTISM ||
          e === t.EClientRoutes.QUIZ ||
          e === t.EClientRoutes.QUIZ_PERSONALITY ||
          e === t.EClientRoutes.QUIZ_LOVE ||
          e === t.EClientRoutes.QUIZ_AUTISM ||
          e === t.EClientRoutes.QUIZ_ANALYZING ||
          e === t.EClientRoutes.QUIZ_ANALYZING_PERSONALITY ||
          e === t.EClientRoutes.QUIZ_ANALYZING_LOVE ||
          e === t.EClientRoutes.QUIZ_ANALYZING_AUTISM ||
          e === t.EClientRoutes.EMAIL ||
          e === t.EClientRoutes.EMAIL_PERSONALITY ||
          e === t.EClientRoutes.EMAIL_LOVE ||
          e === t.EClientRoutes.EMAIL_AUTISM,
        "getIsHiddenNavBar",
        0,
        (e) =>
          !(
            e.includes(t.EClientRoutes.INTRODUCTION) ||
            e.includes(t.EClientRoutes.CANCELLATION) ||
            e.includes(t.EClientRoutes.SURVEYS)
          ),
        "isCentredProfileHeader",
        0,
        (e) =>
          e === t.EClientRoutes.START ||
          e === t.EClientRoutes.START_PROFILE ||
          e === t.EClientRoutes.START_PERSONALITY ||
          e === t.EClientRoutes.START_PERSONALITY_PROFILE ||
          e === t.EClientRoutes.START_ATTACHMENT ||
          e === t.EClientRoutes.START_ADHD ||
          e === t.EClientRoutes.START_CAREERS ||
          e === t.EClientRoutes.START_ANXIETY ||
          e === t.EClientRoutes.START_CONFIDENCE ||
          e === t.EClientRoutes.START_STRENGTHS ||
          e === t.EClientRoutes.START_WORK ||
          e === t.EClientRoutes.START_BURNOUT ||
          e === t.EClientRoutes.START_EMOTIONAL ||
          e === t.EClientRoutes.START_DEPRESSION ||
          e === t.EClientRoutes.START_LOVE ||
          e === t.EClientRoutes.START_LOVE_PROFILE ||
          e === t.EClientRoutes.START_PROCRASTINATION ||
          e === t.EClientRoutes.START_TIME_MANAGEMENT ||
          e === t.EClientRoutes.START_IMPOSTER_SYNDROME ||
          e === t.EClientRoutes.START_PSYCHOLOGICAL_ARCHETYPES ||
          e === t.EClientRoutes.START_POLITICAL_COMPASS_PROFILE ||
          e === t.EClientRoutes.START_TRIVIA ||
          e === t.EClientRoutes.QUIZ ||
          e === t.EClientRoutes.QUIZ_PROFILE ||
          e === t.EClientRoutes.QUIZ_PERSONALITY ||
          e === t.EClientRoutes.QUIZ_PERSONALITY_PROFILE ||
          e === t.EClientRoutes.QUIZ_ATTACHMENT ||
          e === t.EClientRoutes.QUIZ_CAREERS ||
          e === t.EClientRoutes.QUIZ_ANXIETY ||
          e === t.EClientRoutes.QUIZ_CONFIDENCE ||
          e === t.EClientRoutes.QUIZ_STRENGTHS ||
          e === t.EClientRoutes.QUIZ_WORK ||
          e === t.EClientRoutes.QUIZ_BURNOUT ||
          e === t.EClientRoutes.QUIZ_EMOTIONAL ||
          e === t.EClientRoutes.QUIZ_DEPRESSION ||
          e === t.EClientRoutes.QUIZ_LOVE ||
          e === t.EClientRoutes.QUIZ_LOVE_PROFILE ||
          e === t.EClientRoutes.QUIZ_PROCRASTINATION ||
          e === t.EClientRoutes.QUIZ_ADHD ||
          e === t.EClientRoutes.QUIZ_TIME_MANAGEMENT ||
          e === t.EClientRoutes.QUIZ_IMPOSTER_SYNDROME ||
          e === t.EClientRoutes.QUIZ_PSYCHOLOGICAL_ARCHETYPES ||
          e === t.EClientRoutes.QUIZ_POLITICAL_COMPASS_PROFILE ||
          e === t.EClientRoutes.QUIZ_TRIVIA ||
          e === t.EClientRoutes.QUIZ_ANALYZING ||
          e === t.EClientRoutes.QUIZ_ANALYZING_PROFILE ||
          e === t.EClientRoutes.QUIZ_ANALYZING_PERSONALITY ||
          e === t.EClientRoutes.QUIZ_ANALYZING_PERSONALITY_PROFILE ||
          e === t.EClientRoutes.QUIZ_ANALYZING_CAREERS ||
          e === t.EClientRoutes.QUIZ_ANALYZING_ANXIETY ||
          e === t.EClientRoutes.QUIZ_ANALYZING_CONFIDENCE ||
          e === t.EClientRoutes.QUIZ_ANALYZING_STRENGTHS ||
          e === t.EClientRoutes.QUIZ_ANALYZING_PROCRASTINATION ||
          e === t.EClientRoutes.QUIZ_ANALYZING ||
          e === t.EClientRoutes.QUIZ_ANALYZING_WORK ||
          e === t.EClientRoutes.QUIZ_ANALYZING_BURNOUT ||
          e === t.EClientRoutes.QUIZ_ANALYZING_EMOTIONAL ||
          e === t.EClientRoutes.QUIZ_ANALYZING_DEPRESSION ||
          e === t.EClientRoutes.QUIZ_ANALYZING_LOVE ||
          e === t.EClientRoutes.QUIZ_ANALYZING_LOVE_PROFILE ||
          e === t.EClientRoutes.QUIZ_ANALYZING_ADHD ||
          e === t.EClientRoutes.QUIZ_ANALYZING_TIME_MANAGEMENT ||
          e === t.EClientRoutes.QUIZ_ANALYZING_IMPOSTER_SYNDROME ||
          e === t.EClientRoutes.QUIZ_ANALYZING_PSYCHOLOGICAL_ARCHETYPES ||
          e === t.EClientRoutes.QUIZ_ANALYZING_PROCRASTINATION ||
          e === t.EClientRoutes.QUIZ_ANALYZING_ATTACHMENT ||
          e === t.EClientRoutes.QUIZ_ANALYZING_LOVE_PROFILE ||
          e === t.EClientRoutes.START_ADDITIONAL_QUIZ ||
          e === t.EClientRoutes.ADDITIONAL_QUIZ_PROFILE ||
          e.startsWith(t.EClientRoutes.PRINTED_CERTIFICATE_SHIPPING) ||
          e === t.EClientRoutes.SKIP_TRIAL ||
          e === t.EClientRoutes.RETAKE_QUIZ,
        "isDisablePageSelection",
        0,
        (e) => e === t.EClientRoutes.QUIZ,
        "isStaticHeader",
        0,
        (e) =>
          e === t.EClientRoutes.CHECKOUT ||
          e === t.EClientRoutes.CHECKOUT_PROMO ||
          e === t.EClientRoutes.ASK_NAME ||
          e === t.EClientRoutes.EMAIL_VERIFICATION ||
          e === t.EClientRoutes.CHECKOUT_PERSONALITY ||
          e === t.EClientRoutes.CHECKOUT_LOVE ||
          e === t.EClientRoutes.CHECKOUT_AUTISM ||
          e === t.EClientRoutes.CHECKOUT_ENNEAGRAM ||
          e === t.EClientRoutes.CORRECT_EMAIL ||
          e === t.EClientRoutes.QUIZ_LOVE ||
          e === t.EClientRoutes.QUIZ_LOVE_PROFILE,
        "isStaticPolicyPage",
        0,
        (e) =>
          e === t.EClientRoutes.PRIVACY ||
          e === t.EClientRoutes.TERMS ||
          e === t.EClientRoutes.TERMS_EU ||
          e === t.EClientRoutes.COOKIE,
      ],
      372546,
    ),
      e.s([], 608970));
  },
  231627,
  (e) => {
    "use strict";
    var t = e.i(768834),
      _ = e.i(579473);
    e.i(756503);
    var i = e.i(542516);
    let s = {
        currentQuestionIdx: 0,
        currentAnswers: {},
        questions: [],
        isLoading: !1,
        isComplete: !1,
        canGoBack: !1,
        canGoNext: !1,
        progress: 0,
        isGuestSurveyCompleted: !1,
        isCheckingCompletion: !0,
      },
      n = (0, t.create)()(
        (0, _.devtools)(
          (e) => ({
            ...s,
            handleChangeSurveyStore: (t) => e((e) => ({ ...e, ...t })),
            resetSurveyStore: () => e(s),
          }),
          { enabled: "production" !== i.envClient.NEXT_PUBLIC_NODE_ENV },
        ),
      );
    e.s(["useSurveyStore", 0, n]);
  },
  331890,
  129466,
  (e) => {
    "use strict";
    var t = e.i(117595),
      _ = e.i(948148),
      i = e.i(271645),
      s = e.i(266027),
      n = e.i(866897),
      o = e.i(134404);
    e.i(682770);
    var E = e.i(934952);
    e.i(531122);
    var a = e.i(81844);
    let A = async (e) => {
        try {
          let t = e ? `${o.EApiRoutes.COUNTRY_DATA}/${e}` : o.EApiRoutes.COUNTRY_DATA,
            _ = await a.httpInstance.get(t, { cache: "force-cache", next: { revalidate: 86400 } });
          return { data: (await _.json()).data, success: !0 };
        } catch {
          return { error: "error_smth_went_wrong", success: !1 };
        }
      },
      r = function (e) {
        let a = !(arguments.length > 1) || void 0 === arguments[1] || arguments[1],
          r = (0, _.useTranslations)(),
          l = e || t.default.get(n.ECookieArg.COUNTRY),
          I = (0, s.useQuery)({
            queryKey: [o.EApiRoutes.COUNTRY_DATA, l || "auto"],
            queryFn: () => A(l),
            enabled: a,
          });
        return (
          (0, i.useEffect)(() => {
            I.data && !I.data.success && (0, E.customToast)(r("error_smth_went_wrong"), "error");
          }, [I.data, r]),
          I
        );
      };
    e.s(
      [
        "useGetCountryDataQuery",
        0,
        r,
        "useGetNeighborCountriesFromCountryData",
        0,
        function (e) {
          let t = !(arguments.length > 1) || void 0 === arguments[1] || arguments[1],
            { data: _, error: i, isLoading: s, refetch: n } = r(e, t);
          return {
            data: _?.data
              ? {
                  currentCountry: { code: _.data.currentCountry.code, names: _.data.currentCountry.names },
                  neighboringCountries: _.data.neighboringCountries,
                }
              : void 0,
            error: i,
            isLoading: s,
            refetch: n,
            success: _?.success,
          };
        },
      ],
      331890,
    );
    var l = e.i(60423),
      I = e.i(157273);
    e.s(
      [
        "getCountryDataFromLocalStorage",
        0,
        () => {
          let e = l.accessLocalStorage.getItem(I.StorageKeys.COUNTRY_DATA);
          if (!e) return null;
          try {
            return JSON.parse(e);
          } catch {
            return null;
          }
        },
        "saveCountryDataToLocalStorage",
        0,
        (e) => {
          e && l.accessLocalStorage.setItem(I.StorageKeys.COUNTRY_DATA, JSON.stringify(e));
        },
      ],
      129466,
    );
  },
  707301,
  857747,
  (e) => {
    "use strict";
    var t,
      _ = e.i(264267),
      i = e.i(271645);
    function s() {
      return (s = Object.assign.bind()).apply(null, arguments);
    }
    e.s(
      [
        "default",
        0,
        (e) =>
          i.createElement(
            "svg",
            s({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 25" }, e),
            t ||
              (t = i.createElement("path", {
                stroke: "currentColor",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M20 12.5H4m0 0 6 6m-6-6 6-6",
              })),
          ),
      ],
      857747,
    );
    let n = (0, _.svgImage)("/illustrations/quiz/motiv-1.svg", { width: 601, height: 437 }),
      o = (0, _.svgImage)("/illustrations/quiz/motiv-2.svg", { width: 454, height: 448 }),
      E = (0, _.svgImage)("/illustrations/quiz/motiv-3-new.svg", { width: 777, height: 447 }),
      a = (0, _.svgImage)("/illustrations/quiz/motiv-4.svg", { width: 602, height: 469 });
    e.s(
      [
        "IconMotivationQuizFour",
        0,
        a,
        "IconMotivationQuizOne",
        0,
        n,
        "IconMotivationQuizThree",
        0,
        o,
        "IconMotivationQuizTwo",
        0,
        E,
      ],
      707301,
    );
  },
  264267,
  (e) => {
    "use strict";
    var t = e.i(843476);
    e.s([
      "svgImage",
      0,
      (e, _) => {
        let i = "number" == typeof _ ? { width: _, height: _ } : _,
          s = (_) => {
            let { style: s, onError: n, ...o } = _;
            return (0, t.jsx)("img", {
              src: e,
              alt: "",
              width: i?.width,
              height: i?.height,
              ...o,
              style: s,
              onError: (t) => {
                let _, i;
                ((i = Number((_ = t.currentTarget).dataset.retry ?? 0) + 1) > 2 ||
                  ((_.dataset.retry = String(i)),
                  setTimeout(() => {
                    _.src = `${e}${e.includes("?") ? "&" : "?"}retry=${i}`;
                  }, 1e3 * i),
                  0)) &&
                  n?.(t);
              },
            });
          };
        return ((s.src = e), s);
      },
    ]);
  },
  932880,
  (e) => {
    "use strict";
    var t,
      _,
      i = e.i(117595),
      s = e.i(618566),
      n = e.i(861745),
      o = e.i(271645),
      E = e.i(331890),
      a = e.i(59857),
      A = e.i(49587),
      r = e.i(866897),
      l = e.i(157273),
      I = e.i(86596),
      u = e.i(60423),
      R = e.i(129466),
      T = e.i(646162),
      C = e.i(302433),
      S = e.i(523173),
      c = e.i(134404),
      N = e.i(915113);
    e.i(756503);
    var O = e.i(846911);
    e.i(470366);
    var L = e.i(504001);
    e.i(569311);
    var M = e.i(896855),
      U = e.i(202042),
      P =
        (((t = {}).FS_AB_MYIQ_START_PAGE_TEST = "fs_ab_myiq_start_page_test"),
        (t.AB_MYIQ_PAYWALL_BENEFITS_OPTIMIZATION = "ab_myiq_paywall_benefits_optimization"),
        (t.AB_MYIQ_SESSION_RECORDING = "ab_myiq_session_recording"),
        (t.AB_MYIQ_PROFILE_EVENTS = "ab_myiq_profile_events"),
        (t.AB_MYIQ_PRODUCT_ADD_QUIZ_AFTER_PAYWALL = "ab_myiq_product_add_quiz_after_paywall"),
        (t.AB_MYIQ_ADDED_PROFILE_EVENTS = "ab_myiq_added_profile_events"),
        (t.AB_MYIQ_FORMBRIKS_SURVEY_VARIANTS = "ab_myiq_formbricks_survey_variants"),
        (t.AB_MYIQ_QUIZ_COMPLETION_CTA_REMOVAL = "ab_myiq_quiz_completion_cta_removal"),
        (t.AB_MYIQ_PRINT_CERTIFICATE_UPSELL = "ab_myiq_print_certificate_upsell"),
        (t.AB_MYIQ_PRODUCT_FEEDBACK_WIDGET = "ab_myiq_product_feedback_widget"),
        (t.AB_MYIQ_TRIVIA_POPUP_UPSELL = "ab_myiq_trivia_popup_upsell"),
        (t.AB_MYIQ_REVOLUT_MONZO_BLOCK = "ab_myiq_revolut_monzo_block"),
        (t.AB_MYIQ_PROMO_PRICE = "ab_myiq_promo_price"),
        (t.AB_MYIQ_SPECIALIST_QUESTION_BEFORE_PAYWALL = "ab_myiq_specialist_question_before_paywall"),
        (t.AB_MYIQ_REFERRAL_EMAIL_PRODUCT = "ab_myiq_referral_email_product"),
        (t.AB_MYIQ_A_B_1_00_VS_1_99_1 = "ab_myiq_product_trial_1_00_vs_1_99"),
        (t.AB_MYIQ_PRODUCT_CANCEL_SUBS_DOWNGRADE_UPSELL_9_99 =
          "ab_myiq_product_cancel_subs_downgrade_upsell_9_99"),
        (t.AB_MYIQ_DESKTOP_PAYMENT_ABOVE_FOLD = "ab_myiq_desktop_payment_above_fold"),
        (t.AB_MYIQ_BRAZIL_MASTERCARD_ONLY = "ab_myiq_brazil_mastercard_only"),
        (t.AB_MYIQ_LOC_ITALIAN_PAYWALL = "ab_myiq_loc_italian_paywall"),
        (t.AB_MYIQ_LOC_ITALIAN_REPORT = "ab_myiq_loc_italian_report"),
        (t.AB_MYIQ_PAYWALL_LAYOUT = "ab_myiq_paywall_layout"),
        (t.AB_MYIQ_QUIZ_CHAOS_BLOCK_Q11_22 = "ab_myiq_quiz_chaos_block_q11_22"),
        (t.AB_MYIQ_REPORT_DELAYED_GENERATION = "ab_myiq_report_delayed_generation"),
        (t.AB_MYIQ_ANALYZING_AI_CHAT_MODAL = "ab_myiq_analyzing_ai_chat_modal"),
        (t.AB_MYIQ_ANALYZING_REPORT_OPTIN_QUESTION = "ab_myiq_analyzing_report_optin_question"),
        (t.AB_MYIQ_ANALYZING_NUMBER_RECALL_FOLLOWUP = "ab_myiq_analyzing_number_recall_followup"),
        (t.AB_MYIQ_QUIZ_TEXT_QS_CHAT_LAYOUT = "ab_myiq_quiz_text_qs_chat_layout"),
        (t.AB_MYIQ_START_PAGE_MEDIA_LOGOS = "ab_myiq_start_page_media_logos"),
        (t.AB_MYIQ_CANCELLATION_WHAT_YOU_LOSE = "ab_myiq_cancellation_what_you_lose"),
        (t.AB_MYIQ_POST_PAYMENT_PROCESSING_MODAL = "ab_myiq_post_payment_processing_modal"),
        (t.AB_MYIQ_QUIZ_OPENER_SWAP = "ab_myiq_quiz_opener_swap"),
        (t.AB_MYIQ_QUIZ_MIDRUN_SWAP = "ab_myiq_quiz_midrun_swap"),
        (t.AB_MYIQ_ANALYZING_LAST_STEPS_ORDER = "ab_myiq_analyzing_last_steps_order"),
        (t.AB_MYIQ_PAYWALL_FONT_OPTIMIZATION = "ab_myiq_paywall_font_optimization"),
        (t.AB_MYIQ_PAYWALL_BENEFITS_REDESIGN = "ab_myiq_paywall_benefits_redesign"),
        (t.AB_MYIQ_PAYWALL_SUMMARY_REDESIGN = "ab_myiq_paywall_summary_redesign"),
        (t.AB_MYIQ_QUIZ_HINT_ASSIST_COUNT = "ab_myiq_quiz_hint_assist_count"),
        (t.AB_MYIQ_SOCIAL_PILL_DESIGN = "ab_myiq_social_pill_design"),
        (t.AB_MYIQ_QUIZ_FEWER_OPTIONS = "ab_myiq_quiz_fewer_options"),
        (t.AB_MYIQ_QUIZ_PERCEPTION_QUESTIONS = "ab_myiq_quiz_perception_questions"),
        (t.AB_MYIQ_QUIZ_ALGEBRA_SHAPES_V2 = "ab_myiq_quiz_algebra_shapes_v2"),
        (t.AB_MYIQ_QUIZ_FLAG_TRIVIA = "ab_myiq_quiz_flag_trivia"),
        (t.AB_MYIQ_QUIZ_STROOP_COLOR_BLOCK = "ab_myiq_quiz_stroop_color_block"),
        (t.AB_MYIQ_QUIZ_MIRROR_WORDS = "ab_myiq_quiz_mirror_words"),
        (t.AB_MYIQ_QUIZ_COUNT_GRID_PLACEMENT = "ab_myiq_quiz_count_grid_placement"),
        (t.AB_MYIQ_QUIZ_ODD_ONE_OUT_MICROGAME = "ab_myiq_quiz_odd_one_out_microgame"),
        (t.AB_MYIQ_QUIZ_NUMBER_RECALL = "ab_myiq_quiz_number_recall"),
        (t.AB_MYIQ_QUIZ_MATHS_TRIVIA = "ab_myiq_quiz_maths_trivia"),
        (t.AB_MYIQ_QUIZ_OPTICAL_ILLUSION_NUMBERS = "ab_myiq_quiz_optical_illusion_numbers"),
        (t.AB_MYIQ_QUIZ_CLASSIC_ILLUSIONS_V2 = "ab_myiq_quiz_classic_illusions_v2"),
        (t.AB_MYIQ_QUIZ_VERBAL_ANALOGIES = "ab_myiq_quiz_verbal_analogies"),
        (t.AB_MYIQ_QUIZ_REACTION_TAP_GAME = "ab_myiq_quiz_reaction_tap_game"),
        (t.FS_AB_MYIQ_LOC_UKR_COPY = "ab_myiq_loc_ukr_copy"),
        (t.FS_AB_MYIQ_LOC_RUS_COPY = "ab_myiq_loc_rus_copy"),
        (t.FS_AB_MYIQ_LOC_SPA_COPY = "ab_myiq_loc_spa_copy"),
        (t.AB_MYIQ_LOCALIZATION_PORTUGUESE_PT = "ab_myiq_localization_portuguese_pt"),
        (t.AB_MYIQ_LOCALIZATION_BRAZILIAN_PORTUGUESE_PT_BR =
          "ab_myiq_localization_brazilian_portuguese_pt_br"),
        (t.AB_MYIQ_LOCALIZATION_FRENCH_FR = "ab_myiq_localization_french_fr"),
        (t.AB_MYIQ_BENEFIT_VERSION = "ab_myiq_benefit_version"),
        (t.AB_MYIQ_EMAIL_REMOVE_STATS_BLOCK = "ab_myiq_email_remove_stats_block"),
        (t.AB_MYIQ_EMAIL_SOCIAL_SIGNUP = "ab_myiq_email_social_signup"),
        (t.AB_NEW_MYIQ_START_HEADLINE_COPY = "ab_new_myiq_start_headline_copy"),
        (t.AB_NEW_MYIQ_START_PAGE_SOCIAL_PROOF_STATS = "ab_new_myiq_start_page_social_proof_stats"),
        (t.AB_NEW_MYIQ_START_PAGE_GENDER_STICKY_CTA = "ab_new_myiq_start_page_gender_sticky_cta"),
        (t.AB_MYIQ_NEW_HOMEPAGE_COMPACT_CAROUSEL = "ab_myiq_new_homepage_compact_carousel"),
        (t.AB_MYIQ_NEW_HOMEPAGE_CTA_COPY = "ab_myiq_new_homepage_cta_copy"),
        (t.AB_MYIQ_NEW_HOMEPAGE_START_SECTION = "ab_myiq_new_homepage_start_section"),
        t),
      d =
        (((_ = {}).FT_MYIQ_PAYWALL = "ft_myiq_paywall"),
        (_.FT_MYIQ_FUNNEL = "ft_myiq_funnel"),
        (_.FT_MYIQ_REVIEWS = "ft_myiq_reviews"),
        (_.FT_MYIQ_REVIEW_PLATFORM_SPLIT = "ft_myiq_review_platform_split"),
        (_.FT_MYIQ_REPORT_NON_IMAGE_ANSWERS = "ft_myiq_report_non_image_answers"),
        (_.FT_COOKIE_BANNER = "ft_cookie_banner"),
        (_.FT_MEMORIZE_CONTINUE_ANALYTICS = "ft_memorize_continue_analytics"),
        (_.FT_MEMORIZE_CONTINUE_ANALYTICS_REDESIGN = "ft_memorize_continue_analytics_redesign"),
        (_.FT_MYIQ_REPORT_ONE_PAGE_V2 = "ft_myiq_report_one_page_v2"),
        (_.FT_MYIQ_ST_UPDATE = "ft_myiq_st_update"),
        _);
    let m = [c.EClientRoutes.CANCELLATION, c.EClientRoutes.SIGN_IN, c.EClientRoutes.DELETE_ACCOUNT];
    (P.FS_AB_MYIQ_START_PAGE_TEST,
      P.AB_MYIQ_SESSION_RECORDING,
      P.AB_MYIQ_PROFILE_EVENTS,
      P.AB_MYIQ_QUIZ_COMPLETION_CTA_REMOVAL,
      P.AB_MYIQ_REVOLUT_MONZO_BLOCK,
      P.AB_MYIQ_LOC_ITALIAN_PAYWALL,
      P.AB_MYIQ_LOC_ITALIAN_REPORT,
      d.FT_MYIQ_PAYWALL,
      d.FT_MYIQ_FUNNEL,
      d.FT_MYIQ_REVIEWS,
      P.AB_MYIQ_SPECIALIST_QUESTION_BEFORE_PAYWALL,
      P.AB_MYIQ_REFERRAL_EMAIL_PRODUCT,
      P.AB_MYIQ_A_B_1_00_VS_1_99_1,
      P.AB_MYIQ_DESKTOP_PAYMENT_ABOVE_FOLD,
      P.AB_MYIQ_BRAZIL_MASTERCARD_ONLY,
      P.AB_MYIQ_START_PAGE_MEDIA_LOGOS,
      P.AB_MYIQ_PAYWALL_LAYOUT,
      P.AB_MYIQ_QUIZ_CHAOS_BLOCK_Q11_22,
      P.AB_MYIQ_REPORT_DELAYED_GENERATION,
      P.AB_MYIQ_ANALYZING_AI_CHAT_MODAL,
      P.AB_MYIQ_ANALYZING_REPORT_OPTIN_QUESTION,
      P.AB_MYIQ_QUIZ_TEXT_QS_CHAT_LAYOUT,
      P.AB_MYIQ_ANALYZING_NUMBER_RECALL_FOLLOWUP,
      P.AB_MYIQ_POST_PAYMENT_PROCESSING_MODAL,
      P.AB_MYIQ_QUIZ_OPENER_SWAP,
      P.AB_MYIQ_QUIZ_MIDRUN_SWAP,
      P.AB_MYIQ_ANALYZING_LAST_STEPS_ORDER,
      P.AB_MYIQ_PAYWALL_BENEFITS_OPTIMIZATION,
      P.AB_MYIQ_PAYWALL_FONT_OPTIMIZATION,
      P.AB_MYIQ_PAYWALL_BENEFITS_REDESIGN,
      P.AB_MYIQ_BENEFIT_VERSION,
      P.AB_MYIQ_PAYWALL_SUMMARY_REDESIGN,
      P.AB_MYIQ_ADDED_PROFILE_EVENTS,
      P.AB_MYIQ_FORMBRIKS_SURVEY_VARIANTS,
      P.AB_MYIQ_QUIZ_HINT_ASSIST_COUNT,
      P.AB_MYIQ_QUIZ_FEWER_OPTIONS,
      P.AB_MYIQ_QUIZ_PERCEPTION_QUESTIONS,
      P.AB_MYIQ_QUIZ_ALGEBRA_SHAPES_V2,
      P.AB_MYIQ_QUIZ_FLAG_TRIVIA,
      P.AB_MYIQ_QUIZ_STROOP_COLOR_BLOCK,
      P.AB_MYIQ_QUIZ_MIRROR_WORDS,
      P.AB_MYIQ_QUIZ_COUNT_GRID_PLACEMENT,
      P.AB_MYIQ_QUIZ_ODD_ONE_OUT_MICROGAME,
      P.AB_MYIQ_QUIZ_NUMBER_RECALL,
      P.AB_MYIQ_QUIZ_MATHS_TRIVIA,
      P.AB_MYIQ_QUIZ_OPTICAL_ILLUSION_NUMBERS,
      P.AB_MYIQ_QUIZ_CLASSIC_ILLUSIONS_V2,
      P.AB_MYIQ_QUIZ_VERBAL_ANALOGIES,
      P.AB_MYIQ_QUIZ_REACTION_TAP_GAME,
      P.FS_AB_MYIQ_LOC_UKR_COPY,
      P.FS_AB_MYIQ_LOC_RUS_COPY,
      P.FS_AB_MYIQ_LOC_SPA_COPY,
      P.AB_MYIQ_LOCALIZATION_PORTUGUESE_PT,
      P.AB_MYIQ_LOCALIZATION_BRAZILIAN_PORTUGUESE_PT_BR,
      P.AB_MYIQ_LOCALIZATION_FRENCH_FR,
      P.AB_MYIQ_EMAIL_REMOVE_STATS_BLOCK,
      P.AB_MYIQ_EMAIL_SOCIAL_SIGNUP,
      P.AB_NEW_MYIQ_START_HEADLINE_COPY,
      P.AB_NEW_MYIQ_START_PAGE_SOCIAL_PROOF_STATS,
      P.AB_NEW_MYIQ_START_PAGE_GENDER_STICKY_CTA,
      P.AB_MYIQ_NEW_HOMEPAGE_COMPACT_CAROUSEL,
      P.AB_MYIQ_NEW_HOMEPAGE_CTA_COPY,
      P.AB_MYIQ_NEW_HOMEPAGE_START_SECTION,
      d.FT_MYIQ_ST_UPDATE,
      e.s(
        [
          "default",
          0,
          (e) => {
            let { flagshipExperiments: t, serverUserData: _, scope: P = "public" } = e,
              d = (0, n.useLocale)(),
              Q = (0, U.usePathname)(),
              Y = (0, s.useSearchParams)(),
              g = (0, o.useRef)(!1),
              p = (0, o.useRef)(!1),
              y = (0, o.useRef)(!1),
              Z = (0, o.useRef)(!1),
              G = (0, o.useRef)(!1),
              h = (0, N.getIsMarketingSource)(),
              { user: v, handleChangeUserStore: B } = (0, I.useUserStore)(),
              [f, D] = (0, o.useState)(() => I.useUserStore.persist?.hasHydrated() ?? !1);
            (0, o.useEffect)(() => I.useUserStore.persist.onFinishHydration(() => D(!0)), []);
            let { data: b } = (0, E.useGetCountryDataQuery)(void 0, "public" === P && !v?.currency),
              F = v?.id || ("static" === P ? _.id : void 0),
              q = "static" === P ? !!F : !!v,
              x = "static" === P ? Q === c.EClientRoutes.BASE : Q !== c.EClientRoutes.BASE,
              w = async () => {
                let e = navigator.language || navigator.languages?.[0] || "en";
                if (!q) return;
                let { ab_myiq_revolut_monzo_block: i, ab_myiq_paywall_layout: s, ...n } = t,
                  o = u.accessLocalStorage.getItem(l.StorageKeys.MARKETING_USER_ID);
                (Q.includes(c.EClientRoutes.CANCELLATION) ||
                  Q.includes(c.EClientRoutes.SIGN_IN) ||
                  (0, L.initPeopleAnalytic)(o || F || _.id || ""),
                  (0, L.setPeopleAnalyticOnce)({
                    app_version: "v2",
                    product_name: "myiq",
                    build_version: O.envServer.BUILD_VERSION || "unknown",
                    instance_region: O.envServer.INSTANCE_REGION || "non-set",
                    browser_language: e,
                    ...(("block" === i || "not_block" === i) && { ab_myiq_revolut_monzo_block: i }),
                    ...(h && { ab_myiq_paywall_layout: s }),
                    ...n,
                  }),
                  (0, L.setPeopleAnalytic)({
                    email_marketing: o ? "true" : "false",
                    Locale: d,
                    marketing_param: !!(0, N.getIsMarketingSource)(),
                    [C.REDESIGN_FUNNEL_PROPERTY]: (0, A.getIsRedesignFunnel)(),
                  }));
              };
            return (
              (0, o.useEffect)(() => {
                if (q) {
                  let e,
                    t = x
                      ? ((e) => {
                          switch (e) {
                            case c.EClientRoutes.BASE:
                              return S.EAnalyticEvents.MAIN_PAGE_VIEW;
                            case c.EClientRoutes.START:
                            case c.EClientRoutes.START_LOVE:
                            case c.EClientRoutes.START_PERSONALITY:
                            case c.EClientRoutes.START_CAREERS:
                            case c.EClientRoutes.START_ANXIETY:
                            case c.EClientRoutes.START_CONFIDENCE:
                            case c.EClientRoutes.START_STRENGTHS:
                            case c.EClientRoutes.START_ATTACHMENT:
                            case c.EClientRoutes.START_PSYCHOLOGICAL_ARCHETYPES:
                            case c.EClientRoutes.START_PROCRASTINATION:
                            case c.EClientRoutes.START_TIME_MANAGEMENT:
                            case c.EClientRoutes.START_ADHD:
                            case c.EClientRoutes.START_WORK:
                            case c.EClientRoutes.START_BURNOUT:
                            case c.EClientRoutes.START_EMOTIONAL:
                            case c.EClientRoutes.START_DEPRESSION:
                            case c.EClientRoutes.START_IMPOSTER_SYNDROME:
                            case c.EClientRoutes.START_ENNEAGRAM:
                              return S.EAnalyticEvents.FUNNEL_START_VIEW;
                            case c.EClientRoutes.CHECKOUT:
                            case c.EClientRoutes.EMAIL_VERIFICATION:
                            case c.EClientRoutes.CHECKOUT_LOVE:
                            case c.EClientRoutes.CHECKOUT_PERSONALITY:
                            case c.EClientRoutes.CHECKOUT_ENNEAGRAM:
                              return S.EAnalyticEvents.PAYWALL_VIEWED;
                            case c.EClientRoutes.CORRECT_EMAIL:
                              return S.EAnalyticEvents.VALIDATION_EMAIL_VIEWED;
                            case c.EClientRoutes.REPORT:
                              return S.EAnalyticEvents.REPORT_VIEWED;
                            case c.EClientRoutes.EMAIL:
                            case c.EClientRoutes.EMAIL_LOVE:
                            case c.EClientRoutes.EMAIL_PERSONALITY:
                            case c.EClientRoutes.EMAIL_ENNEAGRAM:
                              return S.EAnalyticEvents.EMAIL_VIEWED;
                            case c.EClientRoutes.QUIZ_ANALYZING:
                            case c.EClientRoutes.QUIZ_ANALYZING_LOVE:
                            case c.EClientRoutes.QUIZ_ANALYZING_PERSONALITY:
                            case c.EClientRoutes.QUIZ_ANALYZING_CAREERS:
                            case c.EClientRoutes.QUIZ_ANALYZING_ANXIETY:
                            case c.EClientRoutes.QUIZ_ANALYZING_CONFIDENCE:
                            case c.EClientRoutes.QUIZ_ANALYZING_STRENGTHS:
                            case c.EClientRoutes.QUIZ_ANALYZING_WORK:
                            case c.EClientRoutes.QUIZ_ANALYZING_BURNOUT:
                            case c.EClientRoutes.QUIZ_ANALYZING_EMOTIONAL:
                            case c.EClientRoutes.QUIZ_ANALYZING_DEPRESSION:
                            case c.EClientRoutes.QUIZ_ANALYZING_ADHD:
                            case c.EClientRoutes.QUIZ_ANALYZING_PROCRASTINATION:
                            case c.EClientRoutes.QUIZ_ANALYZING_TIME_MANAGEMENT:
                            case c.EClientRoutes.QUIZ_ANALYZING_IMPOSTER_SYNDROME:
                            case c.EClientRoutes.QUIZ_ANALYZING_PSYCHOLOGICAL_ARCHETYPES:
                            case c.EClientRoutes.QUIZ_ANALYZING_ATTACHMENT:
                            case c.EClientRoutes.QUIZ_ANALYZING_ENNEAGRAM:
                              return S.EAnalyticEvents.ANALYZING_VIEWED;
                          }
                          return null;
                        })(Q)
                      : null;
                  (t !== S.EAnalyticEvents.PAYWALL_VIEWED && (Z.current = !1),
                    t !== S.EAnalyticEvents.MAIN_PAGE_VIEW && (G.current = !1));
                  let _ = (e = v?.funnel || Q).includes("love")
                      ? "love_language"
                      : e.includes("personality")
                        ? "personality"
                        : e.includes("enneagram")
                          ? "enneagram"
                          : "myiq",
                    s =
                      "true" === i.default.get(r.ECookieArg.BT_FUNNEL) && "myiq" === _ && "en" === d
                        ? "myiq-bt"
                        : _,
                    n = (0, T.resolvePersonalityFunnel)(
                      s,
                      i.default.get(r.ECookieArg.PERSONALITY_FUNNEL_VARIANT),
                    ),
                    o =
                      Q.includes(c.EClientRoutes.START) ||
                      Q.includes(c.EClientRoutes.QUIZ) ||
                      Q.includes(c.EClientRoutes.QUIZ_ANALYZING) ||
                      Q.includes(c.EClientRoutes.EMAIL) ||
                      Q.includes(c.EClientRoutes.CHECKOUT),
                    E = "true" === i.default.get(r.ECookieArg.PLAN_PICKER_FUNNEL),
                    A = "true" === i.default.get(r.ECookieArg.US_A1_CAMPAIGN),
                    I = "true" === i.default.get(r.ECookieArg.BR_CAMPAIGN),
                    R =
                      !!Y.get("user_token") ||
                      (0, a.hasValidMarketingParams)({
                        cid: Y.get("cid") ?? void 0,
                        i: Y.get("i") ?? void 0,
                        t: Y.get("t") ?? void 0,
                        email: Y.get("email") ?? void 0,
                        ff: Y.get("ff") ?? void 0,
                        r: Y.get("r") ?? void 0,
                        funnel: Y.get("funnel") ?? void 0,
                        quiz_answers: Y.get("quiz_answers") ?? void 0,
                        rt: Y.get("rt") ?? void 0,
                      }),
                    C = t === S.EAnalyticEvents.PAYWALL_VIEWED && (Z.current || R || !v?.email),
                    O = t === S.EAnalyticEvents.MAIN_PAGE_VIEW && G.current;
                  if (g.current) {
                    let e, _;
                    if (
                      ((e = m.some((e) => Q.includes(e))),
                      (_ = u.accessLocalStorage.getItem(l.StorageKeys.MARKETING_USER_ID)),
                      !e &&
                        !_ &&
                        v?.id &&
                        M.mixpanelClient.peopleGetDistinctId() !== v.id &&
                        (0, L.initPeopleAnalytic)(v.id),
                      o && (0, L.setPeopleAnalytic)({ funnel: n }),
                      t)
                    )
                      switch (t) {
                        case S.EAnalyticEvents.PAYWALL_VIEWED:
                          if (C) break;
                          ((0, L.trackClientEvents)({
                            event: t,
                            sessionId: v?.id,
                            params: {
                              marketing_param: !!(0, N.getIsMarketingSource)(),
                              funnel: s,
                              paymentOrchestrator: "PayNext",
                              paynextSessionId: i.default.get(r.ECookieArg.PAYNEXT_SESSION),
                              ...(E && { plan_picker_funnel: !0 }),
                              ...(A && { us_a1_campaign: !0 }),
                              ...(I && { br_campaign: !0 }),
                            },
                          }),
                            (Z.current = !0));
                          break;
                        case S.EAnalyticEvents.MAIN_PAGE_VIEW:
                          if (O) break;
                          ((0, L.trackClientEvents)({ event: t, sessionId: F, params: { funnel: s } }),
                            (G.current = !0));
                          break;
                        case S.EAnalyticEvents.EMAIL_VIEWED:
                          (0, L.trackClientEvents)({
                            event: t,
                            sessionId: F,
                            params: { marketing_param: !!(0, N.getIsMarketingSource)(), funnel: s },
                          });
                          break;
                        default:
                          (0, L.trackClientEvents)({ event: t, sessionId: F, params: { funnel: s } });
                      }
                  } else
                    ((g.current = !0),
                      t !== S.EAnalyticEvents.MAIN_PAGE_VIEW || O || (G.current = !0),
                      w().then(() => {
                        t &&
                          (C ||
                            O ||
                            (o && (0, L.setPeopleAnalytic)({ funnel: n }),
                            (0, L.trackClientEvents)({
                              event: t,
                              sessionId: F,
                              params: {
                                funnel: s,
                                ...(t === S.EAnalyticEvents.PAYWALL_VIEWED &&
                                  E && { plan_picker_funnel: !0 }),
                                ...(t === S.EAnalyticEvents.PAYWALL_VIEWED && A && { us_a1_campaign: !0 }),
                                ...(t === S.EAnalyticEvents.PAYWALL_VIEWED && I && { br_campaign: !0 }),
                              },
                            }),
                            t === S.EAnalyticEvents.PAYWALL_VIEWED && (Z.current = !0)));
                      }));
                }
              }, [Q, v?.id, v?.email, Y]),
              (0, o.useEffect)(() => {
                f &&
                  b?.success &&
                  !p.current &&
                  ((p.current = !0),
                  (() => {
                    if (!b?.success || !b?.data?.currentCountry?.currency || y.current) return;
                    y.current = !0;
                    let e = b.data.currentCountry.currency,
                      t = {
                        countryCode: e?.country_2code || "US",
                        currencyCode: e?.currency_code || "USD",
                        currencyForPay: e?.currency_card || "USD",
                        currencyCard: e?.currency_card || "USD",
                        currencyPaypal: ((e) => {
                          let { paypalCurrency: t, currencyCode: _ } = e;
                          switch (_) {
                            case "AUD":
                            case "CAD":
                            case "GBP":
                            case "EUR":
                              return _;
                            default:
                              return t || "USD";
                          }
                        })({
                          paypalCurrency: e?.currency_paypal || "USD",
                          currencyCode: e?.currency_code || "USD",
                        }),
                        currencyWallet: e?.currency_wallet || "USD",
                        currencySymbol: e?.currency_symbol || "$",
                        symbolAtStart: e?.symbol_at_start ?? "TRUE",
                        usdExchangeRate: e?.usd_exchange_rate || 1,
                        eurExchangeRate: e?.eur_exchange_rate || 1,
                      };
                    B({
                      user: {
                        id: i.default.get(r.ECookieArg.SESSION_ID) || _.id,
                        currency: t,
                        locale: d,
                        ip: _.ip,
                        user_agent: _.user_agent,
                        operating_system: _.operating_system,
                      },
                    });
                  })());
              }, [f, b?.success]),
              (0, o.useEffect)(() => {
                b?.success && b?.data && (0, R.saveCountryDataToLocalStorage)(b?.data);
              }, [b]),
              null
            );
          },
        ],
        932880,
      ));
  },
  437460,
  698219,
  341302,
  (e) => {
    "use strict";
    var t = e.i(932880);
    e.s(["AnalyticTrackerComponent", () => t.default], 437460);
    var _ = e.i(618566),
      i = e.i(271645),
      s = e.i(202042),
      n = e.i(157273),
      o = e.i(562942),
      E = e.i(190899),
      a = e.i(866897),
      A = e.i(429067),
      r = e.i(86596),
      l = e.i(924254);
    e.i(569311);
    var I = e.i(896855);
    (e.s([], 698219),
      e.s(
        [
          "SessionUtmComponent",
          0,
          () => {
            let e,
              t,
              u,
              R = (0, _.useSearchParams)(),
              T = (0, i.useRef)(!1),
              C = (0, r.useUserStore)((e) => e.user),
              S = (0, r.useUserStore)((e) => e.handleChangeUserStore);
            ((e = (0, _.useSearchParams)()),
              (t = (0, s.usePathname)()),
              (u = e.get(o.UTM_PARAMS.MYIQ_PARAM_ID)),
              (0, i.useEffect)(() => {
                u &&
                  u === o.UTM_PARAMS.ID &&
                  (E.accessSessionStorageUtil.getItem(n.StorageKeys.MARKETING_ID) ||
                    E.accessSessionStorageUtil.setItem(n.StorageKeys.MARKETING_ID, u));
              }, [t, u]),
              E.accessSessionStorageUtil.getItem(n.StorageKeys.MARKETING_ID));
            let c = () =>
              (R.get(o.UTM_PARAMS.MYIQ_PREVENT_PARAM_GOOGLE) ||
                R.get(o.UTM_PARAMS.MYIQ_PREVENT_PARAM_GOOGLE.toUpperCase())) ===
              o.UTM_PARAMS.MYIQ_PREVENT_PARAM_GOOGLE_VALUE;
            R.get(o.UTM_PARAMS.MYIQ_PARAM) || R.get(o.UTM_PARAMS.MYIQ_PARAM.toUpperCase());
            let N =
                R.get(o.UTM_PARAMS.MYIQ_PARAM_GOOGLE) || R.get(o.UTM_PARAMS.MYIQ_PARAM_GOOGLE.toUpperCase()),
              O =
                R.get(o.UTM_PARAMS.MYIQ_PARAM_TIKTOK) || R.get(o.UTM_PARAMS.MYIQ_PARAM_TIKTOK.toUpperCase()),
              L =
                R.get(o.UTM_PARAMS.MYIQ_PARAM_APPLOVIN) ||
                R.get(o.UTM_PARAMS.MYIQ_PARAM_APPLOVIN.toUpperCase()),
              M =
                R.get(o.UTM_PARAMS.MYIQ_BRAIN_TRAINING) ||
                R.get(o.UTM_PARAMS.MYIQ_BRAIN_TRAINING.toUpperCase());
            (R.get(o.UTM_PARAMS.MYIQ_UTM_REFERRAL_DOMAIN),
              R.get(o.UTM_PARAMS.MYIQ_UTM_SOURCE),
              R.get(o.UTM_PARAMS.MYIQ_UTM_MEDIUM),
              R.get(o.UTM_PARAMS.MYIQ_UTM_CAMPAIGN),
              R.get(o.UTM_PARAMS.MYIQ_UTM_CAMPAIGN_ID),
              R.get(o.UTM_PARAMS.MYIQ_UTM_ADGROUP_ID) || R.get(o.UTM_PARAMS.MYIQ_UTM_ADSET_ID),
              R.get(o.UTM_PARAMS.MYIQ_UTM_AD_ID));
            let U = R.get(o.UTM_PARAMS.MYIQ_UTM_SOURCE_ID);
            return (
              R.get(o.UTM_PARAMS.INITIAL_CURRENT_URL),
              R.get(o.UTM_PARAMS.MYIQ_UTM_USER_TOKEN),
              (0, i.useEffect)(() => {
                (0, A.getIsNativeApp)() &&
                  E.accessSessionStorageUtil.setItem(n.StorageKeys.MARKETING_SOURCE, "true");
                let e = !!U;
                if (
                  (e &&
                    (e
                      ? (N &&
                          (E.accessSessionStorageUtil.setItem(n.StorageKeys.GOOGLE_PARAM, "true"),
                          E.accessSessionStorageUtil.removeItem(n.StorageKeys.TIKTOK_PARAM)),
                        O &&
                          (E.accessSessionStorageUtil.setItem(n.StorageKeys.TIKTOK_PARAM, "true"),
                          E.accessSessionStorageUtil.removeItem(n.StorageKeys.GOOGLE_PARAM)),
                        c() &&
                          (E.accessSessionStorageUtil.setItem(n.StorageKeys.GOOGLE_PARAM, "true"),
                          E.accessSessionStorageUtil.removeItem(n.StorageKeys.TIKTOK_PARAM)),
                        E.accessSessionStorageUtil.setItem(n.StorageKeys.MARKETING_SOURCE, "true"))
                      : E.accessSessionStorageUtil.removeItem(n.StorageKeys.MARKETING_SOURCE)),
                  "1" === U &&
                    E.accessSessionStorageUtil.setItem(n.StorageKeys.PERSONALITY_MARKETING_SOURCE, "true"),
                  c())
                )
                  return E.accessSessionStorageUtil.removeItem(n.StorageKeys.MARKETING_SOURCE);
                let t = I.mixpanelClient.peopleGetProperty("initial_utm_source"),
                  _ = I.mixpanelClient.peopleGetProperty("initial_utm_medium"),
                  i = I.mixpanelClient.peopleGetProperty("initial_utm_campaign"),
                  s = I.mixpanelClient.peopleGetProperty("user_token");
                (L && E.accessSessionStorageUtil.setItem(n.StorageKeys.APPLOVIN_PARAM, "true"),
                  M && l.accessCookie.setItem(a.ECookieArg.BRAIN_TRAINING_PARAM, "true"),
                  (t || _ || i || s) &&
                    E.accessSessionStorageUtil.setItem(n.StorageKeys.MARKETING_SOURCE, "true"));
              }, []),
              (0, i.useEffect)(() => {
                let e = !!U;
                e &&
                  C &&
                  !C?.isMarketingUser &&
                  !T.current &&
                  ((T.current = !0), S({ user: { isMarketingUser: !!e } }));
              }, [C?.id, C?.isMarketingUser]),
              null
            );
          },
        ],
        341302,
      ));
  },
  330021,
  (e) => {
    "use strict";
    (e.i(932880), e.i(389634), e.s([]));
  },
  389634,
  (e) => {
    "use strict";
    var t = e.i(271645);
    e.i(470366);
    var _ = e.i(504001);
    e.s([
      "default",
      0,
      (e) => {
        let { user: i, event: s, params: n } = e;
        return (
          (0, t.useEffect)(() => {
            i && (0, _.trackClientEvents)({ event: s, user: i, params: { ...n } });
          }, []),
          null
        );
      },
    ]);
  },
  299649,
  605766,
  (e) => {
    "use strict";
    var t = e.i(843476);
    (e.s([], 299649),
      e.s(
        [
          "ContainerComponent",
          0,
          (e) => {
            let { children: _, className: i, variant: s = "main" } = e;
            return (0, t.jsxs)(t.Fragment, {
              children: [
                "full" === s && (0, t.jsx)("main", { className: `mx-auto w-full pt-16 ${i}`, children: _ }),
                "main" === s &&
                  (0, t.jsx)("main", {
                    className: `mx-auto w-full max-w-7xl pt-16 max-[1320px]:px-6 max-md:px-4 ${i}`,
                    children: _,
                  }),
                "header" === s &&
                  (0, t.jsx)("header", {
                    "data-app-header": !0,
                    className: `w-full bg-background/70 backdrop-blur-lg backdrop-saturate-150 ${i}`,
                    children: _,
                  }),
                "footer" === s &&
                  (0, t.jsx)("footer", { "data-app-footer": !0, className: `w-full ${i}`, children: _ }),
              ],
            });
          },
        ],
        605766,
      ));
  },
  710896,
  127365,
  (e) => {
    "use strict";
    var t = e.i(843476),
      _ = e.i(663615);
    e.i(707301);
    var i = e.i(857747),
      i = i;
    (e.s([], 710896),
      e.s(
        [
          "ControlArrow",
          0,
          (e) => {
            let {
              isDisabled: s,
              customClass: n,
              variant: o,
              width: E = 24,
              height: a = 24,
              onClick: A,
              isAbsolute: r,
              isRTL: l,
            } = e;
            return (0, t.jsx)("div", {
              className: `group focus:outline-none ${"next" === o ? "rotate-180" : ""} w-[${E.toString()}px] h-[${a.toString()}px] ${r ? "absolute" : ""} ${!s && "hover:cursor-pointer"} ${n}`,
              onClick: () => !s && A(),
              children: (0, t.jsx)(i.default, {
                alt: "back-icon",
                className: (0, _.cn)(
                  "flex-shrink-0 focus:outline-none",
                  s ? "opacity-50" : "sm:group-hover:text-gray-700",
                  "backgreen" === o ? "text-green-custom" : "text-dark-custom",
                  "gray" === o && "text-gray-500",
                  l && "rotate-180",
                ),
                height: a,
                width: E,
              }),
            });
          },
        ],
        127365,
      ));
  },
  59857,
  (e) => {
    "use strict";
    e.s([
      "hasValidMarketingParams",
      0,
      (e) =>
        !!e &&
        ["cid", "i", "t", "email", "ff", "r", "funnel", "quiz_answers", "rt"].some((t) => {
          let _ = e[t];
          return _ && "" !== _.toString().trim();
        }),
    ]);
  },
  705992,
  (e) => {
    "use strict";
    var t = e.i(770703);
    (0, t.default)(() => e.A(400639), { loadableGenerated: { modules: [542156] } });
    let _ = (0, t.default)(() => e.A(151820), { loadableGenerated: { modules: [808245] } });
    e.s(["FooterNewComponent", 0, _]);
  },
  624879,
  945931,
  329699,
  197525,
  (e) => {
    "use strict";
    var t = e.i(843476),
      _ = e.i(770703),
      i = e.i(861745),
      s = e.i(271645),
      n = e.i(663615);
    e.i(608970);
    var o = e.i(372546),
      E = e.i(231627);
    e.i(910661);
    var a = e.i(642871),
      A = e.i(86596),
      r = e.i(134404);
    let l = [
      r.EClientRoutes.START,
      r.EClientRoutes.QUIZ,
      r.EClientRoutes.QUIZ_ANALYZING,
      r.EClientRoutes.EMAIL,
      r.EClientRoutes.CHECKOUT,
      r.EClientRoutes.INTRODUCTION,
      r.EClientRoutes.START_ATTACHMENT,
      r.EClientRoutes.START_LOVE,
      r.EClientRoutes.QUIZ_LOVE,
      r.EClientRoutes.QUIZ_ANALYZING_LOVE,
      r.EClientRoutes.START_PERSONALITY,
      r.EClientRoutes.QUIZ_PERSONALITY,
      r.EClientRoutes.QUIZ_ANALYZING_PERSONALITY,
      r.EClientRoutes.EMAIL_PERSONALITY,
      r.EClientRoutes.START_CAREERS,
      r.EClientRoutes.QUIZ_CAREERS,
      r.EClientRoutes.QUIZ_ATTACHMENT,
      r.EClientRoutes.QUIZ_ANALYZING_CAREERS,
      r.EClientRoutes.START_DEPRESSION,
      r.EClientRoutes.QUIZ_DEPRESSION,
      r.EClientRoutes.QUIZ_ANALYZING_DEPRESSION,
      r.EClientRoutes.START_WORK,
      r.EClientRoutes.QUIZ_WORK,
      r.EClientRoutes.QUIZ_ANALYZING_WORK,
      r.EClientRoutes.START_BURNOUT,
      r.EClientRoutes.QUIZ_BURNOUT,
      r.EClientRoutes.QUIZ_ANALYZING_BURNOUT,
      r.EClientRoutes.START_EMOTIONAL,
      r.EClientRoutes.QUIZ_EMOTIONAL,
      r.EClientRoutes.QUIZ_ANALYZING_EMOTIONAL,
      r.EClientRoutes.CORRECT_EMAIL,
      r.EClientRoutes.CERTIFICATE,
    ];
    e.i(299649);
    var I = e.i(605766);
    e.i(710896);
    var u = e.i(127365);
    e.i(570908);
    var R = e.i(871290),
      T = e.i(263970),
      C = e.i(202042),
      S = e.i(19576);
    let c = (0, _.default)(() => e.A(564257).then((e) => e.LogoComponent), {
        loadableGenerated: { modules: [699261] },
      }),
      N = (0, _.default)(() => e.A(472478).then((e) => e.ActionButtonsComponent), {
        loadableGenerated: { modules: [213595] },
      }),
      O = (0, _.default)(() => e.A(597420).then((e) => e.UserEmailComponent), {
        loadableGenerated: { modules: [108176] },
      }),
      L = (0, _.default)(() => e.A(344088).then((e) => e.BurgerBtnComponent), {
        loadableGenerated: { modules: [194025] },
      }),
      M = (0, _.default)(() => e.A(969773).then((e) => e.QuizTimerComponent), {
        loadableGenerated: { modules: [3539] },
      }),
      U = (0, _.default)(() => e.A(969773).then((e) => e.DepressionCountdownTimerComponent), {
        loadableGenerated: { modules: [3539] },
      }),
      P = (0, _.default)(() => e.A(360620).then((e) => e.LangComponent), {
        loadableGenerated: { modules: [464901] },
      });
    (e.s([], 624879),
      e.s(
        [
          "HeaderComponent",
          0,
          (e) => {
            let { isOrganicOrGoogleSource: _ } = e,
              d = (0, C.usePathname)(),
              m = (0, i.useLocale)(),
              Q = (0, A.useUserStore)((e) => e.user),
              Y = (0, T.useGlobalStore)((e) => e.activeFunnel),
              g = (0, T.useGlobalStore)((e) => e.handleChangeGlobalStore),
              p = (0, a.useQuizStore)((e) => e.isShowTestimonials),
              y = (0, a.useQuizStore)((e) => e.isShowMotivation),
              Z = (0, a.useQuizStore)((e) => e.showScienceBased),
              G = (0, a.useQuizStore)((e) => e.isLoadingPageBeforeQuizTest),
              h = (0, a.useQuizStore)((e) => e.quizPaginationTopRightOnly),
              v = (0, a.useQuizStore)((e) => e.quizHeaderQuestionCountVisible),
              B = (0, a.useQuizStore)((e) => e.currentQuestionId),
              f = (0, a.useQuizStore)((e) => e.totalQuestions),
              D = (0, a.useQuizStore)((e) => e.quizTimerFrozen),
              b = (0, E.useSurveyStore)((e) => e.isComplete),
              F = (0, E.useSurveyStore)((e) => e.canGoBack),
              q = (0, E.useSurveyStore)((e) => e.isGuestSurveyCompleted),
              x = (0, E.useSurveyStore)((e) => e.isCheckingCompletion),
              w = (0, E.useSurveyStore)((e) => e.isLoading),
              V = d.replace(`${r.EClientRoutes.SURVEYS}/`, ""),
              k = Q?.survey?.[V] === "completed",
              K = r.EClientRoutes.QUIZ_PERSONALITY !== d || !G,
              H = (0, R.isShowTimerComponent)(d) && !p && !Z && K,
              W = (y || D) && (0, R.isMainIqQuizRouteForTimerPaginationSwap)(d),
              z = "rtl" === (0, S.getLocaleDirection)(m),
              j = h && (0, R.isMainIqQuizRouteForTimerPaginationSwap)(d) && H && !W;
            (0, s.useEffect)(() => {
              let e = (0, R.getActiveFunnel)(d);
              e !== Y && g({ activeFunnel: e });
            }, [d]);
            let $ = (0, R.isShowLangComponent)(d),
              X = (0, t.jsx)(P, {
                userEmail: Q?.email,
                arrowClassName: "!text-inherit",
                className: (0, n.cn)(
                  "h-[40px]! w-fit text-inherit",
                  z ? "mr-auto" : "ml-auto",
                  (0, R.isShowSmallLangText)(d) && "text-xs",
                  (0, R.isLogoCentered)(d) && !j && "col-start-3 row-start-1 justify-self-end",
                ),
                menuClassName: "max-h-[70dvh] overflow-y-auto",
                preserveSearchParams: (0, R.isStartRoute)(d),
                compact: !0,
              });
            return (0, t.jsx)(t.Fragment, {
              children: (0, t.jsx)(I.ContainerComponent, {
                variant: "header",
                className: `${(0, R.isSpecialQuiz)(d) ? "hidden" : "border-b-1 shadow-small"} ${(0, R.isHeaderHaveDiffColor)(d) ? "!bg-zinc-100" : ""} ${(0, o.isStaticHeader)(d) ? "relative" : "fixed z-50"}`,
                children: (0, t.jsxs)("div", {
                  id: "header",
                  style: { maxWidth: (0, R.getHeaderMaxWidth)(d) },
                  className: (0, n.cn)(
                    "relative mx-auto items-center gap-1 max-md:px-4",
                    "h-16",
                    j
                      ? "grid grid-cols-3"
                      : (0, R.isLogoCentered)(d)
                        ? "grid grid-cols-[1fr_auto_1fr]"
                        : "grid grid-cols-[1fr_auto] sm:grid-cols-2",
                    "980px" !== (0, R.getHeaderMaxWidth)(d) ? "max-[1328px]:px-6" : "max-[1004px]:px-6",
                    d.includes(r.EClientRoutes.SURVEYS) && "mx-auto flex w-full items-center justify-between",
                  ),
                  children: [
                    d.includes(r.EClientRoutes.SURVEYS) &&
                      (0, t.jsx)(u.ControlArrow, {
                        height: 24,
                        isDisabled: !F,
                        variant: "backgreen",
                        width: 24,
                        onClick: () => {
                          let {
                              currentQuestionIdx: e,
                              questions: t,
                              currentAnswers: _,
                              handleChangeSurveyStore: i,
                            } = E.useSurveyStore.getState(),
                            s = Math.max(0, e - 1),
                            n = t[s],
                            o = !!n && (!n.isRequired || !!_[n.questionId]);
                          i({
                            currentQuestionIdx: s,
                            canGoBack: s > 0,
                            canGoNext: s < t.length && o,
                            progress: t.length > 0 ? ((s + 1) / t.length) * 100 : 0,
                          });
                        },
                        customClass: b || k || q || x || w || !F ? "invisible" : "",
                      }),
                    (0, t.jsx)(t.Fragment, {
                      children: (0, t.jsx)(c, {
                        isClickable:
                          !l?.includes(d) ||
                          (!!_ && !d.startsWith(r.EClientRoutes.DEPRESSION_RESULT_SHARE + "/")),
                        href: r.EClientRoutes.BASE,
                        className: (0, n.cn)(
                          (j || (0, R.isLogoCentered)(d)) && "col-start-2 row-start-1 justify-self-center",
                        ),
                      }),
                    }),
                    d.includes(r.EClientRoutes.SURVEYS) && (0, t.jsx)("div", { className: "h-6 w-6" }),
                    (0, R.isShowActionButtons)(d) && (0, t.jsx)(N, { name: "header-btn", user: Q || null }),
                    (0, R.isShowUserEmail)(d) && (0, t.jsx)(O, {}),
                    (0, R.isShowBurgerBtn)(d) &&
                      (0, t.jsx)(L, { className: "place-self-end self-center lg:hidden" }),
                    H &&
                      !W &&
                      (0, t.jsx)("div", {
                        className: (0, n.cn)(
                          "flex items-center gap-3",
                          j
                            ? "col-start-1 row-start-1 mx-0 justify-self-start"
                            : (0, n.cn)("justify-self-end", z ? "mr-auto" : "ml-auto"),
                        ),
                        children:
                          d === r.EClientRoutes.QUIZ_DEPRESSION_FUNNEL
                            ? (0, t.jsx)(U, {})
                            : (0, t.jsx)(M, {
                                baseClassName: j ? "!bg-transparent !min-w-0 !px-0 border-0" : void 0,
                                iconClassName: j ? "!h-3.5 !w-3.5 mr-[5px] text-gray-500" : void 0,
                                timerClassName: j ? "text-xs text-gray-500" : void 0,
                              }),
                      }),
                    j && (v || $)
                      ? (0, t.jsxs)("div", {
                          className: "col-start-3 row-start-1 flex items-center gap-2 justify-self-end",
                          children: [
                            v &&
                              (0, t.jsxs)("span", {
                                className: "text-xs font-semibold text-gray-500",
                                children: [B ?? 1, "/", f],
                              }),
                            $ && X,
                          ],
                        })
                      : $ && !j && X,
                  ],
                }),
              }),
            });
          },
        ],
        945931,
      ));
    var d = e.i(88653),
      m = e.i(846932),
      Q = e.i(948148),
      Y = e.i(335889),
      g = e.i(714060);
    let p = { opened: { x: "0", opacity: 1 }, closed: { x: "100vw", opacity: 0 } };
    var y = e.i(523173);
    e.i(756503);
    var Z = e.i(542516);
    e.i(470366);
    var G = e.i(504001);
    (e.s([], 329699),
      e.s(
        [
          "MobileMenuComponent",
          0,
          (e) => {
            let _,
              { sessionId: i } = e,
              n = (0, C.usePathname)(),
              o = (0, C.useRouter)(),
              E = (0, Q.useTranslations)(),
              a = [
                { title: (_ = (0, Q.useTranslations)())("nav_how_it_works"), href: "how-it-works" },
                { title: _("main_page_available_test"), href: "available-tests" },
                { title: _("main_page_explore_plans_title"), href: "explore-plans" },
                { title: _("reviews_page_faq_title_short"), href: "faq" },
                { title: _("nav_help_support"), href: r.EClientRoutes.HELP },
              ],
              A = (0, T.useGlobalStore)((e) => e.isMobileMenuVisible),
              l = (0, T.useGlobalStore)((e) => e.handleChangeGlobalStore),
              I = () => {
                l({ isMobileMenuVisible: !1 });
              };
            return (
              (0, s.useEffect)(() => {
                A ? (document.body.style.overflow = "hidden") : (document.body.style.overflow = "visible");
              }, [A]),
              (0, t.jsx)(d.AnimatePresence, {
                children:
                  A &&
                  (0, t.jsxs)(m.motion.div, {
                    className:
                      "fixed z-[49] h-full w-full overflow-y-auto border-l-1 border-[hsl(var(--heroui-divider)/0.1)] bg-white px-6 pb-6 pt-16 md:right-0 md:w-[384px]",
                    variants: p,
                    initial: "closed",
                    animate: "opened",
                    exit: "closed",
                    transition: { duration: 0.5, ease: [0.74, 0, 0.19, 1.02] },
                    children: [
                      !(0, R.isPolicyPage)(n) &&
                        (0, t.jsxs)(t.Fragment, {
                          children: [
                            (0, t.jsx)("nav", {
                              className: "grid gap-2 pb-6 pt-3",
                              children: a?.map((e) =>
                                (0, t.jsx)(
                                  "div",
                                  {
                                    role: "a",
                                    className:
                                      "block rounded-lg py-2 text-base leading-7 text-gray-500 hover:bg-gray-50",
                                    onClick: (t) => {
                                      var _;
                                      return (
                                        (_ = e.href),
                                        void (t.preventDefault(),
                                        _ === r.EClientRoutes.HELP && o.push(r.EClientRoutes.HELP),
                                        n !== r.EClientRoutes.BASE
                                          ? o.push(`${r.EClientRoutes.BASE}#${_}`)
                                          : document
                                              ?.getElementById(_)
                                              ?.scrollIntoView({ behavior: "smooth" }),
                                        I())
                                      );
                                    },
                                    children: e.title,
                                  },
                                  e.href,
                                ),
                              ),
                            }),
                            (0, t.jsx)(g.Divider, { className: "bg-[hsl(var(--heroui-divider)/0.1)]" }),
                          ],
                        }),
                      (0, t.jsxs)("div", {
                        className: "mt-6 grid gap-4",
                        children: [
                          (0, t.jsx)(Y.Button, {
                            as: C.Link,
                            href: r.EClientRoutes.SIGN_IN,
                            prefetch: !0,
                            onPress: () => {
                              ((0, G.trackClientEvents)({
                                event: y.EAnalyticEvents.PAGE_CLICKED,
                                params: { page_name: "loginButtonClicked" },
                                sessionId: i,
                              }),
                                I());
                            },
                            className:
                              "hover:opacity-1 h-[60px] w-full gap-3 border-green-custom text-lg text-green-custom hover:bg-green-custom hover:text-white",
                            size: "lg",
                            radius: "sm",
                            variant: "bordered",
                            children: E("btn_login"),
                          }),
                          !Z.envClient.NEXT_PUBLIC_QUIZ_DISABLED &&
                            (0, t.jsx)(Y.Button, {
                              href: r.EClientRoutes.START,
                              as: C.Link,
                              prefetch: !0,
                              onPress: () => {
                                ((0, G.trackClientEvents)({
                                  event: y.EAnalyticEvents.PAGE_CLICKED,
                                  params: {
                                    page_name: "startCertifiedTestButtonClicked",
                                    page_title: "Start",
                                  },
                                  sessionId: i,
                                }),
                                  I());
                              },
                              className:
                                "h-[60px] w-full gap-3 border-green-custom bg-green-custom text-lg text-white",
                              size: "lg",
                              radius: "sm",
                              variant: "shadow",
                              children: E("btn_start_test"),
                            }),
                        ],
                      }),
                    ],
                  }),
              })
            );
          },
        ],
        197525,
      ));
  },
  570908,
  (e) => {
    "use strict";
    (e.i(871290), e.s([]));
  },
  133467,
  303513,
  (e) => {
    "use strict";
    var t = e.i(935493);
    (e.s([], 133467), e.s(["StatusBarComponent", () => t.default], 303513));
  },
  49587,
  302433,
  (e) => {
    "use strict";
    var t = e.i(117595),
      _ = e.i(866897),
      i = e.i(134404);
    let s = [
        i.EClientRoutes.QUIZ,
        i.EClientRoutes.QUIZ_ANALYZING,
        i.EClientRoutes.EMAIL,
        i.EClientRoutes.CHECKOUT,
      ],
      n = (e) => "true" !== e;
    (e.s(
      [
        "REDESIGN_FUNNEL_PROPERTY",
        0,
        "redesign_funnel",
        "isRedesignFunnelPage",
        0,
        (e) => s.includes(e),
        "isRedesignFunnelRequest",
        0,
        n,
      ],
      302433,
    ),
      e.s(["getIsRedesignFunnel", 0, () => n(t.default.get(_.ECookieArg.LEGACY_FUNNEL))], 49587));
  },
  263970,
  (e) => {
    "use strict";
    var t = e.i(768834),
      _ = e.i(579473);
    e.i(756503);
    var i = e.i(542516);
    let s = (0, t.create)()(
      (0, _.devtools)(
        (e, t) => ({
          isMobileMenuVisible: !1,
          isFooterBannerVisible: !1,
          activeFunnel: null,
          checkoutTimerMins: 6,
          checkoutTimerSeconds: 59,
          checkoutTimerExpired: !1,
          checkoutTimerReady: !1,
          isTimerOverlappingMainButton: !1,
          isAutoScrolling: !1,
          isPaymentFormExpanded: !1,
          isPaymentFormLostVisibility: !1,
          isPaymentFormOpened: !1,
          checkoutReachedLastBullet: !1,
          checkoutScrolledPastLastBullet: !1,
          handleChangeGlobalStore: (t) => e((e) => ({ ...e, ...t })),
          updateCheckoutTimer: () => {
            let { checkoutTimerMins: _, checkoutTimerSeconds: i, checkoutTimerExpired: s } = t();
            s ||
              (0 === i
                ? _ > 0
                  ? e({ checkoutTimerMins: _ - 1, checkoutTimerSeconds: 59 * !!_ })
                  : e({ checkoutTimerMins: 1, checkoutTimerSeconds: 0 })
                : e({ checkoutTimerSeconds: i - 1 }));
          },
          initCheckoutTimer: (t) => {
            e({
              checkoutTimerMins: Math.floor(t / 60),
              checkoutTimerSeconds: t % 60,
              checkoutTimerExpired: !1,
              checkoutTimerReady: !0,
            });
          },
          expireCheckoutTimer: () =>
            e({
              checkoutTimerExpired: !0,
              checkoutTimerMins: 0,
              checkoutTimerSeconds: 0,
              checkoutTimerReady: !0,
            }),
          setAutoScrolling: function (t) {
            let _ = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1e3;
            (e({ isAutoScrolling: t }),
              t &&
                setTimeout(() => {
                  e({ isAutoScrolling: !1 });
                }, _));
          },
        }),
        { enabled: "production" !== i.envClient.NEXT_PUBLIC_NODE_ENV },
      ),
    );
    e.s(["useGlobalStore", 0, s]);
  },
  910661,
  642871,
  (e) => {
    "use strict";
    var t = e.i(768834),
      _ = e.i(579473);
    e.i(756503);
    var i = e.i(542516);
    let s = {
        userScore: null,
        spentTime: 0,
        secondsPassed: 0,
        isQuizFinished: !1,
        sectionsResult: null,
        percentScoreResult: null,
        accuracyResult: null,
        isShowTestimonials: !1,
        showScienceBased: !1,
        isLoadingPageBeforeQuizTest: !0,
        timerResetKey: 0,
        currentQuestionIndex: 1,
        totalQuestions: 31,
        motivationalPercentages: null,
        userAnswers: null,
        additionalAnswers: null,
        questionTimes: null,
        currentQuestionId: null,
        showResultButton: !1,
        isShowMotivation: !1,
        quizHeaderQuestionCountVisible: !1,
        quizPaginationTopRightOnly: !1,
        quizTimerFrozen: !1,
      },
      n = (0, t.create)()(
        (0, _.persist)(
          (0, _.devtools)(
            (e) => ({
              ...s,
              handleChangeQuizStore: (t) => e((e) => ({ ...e, ...t })),
              resetQuizStore: () => e(s),
            }),
            { enabled: "production" !== i.envClient.NEXT_PUBLIC_NODE_ENV },
          ),
          {
            name: "quiz",
            version: 1,
            partialize: (e) => ({
              secondsPassed: e.secondsPassed,
              timerResetKey: e.timerResetKey,
              currentQuestionIndex: e.currentQuestionIndex,
              totalQuestions: e.totalQuestions,
              isQuizFinished: e.isQuizFinished,
              accuracyResult: e.accuracyResult,
              userAnswers: e.userAnswers,
              additionalAnswers: e.additionalAnswers,
              questionTimes: e.questionTimes,
              currentQuestionId: e.currentQuestionId,
              showResultButton: e.showResultButton,
              isShowMotivation: e.isShowMotivation,
            }),
          },
        ),
      );
    (e.s(
      [
        "fullResetQuizStore",
        0,
        () => {
          n.getState().resetQuizStore();
        },
        "useQuizStore",
        0,
        n,
      ],
      642871,
    ),
      e.s([], 910661));
  },
  190899,
  (e) => {
    "use strict";
    e.s([
      "accessSessionStorageUtil",
      0,
      {
        getItem: (e) => {
          try {
            return sessionStorage.getItem(e);
          } catch {
            return null;
          }
        },
        setItem: (e, t) => {
          try {
            sessionStorage.setItem(e, t);
          } catch {
            return;
          }
        },
        removeItem: (e) => {
          try {
            sessionStorage.removeItem(e);
          } catch {
            return;
          }
        },
      },
    ]);
  },
  915113,
  (e) => {
    "use strict";
    var t = e.i(117595),
      _ = e.i(190899),
      i = e.i(866897),
      s = e.i(157273);
    let n = new Set([
      "DE",
      "RO",
      "IT",
      "CZ",
      "PL",
      "NL",
      "HU",
      "BE",
      "BG",
      "CH",
      "PT",
      "MT",
      "AT",
      "SE",
      "LT",
      "IS",
      "LU",
      "HR",
      "LV",
      "EE",
      "SK",
      "GR",
      "AE",
      "SA",
    ]);
    e.s([
      "getIsMarketingSource",
      0,
      () => {
        if ("DE" === (t.default.get(i.ECookieArg.COUNTRY) || "US")) return "";
        let e = _.accessSessionStorageUtil.getItem(s.StorageKeys.MARKETING_ID),
          n = _.accessSessionStorageUtil.getItem(s.StorageKeys.MARKETING_SOURCE);
        return e || n || "";
      },
      "getIsMarketingSourceForSpecificCountry",
      0,
      () => {
        let e = t.default.get(i.ECookieArg.COUNTRY) || "US";
        if (!n.has(e)) return "";
        let o = _.accessSessionStorageUtil.getItem(s.StorageKeys.MARKETING_ID),
          E = _.accessSessionStorageUtil.getItem(s.StorageKeys.MARKETING_SOURCE);
        return o || E || "";
      },
      "getIsPersonalityMarketingSource",
      0,
      () => !!_.accessSessionStorageUtil.getItem(s.StorageKeys.PERSONALITY_MARKETING_SOURCE),
    ]);
  },
]);
