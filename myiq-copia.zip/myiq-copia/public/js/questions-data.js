// Questions Data for myIQ Test (40 Questions with progressive difficulty)
window.MYIQ_QUESTIONS = [
  {
    id: 1,
    difficulty: "easy",
    category: "pattern",
    correctAnswer: "D",
    title: "Select the piece that logically fits in the missing space (?).",
    desc: "Sequential rotation of simple geometric forms."
  },
  {
    id: 2,
    difficulty: "easy",
    category: "pattern",
    correctAnswer: "F",
    title: "Identify the pattern to complete the 3x3 matrix.",
    desc: "Color transition from light to dark along the row."
  },
  {
    id: 3,
    difficulty: "easy",
    category: "logic",
    correctAnswer: "B",
    title: "Which shape logically follows the row sequence?",
    desc: "Dot addition rule: +1 dot per column."
  },
  {
    id: 4,
    difficulty: "easy",
    category: "spatial",
    correctAnswer: "E",
    title: "Determine the missing figure in the bottom right corner.",
    desc: "Clockwise 45-degree angle rotation."
  },
  {
    id: 5,
    difficulty: "easy",
    category: "pattern",
    correctAnswer: "F",
    title: "Find the figure that completes the grid symmetry.",
    desc: "Vertical reflection symmetry."
  },
  {
    id: 6,
    difficulty: "easy",
    category: "logic",
    correctAnswer: "A",
    title: "Which element satisfies the row and column logic?",
    desc: "Each row must contain one circle, one square, and one triangle."
  },
  {
    id: 7,
    difficulty: "easy",
    category: "spatial",
    correctAnswer: "F",
    title: "Complete the matrix progression.",
    desc: "Concentric circle expansion."
  },
  {
    id: 8,
    difficulty: "easy",
    category: "pattern",
    correctAnswer: "F",
    title: "Choose the correct option to replace the question mark.",
    desc: "Grid diagonal line shading logic."
  },
  {
    id: 9,
    difficulty: "easy",
    category: "logic",
    correctAnswer: "B",
    title: "Select the option that matches the pattern rule.",
    desc: "Corner arrow position clockwise cycle."
  },
  {
    id: 10,
    difficulty: "easy",
    category: "spatial",
    correctAnswer: "A",
    title: "Which pattern completes the 3x3 layout?",
    desc: "Intersecting line segment displacement."
  },
  {
    id: 11,
    difficulty: "medium",
    category: "logic",
    correctAnswer: "C",
    title: "Determine the shape that fits the matrix arithmetic.",
    desc: "Boolean XOR overlay of horizontal and vertical bars."
  },
  {
    id: 12,
    difficulty: "medium",
    category: "pattern",
    correctAnswer: "A",
    title: "Which piece completes the series?",
    desc: "Hexagonal quadrant fill sequence."
  },
  {
    id: 13,
    difficulty: "medium",
    category: "spatial",
    correctAnswer: "F",
    title: "Find the missing figure.",
    desc: "Dual rotation: outer circle clockwise, inner star counter-clockwise."
  },
  {
    id: 14,
    difficulty: "medium",
    category: "logic",
    correctAnswer: "F",
    title: "Which option satisfies both row and column combinations?",
    desc: "Shape addition: Col 1 combined with Col 2 produces Col 3."
  },
  {
    id: 15,
    difficulty: "medium",
    category: "pattern",
    correctAnswer: "E",
    title: "Complete the abstract reasoning matrix.",
    desc: "Nested shape subtraction rule."
  },
  {
    id: 16,
    difficulty: "medium",
    category: "spatial",
    correctAnswer: "F",
    title: "Choose the correct missing element.",
    desc: "Isometric cube vertex permutation."
  },
  {
    id: 17,
    difficulty: "medium",
    category: "logic",
    correctAnswer: "E",
    title: "What comes next in the 3x3 matrix?",
    desc: "Polygon vertex count progression (3 -> 4 -> 5 -> 6)."
  },
  {
    id: 18,
    difficulty: "medium",
    category: "pattern",
    correctAnswer: "A",
    title: "Identify the missing segment.",
    desc: "Curved arc interference pattern."
  },
  {
    id: 19,
    difficulty: "medium",
    category: "spatial",
    correctAnswer: "E",
    title: "Select the option that logically fits.",
    desc: "3D perspective sphere shading shift."
  },
  {
    id: 20,
    difficulty: "medium",
    category: "logic",
    correctAnswer: "C",
    title: "Complete the logical matrix.",
    desc: "Shape matrix with line weight and dot inversion."
  },
  {
    id: 21,
    difficulty: "medium",
    category: "pattern",
    correctAnswer: "D",
    title: "Find the figure that completes the pattern.",
    desc: "Diagonal cross product symmetry."
  },
  {
    id: 22,
    difficulty: "medium",
    category: "spatial",
    correctAnswer: "A",
    title: "Which tile completes the puzzle?",
    desc: "Multi-layer gear rotation index."
  },
  {
    id: 23,
    difficulty: "medium",
    category: "logic",
    correctAnswer: "A",
    title: "Determine the logical missing piece.",
    desc: "Sudoku-style Latin Square variant with 3 symbols."
  },
  {
    id: 24,
    difficulty: "medium",
    category: "pattern",
    correctAnswer: "D",
    title: "Which figure satisfies the grid transformation?",
    desc: "Rotational shift + color inversion simultaneously."
  },
  {
    id: 25,
    difficulty: "hard",
    category: "spatial",
    correctAnswer: "C",
    title: "Select the correct option to complete the high-difficulty matrix.",
    desc: "Non-linear multi-step matrix displacement."
  },
  {
    id: 26,
    difficulty: "hard",
    category: "logic",
    correctAnswer: "F",
    title: "What is the logical outcome in the missing cell?",
    desc: "Superposition and line cancellation logic."
  },
  {
    id: 27,
    difficulty: "hard",
    category: "pattern",
    correctAnswer: "E",
    title: "Identify the hidden visual transformation rule.",
    desc: "Modular arithmetic applied to polygon angles."
  },
  {
    id: 28,
    difficulty: "hard",
    category: "spatial",
    correctAnswer: "E",
    title: "Which figure belongs in the missing spot?",
    desc: "Hyper-dimensional cube projection rotation."
  },
  {
    id: 29,
    difficulty: "hard",
    category: "logic",
    correctAnswer: "B",
    title: "Complete the abstract reasoning test.",
    desc: "Intersecting vector field magnitude progression."
  },
  {
    id: 30,
    difficulty: "hard",
    category: "pattern",
    correctAnswer: "C",
    title: "Select the piece that completes the complex pattern.",
    desc: "Combinatorial Latin Matrix with phase shift."
  },
  {
    id: 31,
    difficulty: "hard",
    category: "spatial",
    correctAnswer: "D",
    title: "Determine the final cell of the series.",
    desc: "Fractal recursion depth progression."
  },
  {
    id: 32,
    difficulty: "hard",
    category: "logic",
    correctAnswer: "A",
    title: "Choose the option that maintains structural harmony.",
    desc: "Symmetric group permutations under dihedral reflections."
  },
  {
    id: 33,
    difficulty: "hard",
    category: "pattern",
    correctAnswer: "F",
    title: "Find the logical resolution to the matrix puzzle.",
    desc: "Differential line thickness and shading gradient matrix."
  },
  {
    id: 34,
    difficulty: "hard",
    category: "spatial",
    correctAnswer: "B",
    title: "Which shape completes the abstract 3x3 layout?",
    desc: "Harmonic oscillation node intersection count."
  },
  {
    id: 35,
    difficulty: "hard",
    category: "logic",
    correctAnswer: "E",
    title: "Determine the correct answer for the final advanced matrix.",
    desc: "Bipartite graph isomorphism sequence."
  },
  {
    id: 36,
    difficulty: "hard",
    category: "pattern",
    correctAnswer: "C",
    title: "Select the option that satisfies all mathematical rules.",
    desc: "Modular matrix dot distribution modulo 3."
  },
  {
    id: 37,
    difficulty: "hard",
    category: "spatial",
    correctAnswer: "A",
    title: "Complete the 3-axis isometric rotation sequence.",
    desc: "Compound Euler angles visual rotation."
  },
  {
    id: 38,
    difficulty: "hard",
    category: "logic",
    correctAnswer: "D",
    title: "What is the logical solution to this puzzle?",
    desc: "Boolean NAND overlay with directional parity."
  },
  {
    id: 39,
    difficulty: "hard",
    category: "pattern",
    correctAnswer: "B",
    title: "Identify the piece that completes the master grid.",
    desc: "Penrose tiling projection segment."
  },
  {
    id: 40,
    difficulty: "hard",
    category: "logic",
    correctAnswer: "F",
    title: "Final Question: Complete the highest-tier cognitive matrix.",
    desc: "Raven's Advanced Progressive Matrices master synthesis item."
  }
];
