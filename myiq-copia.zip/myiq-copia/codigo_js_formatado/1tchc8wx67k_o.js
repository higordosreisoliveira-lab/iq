(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  563921,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("arrow-right", [
      ["path", { d: "M5 12h14", key: "1ays0h" }],
      ["path", { d: "m12 5 7 7-7 7", key: "xquz4c" }],
    ]);
    e.s(["default", 0, t]);
  },
  972520,
  (e) => {
    "use strict";
    var t = e.i(563921);
    e.s(["ArrowRight", () => t.default]);
  },
  315492,
  (e) => {
    "use strict";
    var t = e.i(843476),
      n = e.i(948148),
      a = e.i(271645),
      l = e.i(742214),
      i = e.i(335889),
      s = e.i(238589),
      r = e.i(250578),
      o = e.i(523173),
      c = e.i(86596);
    e.i(382857);
    var d = e.i(355320),
      u = e.i(622963),
      m = e.i(504001),
      p = e.i(998198);
    e.i(324778);
    var _ = e.i(870899);
    let g = (e) => {
      let {
          onAccept: d,
          onDecline: g,
          downgradeVariation: x,
          currentPlanMonthlyAmountCents: h,
          currentPlanPriceCurrency: f,
          periodLabel: b,
          downgradePeriodLabel: v = b,
          isPromoPricePlan: C,
        } = e,
        y = (0, n.useTranslations)(),
        E = (0, u.useModalStore)((e) => e.handleChangeModalStore),
        N = (0, c.useUserStore)((e) => e.user),
        w = (0, s.getDowngradePlan)(x),
        j = (0, s.getDowngradeDiscount)(x),
        [A, L] = (0, a.useState)("offer"),
        [k, S] = (0, a.useState)(!1),
        [I, P] = (0, a.useState)(!1),
        D = k || I,
        { priceForView: O } = (0, p.getPaymentPlanPrice)({ paymentPlan: w, user: N || null }),
        { priceForView: R } = (0, p.getPaymentPlanPrice)({ paymentPlan: w, user: null }),
        F = (0, p.getCurrentPlanPriceForView)({
          user: N || null,
          currentPlanMonthlyAmountCents: h,
          currentPlanPriceCurrency: f,
        }),
        T = (0, p.getCalculatePriceForView)(O, N || null),
        B = { currentPrice: F, downgradePrice: T, currentPeriod: b ?? "" };
      ((0, a.useEffect)(() => {
        (0, m.trackClientEvents)({ event: o.EAnalyticEvents.CANCEL_FLOW_UPGRADE_VIEWED, user: N });
      }, []),
        (0, a.useEffect)(() => {
          "confirmation" === A &&
            (0, m.trackClientEvents)({ event: o.EAnalyticEvents.CANCEL_FLOW_PLAN_CHANGE_VIEWED, user: N });
        }, [A]));
      let U = () => {
          E({ modalComponent: null, isModalVisible: !1 });
        },
        M = async () => {
          (S(!0),
            (0, m.trackClientEvents)({
              event: o.EAnalyticEvents.CANCEL_FLOW_PLAN_CHANGE_CONFIRM_CLICKED,
              user: N,
            }));
          try {
            (await d(), U());
          } finally {
            S(!1);
          }
        },
        W = async () => {
          P(!0);
          try {
            (await g(), U());
          } finally {
            P(!1);
          }
        };
      return (0, t.jsx)(l.ModalContent, {
        className: "!my-0 max-h-[95vh] w-[95%] max-w-md select-none overflow-y-auto rounded-2xl bg-white p-6",
        children: (0, t.jsxs)("div", {
          className: "mx-auto flex h-full w-full flex-col",
          children: [
            "offer" === A &&
              (0, t.jsxs)(t.Fragment, {
                children: [
                  (0, t.jsx)(_.ScreenHeaderComponent, {
                    as: "h2",
                    title: y("cancellation_page_downgrade_offer_title", { discountPercent: j }),
                  }),
                  (0, t.jsxs)("div", {
                    className: "mt-4 flex items-stretch gap-3",
                    children: [
                      (0, t.jsxs)("div", {
                        className:
                          "flex min-w-0 flex-1 flex-col items-center rounded-2xl bg-gray-50 p-4 text-center",
                        children: [
                          (0, t.jsx)("p", {
                            className: "text-rd-body-sm text-gray-500",
                            children: y("cancellation_page_downgrade_current_label"),
                          }),
                          (0, t.jsx)("p", {
                            className: "mt-2 text-rd-num-m tabular-nums text-gray-400 line-through",
                            children: F,
                          }),
                          b &&
                            (0, t.jsxs)("p", {
                              className: "mt-1 text-rd-body-sm text-gray-500",
                              children: ["/", b],
                            }),
                        ],
                      }),
                      (0, t.jsxs)("div", {
                        className:
                          "flex min-w-0 flex-1 flex-col items-center rounded-2xl bg-blue-50 p-4 text-center",
                        children: [
                          (0, t.jsx)("p", {
                            className: "text-rd-body-sm font-semibold text-primary",
                            children: y("cancellation_page_downgrade_new_price_label"),
                          }),
                          (0, t.jsx)("p", {
                            className: "mt-2 text-rd-num-m tabular-nums text-primary",
                            children: T,
                          }),
                          v &&
                            (0, t.jsxs)("p", {
                              className: "mt-1 text-rd-body-sm text-gray-500",
                              children: ["/", v],
                            }),
                        ],
                      }),
                    ],
                  }),
                  (0, t.jsx)("p", {
                    className: "mt-8 text-center text-rd-body text-gray-600",
                    children: y(
                      C
                        ? "cancellation_page_cheaper_offer_disclaimer_promo"
                        : "cancellation_page_cheaper_offer_disclaimer",
                      B,
                    ),
                  }),
                  (0, t.jsxs)("div", {
                    className: "mt-8 flex flex-col gap-3",
                    children: [
                      (0, t.jsx)(i.Button, {
                        isDisabled: D,
                        onPress: () => {
                          ((0, m.trackClientEvents)({
                            event: o.EAnalyticEvents.CANCEL_FLOW_UPGRADE_KEEP_CLICKED,
                            user: N,
                            params: { content_value: `Keep ${R}/month plan` },
                          }),
                            L("confirmation"));
                        },
                        className: `h-fit min-h-14 w-full whitespace-pre-wrap ${(0, r.getButtonsColor)("primary")} rounded-xl !text-rd-body font-medium`,
                        variant: "flat",
                        disableRipple: !0,
                        children: y("cancellation_page_cheaper_offer_accept", { downgradePrice: T }),
                      }),
                      (0, t.jsx)(i.Button, {
                        isLoading: I,
                        isDisabled: D,
                        onPress: W,
                        className: `h-fit min-h-14 w-full whitespace-pre-wrap ${(0, r.getButtonsColor)("danger")} rounded-xl !text-rd-body font-medium`,
                        variant: "flat",
                        disableRipple: !0,
                        "data-nr": "continue-cancellation-button",
                        children: y("cancellation_page_cheaper_offer_decline"),
                      }),
                    ],
                  }),
                ],
              }),
            "confirmation" === A &&
              (0, t.jsxs)(t.Fragment, {
                children: [
                  (0, t.jsx)(_.ScreenHeaderComponent, {
                    as: "h2",
                    title: y("cancellation_page_confirm_downgrade_title"),
                    info: y.rich(
                      C
                        ? "cancellation_page_confirm_downgrade_description_promo"
                        : "cancellation_page_confirm_downgrade_description",
                      { ...B, span: (e) => (0, t.jsx)("span", { className: "font-semibold", children: e }) },
                    ),
                  }),
                  (0, t.jsxs)("div", {
                    className: "mt-8 flex flex-col-reverse gap-3",
                    children: [
                      (0, t.jsx)(i.Button, {
                        isDisabled: D,
                        onPress: () => {
                          ((0, m.trackClientEvents)({
                            event: o.EAnalyticEvents.CANCEL_FLOW_PLAN_CHANGE_BACK_CLICKED,
                            user: N,
                          }),
                            L("offer"));
                        },
                        className:
                          "h-fit min-h-14 w-full whitespace-pre-wrap rounded-xl border-green-custom bg-transparent !text-rd-body font-medium text-green-custom [@media(hover:hover)]:hover:bg-green-custom [@media(hover:hover)]:hover:text-white",
                        variant: "bordered",
                        disableRipple: !0,
                        children: y("cancellation_page_confirm_downgrade_cancel"),
                      }),
                      (0, t.jsx)(i.Button, {
                        isLoading: k,
                        isDisabled: D,
                        onPress: M,
                        className: `h-fit min-h-14 w-full whitespace-pre-wrap ${(0, r.getButtonsColor)("primary")} rounded-xl !text-rd-body font-medium`,
                        variant: "flat",
                        disableRipple: !0,
                        children: y("cancellation_page_confirm_downgrade_button"),
                      }),
                    ],
                  }),
                ],
              }),
          ],
        }),
      });
    };
    e.s([
      "default",
      0,
      (e) =>
        e.isRedesign ? (0, t.jsx)(d.DemoCancellationOfferModalComponent, { ...e }) : (0, t.jsx)(g, { ...e }),
    ]);
  },
  195013,
  function (e) {
    e.n(e.i(315492));
  },
  324778,
  870899,
  (e) => {
    "use strict";
    var t = e.i(843476),
      n = e.i(948148),
      a = e.i(926654);
    (e.s([], 324778),
      e.s(
        [
          "ScreenHeaderComponent",
          0,
          (e) => {
            let { title: l, info: i, isLoading: s, as: r = "h1", titleClassName: o = "" } = e,
              c = (0, n.useTranslations)(),
              d = "h2" === r ? "text-rd-h2" : "text-rd-h1",
              u = l || c("upsell_page_are_you_sure");
            return (0, t.jsxs)("div", {
              children: [
                (0, t.jsx)(r, { className: `text-center ${d} text-gray-900 ${o}`, children: u }),
                i
                  ? (0, t.jsx)(a.Skeleton, {
                      isLoaded: !s,
                      className: "mt-4 min-h-6 rounded-lg",
                      children: (0, t.jsx)("p", {
                        className: "text-center text-rd-body text-gray-600 [text-wrap:pretty]",
                        children: i,
                      }),
                    })
                  : null,
              ],
            });
          },
        ],
        870899,
      ));
  },
  238589,
  (e) => {
    "use strict";
    e.s([
      "PROMO_PRICE_PLAN_NAME",
      0,
      "SPLIT_TRIAL_PROMO_PRICE",
      "PROMO_PRICE_SPLIT_CHARGES",
      0,
      2,
      "getDowngradeDiscount",
      0,
      (e) => ("v1_downgrade_upsell_9_99" === e ? "67" : "77"),
      "getDowngradePlan",
      0,
      (e) => ("v1_downgrade_upsell_9_99" === e ? "DOWNGRADE_PRICE_9_99" : "DOWNGRADE_PRICE_6_99"),
    ]);
  },
  250578,
  (e) => {
    "use strict";
    e.s([
      "getButtonsColor",
      0,
      (e) =>
        "ghost" === e
          ? "!bg-[#EFF2FD] text-[#121620]"
          : "danger" === e
            ? "!bg-danger-custom text-white"
            : "!bg-green-custom text-white",
    ]);
  },
  382857,
  732775,
  8077,
  671433,
  639676,
  19186,
  355320,
  (e) => {
    "use strict";
    var t = e.i(843476),
      n = e.i(861745),
      a = e.i(948148),
      l = e.i(271645),
      i = e.i(523173),
      s = e.i(86596);
    e.i(791371);
    var r = e.i(642448);
    e.i(470366);
    var o = e.i(504001),
      c = e.i(202042);
    let d = "w-full !bg-[#CA3F3C] [@media(hover:hover)]:hover:!bg-[#B53835] active:!bg-[#A1322F]",
      u = (e) => {
        let { id: n, title: a, rows: l } = e;
        return (0, t.jsxs)("section", {
          "aria-labelledby": n,
          className: "flex flex-col gap-3",
          children: [
            (0, t.jsx)("h2", {
              id: n,
              className: "text-hp-body font-semibold text-black-custom",
              children: a,
            }),
            (0, t.jsx)("dl", {
              className: "grid grid-cols-2 gap-2 md:gap-3",
              children: l.map((e) =>
                (0, t.jsxs)(
                  "div",
                  {
                    className: "flex min-w-0 flex-col gap-1 rounded-xl bg-blue-50 px-3 py-3 md:px-4",
                    children: [
                      (0, t.jsx)("dt", { className: "text-hp-caption text-grey-light", children: e.term }),
                      (0, t.jsx)("dd", {
                        className: "text-hp-body font-semibold tabular-nums text-black-custom",
                        children: e.definition,
                      }),
                    ],
                  },
                  e.term,
                ),
              ),
            }),
          ],
        });
      },
      m = (e) => {
        let { title: n, info: a } = e;
        return (0, t.jsxs)("div", {
          className: "flex flex-col gap-4 text-center",
          children: [
            (0, t.jsx)("h1", { className: "text-balance text-hp-h1 text-black-custom", children: n }),
            a && (0, t.jsx)("p", { className: "text-hp-body text-grey-deep", children: a }),
          ],
        });
      };
    e.s(
      [
        "default",
        0,
        (e) => {
          let { cardData: p, onCancelClick: _, nextBillingDate: g, renewalAmount: x, periodLabel: h } = e,
            f = (0, a.useTranslations)(),
            b = (0, n.useLocale)(),
            v = (0, s.useUserStore)((e) => e.user),
            [C, y] = (0, l.useState)(!1),
            E = p?.buttons?.find((e) => "link" === e.type),
            N = p?.buttons?.find((e) => "button" === e.type),
            w = async () => {
              ((0, o.trackClientEvents)({
                event: i.EAnalyticEvents.CANCEL_FLOW_ARE_YOU_SURE_CANCEL_CLICKED,
                user: v,
              }),
                y(!0));
              try {
                await _();
              } finally {
                y(!1);
              }
            },
            j = [
              ...(x
                ? [
                    {
                      term: f("subscription_info_modal_price_label"),
                      definition: `${x}/${h || f("subscription_info_modal_period_month")}`,
                    },
                  ]
                : []),
              ...(g ? [{ term: f("subscription_info_modal_billing_label"), definition: g }] : []),
            ];
          return (0, t.jsxs)("div", {
            className: "flex flex-col gap-10",
            children: [
              (0, t.jsx)(m, {
                title: p?.title,
                info: f.rich("cancellation_page_upsell_description", {
                  variable: g || "",
                  span: (e) =>
                    (0, t.jsx)("span", {
                      className: "whitespace-nowrap font-semibold text-black-custom",
                      children: e,
                    }),
                }),
              }),
              (0, t.jsxs)("div", {
                className: "flex flex-col gap-8",
                children: [
                  j.length > 0 &&
                    (0, t.jsx)(u, {
                      id: "cancellation-current-plan",
                      title: f("subscription_info_modal_current_plan_title"),
                      rows: j,
                    }),
                  (0, t.jsxs)("div", {
                    className: "flex flex-col gap-3",
                    children: [
                      N &&
                        (0, t.jsx)(r.DemoButton, {
                          disabled: C,
                          isLoading: C,
                          dataNr: "cancellation-confirmation-cancel-button-v2",
                          onClick: w,
                          size: "lg",
                          variant: "danger",
                          className: d,
                          children: N.text,
                        }),
                      E &&
                        (0, t.jsx)(r.DemoButton, {
                          href: (0, c.getPathname)({ href: E.url || "/", locale: b }),
                          onClick: () => {
                            (0, o.trackClientEvents)({
                              event: i.EAnalyticEvents.CANCEL_FLOW_ARE_YOU_SURE_RETURN_CLICKED,
                              user: v,
                            });
                          },
                          size: "lg",
                          className: "w-full",
                          children: E.text,
                        }),
                    ],
                  }),
                ],
              }),
            ],
          });
        },
      ],
      732775,
    );
    var p = e.i(742214),
      _ = e.i(238589),
      g = e.i(622963),
      x = e.i(998198),
      h = e.i(972520),
      f = e.i(982363);
    let b = (e) => {
        let { t: n, nextBillingDate: a, rawNextBillingDate: l, user: i, userSubscriptionId: s } = e,
          r = (0, f.createSupportMailtoLink)({
            userId: i?.id,
            subscriptionId: s,
            userEmail: i?.email,
            supportEmail: "help@myiq.com",
          });
        return (l ? new Date(l) > new Date() : new Date(a) > new Date())
          ? n.rich("cancellation_page_cancel_msg_description", {
              variable: a,
              emailLink: (e) =>
                (0, t.jsx)(c.Link, { href: r, className: "cursor-pointer text-blue-500", children: e }),
            })
          : n.rich("cancellation_page_non_auth_canceled_description", {
              variable: a,
              emailLink: (e) =>
                (0, t.jsx)(c.Link, { href: r, className: "cursor-pointer text-blue-500", children: e }),
            });
      },
      v = (e) => {
        let { t: n, nextBillingDate: a, downgradePrice: l } = e;
        return n.rich("cancellation_page_downgrade_msg_description", {
          variable: a,
          downgradePrice: l,
          span: (e) => (0, t.jsx)("span", { className: "font-semibold", children: e }),
        });
      };
    (e.s(
      [
        "createCancellationSections",
        0,
        (e) => ({
          priceBlock: {
            id: "upsell-price-block",
            blockType: "priceBlock",
            blockName: "Upsell",
            title: e("cancellation_page_upsell_title"),
            buttons: [
              {
                id: "btn-cancel",
                type: "button",
                text: e("cancellation_page_upsell_button_cancel"),
                style: "danger",
                url: null,
                newWindow: !1,
              },
              {
                id: "btn-return",
                type: "link",
                text: e("cancellation_page_upsell_button_return"),
                style: "primary",
                url: "/profile",
                newWindow: !1,
              },
            ],
          },
          buttonBlocks: {
            cancelMsg: {
              id: "cancel-msg-block",
              blockType: "buttonBlock",
              blockName: "Cancel msg",
              title: e("cancellation_page_cancel_msg_title"),
              buttons: [
                {
                  id: "btn-return-home",
                  type: "link",
                  text: e("cancellation_page_cancel_msg_button"),
                  style: "primary",
                  url: "/profile",
                  newWindow: !1,
                },
              ],
            },
            downgradeMsg: {
              id: "downgrade-msg-block",
              blockType: "buttonBlock",
              blockName: "Downgrade msg",
              title: e("cancellation_page_downgrade_msg_title"),
              buttons: [
                {
                  id: "btn-return-home",
                  type: "link",
                  text: e("cancellation_page_cancel_msg_button"),
                  style: "primary",
                  url: "/profile",
                  newWindow: !1,
                },
              ],
            },
          },
        }),
        "getCurrentDescription",
        0,
        b,
        "getDowngradeDescription",
        0,
        v,
        "getSupportHelpLine",
        0,
        (e) => {
          let { t: n, user: a, userSubscriptionId: l } = e,
            i = (0, f.createSupportMailtoLink)({
              userId: a?.id,
              subscriptionId: l,
              userEmail: a?.email,
              supportEmail: "help@myiq.com",
            });
          return n.rich("delete_account_help_contact", {
            emailLink: (e) =>
              (0, t.jsx)(c.Link, { href: i, className: "cursor-pointer text-blue-500", children: e }),
          });
        },
      ],
      8077,
    ),
      e.s([], 671433));
    let C = (e) => {
      window.open(e, "_blank");
    };
    (e.s(["openInNewTab", 0, C], 639676), e.i(877045));
    var y = e.i(28639);
    (e.s(
      [
        "default",
        0,
        (e) => {
          let {
              currentSection: d,
              nextBillingDate: p,
              rawNextBillingDate: g,
              isCanceled: E = !1,
              surveyUrl: N = "",
              resultType: w = "cancelled",
              downgradeVariation: j,
              serverUser: A,
              userSubscriptionId: L,
            } = e,
            k = (0, a.useTranslations)(),
            S = (0, n.useLocale)(),
            I = "downgraded" === w,
            P = (0, s.useUserStore)((e) => e.user),
            [D, O] = (0, l.useState)(P?.cancellation_survey === "completed");
          (0, l.useEffect)(() => {
            let e = (e) => {
              e.data?.type === "survey-completed" && e.data?.isCancellationSurvey && O(!0);
            };
            return (window.addEventListener("message", e), () => window.removeEventListener("message", e));
          }, []);
          let { priceForView: R } = (0, x.getPaymentPlanPrice)({
              paymentPlan: (0, _.getDowngradePlan)(j),
              user: P || null,
            }),
            F = (0, x.getCalculatePriceForView)(R, P || null),
            T = g ? new Date(g) > new Date() : new Date(p) > new Date(),
            B = (0, f.createSupportMailtoLink)({
              userId: A?.id,
              subscriptionId: L,
              userEmail: A?.email,
              supportEmail: "help@myiq.com",
            }),
            U = T
              ? k.rich("cancellation_page_cancel_msg_description_short", {
                  variable: p,
                  emailLink: (e) =>
                    (0, t.jsx)("a", {
                      href: B,
                      className: "text-blue-custom transition-opacity hover:opacity-80",
                      children: e,
                    }),
                })
              : b({ t: k, nextBillingDate: p, rawNextBillingDate: g, user: A, userSubscriptionId: L }),
            M = d?.buttons?.find((e) => "link" === e.type),
            W = I
              ? [
                  {
                    term: k("cancellation_page_downgrade_new_price_label"),
                    definition: `${F}/${k("subscription_info_modal_period_month")}`,
                  },
                  ...(p ? [{ term: k("subscription_info_modal_billing_label"), definition: p }] : []),
                ]
              : [
                  {
                    term: k("subscription_info_modal_status_label"),
                    definition: k("subscription_info_modal_status_cancelled"),
                  },
                  ...(T && p
                    ? [{ term: k("subscription_info_modal_access_until_label"), definition: p }]
                    : []),
                ];
          return (0, t.jsxs)("div", {
            className: "flex flex-col gap-10",
            "data-nr": "cancellation-result-card-v2",
            children: [
              (0, t.jsx)(m, {
                title: d?.title,
                info: I ? v({ t: k, nextBillingDate: p, downgradePrice: F }) : U,
              }),
              (0, t.jsxs)("div", {
                className: "flex flex-col gap-8",
                children: [
                  (0, t.jsx)(u, {
                    id: "cancellation-details",
                    title: k("subscription_info_modal_title"),
                    rows: W,
                  }),
                  M &&
                    (0, t.jsx)(r.DemoButton, {
                      href: (0, c.getPathname)({ href: M.url || "/", locale: S }),
                      onClick: () => {
                        ((0, o.trackClientEvents)({
                          event: i.EAnalyticEvents.CANCEL_FLOW_CANCELLATION_COMPLETE_RETURN_CLICKED,
                          user: P,
                        }),
                          (0, y.revokeCancellationAccess)());
                      },
                      size: "lg",
                      className: "w-full",
                      children: M.text,
                    }),
                ],
              }),
              E &&
                !!N &&
                !I &&
                !D &&
                (0, t.jsxs)("section", {
                  className: "flex flex-col items-center gap-2 text-center",
                  children: [
                    (0, t.jsx)("h2", {
                      className: "text-hp-body font-semibold text-black-custom",
                      children: k("cancellation_page_help_us_improve_title"),
                    }),
                    (0, t.jsx)("p", {
                      className: "text-hp-body-sm text-grey-deep",
                      children: k("share_your_feedback_description"),
                    }),
                    (0, t.jsxs)("button", {
                      type: "button",
                      onClick: () => {
                        ((0, o.trackClientEvents)({
                          event: i.EAnalyticEvents.CANCEL_FLOW_FEEDBACK_LINK_CLICKED_FOR_CUSTOMER_IO,
                          user: P,
                        }),
                          N && C(N));
                      },
                      className:
                        "inline-flex items-center gap-1 text-hp-body-sm font-medium text-blue-custom underline-offset-4 [@media(hover:hover)]:hover:underline",
                      children: [
                        k("share_your_feedback"),
                        (0, t.jsx)(h.ArrowRight, {
                          "aria-hidden": !0,
                          className: "size-4 shrink-0 rtl:rotate-180",
                        }),
                      ],
                    }),
                  ],
                }),
            ],
          });
        },
      ],
      19186,
    ),
      e.s([], 382857),
      e.s(
        [
          "DemoCancellationOfferModalComponent",
          0,
          (e) => {
            let {
                onAccept: n,
                onDecline: c,
                downgradeVariation: u,
                currentPlanMonthlyAmountCents: m,
                currentPlanPriceCurrency: h,
                periodLabel: f,
              } = e,
              b = (0, a.useTranslations)(),
              v = (0, g.useModalStore)((e) => e.handleChangeModalStore),
              C = (0, s.useUserStore)((e) => e.user),
              y = (0, _.getDowngradePlan)(u),
              E = (0, _.getDowngradeDiscount)(u),
              [N, w] = (0, l.useState)("offer"),
              [j, A] = (0, l.useState)(!1),
              [L, k] = (0, l.useState)(!1),
              S = j || L,
              { priceForView: I } = (0, x.getPaymentPlanPrice)({ paymentPlan: y, user: C || null }),
              { priceForView: P } = (0, x.getPaymentPlanPrice)({ paymentPlan: y, user: null }),
              D = (0, x.getCurrentPlanPriceForView)({
                user: C || null,
                currentPlanMonthlyAmountCents: m,
                currentPlanPriceCurrency: h,
              }),
              O = (0, x.getCalculatePriceForView)(I, C || null),
              R = { currentPrice: D, downgradePrice: O };
            ((0, l.useEffect)(() => {
              (0, o.trackClientEvents)({ event: i.EAnalyticEvents.CANCEL_FLOW_UPGRADE_VIEWED, user: C });
            }, []),
              (0, l.useEffect)(() => {
                "confirmation" === N &&
                  (0, o.trackClientEvents)({
                    event: i.EAnalyticEvents.CANCEL_FLOW_PLAN_CHANGE_VIEWED,
                    user: C,
                  });
              }, [N]));
            let F = () => {
                v({ modalComponent: null, isModalVisible: !1 });
              },
              T = async () => {
                (A(!0),
                  (0, o.trackClientEvents)({
                    event: i.EAnalyticEvents.CANCEL_FLOW_PLAN_CHANGE_CONFIRM_CLICKED,
                    user: C,
                  }));
                try {
                  (await n(), F());
                } finally {
                  A(!1);
                }
              },
              B = async () => {
                k(!0);
                try {
                  (await c(), F());
                } finally {
                  k(!1);
                }
              };
            return (0, t.jsxs)(p.ModalContent, {
              className:
                "!my-0 max-h-[95vh] w-[95%] max-w-[448px] select-none overflow-y-auto rounded-3xl bg-white p-6 md:p-8",
              children: [
                "offer" === N &&
                  (0, t.jsxs)("div", {
                    className: "flex flex-col gap-6",
                    children: [
                      (0, t.jsx)("h2", {
                        className: "text-balance text-center text-hp-h3-lg text-black-custom",
                        children: b("cancellation_page_downgrade_offer_title", { discountPercent: E }),
                      }),
                      (0, t.jsxs)("div", {
                        className: "grid grid-cols-2 gap-3",
                        children: [
                          (0, t.jsxs)("div", {
                            className:
                              "flex min-w-0 flex-col items-center gap-1 rounded-xl bg-slate-100 px-4 py-3 text-center",
                            children: [
                              (0, t.jsx)("span", {
                                className: "text-hp-body-sm text-grey-light",
                                children: b("cancellation_page_downgrade_current_label"),
                              }),
                              (0, t.jsx)("span", {
                                className: "text-hp-h1 tabular-nums text-grey-light line-through",
                                children: D,
                              }),
                              f &&
                                (0, t.jsxs)("span", {
                                  className: "text-hp-caption text-grey-light",
                                  children: ["/", f],
                                }),
                            ],
                          }),
                          (0, t.jsxs)("div", {
                            className:
                              "flex min-w-0 flex-col items-center gap-1 rounded-xl bg-blue-50 px-4 py-3 text-center",
                            children: [
                              (0, t.jsx)("span", {
                                className: "text-hp-body-sm text-grey-light",
                                children: b("cancellation_page_downgrade_new_price_label"),
                              }),
                              (0, t.jsx)("span", {
                                className: "text-hp-h1 tabular-nums text-primary",
                                children: O,
                              }),
                              f &&
                                (0, t.jsxs)("span", {
                                  className: "text-hp-caption text-grey-light",
                                  children: ["/", f],
                                }),
                            ],
                          }),
                        ],
                      }),
                      (0, t.jsxs)("div", {
                        className: "flex flex-col gap-3",
                        children: [
                          (0, t.jsx)(r.DemoButton, {
                            disabled: S,
                            onClick: () => {
                              ((0, o.trackClientEvents)({
                                event: i.EAnalyticEvents.CANCEL_FLOW_UPGRADE_KEEP_CLICKED,
                                user: C,
                                params: { content_value: `Keep ${P}/month plan` },
                              }),
                                w("confirmation"));
                            },
                            size: "lg",
                            className: "w-full",
                            children: b("cancellation_page_cheaper_offer_accept", { downgradePrice: O }),
                          }),
                          (0, t.jsx)(r.DemoButton, {
                            disabled: S,
                            isLoading: L,
                            dataNr: "continue-cancellation-button",
                            onClick: B,
                            size: "lg",
                            variant: "danger",
                            className: d,
                            children: b("cancellation_page_cheaper_offer_decline"),
                          }),
                        ],
                      }),
                      (0, t.jsx)("p", {
                        className: "text-center text-hp-caption text-grey-light",
                        children: b("cancellation_page_cheaper_offer_disclaimer", R),
                      }),
                    ],
                  }),
                "confirmation" === N &&
                  (0, t.jsxs)("div", {
                    className: "flex flex-col gap-6",
                    children: [
                      (0, t.jsxs)("div", {
                        className: "flex flex-col gap-4",
                        children: [
                          (0, t.jsx)("h2", {
                            className: "text-balance text-center text-hp-h3-lg text-black-custom",
                            children: b("cancellation_page_confirm_downgrade_title"),
                          }),
                          (0, t.jsx)("p", {
                            className: "text-center text-hp-body text-grey-deep",
                            children: b.rich("cancellation_page_confirm_downgrade_description", {
                              ...R,
                              span: (e) =>
                                (0, t.jsx)("span", {
                                  className: "font-semibold text-black-custom",
                                  children: e,
                                }),
                            }),
                          }),
                        ],
                      }),
                      (0, t.jsxs)("div", {
                        className: "flex flex-col gap-3",
                        children: [
                          (0, t.jsxs)(r.DemoButton, {
                            disabled: S,
                            onClick: T,
                            size: "lg",
                            className: "w-full",
                            children: [
                              j &&
                                (0, t.jsx)("span", {
                                  "aria-hidden": !0,
                                  className:
                                    "size-4 shrink-0 animate-spin rounded-full border-2 motion-reduce:animate-none border-white/40 border-t-white",
                                }),
                              b("cancellation_page_confirm_downgrade_button"),
                            ],
                          }),
                          (0, t.jsx)(r.DemoButton, {
                            disabled: S,
                            onClick: () => {
                              ((0, o.trackClientEvents)({
                                event: i.EAnalyticEvents.CANCEL_FLOW_PLAN_CHANGE_BACK_CLICKED,
                                user: C,
                              }),
                                w("offer"));
                            },
                            size: "lg",
                            variant: "secondary",
                            className: "w-full !border-green-custom",
                            children: b("cancellation_page_confirm_downgrade_cancel"),
                          }),
                        ],
                      }),
                    ],
                  }),
              ],
            });
          },
        ],
        355320,
      ));
  },
  256889,
  (e) => {
    "use strict";
    e.s([
      "cn",
      0,
      function () {
        for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
        return t.filter(Boolean).join(" ");
      },
    ]);
  },
  791371,
  642448,
  (e) => {
    "use strict";
    var t = e.i(843476);
    e.i(340609);
    var n = e.i(90147),
      a = e.i(256889);
    let l = { sm: "h-9 px-3 text-hp-body-sm", md: "h-11 px-5 text-hp-body-sm", lg: "h-12 px-6 text-hp-body" },
      i = {
        primary:
          "bg-green-custom text-white border-transparent [@media(hover:hover)]:hover:bg-[#0B635C] active:bg-[#094F4A]",
        secondary:
          "bg-white text-green-custom border-green-custom [@media(hover:hover)]:hover:bg-green-custom/[0.06] active:bg-green-custom/[0.10]",
        ghost:
          "bg-transparent text-grey-deep border-transparent [@media(hover:hover)]:hover:bg-black-custom/[0.04] [@media(hover:hover)]:hover:text-black-custom active:bg-black-custom/[0.06]",
        danger:
          "bg-danger-custom text-white border-transparent [@media(hover:hover)]:hover:bg-danger-custom/90 active:bg-danger-custom/80",
      },
      s = (0, t.jsx)(n.Spinner, { size: "sm", color: "current", "aria-hidden": "true" });
    (e.s([], 791371),
      e.s(
        [
          "DemoButton",
          0,
          (e) => {
            let {
                size: n = "md",
                variant: r = "primary",
                href: o,
                type: c,
                disabled: d,
                isLoading: u,
                dataNr: m,
                className: p,
                onClick: _,
                children: g,
              } = e,
              x = (0, a.cn)(
                "inline-flex items-center justify-center gap-2 shrink-0 select-none rounded-full border border-transparent font-medium whitespace-nowrap transition-colors duration-150 ease-[cubic-bezier(0.4,0,0.2,1)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom disabled:cursor-not-allowed disabled:opacity-50 [&_svg]:size-4 [&_svg]:shrink-0",
                l[n],
                i[r],
                p,
              );
            return o
              ? (0, t.jsx)("a", { href: o, className: x, onClick: _, "data-nr": m, children: g })
              : (0, t.jsxs)("button", {
                  type: c ?? "button",
                  disabled: d,
                  className: x,
                  onClick: _,
                  "data-nr": m,
                  "data-loading": u || void 0,
                  children: [u && s, g],
                });
          },
        ],
        642448,
      ));
  },
  877045,
  28639,
  (e) => {
    "use strict";
    var t = e.i(117595),
      n = e.i(866897),
      a = e.i(157273),
      l = e.i(190899);
    let i = () => {
        l.accessSessionStorageUtil.removeItem(a.StorageKeys.CANCELLATION_STORAGE_SESSION);
      },
      s = () => {
        let e = l.accessSessionStorageUtil.getItem(a.StorageKeys.CANCELLATION_STORAGE_SESSION);
        if (!e) return null;
        let t = ((e) => {
          try {
            return JSON.parse(e);
          } catch {
            return null;
          }
        })(e);
        return t?.token && t.expiresAt > Date.now() ? t.token : (i(), null);
      };
    (e.s(
      [
        "getCancellationSessionHeaders",
        0,
        () => {
          let e = s();
          return e ? { "X-Cancellation-Session": e } : {};
        },
        "getCancellationStorageSession",
        0,
        s,
        "grantCancellationAccess",
        0,
        (e) => {
          if (
            (t.default.set(n.ECookieArg.ACCESS_TO_CANCELLATION, "true", { expires: 1 / 24 }),
            (navigator.cookieEnabled && "true" === t.default.get(n.ECookieArg.ACCESS_TO_CANCELLATION)) || !e)
          )
            return;
          let i = { token: e, expiresAt: Date.now() + 33e5 };
          l.accessSessionStorageUtil.setItem(a.StorageKeys.CANCELLATION_STORAGE_SESSION, JSON.stringify(i));
        },
        "revokeCancellationAccess",
        0,
        () => {
          (t.default.remove(n.ECookieArg.ACCESS_TO_CANCELLATION), i());
        },
      ],
      28639,
    ),
      e.s([], 877045));
  },
  982363,
  (e) => {
    "use strict";
    var t = e.i(322062);
    e.s([
      "createSupportMailtoLink",
      0,
      (e) => {
        let {
            userEmail: n,
            userId: a,
            subscriptionId: l,
            supportEmail: i = "help@myiq.com",
            subject: s = "Support Request",
          } = e,
          r = { ...e };
        if (!a || !n || !l) {
          let i = t.useUserSupportContextStore.getState();
          r = {
            ...e,
            userId: a || i.userId || void 0,
            userEmail: n || i.email || void 0,
            subscriptionId: l || i.subscriptionId || void 0,
          };
        }
        let o = ((e) => {
            let { userId: t, subscriptionId: n, userEmail: a } = e,
              l = [];
            return (t && l.push(`User ID: ${t}`),
            n && l.push(`Subscription ID: ${n}`),
            a && l.push(`Email: ${a}`),
            0 === l.length)
              ? ""
              : [
                  "=== Please keep this information for faster support ===",
                  ...l,
                  "====================================================",
                ].join("\n");
          })(r),
          c = encodeURIComponent(s),
          d = encodeURIComponent(o);
        return `mailto:${i}?subject=${c}&body=${d}`;
      },
    ]);
  },
  322062,
  (e) => {
    "use strict";
    var t = e.i(768834),
      n = e.i(579473);
    let a = { email: null, userId: null, subscriptionId: null },
      l = (0, t.create)()(
        (0, n.persist)(
          (e) => ({
            ...a,
            handleChangeUserSupportContext: (t) =>
              e((e) => ({
                email: t.email ?? e.email,
                userId: t.userId ?? e.userId,
                subscriptionId: t.subscriptionId ?? e.subscriptionId,
              })),
            clearUserSupportContext: () => e(a),
          }),
          { name: "user_support_context", version: 1 },
        ),
      );
    e.s(["useUserSupportContextStore", 0, l]);
  },
  340609,
  90147,
  (e) => {
    "use strict";
    var t = e.i(23877);
    (e.s([], 340609), e.s(["Spinner", () => t.default], 90147));
  },
  23877,
  (e) => {
    "use strict";
    var t = e.i(843476),
      n = e.i(112041);
    e.s(["default", 0, (e) => (0, t.jsx)(n.Spinner, { ...e })]);
  },
  190899,
  (e) => {
    "use strict";
    e.s([
      "accessSessionStorageUtil",
      0,
      {
        getItem: (e) => {
          try {
            return sessionStorage.getItem(e);
          } catch {
            return null;
          }
        },
        setItem: (e, t) => {
          try {
            sessionStorage.setItem(e, t);
          } catch {
            return;
          }
        },
        removeItem: (e) => {
          try {
            sessionStorage.removeItem(e);
          } catch {
            return;
          }
        },
      },
    ]);
  },
]);
