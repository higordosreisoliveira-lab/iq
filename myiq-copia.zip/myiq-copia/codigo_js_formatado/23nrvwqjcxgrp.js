(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  872225,
  (e) => {
    "use strict";
    var t = e.i(503259);
    e.s(
      [
        "Autoplay",
        0,
        function (e) {
          let a,
            s,
            i,
            r,
            n,
            l,
            o,
            u,
            d,
            p,
            { swiper: c, extendParams: m, on: y, emit: g, params: v } = e;
          ((c.autoplay = { running: !1, paused: !1, timeLeft: 0 }),
            m({
              autoplay: {
                enabled: !1,
                delay: 3e3,
                waitForTransition: !0,
                disableOnInteraction: !1,
                stopOnLastSlide: !1,
                reverseDirection: !1,
                pauseOnMouseEnter: !1,
              },
            }));
          let w = v && v.autoplay ? v.autoplay.delay : 3e3,
            h = v && v.autoplay ? v.autoplay.delay : 3e3,
            f = new Date().getTime();
          function x(e) {
            !c ||
              c.destroyed ||
              !c.wrapperEl ||
              e.target !== c.wrapperEl ||
              (c.wrapperEl.removeEventListener("transitionend", x),
              p || (e.detail && e.detail.bySwiperTouchMove) || L());
          }
          let b = () => {
              if (c.destroyed || !c.autoplay.running) return;
              c.autoplay.paused ? (r = !0) : r && ((h = i), (r = !1));
              let e = c.autoplay.paused ? i : f + h - new Date().getTime();
              ((c.autoplay.timeLeft = e),
                g("autoplayTimeLeft", e, e / w),
                (s = requestAnimationFrame(() => {
                  b();
                })));
            },
            T = (e) => {
              if (c.destroyed || !c.autoplay.running) return;
              (cancelAnimationFrame(s), b());
              let t = void 0 === e ? c.params.autoplay.delay : e;
              ((w = c.params.autoplay.delay), (h = c.params.autoplay.delay));
              let r = (() => {
                let e;
                if (
                  (e =
                    c.virtual && c.params.virtual.enabled
                      ? c.slides.find((e) => e.classList.contains("swiper-slide-active"))
                      : c.slides[c.activeIndex])
                )
                  return parseInt(e.getAttribute("data-swiper-autoplay"), 10);
              })();
              (!Number.isNaN(r) && r > 0 && void 0 === e && ((t = r), (w = r), (h = r)), (i = t));
              let n = c.params.speed,
                l = () => {
                  c &&
                    !c.destroyed &&
                    (c.params.autoplay.reverseDirection
                      ? !c.isBeginning || c.params.loop || c.params.rewind
                        ? (c.slidePrev(n, !0, !0), g("autoplay"))
                        : c.params.autoplay.stopOnLastSlide ||
                          (c.slideTo(c.slides.length - 1, n, !0, !0), g("autoplay"))
                      : !c.isEnd || c.params.loop || c.params.rewind
                        ? (c.slideNext(n, !0, !0), g("autoplay"))
                        : c.params.autoplay.stopOnLastSlide || (c.slideTo(0, n, !0, !0), g("autoplay")),
                    c.params.cssMode &&
                      ((f = new Date().getTime()),
                      requestAnimationFrame(() => {
                        T();
                      })));
                };
              return (
                t > 0
                  ? (clearTimeout(a),
                    (a = setTimeout(() => {
                      l();
                    }, t)))
                  : requestAnimationFrame(() => {
                      l();
                    }),
                t
              );
            },
            E = () => {
              ((f = new Date().getTime()), (c.autoplay.running = !0), T(), g("autoplayStart"));
            },
            j = () => {
              ((c.autoplay.running = !1), clearTimeout(a), cancelAnimationFrame(s), g("autoplayStop"));
            },
            S = (e, t) => {
              if (c.destroyed || !c.autoplay.running) return;
              (clearTimeout(a), e || (d = !0));
              let s = () => {
                (g("autoplayPause"),
                  c.params.autoplay.waitForTransition
                    ? c.wrapperEl.addEventListener("transitionend", x)
                    : L());
              };
              if (((c.autoplay.paused = !0), t)) {
                (u && (i = c.params.autoplay.delay), (u = !1), s());
                return;
              }
              ((i = (i || c.params.autoplay.delay) - (new Date().getTime() - f)),
                (c.isEnd && i < 0 && !c.params.loop) || (i < 0 && (i = 0), s()));
            },
            L = () => {
              (c.isEnd && i < 0 && !c.params.loop) ||
                c.destroyed ||
                !c.autoplay.running ||
                ((f = new Date().getTime()),
                d ? ((d = !1), T(i)) : T(),
                (c.autoplay.paused = !1),
                g("autoplayResume"));
            },
            _ = () => {
              if (c.destroyed || !c.autoplay.running) return;
              let e = (0, t.g)();
              ("hidden" === e.visibilityState && ((d = !0), S(!0)), "visible" === e.visibilityState && L());
            },
            N = (e) => {
              "mouse" !== e.pointerType || ((d = !0), (p = !0), c.animating || c.autoplay.paused || S(!0));
            },
            O = (e) => {
              "mouse" === e.pointerType && ((p = !1), c.autoplay.paused && L());
            };
          (y("init", () => {
            c.params.autoplay.enabled &&
              (c.params.autoplay.pauseOnMouseEnter &&
                (c.el.addEventListener("pointerenter", N), c.el.addEventListener("pointerleave", O)),
              (0, t.g)().addEventListener("visibilitychange", _),
              E());
          }),
            y("destroy", () => {
              (c.el &&
                "string" != typeof c.el &&
                (c.el.removeEventListener("pointerenter", N), c.el.removeEventListener("pointerleave", O)),
                (0, t.g)().removeEventListener("visibilitychange", _),
                c.autoplay.running && j());
            }),
            y("_freeModeStaticRelease", () => {
              (l || d) && L();
            }),
            y("_freeModeNoMomentumRelease", () => {
              c.params.autoplay.disableOnInteraction ? j() : S(!0, !0);
            }),
            y("beforeTransitionStart", (e, t, a) => {
              !c.destroyed &&
                c.autoplay.running &&
                (a || !c.params.autoplay.disableOnInteraction ? S(!0, !0) : j());
            }),
            y("sliderFirstMove", () => {
              if (!c.destroyed && c.autoplay.running) {
                if (c.params.autoplay.disableOnInteraction) return void j();
                ((n = !0),
                  (l = !1),
                  (d = !1),
                  (o = setTimeout(() => {
                    ((d = !0), (l = !0), S(!0));
                  }, 200)));
              }
            }),
            y("touchEnd", () => {
              if (!c.destroyed && c.autoplay.running && n) {
                if ((clearTimeout(o), clearTimeout(a), c.params.autoplay.disableOnInteraction)) {
                  ((l = !1), (n = !1));
                  return;
                }
                (l && c.params.cssMode && L(), (l = !1), (n = !1));
              }
            }),
            y("slideChange", () => {
              !c.destroyed && c.autoplay.running && (u = !0);
            }),
            Object.assign(c.autoplay, { start: E, stop: j, pause: S, resume: L }));
        },
      ],
      872225,
    );
  },
  671966,
  540779,
  (e) => {
    "use strict";
    var t,
      a = e.i(933818),
      s = e.i(134404),
      i = e.i(81844);
    let r = async (e, t) => {
      try {
        return (
          (await i.httpInstance
            .get(`${s.EApiRoutes.TRUSTPILOT_REVIEWS}?locale=${t}`, {
              signal: e.signal,
              cache: "force-cache",
              next: { revalidate: 3600 },
            })
            .json()) ?? null
        );
      } catch {
        return null;
      }
    };
    var n = (((t = {}).QUERY = "trustpilot_reviews_query"), t);
    (e.s(
      [
        "trustpilotReviewsQueryOptions",
        0,
        (e) =>
          (0, a.queryOptions)({
            queryKey: [n.QUERY, e],
            queryFn: (t) => r(t, e),
            staleTime: 6e5,
            gcTime: 9e5,
          }),
      ],
      540779,
    ),
      e.s([], 671966));
  },
  740623,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(861745),
      s = e.i(948148),
      i = e.i(271645),
      r = e.i(872225),
      n = e.i(980401),
      l = e.i(335889),
      o = e.i(926654),
      u = e.i(266027);
    e.i(671966);
    var d = e.i(540779);
    let p = (0, e.i(770703).default)(() => e.A(835065), { loadableGenerated: { modules: [188600] } });
    e.i(344419);
    var c = e.i(155740);
    let m = () =>
        (0, t.jsx)("svg", {
          width: "26",
          height: "26",
          viewBox: "0 0 24 24",
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg",
          children: (0, t.jsx)("path", {
            d: "M12 1.6l2.7 6.4 6.9.5-5.3 4.5 1.7 6.7L12 16.5 6 19.7l1.7-6.7L2.4 8.5l6.9-.5L12 1.6z",
            fill: "#00b67a",
          }),
        }),
      y = () =>
        (0, t.jsx)("svg", {
          width: "24",
          height: "24",
          viewBox: "0 0 24 24",
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg",
          children: (0, t.jsx)("path", {
            d: "M15 18l-6-6 6-6",
            stroke: "currentColor",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
          }),
        });
    e.s(
      [
        "default",
        0,
        (e) => {
          let g,
            { isClickable: v, whiteCards: w } = e,
            h = (0, s.useTranslations)(),
            f = (0, a.useLocale)(),
            { data: x, isLoading: b } = (0, u.useQuery)((0, d.trustpilotReviewsQueryOptions)(f)),
            [T, E] = (0, i.useState)(null),
            [j, S] = (0, i.useState)(!0),
            [L, _] = (0, i.useState)(!1),
            { reviews: N, stats: O } = x
              ? Array.isArray(x)
                ? { reviews: x, stats: null }
                : { reviews: x.reviews ?? [], stats: x.stats ?? null }
              : { reviews: [], stats: null },
            I =
              (g = N.filter((e) => {
                let t = e.review?.trim().length ?? 0;
                return t >= 20 && t <= 170;
              })).length >= 4
                ? g
                : N,
            R = !b && I.length > 0,
            A = (0, c.useAutoplayInView)(T);
          return (0, t.jsxs)("div", {
            ref: A,
            className:
              "grid w-full grid-cols-[auto_1fr_auto] items-center gap-x-1.5 gap-y-3 sm:gap-x-4 sm:gap-y-5 lg:gap-x-5 lg:gap-y-8",
            dir: "ltr",
            children: [
              (0, t.jsx)(l.Button, {
                onPress: () => T?.slidePrev(),
                "aria-label": "previous button",
                className:
                  "h-9 w-9 min-w-9 rounded-full border border-[#E6E7EB] bg-white text-dark-custom sm:h-12 sm:w-12 sm:min-w-12 [&_svg]:h-5 [&_svg]:w-5 sm:[&_svg]:h-6 sm:[&_svg]:w-6",
                isIconOnly: !0,
                isDisabled: j,
                radius: "full",
                disableRipple: !0,
                children: (0, t.jsx)(y, {}),
              }),
              (0, t.jsx)(n.Swiper, {
                onSwiper: (e) => E(e),
                onSlideChange: (e) => {
                  (S(e.isBeginning), _(e.isEnd));
                },
                direction: "horizontal",
                modules: [r.Autoplay],
                slidesPerView: 1,
                slidesPerGroup: 1,
                spaceBetween: 16,
                breakpoints: { 768: { slidesPerView: 2 }, 1024: { slidesPerView: 3 } },
                loop: !1,
                autoplay: { delay: 4e3, disableOnInteraction: !0 },
                initialSlide: 0,
                className: "!w-full [&_.swiper-wrapper]:!items-stretch",
                speed: 1e3,
                lazyPreloadPrevNext: 3,
                edgeSwipeDetection: "prevent",
                children: R
                  ? I.map((e, a) =>
                      (0, t.jsx)(
                        n.SwiperSlide,
                        {
                          className: "!h-auto",
                          children: (0, t.jsx)(p, { review: e, isClickable: v, whiteCards: w }),
                        },
                        e.id ?? a,
                      ),
                    )
                  : (0, t.jsx)("div", {
                      className:
                        "grid w-full grid-flow-col gap-2 [&>*:nth-child(1)]:block md:[&>*:nth-child(2)]:block lg:[&>*:nth-child(3)]:block [&>div]:hidden",
                      children: [void 0, void 0, void 0].map((e, a) =>
                        (0, t.jsx)(
                          o.Skeleton,
                          {
                            className: "rounded-lg",
                            children: (0, t.jsx)("div", { className: "h-[210px] w-full" }),
                          },
                          a,
                        ),
                      ),
                    }),
              }),
              (0, t.jsx)(l.Button, {
                onPress: () => T?.slideNext(),
                "aria-label": "next button",
                className:
                  "h-9 w-9 min-w-9 rotate-180 rounded-full border border-[#E6E7EB] bg-white text-dark-custom sm:h-12 sm:w-12 sm:min-w-12 [&_svg]:h-5 [&_svg]:w-5 sm:[&_svg]:h-6 sm:[&_svg]:w-6",
                isIconOnly: !0,
                isDisabled: L,
                radius: "full",
                disableRipple: !0,
                children: (0, t.jsx)(y, {}),
              }),
              O
                ? (0, t.jsxs)("div", {
                    className:
                      "col-span-3 flex flex-col items-center gap-3 text-center text-sm text-grey-custom sm:text-sm",
                    children: [
                      (0, t.jsxs)("div", {
                        children: [
                          (0, t.jsxs)("span", {
                            children: [
                              h.rich("trustpilot_rated", {
                                score: O.trustScore.toFixed(1),
                                b: (e) =>
                                  (0, t.jsx)("span", {
                                    className: "font-semibold text-[#191919]",
                                    children: e,
                                  }),
                              }),
                              " ",
                              h.rich("trustpilot_based_on", {
                                count: O.totalReviews.toLocaleString("en-US"),
                                b: (e) =>
                                  v
                                    ? (0, t.jsx)("a", {
                                        href: "https://www.trustpilot.com/review/myiq.com",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: "font-semibold text-[#191919] underline",
                                        children: e,
                                      })
                                    : (0, t.jsx)("span", {
                                        className: "font-semibold text-[#191919]",
                                        children: e,
                                      }),
                              }),
                              ".",
                            ],
                          }),
                          (0, t.jsx)("span", {
                            className: 'before:content-["_"]',
                            children: h("trustpilot_showing_stars"),
                          }),
                        ],
                      }),
                      (0, t.jsxs)("div", {
                        className: "flex items-center gap-1.5",
                        children: [
                          (0, t.jsx)(m, {}),
                          (0, t.jsx)("span", {
                            className: "text-[20px] font-bold text-[#191919] sm:text-[24px]",
                            children: "Trustpilot",
                          }),
                        ],
                      }),
                    ],
                  })
                : null,
            ],
          });
        },
      ],
      740623,
    );
  },
  107874,
  function (e) {
    e.n(e.i(740623));
  },
  835065,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/1pfpkbax7e985.js"].map((t) => e.l(t))).then(() => t(188600)));
  },
  344419,
  155740,
  (e) => {
    "use strict";
    var t = e.i(271645);
    (e.s(
      [
        "useAutoplayInView",
        0,
        (e) => {
          let a = (0, t.useRef)(null),
            s = (0, t.useRef)(!1);
          return (
            (0, t.useEffect)(() => {
              let t = a.current,
                i = e?.autoplay;
              if (!t || !i || "u" < typeof IntersectionObserver) return;
              let r = new IntersectionObserver((e) => {
                let [t] = e;
                if (t.isIntersecting) {
                  if (!s.current) return;
                  ((s.current = !1), i.start());
                  return;
                }
                i.running && ((s.current = !0), i.stop());
              });
              return (r.observe(t), () => r.disconnect());
            }, [e]),
            a
          );
        },
      ],
      155740,
    ),
      e.s([], 344419));
  },
]);
