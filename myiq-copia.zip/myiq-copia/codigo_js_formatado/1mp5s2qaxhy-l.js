(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  882983,
  (e) => {
    "use strict";
    var t = e.i(265840),
      s = e.i(271645),
      a = e.i(273830),
      l = e.i(620253),
      i = e.i(75540),
      n = e.i(843476),
      o = (0, a.forwardRef)((e, a) => {
        let { as: o, children: r, className: c, ...d } = e,
          { slots: u, classNames: m, bodyId: x, setBodyMounted: p } = (0, t.useModalContext)(),
          h = (0, l.useDOMRef)(a);
        return (
          (0, s.useEffect)(() => (p(!0), () => p(!1)), [p]),
          (0, n.jsx)(o || "div", {
            ref: h,
            className: u.body({ class: (0, i.clsx)(null == m ? void 0 : m.body, c) }),
            id: x,
            ...d,
            children: r,
          })
        );
      });
    ((o.displayName = "HeroUI.ModalBody"), e.s(["ModalBody", 0, o], 882983));
  },
  582458,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("triangle-alert", [
      [
        "path",
        { d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3", key: "wmoenq" },
      ],
      ["path", { d: "M12 9v4", key: "juzpu7" }],
      ["path", { d: "M12 17h.01", key: "p32p05" }],
    ]);
    e.s(["default", 0, t]);
  },
  317197,
  231529,
  (e) => {
    "use strict";
    var t = e.i(843476),
      s = e.i(882983),
      a = e.i(742214),
      l = e.i(663615);
    e.i(680460);
    var i = e.i(885944);
    (e.s([], 317197),
      e.s(
        [
          "ModalBodyComponent",
          0,
          (e) => {
            let {
              children: n,
              title: o,
              subtitle: r,
              className: c = "",
              bodyClassName: d,
              titleClassName: u,
            } = e;
            return (0, t.jsx)(a.ModalContent, {
              className: c,
              children: (0, t.jsxs)(s.ModalBody, {
                className: (0, l.cn)(
                  "flex h-full w-full flex-col gap-5 p-5 antialiased md:p-6 [@media(max-height:580px)]:gap-3 [@media(max-height:580px)]:p-4",
                  d,
                ),
                children: [
                  (o || r) &&
                    (0, t.jsx)(i.ModalHeaderComponent, { title: o, subtitle: r, titleClassName: u }),
                  n,
                ],
              }),
            });
          },
        ],
        231529,
      ));
  },
  131495,
  (e) => {
    "use strict";
    var t = e.i(843476),
      s = e.i(582458),
      s = s,
      a = e.i(948148),
      l = e.i(523173);
    e.i(568267);
    var i = e.i(154692);
    e.i(470366);
    var n = e.i(504001);
    e.i(317197);
    var o = e.i(231529);
    (e.s([], 318548),
      e.i(318548),
      e.s(
        [
          "WarningFewerQuestionsModalComponent",
          0,
          (e) => {
            let { handleContinueToUnansweredQuestion: r, user: c } = e,
              d = (0, a.useTranslations)();
            return (0, t.jsxs)(o.ModalBodyComponent, {
              children: [
                (0, t.jsx)("div", {
                  className: "mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-yellow-100",
                  children: (0, t.jsx)(s.default, { className: "h-7 w-7 text-yellow-600" }),
                }),
                (0, t.jsxs)("div", {
                  className: "mb-4 flex flex-col gap-4",
                  children: [
                    (0, t.jsx)("h2", {
                      className: "select-none text-center text-lg font-bold",
                      children: d("assessment_incomplete"),
                    }),
                    (0, t.jsx)("p", {
                      className: "select-none text-center text-base text-gray-600",
                      children: d(
                        "your_responses_were_insufficient_to_calculate_an_accurate_iq_score_please_retake_the_assessment",
                      ),
                    }),
                  ],
                }),
                (0, t.jsx)("div", {
                  className: "flex w-full flex-col gap-2",
                  children: (0, t.jsx)(i.ButtonComponent, {
                    onClick: () => {
                      ((0, n.trackClientEvents)({
                        event: l.EAnalyticEvents.PAGE_CLICKED,
                        params: {
                          page_name: "Quiz",
                          element_name: "YourResultsMayNotBeAccurate",
                          element_clicked: "Continue the Test",
                        },
                        user: c,
                      }),
                        r());
                    },
                    size: "sm",
                    fullWidth: !0,
                    children: d("start_again"),
                  }),
                }),
              ],
            });
          },
        ],
        131495,
      ));
  },
  952331,
  function (e) {
    e.n(e.i(131495));
  },
]);
