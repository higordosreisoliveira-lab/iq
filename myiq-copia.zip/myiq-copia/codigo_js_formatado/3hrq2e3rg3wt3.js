(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  980401,
  503259,
  399946,
  (e) => {
    "use strict";
    let t, i, s;
    var r = e.i(271645);
    function l(e) {
      return null !== e && "object" == typeof e && "constructor" in e && e.constructor === Object;
    }
    function a(e, t) {
      (void 0 === e && (e = {}), void 0 === t && (t = {}));
      let i = ["__proto__", "constructor", "prototype"];
      Object.keys(t)
        .filter((e) => 0 > i.indexOf(e))
        .forEach((i) => {
          void 0 === e[i]
            ? (e[i] = t[i])
            : l(t[i]) && l(e[i]) && Object.keys(t[i]).length > 0 && a(e[i], t[i]);
        });
    }
    let n = {
      body: {},
      addEventListener() {},
      removeEventListener() {},
      activeElement: { blur() {}, nodeName: "" },
      querySelector: () => null,
      querySelectorAll: () => [],
      getElementById: () => null,
      createEvent: () => ({ initEvent() {} }),
      createElement: () => ({
        children: [],
        childNodes: [],
        style: {},
        setAttribute() {},
        getElementsByTagName: () => [],
      }),
      createElementNS: () => ({}),
      importNode: () => null,
      location: {
        hash: "",
        host: "",
        hostname: "",
        href: "",
        origin: "",
        pathname: "",
        protocol: "",
        search: "",
      },
    };
    function o() {
      let e = "u" > typeof document ? document : {};
      return (a(e, n), e);
    }
    let d = {
      document: n,
      navigator: { userAgent: "" },
      location: {
        hash: "",
        host: "",
        hostname: "",
        href: "",
        origin: "",
        pathname: "",
        protocol: "",
        search: "",
      },
      history: { replaceState() {}, pushState() {}, go() {}, back() {} },
      CustomEvent: function () {
        return this;
      },
      addEventListener() {},
      removeEventListener() {},
      getComputedStyle: () => ({ getPropertyValue: () => "" }),
      Image() {},
      Date() {},
      screen: {},
      setTimeout() {},
      clearTimeout() {},
      matchMedia: () => ({}),
      requestAnimationFrame: (e) => ("u" < typeof setTimeout ? (e(), null) : setTimeout(e, 0)),
      cancelAnimationFrame(e) {
        "u" > typeof setTimeout && clearTimeout(e);
      },
    };
    function c() {
      let e = "u" > typeof window ? window : {};
      return (a(e, d), e);
    }
    function p(e) {
      Object.keys(e).forEach((t) => {
        try {
          e[t] = null;
        } catch (e) {}
        try {
          delete e[t];
        } catch (e) {}
      });
    }
    function u(e, t) {
      return (void 0 === t && (t = 0), setTimeout(e, t));
    }
    function h() {
      return Date.now();
    }
    function f(e, t) {
      let i, s, r, l, a;
      void 0 === t && (t = "x");
      let n = c(),
        o =
          ((a = c()).getComputedStyle && (l = a.getComputedStyle(e, null)),
          !l && e.currentStyle && (l = e.currentStyle),
          l || (l = e.style),
          l);
      return (
        n.WebKitCSSMatrix
          ? ((s = o.transform || o.webkitTransform).split(",").length > 6 &&
              (s = s
                .split(", ")
                .map((e) => e.replace(",", "."))
                .join(", ")),
            (r = new n.WebKitCSSMatrix("none" === s ? "" : s)))
          : (i = (r =
              o.MozTransform ||
              o.OTransform ||
              o.MsTransform ||
              o.msTransform ||
              o.transform ||
              o.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,"))
              .toString()
              .split(",")),
        "x" === t && (s = n.WebKitCSSMatrix ? r.m41 : 16 === i.length ? parseFloat(i[12]) : parseFloat(i[4])),
        "y" === t && (s = n.WebKitCSSMatrix ? r.m42 : 16 === i.length ? parseFloat(i[13]) : parseFloat(i[5])),
        s || 0
      );
    }
    function m(e) {
      return (
        "object" == typeof e &&
        null !== e &&
        e.constructor &&
        "Object" === Object.prototype.toString.call(e).slice(8, -1)
      );
    }
    function v() {
      let e = Object(arguments.length <= 0 ? void 0 : arguments[0]),
        t = ["__proto__", "constructor", "prototype"];
      for (let i = 1; i < arguments.length; i += 1) {
        let s = i < 0 || arguments.length <= i ? void 0 : arguments[i];
        if (
          null != s &&
          ("u" > typeof window && void 0 !== window.HTMLElement
            ? !(s instanceof HTMLElement)
            : !s || (1 !== s.nodeType && 11 !== s.nodeType))
        ) {
          let i = Object.keys(Object(s)).filter((e) => 0 > t.indexOf(e));
          for (let t = 0, r = i.length; t < r; t += 1) {
            let r = i[t],
              l = Object.getOwnPropertyDescriptor(s, r);
            void 0 !== l &&
              l.enumerable &&
              (m(e[r]) && m(s[r])
                ? s[r].__swiper__
                  ? (e[r] = s[r])
                  : v(e[r], s[r])
                : !m(e[r]) && m(s[r])
                  ? ((e[r] = {}), s[r].__swiper__ ? (e[r] = s[r]) : v(e[r], s[r]))
                  : (e[r] = s[r]));
          }
        }
      }
      return e;
    }
    function g(e, t, i) {
      e.style.setProperty(t, i);
    }
    function w(e) {
      let t,
        { swiper: i, targetPosition: s, side: r } = e,
        l = c(),
        a = -i.translate,
        n = null,
        o = i.params.speed;
      ((i.wrapperEl.style.scrollSnapType = "none"), l.cancelAnimationFrame(i.cssModeFrameID));
      let d = s > a ? "next" : "prev",
        p = (e, t) => ("next" === d && e >= t) || ("prev" === d && e <= t),
        u = () => {
          ((t = new Date().getTime()), null === n && (n = t));
          let e = a + (0.5 - Math.cos(Math.max(Math.min((t - n) / o, 1), 0) * Math.PI) / 2) * (s - a);
          if ((p(e, s) && (e = s), i.wrapperEl.scrollTo({ [r]: e }), p(e, s))) {
            ((i.wrapperEl.style.overflow = "hidden"),
              (i.wrapperEl.style.scrollSnapType = ""),
              setTimeout(() => {
                ((i.wrapperEl.style.overflow = ""), i.wrapperEl.scrollTo({ [r]: e }));
              }),
              l.cancelAnimationFrame(i.cssModeFrameID));
            return;
          }
          i.cssModeFrameID = l.requestAnimationFrame(u);
        };
      u();
    }
    function S(e, t) {
      void 0 === t && (t = "");
      let i = c(),
        s = [...e.children];
      return (i.HTMLSlotElement && e instanceof HTMLSlotElement && s.push(...e.assignedElements()), t)
        ? s.filter((e) => e.matches(t))
        : s;
    }
    function b(e, t) {
      let i = c(),
        s = t.contains(e);
      return (
        !s &&
          i.HTMLSlotElement &&
          t instanceof HTMLSlotElement &&
          ((s = [...t.assignedElements()].includes(e)) ||
            (s = (function (e, t) {
              let i = [t];
              for (; i.length > 0;) {
                let t = i.shift();
                if (e === t) return !0;
                i.push(
                  ...t.children,
                  ...(t.shadowRoot ? t.shadowRoot.children : []),
                  ...(t.assignedElements ? t.assignedElements() : []),
                );
              }
            })(e, t))),
        s
      );
    }
    function T(e) {
      try {
        console.warn(e);
        return;
      } catch (e) {}
    }
    function y(e, t) {
      var i;
      void 0 === t && (t = []);
      let s = document.createElement(e);
      return (
        s.classList.add(
          ...(Array.isArray(t)
            ? t
            : (void 0 === (i = t) && (i = ""),
              i
                .trim()
                .split(" ")
                .filter((e) => !!e.trim()))),
        ),
        s
      );
    }
    function E(e, t) {
      let i = [];
      for (; e.previousElementSibling;) {
        let s = e.previousElementSibling;
        (t ? s.matches(t) && i.push(s) : i.push(s), (e = s));
      }
      return i;
    }
    function x(e, t) {
      let i = [];
      for (; e.nextElementSibling;) {
        let s = e.nextElementSibling;
        (t ? s.matches(t) && i.push(s) : i.push(s), (e = s));
      }
      return i;
    }
    function M(e, t) {
      return c().getComputedStyle(e, null).getPropertyValue(t);
    }
    function C(e) {
      let t,
        i = e;
      if (i) {
        for (t = 0; null !== (i = i.previousSibling);) 1 === i.nodeType && (t += 1);
        return t;
      }
    }
    function P(e, t) {
      let i = [],
        s = e.parentElement;
      for (; s;) (t ? s.matches(t) && i.push(s) : i.push(s), (s = s.parentElement));
      return i;
    }
    function k(e, t, i) {
      let s = c();
      return i
        ? e["width" === t ? "offsetWidth" : "offsetHeight"] +
            parseFloat(
              s.getComputedStyle(e, null).getPropertyValue("width" === t ? "margin-right" : "margin-top"),
            ) +
            parseFloat(
              s.getComputedStyle(e, null).getPropertyValue("width" === t ? "margin-left" : "margin-bottom"),
            )
        : e.offsetWidth;
    }
    function O(e, t) {
      (void 0 === t && (t = ""),
        "u" > typeof trustedTypes
          ? (e.innerHTML = trustedTypes.createPolicy("html", { createHTML: (e) => e }).createHTML(t))
          : (e.innerHTML = t));
    }
    function _() {
      let e, i;
      return (
        t ||
          ((e = c()),
          (t = {
            smoothScroll:
              (i = o()).documentElement &&
              i.documentElement.style &&
              "scrollBehavior" in i.documentElement.style,
            touch: !!("ontouchstart" in e || (e.DocumentTouch && i instanceof e.DocumentTouch)),
          })),
        t
      );
    }
    function L(e) {
      return (
        void 0 === e && (e = {}),
        i ||
          (i = (function (e) {
            let { userAgent: t } = void 0 === e ? {} : e,
              i = _(),
              s = c(),
              r = s.navigator.platform,
              l = t || s.navigator.userAgent,
              a = { ios: !1, android: !1 },
              n = s.screen.width,
              o = s.screen.height,
              d = l.match(/(Android);?[\s\/]+([\d.]+)?/),
              p = l.match(/(iPad).*OS\s([\d_]+)/),
              u = l.match(/(iPod)(.*OS\s([\d_]+))?/),
              h = !p && l.match(/(iPhone\sOS|iOS)\s([\d_]+)/),
              f = "MacIntel" === r;
            return (
              !p &&
                f &&
                i.touch &&
                [
                  "1024x1366",
                  "1366x1024",
                  "834x1194",
                  "1194x834",
                  "834x1112",
                  "1112x834",
                  "768x1024",
                  "1024x768",
                  "820x1180",
                  "1180x820",
                  "810x1080",
                  "1080x810",
                ].indexOf(`${n}x${o}`) >= 0 &&
                ((p = l.match(/(Version)\/([\d.]+)/)) || (p = [0, 1, "13_0_0"]), (f = !1)),
              d && "Win32" !== r && ((a.os = "android"), (a.android = !0)),
              (p || h || u) && ((a.os = "ios"), (a.ios = !0)),
              a
            );
          })(e)),
        i
      );
    }
    function I() {
      return (
        s ||
          (s = (function () {
            let e = c(),
              t = L(),
              i = !1;
            function s() {
              let t = e.navigator.userAgent.toLowerCase();
              return t.indexOf("safari") >= 0 && 0 > t.indexOf("chrome") && 0 > t.indexOf("android");
            }
            if (s()) {
              let t = String(e.navigator.userAgent);
              if (t.includes("Version/")) {
                let [e, s] = t
                  .split("Version/")[1]
                  .split(" ")[0]
                  .split(".")
                  .map((e) => Number(e));
                i = e < 16 || (16 === e && s < 2);
              }
            }
            let r = /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(e.navigator.userAgent),
              l = s(),
              a = l || (r && t.ios);
            return { isSafari: i || l, needPerspectiveFix: i, need3dFix: a, isWebView: r };
          })()),
        s
      );
    }
    (e.s(["a", 0, c, "g", 0, o], 503259),
      e.s(
        [
          "a",
          0,
          g,
          "b",
          0,
          P,
          "c",
          0,
          y,
          "e",
          0,
          S,
          "f",
          0,
          h,
          "g",
          0,
          function (e) {
            return (
              e.querySelector(".swiper-slide-transform") ||
              (e.shadowRoot && e.shadowRoot.querySelector(".swiper-slide-transform")) ||
              e
            );
          },
          "h",
          0,
          k,
          "i",
          0,
          C,
          "k",
          0,
          f,
          "l",
          0,
          function (e, t) {
            t &&
              e.addEventListener("transitionend", function i(s) {
                s.target === e && (t.call(e, s), e.removeEventListener("transitionend", i));
              });
          },
          "n",
          0,
          u,
          "q",
          0,
          M,
          "r",
          0,
          x,
          "s",
          0,
          O,
          "t",
          0,
          E,
          "u",
          0,
          w,
          "v",
          0,
          T,
          "w",
          0,
          b,
          "x",
          0,
          v,
          "y",
          0,
          p,
        ],
        399946,
      ));
    let A = (e, t, i) => {
        t && !e.classList.contains(i)
          ? e.classList.add(i)
          : !t && e.classList.contains(i) && e.classList.remove(i);
      },
      z = (e, t, i) => {
        t && !e.classList.contains(i)
          ? e.classList.add(i)
          : !t && e.classList.contains(i) && e.classList.remove(i);
      },
      G = (e, t) => {
        if (!e || e.destroyed || !e.params) return;
        let i = t.closest(e.isElement ? "swiper-slide" : `.${e.params.slideClass}`);
        if (i) {
          let t = i.querySelector(`.${e.params.lazyPreloaderClass}`);
          (!t &&
            e.isElement &&
            (i.shadowRoot
              ? (t = i.shadowRoot.querySelector(`.${e.params.lazyPreloaderClass}`))
              : requestAnimationFrame(() => {
                  i.shadowRoot &&
                    (t = i.shadowRoot.querySelector(`.${e.params.lazyPreloaderClass}`)) &&
                    t.remove();
                })),
            t && t.remove());
        }
      },
      D = (e, t) => {
        if (!e.slides[t]) return;
        let i = e.slides[t].querySelector('[loading="lazy"]');
        i && i.removeAttribute("loading");
      },
      N = (e) => {
        if (!e || e.destroyed || !e.params) return;
        let t = e.params.lazyPreloadPrevNext,
          i = e.slides.length;
        if (!i || !t || t < 0) return;
        t = Math.min(t, i);
        let s =
            "auto" === e.params.slidesPerView ? e.slidesPerViewDynamic() : Math.ceil(e.params.slidesPerView),
          r = e.activeIndex;
        if (e.params.grid && e.params.grid.rows > 1) {
          let i = [r - t];
          (i.push(...Array.from({ length: t }).map((e, t) => r + s + t)),
            e.slides.forEach((t, s) => {
              i.includes(t.column) && D(e, s);
            }));
          return;
        }
        let l = r + s - 1;
        if (e.params.rewind || e.params.loop)
          for (let s = r - t; s <= l + t; s += 1) {
            let t = ((s % i) + i) % i;
            (t < r || t > l) && D(e, t);
          }
        else
          for (let s = Math.max(r - t, 0); s <= Math.min(l + t, i - 1); s += 1)
            s !== r && (s > l || s < r) && D(e, s);
      };
    function B(e) {
      let { swiper: t, runCallbacks: i, direction: s, step: r } = e,
        { activeIndex: l, previousIndex: a } = t,
        n = s;
      (n || (n = l > a ? "next" : l < a ? "prev" : "reset"),
        t.emit(`transition${r}`),
        i && "reset" === n
          ? t.emit(`slideResetTransition${r}`)
          : i &&
            l !== a &&
            (t.emit(`slideChangeTransition${r}`),
            "next" === n ? t.emit(`slideNextTransition${r}`) : t.emit(`slidePrevTransition${r}`)));
    }
    function V(e, t, i) {
      let s = c(),
        { params: r } = e,
        l = r.edgeSwipeDetection,
        a = r.edgeSwipeThreshold;
      return !l || (!(i <= a) && !(i >= s.innerWidth - a)) || ("prevent" === l && (t.preventDefault(), !0));
    }
    function $(e) {
      let t = o(),
        i = e;
      i.originalEvent && (i = i.originalEvent);
      let s = this.touchEventsData;
      if ("pointerdown" === i.type) {
        if (null !== s.pointerId && s.pointerId !== i.pointerId) return;
        s.pointerId = i.pointerId;
      } else
        "touchstart" === i.type &&
          1 === i.targetTouches.length &&
          (s.touchId = i.targetTouches[0].identifier);
      if ("touchstart" === i.type) return void V(this, i, i.targetTouches[0].pageX);
      let { params: r, touches: l, enabled: a } = this;
      if (
        !a ||
        (!r.simulateTouch && "mouse" === i.pointerType) ||
        (this.animating && r.preventInteractionOnTransition)
      )
        return;
      !this.animating && r.cssMode && r.loop && this.loopFix();
      let n = i.target;
      if (
        ("wrapper" === r.touchEventsTarget && !b(n, this.wrapperEl)) ||
        ("which" in i && 3 === i.which) ||
        ("button" in i && i.button > 0) ||
        (s.isTouched && s.isMoved)
      )
        return;
      let d = !!r.noSwipingClass && "" !== r.noSwipingClass,
        p = i.composedPath ? i.composedPath() : i.path;
      d && i.target && i.target.shadowRoot && p && (n = p[0]);
      let u = r.noSwipingSelector ? r.noSwipingSelector : `.${r.noSwipingClass}`,
        f = !!(i.target && i.target.shadowRoot);
      if (
        r.noSwiping &&
        (f
          ? (function (e, t) {
              return (
                void 0 === t && (t = this),
                (function t(i) {
                  if (!i || i === o() || i === c()) return null;
                  i.assignedSlot && (i = i.assignedSlot);
                  let s = i.closest(e);
                  return s || i.getRootNode ? s || t(i.getRootNode().host) : null;
                })(t)
              );
            })(u, n)
          : n.closest(u))
      ) {
        this.allowClick = !0;
        return;
      }
      if (r.swipeHandler && !n.closest(r.swipeHandler)) return;
      ((l.currentX = i.pageX), (l.currentY = i.pageY));
      let m = l.currentX,
        v = l.currentY;
      if (!V(this, i, m)) return;
      (Object.assign(s, {
        isTouched: !0,
        isMoved: !1,
        allowTouchCallbacks: !0,
        isScrolling: void 0,
        startMoving: void 0,
      }),
        (l.startX = m),
        (l.startY = v),
        (s.touchStartTime = h()),
        (this.allowClick = !0),
        this.updateSize(),
        (this.swipeDirection = void 0),
        r.threshold > 0 && (s.allowThresholdMove = !1));
      let g = !0;
      (n.matches(s.focusableElements) && ((g = !1), "SELECT" === n.nodeName && (s.isTouched = !1)),
        t.activeElement &&
          t.activeElement.matches(s.focusableElements) &&
          t.activeElement !== n &&
          ("mouse" === i.pointerType || ("mouse" !== i.pointerType && !n.matches(s.focusableElements))) &&
          t.activeElement.blur());
      let w = g && this.allowTouchMove && r.touchStartPreventDefault;
      ((r.touchStartForcePreventDefault || w) && !n.isContentEditable && i.preventDefault(),
        r.freeMode &&
          r.freeMode.enabled &&
          this.freeMode &&
          this.animating &&
          !r.cssMode &&
          this.freeMode.onTouchStart(),
        this.emit("touchStart", i));
    }
    function j(e) {
      let t,
        i,
        s = o(),
        r = this.touchEventsData,
        { params: l, touches: a, rtlTranslate: n, enabled: d } = this;
      if (!d || (!l.simulateTouch && "mouse" === e.pointerType)) return;
      let c = e;
      if (
        (c.originalEvent && (c = c.originalEvent),
        "pointermove" === c.type && (null !== r.touchId || c.pointerId !== r.pointerId))
      )
        return;
      if ("touchmove" === c.type) {
        if (
          !(t = [...c.changedTouches].find((e) => e.identifier === r.touchId)) ||
          t.identifier !== r.touchId
        )
          return;
      } else t = c;
      if (!r.isTouched) {
        r.startMoving && r.isScrolling && this.emit("touchMoveOpposite", c);
        return;
      }
      let p = t.pageX,
        u = t.pageY;
      if (c.preventedByNestedSwiper) {
        ((a.startX = p), (a.startY = u));
        return;
      }
      if (!this.allowTouchMove) {
        (c.target.matches(r.focusableElements) || (this.allowClick = !1),
          r.isTouched &&
            (Object.assign(a, { startX: p, startY: u, currentX: p, currentY: u }), (r.touchStartTime = h())));
        return;
      }
      if (l.touchReleaseOnEdges && !l.loop) {
        if (this.isVertical()) {
          if (
            (u < a.startY && this.translate <= this.maxTranslate()) ||
            (u > a.startY && this.translate >= this.minTranslate())
          ) {
            ((r.isTouched = !1), (r.isMoved = !1));
            return;
          }
        } else if (
          n &&
          ((p > a.startX && -this.translate <= this.maxTranslate()) ||
            (p < a.startX && -this.translate >= this.minTranslate()))
        )
          return;
        else if (
          !n &&
          ((p < a.startX && this.translate <= this.maxTranslate()) ||
            (p > a.startX && this.translate >= this.minTranslate()))
        )
          return;
      }
      if (
        (s.activeElement &&
          s.activeElement.matches(r.focusableElements) &&
          s.activeElement !== c.target &&
          "mouse" !== c.pointerType &&
          s.activeElement.blur(),
        s.activeElement && c.target === s.activeElement && c.target.matches(r.focusableElements))
      ) {
        ((r.isMoved = !0), (this.allowClick = !1));
        return;
      }
      (r.allowTouchCallbacks && this.emit("touchMove", c),
        (a.previousX = a.currentX),
        (a.previousY = a.currentY),
        (a.currentX = p),
        (a.currentY = u));
      let f = a.currentX - a.startX,
        m = a.currentY - a.startY;
      if (this.params.threshold && Math.sqrt(f ** 2 + m ** 2) < this.params.threshold) return;
      if (void 0 === r.isScrolling) {
        let e;
        (this.isHorizontal() && a.currentY === a.startY) || (this.isVertical() && a.currentX === a.startX)
          ? (r.isScrolling = !1)
          : f * f + m * m >= 25 &&
            ((e = (180 * Math.atan2(Math.abs(m), Math.abs(f))) / Math.PI),
            (r.isScrolling = this.isHorizontal() ? e > l.touchAngle : 90 - e > l.touchAngle));
      }
      if (
        (r.isScrolling && this.emit("touchMoveOpposite", c),
        void 0 === r.startMoving &&
          (a.currentX !== a.startX || a.currentY !== a.startY) &&
          (r.startMoving = !0),
        r.isScrolling || ("touchmove" === c.type && r.preventTouchMoveFromPointerMove))
      ) {
        r.isTouched = !1;
        return;
      }
      if (!r.startMoving) return;
      ((this.allowClick = !1),
        !l.cssMode && c.cancelable && c.preventDefault(),
        l.touchMoveStopPropagation && !l.nested && c.stopPropagation());
      let v = this.isHorizontal() ? f : m,
        g = this.isHorizontal() ? a.currentX - a.previousX : a.currentY - a.previousY;
      (l.oneWayMovement && ((v = Math.abs(v) * (n ? 1 : -1)), (g = Math.abs(g) * (n ? 1 : -1))),
        (a.diff = v),
        (v *= l.touchRatio),
        n && ((v = -v), (g = -g)));
      let w = this.touchesDirection;
      ((this.swipeDirection = v > 0 ? "prev" : "next"), (this.touchesDirection = g > 0 ? "prev" : "next"));
      let S = this.params.loop && !l.cssMode,
        b =
          ("next" === this.touchesDirection && this.allowSlideNext) ||
          ("prev" === this.touchesDirection && this.allowSlidePrev);
      if (!r.isMoved) {
        if (
          (S && b && this.loopFix({ direction: this.swipeDirection }),
          (r.startTranslate = this.getTranslate()),
          this.setTransition(0),
          this.animating)
        ) {
          let e = new window.CustomEvent("transitionend", {
            bubbles: !0,
            cancelable: !0,
            detail: { bySwiperTouchMove: !0 },
          });
          this.wrapperEl.dispatchEvent(e);
        }
        ((r.allowMomentumBounce = !1),
          l.grabCursor &&
            (!0 === this.allowSlideNext || !0 === this.allowSlidePrev) &&
            this.setGrabCursor(!0),
          this.emit("sliderFirstMove", c));
      }
      if (
        (new Date().getTime(),
        !1 !== l._loopSwapReset &&
          r.isMoved &&
          r.allowThresholdMove &&
          w !== this.touchesDirection &&
          S &&
          b &&
          Math.abs(v) >= 1)
      ) {
        (Object.assign(a, {
          startX: p,
          startY: u,
          currentX: p,
          currentY: u,
          startTranslate: r.currentTranslate,
        }),
          (r.loopSwapReset = !0),
          (r.startTranslate = r.currentTranslate));
        return;
      }
      (this.emit("sliderMove", c), (r.isMoved = !0), (r.currentTranslate = v + r.startTranslate));
      let T = !0,
        y = l.resistanceRatio;
      if (
        (l.touchReleaseOnEdges && (y = 0),
        v > 0
          ? (S &&
              b &&
              !i &&
              r.allowThresholdMove &&
              r.currentTranslate >
                (l.centeredSlides
                  ? this.minTranslate() -
                    this.slidesSizesGrid[this.activeIndex + 1] -
                    ("auto" !== l.slidesPerView && this.slides.length - l.slidesPerView >= 2
                      ? this.slidesSizesGrid[this.activeIndex + 1] + this.params.spaceBetween
                      : 0) -
                    this.params.spaceBetween
                  : this.minTranslate()) &&
              this.loopFix({ direction: "prev", setTranslate: !0, activeSlideIndex: 0 }),
            r.currentTranslate > this.minTranslate() &&
              ((T = !1),
              l.resistance &&
                (r.currentTranslate =
                  this.minTranslate() - 1 + (-this.minTranslate() + r.startTranslate + v) ** y)))
          : v < 0 &&
            (S &&
              b &&
              !i &&
              r.allowThresholdMove &&
              r.currentTranslate <
                (l.centeredSlides
                  ? this.maxTranslate() +
                    this.slidesSizesGrid[this.slidesSizesGrid.length - 1] +
                    this.params.spaceBetween +
                    ("auto" !== l.slidesPerView && this.slides.length - l.slidesPerView >= 2
                      ? this.slidesSizesGrid[this.slidesSizesGrid.length - 1] + this.params.spaceBetween
                      : 0)
                  : this.maxTranslate()) &&
              this.loopFix({
                direction: "next",
                setTranslate: !0,
                activeSlideIndex:
                  this.slides.length -
                  ("auto" === l.slidesPerView
                    ? this.slidesPerViewDynamic()
                    : Math.ceil(parseFloat(l.slidesPerView, 10))),
              }),
            r.currentTranslate < this.maxTranslate() &&
              ((T = !1),
              l.resistance &&
                (r.currentTranslate =
                  this.maxTranslate() + 1 - (this.maxTranslate() - r.startTranslate - v) ** y))),
        T && (c.preventedByNestedSwiper = !0),
        !this.allowSlideNext &&
          "next" === this.swipeDirection &&
          r.currentTranslate < r.startTranslate &&
          (r.currentTranslate = r.startTranslate),
        !this.allowSlidePrev &&
          "prev" === this.swipeDirection &&
          r.currentTranslate > r.startTranslate &&
          (r.currentTranslate = r.startTranslate),
        this.allowSlidePrev || this.allowSlideNext || (r.currentTranslate = r.startTranslate),
        l.threshold > 0)
      )
        if (Math.abs(v) > l.threshold || r.allowThresholdMove) {
          if (!r.allowThresholdMove) {
            ((r.allowThresholdMove = !0),
              (a.startX = a.currentX),
              (a.startY = a.currentY),
              (r.currentTranslate = r.startTranslate),
              (a.diff = this.isHorizontal() ? a.currentX - a.startX : a.currentY - a.startY));
            return;
          }
        } else {
          r.currentTranslate = r.startTranslate;
          return;
        }
      l.followFinger &&
        !l.cssMode &&
        (((l.freeMode && l.freeMode.enabled && this.freeMode) || l.watchSlidesProgress) &&
          (this.updateActiveIndex(), this.updateSlidesClasses()),
        l.freeMode && l.freeMode.enabled && this.freeMode && this.freeMode.onTouchMove(),
        this.updateProgress(r.currentTranslate),
        this.setTranslate(r.currentTranslate));
    }
    function F(e) {
      let t,
        i,
        s = this,
        r = s.touchEventsData,
        l = e;
      if ((l.originalEvent && (l = l.originalEvent), "touchend" === l.type || "touchcancel" === l.type)) {
        if (
          !(t = [...l.changedTouches].find((e) => e.identifier === r.touchId)) ||
          t.identifier !== r.touchId
        )
          return;
      } else {
        if (null !== r.touchId || l.pointerId !== r.pointerId) return;
        t = l;
      }
      if (
        ["pointercancel", "pointerout", "pointerleave", "contextmenu"].includes(l.type) &&
        !(["pointercancel", "contextmenu"].includes(l.type) && (s.browser.isSafari || s.browser.isWebView))
      )
        return;
      ((r.pointerId = null), (r.touchId = null));
      let { params: a, touches: n, rtlTranslate: o, slidesGrid: d, enabled: c } = s;
      if (!c || (!a.simulateTouch && "mouse" === l.pointerType)) return;
      if ((r.allowTouchCallbacks && s.emit("touchEnd", l), (r.allowTouchCallbacks = !1), !r.isTouched)) {
        (r.isMoved && a.grabCursor && s.setGrabCursor(!1), (r.isMoved = !1), (r.startMoving = !1));
        return;
      }
      a.grabCursor &&
        r.isMoved &&
        r.isTouched &&
        (!0 === s.allowSlideNext || !0 === s.allowSlidePrev) &&
        s.setGrabCursor(!1);
      let p = h(),
        f = p - r.touchStartTime;
      if (s.allowClick) {
        let e = l.path || (l.composedPath && l.composedPath());
        (s.updateClickedSlide((e && e[0]) || l.target, e),
          s.emit("tap click", l),
          f < 300 && p - r.lastClickTime < 300 && s.emit("doubleTap doubleClick", l));
      }
      if (
        ((r.lastClickTime = h()),
        u(() => {
          s.destroyed || (s.allowClick = !0);
        }),
        !r.isTouched ||
          !r.isMoved ||
          !s.swipeDirection ||
          (0 === n.diff && !r.loopSwapReset) ||
          (r.currentTranslate === r.startTranslate && !r.loopSwapReset))
      ) {
        ((r.isTouched = !1), (r.isMoved = !1), (r.startMoving = !1));
        return;
      }
      if (
        ((r.isTouched = !1),
        (r.isMoved = !1),
        (r.startMoving = !1),
        (i = a.followFinger ? (o ? s.translate : -s.translate) : -r.currentTranslate),
        a.cssMode)
      )
        return;
      if (a.freeMode && a.freeMode.enabled) return void s.freeMode.onTouchEnd({ currentPos: i });
      let m = i >= -s.maxTranslate() && !s.params.loop,
        v = 0,
        g = s.slidesSizesGrid[0];
      for (let e = 0; e < d.length; e += e < a.slidesPerGroupSkip ? 1 : a.slidesPerGroup) {
        let t = e < a.slidesPerGroupSkip - 1 ? 1 : a.slidesPerGroup;
        void 0 !== d[e + t]
          ? (m || (i >= d[e] && i < d[e + t])) && ((v = e), (g = d[e + t] - d[e]))
          : (m || i >= d[e]) && ((v = e), (g = d[d.length - 1] - d[d.length - 2]));
      }
      let w = null,
        S = null;
      a.rewind &&
        (s.isBeginning
          ? (S =
              a.virtual && a.virtual.enabled && s.virtual ? s.virtual.slides.length - 1 : s.slides.length - 1)
          : s.isEnd && (w = 0));
      let b = (i - d[v]) / g,
        T = v < a.slidesPerGroupSkip - 1 ? 1 : a.slidesPerGroup;
      if (f > a.longSwipesMs) {
        if (!a.longSwipes) return void s.slideTo(s.activeIndex);
        ("next" === s.swipeDirection &&
          (b >= a.longSwipesRatio ? s.slideTo(a.rewind && s.isEnd ? w : v + T) : s.slideTo(v)),
          "prev" === s.swipeDirection &&
            (b > 1 - a.longSwipesRatio
              ? s.slideTo(v + T)
              : null !== S && b < 0 && Math.abs(b) > a.longSwipesRatio
                ? s.slideTo(S)
                : s.slideTo(v)));
      } else {
        if (!a.shortSwipes) return void s.slideTo(s.activeIndex);
        s.navigation && (l.target === s.navigation.nextEl || l.target === s.navigation.prevEl)
          ? l.target === s.navigation.nextEl
            ? s.slideTo(v + T)
            : s.slideTo(v)
          : ("next" === s.swipeDirection && s.slideTo(null !== w ? w : v + T),
            "prev" === s.swipeDirection && s.slideTo(null !== S ? S : v));
      }
    }
    function R() {
      let e = this,
        { params: t, el: i } = e;
      if (i && 0 === i.offsetWidth) return;
      t.breakpoints && e.setBreakpoint();
      let { allowSlideNext: s, allowSlidePrev: r, snapGrid: l } = e,
        a = e.virtual && e.params.virtual.enabled;
      ((e.allowSlideNext = !0),
        (e.allowSlidePrev = !0),
        e.updateSize(),
        e.updateSlides(),
        e.updateSlidesClasses());
      let n = a && t.loop;
      (("auto" !== t.slidesPerView && !(t.slidesPerView > 1)) ||
      !e.isEnd ||
      e.isBeginning ||
      e.params.centeredSlides ||
      n
        ? e.params.loop && !a
          ? e.slideToLoop(e.realIndex, 0, !1, !0)
          : e.slideTo(e.activeIndex, 0, !1, !0)
        : e.slideTo(e.slides.length - 1, 0, !1, !0),
        e.autoplay &&
          e.autoplay.running &&
          e.autoplay.paused &&
          (clearTimeout(e.autoplay.resizeTimeout),
          (e.autoplay.resizeTimeout = setTimeout(() => {
            e.autoplay && e.autoplay.running && e.autoplay.paused && e.autoplay.resume();
          }, 500))),
        (e.allowSlidePrev = r),
        (e.allowSlideNext = s),
        e.params.watchOverflow && l !== e.snapGrid && e.checkOverflow());
    }
    function H(e) {
      this.enabled &&
        !this.allowClick &&
        (this.params.preventClicks && e.preventDefault(),
        this.params.preventClicksPropagation &&
          this.animating &&
          (e.stopPropagation(), e.stopImmediatePropagation()));
    }
    function W() {
      let { wrapperEl: e, rtlTranslate: t, enabled: i } = this;
      if (!i) return;
      ((this.previousTranslate = this.translate),
        this.isHorizontal() ? (this.translate = -e.scrollLeft) : (this.translate = -e.scrollTop),
        0 === this.translate && (this.translate = 0),
        this.updateActiveIndex(),
        this.updateSlidesClasses());
      let s = this.maxTranslate() - this.minTranslate();
      ((0 === s ? 0 : (this.translate - this.minTranslate()) / s) !== this.progress &&
        this.updateProgress(t ? -this.translate : this.translate),
        this.emit("setTranslate", this.translate, !1));
    }
    function q(e) {
      (G(this, e.target),
        !this.params.cssMode &&
          ("auto" === this.params.slidesPerView || this.params.autoHeight) &&
          this.update());
    }
    function X() {
      !this.documentTouchHandlerProceeded &&
        ((this.documentTouchHandlerProceeded = !0),
        this.params.touchReleaseOnEdges && (this.el.style.touchAction = "auto"));
    }
    let Y = (e, t) => {
        let i = o(),
          { params: s, el: r, wrapperEl: l, device: a } = e,
          n = !!s.nested,
          d = "on" === t ? "addEventListener" : "removeEventListener";
        r &&
          "string" != typeof r &&
          (i[d]("touchstart", e.onDocumentTouchStart, { passive: !1, capture: n }),
          r[d]("touchstart", e.onTouchStart, { passive: !1 }),
          r[d]("pointerdown", e.onTouchStart, { passive: !1 }),
          i[d]("touchmove", e.onTouchMove, { passive: !1, capture: n }),
          i[d]("pointermove", e.onTouchMove, { passive: !1, capture: n }),
          i[d]("touchend", e.onTouchEnd, { passive: !0 }),
          i[d]("pointerup", e.onTouchEnd, { passive: !0 }),
          i[d]("pointercancel", e.onTouchEnd, { passive: !0 }),
          i[d]("touchcancel", e.onTouchEnd, { passive: !0 }),
          i[d]("pointerout", e.onTouchEnd, { passive: !0 }),
          i[d]("pointerleave", e.onTouchEnd, { passive: !0 }),
          i[d]("contextmenu", e.onTouchEnd, { passive: !0 }),
          (s.preventClicks || s.preventClicksPropagation) && r[d]("click", e.onClick, !0),
          s.cssMode && l[d]("scroll", e.onScroll),
          s.updateOnWindowResize
            ? e[t](
                a.ios || a.android ? "resize orientationchange observerUpdate" : "resize observerUpdate",
                R,
                !0,
              )
            : e[t]("observerUpdate", R, !0),
          r[d]("load", e.onLoad, { capture: !0 }));
      },
      U = (e, t) => e.grid && t.grid && t.grid.rows > 1;
    var K = {
      init: !0,
      direction: "horizontal",
      oneWayMovement: !1,
      swiperElementNodeName: "SWIPER-CONTAINER",
      touchEventsTarget: "wrapper",
      initialSlide: 0,
      speed: 300,
      cssMode: !1,
      updateOnWindowResize: !0,
      resizeObserver: !0,
      nested: !1,
      createElements: !1,
      eventsPrefix: "swiper",
      enabled: !0,
      focusableElements: "input, select, option, textarea, button, video, label",
      width: null,
      height: null,
      preventInteractionOnTransition: !1,
      userAgent: null,
      url: null,
      edgeSwipeDetection: !1,
      edgeSwipeThreshold: 20,
      autoHeight: !1,
      setWrapperSize: !1,
      virtualTranslate: !1,
      effect: "slide",
      breakpoints: void 0,
      breakpointsBase: "window",
      spaceBetween: 0,
      slidesPerView: 1,
      slidesPerGroup: 1,
      slidesPerGroupSkip: 0,
      slidesPerGroupAuto: !1,
      centeredSlides: !1,
      centeredSlidesBounds: !1,
      slidesOffsetBefore: 0,
      slidesOffsetAfter: 0,
      normalizeSlideIndex: !0,
      centerInsufficientSlides: !1,
      watchOverflow: !0,
      roundLengths: !1,
      touchRatio: 1,
      touchAngle: 45,
      simulateTouch: !0,
      shortSwipes: !0,
      longSwipes: !0,
      longSwipesRatio: 0.5,
      longSwipesMs: 300,
      followFinger: !0,
      allowTouchMove: !0,
      threshold: 5,
      touchMoveStopPropagation: !1,
      touchStartPreventDefault: !0,
      touchStartForcePreventDefault: !1,
      touchReleaseOnEdges: !1,
      uniqueNavElements: !0,
      resistance: !0,
      resistanceRatio: 0.85,
      watchSlidesProgress: !1,
      grabCursor: !1,
      preventClicks: !0,
      preventClicksPropagation: !0,
      slideToClickedSlide: !1,
      loop: !1,
      loopAddBlankSlides: !0,
      loopAdditionalSlides: 0,
      loopPreventsSliding: !0,
      rewind: !1,
      allowSlidePrev: !0,
      allowSlideNext: !0,
      swipeHandler: null,
      noSwiping: !0,
      noSwipingClass: "swiper-no-swiping",
      noSwipingSelector: null,
      passiveListeners: !0,
      maxBackfaceHiddenSlides: 10,
      containerModifierClass: "swiper-",
      slideClass: "swiper-slide",
      slideBlankClass: "swiper-slide-blank",
      slideActiveClass: "swiper-slide-active",
      slideVisibleClass: "swiper-slide-visible",
      slideFullyVisibleClass: "swiper-slide-fully-visible",
      slideNextClass: "swiper-slide-next",
      slidePrevClass: "swiper-slide-prev",
      wrapperClass: "swiper-wrapper",
      lazyPreloaderClass: "swiper-lazy-preloader",
      lazyPreloadPrevNext: 0,
      runCallbacksOnInit: !0,
      _emitClasses: !1,
    };
    let Z = {
        eventsEmitter: {
          on(e, t, i) {
            let s = this;
            if (!s.eventsListeners || s.destroyed || "function" != typeof t) return s;
            let r = i ? "unshift" : "push";
            return (
              e.split(" ").forEach((e) => {
                (s.eventsListeners[e] || (s.eventsListeners[e] = []), s.eventsListeners[e][r](t));
              }),
              s
            );
          },
          once(e, t, i) {
            let s = this;
            if (!s.eventsListeners || s.destroyed || "function" != typeof t) return s;
            function r() {
              (s.off(e, r), r.__emitterProxy && delete r.__emitterProxy);
              for (var i = arguments.length, l = Array(i), a = 0; a < i; a++) l[a] = arguments[a];
              t.apply(s, l);
            }
            return ((r.__emitterProxy = t), s.on(e, r, i));
          },
          onAny(e, t) {
            return (
              !this.eventsListeners ||
                this.destroyed ||
                "function" != typeof e ||
                (0 > this.eventsAnyListeners.indexOf(e) &&
                  this.eventsAnyListeners[t ? "unshift" : "push"](e)),
              this
            );
          },
          offAny(e) {
            if (!this.eventsListeners || this.destroyed || !this.eventsAnyListeners) return this;
            let t = this.eventsAnyListeners.indexOf(e);
            return (t >= 0 && this.eventsAnyListeners.splice(t, 1), this);
          },
          off(e, t) {
            let i = this;
            return (
              i.eventsListeners &&
                !i.destroyed &&
                i.eventsListeners &&
                e.split(" ").forEach((e) => {
                  void 0 === t
                    ? (i.eventsListeners[e] = [])
                    : i.eventsListeners[e] &&
                      i.eventsListeners[e].forEach((s, r) => {
                        (s === t || (s.__emitterProxy && s.__emitterProxy === t)) &&
                          i.eventsListeners[e].splice(r, 1);
                      });
                }),
              i
            );
          },
          emit() {
            let e,
              t,
              i,
              s = this;
            if (!s.eventsListeners || s.destroyed || !s.eventsListeners) return s;
            for (var r = arguments.length, l = Array(r), a = 0; a < r; a++) l[a] = arguments[a];
            return (
              "string" == typeof l[0] || Array.isArray(l[0])
                ? ((e = l[0]), (t = l.slice(1, l.length)), (i = s))
                : ((e = l[0].events), (t = l[0].data), (i = l[0].context || s)),
              t.unshift(i),
              (Array.isArray(e) ? e : e.split(" ")).forEach((e) => {
                (s.eventsAnyListeners &&
                  s.eventsAnyListeners.length &&
                  s.eventsAnyListeners.forEach((s) => {
                    s.apply(i, [e, ...t]);
                  }),
                  s.eventsListeners &&
                    s.eventsListeners[e] &&
                    s.eventsListeners[e].forEach((e) => {
                      e.apply(i, t);
                    }));
              }),
              s
            );
          },
        },
        update: {
          updateSize: function () {
            let e,
              t,
              i = this.el;
            ((e =
              void 0 !== this.params.width && null !== this.params.width ? this.params.width : i.clientWidth),
              (t =
                void 0 !== this.params.height && null !== this.params.height
                  ? this.params.height
                  : i.clientHeight),
              (0 === e && this.isHorizontal()) ||
                (0 === t && this.isVertical()) ||
                ((e = e - parseInt(M(i, "padding-left") || 0, 10) - parseInt(M(i, "padding-right") || 0, 10)),
                (t = t - parseInt(M(i, "padding-top") || 0, 10) - parseInt(M(i, "padding-bottom") || 0, 10)),
                Number.isNaN(e) && (e = 0),
                Number.isNaN(t) && (t = 0),
                Object.assign(this, { width: e, height: t, size: this.isHorizontal() ? e : t })));
          },
          updateSlides: function () {
            let e,
              t = this;
            function i(e, i) {
              return parseFloat(e.getPropertyValue(t.getDirectionLabel(i)) || 0);
            }
            let s = t.params,
              { wrapperEl: r, slidesEl: l, size: a, rtlTranslate: n, wrongRTL: o } = t,
              d = t.virtual && s.virtual.enabled,
              c = d ? t.virtual.slides.length : t.slides.length,
              p = S(l, `.${t.params.slideClass}, swiper-slide`),
              u = d ? t.virtual.slides.length : p.length,
              h = [],
              f = [],
              m = [],
              v = s.slidesOffsetBefore;
            "function" == typeof v && (v = s.slidesOffsetBefore.call(t));
            let w = s.slidesOffsetAfter;
            "function" == typeof w && (w = s.slidesOffsetAfter.call(t));
            let b = t.snapGrid.length,
              T = t.slidesGrid.length,
              y = s.spaceBetween,
              E = -v,
              x = 0,
              C = 0;
            if (void 0 === a) return;
            ("string" == typeof y && y.indexOf("%") >= 0
              ? (y = (parseFloat(y.replace("%", "")) / 100) * a)
              : "string" == typeof y && (y = parseFloat(y)),
              (t.virtualSize = -y),
              p.forEach((e) => {
                (n ? (e.style.marginLeft = "") : (e.style.marginRight = ""),
                  (e.style.marginBottom = ""),
                  (e.style.marginTop = ""));
              }),
              s.centeredSlides &&
                s.cssMode &&
                (g(r, "--swiper-centered-offset-before", ""), g(r, "--swiper-centered-offset-after", "")));
            let P = s.grid && s.grid.rows > 1 && t.grid;
            P ? t.grid.initSlides(p) : t.grid && t.grid.unsetSlides();
            let O =
              "auto" === s.slidesPerView &&
              s.breakpoints &&
              Object.keys(s.breakpoints).filter((e) => void 0 !== s.breakpoints[e].slidesPerView).length > 0;
            for (let r = 0; r < u; r += 1) {
              let l;
              if (
                ((e = 0),
                p[r] && (l = p[r]),
                P && t.grid.updateSlide(r, l, p),
                !p[r] || "none" !== M(l, "display"))
              ) {
                if ("auto" === s.slidesPerView) {
                  O && (p[r].style[t.getDirectionLabel("width")] = "");
                  let a = getComputedStyle(l),
                    n = l.style.transform,
                    o = l.style.webkitTransform;
                  if (
                    (n && (l.style.transform = "none"),
                    o && (l.style.webkitTransform = "none"),
                    s.roundLengths)
                  )
                    e = t.isHorizontal() ? k(l, "width", !0) : k(l, "height", !0);
                  else {
                    let t = i(a, "width"),
                      s = i(a, "padding-left"),
                      r = i(a, "padding-right"),
                      n = i(a, "margin-left"),
                      o = i(a, "margin-right"),
                      d = a.getPropertyValue("box-sizing");
                    if (d && "border-box" === d) e = t + n + o;
                    else {
                      let { clientWidth: i, offsetWidth: a } = l;
                      e = t + s + r + n + o + (a - i);
                    }
                  }
                  (n && (l.style.transform = n),
                    o && (l.style.webkitTransform = o),
                    s.roundLengths && (e = Math.floor(e)));
                } else
                  ((e = (a - (s.slidesPerView - 1) * y) / s.slidesPerView),
                    s.roundLengths && (e = Math.floor(e)),
                    p[r] && (p[r].style[t.getDirectionLabel("width")] = `${e}px`));
                (p[r] && (p[r].swiperSlideSize = e),
                  m.push(e),
                  s.centeredSlides
                    ? ((E = E + e / 2 + x / 2 + y),
                      0 === x && 0 !== r && (E = E - a / 2 - y),
                      0 === r && (E = E - a / 2 - y),
                      0.001 > Math.abs(E) && (E = 0),
                      s.roundLengths && (E = Math.floor(E)),
                      C % s.slidesPerGroup == 0 && h.push(E),
                      f.push(E))
                    : (s.roundLengths && (E = Math.floor(E)),
                      (C - Math.min(t.params.slidesPerGroupSkip, C)) % t.params.slidesPerGroup == 0 &&
                        h.push(E),
                      f.push(E),
                      (E = E + e + y)),
                  (t.virtualSize += e + y),
                  (x = e),
                  (C += 1));
              }
            }
            if (
              ((t.virtualSize = Math.max(t.virtualSize, a) + w),
              n &&
                o &&
                ("slide" === s.effect || "coverflow" === s.effect) &&
                (r.style.width = `${t.virtualSize + y}px`),
              s.setWrapperSize && (r.style[t.getDirectionLabel("width")] = `${t.virtualSize + y}px`),
              P && t.grid.updateWrapperSize(e, h),
              !s.centeredSlides)
            ) {
              let e = [];
              for (let i = 0; i < h.length; i += 1) {
                let r = h[i];
                (s.roundLengths && (r = Math.floor(r)), h[i] <= t.virtualSize - a && e.push(r));
              }
              ((h = e),
                Math.floor(t.virtualSize - a) - Math.floor(h[h.length - 1]) > 1 && h.push(t.virtualSize - a));
            }
            if (d && s.loop) {
              let e = m[0] + y;
              if (s.slidesPerGroup > 1) {
                let i = Math.ceil((t.virtual.slidesBefore + t.virtual.slidesAfter) / s.slidesPerGroup),
                  r = e * s.slidesPerGroup;
                for (let e = 0; e < i; e += 1) h.push(h[h.length - 1] + r);
              }
              for (let i = 0; i < t.virtual.slidesBefore + t.virtual.slidesAfter; i += 1)
                (1 === s.slidesPerGroup && h.push(h[h.length - 1] + e),
                  f.push(f[f.length - 1] + e),
                  (t.virtualSize += e));
            }
            if ((0 === h.length && (h = [0]), 0 !== y)) {
              let e = t.isHorizontal() && n ? "marginLeft" : t.getDirectionLabel("marginRight");
              p.filter((e, t) => !s.cssMode || !!s.loop || t !== p.length - 1).forEach((t) => {
                t.style[e] = `${y}px`;
              });
            }
            if (s.centeredSlides && s.centeredSlidesBounds) {
              let e = 0;
              m.forEach((t) => {
                e += t + (y || 0);
              });
              let t = (e -= y) > a ? e - a : 0;
              h = h.map((e) => (e <= 0 ? -v : e > t ? t + w : e));
            }
            if (s.centerInsufficientSlides) {
              let e = 0;
              (m.forEach((t) => {
                e += t + (y || 0);
              }),
                (e -= y));
              let t = (s.slidesOffsetBefore || 0) + (s.slidesOffsetAfter || 0);
              if (e + t < a) {
                let i = (a - e - t) / 2;
                (h.forEach((e, t) => {
                  h[t] = e - i;
                }),
                  f.forEach((e, t) => {
                    f[t] = e + i;
                  }));
              }
            }
            if (
              (Object.assign(t, { slides: p, snapGrid: h, slidesGrid: f, slidesSizesGrid: m }),
              s.centeredSlides && s.cssMode && !s.centeredSlidesBounds)
            ) {
              (g(r, "--swiper-centered-offset-before", `${-h[0]}px`),
                g(r, "--swiper-centered-offset-after", `${t.size / 2 - m[m.length - 1] / 2}px`));
              let e = -t.snapGrid[0],
                i = -t.slidesGrid[0];
              ((t.snapGrid = t.snapGrid.map((t) => t + e)), (t.slidesGrid = t.slidesGrid.map((e) => e + i)));
            }
            if (
              (u !== c && t.emit("slidesLengthChange"),
              h.length !== b && (t.params.watchOverflow && t.checkOverflow(), t.emit("snapGridLengthChange")),
              f.length !== T && t.emit("slidesGridLengthChange"),
              s.watchSlidesProgress && t.updateSlidesOffset(),
              t.emit("slidesUpdated"),
              !d && !s.cssMode && ("slide" === s.effect || "fade" === s.effect))
            ) {
              let e = `${s.containerModifierClass}backface-hidden`,
                i = t.el.classList.contains(e);
              u <= s.maxBackfaceHiddenSlides ? i || t.el.classList.add(e) : i && t.el.classList.remove(e);
            }
          },
          updateAutoHeight: function (e) {
            let t,
              i = this,
              s = [],
              r = i.virtual && i.params.virtual.enabled,
              l = 0;
            "number" == typeof e ? i.setTransition(e) : !0 === e && i.setTransition(i.params.speed);
            let a = (e) => (r ? i.slides[i.getSlideIndexByData(e)] : i.slides[e]);
            if ("auto" !== i.params.slidesPerView && i.params.slidesPerView > 1)
              if (i.params.centeredSlides)
                (i.visibleSlides || []).forEach((e) => {
                  s.push(e);
                });
              else
                for (t = 0; t < Math.ceil(i.params.slidesPerView); t += 1) {
                  let e = i.activeIndex + t;
                  if (e > i.slides.length && !r) break;
                  s.push(a(e));
                }
            else s.push(a(i.activeIndex));
            for (t = 0; t < s.length; t += 1)
              if (void 0 !== s[t]) {
                let e = s[t].offsetHeight;
                l = e > l ? e : l;
              }
            (l || 0 === l) && (i.wrapperEl.style.height = `${l}px`);
          },
          updateSlidesOffset: function () {
            let e = this.slides,
              t = this.isElement
                ? this.isHorizontal()
                  ? this.wrapperEl.offsetLeft
                  : this.wrapperEl.offsetTop
                : 0;
            for (let i = 0; i < e.length; i += 1)
              e[i].swiperSlideOffset =
                (this.isHorizontal() ? e[i].offsetLeft : e[i].offsetTop) - t - this.cssOverflowAdjustment();
          },
          updateSlidesProgress: function (e) {
            void 0 === e && (e = (this && this.translate) || 0);
            let t = this.params,
              { slides: i, rtlTranslate: s, snapGrid: r } = this;
            if (0 === i.length) return;
            void 0 === i[0].swiperSlideOffset && this.updateSlidesOffset();
            let l = -e;
            (s && (l = e), (this.visibleSlidesIndexes = []), (this.visibleSlides = []));
            let a = t.spaceBetween;
            "string" == typeof a && a.indexOf("%") >= 0
              ? (a = (parseFloat(a.replace("%", "")) / 100) * this.size)
              : "string" == typeof a && (a = parseFloat(a));
            for (let e = 0; e < i.length; e += 1) {
              let n = i[e],
                o = n.swiperSlideOffset;
              t.cssMode && t.centeredSlides && (o -= i[0].swiperSlideOffset);
              let d = (l + (t.centeredSlides ? this.minTranslate() : 0) - o) / (n.swiperSlideSize + a),
                c = (l - r[0] + (t.centeredSlides ? this.minTranslate() : 0) - o) / (n.swiperSlideSize + a),
                p = -(l - o),
                u = p + this.slidesSizesGrid[e],
                h = p >= 0 && p <= this.size - this.slidesSizesGrid[e],
                f = (p >= 0 && p < this.size - 1) || (u > 1 && u <= this.size) || (p <= 0 && u >= this.size);
              (f && (this.visibleSlides.push(n), this.visibleSlidesIndexes.push(e)),
                A(n, f, t.slideVisibleClass),
                A(n, h, t.slideFullyVisibleClass),
                (n.progress = s ? -d : d),
                (n.originalProgress = s ? -c : c));
            }
          },
          updateProgress: function (e) {
            if (void 0 === e) {
              let t = this.rtlTranslate ? -1 : 1;
              e = (this && this.translate && this.translate * t) || 0;
            }
            let t = this.params,
              i = this.maxTranslate() - this.minTranslate(),
              { progress: s, isBeginning: r, isEnd: l, progressLoop: a } = this,
              n = r,
              o = l;
            if (0 === i) ((s = 0), (r = !0), (l = !0));
            else {
              s = (e - this.minTranslate()) / i;
              let t = 1 > Math.abs(e - this.minTranslate()),
                a = 1 > Math.abs(e - this.maxTranslate());
              ((r = t || s <= 0), (l = a || s >= 1), t && (s = 0), a && (s = 1));
            }
            if (t.loop) {
              let t = this.getSlideIndexByData(0),
                i = this.getSlideIndexByData(this.slides.length - 1),
                s = this.slidesGrid[t],
                r = this.slidesGrid[i],
                l = this.slidesGrid[this.slidesGrid.length - 1],
                n = Math.abs(e);
              (a = n >= s ? (n - s) / l : (n + l - r) / l) > 1 && (a -= 1);
            }
            (Object.assign(this, { progress: s, progressLoop: a, isBeginning: r, isEnd: l }),
              (t.watchSlidesProgress || (t.centeredSlides && t.autoHeight)) && this.updateSlidesProgress(e),
              r && !n && this.emit("reachBeginning toEdge"),
              l && !o && this.emit("reachEnd toEdge"),
              ((n && !r) || (o && !l)) && this.emit("fromEdge"),
              this.emit("progress", s));
          },
          updateSlidesClasses: function () {
            let e,
              t,
              i,
              { slides: s, params: r, slidesEl: l, activeIndex: a } = this,
              n = this.virtual && r.virtual.enabled,
              o = this.grid && r.grid && r.grid.rows > 1,
              d = (e) => S(l, `.${r.slideClass}${e}, swiper-slide${e}`)[0];
            if (n)
              if (r.loop) {
                let t = a - this.virtual.slidesBefore;
                (t < 0 && (t = this.virtual.slides.length + t),
                  t >= this.virtual.slides.length && (t -= this.virtual.slides.length),
                  (e = d(`[data-swiper-slide-index="${t}"]`)));
              } else e = d(`[data-swiper-slide-index="${a}"]`);
            else
              o
                ? ((e = s.find((e) => e.column === a)),
                  (i = s.find((e) => e.column === a + 1)),
                  (t = s.find((e) => e.column === a - 1)))
                : (e = s[a]);
            (e &&
              !o &&
              ((i = x(e, `.${r.slideClass}, swiper-slide`)[0]),
              r.loop && !i && (i = s[0]),
              (t = E(e, `.${r.slideClass}, swiper-slide`)[0]),
              r.loop),
              s.forEach((s) => {
                (z(s, s === e, r.slideActiveClass),
                  z(s, s === i, r.slideNextClass),
                  z(s, s === t, r.slidePrevClass));
              }),
              this.emitSlidesClasses());
          },
          updateActiveIndex: function (e) {
            let t,
              i,
              s = this,
              r = s.rtlTranslate ? s.translate : -s.translate,
              { snapGrid: l, params: a, activeIndex: n, realIndex: o, snapIndex: d } = s,
              c = e,
              p = (e) => {
                let t = e - s.virtual.slidesBefore;
                return (
                  t < 0 && (t = s.virtual.slides.length + t),
                  t >= s.virtual.slides.length && (t -= s.virtual.slides.length),
                  t
                );
              };
            if (
              (void 0 === c &&
                (c = (function (e) {
                  let t,
                    { slidesGrid: i, params: s } = e,
                    r = e.rtlTranslate ? e.translate : -e.translate;
                  for (let e = 0; e < i.length; e += 1)
                    void 0 !== i[e + 1]
                      ? r >= i[e] && r < i[e + 1] - (i[e + 1] - i[e]) / 2
                        ? (t = e)
                        : r >= i[e] && r < i[e + 1] && (t = e + 1)
                      : r >= i[e] && (t = e);
                  return (s.normalizeSlideIndex && (t < 0 || void 0 === t) && (t = 0), t);
                })(s)),
              l.indexOf(r) >= 0)
            )
              t = l.indexOf(r);
            else {
              let e = Math.min(a.slidesPerGroupSkip, c);
              t = e + Math.floor((c - e) / a.slidesPerGroup);
            }
            if ((t >= l.length && (t = l.length - 1), c === n && !s.params.loop)) {
              t !== d && ((s.snapIndex = t), s.emit("snapIndexChange"));
              return;
            }
            if (c === n && s.params.loop && s.virtual && s.params.virtual.enabled) {
              s.realIndex = p(c);
              return;
            }
            let u = s.grid && a.grid && a.grid.rows > 1;
            if (s.virtual && a.virtual.enabled && a.loop) i = p(c);
            else if (u) {
              let e = s.slides.find((e) => e.column === c),
                t = parseInt(e.getAttribute("data-swiper-slide-index"), 10);
              (Number.isNaN(t) && (t = Math.max(s.slides.indexOf(e), 0)), (i = Math.floor(t / a.grid.rows)));
            } else if (s.slides[c]) {
              let e = s.slides[c].getAttribute("data-swiper-slide-index");
              i = e ? parseInt(e, 10) : c;
            } else i = c;
            (Object.assign(s, {
              previousSnapIndex: d,
              snapIndex: t,
              previousRealIndex: o,
              realIndex: i,
              previousIndex: n,
              activeIndex: c,
            }),
              s.initialized && N(s),
              s.emit("activeIndexChange"),
              s.emit("snapIndexChange"),
              (s.initialized || s.params.runCallbacksOnInit) &&
                (o !== i && s.emit("realIndexChange"), s.emit("slideChange")));
          },
          updateClickedSlide: function (e, t) {
            let i,
              s = this.params,
              r = e.closest(`.${s.slideClass}, swiper-slide`);
            !r &&
              this.isElement &&
              t &&
              t.length > 1 &&
              t.includes(e) &&
              [...t.slice(t.indexOf(e) + 1, t.length)].forEach((e) => {
                !r && e.matches && e.matches(`.${s.slideClass}, swiper-slide`) && (r = e);
              });
            let l = !1;
            if (r) {
              for (let e = 0; e < this.slides.length; e += 1)
                if (this.slides[e] === r) {
                  ((l = !0), (i = e));
                  break;
                }
            }
            if (r && l)
              ((this.clickedSlide = r),
                this.virtual && this.params.virtual.enabled
                  ? (this.clickedIndex = parseInt(r.getAttribute("data-swiper-slide-index"), 10))
                  : (this.clickedIndex = i));
            else {
              ((this.clickedSlide = void 0), (this.clickedIndex = void 0));
              return;
            }
            s.slideToClickedSlide &&
              void 0 !== this.clickedIndex &&
              this.clickedIndex !== this.activeIndex &&
              this.slideToClickedSlide();
          },
        },
        translate: {
          getTranslate: function (e) {
            void 0 === e && (e = this.isHorizontal() ? "x" : "y");
            let { params: t, rtlTranslate: i, translate: s, wrapperEl: r } = this;
            if (t.virtualTranslate) return i ? -s : s;
            if (t.cssMode) return s;
            let l = f(r, e);
            return ((l += this.cssOverflowAdjustment()), i && (l = -l), l || 0);
          },
          setTranslate: function (e, t) {
            let { rtlTranslate: i, params: s, wrapperEl: r, progress: l } = this,
              a = 0,
              n = 0;
            (this.isHorizontal() ? (a = i ? -e : e) : (n = e),
              s.roundLengths && ((a = Math.floor(a)), (n = Math.floor(n))),
              (this.previousTranslate = this.translate),
              (this.translate = this.isHorizontal() ? a : n),
              s.cssMode
                ? (r[this.isHorizontal() ? "scrollLeft" : "scrollTop"] = this.isHorizontal() ? -a : -n)
                : s.virtualTranslate ||
                  (this.isHorizontal()
                    ? (a -= this.cssOverflowAdjustment())
                    : (n -= this.cssOverflowAdjustment()),
                  (r.style.transform = `translate3d(${a}px, ${n}px, 0px)`)));
            let o = this.maxTranslate() - this.minTranslate();
            ((0 === o ? 0 : (e - this.minTranslate()) / o) !== l && this.updateProgress(e),
              this.emit("setTranslate", this.translate, t));
          },
          minTranslate: function () {
            return -this.snapGrid[0];
          },
          maxTranslate: function () {
            return -this.snapGrid[this.snapGrid.length - 1];
          },
          translateTo: function (e, t, i, s, r) {
            let l;
            (void 0 === e && (e = 0),
              void 0 === t && (t = this.params.speed),
              void 0 === i && (i = !0),
              void 0 === s && (s = !0));
            let a = this,
              { params: n, wrapperEl: o } = a;
            if (a.animating && n.preventInteractionOnTransition) return !1;
            let d = a.minTranslate(),
              c = a.maxTranslate();
            if (((l = s && e > d ? d : s && e < c ? c : e), a.updateProgress(l), n.cssMode)) {
              let e = a.isHorizontal();
              if (0 === t) o[e ? "scrollLeft" : "scrollTop"] = -l;
              else {
                if (!a.support.smoothScroll)
                  return (w({ swiper: a, targetPosition: -l, side: e ? "left" : "top" }), !0);
                o.scrollTo({ [e ? "left" : "top"]: -l, behavior: "smooth" });
              }
              return !0;
            }
            return (
              0 === t
                ? (a.setTransition(0),
                  a.setTranslate(l),
                  i && (a.emit("beforeTransitionStart", t, r), a.emit("transitionEnd")))
                : (a.setTransition(t),
                  a.setTranslate(l),
                  i && (a.emit("beforeTransitionStart", t, r), a.emit("transitionStart")),
                  a.animating ||
                    ((a.animating = !0),
                    a.onTranslateToWrapperTransitionEnd ||
                      (a.onTranslateToWrapperTransitionEnd = function (e) {
                        !a ||
                          a.destroyed ||
                          (e.target === this &&
                            (a.wrapperEl.removeEventListener(
                              "transitionend",
                              a.onTranslateToWrapperTransitionEnd,
                            ),
                            (a.onTranslateToWrapperTransitionEnd = null),
                            delete a.onTranslateToWrapperTransitionEnd,
                            (a.animating = !1),
                            i && a.emit("transitionEnd")));
                      }),
                    a.wrapperEl.addEventListener("transitionend", a.onTranslateToWrapperTransitionEnd))),
              !0
            );
          },
        },
        transition: {
          setTransition: function (e, t) {
            (this.params.cssMode ||
              ((this.wrapperEl.style.transitionDuration = `${e}ms`),
              (this.wrapperEl.style.transitionDelay = 0 === e ? "0ms" : "")),
              this.emit("setTransition", e, t));
          },
          transitionStart: function (e, t) {
            void 0 === e && (e = !0);
            let { params: i } = this;
            i.cssMode ||
              (i.autoHeight && this.updateAutoHeight(),
              B({ swiper: this, runCallbacks: e, direction: t, step: "Start" }));
          },
          transitionEnd: function (e, t) {
            void 0 === e && (e = !0);
            let { params: i } = this;
            ((this.animating = !1),
              i.cssMode ||
                (this.setTransition(0), B({ swiper: this, runCallbacks: e, direction: t, step: "End" })));
          },
        },
        slide: {
          slideTo: function (e, t, i, s, r) {
            let l;
            (void 0 === e && (e = 0),
              void 0 === i && (i = !0),
              "string" == typeof e && (e = parseInt(e, 10)));
            let a = this,
              n = e;
            n < 0 && (n = 0);
            let {
              params: o,
              snapGrid: d,
              slidesGrid: c,
              previousIndex: p,
              activeIndex: u,
              rtlTranslate: h,
              wrapperEl: f,
              enabled: m,
            } = a;
            if ((!m && !s && !r) || a.destroyed || (a.animating && o.preventInteractionOnTransition))
              return !1;
            void 0 === t && (t = a.params.speed);
            let v = Math.min(a.params.slidesPerGroupSkip, n),
              g = v + Math.floor((n - v) / a.params.slidesPerGroup);
            g >= d.length && (g = d.length - 1);
            let S = -d[g];
            if (o.normalizeSlideIndex)
              for (let e = 0; e < c.length; e += 1) {
                let t = -Math.floor(100 * S),
                  i = Math.floor(100 * c[e]),
                  s = Math.floor(100 * c[e + 1]);
                void 0 !== c[e + 1]
                  ? t >= i && t < s - (s - i) / 2
                    ? (n = e)
                    : t >= i && t < s && (n = e + 1)
                  : t >= i && (n = e);
              }
            if (
              a.initialized &&
              n !== u &&
              ((!a.allowSlideNext &&
                (h ? S > a.translate && S > a.minTranslate() : S < a.translate && S < a.minTranslate())) ||
                (!a.allowSlidePrev && S > a.translate && S > a.maxTranslate() && (u || 0) !== n))
            )
              return !1;
            (n !== (p || 0) && i && a.emit("beforeSlideChangeStart"),
              a.updateProgress(S),
              (l = n > u ? "next" : n < u ? "prev" : "reset"));
            let b = a.virtual && a.params.virtual.enabled;
            if (!(b && r) && ((h && -S === a.translate) || (!h && S === a.translate)))
              return (
                a.updateActiveIndex(n),
                o.autoHeight && a.updateAutoHeight(),
                a.updateSlidesClasses(),
                "slide" !== o.effect && a.setTranslate(S),
                "reset" !== l && (a.transitionStart(i, l), a.transitionEnd(i, l)),
                !1
              );
            if (o.cssMode) {
              let e = a.isHorizontal(),
                i = h ? S : -S;
              if (0 === t)
                (b && ((a.wrapperEl.style.scrollSnapType = "none"), (a._immediateVirtual = !0)),
                  b && !a._cssModeVirtualInitialSet && a.params.initialSlide > 0
                    ? ((a._cssModeVirtualInitialSet = !0),
                      requestAnimationFrame(() => {
                        f[e ? "scrollLeft" : "scrollTop"] = i;
                      }))
                    : (f[e ? "scrollLeft" : "scrollTop"] = i),
                  b &&
                    requestAnimationFrame(() => {
                      ((a.wrapperEl.style.scrollSnapType = ""), (a._immediateVirtual = !1));
                    }));
              else {
                if (!a.support.smoothScroll)
                  return (w({ swiper: a, targetPosition: i, side: e ? "left" : "top" }), !0);
                f.scrollTo({ [e ? "left" : "top"]: i, behavior: "smooth" });
              }
              return !0;
            }
            let T = I().isSafari;
            return (
              b && !r && T && a.isElement && a.virtual.update(!1, !1, n),
              a.setTransition(t),
              a.setTranslate(S),
              a.updateActiveIndex(n),
              a.updateSlidesClasses(),
              a.emit("beforeTransitionStart", t, s),
              a.transitionStart(i, l),
              0 === t
                ? a.transitionEnd(i, l)
                : a.animating ||
                  ((a.animating = !0),
                  a.onSlideToWrapperTransitionEnd ||
                    (a.onSlideToWrapperTransitionEnd = function (e) {
                      !a ||
                        a.destroyed ||
                        (e.target === this &&
                          (a.wrapperEl.removeEventListener("transitionend", a.onSlideToWrapperTransitionEnd),
                          (a.onSlideToWrapperTransitionEnd = null),
                          delete a.onSlideToWrapperTransitionEnd,
                          a.transitionEnd(i, l)));
                    }),
                  a.wrapperEl.addEventListener("transitionend", a.onSlideToWrapperTransitionEnd)),
              !0
            );
          },
          slideToLoop: function (e, t, i, s) {
            (void 0 === e && (e = 0),
              void 0 === i && (i = !0),
              "string" == typeof e && (e = parseInt(e, 10)));
            let r = this;
            if (r.destroyed) return;
            void 0 === t && (t = r.params.speed);
            let l = r.grid && r.params.grid && r.params.grid.rows > 1,
              a = e;
            if (r.params.loop)
              if (r.virtual && r.params.virtual.enabled) a += r.virtual.slidesBefore;
              else {
                let e;
                if (l) {
                  let t = a * r.params.grid.rows;
                  e = r.slides.find((e) => +e.getAttribute("data-swiper-slide-index") === t).column;
                } else e = r.getSlideIndexByData(a);
                let t = l ? Math.ceil(r.slides.length / r.params.grid.rows) : r.slides.length,
                  { centeredSlides: i } = r.params,
                  n = r.params.slidesPerView;
                "auto" === n
                  ? (n = r.slidesPerViewDynamic())
                  : ((n = Math.ceil(parseFloat(r.params.slidesPerView, 10))), i && n % 2 == 0 && (n += 1));
                let o = t - e < n;
                if (
                  (i && (o = o || e < Math.ceil(n / 2)),
                  s && i && "auto" !== r.params.slidesPerView && !l && (o = !1),
                  o)
                ) {
                  let s = i
                    ? e < r.activeIndex
                      ? "prev"
                      : "next"
                    : e - r.activeIndex - 1 < r.params.slidesPerView
                      ? "next"
                      : "prev";
                  r.loopFix({
                    direction: s,
                    slideTo: !0,
                    activeSlideIndex: "next" === s ? e + 1 : e - t + 1,
                    slideRealIndex: "next" === s ? r.realIndex : void 0,
                  });
                }
                if (l) {
                  let e = a * r.params.grid.rows;
                  a = r.slides.find((t) => +t.getAttribute("data-swiper-slide-index") === e).column;
                } else a = r.getSlideIndexByData(a);
              }
            return (
              requestAnimationFrame(() => {
                r.slideTo(a, t, i, s);
              }),
              r
            );
          },
          slideNext: function (e, t, i) {
            void 0 === t && (t = !0);
            let s = this,
              { enabled: r, params: l, animating: a } = s;
            if (!r || s.destroyed) return s;
            void 0 === e && (e = s.params.speed);
            let n = l.slidesPerGroup;
            "auto" === l.slidesPerView &&
              1 === l.slidesPerGroup &&
              l.slidesPerGroupAuto &&
              (n = Math.max(s.slidesPerViewDynamic("current", !0), 1));
            let o = s.activeIndex < l.slidesPerGroupSkip ? 1 : n,
              d = s.virtual && l.virtual.enabled;
            if (l.loop) {
              if (a && !d && l.loopPreventsSliding) return !1;
              if (
                (s.loopFix({ direction: "next" }),
                (s._clientLeft = s.wrapperEl.clientLeft),
                s.activeIndex === s.slides.length - 1 && l.cssMode)
              )
                return (
                  requestAnimationFrame(() => {
                    s.slideTo(s.activeIndex + o, e, t, i);
                  }),
                  !0
                );
            }
            return l.rewind && s.isEnd ? s.slideTo(0, e, t, i) : s.slideTo(s.activeIndex + o, e, t, i);
          },
          slidePrev: function (e, t, i) {
            void 0 === t && (t = !0);
            let s = this,
              { params: r, snapGrid: l, slidesGrid: a, rtlTranslate: n, enabled: o, animating: d } = s;
            if (!o || s.destroyed) return s;
            void 0 === e && (e = s.params.speed);
            let c = s.virtual && r.virtual.enabled;
            if (r.loop) {
              if (d && !c && r.loopPreventsSliding) return !1;
              (s.loopFix({ direction: "prev" }), (s._clientLeft = s.wrapperEl.clientLeft));
            }
            function p(e) {
              return e < 0 ? -Math.floor(Math.abs(e)) : Math.floor(e);
            }
            let u = p(n ? s.translate : -s.translate),
              h = l.map((e) => p(e)),
              f = r.freeMode && r.freeMode.enabled,
              m = l[h.indexOf(u) - 1];
            if (void 0 === m && (r.cssMode || f)) {
              let e;
              (l.forEach((t, i) => {
                u >= t && (e = i);
              }),
                void 0 !== e && (m = f ? l[e] : l[e > 0 ? e - 1 : e]));
            }
            let v = 0;
            if (
              (void 0 !== m &&
                ((v = a.indexOf(m)) < 0 && (v = s.activeIndex - 1),
                "auto" === r.slidesPerView &&
                  1 === r.slidesPerGroup &&
                  r.slidesPerGroupAuto &&
                  (v = Math.max((v = v - s.slidesPerViewDynamic("previous", !0) + 1), 0))),
              r.rewind && s.isBeginning)
            ) {
              let r =
                s.params.virtual && s.params.virtual.enabled && s.virtual
                  ? s.virtual.slides.length - 1
                  : s.slides.length - 1;
              return s.slideTo(r, e, t, i);
            }
            return r.loop && 0 === s.activeIndex && r.cssMode
              ? (requestAnimationFrame(() => {
                  s.slideTo(v, e, t, i);
                }),
                !0)
              : s.slideTo(v, e, t, i);
          },
          slideReset: function (e, t, i) {
            if ((void 0 === t && (t = !0), !this.destroyed))
              return (void 0 === e && (e = this.params.speed), this.slideTo(this.activeIndex, e, t, i));
          },
          slideToClosest: function (e, t, i, s) {
            if ((void 0 === t && (t = !0), void 0 === s && (s = 0.5), this.destroyed)) return;
            void 0 === e && (e = this.params.speed);
            let r = this.activeIndex,
              l = Math.min(this.params.slidesPerGroupSkip, r),
              a = l + Math.floor((r - l) / this.params.slidesPerGroup),
              n = this.rtlTranslate ? this.translate : -this.translate;
            if (n >= this.snapGrid[a]) {
              let e = this.snapGrid[a];
              n - e > (this.snapGrid[a + 1] - e) * s && (r += this.params.slidesPerGroup);
            } else {
              let e = this.snapGrid[a - 1];
              n - e <= (this.snapGrid[a] - e) * s && (r -= this.params.slidesPerGroup);
            }
            return (
              (r = Math.min((r = Math.max(r, 0)), this.slidesGrid.length - 1)),
              this.slideTo(r, e, t, i)
            );
          },
          slideToClickedSlide: function () {
            let e,
              t = this;
            if (t.destroyed) return;
            let { params: i, slidesEl: s } = t,
              r = "auto" === i.slidesPerView ? t.slidesPerViewDynamic() : i.slidesPerView,
              l = t.getSlideIndexWhenGrid(t.clickedIndex),
              a = t.isElement ? "swiper-slide" : `.${i.slideClass}`,
              n = t.grid && t.params.grid && t.params.grid.rows > 1;
            if (i.loop) {
              if (t.animating) return;
              ((e = parseInt(t.clickedSlide.getAttribute("data-swiper-slide-index"), 10)),
                i.centeredSlides
                  ? t.slideToLoop(e)
                  : l > (n ? (t.slides.length - r) / 2 - (t.params.grid.rows - 1) : t.slides.length - r)
                    ? (t.loopFix(),
                      (l = t.getSlideIndex(S(s, `${a}[data-swiper-slide-index="${e}"]`)[0])),
                      u(() => {
                        t.slideTo(l);
                      }))
                    : t.slideTo(l));
            } else t.slideTo(l);
          },
        },
        loop: {
          loopCreate: function (e, t) {
            let i,
              s = this,
              { params: r, slidesEl: l } = s;
            if (!r.loop || (s.virtual && s.params.virtual.enabled)) return;
            let a = s.grid && r.grid && r.grid.rows > 1;
            r.loopAddBlankSlides &&
              (r.slidesPerGroup > 1 || a) &&
              ((i = S(l, `.${r.slideBlankClass}`)).forEach((e) => {
                e.remove();
              }),
              i.length > 0 && (s.recalcSlides(), s.updateSlides()));
            let n = r.slidesPerGroup * (a ? r.grid.rows : 1),
              o = s.slides.length % n != 0,
              d = a && s.slides.length % r.grid.rows != 0,
              c = (e) => {
                for (let t = 0; t < e; t += 1) {
                  let e = s.isElement
                    ? y("swiper-slide", [r.slideBlankClass])
                    : y("div", [r.slideClass, r.slideBlankClass]);
                  s.slidesEl.append(e);
                }
              };
            (o
              ? r.loopAddBlankSlides
                ? (c(n - (s.slides.length % n)), s.recalcSlides(), s.updateSlides())
                : T(
                    "Swiper Loop Warning: The number of slides is not even to slidesPerGroup, loop mode may not function properly. You need to add more slides (or make duplicates, or empty slides)",
                  )
              : d &&
                (r.loopAddBlankSlides
                  ? (c(r.grid.rows - (s.slides.length % r.grid.rows)), s.recalcSlides(), s.updateSlides())
                  : T(
                      "Swiper Loop Warning: The number of slides is not even to grid.rows, loop mode may not function properly. You need to add more slides (or make duplicates, or empty slides)",
                    )),
              S(l, `.${r.slideClass}, swiper-slide`).forEach((e, t) => {
                e.setAttribute("data-swiper-slide-index", t);
              }),
              s.loopFix({ slideRealIndex: e, direction: r.centeredSlides ? void 0 : "next", initial: t }));
          },
          loopFix: function (e) {
            let {
                slideRealIndex: t,
                slideTo: i = !0,
                direction: s,
                setTranslate: r,
                activeSlideIndex: l,
                initial: a,
                byController: n,
                byMousewheel: o,
              } = void 0 === e ? {} : e,
              d = this;
            if (!d.params.loop) return;
            d.emit("beforeLoopFix");
            let { slides: c, allowSlidePrev: p, allowSlideNext: u, slidesEl: h, params: f } = d,
              { centeredSlides: m, initialSlide: v } = f;
            if (((d.allowSlidePrev = !0), (d.allowSlideNext = !0), d.virtual && f.virtual.enabled)) {
              (i &&
                (f.centeredSlides || 0 !== d.snapIndex
                  ? f.centeredSlides && d.snapIndex < f.slidesPerView
                    ? d.slideTo(d.virtual.slides.length + d.snapIndex, 0, !1, !0)
                    : d.snapIndex === d.snapGrid.length - 1 && d.slideTo(d.virtual.slidesBefore, 0, !1, !0)
                  : d.slideTo(d.virtual.slides.length, 0, !1, !0)),
                (d.allowSlidePrev = p),
                (d.allowSlideNext = u),
                d.emit("loopFix"));
              return;
            }
            let g = f.slidesPerView;
            "auto" === g
              ? (g = d.slidesPerViewDynamic())
              : ((g = Math.ceil(parseFloat(f.slidesPerView, 10))), m && g % 2 == 0 && (g += 1));
            let w = f.slidesPerGroupAuto ? g : f.slidesPerGroup,
              S = m ? Math.max(w, Math.ceil(g / 2)) : w;
            (S % w != 0 && (S += w - (S % w)), (d.loopedSlides = S += f.loopAdditionalSlides));
            let b = d.grid && f.grid && f.grid.rows > 1;
            c.length < g + S || ("cards" === d.params.effect && c.length < g + 2 * S)
              ? T(
                  "Swiper Loop Warning: The number of slides is not enough for loop mode, it will be disabled or not function properly. You need to add more slides (or make duplicates) or lower the values of slidesPerView and slidesPerGroup parameters",
                )
              : b &&
                "row" === f.grid.fill &&
                T("Swiper Loop Warning: Loop mode is not compatible with grid.fill = `row`");
            let y = [],
              E = [],
              x = b ? Math.ceil(c.length / f.grid.rows) : c.length,
              M = a && x - v < g && !m,
              C = M ? v : d.activeIndex;
            void 0 === l
              ? (l = d.getSlideIndex(c.find((e) => e.classList.contains(f.slideActiveClass))))
              : (C = l);
            let P = "next" === s || !s,
              k = "prev" === s || !s,
              O = 0,
              _ = 0,
              L = (b ? c[l].column : l) + (m && void 0 === r ? -g / 2 + 0.5 : 0);
            if (L < S) {
              O = Math.max(S - L, w);
              for (let e = 0; e < S - L; e += 1) {
                let t = e - Math.floor(e / x) * x;
                if (b) {
                  let e = x - t - 1;
                  for (let t = c.length - 1; t >= 0; t -= 1) c[t].column === e && y.push(t);
                } else y.push(x - t - 1);
              }
            } else if (L + g > x - S) {
              ((_ = Math.max(L - (x - 2 * S), w)), M && (_ = Math.max(_, g - x + v + 1)));
              for (let e = 0; e < _; e += 1) {
                let t = e - Math.floor(e / x) * x;
                b
                  ? c.forEach((e, i) => {
                      e.column === t && E.push(i);
                    })
                  : E.push(t);
              }
            }
            if (
              ((d.__preventObserver__ = !0),
              requestAnimationFrame(() => {
                d.__preventObserver__ = !1;
              }),
              "cards" === d.params.effect &&
                c.length < g + 2 * S &&
                (E.includes(l) && E.splice(E.indexOf(l), 1), y.includes(l) && y.splice(y.indexOf(l), 1)),
              k &&
                y.forEach((e) => {
                  ((c[e].swiperLoopMoveDOM = !0), h.prepend(c[e]), (c[e].swiperLoopMoveDOM = !1));
                }),
              P &&
                E.forEach((e) => {
                  ((c[e].swiperLoopMoveDOM = !0), h.append(c[e]), (c[e].swiperLoopMoveDOM = !1));
                }),
              d.recalcSlides(),
              "auto" === f.slidesPerView
                ? d.updateSlides()
                : b &&
                  ((y.length > 0 && k) || (E.length > 0 && P)) &&
                  d.slides.forEach((e, t) => {
                    d.grid.updateSlide(t, e, d.slides);
                  }),
              f.watchSlidesProgress && d.updateSlidesOffset(),
              i)
            ) {
              if (y.length > 0 && k) {
                if (void 0 === t) {
                  let e = d.slidesGrid[C],
                    t = d.slidesGrid[C + O] - e;
                  o
                    ? d.setTranslate(d.translate - t)
                    : (d.slideTo(C + Math.ceil(O), 0, !1, !0),
                      r &&
                        ((d.touchEventsData.startTranslate = d.touchEventsData.startTranslate - t),
                        (d.touchEventsData.currentTranslate = d.touchEventsData.currentTranslate - t)));
                } else if (r) {
                  let e = b ? y.length / f.grid.rows : y.length;
                  (d.slideTo(d.activeIndex + e, 0, !1, !0),
                    (d.touchEventsData.currentTranslate = d.translate));
                }
              } else if (E.length > 0 && P)
                if (void 0 === t) {
                  let e = d.slidesGrid[C],
                    t = d.slidesGrid[C - _] - e;
                  o
                    ? d.setTranslate(d.translate - t)
                    : (d.slideTo(C - _, 0, !1, !0),
                      r &&
                        ((d.touchEventsData.startTranslate = d.touchEventsData.startTranslate - t),
                        (d.touchEventsData.currentTranslate = d.touchEventsData.currentTranslate - t)));
                } else {
                  let e = b ? E.length / f.grid.rows : E.length;
                  d.slideTo(d.activeIndex - e, 0, !1, !0);
                }
            }
            if (
              ((d.allowSlidePrev = p), (d.allowSlideNext = u), d.controller && d.controller.control && !n)
            ) {
              let e = {
                slideRealIndex: t,
                direction: s,
                setTranslate: r,
                activeSlideIndex: l,
                byController: !0,
              };
              Array.isArray(d.controller.control)
                ? d.controller.control.forEach((t) => {
                    !t.destroyed &&
                      t.params.loop &&
                      t.loopFix({ ...e, slideTo: t.params.slidesPerView === f.slidesPerView && i });
                  })
                : d.controller.control instanceof d.constructor &&
                  d.controller.control.params.loop &&
                  d.controller.control.loopFix({
                    ...e,
                    slideTo: d.controller.control.params.slidesPerView === f.slidesPerView && i,
                  });
            }
            d.emit("loopFix");
          },
          loopDestroy: function () {
            let { params: e, slidesEl: t } = this;
            if (!e.loop || !t || (this.virtual && this.params.virtual.enabled)) return;
            this.recalcSlides();
            let i = [];
            (this.slides.forEach((e) => {
              i[
                void 0 === e.swiperSlideIndex
                  ? +e.getAttribute("data-swiper-slide-index")
                  : e.swiperSlideIndex
              ] = e;
            }),
              this.slides.forEach((e) => {
                e.removeAttribute("data-swiper-slide-index");
              }),
              i.forEach((e) => {
                t.append(e);
              }),
              this.recalcSlides(),
              this.slideTo(this.realIndex, 0));
          },
        },
        grabCursor: {
          setGrabCursor: function (e) {
            let t = this;
            if (!t.params.simulateTouch || (t.params.watchOverflow && t.isLocked) || t.params.cssMode) return;
            let i = "container" === t.params.touchEventsTarget ? t.el : t.wrapperEl;
            (t.isElement && (t.__preventObserver__ = !0),
              (i.style.cursor = "move"),
              (i.style.cursor = e ? "grabbing" : "grab"),
              t.isElement &&
                requestAnimationFrame(() => {
                  t.__preventObserver__ = !1;
                }));
          },
          unsetGrabCursor: function () {
            let e = this;
            (e.params.watchOverflow && e.isLocked) ||
              e.params.cssMode ||
              (e.isElement && (e.__preventObserver__ = !0),
              (e["container" === e.params.touchEventsTarget ? "el" : "wrapperEl"].style.cursor = ""),
              e.isElement &&
                requestAnimationFrame(() => {
                  e.__preventObserver__ = !1;
                }));
          },
        },
        events: {
          attachEvents: function () {
            let { params: e } = this;
            ((this.onTouchStart = $.bind(this)),
              (this.onTouchMove = j.bind(this)),
              (this.onTouchEnd = F.bind(this)),
              (this.onDocumentTouchStart = X.bind(this)),
              e.cssMode && (this.onScroll = W.bind(this)),
              (this.onClick = H.bind(this)),
              (this.onLoad = q.bind(this)),
              Y(this, "on"));
          },
          detachEvents: function () {
            Y(this, "off");
          },
        },
        breakpoints: {
          setBreakpoint: function () {
            let e = this,
              { realIndex: t, initialized: i, params: s, el: r } = e,
              l = s.breakpoints;
            if (!l || (l && 0 === Object.keys(l).length)) return;
            let a = o(),
              n = "window" !== s.breakpointsBase && s.breakpointsBase ? "container" : s.breakpointsBase,
              d =
                ["window", "container"].includes(s.breakpointsBase) || !s.breakpointsBase
                  ? e.el
                  : a.querySelector(s.breakpointsBase),
              c = e.getBreakpoint(l, n, d);
            if (!c || e.currentBreakpoint === c) return;
            let p = (c in l ? l[c] : void 0) || e.originalParams,
              u = U(e, s),
              h = U(e, p),
              f = e.params.grabCursor,
              m = p.grabCursor,
              g = s.enabled;
            (u && !h
              ? (r.classList.remove(
                  `${s.containerModifierClass}grid`,
                  `${s.containerModifierClass}grid-column`,
                ),
                e.emitContainerClasses())
              : !u &&
                h &&
                (r.classList.add(`${s.containerModifierClass}grid`),
                ((p.grid.fill && "column" === p.grid.fill) || (!p.grid.fill && "column" === s.grid.fill)) &&
                  r.classList.add(`${s.containerModifierClass}grid-column`),
                e.emitContainerClasses()),
              f && !m ? e.unsetGrabCursor() : !f && m && e.setGrabCursor(),
              ["navigation", "pagination", "scrollbar"].forEach((t) => {
                if (void 0 === p[t]) return;
                let i = s[t] && s[t].enabled,
                  r = p[t] && p[t].enabled;
                (i && !r && e[t].disable(), !i && r && e[t].enable());
              }));
            let w = p.direction && p.direction !== s.direction,
              S = s.loop && (p.slidesPerView !== s.slidesPerView || w),
              b = s.loop;
            (w && i && e.changeDirection(), v(e.params, p));
            let T = e.params.enabled,
              y = e.params.loop;
            (Object.assign(e, {
              allowTouchMove: e.params.allowTouchMove,
              allowSlideNext: e.params.allowSlideNext,
              allowSlidePrev: e.params.allowSlidePrev,
            }),
              g && !T ? e.disable() : !g && T && e.enable(),
              (e.currentBreakpoint = c),
              e.emit("_beforeBreakpoint", p),
              i &&
                (S
                  ? (e.loopDestroy(), e.loopCreate(t), e.updateSlides())
                  : !b && y
                    ? (e.loopCreate(t), e.updateSlides())
                    : b && !y && e.loopDestroy()),
              e.emit("breakpoint", p));
          },
          getBreakpoint: function (e, t, i) {
            if ((void 0 === t && (t = "window"), !e || ("container" === t && !i))) return;
            let s = !1,
              r = c(),
              l = "window" === t ? r.innerHeight : i.clientHeight,
              a = Object.keys(e).map((e) =>
                "string" == typeof e && 0 === e.indexOf("@")
                  ? { value: l * parseFloat(e.substr(1)), point: e }
                  : { value: e, point: e },
              );
            a.sort((e, t) => parseInt(e.value, 10) - parseInt(t.value, 10));
            for (let e = 0; e < a.length; e += 1) {
              let { point: l, value: n } = a[e];
              "window" === t
                ? r.matchMedia(`(min-width: ${n}px)`).matches && (s = l)
                : n <= i.clientWidth && (s = l);
            }
            return s || "max";
          },
        },
        checkOverflow: {
          checkOverflow: function () {
            let { isLocked: e, params: t } = this,
              { slidesOffsetBefore: i } = t;
            if (i) {
              let e = this.slides.length - 1,
                t = this.slidesGrid[e] + this.slidesSizesGrid[e] + 2 * i;
              this.isLocked = this.size > t;
            } else this.isLocked = 1 === this.snapGrid.length;
            (!0 === t.allowSlideNext && (this.allowSlideNext = !this.isLocked),
              !0 === t.allowSlidePrev && (this.allowSlidePrev = !this.isLocked),
              e && e !== this.isLocked && (this.isEnd = !1),
              e !== this.isLocked && this.emit(this.isLocked ? "lock" : "unlock"));
          },
        },
        classes: {
          addClasses: function () {
            var e, t;
            let i,
              { classNames: s, params: r, rtl: l, el: a, device: n } = this,
              o =
                ((e = [
                  "initialized",
                  r.direction,
                  { "free-mode": this.params.freeMode && r.freeMode.enabled },
                  { autoheight: r.autoHeight },
                  { rtl: l },
                  { grid: r.grid && r.grid.rows > 1 },
                  { "grid-column": r.grid && r.grid.rows > 1 && "column" === r.grid.fill },
                  { android: n.android },
                  { ios: n.ios },
                  { "css-mode": r.cssMode },
                  { centered: r.cssMode && r.centeredSlides },
                  { "watch-progress": r.watchSlidesProgress },
                ]),
                (t = r.containerModifierClass),
                (i = []),
                e.forEach((e) => {
                  "object" == typeof e
                    ? Object.keys(e).forEach((s) => {
                        e[s] && i.push(t + s);
                      })
                    : "string" == typeof e && i.push(t + e);
                }),
                i);
            (s.push(...o), a.classList.add(...s), this.emitContainerClasses());
          },
          removeClasses: function () {
            let { el: e, classNames: t } = this;
            e && "string" != typeof e && (e.classList.remove(...t), this.emitContainerClasses());
          },
        },
      },
      J = {};
    class Q {
      constructor() {
        let e, t;
        for (var i = arguments.length, s = Array(i), r = 0; r < i; r++) s[r] = arguments[r];
        (1 === s.length && s[0].constructor && "Object" === Object.prototype.toString.call(s[0]).slice(8, -1)
          ? (t = s[0])
          : ([e, t] = s),
          t || (t = {}),
          (t = v({}, t)),
          e && !t.el && (t.el = e));
        const l = o();
        if (t.el && "string" == typeof t.el && l.querySelectorAll(t.el).length > 1) {
          const e = [];
          return (
            l.querySelectorAll(t.el).forEach((i) => {
              let s = v({}, t, { el: i });
              e.push(new Q(s));
            }),
            e
          );
        }
        const a = this;
        ((a.__swiper__ = !0),
          (a.support = _()),
          (a.device = L({ userAgent: t.userAgent })),
          (a.browser = I()),
          (a.eventsListeners = {}),
          (a.eventsAnyListeners = []),
          (a.modules = [...a.__modules__]),
          t.modules && Array.isArray(t.modules) && a.modules.push(...t.modules));
        const n = {};
        a.modules.forEach((e) => {
          var i;
          e({
            params: t,
            swiper: a,
            extendParams:
              ((i = t),
              function (e) {
                void 0 === e && (e = {});
                let t = Object.keys(e)[0],
                  s = e[t];
                ("object" != typeof s ||
                  null === s ||
                  (!0 === i[t] && (i[t] = { enabled: !0 }),
                  "navigation" === t &&
                    i[t] &&
                    i[t].enabled &&
                    !i[t].prevEl &&
                    !i[t].nextEl &&
                    (i[t].auto = !0),
                  ["pagination", "scrollbar"].indexOf(t) >= 0 &&
                    i[t] &&
                    i[t].enabled &&
                    !i[t].el &&
                    (i[t].auto = !0),
                  t in i &&
                    "enabled" in s &&
                    ("object" != typeof i[t] || "enabled" in i[t] || (i[t].enabled = !0),
                    i[t] || (i[t] = { enabled: !1 }))),
                  v(n, e));
              }),
            on: a.on.bind(a),
            once: a.once.bind(a),
            off: a.off.bind(a),
            emit: a.emit.bind(a),
          });
        });
        const d = v({}, K, n);
        return (
          (a.params = v({}, d, J, t)),
          (a.originalParams = v({}, a.params)),
          (a.passedParams = v({}, t)),
          a.params &&
            a.params.on &&
            Object.keys(a.params.on).forEach((e) => {
              a.on(e, a.params.on[e]);
            }),
          a.params && a.params.onAny && a.onAny(a.params.onAny),
          Object.assign(a, {
            enabled: a.params.enabled,
            el: e,
            classNames: [],
            slides: [],
            slidesGrid: [],
            snapGrid: [],
            slidesSizesGrid: [],
            isHorizontal: () => "horizontal" === a.params.direction,
            isVertical: () => "vertical" === a.params.direction,
            activeIndex: 0,
            realIndex: 0,
            isBeginning: !0,
            isEnd: !1,
            translate: 0,
            previousTranslate: 0,
            progress: 0,
            velocity: 0,
            animating: !1,
            cssOverflowAdjustment() {
              return 8388608 * Math.trunc(this.translate / 8388608);
            },
            allowSlideNext: a.params.allowSlideNext,
            allowSlidePrev: a.params.allowSlidePrev,
            touchEventsData: {
              isTouched: void 0,
              isMoved: void 0,
              allowTouchCallbacks: void 0,
              touchStartTime: void 0,
              isScrolling: void 0,
              currentTranslate: void 0,
              startTranslate: void 0,
              allowThresholdMove: void 0,
              focusableElements: a.params.focusableElements,
              lastClickTime: 0,
              clickTimeout: void 0,
              velocities: [],
              allowMomentumBounce: void 0,
              startMoving: void 0,
              pointerId: null,
              touchId: null,
            },
            allowClick: !0,
            allowTouchMove: a.params.allowTouchMove,
            touches: { startX: 0, startY: 0, currentX: 0, currentY: 0, diff: 0 },
            imagesToLoad: [],
            imagesLoaded: 0,
          }),
          a.emit("_swiper"),
          a.params.init && a.init(),
          a
        );
      }
      getDirectionLabel(e) {
        return this.isHorizontal()
          ? e
          : {
              width: "height",
              "margin-top": "margin-left",
              "margin-bottom ": "margin-right",
              "margin-left": "margin-top",
              "margin-right": "margin-bottom",
              "padding-left": "padding-top",
              "padding-right": "padding-bottom",
              marginRight: "marginBottom",
            }[e];
      }
      getSlideIndex(e) {
        let { slidesEl: t, params: i } = this,
          s = C(S(t, `.${i.slideClass}, swiper-slide`)[0]);
        return C(e) - s;
      }
      getSlideIndexByData(e) {
        return this.getSlideIndex(this.slides.find((t) => +t.getAttribute("data-swiper-slide-index") === e));
      }
      getSlideIndexWhenGrid(e) {
        return (
          this.grid &&
            this.params.grid &&
            this.params.grid.rows > 1 &&
            ("column" === this.params.grid.fill
              ? (e = Math.floor(e / this.params.grid.rows))
              : "row" === this.params.grid.fill &&
                (e %= Math.ceil(this.slides.length / this.params.grid.rows))),
          e
        );
      }
      recalcSlides() {
        let { slidesEl: e, params: t } = this;
        this.slides = S(e, `.${t.slideClass}, swiper-slide`);
      }
      enable() {
        this.enabled ||
          ((this.enabled = !0), this.params.grabCursor && this.setGrabCursor(), this.emit("enable"));
      }
      disable() {
        this.enabled &&
          ((this.enabled = !1), this.params.grabCursor && this.unsetGrabCursor(), this.emit("disable"));
      }
      setProgress(e, t) {
        e = Math.min(Math.max(e, 0), 1);
        let i = this.minTranslate(),
          s = (this.maxTranslate() - i) * e + i;
        (this.translateTo(s, void 0 === t ? 0 : t), this.updateActiveIndex(), this.updateSlidesClasses());
      }
      emitContainerClasses() {
        let e = this;
        if (!e.params._emitClasses || !e.el) return;
        let t = e.el.className
          .split(" ")
          .filter((t) => 0 === t.indexOf("swiper") || 0 === t.indexOf(e.params.containerModifierClass));
        e.emit("_containerClasses", t.join(" "));
      }
      getSlideClasses(e) {
        let t = this;
        return t.destroyed
          ? ""
          : e.className
              .split(" ")
              .filter((e) => 0 === e.indexOf("swiper-slide") || 0 === e.indexOf(t.params.slideClass))
              .join(" ");
      }
      emitSlidesClasses() {
        let e = this;
        if (!e.params._emitClasses || !e.el) return;
        let t = [];
        (e.slides.forEach((i) => {
          let s = e.getSlideClasses(i);
          (t.push({ slideEl: i, classNames: s }), e.emit("_slideClass", i, s));
        }),
          e.emit("_slideClasses", t));
      }
      slidesPerViewDynamic(e, t) {
        (void 0 === e && (e = "current"), void 0 === t && (t = !1));
        let { params: i, slides: s, slidesGrid: r, slidesSizesGrid: l, size: a, activeIndex: n } = this,
          o = 1;
        if ("number" == typeof i.slidesPerView) return i.slidesPerView;
        if (i.centeredSlides) {
          let e,
            t = s[n] ? Math.ceil(s[n].swiperSlideSize) : 0;
          for (let i = n + 1; i < s.length; i += 1)
            s[i] && !e && ((t += Math.ceil(s[i].swiperSlideSize)), (o += 1), t > a && (e = !0));
          for (let i = n - 1; i >= 0; i -= 1)
            s[i] && !e && ((t += s[i].swiperSlideSize), (o += 1), t > a && (e = !0));
        } else if ("current" === e)
          for (let e = n + 1; e < s.length; e += 1)
            (t ? r[e] + l[e] - r[n] < a : r[e] - r[n] < a) && (o += 1);
        else for (let e = n - 1; e >= 0; e -= 1) r[n] - r[e] < a && (o += 1);
        return o;
      }
      update() {
        let e,
          t = this;
        if (!t || t.destroyed) return;
        let { snapGrid: i, params: s } = t;
        function r() {
          let e = Math.min(
            Math.max(t.rtlTranslate ? -1 * t.translate : t.translate, t.maxTranslate()),
            t.minTranslate(),
          );
          (t.setTranslate(e), t.updateActiveIndex(), t.updateSlidesClasses());
        }
        if (
          (s.breakpoints && t.setBreakpoint(),
          [...t.el.querySelectorAll('[loading="lazy"]')].forEach((e) => {
            e.complete && G(t, e);
          }),
          t.updateSize(),
          t.updateSlides(),
          t.updateProgress(),
          t.updateSlidesClasses(),
          s.freeMode && s.freeMode.enabled && !s.cssMode)
        )
          (r(), s.autoHeight && t.updateAutoHeight());
        else {
          if (("auto" === s.slidesPerView || s.slidesPerView > 1) && t.isEnd && !s.centeredSlides) {
            let i = t.virtual && s.virtual.enabled ? t.virtual.slides : t.slides;
            e = t.slideTo(i.length - 1, 0, !1, !0);
          } else e = t.slideTo(t.activeIndex, 0, !1, !0);
          e || r();
        }
        (s.watchOverflow && i !== t.snapGrid && t.checkOverflow(), t.emit("update"));
      }
      changeDirection(e, t) {
        void 0 === t && (t = !0);
        let i = this.params.direction;
        return (
          e || (e = "horizontal" === i ? "vertical" : "horizontal"),
          e === i ||
            ("horizontal" !== e && "vertical" !== e) ||
            (this.el.classList.remove(`${this.params.containerModifierClass}${i}`),
            this.el.classList.add(`${this.params.containerModifierClass}${e}`),
            this.emitContainerClasses(),
            (this.params.direction = e),
            this.slides.forEach((t) => {
              "vertical" === e ? (t.style.width = "") : (t.style.height = "");
            }),
            this.emit("changeDirection"),
            t && this.update()),
          this
        );
      }
      changeLanguageDirection(e) {
        (!this.rtl || "rtl" !== e) &&
          (this.rtl || "ltr" !== e) &&
          ((this.rtl = "rtl" === e),
          (this.rtlTranslate = "horizontal" === this.params.direction && this.rtl),
          this.rtl
            ? (this.el.classList.add(`${this.params.containerModifierClass}rtl`), (this.el.dir = "rtl"))
            : (this.el.classList.remove(`${this.params.containerModifierClass}rtl`), (this.el.dir = "ltr")),
          this.update());
      }
      mount(e) {
        let t = this;
        if (t.mounted) return !0;
        let i = e || t.params.el;
        if (("string" == typeof i && (i = document.querySelector(i)), !i)) return !1;
        ((i.swiper = t),
          i.parentNode &&
            i.parentNode.host &&
            i.parentNode.host.nodeName === t.params.swiperElementNodeName.toUpperCase() &&
            (t.isElement = !0));
        let s = () => `.${(t.params.wrapperClass || "").trim().split(" ").join(".")}`,
          r =
            i && i.shadowRoot && i.shadowRoot.querySelector ? i.shadowRoot.querySelector(s()) : S(i, s())[0];
        return (
          !r &&
            t.params.createElements &&
            ((r = y("div", t.params.wrapperClass)),
            i.append(r),
            S(i, `.${t.params.slideClass}`).forEach((e) => {
              r.append(e);
            })),
          Object.assign(t, {
            el: i,
            wrapperEl: r,
            slidesEl: t.isElement && !i.parentNode.host.slideSlots ? i.parentNode.host : r,
            hostEl: t.isElement ? i.parentNode.host : i,
            mounted: !0,
            rtl: "rtl" === i.dir.toLowerCase() || "rtl" === M(i, "direction"),
            rtlTranslate:
              "horizontal" === t.params.direction &&
              ("rtl" === i.dir.toLowerCase() || "rtl" === M(i, "direction")),
            wrongRTL: "-webkit-box" === M(r, "display"),
          }),
          !0
        );
      }
      init(e) {
        let t = this;
        if (t.initialized || !1 === t.mount(e)) return t;
        (t.emit("beforeInit"),
          t.params.breakpoints && t.setBreakpoint(),
          t.addClasses(),
          t.updateSize(),
          t.updateSlides(),
          t.params.watchOverflow && t.checkOverflow(),
          t.params.grabCursor && t.enabled && t.setGrabCursor(),
          t.params.loop && t.virtual && t.params.virtual.enabled
            ? t.slideTo(
                t.params.initialSlide + t.virtual.slidesBefore,
                0,
                t.params.runCallbacksOnInit,
                !1,
                !0,
              )
            : t.slideTo(t.params.initialSlide, 0, t.params.runCallbacksOnInit, !1, !0),
          t.params.loop && t.loopCreate(void 0, !0),
          t.attachEvents());
        let i = [...t.el.querySelectorAll('[loading="lazy"]')];
        return (
          t.isElement && i.push(...t.hostEl.querySelectorAll('[loading="lazy"]')),
          i.forEach((e) => {
            e.complete
              ? G(t, e)
              : e.addEventListener("load", (e) => {
                  G(t, e.target);
                });
          }),
          N(t),
          (t.initialized = !0),
          N(t),
          t.emit("init"),
          t.emit("afterInit"),
          t
        );
      }
      destroy(e, t) {
        (void 0 === e && (e = !0), void 0 === t && (t = !0));
        let i = this,
          { params: s, el: r, wrapperEl: l, slides: a } = i;
        return (
          void 0 === i.params ||
            i.destroyed ||
            (i.emit("beforeDestroy"),
            (i.initialized = !1),
            i.detachEvents(),
            s.loop && i.loopDestroy(),
            t &&
              (i.removeClasses(),
              r && "string" != typeof r && r.removeAttribute("style"),
              l && l.removeAttribute("style"),
              a &&
                a.length &&
                a.forEach((e) => {
                  (e.classList.remove(
                    s.slideVisibleClass,
                    s.slideFullyVisibleClass,
                    s.slideActiveClass,
                    s.slideNextClass,
                    s.slidePrevClass,
                  ),
                    e.removeAttribute("style"),
                    e.removeAttribute("data-swiper-slide-index"));
                })),
            i.emit("destroy"),
            Object.keys(i.eventsListeners).forEach((e) => {
              i.off(e);
            }),
            !1 !== e && (i.el && "string" != typeof i.el && (i.el.swiper = null), p(i)),
            (i.destroyed = !0)),
          null
        );
      }
      static extendDefaults(e) {
        v(J, e);
      }
      static get extendedDefaults() {
        return J;
      }
      static get defaults() {
        return K;
      }
      static installModule(e) {
        Q.prototype.__modules__ || (Q.prototype.__modules__ = []);
        let t = Q.prototype.__modules__;
        "function" == typeof e && 0 > t.indexOf(e) && t.push(e);
      }
      static use(e) {
        return (Array.isArray(e) ? e.forEach((e) => Q.installModule(e)) : Q.installModule(e), Q);
      }
    }
    (Object.keys(Z).forEach((e) => {
      Object.keys(Z[e]).forEach((t) => {
        Q.prototype[t] = Z[e][t];
      });
    }),
      Q.use([
        function (e) {
          let { swiper: t, on: i, emit: s } = e,
            r = c(),
            l = null,
            a = null,
            n = () => {
              t && !t.destroyed && t.initialized && (s("beforeResize"), s("resize"));
            },
            o = () => {
              t && !t.destroyed && t.initialized && s("orientationchange");
            };
          (i("init", () => {
            t.params.resizeObserver && void 0 !== r.ResizeObserver
              ? t &&
                !t.destroyed &&
                t.initialized &&
                (l = new ResizeObserver((e) => {
                  a = r.requestAnimationFrame(() => {
                    let { width: i, height: s } = t,
                      r = i,
                      l = s;
                    (e.forEach((e) => {
                      let { contentBoxSize: i, contentRect: s, target: a } = e;
                      (a && a !== t.el) ||
                        ((r = s ? s.width : (i[0] || i).inlineSize),
                        (l = s ? s.height : (i[0] || i).blockSize));
                    }),
                      (r !== i || l !== s) && n());
                  });
                })).observe(t.el)
              : (r.addEventListener("resize", n), r.addEventListener("orientationchange", o));
          }),
            i("destroy", () => {
              (a && r.cancelAnimationFrame(a),
                l && l.unobserve && t.el && (l.unobserve(t.el), (l = null)),
                r.removeEventListener("resize", n),
                r.removeEventListener("orientationchange", o));
            }));
        },
        function (e) {
          let { swiper: t, extendParams: i, on: s, emit: r } = e,
            l = [],
            a = c(),
            n = function (e, i) {
              void 0 === i && (i = {});
              let s = new (a.MutationObserver || a.WebkitMutationObserver)((e) => {
                if (t.__preventObserver__) return;
                if (1 === e.length) return void r("observerUpdate", e[0]);
                let i = function () {
                  r("observerUpdate", e[0]);
                };
                a.requestAnimationFrame ? a.requestAnimationFrame(i) : a.setTimeout(i, 0);
              });
              (s.observe(e, {
                attributes: void 0 === i.attributes || i.attributes,
                childList: t.isElement || (void 0 === i.childList || i).childList,
                characterData: void 0 === i.characterData || i.characterData,
              }),
                l.push(s));
            };
          (i({ observer: !1, observeParents: !1, observeSlideChildren: !1 }),
            s("init", () => {
              if (t.params.observer) {
                if (t.params.observeParents) {
                  let e = P(t.hostEl);
                  for (let t = 0; t < e.length; t += 1) n(e[t]);
                }
                (n(t.hostEl, { childList: t.params.observeSlideChildren }),
                  n(t.wrapperEl, { attributes: !1 }));
              }
            }),
            s("destroy", () => {
              (l.forEach((e) => {
                e.disconnect();
              }),
                l.splice(0, l.length));
            }));
        },
      ]));
    let ee = [
      "eventsPrefix",
      "injectStyles",
      "injectStylesUrls",
      "modules",
      "init",
      "_direction",
      "oneWayMovement",
      "swiperElementNodeName",
      "touchEventsTarget",
      "initialSlide",
      "_speed",
      "cssMode",
      "updateOnWindowResize",
      "resizeObserver",
      "nested",
      "focusableElements",
      "_enabled",
      "_width",
      "_height",
      "preventInteractionOnTransition",
      "userAgent",
      "url",
      "_edgeSwipeDetection",
      "_edgeSwipeThreshold",
      "_freeMode",
      "_autoHeight",
      "setWrapperSize",
      "virtualTranslate",
      "_effect",
      "breakpoints",
      "breakpointsBase",
      "_spaceBetween",
      "_slidesPerView",
      "maxBackfaceHiddenSlides",
      "_grid",
      "_slidesPerGroup",
      "_slidesPerGroupSkip",
      "_slidesPerGroupAuto",
      "_centeredSlides",
      "_centeredSlidesBounds",
      "_slidesOffsetBefore",
      "_slidesOffsetAfter",
      "normalizeSlideIndex",
      "_centerInsufficientSlides",
      "_watchOverflow",
      "roundLengths",
      "touchRatio",
      "touchAngle",
      "simulateTouch",
      "_shortSwipes",
      "_longSwipes",
      "longSwipesRatio",
      "longSwipesMs",
      "_followFinger",
      "allowTouchMove",
      "_threshold",
      "touchMoveStopPropagation",
      "touchStartPreventDefault",
      "touchStartForcePreventDefault",
      "touchReleaseOnEdges",
      "uniqueNavElements",
      "_resistance",
      "_resistanceRatio",
      "_watchSlidesProgress",
      "_grabCursor",
      "preventClicks",
      "preventClicksPropagation",
      "_slideToClickedSlide",
      "_loop",
      "loopAdditionalSlides",
      "loopAddBlankSlides",
      "loopPreventsSliding",
      "_rewind",
      "_allowSlidePrev",
      "_allowSlideNext",
      "_swipeHandler",
      "_noSwiping",
      "noSwipingClass",
      "noSwipingSelector",
      "passiveListeners",
      "containerModifierClass",
      "slideClass",
      "slideActiveClass",
      "slideVisibleClass",
      "slideFullyVisibleClass",
      "slideNextClass",
      "slidePrevClass",
      "slideBlankClass",
      "wrapperClass",
      "lazyPreloaderClass",
      "lazyPreloadPrevNext",
      "runCallbacksOnInit",
      "observer",
      "observeParents",
      "observeSlideChildren",
      "a11y",
      "_autoplay",
      "_controller",
      "coverflowEffect",
      "cubeEffect",
      "fadeEffect",
      "flipEffect",
      "creativeEffect",
      "cardsEffect",
      "hashNavigation",
      "history",
      "keyboard",
      "mousewheel",
      "_navigation",
      "_pagination",
      "parallax",
      "_scrollbar",
      "_thumbs",
      "virtual",
      "zoom",
      "control",
    ];
    function et(e) {
      return (
        "object" == typeof e &&
        null !== e &&
        e.constructor &&
        "Object" === Object.prototype.toString.call(e).slice(8, -1) &&
        !e.__swiper__
      );
    }
    function ei(e, t) {
      let i = ["__proto__", "constructor", "prototype"];
      Object.keys(t)
        .filter((e) => 0 > i.indexOf(e))
        .forEach((i) => {
          void 0 === e[i]
            ? (e[i] = t[i])
            : et(t[i]) && et(e[i]) && Object.keys(t[i]).length > 0
              ? t[i].__swiper__
                ? (e[i] = t[i])
                : ei(e[i], t[i])
              : (e[i] = t[i]);
        });
    }
    function es(e) {
      return (
        void 0 === e && (e = {}),
        e.navigation && void 0 === e.navigation.nextEl && void 0 === e.navigation.prevEl
      );
    }
    function er(e) {
      return (void 0 === e && (e = {}), e.pagination && void 0 === e.pagination.el);
    }
    function el(e) {
      return (void 0 === e && (e = {}), e.scrollbar && void 0 === e.scrollbar.el);
    }
    function ea(e) {
      void 0 === e && (e = "");
      let t = e
          .split(" ")
          .map((e) => e.trim())
          .filter((e) => !!e),
        i = [];
      return (
        t.forEach((e) => {
          0 > i.indexOf(e) && i.push(e);
        }),
        i.join(" ")
      );
    }
    function en() {
      return (en = Object.assign.bind()).apply(this, arguments);
    }
    function eo(e) {
      return e.type && e.type.displayName && e.type.displayName.includes("SwiperSlide");
    }
    function ed(e, t) {
      return "u" < typeof window ? (0, r.useEffect)(e, t) : (0, r.useLayoutEffect)(e, t);
    }
    let ec = (0, r.createContext)(null),
      ep = (0, r.createContext)(null),
      eu = (0, r.forwardRef)(function (e, t) {
        var i, s, l;
        let a,
          n,
          o,
          d,
          c,
          p,
          u,
          {
            className: h,
            tag: f = "div",
            wrapperTag: m = "div",
            children: v,
            onSwiper: g,
            ...w
          } = void 0 === e ? {} : e,
          S = !1,
          [b, T] = (0, r.useState)("swiper"),
          [y, E] = (0, r.useState)(null),
          [x, M] = (0, r.useState)(!1),
          C = (0, r.useRef)(!1),
          P = (0, r.useRef)(null),
          k = (0, r.useRef)(null),
          _ = (0, r.useRef)(null),
          L = (0, r.useRef)(null),
          I = (0, r.useRef)(null),
          A = (0, r.useRef)(null),
          z = (0, r.useRef)(null),
          G = (0, r.useRef)(null),
          {
            params: D,
            passedParams: N,
            rest: B,
            events: V,
          } = (void 0 === (i = w) && (i = {}),
          void 0 === s && (s = !0),
          (n = {}),
          (o = {}),
          ei((a = { on: {} }), K),
          (a._emitClasses = !0),
          (a.init = !1),
          (d = {}),
          (c = ee.map((e) => e.replace(/_/, ""))),
          Object.keys(Object.assign({}, i)).forEach((e) => {
            void 0 !== i[e] &&
              (c.indexOf(e) >= 0
                ? et(i[e])
                  ? ((a[e] = {}), (o[e] = {}), ei(a[e], i[e]), ei(o[e], i[e]))
                  : ((a[e] = i[e]), (o[e] = i[e]))
                : 0 === e.search(/on[A-Z]/) && "function" == typeof i[e]
                  ? s
                    ? (n[`${e[2].toLowerCase()}${e.substr(3)}`] = i[e])
                    : (a.on[`${e[2].toLowerCase()}${e.substr(3)}`] = i[e])
                  : (d[e] = i[e]));
          }),
          ["navigation", "pagination", "scrollbar"].forEach((e) => {
            (!0 === a[e] && (a[e] = {}), !1 === a[e] && delete a[e]);
          }),
          { params: a, passedParams: o, rest: d, events: n }),
          { slides: $, slots: j } =
            ((p = []),
            (u = { "container-start": [], "container-end": [], "wrapper-start": [], "wrapper-end": [] }),
            r.default.Children.toArray(v).forEach((e) => {
              if (eo(e)) p.push(e);
              else if (e.props && e.props.slot && u[e.props.slot]) u[e.props.slot].push(e);
              else if (e.props && e.props.children) {
                let t = (function e(t) {
                  let i = [];
                  return (
                    r.default.Children.toArray(t).forEach((t) => {
                      eo(t)
                        ? i.push(t)
                        : t.props && t.props.children && e(t.props.children).forEach((e) => i.push(e));
                    }),
                    i
                  );
                })(e.props.children);
                t.length > 0 ? t.forEach((e) => p.push(e)) : u["container-end"].push(e);
              } else u["container-end"].push(e);
            }),
            { slides: p, slots: u }),
          F = () => {
            M(!x);
          };
        Object.assign(D.on, {
          _containerClasses(e, t) {
            T(t);
          },
        });
        let R = () => {
          (Object.assign(D.on, V), (S = !0));
          let e = { ...D };
          if (
            (delete e.wrapperClass,
            (k.current = new Q(e)),
            k.current.virtual && k.current.params.virtual.enabled)
          ) {
            k.current.virtual.slides = $;
            let e = { cache: !1, slides: $, renderExternal: E, renderExternalUpdate: !1 };
            (ei(k.current.params.virtual, e), ei(k.current.originalParams.virtual, e));
          }
        };
        return (
          P.current || R(),
          k.current && k.current.on("_beforeBreakpoint", F),
          (0, r.useEffect)(() => () => {
            k.current && k.current.off("_beforeBreakpoint", F);
          }),
          (0, r.useEffect)(() => {
            !C.current && k.current && (k.current.emitSlidesClasses(), (C.current = !0));
          }),
          ed(() => {
            if ((t && (t.current = P.current), P.current))
              return (
                k.current.destroyed && R(),
                !(function (e, t) {
                  let { el: i, nextEl: s, prevEl: r, paginationEl: l, scrollbarEl: a, swiper: n } = e;
                  (es(t) &&
                    s &&
                    r &&
                    ((n.params.navigation.nextEl = s),
                    (n.originalParams.navigation.nextEl = s),
                    (n.params.navigation.prevEl = r),
                    (n.originalParams.navigation.prevEl = r)),
                    er(t) && l && ((n.params.pagination.el = l), (n.originalParams.pagination.el = l)),
                    el(t) && a && ((n.params.scrollbar.el = a), (n.originalParams.scrollbar.el = a)),
                    n.init(i));
                })(
                  {
                    el: P.current,
                    nextEl: I.current,
                    prevEl: A.current,
                    paginationEl: z.current,
                    scrollbarEl: G.current,
                    swiper: k.current,
                  },
                  D,
                ),
                g && !k.current.destroyed && g(k.current),
                () => {
                  k.current && !k.current.destroyed && k.current.destroy(!0, !1);
                }
              );
          }, []),
          ed(() => {
            !S &&
              V &&
              k.current &&
              Object.keys(V).forEach((e) => {
                k.current.on(e, V[e]);
              });
            let e = (function (e, t, i, s, r) {
              let l = [];
              if (!t) return l;
              let a = (e) => {
                0 > l.indexOf(e) && l.push(e);
              };
              if (i && s) {
                let e = s.map(r),
                  t = i.map(r);
                (e.join("") !== t.join("") && a("children"), s.length !== i.length && a("children"));
              }
              return (
                ee
                  .filter((e) => "_" === e[0])
                  .map((e) => e.replace(/_/, ""))
                  .forEach((i) => {
                    if (i in e && i in t)
                      if (et(e[i]) && et(t[i])) {
                        let s = Object.keys(e[i]),
                          r = Object.keys(t[i]);
                        s.length !== r.length
                          ? a(i)
                          : (s.forEach((s) => {
                              e[i][s] !== t[i][s] && a(i);
                            }),
                            r.forEach((s) => {
                              e[i][s] !== t[i][s] && a(i);
                            }));
                      } else e[i] !== t[i] && a(i);
                  }),
                l
              );
            })(N, _.current, $, L.current, (e) => e.key);
            return (
              (_.current = N),
              (L.current = $),
              e.length &&
                k.current &&
                !k.current.destroyed &&
                (function (e) {
                  let t,
                    i,
                    s,
                    r,
                    l,
                    a,
                    n,
                    o,
                    {
                      swiper: d,
                      slides: c,
                      passedParams: p,
                      changedParams: u,
                      nextEl: h,
                      prevEl: f,
                      scrollbarEl: m,
                      paginationEl: v,
                    } = e,
                    g = u.filter((e) => "children" !== e && "direction" !== e && "wrapperClass" !== e),
                    { params: w, pagination: S, navigation: b, scrollbar: T, virtual: y, thumbs: E } = d;
                  (u.includes("thumbs") &&
                    p.thumbs &&
                    p.thumbs.swiper &&
                    !p.thumbs.swiper.destroyed &&
                    w.thumbs &&
                    (!w.thumbs.swiper || w.thumbs.swiper.destroyed) &&
                    (t = !0),
                    u.includes("controller") &&
                      p.controller &&
                      p.controller.control &&
                      w.controller &&
                      !w.controller.control &&
                      (i = !0),
                    u.includes("pagination") &&
                      p.pagination &&
                      (p.pagination.el || v) &&
                      (w.pagination || !1 === w.pagination) &&
                      S &&
                      !S.el &&
                      (s = !0),
                    u.includes("scrollbar") &&
                      p.scrollbar &&
                      (p.scrollbar.el || m) &&
                      (w.scrollbar || !1 === w.scrollbar) &&
                      T &&
                      !T.el &&
                      (r = !0),
                    u.includes("navigation") &&
                      p.navigation &&
                      (p.navigation.prevEl || f) &&
                      (p.navigation.nextEl || h) &&
                      (w.navigation || !1 === w.navigation) &&
                      b &&
                      !b.prevEl &&
                      !b.nextEl &&
                      (l = !0));
                  let x = (e) => {
                    d[e] &&
                      (d[e].destroy(),
                      "navigation" === e
                        ? (d.isElement && (d[e].prevEl.remove(), d[e].nextEl.remove()),
                          (w[e].prevEl = void 0),
                          (w[e].nextEl = void 0),
                          (d[e].prevEl = void 0),
                          (d[e].nextEl = void 0))
                        : (d.isElement && d[e].el.remove(), (w[e].el = void 0), (d[e].el = void 0)));
                  };
                  (u.includes("loop") &&
                    d.isElement &&
                    (w.loop && !p.loop ? (a = !0) : !w.loop && p.loop ? (n = !0) : (o = !0)),
                    g.forEach((e) => {
                      if (et(w[e]) && et(p[e]))
                        (Object.assign(w[e], p[e]),
                          ("navigation" === e || "pagination" === e || "scrollbar" === e) &&
                            "enabled" in p[e] &&
                            !p[e].enabled &&
                            x(e));
                      else {
                        let t = p[e];
                        (!0 === t || !1 === t) &&
                        ("navigation" === e || "pagination" === e || "scrollbar" === e)
                          ? !1 === t && x(e)
                          : (w[e] = p[e]);
                      }
                    }),
                    g.includes("controller") &&
                      !i &&
                      d.controller &&
                      d.controller.control &&
                      w.controller &&
                      w.controller.control &&
                      (d.controller.control = w.controller.control),
                    u.includes("children") && c && y && w.virtual.enabled
                      ? ((y.slides = c), y.update(!0))
                      : u.includes("virtual") &&
                        y &&
                        w.virtual.enabled &&
                        (c && (y.slides = c), y.update(!0)),
                    u.includes("children") && c && w.loop && (o = !0),
                    t && E.init() && E.update(!0),
                    i && (d.controller.control = w.controller.control),
                    s &&
                      (d.isElement &&
                        (!v || "string" == typeof v) &&
                        ((v = document.createElement("div")).classList.add("swiper-pagination"),
                        v.part.add("pagination"),
                        d.el.appendChild(v)),
                      v && (w.pagination.el = v),
                      S.init(),
                      S.render(),
                      S.update()),
                    r &&
                      (d.isElement &&
                        (!m || "string" == typeof m) &&
                        ((m = document.createElement("div")).classList.add("swiper-scrollbar"),
                        m.part.add("scrollbar"),
                        d.el.appendChild(m)),
                      m && (w.scrollbar.el = m),
                      T.init(),
                      T.updateSize(),
                      T.setTranslate()),
                    l &&
                      (d.isElement &&
                        ((h && "string" != typeof h) ||
                          ((h = document.createElement("div")).classList.add("swiper-button-next"),
                          O(h, d.hostEl.constructor.nextButtonSvg),
                          h.part.add("button-next"),
                          d.el.appendChild(h)),
                        (f && "string" != typeof f) ||
                          ((f = document.createElement("div")).classList.add("swiper-button-prev"),
                          O(f, d.hostEl.constructor.prevButtonSvg),
                          f.part.add("button-prev"),
                          d.el.appendChild(f))),
                      h && (w.navigation.nextEl = h),
                      f && (w.navigation.prevEl = f),
                      b.init(),
                      b.update()),
                    u.includes("allowSlideNext") && (d.allowSlideNext = p.allowSlideNext),
                    u.includes("allowSlidePrev") && (d.allowSlidePrev = p.allowSlidePrev),
                    u.includes("direction") && d.changeDirection(p.direction, !1),
                    (a || o) && d.loopDestroy(),
                    (n || o) && d.loopCreate(),
                    d.update());
                })({
                  swiper: k.current,
                  slides: $,
                  passedParams: N,
                  changedParams: e,
                  nextEl: I.current,
                  prevEl: A.current,
                  scrollbarEl: G.current,
                  paginationEl: z.current,
                }),
              () => {
                V &&
                  k.current &&
                  Object.keys(V).forEach((e) => {
                    k.current.off(e, V[e]);
                  });
              }
            );
          }),
          ed(() => {
            var e;
            (e = k.current) &&
              !e.destroyed &&
              e.params.virtual &&
              (!e.params.virtual || e.params.virtual.enabled) &&
              (e.updateSlides(),
              e.updateProgress(),
              e.updateSlidesClasses(),
              e.emit("_virtualUpdated"),
              e.parallax && e.params.parallax && e.params.parallax.enabled && e.parallax.setTranslate());
          }, [y]),
          r.default.createElement(
            f,
            en({ ref: P, className: ea(`${b}${h ? ` ${h}` : ""}`) }, B),
            r.default.createElement(
              ep.Provider,
              { value: k.current },
              j["container-start"],
              r.default.createElement(
                m,
                {
                  className: (void 0 === (l = D.wrapperClass) && (l = ""), l)
                    ? l.includes("swiper-wrapper")
                      ? l
                      : `swiper-wrapper ${l}`
                    : "swiper-wrapper",
                },
                j["wrapper-start"],
                D.virtual
                  ? (function (e, t, i) {
                      if (!i) return null;
                      let s = (e) => {
                          let i = e;
                          return (e < 0 ? (i = t.length + e) : i >= t.length && (i -= t.length), i);
                        },
                        l = e.isHorizontal()
                          ? { [e.rtlTranslate ? "right" : "left"]: `${i.offset}px` }
                          : { top: `${i.offset}px` },
                        { from: a, to: n } = i,
                        o = e.params.loop ? -t.length : 0,
                        d = e.params.loop ? 2 * t.length : t.length,
                        c = [];
                      for (let e = o; e < d; e += 1) e >= a && e <= n && c.push(t[s(e)]);
                      return c.map((t, i) =>
                        r.default.cloneElement(t, {
                          swiper: e,
                          style: l,
                          key: t.props.virtualIndex || t.key || `slide-${i}`,
                        }),
                      );
                    })(k.current, $, y)
                  : $.map((e, t) => r.default.cloneElement(e, { swiper: k.current, swiperSlideIndex: t })),
                j["wrapper-end"],
              ),
              es(D) &&
                r.default.createElement(
                  r.default.Fragment,
                  null,
                  r.default.createElement("div", { ref: A, className: "swiper-button-prev" }),
                  r.default.createElement("div", { ref: I, className: "swiper-button-next" }),
                ),
              el(D) && r.default.createElement("div", { ref: G, className: "swiper-scrollbar" }),
              er(D) && r.default.createElement("div", { ref: z, className: "swiper-pagination" }),
              j["container-end"],
            ),
          )
        );
      });
    eu.displayName = "Swiper";
    let eh = (0, r.forwardRef)(function (e, t) {
      let {
          tag: i = "div",
          children: s,
          className: l = "",
          swiper: a,
          zoom: n,
          lazy: o,
          virtualIndex: d,
          swiperSlideIndex: c,
          ...p
        } = void 0 === e ? {} : e,
        u = (0, r.useRef)(null),
        [h, f] = (0, r.useState)("swiper-slide"),
        [m, v] = (0, r.useState)(!1);
      function g(e, t, i) {
        t === u.current && f(i);
      }
      (ed(() => {
        if (
          (void 0 !== c && (u.current.swiperSlideIndex = c), t && (t.current = u.current), u.current && a)
        ) {
          if (a.destroyed) {
            "swiper-slide" !== h && f("swiper-slide");
            return;
          }
          return (
            a.on("_slideClass", g),
            () => {
              a && a.off("_slideClass", g);
            }
          );
        }
      }),
        ed(() => {
          a && u.current && !a.destroyed && f(a.getSlideClasses(u.current));
        }, [a]));
      let w = {
          isActive: h.indexOf("swiper-slide-active") >= 0,
          isVisible: h.indexOf("swiper-slide-visible") >= 0,
          isPrev: h.indexOf("swiper-slide-prev") >= 0,
          isNext: h.indexOf("swiper-slide-next") >= 0,
        },
        S = () => ("function" == typeof s ? s(w) : s);
      return r.default.createElement(
        i,
        en(
          {
            ref: u,
            className: ea(`${h}${l ? ` ${l}` : ""}`),
            "data-swiper-slide-index": d,
            onLoad: () => {
              v(!0);
            },
          },
          p,
        ),
        n &&
          r.default.createElement(
            ec.Provider,
            { value: w },
            r.default.createElement(
              "div",
              { className: "swiper-zoom-container", "data-swiper-zoom": "number" == typeof n ? n : void 0 },
              S(),
              o && !m && r.default.createElement("div", { className: "swiper-lazy-preloader" }),
            ),
          ),
        !n &&
          r.default.createElement(
            ec.Provider,
            { value: w },
            S(),
            o && !m && r.default.createElement("div", { className: "swiper-lazy-preloader" }),
          ),
      );
    });
    ((eh.displayName = "SwiperSlide"), e.s(["Swiper", 0, eu, "SwiperSlide", 0, eh], 980401));
  },
]);
