(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  396515,
  (e) => {
    "use strict";
    var t = e.i(843476),
      o = e.i(948148),
      s = e.i(742214),
      l = e.i(190338),
      n = e.i(86596),
      i = e.i(622963);
    e.i(568267);
    var R = e.i(154692),
      a = e.i(202042);
    (e.s([], 712364),
      e.i(712364),
      e.s(
        [
          "PaymentProcessedOtherTabModalComponent",
          0,
          () => {
            let e = (0, o.useTranslations)(),
              E = (0, a.useRouter)(),
              r = (0, i.useModalStore)((e) => e.handleChangeModalStore),
              u = (0, n.useUserStore)((e) => e.user);
            return (0, t.jsx)(s.ModalContent, {
              className:
                "!my-0 max-h-[95vh] w-[95%] max-w-md select-none overflow-y-auto rounded-lg bg-white p-0",
              children: (0, t.jsx)("div", {
                className: "relative",
                children: (0, t.jsx)("div", {
                  className: "flex h-full max-h-full flex-col overflow-hidden",
                  children: (0, t.jsxs)("div", {
                    className: "flex flex-1 flex-col overflow-hidden rounded-lg text-sm text-gray-600",
                    children: [
                      (0, t.jsx)("div", {
                        className: "flex-1 overflow-y-auto px-6 pt-6",
                        children: (0, t.jsx)("h1", {
                          className: "text-center text-lg font-semibold text-gray-600",
                          children: e("payment_processed_other_tab_description"),
                        }),
                      }),
                      (0, t.jsx)("div", {
                        className: "flex-shrink-0 p-6",
                        children: (0, t.jsx)(R.ButtonComponent, {
                          disableRipple: !0,
                          text: e("btn_continue"),
                          onClick: () => {
                            r({ modalComponent: null, isModalVisible: !1 });
                            let e = (0, l.getReportRouteByTestVariation)(u?.funnel);
                            E.replace(e);
                          },
                          className:
                            "lg:min-w-none mt-auto h-12 w-full min-w-max flex-1 whitespace-pre-wrap rounded-xl text-base",
                        }),
                      }),
                    ],
                  }),
                }),
              }),
            });
          },
        ],
        396515,
      ));
  },
  228632,
  function (e) {
    e.n(e.i(396515));
  },
  190338,
  (e) => {
    "use strict";
    var t = e.i(134404);
    e.s([
      "getReportRouteByTestVariation",
      0,
      (e) =>
        "love_language" === e
          ? t.EClientRoutes.REPORT_LOVE
          : "personality" === e
            ? t.EClientRoutes.REPORT_PERSONALITY
            : "careers" === e
              ? t.EClientRoutes.REPORT_CAREERS
              : "work" === e
                ? t.EClientRoutes.REPORT_WORK
                : "burnout" === e
                  ? t.EClientRoutes.REPORT_BURNOUT
                  : "emotional" === e
                    ? t.EClientRoutes.REPORT_EMOTIONAL
                    : "depression" === e
                      ? t.EClientRoutes.REPORT_DEPRESSION
                      : "depression_funnel" === e
                        ? t.EClientRoutes.REPORT_DEPRESSION_FUNNEL
                        : "adhd" === e
                          ? t.EClientRoutes.REPORT_ADHD
                          : "attachment" === e
                            ? t.EClientRoutes.REPORT_ATTACHMENT
                            : "time_management" === e
                              ? t.EClientRoutes.REPORT_TIME_MANAGEMENT
                              : "anxiety" === e
                                ? t.EClientRoutes.REPORT_ANXIETY
                                : "confidence" === e
                                  ? t.EClientRoutes.REPORT_CONFIDENCE
                                  : "strengths" === e
                                    ? t.EClientRoutes.REPORT_STRENGTHS
                                    : "psychological_archetypes" === e
                                      ? t.EClientRoutes.REPORT_PSYCHOLOGICAL_ARCHETYPES
                                      : "procrastination" === e
                                        ? t.EClientRoutes.REPORT_PROCRASTINATION
                                        : "imposter_syndrome" === e
                                          ? t.EClientRoutes.REPORT_IMPOSTER_SYNDROME
                                          : "political_compass" === e
                                            ? t.EClientRoutes.REPORT_POLITICAL_COMPASS
                                            : "autism" === e
                                              ? t.EClientRoutes.REPORT_AUTISM
                                              : "enneagram" === e
                                                ? t.EClientRoutes.REPORT_ENNEAGRAM
                                                : t.EClientRoutes.REPORT,
    ]);
  },
]);
