# DOSSIÊ myiq.com — cópia do front-end (coletada em 2026-10-06)

Só código **público** que o site entrega para qualquer visitante. Não houve login, nem e-mail digitado, nem pagamento, e nenhum desafio do Cloudflare foi contornado.
Stack: **Next.js (App Router) + Turbopack**, atrás do Cloudflare (IP 104.18.24.47). Backend: Supabase. 40 idiomas (hreflang).

## Pastas

| Pasta | O que tem |
|---|---|
| `paginas/` | HTML renderizado no servidor de cada rota (GET simples): home, quiz, start, checkout, pricing, terms, privacy, cookie, help, contato, cancellation_auth, sign-in, pt-BR, pt-BR_quiz, results (**404**), robots.txt e sitemap.xml. As strings de tradução (`checkout_*`, `help_article_*`) vêm embutidas no payload RSC dentro do HTML. |
| `codigo_js/` | 165 chunks originais (minificados) de `/_next/static/chunks/`, JS e CSS, com o fechamento completo: nenhuma referência ficou sem baixar. |
| `codigo_js_formatado/` | Os mesmos .js passados no prettier (~220 mil linhas). **Use esta pasta para ler.** |
| `terceiros/` | Scripts de rastreamento/pixels que a home carregou (TikTok, Snap, Bing, Pinterest, AppLovin/Axon, Kwai, Quora, Clarity, Customer.io, dashfi, mythad, ap4r, X/Twitter, Meta), mais o proxy de GA em `myiq.com/j27d3d6` e o `mp.myiq.com` (proxy do Mixpanel). |
| `capturas/` | `home_renderizada.png/html` (screenshot pelo navegador) e `network_log.jsonl` (todas as 345 requisições da home, inclusive os POSTs de tracking). |
| `ferramentas/` | `crawl_myiq.py` (Playwright, rodar com `py -3.12`). Atenção: só a home passa pelo navegador headless; as outras rotas recebem o desafio do Cloudflare ("Just a moment…", 403). Para essas, use um GET simples. |

## Chunks exclusivos por página (não aparecem na home)

- **checkout**: `0aal15mg4ted9` `0edniv33fp3-h` `0prifl20_uaw7` `0tl7p_h2951zs` `11gajfol54dkl` `1dnwp45ex2q2j` `20y6-wzppf_4k` `2fv-hc20jxc_t` `2rkzyhf41asn1` `38gdz74qh1kzy` `3haxw6p7xnhfm` `3qm1bwuz746es` `3r1phbmxh0b5i` `3shgo-oc6cycz` `42fvhfqa88dw7`
- **cancellation/auth**: `0ua5j1n_y4vzk` `0w3wb6vsz1asz` `1ycgi-txkb2h1` `30o8erl2w86v2`
- **pricing**: `2lpecm-85e2vm`
- **sign-in**: `0w3wb6vsz1asz` `1623vpzwmue7b` `1ycgi-txkb2h1` `304_48ho-66nh` `31cly7veb9ayg` `43lqg8cawfy8b`
- **quiz / start**: ver `paginas/quiz.html` e `paginas/start.html` (lista grande)
- **terms**: `2pqslb_mq4cmc` `2xtqq_k2-o7jt` `3__qmtq203ml1`

## Onde aparece cada termo (em `codigo_js_formatado/`)

- **Braintree**: `0edniv33fp3-h` `0tl7p_h2951zs` `20y6-wzppf_4k` (os três são do checkout) e outros
- **Stripe**: `0edniv33fp3-h` `20y6-wzppf_4k` `1md-fabbtg6r_` `2r6qb9jto558s` `2rr-8gy9tdmn6`
- **PayPal / Apple Pay**: `0tl7p_h2951zs` `0f86hoio837-d` `3-0_kq2g74b8i` `3nf4bje-8x16b`
- **Supabase**: `0edniv33fp3-h` `42fvhfqa88dw7` (checkout) e outros
- **`/api/`**: `1md-fabbtg6r_` `36xq5vxi1f1jq`

## O que salta aos olhos (ainda NÃO verificado, é ponto de partida)

1. **robots.txt bloqueia `ia_archiver` e `archive.org_bot` no site inteiro.** O Wayback Machine não guarda histórico de termos e preços.
2. **Trial de US$0,99/US$1,00 que vira US$29,99 "every 28 days".** Ciclo de 28 dias dá 13 cobranças por ano, e não 12. Texto visível em `paginas/checkout.html` e `paginas/pricing.html`. Os termos (`help_article_renewal_billing_*`, "section 6") estão em `paginas/terms.html`.
3. Existe uma variante de checkout com "autism" no nome das chaves (`checkout_autism_page_benefits_*`): funil temático separado.
4. Rastreamento pesado: 15+ redes de anúncio na home, GA servido por proxy próprio (`/j27d3d6/`) e Mixpanel por proxy (`mp.myiq.com`).
5. `/checkout*` e `/profile*` estão em Disallow no robots, e `/admin` também. A rota `/admin` **não** foi acessada.
