(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  892902,
  (e) => {
    "use strict";
    let t = e.i(271645).default.createContext({ register: () => {} });
    ((t.displayName = "PressResponderContext"), e.s(["PressResponderContext", 0, t]));
  },
  346996,
  109509,
  (e) => {
    "use strict";
    let t;
    var n = e.i(424220),
      r = e.i(663859);
    function o(e) {
      return (
        ("" === e.pointerType && !!e.isTrusted) ||
        ((0, r.isAndroid)() && e.pointerType
          ? "click" === e.type && 1 === e.buttons
          : 0 === e.detail && !e.pointerType)
      );
    }
    e.s(
      [
        "isVirtualClick",
        0,
        o,
        "isVirtualPointerEvent",
        0,
        function (e) {
          return (
            (!(0, r.isAndroid)() && 0 === e.width && 0 === e.height) ||
            (1 === e.width &&
              1 === e.height &&
              0 === e.pressure &&
              0 === e.detail &&
              "mouse" === e.pointerType)
          );
        },
      ],
      109509,
    );
    var i = e.i(934203),
      u = e.i(271645);
    e.i(454453);
    let a = null,
      s = new Set(),
      l = new Map(),
      c = !1,
      d = !1,
      f = { Tab: !0, Escape: !0 };
    function v(e, t) {
      for (let n of s) n(e, t);
    }
    function p(e) {
      ((c = !0),
        e.metaKey ||
          (!(0, r.isMac)() && e.altKey) ||
          e.ctrlKey ||
          "Control" === e.key ||
          "Shift" === e.key ||
          "Meta" === e.key ||
          ((a = "keyboard"), v("keyboard", e)));
    }
    function m(e) {
      ((a = "pointer"), ("mousedown" === e.type || "pointerdown" === e.type) && ((c = !0), v("pointer", e)));
    }
    function E(e) {
      o(e) && ((c = !0), (a = "virtual"));
    }
    function g(e) {
      e.target !== window &&
        e.target !== document &&
        !n.ignoreFocusEvent &&
        e.isTrusted &&
        (c || d || ((a = "virtual"), v("virtual", e)), (c = !1), (d = !1));
    }
    function w() {
      n.ignoreFocusEvent || ((c = !1), (d = !0));
    }
    function y(e) {
      if ("u" < typeof window || "u" < typeof document || l.get((0, i.getOwnerWindow)(e))) return;
      let t = (0, i.getOwnerWindow)(e),
        n = (0, i.getOwnerDocument)(e),
        r = t.HTMLElement.prototype.focus;
      ((t.HTMLElement.prototype.focus = function () {
        ((c = !0), r.apply(this, arguments));
      }),
        n.addEventListener("keydown", p, !0),
        n.addEventListener("keyup", p, !0),
        n.addEventListener("click", E, !0),
        t.addEventListener("focus", g, !0),
        t.addEventListener("blur", w, !1),
        "u" > typeof PointerEvent &&
          (n.addEventListener("pointerdown", m, !0),
          n.addEventListener("pointermove", m, !0),
          n.addEventListener("pointerup", m, !0)),
        t.addEventListener(
          "beforeunload",
          () => {
            b(e);
          },
          { once: !0 },
        ),
        l.set(t, { focus: r }));
    }
    let b = (e, t) => {
      let n = (0, i.getOwnerWindow)(e),
        r = (0, i.getOwnerDocument)(e);
      (t && r.removeEventListener("DOMContentLoaded", t),
        l.has(n) &&
          ((n.HTMLElement.prototype.focus = l.get(n).focus),
          r.removeEventListener("keydown", p, !0),
          r.removeEventListener("keyup", p, !0),
          r.removeEventListener("click", E, !0),
          n.removeEventListener("focus", g, !0),
          n.removeEventListener("blur", w, !1),
          "u" > typeof PointerEvent &&
            (r.removeEventListener("pointerdown", m, !0),
            r.removeEventListener("pointermove", m, !0),
            r.removeEventListener("pointerup", m, !0)),
          l.delete(n)));
    };
    function h() {
      return "pointer" !== a;
    }
    "u" > typeof document &&
      ("loading" !== (t = (0, i.getOwnerDocument)(void 0)).readyState
        ? y(void 0)
        : t.addEventListener("DOMContentLoaded", () => {
            y(void 0);
          }));
    let L = new Set(["checkbox", "radio", "range", "color", "file", "image", "button", "submit", "reset"]);
    e.s(
      [
        "getInteractionModality",
        0,
        function () {
          return a;
        },
        "isFocusVisible",
        0,
        h,
        "setInteractionModality",
        0,
        function (e) {
          ((a = e), v(e, null));
        },
        "useFocusVisibleListener",
        0,
        function (e, t, n) {
          (y(),
            (0, u.useEffect)(() => {
              let t = (t, r) => {
                var o;
                let u, a, s, l, c;
                ((o = !!(null == n ? void 0 : n.isTextInput)),
                  (u = (0, i.getOwnerDocument)(null == r ? void 0 : r.target)),
                  (a =
                    "u" > typeof window
                      ? (0, i.getOwnerWindow)(null == r ? void 0 : r.target).HTMLInputElement
                      : HTMLInputElement),
                  (s =
                    "u" > typeof window
                      ? (0, i.getOwnerWindow)(null == r ? void 0 : r.target).HTMLTextAreaElement
                      : HTMLTextAreaElement),
                  (l =
                    "u" > typeof window
                      ? (0, i.getOwnerWindow)(null == r ? void 0 : r.target).HTMLElement
                      : HTMLElement),
                  (c =
                    "u" > typeof window
                      ? (0, i.getOwnerWindow)(null == r ? void 0 : r.target).KeyboardEvent
                      : KeyboardEvent),
                  ((o =
                    o ||
                    (u.activeElement instanceof a && !L.has(u.activeElement.type)) ||
                    u.activeElement instanceof s ||
                    (u.activeElement instanceof l && u.activeElement.isContentEditable)) &&
                    "keyboard" === t &&
                    r instanceof c &&
                    !f[r.key]) ||
                    e(h()));
              };
              return (
                s.add(t),
                () => {
                  s.delete(t);
                }
              );
            }, t));
        },
      ],
      346996,
    );
  },
  616231,
  (e) => {
    "use strict";
    var t = e.i(424220),
      n = e.i(271645),
      r = e.i(548121),
      o = e.i(934203),
      i = e.i(933714);
    e.s([
      "useFocusWithin",
      0,
      function (e) {
        let { isDisabled: u, onBlurWithin: a, onFocusWithin: s, onFocusWithinChange: l } = e,
          c = (0, n.useRef)({ isFocusWithin: !1 }),
          { addGlobalListener: d, removeAllGlobalListeners: f } = (0, r.useGlobalListeners)(),
          v = (0, n.useCallback)(
            (e) => {
              e.currentTarget.contains(e.target) &&
                c.current.isFocusWithin &&
                !e.currentTarget.contains(e.relatedTarget) &&
                ((c.current.isFocusWithin = !1), f(), a && a(e), l && l(!1));
            },
            [a, l, c, f],
          ),
          p = (0, t.useSyntheticBlurEvent)(v),
          m = (0, n.useCallback)(
            (e) => {
              if (!e.currentTarget.contains(e.target)) return;
              let n = (0, o.getOwnerDocument)(e.target),
                r = (0, i.getActiveElement)(n);
              if (!c.current.isFocusWithin && r === (0, i.getEventTarget)(e.nativeEvent)) {
                (s && s(e), l && l(!0), (c.current.isFocusWithin = !0), p(e));
                let r = e.currentTarget;
                d(
                  n,
                  "focus",
                  (e) => {
                    if (c.current.isFocusWithin && !(0, i.nodeContains)(r, e.target)) {
                      let o = new n.defaultView.FocusEvent("blur", { relatedTarget: e.target });
                      ((0, t.setEventTarget)(o, r), v((0, t.createSyntheticEvent)(o)));
                    }
                  },
                  { capture: !0 },
                );
              }
            },
            [s, l, p, d, v],
          );
        return u
          ? { focusWithinProps: { onFocus: void 0, onBlur: void 0 } }
          : { focusWithinProps: { onFocus: m, onBlur: v } };
      },
    ]);
  },
  424220,
  514480,
  (e) => {
    "use strict";
    var t = e.i(116914),
      n = e.i(110514),
      r = e.i(934203);
    let o = "u" > typeof Element && "checkVisibility" in Element.prototype,
      i = [
        "input:not([disabled]):not([type=hidden])",
        "select:not([disabled])",
        "textarea:not([disabled])",
        "button:not([disabled])",
        "a[href]",
        "area[href]",
        "summary",
        "iframe",
        "object",
        "embed",
        "audio[controls]",
        "video[controls]",
        '[contenteditable]:not([contenteditable^="false"])',
        "permission",
      ],
      u = i.join(":not([hidden]),") + ",[tabindex]:not([disabled]):not([hidden])";
    function a(e) {
      if (
        (function () {
          if (null == s) {
            s = !1;
            try {
              document.createElement("div").focus({
                get preventScroll() {
                  return ((s = !0), !0);
                },
              });
            } catch {}
          }
          return s;
        })()
      )
        e.focus({ preventScroll: !0 });
      else {
        let t = (function (e) {
          let t = e.parentNode,
            n = [],
            r = document.scrollingElement || document.documentElement;
          for (; t instanceof HTMLElement && t !== r;)
            ((t.offsetHeight < t.scrollHeight || t.offsetWidth < t.scrollWidth) &&
              n.push({ element: t, scrollTop: t.scrollTop, scrollLeft: t.scrollLeft }),
              (t = t.parentNode));
          return (
            r instanceof HTMLElement &&
              n.push({ element: r, scrollTop: r.scrollTop, scrollLeft: r.scrollLeft }),
            n
          );
        })(e);
        (e.focus(),
          (function (e) {
            for (let { element: t, scrollTop: n, scrollLeft: r } of e)
              ((t.scrollTop = n), (t.scrollLeft = r));
          })(t));
      }
    }
    (i.push('[tabindex]:not([tabindex="-1"]):not([disabled])'),
      i.join(':not([hidden]):not([tabindex="-1"]),'));
    let s = null;
    e.s(["focusWithoutScrolling", 0, a], 514480);
    var l = e.i(271645);
    function c(e) {
      return (
        (e.nativeEvent = e),
        (e.isDefaultPrevented = () => e.defaultPrevented),
        (e.isPropagationStopped = () => e.cancelBubble),
        (e.persist = () => {}),
        e
      );
    }
    let d = !1;
    e.s(
      [
        "createSyntheticEvent",
        0,
        c,
        "ignoreFocusEvent",
        () => d,
        "preventFocus",
        0,
        function (e) {
          for (
            var t;
            e &&
            !(
              (t = e).matches(u) &&
              (function e(t, n) {
                return o
                  ? t.checkVisibility({ visibilityProperty: !0 }) &&
                      !t.closest("[data-react-aria-prevent-focus]")
                  : "#comment" !== t.nodeName &&
                      (function (e) {
                        let t = (0, r.getOwnerWindow)(e);
                        if (!(e instanceof t.HTMLElement) && !(e instanceof t.SVGElement)) return !1;
                        let { display: n, visibility: o } = e.style,
                          i = "none" !== n && "hidden" !== o && "collapse" !== o;
                        if (i) {
                          let { getComputedStyle: t } = e.ownerDocument.defaultView,
                            { display: n, visibility: r } = t(e);
                          i = "none" !== n && "hidden" !== r && "collapse" !== r;
                        }
                        return i;
                      })(t) &&
                      !t.hasAttribute("hidden") &&
                      !t.hasAttribute("data-react-aria-prevent-focus") &&
                      ("DETAILS" !== t.nodeName ||
                        !n ||
                        "SUMMARY" === n.nodeName ||
                        t.hasAttribute("open")) &&
                      (!t.parentElement || e(t.parentElement, t));
              })(t) &&
              !(function (e) {
                let t = e;
                for (; null != t;) {
                  if (t instanceof t.ownerDocument.defaultView.HTMLElement && t.inert) return !0;
                  t = t.parentElement;
                }
                return !1;
              })(t)
            );
          )
            e = e.parentElement;
          let n = (0, r.getOwnerWindow)(e),
            i = n.document.activeElement;
          if (!i || i === e) return;
          d = !0;
          let s = !1,
            l = (e) => {
              (e.target === i || s) && e.stopImmediatePropagation();
            },
            c = (t) => {
              (t.target === i || s) && (t.stopImmediatePropagation(), e || s || ((s = !0), a(i), p()));
            },
            f = (t) => {
              (t.target === e || s) && t.stopImmediatePropagation();
            },
            v = (t) => {
              (t.target === e || s) && (t.stopImmediatePropagation(), s || ((s = !0), a(i), p()));
            };
          (n.addEventListener("blur", l, !0),
            n.addEventListener("focusout", c, !0),
            n.addEventListener("focusin", v, !0),
            n.addEventListener("focus", f, !0));
          let p = () => {
              (cancelAnimationFrame(m),
                n.removeEventListener("blur", l, !0),
                n.removeEventListener("focusout", c, !0),
                n.removeEventListener("focusin", v, !0),
                n.removeEventListener("focus", f, !0),
                (d = !1),
                (s = !1));
            },
            m = requestAnimationFrame(p);
          return p;
        },
        "setEventTarget",
        0,
        function (e, t) {
          (Object.defineProperty(e, "target", { value: t }),
            Object.defineProperty(e, "currentTarget", { value: t }));
        },
        "useSyntheticBlurEvent",
        0,
        function (e) {
          let r = (0, l.useRef)({ isFocused: !1, observer: null });
          (0, t.useLayoutEffect)(() => {
            let e = r.current;
            return () => {
              e.observer && (e.observer.disconnect(), (e.observer = null));
            };
          }, []);
          let o = (0, n.useEffectEvent)((t) => {
            null == e || e(t);
          });
          return (0, l.useCallback)(
            (e) => {
              if (
                e.target instanceof HTMLButtonElement ||
                e.target instanceof HTMLInputElement ||
                e.target instanceof HTMLTextAreaElement ||
                e.target instanceof HTMLSelectElement
              ) {
                r.current.isFocused = !0;
                let t = e.target;
                (t.addEventListener(
                  "focusout",
                  (e) => {
                    ((r.current.isFocused = !1),
                      t.disabled && o(c(e)),
                      r.current.observer && (r.current.observer.disconnect(), (r.current.observer = null)));
                  },
                  { once: !0 },
                ),
                  (r.current.observer = new MutationObserver(() => {
                    if (r.current.isFocused && t.disabled) {
                      var e;
                      null == (e = r.current.observer) || e.disconnect();
                      let n = t === document.activeElement ? null : document.activeElement;
                      (t.dispatchEvent(new FocusEvent("blur", { relatedTarget: n })),
                        t.dispatchEvent(new FocusEvent("focusout", { bubbles: !0, relatedTarget: n })));
                    }
                  })),
                  r.current.observer.observe(t, { attributes: !0, attributeFilter: ["disabled"] }));
              }
            },
            [o],
          );
        },
      ],
      424220,
    );
  },
  933714,
  (e) => {
    "use strict";
    var t = e.i(934203),
      n = e.i(674750);
    e.s([
      "getActiveElement",
      0,
      function () {
        var e;
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : document;
        if (!(0, n.shadowDOM)()) return t.activeElement;
        let r = t.activeElement;
        for (; r && "shadowRoot" in r && (null == (e = r.shadowRoot) ? void 0 : e.activeElement);)
          r = r.shadowRoot.activeElement;
        return r;
      },
      "getEventTarget",
      0,
      function (e) {
        return (0, n.shadowDOM)() && e.target.shadowRoot && e.composedPath ? e.composedPath()[0] : e.target;
      },
      "nodeContains",
      0,
      function (e, r) {
        if (!(0, n.shadowDOM)()) return !!r && !!e && e.contains(r);
        if (!e || !r) return !1;
        let o = r;
        for (; null !== o;) {
          if (o === e) return !0;
          o =
            "SLOT" === o.tagName && o.assignedSlot
              ? o.assignedSlot.parentNode
              : (0, t.isShadowRoot)(o)
                ? o.host
                : o.parentNode;
        }
        return !1;
      },
    ]);
  },
  312988,
  (e) => {
    "use strict";
    e.s([
      "chain",
      0,
      function () {
        for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
        return function () {
          for (var e = arguments.length, n = Array(e), r = 0; r < e; r++) n[r] = arguments[r];
          for (let e of t) "function" == typeof e && e(...n);
        };
      },
    ]);
  },
  934203,
  (e) => {
    "use strict";
    let t = (e) => {
      var t;
      return null != (t = null == e ? void 0 : e.ownerDocument) ? t : document;
    };
    e.s([
      "getOwnerDocument",
      0,
      t,
      "getOwnerWindow",
      0,
      (e) => (e && "window" in e && e.window === e ? e : t(e).defaultView || window),
      "isShadowRoot",
      0,
      function (e) {
        return (
          null !== e &&
          "object" == typeof e &&
          "nodeType" in e &&
          "number" == typeof e.nodeType &&
          e.nodeType === Node.DOCUMENT_FRAGMENT_NODE &&
          "host" in e
        );
      },
    ]);
  },
  47682,
  (e) => {
    "use strict";
    var t = e.i(312988);
    (e.i(116914),
      e.i(110514),
      e.i(271645),
      e.i(454453),
      "u" > typeof window && window.document && window.document.createElement);
    let n = new Map();
    "u" > typeof FinalizationRegistry &&
      new FinalizationRegistry((e) => {
        n.delete(e);
      });
    var r = e.i(207670);
    e.s(
      [
        "mergeProps",
        0,
        function () {
          for (var e = arguments.length, o = Array(e), i = 0; i < e; i++) o[i] = arguments[i];
          let u = { ...o[0] };
          for (let e = 1; e < o.length; e++) {
            let i = o[e];
            for (let e in i) {
              let o = u[e],
                a = i[e];
              "function" == typeof o &&
              "function" == typeof a &&
              "o" === e[0] &&
              "n" === e[1] &&
              e.charCodeAt(2) >= 65 &&
              90 >= e.charCodeAt(2)
                ? (u[e] = (0, t.chain)(o, a))
                : ("className" === e || "UNSAFE_className" === e) &&
                    "string" == typeof o &&
                    "string" == typeof a
                  ? (u[e] = (0, r.default)(o, a))
                  : "id" === e && o && a
                    ? (u.id = (function (e, t) {
                        if (e === t) return e;
                        let r = n.get(e);
                        if (r) return (r.forEach((e) => (e.current = t)), t);
                        let o = n.get(t);
                        return o ? (o.forEach((t) => (t.current = e)), e) : t;
                      })(o, a))
                    : (u[e] = void 0 !== a ? a : o);
            }
          }
          return u;
        },
      ],
      47682,
    );
  },
  663859,
  (e) => {
    "use strict";
    function t(e) {
      var t;
      if ("u" < typeof window || null == window.navigator) return !1;
      let n = null == (t = window.navigator.userAgentData) ? void 0 : t.brands;
      return (Array.isArray(n) && n.some((t) => e.test(t.brand))) || e.test(window.navigator.userAgent);
    }
    function n(e) {
      var t;
      return (
        "u" > typeof window &&
        null != window.navigator &&
        e.test(
          (null == (t = window.navigator.userAgentData) ? void 0 : t.platform) || window.navigator.platform,
        )
      );
    }
    function r(e) {
      let t = null;
      return () => (null == t && (t = e()), t);
    }
    e.i(247167);
    let o = r(function () {
        return n(/^Mac/i);
      }),
      i = r(function () {
        return n(/^iPhone/i);
      }),
      u = r(function () {
        return n(/^iPad/i) || (o() && navigator.maxTouchPoints > 1);
      }),
      a = r(function () {
        return i() || u();
      });
    r(function () {
      return o() || a();
    });
    let s = r(function () {
        return t(/AppleWebKit/i) && !l();
      }),
      l = r(function () {
        return t(/Chrome/i);
      }),
      c = r(function () {
        return t(/Android/i);
      }),
      d = r(function () {
        return t(/Firefox/i);
      });
    e.s([
      "isAndroid",
      0,
      c,
      "isFirefox",
      0,
      d,
      "isIOS",
      0,
      a,
      "isIPad",
      0,
      u,
      "isMac",
      0,
      o,
      "isWebKit",
      0,
      s,
    ]);
  },
  109789,
  (e) => {
    "use strict";
    let t = new Map(),
      n = new Set();
    function r() {
      if ("u" < typeof window) return;
      function e(e) {
        return "propertyName" in e;
      }
      let r = (o) => {
        if (!e(o) || !o.target) return;
        let i = t.get(o.target);
        if (
          i &&
          (i.delete(o.propertyName),
          0 === i.size && (o.target.removeEventListener("transitioncancel", r), t.delete(o.target)),
          0 === t.size)
        ) {
          for (let e of n) e();
          n.clear();
        }
      };
      (document.body.addEventListener("transitionrun", (n) => {
        if (!e(n) || !n.target) return;
        let o = t.get(n.target);
        (o ||
          ((o = new Set()),
          t.set(n.target, o),
          n.target.addEventListener("transitioncancel", r, { once: !0 })),
          o.add(n.propertyName));
      }),
        document.body.addEventListener("transitionend", r));
    }
    ("u" > typeof document &&
      ("loading" !== document.readyState ? r() : document.addEventListener("DOMContentLoaded", r)),
      e.s([
        "runAfterTransition",
        0,
        function (e) {
          requestAnimationFrame(() => {
            for (let [e] of t) "isConnected" in e && !e.isConnected && t.delete(e);
            0 === t.size ? e() : n.add(e);
          });
        },
      ]));
  },
  548121,
  (e) => {
    "use strict";
    var t = e.i(271645);
    e.s([
      "useGlobalListeners",
      0,
      function () {
        let e = (0, t.useRef)(new Map()),
          n = (0, t.useCallback)((t, n, r, o) => {
            let i = (null == o ? void 0 : o.once)
              ? function () {
                  for (var t = arguments.length, n = Array(t), o = 0; o < t; o++) n[o] = arguments[o];
                  (e.current.delete(r), r(...n));
                }
              : r;
            (e.current.set(r, { type: n, eventTarget: t, fn: i, options: o }), t.addEventListener(n, i, o));
          }, []),
          r = (0, t.useCallback)((t, n, r, o) => {
            var i;
            let u = (null == (i = e.current.get(r)) ? void 0 : i.fn) || r;
            (t.removeEventListener(n, u, o), e.current.delete(r));
          }, []),
          o = (0, t.useCallback)(() => {
            e.current.forEach((e, t) => {
              r(e.eventTarget, e.type, t, e.options);
            });
          }, [r]);
        return (
          (0, t.useEffect)(() => o, [o]),
          { addGlobalListener: n, removeGlobalListener: r, removeAllGlobalListeners: o }
        );
      },
    ]);
  },
  116914,
  110514,
  (e) => {
    "use strict";
    var t,
      n = e.i(271645);
    let r = "u" > typeof document ? n.default.useLayoutEffect : () => {};
    e.s(["useLayoutEffect", 0, r], 116914);
    let o = null != (t = n.default.useInsertionEffect) ? t : r;
    e.s(
      [
        "useEffectEvent",
        0,
        function (e) {
          let t = (0, n.useRef)(null);
          return (
            o(() => {
              t.current = e;
            }, [e]),
            (0, n.useCallback)(function () {
              for (var e = arguments.length, n = Array(e), r = 0; r < e; r++) n[r] = arguments[r];
              let o = t.current;
              return null == o ? void 0 : o(...n);
            }, [])
          );
        },
      ],
      110514,
    );
  },
  957303,
  (e) => {
    "use strict";
    var t = e.i(116914);
    e.s([
      "useSyncRef",
      0,
      function (e, n) {
        (0, t.useLayoutEffect)(() => {
          if (e && e.ref && n)
            return (
              (e.ref.current = n.current),
              () => {
                e.ref && (e.ref.current = null);
              }
            );
        });
      },
    ]);
  },
  454453,
  (e) => {
    "use strict";
    e.i(247167);
    var t = e.i(271645);
    let n = { prefix: String(Math.round(1e10 * Math.random())), current: 0 },
      r = t.default.createContext(n),
      o = t.default.createContext(!1);
    "u" > typeof window && window.document && window.document.createElement;
    let i = new WeakMap(),
      u =
        "function" == typeof t.default.useId
          ? function (e) {
              let r = t.default.useId(),
                [o] = (0, t.useState)(c()),
                i = o ? "react-aria" : `react-aria${n.prefix}`;
              return e || `${i}-${r}`;
            }
          : function (e) {
              let n = (0, t.useContext)(r),
                o = (function () {
                  let e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
                    n = (0, t.useContext)(r),
                    o = (0, t.useRef)(null);
                  if (null === o.current && !e) {
                    var u, a;
                    let e =
                      null == (a = t.default.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED) ||
                      null == (u = a.ReactCurrentOwner)
                        ? void 0
                        : u.current;
                    if (e) {
                      let t = i.get(e);
                      null == t
                        ? i.set(e, { id: n.current, state: e.memoizedState })
                        : e.memoizedState !== t.state && ((n.current = t.id), i.delete(e));
                    }
                    o.current = ++n.current;
                  }
                  return o.current;
                })(!!e),
                u = `react-aria${n.prefix}`;
              return e || `${u}-${o}`;
            };
    function a() {
      return !1;
    }
    function s() {
      return !0;
    }
    function l(e) {
      return () => {};
    }
    function c() {
      return "function" == typeof t.default.useSyncExternalStore
        ? t.default.useSyncExternalStore(l, a, s)
        : (0, t.useContext)(o);
    }
    e.s(["useIsSSR", 0, c, "useSSRSafeId", 0, u]);
  },
  674750,
  (e) => {
    "use strict";
    e.s([
      "shadowDOM",
      0,
      function () {
        return !1;
      },
    ]);
  },
]);
