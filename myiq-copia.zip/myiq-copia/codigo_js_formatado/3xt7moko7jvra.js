(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  23737,
  (t) => {
    "use strict";
    let e = (0, t.i(475254).default)("circle-question-mark", [
      ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
      ["path", { d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3", key: "1u773s" }],
      ["path", { d: "M12 17h.01", key: "p32p05" }],
    ]);
    t.s(["default", 0, e]);
  },
  126695,
  (t) => {
    "use strict";
    var e = t.i(843476),
      i = t.i(23737),
      i = i,
      a = t.i(948148),
      s = t.i(271645),
      n = t.i(663615);
    t.s(
      [
        "default",
        0,
        (t) => {
          let { hintsLeft: l, poolSize: c, onActivate: r } = t,
            o = (0, a.useTranslations)(),
            [u, d] = (0, s.useState)(!1);
          return (
            (0, s.useEffect)(() => {
              let t = requestAnimationFrame(() => d(!0));
              return () => cancelAnimationFrame(t);
            }, []),
            (0, e.jsx)("div", {
              role: "status",
              className: (0, n.cn)(
                "fixed bottom-[calc(76px+var(--cookie-consent-h,0px))] right-4 z-[70]",
                "md:hidden",
                "max-w-[calc(100vw-32px)] transition-all duration-300 ease-out",
                u ? "translate-y-0 opacity-100" : "translate-y-2 opacity-0",
              ),
              children: (0, e.jsxs)("button", {
                type: "button",
                onClick: r,
                "data-nr": "hint-assist-activate-btn",
                className:
                  "flex items-center gap-1.5 rounded-2xl rounded-br-md bg-white py-2 pl-3 pr-3.5 text-start text-[13px] leading-tight text-black-custom shadow-[0_2px_6px_rgba(11,12,39,0.08),0_12px_32px_rgba(11,12,39,0.22)] ring-1 ring-black/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-custom md:text-sm",
                children: [
                  (0, e.jsx)(i.default, {
                    "aria-hidden": "true",
                    className: "h-4 w-4 shrink-0 text-blue-custom",
                  }),
                  (0, e.jsx)("span", {
                    className: "font-medium",
                    children: o("quiz_page_ab_myiq_hint_assist_counter", {
                      left: String(l),
                      total: String(c),
                    }),
                  }),
                ],
              }),
            })
          );
        },
      ],
      126695,
    );
  },
  360625,
  function (t) {
    t.n(t.i(126695));
  },
]);
