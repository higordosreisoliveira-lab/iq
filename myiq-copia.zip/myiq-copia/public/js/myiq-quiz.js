/* myiq-quiz.js — faithful reconstruction of the real myIQ quiz flow.
 * Captured live from myiq.com/pt-BR/quiz (40 screens: text, digit-sequence,
 * image matrices, memorize, motivational, reviews). Uses the real /quiz-images
 * SVGs and the real CSS classes so it renders identically, then computes a
 * score and advances to /analyzing -> /checkout.
 */
(function () {
  var root = document.getElementById('quiz-root');
  if (!root) return;

  var isPt = location.pathname.indexOf('/pt-BR') === 0;
  var P = function (prefix) { return (isPt ? '/pt-BR' : '') + prefix; };

  /* ---- exact real class strings (captured) ---- */
  var C = {
    wrap: 'mx-auto w-full max-w-7xl px-4 md:px-6 lg:px-8 mb-auto md:my-auto',
    pad: 'w-full py-6 max-xs-sm:py-4 md:py-10',
    col: 'mx-auto flex w-full max-w-lg flex-col items-center gap-5 max-xs-sm:gap-3 text-center md:gap-6',
    h1: 'text-balance text-hp-h2 max-xs-sm:text-[1.25rem] max-xs-sm:leading-[1.5rem] tabular-nums text-black-custom lg:text-hp-h2-lg',
    group: 'mx-auto flex w-full max-w-md flex-col gap-3 max-xs-sm:gap-2',
    optBtn: 'flex min-h-14 max-xs-sm:min-h-12 w-full items-center gap-3 rounded-2xl border px-4 max-xs-sm:px-3 py-3 max-xs-sm:py-2 text-left transition-[background-color,border-color,color,transform] duration-150 active:scale-[0.97] ease-[cubic-bezier(0.4,0,0.2,1)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom motion-reduce:transition-none md:px-5 border-slate-300 bg-white [@media(hover:hover)]:hover:border-slate-400 [@media(hover:hover)]:hover:bg-light-blue',
    optBadge: 'flex size-6 shrink-0 items-center justify-center rounded-full text-hp-caption font-medium tabular-nums bg-slate-100 text-grey-deep',
    optLabel: 'min-w-0 flex-1 text-pretty text-hp-body tabular-nums text-grey-deep',
    imgGrid: 'mx-auto grid w-full max-w-md grid-cols-2 gap-3 sm:grid-cols-3 max-xs-sm:gap-2',
    imgBtn: 'relative flex aspect-square w-full items-center justify-center rounded-2xl border p-2 transition-[background-color,border-color,transform] duration-150 active:scale-[0.97] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom border-slate-300 bg-white [@media(hover:hover)]:hover:border-slate-400 [@media(hover:hover)]:hover:bg-light-blue',
    imgBadge: 'absolute left-2 top-2 flex size-6 items-center justify-center rounded-full text-hp-caption font-medium bg-slate-100 text-grey-deep',
    primary: 'inline-flex items-center justify-center gap-2 shrink-0 select-none rounded-full border border-transparent font-medium whitespace-nowrap transition-colors duration-150 h-12 px-6 text-hp-body bg-green-custom text-white [@media(hover:hover)]:hover:bg-[#0B635C] active:bg-[#094F4A] w-full md:w-auto md:min-w-[16rem]',
  };

  var T = isPt ? {
    chooseAnswer: 'Escolha sua resposta:',
    memorizeWord: 'Memorize esta palavra', memorizeWordSub: 'Vamos perguntar sobre ela durante o teste',
    memorizeNumber: 'Memorize este número', memorizeSeqTitle: 'Memorize esta sequência de números',
    memorizeMore: 'Memorize mais uma palavra',
    memorized: 'Já memorizei', continueWhenReady: 'Continue quando quiser', cont: 'Continuar',
    quit: 'Sair do teste', of: 'de',
  } : {
    chooseAnswer: 'Choose your answer:',
    memorizeWord: 'Memorize this word', memorizeWordSub: 'We will ask about it during the test',
    memorizeNumber: 'Memorize this number', memorizeSeqTitle: 'Memorize this number sequence',
    memorizeMore: 'Memorize one more word',
    memorized: "I've memorized it", continueWhenReady: 'Continue when ready', cont: 'Continue',
    quit: 'Quit test', of: 'of',
  };

  /* ---- the real flow (captured from myiq.com) ---- */
  var W = isPt ? 'Cognitivo' : 'Cognitive';
  var SEQ = [4, 7, 2, 9, 5];
  function likert() {
    return isPt
      ? ['Concordo totalmente', 'Concordo', 'Neutro', 'Discordo', 'Discordo totalmente']
      : ['Strongly agree', 'Agree', 'Neutral', 'Disagree', 'Strongly disagree'];
  }
  function opt(list, correct) { return { options: list, correct: correct }; }

  // image question helper: prefix -> figure + 6 answers
  function imgQ(fig, answers, correct) { return { kind: 'image', figSrc: fig, answers: answers, correct: correct }; }
  function std(n, correct) {
    var a = []; for (var i = 1; i <= 6; i++) a.push('/quiz-images/' + n + '-' + i + '.svg');
    return imgQ('/quiz-images/question' + n + '.svg', a, correct);
  }
  var sudoku3 = imgQ('/quiz-images/sudoku/question-3/question-3.svg',
    ['a', 'b', 'c', 'd', 'e', 'f'].map(function (x) { return '/quiz-images/sudoku/question-3/answer-' + x + '.svg'; }), 2);
  var sudoku4 = imgQ('/quiz-images/sudoku/question-4/question-4.svg',
    ['a', 'b', 'c', 'd', 'e', 'f'].map(function (x) { return '/quiz-images/sudoku/question-4/answer-' + x + '.svg'; }), 3);
  var abV1 = imgQ('/quiz-images/ab-new-image-questions/v1/question.svg',
    ['answer-a', 'answer-b', 'answer-c correct', 'answer-d', 'answer-e', 'answer-f'].map(function (x) { return '/quiz-images/ab-new-image-questions/v1/' + x + '.svg'; }), 2);

  var FLOW = [
    { kind: 'memorize', title: T.memorizeWord, sub: T.memorizeWordSub, value: W, big: true, btn: T.memorized },
    { kind: 'text', prompt: isPt ? 'Um fazendeiro tem 15 ovelhas. Todas morrem, menos 8. Quantas sobraram?' : 'A farmer has 15 sheep. All but 8 die. How many are left?', opt: opt(['7', '8', '15', '0', '3'], 1) },
    { kind: 'text', prompt: isPt ? 'Você ultrapassa a pessoa que está em 3º lugar. Em que lugar você está?' : 'You overtake the person in 3rd place. What place are you in?', opt: opt(['1', '4', '3', '2', '5'], 2) },
    { kind: 'text', prompt: isPt ? 'Quantos cantos tem um cubo?' : 'How many corners does a cube have?', opt: opt(['6', '4', '8', '5', '7'], 2) },
    { kind: 'text', prompt: isPt ? 'Eu prefiro aprender na prática' : 'I prefer to learn by doing', opt: opt(likert(), -1) },
    { kind: 'text', prompt: isPt ? 'Qual é o próximo número desta sequência? 2, 4, 8, 16, ___' : 'What is the next number in this sequence? 2, 4, 8, 16, ___', opt: opt(['20', '24', '30', '32', '36'], 3) },
    { kind: 'text', prompt: isPt ? 'Qual número está faltando? 3, 6, 9, 12, ___, 18' : 'Which number is missing? 3, 6, 9, 12, ___, 18', opt: opt(['13', '14', '15', '16', '17'], 2) },
    { kind: 'sequence', title: T.memorizeSeqTitle, value: SEQ.join('  '), btn: T.memorized },
    { kind: 'text', prompt: isPt ? 'Qual era o 2º dígito?' : 'What was the 2nd digit?', opt: opt(['7', '3', '8', '1', '5'], 0) },
    { kind: 'sequence', title: T.memorizeSeqTitle, value: SEQ.join('  '), btn: T.memorized },
    { kind: 'text', prompt: isPt ? 'Qual era o 3º dígito?' : 'What was the 3rd digit?', opt: opt(['9', '2', '6', '3', '4'], 1) },
    { kind: 'sequence', title: T.memorizeSeqTitle, value: SEQ.join('  '), btn: T.memorized },
    { kind: 'text', prompt: isPt ? 'Qual era o 4º dígito?' : 'What was the 4th digit?', opt: opt(['5', '1', '7', '9', '3'], 3) },
    { kind: 'text', prompt: isPt ? 'Eu visualizo objetos em 3D na minha mente com facilidade' : 'I can visualize 3D objects in my mind easily', opt: opt(likert(), -1) },
    std(1, 3), // q11
    { kind: 'motivational', text: isPt ? 'Sua velocidade supera a de 75% de todos os participantes do teste! ⚡️' : 'Your speed beats 75% of all test takers! ⚡️', btn: T.cont },
    std(2, 0), std(3, 1), std(4, 4), std(5, 2), std(6, 5), std(7, 0), std(8, 4), std(9, 3), std(10, 2), std(11, 1), std(12, 3),
    { kind: 'motivational', text: isPt ? 'Você está superando 28% dos participantes no Brasil' : "You're outperforming 28% of test takers in your country", btn: T.cont },
    std(13, 0),
    { kind: 'text', prompt: isPt ? 'Qual palavra pedimos para você lembrar no início?' : 'Which word did we ask you to remember at the start?', opt: opt(isPt ? ['Esperto', 'QI', 'Cérebro', 'Cognitivo', 'Inteligência'] : ['Smart', 'IQ', 'Brain', 'Cognitive', 'Intelligence'], 3) },
    std(14, 2), std(15, 5), std(16, 1), std(17, 0),
    { kind: 'memorize', title: T.memorizeNumber, value: '7  2  8  4', big: true, btn: T.memorized },
    std(18, 4), sudoku3, std(20, 1),
    { kind: 'motivational', text: isPt ? 'Um padrão está começando a aparecer no seu jeito de pensar 👀️' : 'A pattern is starting to emerge in how you think 👀️', btn: T.cont },
    std(21, 3), std(22, 0), sudoku4, abV1,
    abV1, // q36 (v2 not downloaded; reuse v1 matrix identically)
    { kind: 'text', prompt: isPt ? 'Eu acredito que a inteligência se desenvolve com esforço contínuo' : 'I believe intelligence develops through continuous effort', opt: opt(likert(), -1) },
    { kind: 'text', prompt: isPt ? 'Eu costumo refletir sobre o meu desempenho em comparação com o dos outros' : 'I often reflect on my performance compared to others', opt: opt(likert(), -1) },
    { kind: 'memorize', title: T.memorizeMore, value: isPt ? 'Padrão' : 'Pattern', big: true, btn: T.memorized },
    { kind: 'text', prompt: isPt ? 'Qual é a sua idade?' : 'What is your age?', opt: opt(['18-25', '26-29', '30–44', '45–60', isPt ? '61 anos ou mais' : '61 or older'], -1) },
    { kind: 'text', prompt: isPt ? 'Qual é o seu nível de escolaridade?' : 'What is your education level?', opt: opt(isPt ? ['Ensino médio incompleto', 'Ensino médio completo', 'Curso técnico ou tecnólogo', 'Ensino superior completo', 'Pós-graduação'] : ['Some high school', 'High school', 'Technical / associate', 'Bachelor’s degree', 'Postgraduate'], -1) },
    { kind: 'motivational', text: isPt ? 'Você está quase lá! Faltam só 5 perguntas! ⚡️' : "You're almost there! Just 5 questions left! ⚡️", btn: T.cont },
    { kind: 'reviews', title: isPt ? 'Mais de 8 milhões de pessoas já descobriram a própria pontuação de QI com o myIQ' : 'Over 8 million people have discovered their IQ score with myIQ', btn: T.cont },
  ];

  /* ---- state ---- */
  var idx = 0, correct = 0, totalQ = 0, answered = 0;
  FLOW.forEach(function (s) { if (s.kind === 'text' || s.kind === 'image') totalQ++; });
  var timeLeft = 20 * 60;

  var bar = document.getElementById('quiz-progress-bar');
  var numEl = document.getElementById('quiz-current-num');
  var totalEl = document.getElementById('quiz-total-num');
  var timerEl = document.getElementById('quiz-timer-display');
  if (totalEl) totalEl.textContent = String(FLOW.length);

  var tmr = setInterval(function () {
    timeLeft--; if (timeLeft < 0) { clearInterval(tmr); finish(); return; }
    if (timerEl) { var m = Math.floor(timeLeft / 60), s = timeLeft % 60; timerEl.textContent = (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s; }
  }, 1000);

  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;'); }
  var LETTERS = ['A', 'B', 'C', 'D', 'E', 'F'];

  function textScreen(s) {
    var showLetters = s.opt.options.length <= 5 && s.opt.correct !== -1 ? true : s.opt.options.length <= 5;
    var opts = s.opt.options.map(function (o, i) {
      var badge = (s.opt.options.length <= 5 && s.opt.correct !== undefined)
        ? '<span aria-hidden="true" class="' + C.optBadge + '">' + LETTERS[i] + '</span>' : '';
      return '<button type="button" data-i="' + i + '" class="' + C.optBtn + '">' + badge +
        '<span class="' + C.optLabel + '">' + esc(o) + '</span></button>';
    }).join('');
    return '<div class="' + C.col + '"><h1 class="' + C.h1 + '">' + esc(s.prompt) + '</h1>' +
      '<div class="' + C.group + '">' + opts + '</div></div>';
  }
  function imageScreen(s) {
    var fig = '<div class="mx-auto w-full max-w-md"><img draggable="false" width="464" height="352" class="h-auto w-full" src="' + s.figSrc + '" alt=""></div>';
    var opts = s.answers.map(function (src, i) {
      return '<button type="button" data-i="' + i + '" class="' + C.imgBtn + '"><span aria-hidden="true" class="' + C.imgBadge + '">' + LETTERS[i] + '</span>' +
        '<img draggable="false" class="h-full w-full object-contain p-1" src="' + src + '" alt=""></button>';
    }).join('');
    return '<div class="' + C.col + '">' + fig + '<h1 class="' + C.h1 + '">' + T.chooseAnswer + '</h1>' +
      '<div class="' + C.imgGrid + '">' + opts + '</div></div>';
  }
  function memorizeScreen(s) {
    return '<div class="' + C.col + '"><h1 class="' + C.h1 + '">' + esc(s.title) + '</h1>' +
      (s.sub ? '<p class="mt-1 max-w-md text-pretty text-hp-lede text-grey-deep">' + esc(s.sub) + '</p>' : '') +
      '<div class="mt-2 flex w-full items-center justify-center rounded-3xl bg-slate-100/[0.88] px-6 py-10 md:py-14">' +
      '<p class="text-balance text-[2.5rem] font-semibold leading-[2.75rem] text-black-custom md:text-hp-hero-lg">' + esc(s.value) + '</p></div>' +
      '<button type="button" data-next="1" class="' + C.primary + '">' + esc(s.btn) + '</button></div>';
  }
  function motivationalScreen(s) {
    return '<div class="' + C.col + '"><div class="text-5xl">🎉</div><h1 class="' + C.h1 + '">' + esc(s.text) + '</h1>' +
      '<button type="button" data-next="1" class="' + C.primary + '">' + esc(s.btn) + '</button></div>';
  }
  function reviewsScreen(s) {
    return '<div class="' + C.col + '"><h1 class="' + C.h1 + '">' + esc(s.title) + '</h1>' +
      '<div class="flex items-center gap-1 text-green-custom">' + '★★★★★'.split('').map(function () { return '★'; }).join('') + '</div>' +
      '<p class="text-hp-body text-grey-deep">4.1 / 5 · 151,263 ' + (isPt ? 'avaliações no Trustpilot' : 'reviews on Trustpilot') + '</p>' +
      '<button type="button" data-next="1" class="' + C.primary + '">' + esc(s.btn) + '</button></div>';
  }

  function render() {
    var s = FLOW[idx];
    if (!s) return finish();
    var html;
    if (s.kind === 'text') html = textScreen(s);
    else if (s.kind === 'image') html = imageScreen(s);
    else if (s.kind === 'memorize' || s.kind === 'sequence') html = memorizeScreen(s);
    else if (s.kind === 'motivational') html = motivationalScreen(s);
    else if (s.kind === 'reviews') html = reviewsScreen(s);
    root.innerHTML = '<div class="' + C.wrap + '"><div class="' + C.pad + '">' + html + '</div></div>';

    var pct = Math.round(((idx + 1) / FLOW.length) * 100);
    if (bar) bar.style.width = pct + '%';
    if (numEl) numEl.textContent = String(idx + 1);

    root.querySelectorAll('[data-i]').forEach(function (b) {
      b.addEventListener('click', function () {
        var i = +b.getAttribute('data-i');
        if (s.opt && s.opt.correct === i) correct++;
        if (s.answers && s.correct === i) correct++;
        answered++;
        b.classList.add('border-green-custom', 'bg-light-blue');
        setTimeout(next, 180);
      });
    });
    root.querySelectorAll('[data-next]').forEach(function (b) { b.addEventListener('click', function () { setTimeout(next, 60); }); });
    window.scrollTo(0, 0);
  }
  function next() { idx++; if (idx >= FLOW.length) finish(); else render(); }

  function finish() {
    clearInterval(tmr);
    var ratio = totalQ ? correct / totalQ : 0.6;
    var iq = Math.round(92 + ratio * 48 + (answered > 30 ? 4 : 0));
    iq = Math.max(85, Math.min(149, iq));
    var pct = Math.min(99.6, Math.max(25, Math.round((iq - 55) / 90 * 99 * 10) / 10));
    var result = {
      score: iq, percentile: pct, correctCount: correct, totalQuestions: totalQ,
      domains: {
        fluid: clamp(iq + rnd(-3, 4)), visual: clamp(iq + rnd(-5, 3)), memory: clamp(iq + rnd(-2, 5)),
        pattern: clamp(iq + rnd(-1, 4)), logic: clamp(iq + rnd(-4, 3)),
      }, completedAt: new Date().toISOString(),
    };
    try { localStorage.setItem('myiq_test_result', JSON.stringify(result)); } catch (e) {}
    location.href = P('/analyzing');
  }
  function rnd(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }
  function clamp(v) { return Math.max(70, Math.min(155, v)); }

  // keyboard A-F / 1-6
  document.addEventListener('keydown', function (e) {
    var k = e.key.toUpperCase();
    var map = { '1': 0, '2': 1, '3': 2, '4': 3, '5': 4, '6': 5, 'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4, 'F': 5 };
    if (k in map) { var b = root.querySelector('[data-i="' + map[k] + '"]'); if (b) b.click(); }
    if (k === 'ENTER') { var n = root.querySelector('[data-next]'); if (n) n.click(); }
  });

  render();
})();
