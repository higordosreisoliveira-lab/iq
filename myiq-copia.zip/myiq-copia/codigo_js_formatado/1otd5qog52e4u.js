(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  812384,
  408110,
  (e) => {
    "use strict";
    var t = e.i(954616),
      a = e.i(86596);
    e.i(682770);
    var r = e.i(934952),
      n = e.i(117595),
      i = e.i(866897),
      s = e.i(134404),
      l = e.i(157273),
      c = e.i(60423);
    e.i(756503);
    var o = e.i(542516);
    e.i(531122);
    var u = e.i(81844);
    let d = async (e) => {
        let t = await u.httpInstance.post(s.EApiRoutes.CHECKOUT_SESSION, {
            json: ((e) => {
              if (!e.userData || e.userData.quiz_answers_additional?.length) return e;
              let t = c.accessLocalStorage.getItem(l.StorageKeys.MYIQ_NON_IMAGE_ANSWERS);
              if (!t) return e;
              try {
                let a = JSON.parse(t);
                if (Array.isArray(a) && a.length)
                  return { ...e, userData: { ...e.userData, quiz_answers_additional: a } };
              } catch {}
              return e;
            })(
              ((e) => {
                if (!e.userData || e.userData.quiz_answers?.length) return e;
                let t = c.accessLocalStorage.getItem(l.StorageKeys.QUIZ_ANSWERS);
                if (!t) return e;
                try {
                  let a = JSON.parse(t);
                  if (Array.isArray(a) && a.length)
                    return { ...e, userData: { ...e.userData, quiz_answers: a } };
                } catch {}
                return e;
              })(e),
            ),
            throwHttpErrors: !1,
          }),
          a = await t.json();
        return (
          a.success &&
            a.data?.paynextClientSessionId &&
            n.default.set(i.ECookieArg.PAYNEXT_SESSION, a.data?.paynextClientSessionId, {
              secure: "production" === o.envClient.NEXT_PUBLIC_APP_ENV,
              expires: 40 / 24,
              path: "/",
              sameSite: "lax",
            }),
          a
        );
      },
      p = async (e) => {
        let t = await u.httpInstance.post(s.EApiRoutes.CHECKOUT_SESSION, { json: e, throwHttpErrors: !1 });
        return (await t.json()).data ?? null;
      },
      m = async (e) =>
        (
          await u.httpInstance.post(s.EApiRoutes.CHECKOUT_SESSION_FRAUD_SESSIONS, {
            json: e,
            throwHttpErrors: !1,
          })
        ).json();
    (e.s(
      [
        "createUserSessionFetcher",
        0,
        d,
        "getCheckoutSessionPriceFetcher",
        0,
        p,
        "updateCheckoutSessionFraudSessionsFetcher",
        0,
        m,
      ],
      408110,
    ),
      e.s(
        [
          "useCreateUserSessionMutation",
          0,
          () => {
            let e = (0, a.useUserStore)((e) => e.handleChangeUserStore),
              n = (0, t.useMutation)({
                mutationFn: d,
                onSuccess(t) {
                  t.success
                    ? t.data &&
                      e({
                        user: {
                          paymentInfo: {
                            ...t.data,
                            paynextAmountPayment: t.data.paynextAmountPayment?.toString(),
                          },
                        },
                      })
                    : (0, r.customToast)(t?.error || "", "error");
                },
              });
            return { ...n, trigger: n.mutateAsync };
          },
          "useUpdateCheckoutSessionFraudSessionsMutation",
          0,
          () => {
            let e = (0, t.useMutation)({ mutationFn: m });
            return { ...e, trigger: e.mutateAsync };
          },
        ],
        812384,
      ));
  },
  599545,
  (e) => {
    "use strict";
    var t = e.i(492669);
    e.s(["IconCheckmark", () => t.default]);
  },
  973924,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(948148),
      r = e.i(271645),
      n = e.i(663615),
      i = e.i(408110),
      s = e.i(812384);
    e.i(842582);
    var l = e.i(76399),
      c = e.i(715413),
      o = e.i(523173);
    e.i(934337);
    var u = e.i(599545);
    e.i(470366);
    var d = e.i(504001);
    e.i(80460);
    var p = e.i(998198),
      m = e.i(998978);
    e.i(118046);
    var x = e.i(112015);
    e.i(473189);
    var f = e.i(476880),
      h = e.i(823933);
    e.s([
      "default",
      0,
      (e) => {
        let { user: y, selectedPlan: g, onPlanChange: S, isMarketingSource: b, idSuffix: _ = "" } = e,
          N = (0, a.useTranslations)(),
          { trigger: C } = (0, s.useCreateUserSessionMutation)(),
          { deviceData: w } = (0, c.useBraintreeDataCollector)(),
          { getAttributionData: v } = (0, l.useCollectParams)(),
          [P, E] = (0, r.useState)(!1),
          I = (0, r.useRef)(!1),
          j = (0, r.useRef)(null),
          A = (0, r.useRef)(!1),
          [D, k] = (0, r.useState)({}),
          T = (0, r.useRef)(!1),
          O = () => ("string" == typeof w ? w : JSON.stringify(w) || ""),
          R = async (e) => {
            if (y && !I.current && j.current !== e) {
              ((I.current = !0), (j.current = e), E(!0));
              try {
                await C({
                  attributionData: (0, f.getPaymentAttributionData)(v()),
                  isMarketingSource: !!b,
                  deviceData: O(),
                  userData: y,
                  planId: e,
                });
              } finally {
                ((I.current = !1), E(!1));
              }
            }
          };
        ((0, r.useEffect)(() => {
          if (!y || A.current) return;
          A.current = !0;
          let e = (0, h.getPlanPickerConfig)(g);
          e && R(e.planId);
        }, [y]),
          (0, r.useEffect)(() => {
            if (!y || T.current) return;
            T.current = !0;
            let e = (0, f.getPaymentAttributionData)(v()),
              t = O();
            Promise.all(
              x.PLAN_PICKER_CONFIG.map((a) =>
                (0, i.getCheckoutSessionPriceFetcher)({
                  userData: y,
                  planId: a.planId,
                  attributionData: e,
                  isMarketingSource: !!b,
                  deviceData: t,
                })
                  .then((e) => ({ id: a.id, data: e }))
                  .catch(() => ({ id: a.id, data: null })),
              ),
            ).then((e) => {
              let t = {};
              for (let a of e) a.data && (t[a.id] = a.data);
              k(t);
            });
          }, [y]));
        let U = (e) => (0, p.getCalculatePriceForView)(e, y),
          K = (e) => (0, p.getPaymentPlanPrice)({ paymentPlan: e, user: y }).priceForView,
          F = (e) => {
            let t = D[e.id],
              a = t?.paynextAmountToPay ?? U(K(e.trialPriceKey)),
              r = t?.paynextAmountMonth ?? U(K(e.renewalPriceKey)),
              n = 10 ** (0, m.getCurrencyMinorUnits)(y?.currency?.currencyCode || "USD"),
              i = t?.paynextAmountDisplayed
                ? Number(t.paynextAmountDisplayed)
                : Math.round(K(e.trialPriceKey) * n),
              s = t?.billing_price ?? Math.round(K(e.renewalPriceKey) * n);
            return {
              trialStr: a,
              renewalStr: r,
              perDayStr: U(i / n / e.perDayDivisor),
              savePercent: (0, p.getSale)(s, i, !0),
            };
          },
          M = F((0, h.getPlanPickerConfig)(g) ?? x.PLAN_PICKER_CONFIG[0]);
        return (0, t.jsxs)("div", {
          id: `checkout-coupon-disclaimer${_}`,
          className: "flex flex-col gap-4",
          children: [
            (0, t.jsx)("div", {
              className: "flex flex-col gap-3",
              role: "radiogroup",
              "aria-label": N("payment_plan_selection_aria_label"),
              children: x.PLAN_PICKER_CONFIG.map((e) => {
                let a = g === e.id,
                  r = F(e);
                return (0, t.jsx)(
                  "button",
                  {
                    type: "button",
                    role: "radio",
                    "aria-checked": a,
                    disabled: P,
                    onClick: () =>
                      ((e) => {
                        if (I.current) return;
                        let t = (0, h.getPlanPickerConfig)(g),
                          a = (0, h.getPlanPickerConfig)(e);
                        ((0, d.trackClientEvents)({
                          event: o.EAnalyticEvents.PAYWALL_PLAN_SELECTED,
                          user: y,
                          params: {
                            plan_picker_funnel: !0,
                            plan_id: a?.planId ?? "",
                            previous_plan_id: t?.planId ?? "",
                            plan_name: a?.planName ?? "",
                            price: a ? F(a).trialStr : "",
                          },
                        }),
                          e !== g && a && (S(e), R(a.planId)));
                      })(e.id),
                    className: (0, n.cn)(
                      "relative w-full rounded-xl border-2 px-4 py-3 text-left transition-all duration-200 disabled:opacity-60",
                      a ? "border-green-custom bg-green-custom/5" : "border-zinc-200 bg-white",
                    ),
                    children: (0, t.jsxs)("div", {
                      className: "flex w-full items-center justify-between gap-4",
                      children: [
                        (0, t.jsxs)("div", {
                          className: "flex items-center gap-3",
                          children: [
                            (0, t.jsx)("span", {
                              className: (0, n.cn)(
                                "flex h-5 w-5 shrink-0 items-center justify-center rounded-full",
                                a ? "bg-green-custom" : "border-2 border-zinc-200 bg-white",
                              ),
                              children: a
                                ? (0, t.jsx)(u.IconCheckmark, { className: "h-3 w-3 text-white" })
                                : null,
                            }),
                            (0, t.jsxs)("div", {
                              className: "flex flex-col",
                              children: [
                                (0, t.jsx)("span", {
                                  className: "text-base font-semibold text-[#323a50]",
                                  children: N(e.labelKey),
                                }),
                                (0, t.jsxs)("div", {
                                  className: "flex flex-wrap items-center gap-2",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className: "text-sm font-medium text-[#323a50]",
                                      children: r.trialStr,
                                    }),
                                    (0, t.jsx)("span", {
                                      className: "text-sm text-neutral-500 line-through",
                                      children: r.renewalStr,
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            e.badgeKey
                              ? (0, t.jsx)("span", {
                                  className:
                                    "hidden rounded-full border border-blue-600 bg-blue-50 px-2.5 py-1 text-xs font-semibold text-blue-600 xs-m:block",
                                  children: N(e.badgeKey),
                                })
                              : null,
                          ],
                        }),
                        (0, t.jsxs)("div", {
                          className: "shrink-0 text-right",
                          children: [
                            (0, t.jsx)("p", {
                              className: "text-base font-bold text-[#0D0D0E]",
                              children: r.perDayStr,
                            }),
                            (0, t.jsx)("p", {
                              className: "text-xs text-neutral-500",
                              children: N("plan_picker_per_day"),
                            }),
                          ],
                        }),
                      ],
                    }),
                  },
                  e.id,
                );
              }),
            }),
            (0, t.jsxs)("div", {
              className: "mb-4 flex items-center justify-between sm:mb-5",
              children: [
                (0, t.jsx)("p", {
                  className: "text-lg font-semibold text-[#0D0D0E]",
                  children: N("plan_picker_due_today_label"),
                }),
                (0, t.jsxs)("div", {
                  className: "flex flex-col items-end",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex items-center justify-end gap-2",
                      children: [
                        (0, t.jsx)("span", {
                          className: "mt-px text-sm font-semibold text-neutral-500 line-through",
                          children: M.renewalStr,
                        }),
                        (0, t.jsx)("span", {
                          className: "text-lg font-bold text-[#0D0D0E]",
                          children: M.trialStr,
                        }),
                      ],
                    }),
                    (0, t.jsx)("span", {
                      className: "text-xs font-semibold text-blue-600",
                      children: N("checkout_page_you_save", { sale: M.savePercent }),
                    }),
                  ],
                }),
              ],
            }),
          ],
        });
      },
    ]);
  },
  380091,
  function (e) {
    e.n(e.i(973924));
  },
  715413,
  (e) => {
    "use strict";
    var t = e.i(271645);
    e.i(756503);
    var a = e.i(542516);
    let r = [
      "https://js.braintreegateway.com/web/3.133.0/js/client.min.js",
      "https://js.braintreegateway.com/web/3.133.0/js/data-collector.min.js",
    ];
    e.s([
      "useBraintreeDataCollector",
      0,
      () => {
        let [e, n] = (0, t.useState)(null),
          [i, s] = (0, t.useState)(!1),
          [l, c] = (0, t.useState)(null);
        return (
          (0, t.useEffect)(() => {
            if ("u" > typeof document)
              for (let e of r) {
                if (document.querySelector(`script[src="${e}"]`)) continue;
                let t = document.createElement("script");
                ((t.src = e), (t.async = !0), document.head.appendChild(t));
              }
            let e = null,
              t = null,
              i = Date.now(),
              l = () =>
                !!(window.braintree?.client && window.braintree?.dataCollector) &&
                (e && (clearInterval(e), (e = null)),
                t && (clearTimeout(t), (t = null)),
                s(!0),
                c(null),
                window.braintree?.client?.create(
                  { authorization: a.envClient.NEXT_PUBLIC_BRAINTREE_AUTHORIZATION || "" },
                  function (e, t) {
                    if (e) {
                      (n(""), s(!1));
                      return;
                    }
                    window?.braintree?.dataCollector?.create({ client: t }, function (e, t) {
                      (s(!1), e) ? n("") : n(t.deviceData);
                    });
                  },
                ),
                !0);
            if (!l())
              return (
                (e = setInterval(() => {
                  !l() && Date.now() - i >= 1e4 && (e && (clearInterval(e), (e = null)), n(""));
                }, 100)),
                (t = setTimeout(() => {
                  (e && (clearInterval(e), (e = null)), window.braintree || n(""));
                }, 1e4)),
                () => {
                  (e && clearInterval(e), t && clearTimeout(t));
                }
              );
          }, []),
          { deviceData: e, isCollecting: i, error: l }
        );
      },
    ]);
  },
]);
