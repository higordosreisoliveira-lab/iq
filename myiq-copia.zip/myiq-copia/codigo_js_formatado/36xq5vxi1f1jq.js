(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  352445,
  (t, e, r) => {
    ((e.exports = function (t, e) {
      if (!(t instanceof e)) throw TypeError("Cannot call a class as a function");
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  514356,
  (t, e, r) => {
    var n = t.r(863974);
    function o(t, e) {
      for (var r = 0; r < e.length; r++) {
        var o = e[r];
        ((o.enumerable = o.enumerable || !1),
          (o.configurable = !0),
          "value" in o && (o.writable = !0),
          Object.defineProperty(t, n(o.key), o));
      }
    }
    ((e.exports = function (t, e, r) {
      return (
        e && o(t.prototype, e),
        r && o(t, r),
        Object.defineProperty(t, "prototype", { writable: !1 }),
        t
      );
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  332164,
  (t, e, r) => {
    ((e.exports = function (t) {
      if (void 0 === t) throw ReferenceError("this hasn't been initialised - super() hasn't been called");
      return t;
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  180689,
  (t, e, r) => {
    var n = t.r(935045).default,
      o = t.r(332164);
    ((e.exports = function (t, e) {
      if (e && ("object" == n(e) || "function" == typeof e)) return e;
      if (void 0 !== e) throw TypeError("Derived constructors may only return object or undefined");
      return o(t);
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  619823,
  (t, e, r) => {
    function n(t) {
      return (
        (e.exports = n =
          Object.setPrototypeOf
            ? Object.getPrototypeOf.bind()
            : function (t) {
                return t.__proto__ || Object.getPrototypeOf(t);
              }),
        (e.exports.__esModule = !0),
        (e.exports.default = e.exports),
        n(t)
      );
    }
    ((e.exports = n), (e.exports.__esModule = !0), (e.exports.default = e.exports));
  },
  410885,
  (t, e, r) => {
    function n(t, r) {
      return (
        (e.exports = n =
          Object.setPrototypeOf
            ? Object.setPrototypeOf.bind()
            : function (t, e) {
                return ((t.__proto__ = e), t);
              }),
        (e.exports.__esModule = !0),
        (e.exports.default = e.exports),
        n(t, r)
      );
    }
    ((e.exports = n), (e.exports.__esModule = !0), (e.exports.default = e.exports));
  },
  59947,
  (t, e, r) => {
    var n = t.r(410885);
    ((e.exports = function (t, e) {
      if ("function" != typeof e && null !== e)
        throw TypeError("Super expression must either be null or a function");
      ((t.prototype = Object.create(e && e.prototype, {
        constructor: { value: t, writable: !0, configurable: !0 },
      })),
        Object.defineProperty(t, "prototype", { writable: !1 }),
        e && n(t, e));
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  245813,
  (t, e, r) => {
    ((e.exports = function (t) {
      try {
        return -1 !== Function.toString.call(t).indexOf("[native code]");
      } catch (e) {
        return "function" == typeof t;
      }
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  858524,
  (t, e, r) => {
    function n() {
      try {
        var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
      } catch (t) {}
      return ((e.exports = n =
        function () {
          return !!t;
        }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports))();
    }
    ((e.exports = n), (e.exports.__esModule = !0), (e.exports.default = e.exports));
  },
  742062,
  (t, e, r) => {
    var n = t.r(858524),
      o = t.r(410885);
    ((e.exports = function (t, e, r) {
      if (n()) return Reflect.construct.apply(null, arguments);
      var a = [null];
      a.push.apply(a, e);
      var u = new (t.bind.apply(t, a))();
      return (r && o(u, r.prototype), u);
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  413098,
  (t, e, r) => {
    var n = t.r(619823),
      o = t.r(410885),
      a = t.r(245813),
      u = t.r(742062);
    function s(t) {
      var r = "function" == typeof Map ? new Map() : void 0;
      return (
        (e.exports = s =
          function (t) {
            if (null === t || !a(t)) return t;
            if ("function" != typeof t) throw TypeError("Super expression must either be null or a function");
            if (void 0 !== r) {
              if (r.has(t)) return r.get(t);
              r.set(t, e);
            }
            function e() {
              return u(t, arguments, n(this).constructor);
            }
            return (
              (e.prototype = Object.create(t.prototype, {
                constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 },
              })),
              o(e, t)
            );
          }),
        (e.exports.__esModule = !0),
        (e.exports.default = e.exports),
        s(t)
      );
    }
    ((e.exports = s), (e.exports.__esModule = !0), (e.exports.default = e.exports));
  },
  641731,
  (t, e, r) => {
    "use strict";
    var n = t.r(13451);
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      (r.UnsupportedStrategy =
        r.UnknownError =
        r.OAuthCallbackError =
        r.MissingSecret =
        r.MissingAuthorize =
        r.MissingAdapterMethods =
        r.MissingAdapter =
        r.MissingAPIRoute =
        r.InvalidCallbackUrl =
        r.AccountNotLinkedError =
          void 0),
      (r.adapterErrorHandler = function (t, e) {
        if (t)
          return Object.keys(t).reduce(function (r, n) {
            return (
              (r[n] = (0, a.default)(
                o.default.mark(function r() {
                  var a,
                    u,
                    s,
                    i,
                    c,
                    l = arguments;
                  return o.default.wrap(
                    function (r) {
                      for (;;)
                        switch ((r.prev = r.next)) {
                          case 0:
                            for (r.prev = 0, u = Array((a = l.length)), s = 0; s < a; s++) u[s] = l[s];
                            return (
                              e.debug("adapter_".concat(n), { args: u }),
                              (i = t[n]),
                              (r.next = 6),
                              i.apply(void 0, u)
                            );
                          case 6:
                            return r.abrupt("return", r.sent);
                          case 9:
                            throw (
                              (r.prev = 9),
                              (r.t0 = r.catch(0)),
                              e.error("adapter_error_".concat(n), r.t0),
                              ((c = new h(r.t0)).name = "".concat(y(n), "Error")),
                              c
                            );
                          case 15:
                          case "end":
                            return r.stop();
                        }
                    },
                    r,
                    null,
                    [[0, 9]],
                  );
                }),
              )),
              r
            );
          }, {});
      }),
      (r.capitalize = y),
      (r.eventsErrorHandler = function (t, e) {
        return Object.keys(t).reduce(function (r, n) {
          return (
            (r[n] = (0, a.default)(
              o.default.mark(function r() {
                var a,
                  u = arguments;
                return o.default.wrap(
                  function (r) {
                    for (;;)
                      switch ((r.prev = r.next)) {
                        case 0:
                          return ((r.prev = 0), (a = t[n]), (r.next = 4), a.apply(void 0, u));
                        case 4:
                          return r.abrupt("return", r.sent);
                        case 7:
                          ((r.prev = 7), (r.t0 = r.catch(0)), e.error("".concat(v(n), "_EVENT_ERROR"), r.t0));
                        case 10:
                        case "end":
                          return r.stop();
                      }
                  },
                  r,
                  null,
                  [[0, 7]],
                );
              }),
            )),
            r
          );
        }, {});
      }),
      (r.upperSnake = v));
    var o = n(t.r(231277)),
      a = n(t.r(145940)),
      u = n(t.r(514414)),
      s = n(t.r(352445)),
      i = n(t.r(514356)),
      c = n(t.r(180689)),
      l = n(t.r(619823)),
      f = n(t.r(59947));
    function p(t, e, r) {
      return (
        (e = (0, l.default)(e)),
        (0, c.default)(t, d() ? Reflect.construct(e, r || [], (0, l.default)(t).constructor) : e.apply(t, r))
      );
    }
    function d() {
      try {
        var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
      } catch (t) {}
      return (d = function () {
        return !!t;
      })();
    }
    var h = (r.UnknownError = (function (t) {
      function e(t) {
        var r, n;
        return (
          (0, s.default)(this, e),
          ((n = p(this, e, [null != (r = null == t ? void 0 : t.message) ? r : t])).name = "UnknownError"),
          (n.code = t.code),
          t instanceof Error && (n.stack = t.stack),
          n
        );
      }
      return (
        (0, f.default)(e, t),
        (0, i.default)(e, [
          {
            key: "toJSON",
            value: function () {
              return { name: this.name, message: this.message, stack: this.stack };
            },
          },
        ])
      );
    })((0, n(t.r(413098)).default)(Error)));
    function v(t) {
      return t.replace(/([A-Z])/g, "_$1").toUpperCase();
    }
    function y(t) {
      return "".concat(t[0].toUpperCase()).concat(t.slice(1));
    }
    ((r.OAuthCallbackError = (function (t) {
      function e() {
        var t;
        (0, s.default)(this, e);
        for (var r = arguments.length, n = Array(r), o = 0; o < r; o++) n[o] = arguments[o];
        return ((t = p(this, e, [].concat(n))), (0, u.default)(t, "name", "OAuthCallbackError"), t);
      }
      return ((0, f.default)(e, t), (0, i.default)(e));
    })(h)),
      (r.AccountNotLinkedError = (function (t) {
        function e() {
          var t;
          (0, s.default)(this, e);
          for (var r = arguments.length, n = Array(r), o = 0; o < r; o++) n[o] = arguments[o];
          return ((t = p(this, e, [].concat(n))), (0, u.default)(t, "name", "AccountNotLinkedError"), t);
        }
        return ((0, f.default)(e, t), (0, i.default)(e));
      })(h)),
      (r.MissingAPIRoute = (function (t) {
        function e() {
          var t;
          (0, s.default)(this, e);
          for (var r = arguments.length, n = Array(r), o = 0; o < r; o++) n[o] = arguments[o];
          return (
            (t = p(this, e, [].concat(n))),
            (0, u.default)(t, "name", "MissingAPIRouteError"),
            (0, u.default)(t, "code", "MISSING_NEXTAUTH_API_ROUTE_ERROR"),
            t
          );
        }
        return ((0, f.default)(e, t), (0, i.default)(e));
      })(h)),
      (r.MissingSecret = (function (t) {
        function e() {
          var t;
          (0, s.default)(this, e);
          for (var r = arguments.length, n = Array(r), o = 0; o < r; o++) n[o] = arguments[o];
          return (
            (t = p(this, e, [].concat(n))),
            (0, u.default)(t, "name", "MissingSecretError"),
            (0, u.default)(t, "code", "NO_SECRET"),
            t
          );
        }
        return ((0, f.default)(e, t), (0, i.default)(e));
      })(h)),
      (r.MissingAuthorize = (function (t) {
        function e() {
          var t;
          (0, s.default)(this, e);
          for (var r = arguments.length, n = Array(r), o = 0; o < r; o++) n[o] = arguments[o];
          return (
            (t = p(this, e, [].concat(n))),
            (0, u.default)(t, "name", "MissingAuthorizeError"),
            (0, u.default)(t, "code", "CALLBACK_CREDENTIALS_HANDLER_ERROR"),
            t
          );
        }
        return ((0, f.default)(e, t), (0, i.default)(e));
      })(h)),
      (r.MissingAdapter = (function (t) {
        function e() {
          var t;
          (0, s.default)(this, e);
          for (var r = arguments.length, n = Array(r), o = 0; o < r; o++) n[o] = arguments[o];
          return (
            (t = p(this, e, [].concat(n))),
            (0, u.default)(t, "name", "MissingAdapterError"),
            (0, u.default)(t, "code", "EMAIL_REQUIRES_ADAPTER_ERROR"),
            t
          );
        }
        return ((0, f.default)(e, t), (0, i.default)(e));
      })(h)),
      (r.MissingAdapterMethods = (function (t) {
        function e() {
          var t;
          (0, s.default)(this, e);
          for (var r = arguments.length, n = Array(r), o = 0; o < r; o++) n[o] = arguments[o];
          return (
            (t = p(this, e, [].concat(n))),
            (0, u.default)(t, "name", "MissingAdapterMethodsError"),
            (0, u.default)(t, "code", "MISSING_ADAPTER_METHODS_ERROR"),
            t
          );
        }
        return ((0, f.default)(e, t), (0, i.default)(e));
      })(h)),
      (r.UnsupportedStrategy = (function (t) {
        function e() {
          var t;
          (0, s.default)(this, e);
          for (var r = arguments.length, n = Array(r), o = 0; o < r; o++) n[o] = arguments[o];
          return (
            (t = p(this, e, [].concat(n))),
            (0, u.default)(t, "name", "UnsupportedStrategyError"),
            (0, u.default)(t, "code", "CALLBACK_CREDENTIALS_JWT_ERROR"),
            t
          );
        }
        return ((0, f.default)(e, t), (0, i.default)(e));
      })(h)),
      (r.InvalidCallbackUrl = (function (t) {
        function e() {
          var t;
          (0, s.default)(this, e);
          for (var r = arguments.length, n = Array(r), o = 0; o < r; o++) n[o] = arguments[o];
          return (
            (t = p(this, e, [].concat(n))),
            (0, u.default)(t, "name", "InvalidCallbackUrl"),
            (0, u.default)(t, "code", "INVALID_CALLBACK_URL_ERROR"),
            t
          );
        }
        return ((0, f.default)(e, t), (0, i.default)(e));
      })(h)));
  },
  36357,
  (t, e, r) => {
    "use strict";
    var n = t.r(13451);
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      (r.default = void 0),
      (r.proxyLogger = function () {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : l,
          e = arguments.length > 1 ? arguments[1] : void 0;
        try {
          if ("u" < typeof window) return t;
          var r = {},
            n = function (t) {
              var n;
              r[t] =
                ((n = (0, u.default)(
                  o.default.mark(function r(n, u) {
                    var s, f;
                    return o.default.wrap(function (r) {
                      for (;;)
                        switch ((r.prev = r.next)) {
                          case 0:
                            if (
                              (l[t](n, u),
                              "error" === t && (u = c(u)),
                              (u.client = !0),
                              (s = "".concat(e, "/_log")),
                              (f = new URLSearchParams(
                                (function (t) {
                                  for (var e = 1; e < arguments.length; e++) {
                                    var r = null != arguments[e] ? arguments[e] : {};
                                    e % 2
                                      ? i(Object(r), !0).forEach(function (e) {
                                          (0, a.default)(t, e, r[e]);
                                        })
                                      : Object.getOwnPropertyDescriptors
                                        ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
                                        : i(Object(r)).forEach(function (e) {
                                            Object.defineProperty(
                                              t,
                                              e,
                                              Object.getOwnPropertyDescriptor(r, e),
                                            );
                                          });
                                  }
                                  return t;
                                })({ level: t, code: n }, u),
                              )),
                              !navigator.sendBeacon)
                            ) {
                              r.next = 8;
                              break;
                            }
                            return r.abrupt("return", navigator.sendBeacon(s, f));
                          case 8:
                            return ((r.next = 10), fetch(s, { method: "POST", body: f, keepalive: !0 }));
                          case 10:
                            return r.abrupt("return", r.sent);
                          case 11:
                          case "end":
                            return r.stop();
                        }
                    }, r);
                  }),
                )),
                function (t, e) {
                  return n.apply(this, arguments);
                });
            };
          for (var s in t) n(s);
          return r;
        } catch (t) {
          return l;
        }
      }),
      (r.setLogger = function () {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          e = arguments.length > 1 ? arguments[1] : void 0;
        (e || (l.debug = function () {}),
          t.error && (l.error = t.error),
          t.warn && (l.warn = t.warn),
          t.debug && (l.debug = t.debug));
      }));
    var o = n(t.r(231277)),
      a = n(t.r(514414)),
      u = n(t.r(145940)),
      s = t.r(641731);
    function i(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(t);
        (e &&
          (n = n.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, n));
      }
      return r;
    }
    function c(t) {
      var e, r;
      if (t instanceof Error && !(t instanceof s.UnknownError))
        return { message: t.message, stack: t.stack, name: t.name };
      if (null != (e = t) && e.error) {
        ((t.error = c(t.error)), (t.message = null != (r = t.message) ? r : t.error.message));
      }
      return t;
    }
    var l = {
      error: function (t, e) {
        ((e = c(e)),
          console.error(
            "[next-auth][error][".concat(t, "]"),
            "\nhttps://next-auth.js.org/errors#".concat(t.toLowerCase()),
            e.message,
            e,
          ));
      },
      warn: function (t) {
        console.warn(
          "[next-auth][warn][".concat(t, "]"),
          "\nhttps://next-auth.js.org/warnings#".concat(t.toLowerCase()),
        );
      },
      debug: function (t, e) {
        console.log("[next-auth][debug][".concat(t, "]"), e);
      },
    };
    r.default = l;
  },
  498520,
  (t, e, r) => {
    "use strict";
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      (r.default = function (t) {
        var e;
        let r = new URL("http://localhost:3000/api/auth");
        t && !t.startsWith("http") && (t = `https://${t}`);
        let n = new URL(null != (e = t) ? e : r),
          o = ("/" === n.pathname ? r.pathname : n.pathname).replace(/\/$/, ""),
          a = `${n.origin}${o}`;
        return { origin: n.origin, host: n.host, path: o, base: a, toString: () => a };
      }));
  },
  790120,
  (t, e, r) => {
    "use strict";
    var n = t.r(13451);
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      (r.BroadcastChannel = function () {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "nextauth.message";
        return {
          receive: function (e) {
            var r = function (r) {
              if (r.key === t) {
                var n,
                  o = JSON.parse(null != (n = r.newValue) ? n : "{}");
                (null == o ? void 0 : o.event) === "session" && null != o && o.data && e(o);
              }
            };
            return (
              window.addEventListener("storage", r),
              function () {
                return window.removeEventListener("storage", r);
              }
            );
          },
          post: function (e) {
            if ("u" > typeof window)
              try {
                localStorage.setItem(t, JSON.stringify(i(i({}, e), {}, { timestamp: f() })));
              } catch (t) {}
          },
        };
      }),
      (r.apiBaseUrl = l),
      (r.fetchData = function (t, e, r) {
        return c.apply(this, arguments);
      }),
      (r.now = f));
    var o = n(t.r(231277)),
      a = n(t.r(514414)),
      u = n(t.r(145940));
    function s(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(t);
        (e &&
          (n = n.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, n));
      }
      return r;
    }
    function i(t) {
      for (var e = 1; e < arguments.length; e++) {
        var r = null != arguments[e] ? arguments[e] : {};
        e % 2
          ? s(Object(r), !0).forEach(function (e) {
              (0, a.default)(t, e, r[e]);
            })
          : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
            : s(Object(r)).forEach(function (e) {
                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(r, e));
              });
      }
      return t;
    }
    function c() {
      return (c = (0, u.default)(
        o.default.mark(function t(e, r, n) {
          var a,
            u,
            s,
            c,
            f,
            p,
            d,
            h,
            v,
            y = arguments;
          return o.default.wrap(
            function (t) {
              for (;;)
                switch ((t.prev = t.next)) {
                  case 0:
                    return (
                      (u = (a = y.length > 3 && void 0 !== y[3] ? y[3] : {}).ctx),
                      (c = void 0 === (s = a.req) ? (null == u ? void 0 : u.req) : s),
                      (f = "".concat(l(r), "/").concat(e)),
                      (t.prev = 2),
                      (d = {
                        headers: i(
                          { "Content-Type": "application/json" },
                          null != c && null != (p = c.headers) && p.cookie
                            ? { cookie: c.headers.cookie }
                            : {},
                        ),
                      }),
                      null != c && c.body && ((d.body = JSON.stringify(c.body)), (d.method = "POST")),
                      (t.next = 7),
                      fetch(f, d)
                    );
                  case 7:
                    return ((h = t.sent), (t.next = 10), h.json());
                  case 10:
                    if (((v = t.sent), h.ok)) {
                      t.next = 13;
                      break;
                    }
                    throw v;
                  case 13:
                    return t.abrupt("return", Object.keys(v).length > 0 ? v : null);
                  case 16:
                    return (
                      (t.prev = 16),
                      (t.t0 = t.catch(2)),
                      n.error("CLIENT_FETCH_ERROR", { error: t.t0, url: f }),
                      t.abrupt("return", null)
                    );
                  case 20:
                  case "end":
                    return t.stop();
                }
            },
            t,
            null,
            [[2, 16]],
          );
        }),
      )).apply(this, arguments);
    }
    function l(t) {
      return "u" < typeof window ? "".concat(t.baseUrlServer).concat(t.basePathServer) : t.basePath;
    }
    function f() {
      return Math.floor(Date.now() / 1e3);
    }
  },
  13451,
  (t, e, r) => {
    ((e.exports = function (t) {
      return t && t.__esModule ? t : { default: t };
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  935045,
  (t, e, r) => {
    function n(t) {
      return (
        (e.exports = n =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                return typeof t;
              }
            : function (t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype
                  ? "symbol"
                  : typeof t;
              }),
        (e.exports.__esModule = !0),
        (e.exports.default = e.exports),
        n(t)
      );
    }
    ((e.exports = n), (e.exports.__esModule = !0), (e.exports.default = e.exports));
  },
  398113,
  (t, e, r) => {
    ((e.exports = function (t, e) {
      ((this.v = t), (this.k = e));
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  178679,
  (t, e, r) => {
    function n(t, r, o, a) {
      var u = Object.defineProperty;
      try {
        u({}, "", {});
      } catch (t) {
        u = 0;
      }
      ((e.exports = n =
        function (t, e, r, o) {
          function a(e, r) {
            n(t, e, function (t) {
              return this._invoke(e, r, t);
            });
          }
          e
            ? u
              ? u(t, e, { value: r, enumerable: !o, configurable: !o, writable: !o })
              : (t[e] = r)
            : (a("next", 0), a("throw", 1), a("return", 2));
        }),
        (e.exports.__esModule = !0),
        (e.exports.default = e.exports),
        n(t, r, o, a));
    }
    ((e.exports = n), (e.exports.__esModule = !0), (e.exports.default = e.exports));
  },
  755157,
  (t, e, r) => {
    var n = t.r(178679);
    function o() {
      var t,
        r,
        a = "function" == typeof Symbol ? Symbol : {},
        u = a.iterator || "@@iterator",
        s = a.toStringTag || "@@toStringTag";
      function i(e, o, a, u) {
        var s = Object.create((o && o.prototype instanceof l ? o : l).prototype);
        return (
          n(
            s,
            "_invoke",
            (function (e, n, o) {
              var a,
                u,
                s,
                i = 0,
                l = o || [],
                f = !1,
                p = {
                  p: 0,
                  n: 0,
                  v: t,
                  a: d,
                  f: d.bind(t, 4),
                  d: function (e, r) {
                    return ((a = e), (u = 0), (s = t), (p.n = r), c);
                  },
                };
              function d(e, n) {
                for (u = e, s = n, r = 0; !f && i && !o && r < l.length; r++) {
                  var o,
                    a = l[r],
                    d = p.p,
                    h = a[2];
                  e > 3
                    ? (o = h === n) && ((s = a[(u = a[4]) ? 5 : ((u = 3), 3)]), (a[4] = a[5] = t))
                    : a[0] <= d &&
                      ((o = e < 2 && d < a[1])
                        ? ((u = 0), (p.v = n), (p.n = a[1]))
                        : d < h &&
                          (o = e < 3 || a[0] > n || n > h) &&
                          ((a[4] = e), (a[5] = n), (p.n = h), (u = 0)));
                }
                if (o || e > 1) return c;
                throw ((f = !0), n);
              }
              return function (o, l, h) {
                if (i > 1) throw TypeError("Generator is already running");
                for (f && 1 === l && d(l, h), u = l, s = h; (r = u < 2 ? t : s) || !f;) {
                  a || (u ? (u < 3 ? (u > 1 && (p.n = -1), d(u, s)) : (p.n = s)) : (p.v = s));
                  try {
                    if (((i = 2), a)) {
                      if ((u || (o = "next"), (r = a[o]))) {
                        if (!(r = r.call(a, s))) throw TypeError("iterator result is not an object");
                        if (!r.done) return r;
                        ((s = r.value), u < 2 && (u = 0));
                      } else
                        (1 === u && (r = a.return) && r.call(a),
                          u < 2 &&
                            ((s = TypeError("The iterator does not provide a '" + o + "' method")), (u = 1)));
                      a = t;
                    } else if ((r = (f = p.n < 0) ? s : e.call(n, p)) !== c) break;
                  } catch (e) {
                    ((a = t), (u = 1), (s = e));
                  } finally {
                    i = 1;
                  }
                }
                return { value: r, done: f };
              };
            })(e, a, u),
            !0,
          ),
          s
        );
      }
      var c = {};
      function l() {}
      function f() {}
      function p() {}
      r = Object.getPrototypeOf;
      var d =
        (p.prototype =
        l.prototype =
          Object.create(
            [][u]
              ? r(r([][u]()))
              : (n((r = {}), u, function () {
                  return this;
                }),
                r),
          ));
      function h(t) {
        return (
          Object.setPrototypeOf
            ? Object.setPrototypeOf(t, p)
            : ((t.__proto__ = p), n(t, s, "GeneratorFunction")),
          (t.prototype = Object.create(d)),
          t
        );
      }
      return (
        (f.prototype = p),
        n(d, "constructor", p),
        n(p, "constructor", f),
        (f.displayName = "GeneratorFunction"),
        n(p, s, "GeneratorFunction"),
        n(d),
        n(d, s, "Generator"),
        n(d, u, function () {
          return this;
        }),
        n(d, "toString", function () {
          return "[object Generator]";
        }),
        ((e.exports = o =
          function () {
            return { w: i, m: h };
          }),
        (e.exports.__esModule = !0),
        (e.exports.default = e.exports))()
      );
    }
    ((e.exports = o), (e.exports.__esModule = !0), (e.exports.default = e.exports));
  },
  336852,
  (t, e, r) => {
    var n = t.r(398113),
      o = t.r(178679);
    ((e.exports = function t(e, r) {
      var a;
      (this.next ||
        (o(t.prototype),
        o(
          t.prototype,
          ("function" == typeof Symbol && Symbol.asyncIterator) || "@asyncIterator",
          function () {
            return this;
          },
        )),
        o(
          this,
          "_invoke",
          function (t, o, u) {
            function s() {
              return new r(function (o, a) {
                !(function t(o, a, u, s) {
                  try {
                    var i = e[o](a),
                      c = i.value;
                    return c instanceof n
                      ? r.resolve(c.v).then(
                          function (e) {
                            t("next", e, u, s);
                          },
                          function (e) {
                            t("throw", e, u, s);
                          },
                        )
                      : r.resolve(c).then(
                          function (t) {
                            ((i.value = t), u(i));
                          },
                          function (e) {
                            return t("throw", e, u, s);
                          },
                        );
                  } catch (t) {
                    s(t);
                  }
                })(t, u, o, a);
              });
            }
            return (a = a ? a.then(s, s) : s());
          },
          !0,
        ));
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  506822,
  (t, e, r) => {
    var n = t.r(755157),
      o = t.r(336852);
    ((e.exports = function (t, e, r, a, u) {
      return new o(n().w(t, e, r, a), u || Promise);
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  288691,
  (t, e, r) => {
    var n = t.r(506822);
    ((e.exports = function (t, e, r, o, a) {
      var u = n(t, e, r, o, a);
      return u.next().then(function (t) {
        return t.done ? t.value : u.next();
      });
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  354534,
  (t, e, r) => {
    ((e.exports = function (t) {
      var e = Object(t),
        r = [];
      for (var n in e) r.unshift(n);
      return function t() {
        for (; r.length;) if ((n = r.pop()) in e) return ((t.value = n), (t.done = !1), t);
        return ((t.done = !0), t);
      };
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  56299,
  (t, e, r) => {
    var n = t.r(935045).default;
    ((e.exports = function (t) {
      if (null != t) {
        var e = t[("function" == typeof Symbol && Symbol.iterator) || "@@iterator"],
          r = 0;
        if (e) return e.call(t);
        if ("function" == typeof t.next) return t;
        if (!isNaN(t.length))
          return {
            next: function () {
              return (t && r >= t.length && (t = void 0), { value: t && t[r++], done: !t });
            },
          };
      }
      throw TypeError(n(t) + " is not iterable");
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  330659,
  (t, e, r) => {
    var n = t.r(398113),
      o = t.r(755157),
      a = t.r(288691),
      u = t.r(506822),
      s = t.r(336852),
      i = t.r(354534),
      c = t.r(56299);
    function l() {
      "use strict";
      var t = o(),
        r = t.m(l),
        f = (Object.getPrototypeOf ? Object.getPrototypeOf(r) : r.__proto__).constructor;
      function p(t) {
        var e = "function" == typeof t && t.constructor;
        return !!e && (e === f || "GeneratorFunction" === (e.displayName || e.name));
      }
      var d = { throw: 1, return: 2, break: 3, continue: 3 };
      function h(t) {
        var e, r;
        return function (n) {
          (e ||
            ((e = {
              stop: function () {
                return r(n.a, 2);
              },
              catch: function () {
                return n.v;
              },
              abrupt: function (t, e) {
                return r(n.a, d[t], e);
              },
              delegateYield: function (t, o, a) {
                return ((e.resultName = o), r(n.d, c(t), a));
              },
              finish: function (t) {
                return r(n.f, t);
              },
            }),
            (r = function (t, r, o) {
              ((n.p = e.prev), (n.n = e.next));
              try {
                return t(r, o);
              } finally {
                e.next = n.n;
              }
            })),
            e.resultName && ((e[e.resultName] = n.v), (e.resultName = void 0)),
            (e.sent = n.v),
            (e.next = n.n));
          try {
            return t.call(this, e);
          } finally {
            ((n.p = e.prev), (n.n = e.next));
          }
        };
      }
      return ((e.exports = l =
        function () {
          return {
            wrap: function (e, r, n, o) {
              return t.w(h(e), r, n, o && o.reverse());
            },
            isGeneratorFunction: p,
            mark: t.m,
            awrap: function (t, e) {
              return new n(t, e);
            },
            AsyncIterator: s,
            async: function (t, e, r, n, o) {
              return (p(e) ? u : a)(h(t), e, r, n, o);
            },
            keys: i,
            values: c,
          };
        }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports))();
    }
    ((e.exports = l), (e.exports.__esModule = !0), (e.exports.default = e.exports));
  },
  231277,
  (t, e, r) => {
    var n = t.r(330659)();
    e.exports = n;
    try {
      regeneratorRuntime = n;
    } catch (t) {
      "object" == typeof globalThis
        ? (globalThis.regeneratorRuntime = n)
        : Function("r", "regeneratorRuntime = r")(n);
    }
  },
  226252,
  (t, e, r) => {
    var n = t.r(935045).default;
    ((e.exports = function (t, e) {
      if ("object" != n(t) || !t) return t;
      var r = t[Symbol.toPrimitive];
      if (void 0 !== r) {
        var o = r.call(t, e || "default");
        if ("object" != n(o)) return o;
        throw TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === e ? String : Number)(t);
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  863974,
  (t, e, r) => {
    var n = t.r(935045).default,
      o = t.r(226252);
    ((e.exports = function (t) {
      var e = o(t, "string");
      return "symbol" == n(e) ? e : e + "";
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  514414,
  (t, e, r) => {
    var n = t.r(863974);
    ((e.exports = function (t, e, r) {
      return (
        (e = n(e)) in t
          ? Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 })
          : (t[e] = r),
        t
      );
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  145940,
  (t, e, r) => {
    function n(t, e, r, n, o, a, u) {
      try {
        var s = t[a](u),
          i = s.value;
      } catch (t) {
        return void r(t);
      }
      s.done ? e(i) : Promise.resolve(i).then(n, o);
    }
    ((e.exports = function (t) {
      return function () {
        var e = this,
          r = arguments;
        return new Promise(function (o, a) {
          var u = t.apply(e, r);
          function s(t) {
            n(u, o, a, s, i, "next", t);
          }
          function i(t) {
            n(u, o, a, s, i, "throw", t);
          }
          s(void 0);
        });
      };
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  31159,
  (t, e, r) => {
    ((e.exports = function (t) {
      if (Array.isArray(t)) return t;
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  773973,
  (t, e, r) => {
    ((e.exports = function (t, e) {
      var r = null == t ? null : ("u" > typeof Symbol && t[Symbol.iterator]) || t["@@iterator"];
      if (null != r) {
        var n,
          o,
          a,
          u,
          s = [],
          i = !0,
          c = !1;
        try {
          if (((a = (r = r.call(t)).next), 0 === e)) {
            if (Object(r) !== r) return;
            i = !1;
          } else for (; !(i = (n = a.call(r)).done) && (s.push(n.value), s.length !== e); i = !0);
        } catch (t) {
          ((c = !0), (o = t));
        } finally {
          try {
            if (!i && null != r.return && ((u = r.return()), Object(u) !== u)) return;
          } finally {
            if (c) throw o;
          }
        }
        return s;
      }
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  427500,
  (t, e, r) => {
    ((e.exports = function (t, e) {
      (null == e || e > t.length) && (e = t.length);
      for (var r = 0, n = Array(e); r < e; r++) n[r] = t[r];
      return n;
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  737906,
  (t, e, r) => {
    var n = t.r(427500);
    ((e.exports = function (t, e) {
      if (t) {
        if ("string" == typeof t) return n(t, e);
        var r = {}.toString.call(t).slice(8, -1);
        return (
          "Object" === r && t.constructor && (r = t.constructor.name),
          "Map" === r || "Set" === r
            ? Array.from(t)
            : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)
              ? n(t, e)
              : void 0
        );
      }
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  294441,
  (t, e, r) => {
    ((e.exports = function () {
      throw TypeError(
        "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
      );
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  462195,
  (t, e, r) => {
    var n = t.r(31159),
      o = t.r(773973),
      a = t.r(737906),
      u = t.r(294441);
    ((e.exports = function (t, e) {
      return n(t) || o(t, e) || a(t, e) || u();
    }),
      (e.exports.__esModule = !0),
      (e.exports.default = e.exports));
  },
  933818,
  (t) => {
    "use strict";
    t.s([
      "queryOptions",
      0,
      function (t) {
        return t;
      },
    ]);
  },
  954616,
  (t) => {
    "use strict";
    var e = t.i(271645),
      r = t.i(114272),
      n = t.i(540143),
      o = t.i(915823),
      a = t.i(619273),
      u = class extends o.Subscribable {
        #t;
        #e = void 0;
        #r;
        #n;
        constructor(t, e) {
          (super(), (this.#t = t), this.setOptions(e), this.bindMethods(), this.#o());
        }
        bindMethods() {
          ((this.mutate = this.mutate.bind(this)), (this.reset = this.reset.bind(this)));
        }
        setOptions(t) {
          let e = this.options;
          ((this.options = this.#t.defaultMutationOptions(t)),
            (0, a.shallowEqualObjects)(this.options, e) ||
              this.#t
                .getMutationCache()
                .notify({ type: "observerOptionsUpdated", mutation: this.#r, observer: this }),
            e?.mutationKey &&
            this.options.mutationKey &&
            (0, a.hashKey)(e.mutationKey) !== (0, a.hashKey)(this.options.mutationKey)
              ? this.reset()
              : this.#r?.state.status === "pending" && this.#r.setOptions(this.options));
        }
        onUnsubscribe() {
          this.hasListeners() || this.#r?.removeObserver(this);
        }
        onMutationUpdate(t) {
          (this.#o(), this.#a(t));
        }
        getCurrentResult() {
          return this.#e;
        }
        reset() {
          (this.#r?.removeObserver(this), (this.#r = void 0), this.#o(), this.#a());
        }
        mutate(t, e) {
          return (
            (this.#n = e),
            this.#r?.removeObserver(this),
            (this.#r = this.#t.getMutationCache().build(this.#t, this.options)),
            this.#r.addObserver(this),
            this.#r.execute(t)
          );
        }
        #o() {
          let t = this.#r?.state ?? (0, r.getDefaultState)();
          this.#e = {
            ...t,
            isPending: "pending" === t.status,
            isSuccess: "success" === t.status,
            isError: "error" === t.status,
            isIdle: "idle" === t.status,
            mutate: this.mutate,
            reset: this.reset,
          };
        }
        #a(t) {
          n.notifyManager.batch(() => {
            if (this.#n && this.hasListeners()) {
              let e = this.#e.variables,
                r = this.#e.context,
                n = { client: this.#t, meta: this.options.meta, mutationKey: this.options.mutationKey };
              t?.type === "success"
                ? (this.#n.onSuccess?.(t.data, e, r, n), this.#n.onSettled?.(t.data, null, e, r, n))
                : t?.type === "error" &&
                  (this.#n.onError?.(t.error, e, r, n), this.#n.onSettled?.(void 0, t.error, e, r, n));
            }
            this.listeners.forEach((t) => {
              t(this.#e);
            });
          });
        }
      },
      s = t.i(912598);
    t.s(
      [
        "useMutation",
        0,
        function (t, r) {
          let o = (0, s.useQueryClient)(r),
            [i] = e.useState(() => new u(o, t));
          e.useEffect(() => {
            i.setOptions(t);
          }, [i, t]);
          let c = e.useSyncExternalStore(
              e.useCallback((t) => i.subscribe(n.notifyManager.batchCalls(t)), [i]),
              () => i.getCurrentResult(),
              () => i.getCurrentResult(),
            ),
            l = e.useCallback(
              (t, e) => {
                i.mutate(t, e).catch(a.noop);
              },
              [i],
            );
          if (c.error && (0, a.shouldThrowError)(i.options.throwOnError, [c.error])) throw c.error;
          return { ...c, mutate: l, mutateAsync: c.mutate };
        },
      ],
      954616,
    );
  },
  627667,
  (t, e, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
  },
  217255,
  (t, e, r) => {
    "use strict";
    var n,
      o,
      a,
      u,
      s,
      i = t.i(247167),
      c = t.r(13451),
      l = t.r(935045);
    Object.defineProperty(r, "__esModule", { value: !0 });
    var f = {
      SessionContext: !0,
      useSession: !0,
      getSession: !0,
      getCsrfToken: !0,
      getProviders: !0,
      signIn: !0,
      signOut: !0,
      SessionProvider: !0,
    };
    ((r.SessionContext = void 0),
      (r.SessionProvider = function (t) {
        if (!P) throw Error("React Context is unavailable in Server Components");
        var e,
          r,
          n,
          o,
          a,
          u,
          s = t.children,
          i = t.basePath,
          c = t.refetchInterval,
          l = t.refetchWhenOffline;
        i && (M.basePath = i);
        var f = void 0 !== t.session;
        M._lastSync = f ? (0, g.now)() : 0;
        var d = y.useState(function () {
            return (f && (M._session = t.session), t.session);
          }),
          b = (0, v.default)(d, 2),
          x = b[0],
          w = b[1],
          m = y.useState(!f),
          O = (0, v.default)(m, 2),
          S = O[0],
          E = O[1];
        (y.useEffect(function () {
          return (
            (M._getSession = (0, h.default)(
              p.default.mark(function t() {
                var e,
                  r,
                  n = arguments;
                return p.default.wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (
                            ((e = (n.length > 0 && void 0 !== n[0] ? n[0] : {}).event),
                            (t.prev = 1),
                            !((r = "storage" === e) || void 0 === M._session))
                          ) {
                            t.next = 10;
                            break;
                          }
                          return ((M._lastSync = (0, g.now)()), (t.next = 7), k({ broadcast: !r }));
                        case 7:
                          return ((M._session = t.sent), w(M._session), t.abrupt("return"));
                        case 10:
                          if (!(!e || null === M._session || (0, g.now)() < M._lastSync)) {
                            t.next = 12;
                            break;
                          }
                          return t.abrupt("return");
                        case 12:
                          return ((M._lastSync = (0, g.now)()), (t.next = 15), k());
                        case 15:
                          ((M._session = t.sent), w(M._session), (t.next = 22));
                          break;
                        case 19:
                          ((t.prev = 19), (t.t0 = t.catch(1)), j.error("CLIENT_SESSION_ERROR", t.t0));
                        case 22:
                          return ((t.prev = 22), E(!1), t.finish(22));
                        case 25:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  null,
                  [[1, 19, 22, 25]],
                );
              }),
            )),
            M._getSession(),
            function () {
              ((M._lastSync = 0), (M._session = void 0), (M._getSession = function () {}));
            }
          );
        }, []),
          y.useEffect(function () {
            var t = R.receive(function () {
              return M._getSession({ event: "storage" });
            });
            return function () {
              return t();
            };
          }, []),
          y.useEffect(
            function () {
              var e = t.refetchOnWindowFocus,
                r = void 0 === e || e,
                n = function () {
                  r && "visible" === document.visibilityState && M._getSession({ event: "visibilitychange" });
                };
              return (
                document.addEventListener("visibilitychange", n, !1),
                function () {
                  return document.removeEventListener("visibilitychange", n, !1);
                }
              );
            },
            [t.refetchOnWindowFocus],
          ));
        var U =
            ((e = y.useState("u" > typeof navigator && navigator.onLine)),
            (n = (r = (0, v.default)(e, 2))[0]),
            (o = r[1]),
            (a = function () {
              return o(!0);
            }),
            (u = function () {
              return o(!1);
            }),
            y.useEffect(function () {
              return (
                window.addEventListener("online", a),
                window.addEventListener("offline", u),
                function () {
                  (window.removeEventListener("online", a), window.removeEventListener("offline", u));
                }
              );
            }, []),
            n),
          T = !1 !== l || U;
        y.useEffect(
          function () {
            if (c && T) {
              var t = setInterval(function () {
                M._session && M._getSession({ event: "poll" });
              }, 1e3 * c);
              return function () {
                return clearInterval(t);
              };
            }
          },
          [c, T],
        );
        var C = y.useMemo(
          function () {
            return {
              data: x,
              status: S ? "loading" : x ? "authenticated" : "unauthenticated",
              update: function (t) {
                return (0, h.default)(
                  p.default.mark(function e() {
                    var r;
                    return p.default.wrap(function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            if (!(S || !x)) {
                              e.next = 2;
                              break;
                            }
                            return e.abrupt("return");
                          case 2:
                            return (E(!0), (e.t0 = g.fetchData), (e.t1 = M), (e.t2 = j), (e.next = 8), A());
                          case 8:
                            return (
                              (e.t3 = e.sent),
                              (e.t4 = t),
                              (e.t5 = { csrfToken: e.t3, data: e.t4 }),
                              (e.t6 = { body: e.t5 }),
                              (e.t7 = { req: e.t6 }),
                              (e.next = 15),
                              (0, e.t0)("session", e.t1, e.t2, e.t7)
                            );
                          case 15:
                            return (
                              (r = e.sent),
                              E(!1),
                              r && (w(r), R.post({ event: "session", data: { trigger: "getSession" } })),
                              e.abrupt("return", r)
                            );
                          case 19:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                  }),
                )();
              },
            };
          },
          [x, S],
        );
        return (0, _.jsx)(P.Provider, { value: C, children: s });
      }),
      (r.getCsrfToken = A),
      (r.getProviders = C),
      (r.getSession = k),
      (r.signIn = function (t, e, r) {
        return I.apply(this, arguments);
      }),
      (r.signOut = function (t) {
        return N.apply(this, arguments);
      }),
      (r.useSession = function (t) {
        if (!P) throw Error("React Context is unavailable in Server Components");
        var e = y.useContext(P),
          r = null != t ? t : {},
          n = r.required,
          o = r.onUnauthenticated,
          a = n && "unauthenticated" === e.status;
        return (y.useEffect(
          function () {
            if (a) {
              var t = "/api/auth/signin?".concat(
                new URLSearchParams({ error: "SessionRequired", callbackUrl: window.location.href }),
              );
              o ? o() : (window.location.href = t);
            }
          },
          [a, o],
        ),
        a)
          ? { data: e.data, update: e.update, status: "loading" }
          : e;
      }));
    var p = c(t.r(231277)),
      d = c(t.r(514414)),
      h = c(t.r(145940)),
      v = c(t.r(462195)),
      y = O(t.r(271645)),
      b = O(t.r(36357)),
      x = c(t.r(498520)),
      g = t.r(790120),
      _ = t.r(843476),
      w = t.r(627667);
    function m(t) {
      if ("function" != typeof WeakMap) return null;
      var e = new WeakMap(),
        r = new WeakMap();
      return (m = function (t) {
        return t ? r : e;
      })(t);
    }
    function O(t, e) {
      if (!e && t && t.__esModule) return t;
      if (null === t || ("object" != l(t) && "function" != typeof t)) return { default: t };
      var r = m(e);
      if (r && r.has(t)) return r.get(t);
      var n = { __proto__: null },
        o = Object.defineProperty && Object.getOwnPropertyDescriptor;
      for (var a in t)
        if ("default" !== a && {}.hasOwnProperty.call(t, a)) {
          var u = o ? Object.getOwnPropertyDescriptor(t, a) : null;
          u && (u.get || u.set) ? Object.defineProperty(n, a, u) : (n[a] = t[a]);
        }
      return ((n.default = t), r && r.set(t, n), n);
    }
    function S(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(t);
        (e &&
          (n = n.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, n));
      }
      return r;
    }
    function E(t) {
      for (var e = 1; e < arguments.length; e++) {
        var r = null != arguments[e] ? arguments[e] : {};
        e % 2
          ? S(Object(r), !0).forEach(function (e) {
              (0, d.default)(t, e, r[e]);
            })
          : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
            : S(Object(r)).forEach(function (e) {
                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(r, e));
              });
      }
      return t;
    }
    Object.keys(w).forEach(function (t) {
      "default" === t ||
        "__esModule" === t ||
        Object.prototype.hasOwnProperty.call(f, t) ||
        (t in r && r[t] === w[t]) ||
        Object.defineProperty(r, t, {
          enumerable: !0,
          get: function () {
            return w[t];
          },
        });
    });
    var M = {
        baseUrl: (0, x.default)(null != (n = i.default.env.NEXTAUTH_URL) ? n : i.default.env.VERCEL_URL)
          .origin,
        basePath: (0, x.default)(i.default.env.NEXTAUTH_URL).path,
        baseUrlServer: (0, x.default)(
          null != (o = null != (a = i.default.env.NEXTAUTH_URL_INTERNAL) ? a : i.default.env.NEXTAUTH_URL)
            ? o
            : i.default.env.VERCEL_URL,
        ).origin,
        basePathServer: (0, x.default)(
          null != (u = i.default.env.NEXTAUTH_URL_INTERNAL) ? u : i.default.env.NEXTAUTH_URL,
        ).path,
        _lastSync: 0,
        _session: void 0,
        _getSession: function () {},
      },
      R = (0, g.BroadcastChannel)(),
      j = (0, b.proxyLogger)(b.default, M.basePath),
      P = (r.SessionContext = null == (s = y.createContext) ? void 0 : s.call(y, void 0));
    function k(t) {
      return U.apply(this, arguments);
    }
    function U() {
      return (U = (0, h.default)(
        p.default.mark(function t(e) {
          var r, n;
          return p.default.wrap(function (t) {
            for (;;)
              switch ((t.prev = t.next)) {
                case 0:
                  return ((t.next = 2), (0, g.fetchData)("session", M, j, e));
                case 2:
                  return (
                    (n = t.sent),
                    (null == (r = null == e ? void 0 : e.broadcast) || r) &&
                      R.post({ event: "session", data: { trigger: "getSession" } }),
                    t.abrupt("return", n)
                  );
                case 5:
                case "end":
                  return t.stop();
              }
          }, t);
        }),
      )).apply(this, arguments);
    }
    function A(t) {
      return T.apply(this, arguments);
    }
    function T() {
      return (T = (0, h.default)(
        p.default.mark(function t(e) {
          var r;
          return p.default.wrap(function (t) {
            for (;;)
              switch ((t.prev = t.next)) {
                case 0:
                  return ((t.next = 2), (0, g.fetchData)("csrf", M, j, e));
                case 2:
                  return ((r = t.sent), t.abrupt("return", null == r ? void 0 : r.csrfToken));
                case 4:
                case "end":
                  return t.stop();
              }
          }, t);
        }),
      )).apply(this, arguments);
    }
    function C() {
      return L.apply(this, arguments);
    }
    function L() {
      return (L = (0, h.default)(
        p.default.mark(function t() {
          return p.default.wrap(function (t) {
            for (;;)
              switch ((t.prev = t.next)) {
                case 0:
                  return ((t.next = 2), (0, g.fetchData)("providers", M, j));
                case 2:
                  return t.abrupt("return", t.sent);
                case 3:
                case "end":
                  return t.stop();
              }
          }, t);
        }),
      )).apply(this, arguments);
    }
    function I() {
      return (I = (0, h.default)(
        p.default.mark(function t(e, r, n) {
          var o, a, u, s, i, c, l, f, d, h, v, y, b, x, _, w, m;
          return p.default.wrap(function (t) {
            for (;;)
              switch ((t.prev = t.next)) {
                case 0:
                  return (
                    (u = void 0 === (a = (o = null != r ? r : {}).callbackUrl) ? window.location.href : a),
                    (i = void 0 === (s = o.redirect) || s),
                    (c = (0, g.apiBaseUrl)(M)),
                    (t.next = 4),
                    C()
                  );
                case 4:
                  if ((l = t.sent)) {
                    t.next = 8;
                    break;
                  }
                  return ((window.location.href = "".concat(c, "/error")), t.abrupt("return"));
                case 8:
                  if (!(!e || !(e in l))) {
                    t.next = 11;
                    break;
                  }
                  return (
                    (window.location.href = ""
                      .concat(c, "/signin?")
                      .concat(new URLSearchParams({ callbackUrl: u }))),
                    t.abrupt("return")
                  );
                case 11:
                  return (
                    (f = "credentials" === l[e].type),
                    (d = "email" === l[e].type),
                    (h = f || d),
                    (v = ""
                      .concat(c, "/")
                      .concat(f ? "callback" : "signin", "/")
                      .concat(e)),
                    (y = "".concat(v).concat(n ? "?".concat(new URLSearchParams(n)) : "")),
                    (t.t0 = fetch),
                    (t.t1 = y),
                    (t.t2 = { "Content-Type": "application/x-www-form-urlencoded" }),
                    (t.t3 = URLSearchParams),
                    (t.t4 = E),
                    (t.t5 = E({}, r)),
                    (t.t6 = {}),
                    (t.next = 25),
                    A()
                  );
                case 25:
                  return (
                    (t.t7 = t.sent),
                    (t.t8 = u),
                    (t.t9 = { csrfToken: t.t7, callbackUrl: t.t8, json: !0 }),
                    (t.t10 = (0, t.t4)(t.t5, t.t6, t.t9)),
                    (t.t11 = new t.t3(t.t10)),
                    (t.t12 = { method: "post", headers: t.t2, body: t.t11 }),
                    (t.next = 33),
                    (0, t.t0)(t.t1, t.t12)
                  );
                case 33:
                  return ((b = t.sent), (t.next = 36), b.json());
                case 36:
                  if (((x = t.sent), !(i || !h))) {
                    t.next = 42;
                    break;
                  }
                  return (
                    (w = null != (_ = x.url) ? _ : u),
                    (window.location.href = w),
                    w.includes("#") && window.location.reload(),
                    t.abrupt("return")
                  );
                case 42:
                  if (((m = new URL(x.url).searchParams.get("error")), !b.ok)) {
                    t.next = 46;
                    break;
                  }
                  return ((t.next = 46), M._getSession({ event: "storage" }));
                case 46:
                  return t.abrupt("return", { error: m, status: b.status, ok: b.ok, url: m ? null : x.url });
                case 47:
                case "end":
                  return t.stop();
              }
          }, t);
        }),
      )).apply(this, arguments);
    }
    function N() {
      return (N = (0, h.default)(
        p.default.mark(function t(e) {
          var r, n, o, a, u, s, i, c, l;
          return p.default.wrap(function (t) {
            for (;;)
              switch ((t.prev = t.next)) {
                case 0:
                  return (
                    (o = void 0 === (n = (null != e ? e : {}).callbackUrl) ? window.location.href : n),
                    (a = (0, g.apiBaseUrl)(M)),
                    (t.t0 = { "Content-Type": "application/x-www-form-urlencoded" }),
                    (t.t1 = URLSearchParams),
                    (t.next = 6),
                    A()
                  );
                case 6:
                  return (
                    (t.t2 = t.sent),
                    (t.t3 = o),
                    (t.t4 = { csrfToken: t.t2, callbackUrl: t.t3, json: !0 }),
                    (t.t5 = new t.t1(t.t4)),
                    (u = { method: "post", headers: t.t0, body: t.t5 }),
                    (t.next = 13),
                    fetch("".concat(a, "/signout"), u)
                  );
                case 13:
                  return ((s = t.sent), (t.next = 16), s.json());
                case 16:
                  if (
                    ((i = t.sent),
                    R.post({ event: "session", data: { trigger: "signout" } }),
                    !(null == (r = null == e ? void 0 : e.redirect) || r))
                  ) {
                    t.next = 23;
                    break;
                  }
                  return (
                    (l = null != (c = i.url) ? c : o),
                    (window.location.href = l),
                    l.includes("#") && window.location.reload(),
                    t.abrupt("return")
                  );
                case 23:
                  return ((t.next = 25), M._getSession({ event: "storage" }));
                case 25:
                  return t.abrupt("return", i);
                case 26:
                case "end":
                  return t.stop();
              }
          }, t);
        }),
      )).apply(this, arguments);
    }
  },
  431936,
  (t) => {
    "use strict";
    var e = t.i(134404);
    (t.i(756503), t.i(542516), t.i(531122));
    var r = t.i(81844);
    t.i(862347);
    let n = async (t, n) => {
        try {
          let o = new URLSearchParams();
          (n?.validationMode && o.append("validationMode", "true"),
            n?.fullData && o.append("fullData", "true"),
            o.append("email", t));
          let a = await r.apiInstance.get(`${e.EServerRoutes.AUTH_USER}?${o.toString()}`, {
              throwHttpErrors: !1,
              timeout: 5e3,
            }),
            u = await a.json();
          return a.ok ? u : { ...u, error: u?.message || "error_smth_went_wrong" };
        } catch {
          return { error: "error_smth_went_wrong" };
        }
      },
      o = async (t) => {
        try {
          let n = await r.apiInstance.patch(e.EServerRoutes.AUTH_USER, { json: t, throwHttpErrors: !1 });
          return await n.json();
        } catch {
          return { error: "error_smth_went_wrong", success: !1, data: null };
        }
      },
      a = async (t) => {
        let n = await r.apiInstance.post(e.EServerRoutes.CREATE_SESSION, { json: t, throwHttpErrors: !1 });
        return await n.json();
      };
    t.s(["createSessionFetcher", 0, a, "getUserByEmailFetcher", 0, n, "patchUserFetcher", 0, o]);
  },
  712470,
  (t) => {
    "use strict";
    var e = t.i(954616),
      r = t.i(912598),
      n = t.i(134404),
      o = t.i(86596);
    t.i(682770);
    var a = t.i(934952),
      u = t.i(431936);
    t.s([
      "useCreateSessionMutation",
      0,
      () => {
        let t = (0, e.useMutation)({
          mutationFn: u.createSessionFetcher,
          onSuccess(t) {
            t.success || (0, a.customToast)(t?.error || "", "error");
          },
        });
        return { ...t, trigger: (e) => t.mutateAsync(e) };
      },
      "usePatchUserMutation",
      0,
      () => {
        let t = (0, r.useQueryClient)(),
          a = (0, o.useUserStore)((t) => t.handleChangeUserStore),
          s = (0, e.useMutation)({
            mutationFn: u.patchUserFetcher,
            onSuccess(e, r) {
              e.success &&
                r.email &&
                e.data &&
                (t.setQueryData([n.EApiRoutes.AUTH_USER, r.email], { success: !0, data: e.data }),
                a({ user: { ...e.data.user_info } }));
            },
          });
        return { ...s, trigger: s.mutateAsync };
      },
    ]);
  },
  946684,
  (t) => {
    "use strict";
    var e = t.i(933818),
      r = t.i(266027),
      n = t.i(431936),
      o = t.i(134404);
    let a = (t) =>
      (0, e.queryOptions)({
        queryKey: [o.EApiRoutes.AUTH_USER, t],
        queryFn: async () =>
          t ? { success: !0, data: await (0, n.getUserByEmailFetcher)(t) } : { success: !1, data: null },
        staleTime: 6e5,
        gcTime: 9e5,
        enabled: !!t,
      });
    t.s(["useGetProfileQuery", 0, (t) => (0, r.useQuery)(a(t)), "userProfileQueryOptions", 0, a]);
  },
]);
