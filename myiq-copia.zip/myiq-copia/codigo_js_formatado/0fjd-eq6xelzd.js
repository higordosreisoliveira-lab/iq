(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  888073,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(948148);
    (e.s([], 241249),
      e.i(241249),
      e.s(
        [
          "ReviewsTitleComponent",
          0,
          () => {
            let e = (0, i.useTranslations)();
            return (0, t.jsx)("h2", {
              className:
                "text-[28px] font-semibold capitalize leading-none tracking-tight text-gray-900 md:text-[39px]",
              children: e("review_page_reviews"),
            });
          },
        ],
        888073,
      ));
  },
  366126,
  function (e) {
    e.n(e.i(888073));
  },
]);
