(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  885147,
  (e) => {
    "use strict";
    let t;
    var r = e.i(843476),
      l = e.i(271645);
    let n = { horizontalrule: (0, r.jsx)("hr", {}) },
      i = { linebreak: (0, r.jsx)("br", {}) },
      o = "u" > typeof crypto && crypto.randomUUID && crypto.randomUUID.bind(crypto),
      s = new Uint8Array(16),
      a = [];
    for (let e = 0; e < 256; ++e) a.push((e + 256).toString(16).slice(1));
    let c = function (e, r, l) {
        if (o && !r && !e) return o();
        var n = e,
          i = l;
        let c =
          (n = n || {}).random ??
          n.rng?.() ??
          (function () {
            if (!t) {
              if ("u" < typeof crypto || !crypto.getRandomValues)
                throw Error(
                  "crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported",
                );
              t = crypto.getRandomValues.bind(crypto);
            }
            return t(s);
          })();
        if (c.length < 16) throw Error("Random bytes length must be >= 16");
        if (((c[6] = (15 & c[6]) | 64), (c[8] = (63 & c[8]) | 128), r)) {
          if ((i = i || 0) < 0 || i + 16 > r.length)
            throw RangeError(`UUID byte range ${i}:${i + 15} is out of buffer bounds`);
          for (let e = 0; e < 16; ++e) r[i + e] = c[e];
          return r;
        }
        return (function (e) {
          let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
          return (
            a[e[t + 0]] +
            a[e[t + 1]] +
            a[e[t + 2]] +
            a[e[t + 3]] +
            "-" +
            a[e[t + 4]] +
            a[e[t + 5]] +
            "-" +
            a[e[t + 6]] +
            a[e[t + 7]] +
            "-" +
            a[e[t + 8]] +
            a[e[t + 9]] +
            "-" +
            a[e[t + 10]] +
            a[e[t + 11]] +
            a[e[t + 12]] +
            a[e[t + 13]] +
            a[e[t + 14]] +
            a[e[t + 15]]
          ).toLowerCase();
        })(c);
      },
      d = "֑-߿יִ-﷽ﹰ-ﻼ",
      u = "A-Za-zÀ-ÖØ-öø-ʸ̀-֐ࠀ-῿‎Ⰰ-﬜︀-﹯﻽-￿";
    (RegExp("^[^" + u + "]*[" + d + "]"), RegExp("^[^" + d + "]*[" + u + "]"));
    let h = {
      paragraph: (e) => {
        let { node: t, nodesToJSX: l } = e,
          n = l({ nodes: t.children });
        return n?.length
          ? (0, r.jsx)("p", { children: n })
          : (0, r.jsx)("p", { children: (0, r.jsx)("br", {}) });
      },
      text: (e) => {
        let { node: t } = e,
          l = t.text;
        return (
          1 & t.format && (l = (0, r.jsx)("strong", { children: l })),
          2 & t.format && (l = (0, r.jsx)("em", { children: l })),
          4 & t.format &&
            (l = (0, r.jsx)("span", { style: { textDecoration: "line-through" }, children: l })),
          8 & t.format && (l = (0, r.jsx)("span", { style: { textDecoration: "underline" }, children: l })),
          16 & t.format && (l = (0, r.jsx)("code", { children: l })),
          32 & t.format && (l = (0, r.jsx)("sub", { children: l })),
          64 & t.format && (l = (0, r.jsx)("sup", { children: l })),
          l
        );
      },
      ...i,
      quote: (e) => {
        let { node: t, nodesToJSX: l } = e,
          n = l({ nodes: t.children });
        return (0, r.jsx)("blockquote", { children: n });
      },
      table: (e) => {
        let { node: t, nodesToJSX: l } = e,
          n = l({ nodes: t.children });
        return (0, r.jsx)("div", {
          className: "lexical-table-container",
          children: (0, r.jsx)("table", {
            className: "lexical-table",
            style: { borderCollapse: "collapse" },
            children: (0, r.jsx)("tbody", { children: n }),
          }),
        });
      },
      tablecell: (e) => {
        let { node: t, nodesToJSX: l } = e,
          n = l({ nodes: t.children }),
          i = t.headerState > 0 ? "th" : "td",
          o = `lexical-table-cell-header-${t.headerState}`,
          s = { backgroundColor: t.backgroundColor || void 0, border: "1px solid #ccc", padding: "8px" },
          a = t.colSpan && t.colSpan > 1 ? t.colSpan : void 0,
          c = t.rowSpan && t.rowSpan > 1 ? t.rowSpan : void 0;
        return (0, r.jsx)(i, {
          className: `lexical-table-cell ${o}`,
          colSpan: a,
          rowSpan: c,
          style: s,
          children: n,
        });
      },
      tablerow: (e) => {
        let { node: t, nodesToJSX: l } = e,
          n = l({ nodes: t.children });
        return (0, r.jsx)("tr", { className: "lexical-table-row", children: n });
      },
      heading: (e) => {
        let { node: t, nodesToJSX: l } = e,
          n = l({ nodes: t.children }),
          i = t.tag;
        return (0, r.jsx)(i, { children: n });
      },
      ...n,
      list: (e) => {
        let { node: t, nodesToJSX: l } = e,
          n = l({ nodes: t.children }),
          i = t.tag;
        return (0, r.jsx)(i, { className: `list-${t?.listType}`, children: n });
      },
      listitem: (e) => {
        let { node: t, nodesToJSX: l, parent: n } = e,
          i = t.children.some((e) => "list" === e.type),
          o = l({ nodes: t.children });
        if (!("listType" in n) || n?.listType !== "check")
          return (0, r.jsx)("li", {
            className: `${i ? "nestedListItem" : ""}`,
            style: i ? { listStyleType: "none" } : void 0,
            value: t?.value,
            children: o,
          });
        {
          let e = c();
          return (0, r.jsx)("li", {
            "aria-checked": t.checked ? "true" : "false",
            className: `list-item-checkbox${t.checked ? " list-item-checkbox-checked" : " list-item-checkbox-unchecked"}${i ? " nestedListItem" : ""}`,
            role: "checkbox",
            style: { listStyleType: "none" },
            tabIndex: -1,
            value: t?.value,
            children: i
              ? o
              : (0, r.jsxs)(r.Fragment, {
                  children: [
                    (0, r.jsx)("input", { checked: t.checked, id: e, readOnly: !0, type: "checkbox" }),
                    (0, r.jsx)("label", { htmlFor: e, children: o }),
                    (0, r.jsx)("br", {}),
                  ],
                }),
          });
        }
      },
      ...((e) => {
        let { internalDocToHref: t } = e;
        return {
          autolink: (e) => {
            let { node: t, nodesToJSX: l } = e,
              n = l({ nodes: t.children }),
              i = t.fields.newTab ? "noopener noreferrer" : void 0,
              o = t.fields.newTab ? "_blank" : void 0;
            return (0, r.jsx)("a", { href: t.fields.url, rel: i, target: o, children: n });
          },
          link: (e) => {
            let { node: l, nodesToJSX: n } = e,
              i = n({ nodes: l.children }),
              o = l.fields.newTab ? "noopener noreferrer" : void 0,
              s = l.fields.newTab ? "_blank" : void 0,
              a = l.fields.url ?? "";
            return (
              "internal" === l.fields.linkType &&
                (t
                  ? (a = t({ linkNode: l }))
                  : (console.error(
                      "Lexical => JSX converter: Link converter: found internal link, but internalDocToHref is not provided",
                    ),
                    (a = "#"))),
              (0, r.jsx)("a", { href: a, rel: o, target: s, children: i })
            );
          },
        };
      })({}),
      upload: (e) => {
        let { node: t } = e;
        if ("object" != typeof t.value) return null;
        let l = t.value,
          n = t.fields?.alt || l?.alt || "",
          i = l.url;
        if (!l.mimeType.startsWith("image"))
          return (0, r.jsx)("a", { href: i, rel: "noopener noreferrer", children: l.filename });
        if (!l.sizes || !Object.keys(l.sizes).length)
          return (0, r.jsx)("img", { alt: n, height: l.height, src: i, width: l.width });
        let o = [];
        for (let e in l.sizes) {
          let t = l.sizes[e];
          if (!t || !t.width || !t.height || !t.mimeType || !t.filesize || !t.filename || !t.url) continue;
          let n = t?.url;
          o.push(
            (0, r.jsx)("source", { media: `(max-width: ${t.width}px)`, srcSet: n, type: t.mimeType }, e),
          );
        }
        return (
          o.push((0, r.jsx)("img", { alt: n, height: l?.height, src: i, width: l?.width }, "image")),
          (0, r.jsx)("picture", { children: o })
        );
      },
      tab: "	",
    };
    function p(e) {
      return (t) => {
        if (e.Component) {
          let r = { ...t, isEditor: !1, isJSXConverter: !0 };
          return e.Component(r);
        }
        if (e.Block) {
          let r = t.node,
            n = {
              childIndex: t.childIndex,
              converters: t.converters,
              formData: r.fields ?? {},
              isEditor: !1,
              isJSXConverter: !0,
              node: r,
              nodesToJSX: t.nodesToJSX,
              parent: t.parent,
            };
          return l.default.createElement(e.Block, n);
        }
        if (e.html) {
          let l = { ...t, isEditor: !1, isJSXConverter: !0 },
            n = "function" == typeof e.html ? e.html(l) : e.html;
          return (0, r.jsx)("span", { dangerouslySetInnerHTML: { __html: n } });
        }
        return null;
      };
    }
    e.s(
      [
        "RichText",
        0,
        function (e) {
          let {
            className: t,
            converters: n,
            data: i,
            disableContainer: o,
            disableIndent: s,
            disableTextAlign: a,
            nodeMap: c,
          } = e;
          if (!i) return null;
          let d = {};
          d = n ? ("function" == typeof n ? n({ defaultConverters: h }) : n) : h;
          let u =
            i &&
            !Array.isArray(i) &&
            "object" == typeof i &&
            "root" in i &&
            (function (e) {
              let { converters: t, data: n, disableIndent: i, disableTextAlign: o, nodeMap: s } = e;
              if (
                (function (e) {
                  if (!e?.root?.children?.length) return !1;
                  let t = !1;
                  if (e?.root?.children?.length === 1 && e?.root?.children[0]?.type === "paragraph") {
                    let r = e?.root?.children[0];
                    if (r?.children && r?.children?.length !== 0) {
                      if (r?.children?.length === 1) {
                        let e = r?.children[0];
                        e?.type !== "text" || e?.text?.length || (t = !0);
                      }
                    } else t = !0;
                  }
                  return !t;
                })(n)
              ) {
                let e = s
                  ? (function (e) {
                      let t = {};
                      for (let [l, n] of Object.entries(e))
                        if (n && "object" == typeof n) {
                          if ("blocks" === l) {
                            for (let [e, r] of ((t.blocks = {}), Object.entries(n)))
                              (r.Component || r.Block || r.html) && (t.blocks[e] = p(r));
                            continue;
                          }
                          if ("inlineBlocks" === l) {
                            for (let [e, r] of ((t.inlineBlocks = {}), Object.entries(n)))
                              (r.Component || r.Block || r.html) && (t.inlineBlocks[e] = p(r));
                            continue;
                          }
                          (n.Component || n.html) &&
                            (t[l] = (function (e) {
                              return (t) => {
                                let l = { ...t, isEditor: !1, isJSXConverter: !0 };
                                if (e.Component) return e.Component(l);
                                if (e.html) {
                                  let t = "function" == typeof e.html ? e.html(l) : e.html;
                                  return (0, r.jsx)("span", { dangerouslySetInnerHTML: { __html: t } });
                                }
                                return null;
                              };
                            })(n));
                        }
                      return t;
                    })(s)
                  : void 0;
                return (function e(t) {
                  let { converters: n, disableIndent: i, disableTextAlign: o, nodes: s, parent: a } = t,
                    c = n.unknown;
                  return s
                    .map((t, s) => {
                      let d;
                      "block" === t.type
                        ? (d = n?.blocks?.[t?.fields?.blockType]) ||
                          c ||
                          console.error(
                            `Lexical => JSX converter: Blocks converter: found ${t?.fields?.blockType} block, but no converter is provided`,
                          )
                        : "inlineBlock" === t.type
                          ? (d = n?.inlineBlocks?.[t?.fields?.blockType]) ||
                            c ||
                            console.error(
                              `Lexical => JSX converter: Inline Blocks converter: found ${t?.fields?.blockType} inline block, but no converter is provided`,
                            )
                          : (d = n[t.type]);
                      try {
                        let u;
                        (!d && c && (d = c),
                          (u = d
                            ? "function" == typeof d
                              ? d({
                                  childIndex: s,
                                  converters: n,
                                  node: t,
                                  nodesToJSX: (r) =>
                                    e({
                                      converters: r.converters ?? n,
                                      disableIndent: r.disableIndent ?? i,
                                      disableTextAlign: r.disableTextAlign ?? o,
                                      nodes: r.nodes,
                                      parent: r.parent ?? { ...t, parent: a },
                                    }),
                                  parent: a,
                                })
                              : d
                            : (0, r.jsx)("span", { children: "unknown node" }, s)));
                        let h = {};
                        if (!o && (!Array.isArray(o) || !o?.includes(t.type)) && "format" in t && t.format)
                          switch (t.format) {
                            case "center":
                              h.textAlign = "center";
                              break;
                            case "end":
                            case "right":
                              h.textAlign = "right";
                              break;
                            case "justify":
                              h.textAlign = "justify";
                              break;
                            case "left":
                              break;
                            case "start":
                              h.textAlign = "left";
                          }
                        if (
                          (!i &&
                            (!Array.isArray(i) || !i?.includes(t.type)) &&
                            "indent" in t &&
                            t.indent &&
                            "listitem" !== t.type &&
                            (h.paddingInlineStart = `${40 * Number(t.indent)}px`),
                          l.default.isValidElement(u))
                        ) {
                          if (h.textAlign || h.paddingInlineStart) {
                            let e = { ...h, ...(u?.props?.style ?? {}) };
                            return l.default.cloneElement(u, { key: s, style: e });
                          }
                          return l.default.cloneElement(u, { key: s });
                        }
                        return u;
                      } catch (e) {
                        return (console.error("Error converting lexical node to JSX:", e, "node:", t), null);
                      }
                    })
                    .filter(Boolean);
                })({
                  converters: e
                    ? {
                        ...t,
                        ...e,
                        blocks: { ...t.blocks, ...e.blocks },
                        inlineBlocks: { ...t.inlineBlocks, ...e.inlineBlocks },
                      }
                    : t,
                  disableIndent: i,
                  disableTextAlign: o,
                  nodes: n.root.children,
                  parent: n.root,
                });
              }
              return (0, r.jsx)(r.Fragment, {});
            })({ converters: d, data: i, disableIndent: s, disableTextAlign: a, nodeMap: c });
          return o
            ? (0, r.jsx)(r.Fragment, { children: u })
            : (0, r.jsx)("div", { className: t ?? "payload-richtext", children: u });
        },
      ],
      885147,
    );
  },
  660678,
  (e) => {
    "use strict";
    var t = e.i(271645),
      r = e.i(372775),
      l = e.i(912598);
    e.s([
      "HydrationBoundary",
      0,
      (e) => {
        let { children: n, options: i = {}, state: o, queryClient: s } = e,
          a = (0, l.useQueryClient)(s),
          c = t.useRef(i);
        c.current = i;
        let d = t.useMemo(() => {
          if (o) {
            if ("object" != typeof o) return;
            let e = a.getQueryCache(),
              t = o.queries || [],
              l = [],
              n = [];
            for (let r of t) {
              let t = e.get(r.queryHash);
              t
                ? (r.state.dataUpdatedAt > t.state.dataUpdatedAt ||
                    (r.promise &&
                      "pending" !== t.state.status &&
                      "fetching" !== t.state.fetchStatus &&
                      void 0 !== r.dehydratedAt &&
                      r.dehydratedAt > t.state.dataUpdatedAt)) &&
                  n.push(r)
                : l.push(r);
            }
            if ((l.length > 0 && (0, r.hydrate)(a, { queries: l }, c.current), n.length > 0)) return n;
          }
        }, [a, o]);
        return (
          t.useEffect(() => {
            d && (0, r.hydrate)(a, { queries: d }, c.current);
          }, [a, d]),
          n
        );
      },
    ]);
  },
  302125,
  (e, t, r) => {
    var l;
    (e.e,
      (t.exports = (l = function () {
        var e = JSON.parse(
            '{"$":"dollar","%":"percent","&":"and","<":"less",">":"greater","|":"or","¢":"cent","£":"pound","¤":"currency","¥":"yen","©":"(c)","ª":"a","®":"(r)","º":"o","À":"A","Á":"A","Â":"A","Ã":"A","Ä":"A","Å":"A","Æ":"AE","Ç":"C","È":"E","É":"E","Ê":"E","Ë":"E","Ì":"I","Í":"I","Î":"I","Ï":"I","Ð":"D","Ñ":"N","Ò":"O","Ó":"O","Ô":"O","Õ":"O","Ö":"O","Ø":"O","Ù":"U","Ú":"U","Û":"U","Ü":"U","Ý":"Y","Þ":"TH","ß":"ss","à":"a","á":"a","â":"a","ã":"a","ä":"a","å":"a","æ":"ae","ç":"c","è":"e","é":"e","ê":"e","ë":"e","ì":"i","í":"i","î":"i","ï":"i","ð":"d","ñ":"n","ò":"o","ó":"o","ô":"o","õ":"o","ö":"o","ø":"o","ù":"u","ú":"u","û":"u","ü":"u","ý":"y","þ":"th","ÿ":"y","Ā":"A","ā":"a","Ă":"A","ă":"a","Ą":"A","ą":"a","Ć":"C","ć":"c","Č":"C","č":"c","Ď":"D","ď":"d","Đ":"DJ","đ":"dj","Ē":"E","ē":"e","Ė":"E","ė":"e","Ę":"e","ę":"e","Ě":"E","ě":"e","Ğ":"G","ğ":"g","Ģ":"G","ģ":"g","Ĩ":"I","ĩ":"i","Ī":"i","ī":"i","Į":"I","į":"i","İ":"I","ı":"i","Ķ":"k","ķ":"k","Ļ":"L","ļ":"l","Ľ":"L","ľ":"l","Ł":"L","ł":"l","Ń":"N","ń":"n","Ņ":"N","ņ":"n","Ň":"N","ň":"n","Ō":"O","ō":"o","Ő":"O","ő":"o","Œ":"OE","œ":"oe","Ŕ":"R","ŕ":"r","Ř":"R","ř":"r","Ś":"S","ś":"s","Ş":"S","ş":"s","Š":"S","š":"s","Ţ":"T","ţ":"t","Ť":"T","ť":"t","Ũ":"U","ũ":"u","Ū":"u","ū":"u","Ů":"U","ů":"u","Ű":"U","ű":"u","Ų":"U","ų":"u","Ŵ":"W","ŵ":"w","Ŷ":"Y","ŷ":"y","Ÿ":"Y","Ź":"Z","ź":"z","Ż":"Z","ż":"z","Ž":"Z","ž":"z","Ə":"E","ƒ":"f","Ơ":"O","ơ":"o","Ư":"U","ư":"u","ǈ":"LJ","ǉ":"lj","ǋ":"NJ","ǌ":"nj","Ș":"S","ș":"s","Ț":"T","ț":"t","ə":"e","˚":"o","Ά":"A","Έ":"E","Ή":"H","Ί":"I","Ό":"O","Ύ":"Y","Ώ":"W","ΐ":"i","Α":"A","Β":"B","Γ":"G","Δ":"D","Ε":"E","Ζ":"Z","Η":"H","Θ":"8","Ι":"I","Κ":"K","Λ":"L","Μ":"M","Ν":"N","Ξ":"3","Ο":"O","Π":"P","Ρ":"R","Σ":"S","Τ":"T","Υ":"Y","Φ":"F","Χ":"X","Ψ":"PS","Ω":"W","Ϊ":"I","Ϋ":"Y","ά":"a","έ":"e","ή":"h","ί":"i","ΰ":"y","α":"a","β":"b","γ":"g","δ":"d","ε":"e","ζ":"z","η":"h","θ":"8","ι":"i","κ":"k","λ":"l","μ":"m","ν":"n","ξ":"3","ο":"o","π":"p","ρ":"r","ς":"s","σ":"s","τ":"t","υ":"y","φ":"f","χ":"x","ψ":"ps","ω":"w","ϊ":"i","ϋ":"y","ό":"o","ύ":"y","ώ":"w","Ё":"Yo","Ђ":"DJ","Є":"Ye","І":"I","Ї":"Yi","Ј":"J","Љ":"LJ","Њ":"NJ","Ћ":"C","Џ":"DZ","А":"A","Б":"B","В":"V","Г":"G","Д":"D","Е":"E","Ж":"Zh","З":"Z","И":"I","Й":"J","К":"K","Л":"L","М":"M","Н":"N","О":"O","П":"P","Р":"R","С":"S","Т":"T","У":"U","Ф":"F","Х":"H","Ц":"C","Ч":"Ch","Ш":"Sh","Щ":"Sh","Ъ":"U","Ы":"Y","Ь":"","Э":"E","Ю":"Yu","Я":"Ya","а":"a","б":"b","в":"v","г":"g","д":"d","е":"e","ж":"zh","з":"z","и":"i","й":"j","к":"k","л":"l","м":"m","н":"n","о":"o","п":"p","р":"r","с":"s","т":"t","у":"u","ф":"f","х":"h","ц":"c","ч":"ch","ш":"sh","щ":"sh","ъ":"u","ы":"y","ь":"","э":"e","ю":"yu","я":"ya","ё":"yo","ђ":"dj","є":"ye","і":"i","ї":"yi","ј":"j","љ":"lj","њ":"nj","ћ":"c","ѝ":"u","џ":"dz","Ґ":"G","ґ":"g","Ғ":"GH","ғ":"gh","Қ":"KH","қ":"kh","Ң":"NG","ң":"ng","Ү":"UE","ү":"ue","Ұ":"U","ұ":"u","Һ":"H","һ":"h","Ә":"AE","ә":"ae","Ө":"OE","ө":"oe","Ա":"A","Բ":"B","Գ":"G","Դ":"D","Ե":"E","Զ":"Z","Է":"E\'","Ը":"Y\'","Թ":"T\'","Ժ":"JH","Ի":"I","Լ":"L","Խ":"X","Ծ":"C\'","Կ":"K","Հ":"H","Ձ":"D\'","Ղ":"GH","Ճ":"TW","Մ":"M","Յ":"Y","Ն":"N","Շ":"SH","Չ":"CH","Պ":"P","Ջ":"J","Ռ":"R\'","Ս":"S","Վ":"V","Տ":"T","Ր":"R","Ց":"C","Փ":"P\'","Ք":"Q\'","Օ":"O\'\'","Ֆ":"F","և":"EV","ء":"a","آ":"aa","أ":"a","ؤ":"u","إ":"i","ئ":"e","ا":"a","ب":"b","ة":"h","ت":"t","ث":"th","ج":"j","ح":"h","خ":"kh","د":"d","ذ":"th","ر":"r","ز":"z","س":"s","ش":"sh","ص":"s","ض":"dh","ط":"t","ظ":"z","ع":"a","غ":"gh","ف":"f","ق":"q","ك":"k","ل":"l","م":"m","ن":"n","ه":"h","و":"w","ى":"a","ي":"y","ً":"an","ٌ":"on","ٍ":"en","َ":"a","ُ":"u","ِ":"e","ْ":"","٠":"0","١":"1","٢":"2","٣":"3","٤":"4","٥":"5","٦":"6","٧":"7","٨":"8","٩":"9","پ":"p","چ":"ch","ژ":"zh","ک":"k","گ":"g","ی":"y","۰":"0","۱":"1","۲":"2","۳":"3","۴":"4","۵":"5","۶":"6","۷":"7","۸":"8","۹":"9","฿":"baht","ა":"a","ბ":"b","გ":"g","დ":"d","ე":"e","ვ":"v","ზ":"z","თ":"t","ი":"i","კ":"k","ლ":"l","მ":"m","ნ":"n","ო":"o","პ":"p","ჟ":"zh","რ":"r","ს":"s","ტ":"t","უ":"u","ფ":"f","ქ":"k","ღ":"gh","ყ":"q","შ":"sh","ჩ":"ch","ც":"ts","ძ":"dz","წ":"ts","ჭ":"ch","ხ":"kh","ჯ":"j","ჰ":"h","Ṣ":"S","ṣ":"s","Ẁ":"W","ẁ":"w","Ẃ":"W","ẃ":"w","Ẅ":"W","ẅ":"w","ẞ":"SS","Ạ":"A","ạ":"a","Ả":"A","ả":"a","Ấ":"A","ấ":"a","Ầ":"A","ầ":"a","Ẩ":"A","ẩ":"a","Ẫ":"A","ẫ":"a","Ậ":"A","ậ":"a","Ắ":"A","ắ":"a","Ằ":"A","ằ":"a","Ẳ":"A","ẳ":"a","Ẵ":"A","ẵ":"a","Ặ":"A","ặ":"a","Ẹ":"E","ẹ":"e","Ẻ":"E","ẻ":"e","Ẽ":"E","ẽ":"e","Ế":"E","ế":"e","Ề":"E","ề":"e","Ể":"E","ể":"e","Ễ":"E","ễ":"e","Ệ":"E","ệ":"e","Ỉ":"I","ỉ":"i","Ị":"I","ị":"i","Ọ":"O","ọ":"o","Ỏ":"O","ỏ":"o","Ố":"O","ố":"o","Ồ":"O","ồ":"o","Ổ":"O","ổ":"o","Ỗ":"O","ỗ":"o","Ộ":"O","ộ":"o","Ớ":"O","ớ":"o","Ờ":"O","ờ":"o","Ở":"O","ở":"o","Ỡ":"O","ỡ":"o","Ợ":"O","ợ":"o","Ụ":"U","ụ":"u","Ủ":"U","ủ":"u","Ứ":"U","ứ":"u","Ừ":"U","ừ":"u","Ử":"U","ử":"u","Ữ":"U","ữ":"u","Ự":"U","ự":"u","Ỳ":"Y","ỳ":"y","Ỵ":"Y","ỵ":"y","Ỷ":"Y","ỷ":"y","Ỹ":"Y","ỹ":"y","–":"-","‘":"\'","’":"\'","“":"\\"","”":"\\"","„":"\\"","†":"+","•":"*","…":"...","₠":"ecu","₢":"cruzeiro","₣":"french franc","₤":"lira","₥":"mill","₦":"naira","₧":"peseta","₨":"rupee","₩":"won","₪":"new shequel","₫":"dong","€":"euro","₭":"kip","₮":"tugrik","₯":"drachma","₰":"penny","₱":"peso","₲":"guarani","₳":"austral","₴":"hryvnia","₵":"cedi","₸":"kazakhstani tenge","₹":"indian rupee","₺":"turkish lira","₽":"russian ruble","₿":"bitcoin","℠":"sm","™":"tm","∂":"d","∆":"delta","∑":"sum","∞":"infinity","♥":"love","元":"yuan","円":"yen","﷼":"rial","ﻵ":"laa","ﻷ":"laa","ﻹ":"lai","ﻻ":"la"}',
          ),
          t = JSON.parse(
            '{"bg":{"Й":"Y","Ц":"Ts","Щ":"Sht","Ъ":"A","Ь":"Y","й":"y","ц":"ts","щ":"sht","ъ":"a","ь":"y"},"de":{"Ä":"AE","ä":"ae","Ö":"OE","ö":"oe","Ü":"UE","ü":"ue","ß":"ss","%":"prozent","&":"und","|":"oder","∑":"summe","∞":"unendlich","♥":"liebe"},"es":{"%":"por ciento","&":"y","<":"menor que",">":"mayor que","|":"o","¢":"centavos","£":"libras","¤":"moneda","₣":"francos","∑":"suma","∞":"infinito","♥":"amor"},"fr":{"%":"pourcent","&":"et","<":"plus petit",">":"plus grand","|":"ou","¢":"centime","£":"livre","¤":"devise","₣":"franc","∑":"somme","∞":"infini","♥":"amour"},"pt":{"%":"porcento","&":"e","<":"menor",">":"maior","|":"ou","¢":"centavo","∑":"soma","£":"libra","∞":"infinito","♥":"amor"},"uk":{"И":"Y","и":"y","Й":"Y","й":"y","Ц":"Ts","ц":"ts","Х":"Kh","х":"kh","Щ":"Shch","щ":"shch","Г":"H","г":"h"},"vi":{"Đ":"D","đ":"d"},"da":{"Ø":"OE","ø":"oe","Å":"AA","å":"aa","%":"procent","&":"og","|":"eller","$":"dollar","<":"mindre end",">":"større end"},"nb":{"&":"og","Å":"AA","Æ":"AE","Ø":"OE","å":"aa","æ":"ae","ø":"oe"},"it":{"&":"e"},"nl":{"&":"en"},"sv":{"&":"och","Å":"AA","Ä":"AE","Ö":"OE","å":"aa","ä":"ae","ö":"oe"}}',
          );
        function r(r, l) {
          if ("string" != typeof r) throw Error("slugify: string argument expected");
          var n = t[(l = "string" == typeof l ? { replacement: l } : l || {}).locale] || {},
            i = void 0 === l.replacement ? "-" : l.replacement,
            o = void 0 === l.trim || l.trim,
            s = r
              .normalize()
              .split("")
              .reduce(function (t, r) {
                var o = n[r];
                return (
                  void 0 === o && (o = e[r]),
                  void 0 === o && (o = r),
                  o === i && (o = " "),
                  t + o.replace(l.remove || /[^\w\s$*_+~.()'"!\-:@]+/g, "")
                );
              }, "");
          return (
            l.strict && (s = s.replace(/[^A-Za-z0-9\s]/g, "")),
            o && (s = s.trim()),
            (s = s.replace(/\s+/g, i)),
            l.lower && (s = s.toLowerCase()),
            s
          );
        }
        return (
          (r.extend = function (t) {
            Object.assign(e, t);
          }),
          r
        );
      })()),
      (t.exports.default = l()));
  },
  267493,
  605663,
  (e) => {
    "use strict";
    var t = e.i(933818);
    e.i(471086);
    var r = e.i(678787),
      l = e.i(651501),
      n = e.i(81844);
    let i = async (e, t, i) => {
      try {
        return await n.httpInstance
          .get(`${r.EPageApi.API_PAGE}`, {
            searchParams: { slug: t, locale: i },
            signal: e?.signal,
            cache: "force-cache",
            next: { revalidate: 300, tags: [r.EPageApi.API_PAGE, t] },
          })
          .json();
      } catch (e) {
        if (e instanceof l.HTTPError && 404 === e.response.status) return null;
        throw e;
      }
    };
    (e.s(
      [
        "pageQueryOptions",
        0,
        (e, l) =>
          (0, t.queryOptions)({
            queryKey: [r.EPageKey.PAGES_QUERY, e, l],
            queryFn: (t) => i(t, e, l || "en"),
            select: (e) => e?.docs?.at(0) || null,
            staleTime: 6e5,
            gcTime: 9e5,
          }),
      ],
      605663,
    ),
      e.s([], 267493));
  },
  471086,
  678787,
  887541,
  (e) => {
    "use strict";
    var t,
      r,
      l,
      n,
      i = (((t = {}).PAGES_QUERY = "pages_query"), t),
      o = (((r = {}).API_PAGE = "page"), r);
    e.s(["EPageApi", () => o, "EPageKey", () => i], 678787);
    var s =
        (((l = {}).REVIEWS_QUERY = "reviews_query"), (l.REVIEWS_GENERAL_QUERY = "reviews_general_query"), l),
      a = (((n = {}).API_REVIEWS = "country-reviews"), n);
    (e.s(["EReviewsApi", () => a, "EReviewsKey", () => s], 887541), e.s([], 471086));
  },
  545364,
  714621,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(202042),
      l = e.i(948148),
      n = e.i(134404);
    (e.s([], 545364),
      e.s(
        [
          "HelpCenterBreadcrumb",
          0,
          (e) => {
            let i,
              o,
              { breadCrumbLabel: s, isProfile: a } = e,
              c = [
                { label: (i = (0, l.useTranslations)())("home_title"), href: n.EClientRoutes.BASE },
                { label: i("help_center_title"), href: n.EClientRoutes.HELP },
              ],
              d = [
                { label: (o = (0, l.useTranslations)())("home_title"), href: n.EClientRoutes.BASE },
                { label: o("help_center_title"), href: n.EClientRoutes.HELP },
              ];
            return (0, t.jsx)("nav", {
              className: "flex w-full overflow-hidden text-sm text-grey-light",
              children: (0, t.jsxs)("ul", {
                className: "flex w-full items-center",
                children: [
                  a
                    ? d.map((e, l) =>
                        (0, t.jsxs)(
                          "li",
                          {
                            className: "flex flex-shrink-0 items-center",
                            children: [
                              (0, t.jsx)(r.Link, {
                                href: `/profile${e.href}`,
                                children: (0, t.jsx)("p", {
                                  className: "cursor-pointer whitespace-nowrap hover:underline",
                                  children: e.label,
                                }),
                              }),
                              (s || l < d.length - 1) &&
                                (0, t.jsx)("span", { className: "mx-2", children: ">" }),
                            ],
                          },
                          `${l}-${e.label}`,
                        ),
                      )
                    : c.map((e, l) =>
                        (0, t.jsxs)(
                          "li",
                          {
                            className: "flex flex-shrink-0 items-center",
                            children: [
                              (0, t.jsx)(r.Link, {
                                href: e.href,
                                children: (0, t.jsx)("p", {
                                  className: "cursor-pointer whitespace-nowrap hover:underline",
                                  children: e.label,
                                }),
                              }),
                              (s || l < c.length - 1) &&
                                (0, t.jsx)("span", { className: "mx-2", children: ">" }),
                            ],
                          },
                          `${l}-${e.label}`,
                        ),
                      ),
                  (0, t.jsx)("li", {
                    className: "min-w-0 flex-shrink",
                    children: (0, t.jsx)("p", {
                      className:
                        "overflow-hidden text-ellipsis whitespace-nowrap font-bold text-dark-custom sm:max-w-full",
                      children: s,
                    }),
                  }),
                ],
              }),
            });
          },
        ],
        714621,
      ));
  },
  427930,
  219546,
  815389,
  319587,
  (e) => {
    "use strict";
    var t = e.i(271645),
      r = e.i(93097);
    let l = (e) =>
      e
        .toLowerCase()
        .trim()
        .replace(/[^\p{L}\p{N}\s-]/gu, "")
        .replace(/\s+/g, "-")
        .slice(0, 80);
    (e.s(
      [
        "usePageToc",
        0,
        () => {
          let e = (0, t.useRef)(null),
            [n, i] = (0, t.useState)([]),
            [o, s] = (0, t.useState)(null),
            a = (0, t.useRef)("");
          return (
            (0, t.useEffect)(() => {
              let t = e.current;
              if (!t) return;
              let n = () => {
                let e = Array.from(t.querySelectorAll("h2, h6")),
                  n = new Map(),
                  o = [];
                for (let t of e) {
                  let e = t.textContent?.trim() || "";
                  if (e) {
                    if ((0, r.isAllCaps)(e)) {
                      let l = (0, r.toTitleCase)(e);
                      (Array.from(t.childNodes).every((e) => e.nodeType === Node.TEXT_NODE) &&
                        (t.textContent = l),
                        (e = l));
                    }
                    if (!t.id) {
                      let r = l(e) || "section",
                        i = n.get(r) || 0;
                      (n.set(r, i + 1), (t.id = 0 === i ? r : `${r}-${i + 1}`));
                    }
                    o.push({ id: t.id, label: e, level: +("H6" === t.tagName) });
                  }
                }
                let s = JSON.stringify(o);
                s !== a.current && ((a.current = s), i(o));
              };
              n();
              let o = new MutationObserver(n);
              return (o.observe(t, { childList: !0, subtree: !0 }), () => o.disconnect());
            }, []),
            (0, t.useEffect)(() => {
              if (!n.length) return;
              let e = n
                .map((e) => {
                  let { id: t } = e;
                  return document.getElementById(t);
                })
                .filter((e) => !!e);
              if (!e.length) return;
              let t = () => {
                let t = e[0].id;
                for (let r of e) r.getBoundingClientRect().top - 120 <= 0 && (t = r.id);
                s(t);
              };
              return (
                t(),
                window.addEventListener("scroll", t, { passive: !0 }),
                () => window.removeEventListener("scroll", t)
              );
            }, [n]),
            { articleRef: e, items: n, activeId: o }
          );
        },
      ],
      219546,
    ),
      e.s(
        [
          "SCROLL_HEADER_OFFSET",
          0,
          112,
          "STATIC_PAGE_PROSE_CLASS",
          0,
          "prose max-w-none text-[15px] leading-[26px] text-grey-dark lg:text-base lg:leading-[28px] prose-headings:font-bold prose-headings:tracking-[-0.01em] prose-headings:text-light-black-custom lg:[&>:first-child]:mt-0 prose-h2:mb-4 prose-h2:mt-11 prose-h2:scroll-mt-28 prose-h2:text-xl prose-h2:leading-7 lg:prose-h2:mt-[52px] lg:prose-h2:text-[21px] lg:prose-h2:leading-[30px] [&_h6]:mb-2 [&_h6]:mt-7 [&_h6]:scroll-mt-28 [&_h6]:text-base [&_h6]:font-semibold [&_h6]:tracking-normal [&_h6]:leading-6 lg:[&_h6]:text-[17px] lg:[&_h6]:leading-7 prose-p:my-3.5 prose-strong:font-semibold prose-strong:text-light-black-custom [&_a]:font-medium [&_a]:text-blue-custom [&_a]:no-underline [&_a:hover]:underline [&_ul]:my-3.5 [&_ul]:ps-5 [&_ol]:my-3.5 [&_ol]:ps-5 [&_ul_li]:list-disc [&_ol_li]:list-decimal [&_li]:my-1.5 marker:text-grey-dark [&_.lexical-table-container]:overflow-x-auto [&_.lexical-table]:w-full [&_.lexical-table]:my-0 [&_.lexical-table]:text-sm [&_.lexical-table]:leading-6 [&_.lexical-table-cell]:!border-x-0 [&_.lexical-table-cell]:!border-t-0 [&_.lexical-table-cell]:!border-b [&_.lexical-table-cell]:!border-solid [&_.lexical-table-cell]:!border-[#eef0f3] [&_.lexical-table-row:last-child_.lexical-table-cell]:!border-b-0 [&_.lexical-table-cell]:!py-3 [&_.lexical-table-cell]:!ps-0 [&_.lexical-table-cell]:!pe-3 [&_.lexical-table-cell]:align-top lg:[&_.lexical-table-cell]:!pe-6 [&_.lexical-table-cell]:text-start [&_.lexical-table-cell]:font-normal [&_.lexical-table-cell]:text-grey-dark [&_.lexical-table-cell_p]:!my-0 [&_.lexical-table-row>*:first-child]:font-semibold [&_.lexical-table-row>*:first-child]:text-light-black-custom prose-blockquote:rounded-xl prose-blockquote:border prose-blockquote:border-[#eef0f3] prose-blockquote:bg-[#f7f8fa] prose-blockquote:px-5 prose-blockquote:py-4 prose-blockquote:font-normal prose-blockquote:not-italic prose-blockquote:text-grey-dark",
        ],
        815389,
      ),
      e.s(
        [
          "useSmoothScroll",
          0,
          () => ({
            scrollToHeading: (0, t.useCallback)((e) => {
              let t = document.getElementById(e);
              if (!t) return;
              let r = t.getBoundingClientRect().top + window.scrollY - 112;
              history.replaceState(null, "", `#${e}`);
              let l = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
              window.scrollTo({ top: Math.max(r, 0), behavior: l ? "auto" : "smooth" });
            }, []),
          }),
        ],
        319587,
      ),
      e.s([], 427930));
  },
  867107,
  1693,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(885147),
      l = e.i(302125),
      n = e.i(93097);
    let i = (e) =>
        "object" == typeof e && null !== e && "type" in e && "text" === e.type && "text" in e && !e.format,
      o = function () {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
          r = (r) => {
            let { node: o, nodesToJSX: s } = r,
              a = o.children
                .filter((e) => "object" == typeof e && e && "text" in e)
                .map((e) => e.text)
                .join(""),
              c = a.match(/^(\d+(?:\.\d+)?)(?:\.|[\s]|$)/),
              d = c ? parseFloat(c[1]) : null,
              u = e.find((e) => e.headingNumber === d),
              h = {
                id: u?.customId || (0, l.default)(a, { lower: !0, strict: !0 }),
                className: "scroll-mt-20",
              },
              p =
                (0, n.isAllCaps)(a) && o.children.every(i)
                  ? [{ ...o.children[0], text: (0, n.toTitleCase)(a) }]
                  : o.children;
            switch (o.tag) {
              case "h2":
                return (0, t.jsx)("h2", { ...h, children: s({ nodes: p }) });
              case "h6":
                return (0, t.jsx)("h6", { ...h, children: s({ nodes: p }) });
              default:
                return null;
            }
          };
        return ((r.displayName = "HeadingConverter"), r);
      };
    o();
    var s = e.i(335889),
      a = e.i(663615),
      c = e.i(523173),
      d = e.i(982363);
    e.i(470366);
    var u = e.i(504001);
    let h = /^(https?:|mailto:|\/|#)/i,
      p = function () {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
          r = arguments.length > 1 ? arguments[1] : void 0,
          l = arguments.length > 2 ? arguments[2] : void 0,
          n = arguments.length > 3 ? arguments[3] : void 0,
          i = arguments.length > 4 ? arguments[4] : void 0,
          o = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : "md",
          p = (p) => {
            let m,
              { node: f, nodesToJSX: x } = p,
              { url: g, newTab: b } = f.fields,
              y = g && h.test(g.trim()) ? g : "",
              v = y && e?.some((e) => e?.includes(y)),
              k = y || "";
            if (y?.startsWith("mailto:")) {
              let e = y.match(/^mailto:([^?]+)/);
              e &&
                ((m = e[1]),
                (k = (0, d.createSupportMailtoLink)({
                  userId: r?.id,
                  subscriptionId: l,
                  userEmail: r?.email,
                  supportEmail: m,
                })));
            }
            let E = m?.toLowerCase() === "legal@myiq.com";
            return y && v
              ? (0, t.jsx)("span", {
                  className: (0, a.cn)("my-5 block", n),
                  children: (0, t.jsxs)(s.Button, {
                    as: "a",
                    href: y,
                    target: b ? "_blank" : "_self",
                    rel: b ? "noopener noreferrer" : void 0,
                    variant: "solid",
                    size: o,
                    className: (0, a.cn)("!bg-green-custom !text-white !no-underline", n),
                    disableRipple: !0,
                    onPress: () => {
                      y?.includes("cancellation") &&
                        (0, u.trackClientEvents)({
                          event: c.EAnalyticEvents.CANCEL_FLOW_CANCELLATION_PORTAL_CLICKED,
                        });
                    },
                    children: [x({ nodes: f.children }), i && i],
                  }),
                })
              : (0, t.jsx)("a", {
                  href: k,
                  target: b ? "_blank" : "_self",
                  rel: b ? "noopener noreferrer" : void 0,
                  className: "text-blue-500 underline",
                  onClick: E
                    ? () => {
                        E && (0, u.trackClientEvents)({ event: c.EAnalyticEvents.TERMS_LEGAL_EMAIL_CLICKED });
                      }
                    : void 0,
                  children: x({ nodes: f.children }),
                });
          };
        return ((p.displayName = "LinkConverter"), p);
      };
    (p(),
      e.s([], 867107),
      e.s(
        [
          "RichText",
          0,
          (e) => {
            let {
              className: l,
              data: n,
              headingIdMap: i,
              linkAsButton: s,
              serverUser: a,
              userSubscriptionId: c,
              linkAsButtonClassName: d,
              linkAsButtonSize: u,
              buttonIcon: h,
              ...m
            } = e;
            return (0, t.jsx)(r.RichText, {
              ...m,
              data: n,
              className: l,
              converters: i
                ? (e) => {
                    let { defaultConverters: t } = e,
                      r = p([], a, c);
                    return { ...t, heading: o(i), link: r, autolink: r };
                  }
                : (e) => {
                    let { defaultConverters: t } = e,
                      r = p(s, a, c, d, h, u);
                    return { ...t, heading: o(), link: r, autolink: r };
                  },
            });
          },
        ],
        1693,
      ));
  },
  982363,
  (e) => {
    "use strict";
    var t = e.i(322062);
    e.s([
      "createSupportMailtoLink",
      0,
      (e) => {
        let {
            userEmail: r,
            userId: l,
            subscriptionId: n,
            supportEmail: i = "help@myiq.com",
            subject: o = "Support Request",
          } = e,
          s = { ...e };
        if (!l || !r || !n) {
          let i = t.useUserSupportContextStore.getState();
          s = {
            ...e,
            userId: l || i.userId || void 0,
            userEmail: r || i.email || void 0,
            subscriptionId: n || i.subscriptionId || void 0,
          };
        }
        let a = ((e) => {
            let { userId: t, subscriptionId: r, userEmail: l } = e,
              n = [];
            return (t && n.push(`User ID: ${t}`),
            r && n.push(`Subscription ID: ${r}`),
            l && n.push(`Email: ${l}`),
            0 === n.length)
              ? ""
              : [
                  "=== Please keep this information for faster support ===",
                  ...n,
                  "====================================================",
                ].join("\n");
          })(s),
          c = encodeURIComponent(o),
          d = encodeURIComponent(a);
        return `mailto:${i}?subject=${c}&body=${d}`;
      },
    ]);
  },
  322062,
  (e) => {
    "use strict";
    var t = e.i(768834),
      r = e.i(579473);
    let l = { email: null, userId: null, subscriptionId: null },
      n = (0, t.create)()(
        (0, r.persist)(
          (e) => ({
            ...l,
            handleChangeUserSupportContext: (t) =>
              e((e) => ({
                email: t.email ?? e.email,
                userId: t.userId ?? e.userId,
                subscriptionId: t.subscriptionId ?? e.subscriptionId,
              })),
            clearUserSupportContext: () => e(l),
          }),
          { name: "user_support_context", version: 1 },
        ),
      );
    e.s(["useUserSupportContextStore", 0, n]);
  },
  93097,
  (e) => {
    "use strict";
    let t = new Set(["a", "an", "and", "as", "at", "by", "for", "in", "of", "on", "or", "the", "to", "with"]),
      r = {
        iq: "IQ",
        myiq: "myIQ",
        sla: "SLA",
        gdpr: "GDPR",
        ccpa: "CCPA",
        faq: "FAQ",
        eu: "EU",
        us: "US",
        uk: "UK",
      };
    e.s([
      "isAllCaps",
      0,
      (e) => /\p{Lu}/u.test(e) && e === e.toUpperCase(),
      "toTitleCase",
      0,
      (e) =>
        e.toLowerCase().replace(/\p{L}[\p{L}’'-]*/gu, (e, l) => {
          let n = r[e];
          return n || (l > 0 && t.has(e) ? e : e.charAt(0).toUpperCase() + e.slice(1));
        }),
    ]);
  },
]);
