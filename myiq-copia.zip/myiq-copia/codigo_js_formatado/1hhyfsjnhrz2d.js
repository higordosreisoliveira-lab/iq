(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  461316,
  (e, t, r) => {
    "use strict";
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      (r.default = function (e) {
        let { html: t, height: r = null, width: o = null, children: s, dataNtpc: a = "" } = e;
        return (
          (0, i.useEffect)(() => {
            a && performance.mark("mark_feature_usage", { detail: { feature: `next-third-parties-${a}` } });
          }, [a]),
          (0, n.jsxs)(n.Fragment, {
            children: [
              s,
              t
                ? (0, n.jsx)("div", {
                    style: { height: null != r ? `${r}px` : "auto", width: null != o ? `${o}px` : "auto" },
                    "data-ntpc": a,
                    dangerouslySetInnerHTML: { __html: t },
                  })
                : null,
            ],
          })
        );
      }));
    let n = e.r(843476),
      i = e.r(271645);
  },
  654576,
  (e, t, r) => {
    "use strict";
    let n;
    var i =
      (e.e && e.e.__importDefault) ||
      function (e) {
        return e && e.__esModule ? e : { default: e };
      };
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      (r.GoogleAnalytics = function (e) {
        let { gaId: t, debugMode: r, dataLayerName: i = "dataLayer", nonce: c } = e;
        return (
          void 0 === n && (n = i),
          (0, s.useEffect)(() => {
            performance.mark("mark_feature_usage", { detail: { feature: "next-third-parties-ga" } });
          }, []),
          (0, o.jsxs)(o.Fragment, {
            children: [
              (0, o.jsx)(a.default, {
                id: "_next-ga-init",
                dangerouslySetInnerHTML: {
                  __html: `
          window['${i}'] = window['${i}'] || [];
          function gtag(){window['${i}'].push(arguments);}
          gtag('js', new Date());

          gtag('config', '${t}' ${r ? ",{ 'debug_mode': true }" : ""});`,
                },
                nonce: c,
              }),
              (0, o.jsx)(a.default, {
                id: "_next-ga",
                src: `https://www.googletagmanager.com/gtag/js?id=${t}`,
                nonce: c,
              }),
            ],
          })
        );
      }),
      (r.sendGAEvent = function () {
        for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
        void 0 === n
          ? console.warn("@next/third-parties: GA has not been initialized")
          : window[n]
            ? window[n].push(arguments)
            : console.warn(`@next/third-parties: GA dataLayer ${n} does not exist`);
      }));
    let o = e.r(843476),
      s = e.r(271645),
      a = i(e.r(3303));
  },
  667345,
  (e, t, r) => {
    "use strict";
    var n =
      (e.e && e.e.__importDefault) ||
      function (e) {
        return e && e.__esModule ? e : { default: e };
      };
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      (r.default = function (e) {
        let { apiKey: t, ...r } = e,
          n = { ...r, key: t },
          { html: a } = (0, o.GoogleMapsEmbed)(n);
        return (0, i.jsx)(s.default, {
          height: n.height || null,
          width: n.width || null,
          html: a,
          dataNtpc: "GoogleMapsEmbed",
        });
      }));
    let i = e.r(843476),
      o = e.r(981498),
      s = n(e.r(461316));
  },
  19598,
  (e, t, r) => {
    "use strict";
    var n =
      (e.e && e.e.__importDefault) ||
      function (e) {
        return e && e.__esModule ? e : { default: e };
      };
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      (r.sendGTMEvent = void 0),
      (r.GoogleTagManager = function (e) {
        let {
          gtmId: t,
          gtmScriptUrl: r,
          dataLayerName: n = "dataLayer",
          auth: c,
          preview: u,
          dataLayer: l,
          nonce: p,
        } = e;
        a = n;
        let h = new URL(r || "https://www.googletagmanager.com/gtm.js");
        return (
          t && h.searchParams.set("id", t),
          "dataLayer" !== n && h.searchParams.set("l", n),
          c && h.searchParams.set("gtm_auth", c),
          u && (h.searchParams.set("gtm_preview", u), h.searchParams.set("gtm_cookies_win", "x")),
          (0, o.useEffect)(() => {
            performance.mark("mark_feature_usage", { detail: { feature: "next-third-parties-gtm" } });
          }, []),
          (0, i.jsxs)(i.Fragment, {
            children: [
              (0, i.jsx)(s.default, {
                id: "_next-gtm-init",
                dangerouslySetInnerHTML: {
                  __html: `
      (function(w,l){
        w[l]=w[l]||[];
        w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});
        ${l ? `w[l].push(${JSON.stringify(l)})` : ""}
      })(window,'${n}');`,
                },
                nonce: p,
              }),
              (0, i.jsx)(s.default, { id: "_next-gtm", "data-ntpc": "GTM", src: h.href, nonce: p }),
            ],
          })
        );
      }));
    let i = e.r(843476),
      o = e.r(271645),
      s = n(e.r(3303)),
      a = "dataLayer";
    r.sendGTMEvent = (e, t) => {
      let r = t || a;
      ((window[r] = window[r] || []), window[r].push(e));
    };
  },
  387644,
  (e, t, r) => {
    "use strict";
    var n =
      (e.e && e.e.__importDefault) ||
      function (e) {
        return e && e.__esModule ? e : { default: e };
      };
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      (r.sendGAEvent =
        r.GoogleAnalytics =
        r.sendGTMEvent =
        r.GoogleTagManager =
        r.YouTubeEmbed =
        r.GoogleMapsEmbed =
          void 0));
    var i = e.r(667345);
    Object.defineProperty(r, "GoogleMapsEmbed", {
      enumerable: !0,
      get: function () {
        return n(i).default;
      },
    });
    var o = e.r(621783);
    Object.defineProperty(r, "YouTubeEmbed", {
      enumerable: !0,
      get: function () {
        return n(o).default;
      },
    });
    var s = e.r(19598);
    (Object.defineProperty(r, "GoogleTagManager", {
      enumerable: !0,
      get: function () {
        return s.GoogleTagManager;
      },
    }),
      Object.defineProperty(r, "sendGTMEvent", {
        enumerable: !0,
        get: function () {
          return s.sendGTMEvent;
        },
      }));
    var a = e.r(654576);
    (Object.defineProperty(r, "GoogleAnalytics", {
      enumerable: !0,
      get: function () {
        return a.GoogleAnalytics;
      },
    }),
      Object.defineProperty(r, "sendGAEvent", {
        enumerable: !0,
        get: function () {
          return a.sendGAEvent;
        },
      }));
  },
  621783,
  (e, t, r) => {
    "use strict";
    var n =
      (e.e && e.e.__importDefault) ||
      function (e) {
        return e && e.__esModule ? e : { default: e };
      };
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      (r.default = function (e) {
        let { html: t, scripts: r, stylesheets: n } = (0, s.YouTubeEmbed)(e);
        return (0, i.jsx)(a.default, {
          height: e.height || null,
          width: e.width || null,
          html: t,
          dataNtpc: "YouTubeEmbed",
          children:
            null == r
              ? void 0
              : r.map((e) =>
                  (0, i.jsx)(o.default, { src: e.url, strategy: c[e.strategy], stylesheets: n }, e.url),
                ),
        });
      }));
    let i = e.r(843476),
      o = n(e.r(3303)),
      s = e.r(981498),
      a = n(e.r(461316)),
      c = { server: "beforeInteractive", client: "afterInteractive", idle: "lazyOnload", worker: "worker" };
  },
  71187,
  (e, t, r) => {
    "use strict";
    function n(e) {
      try {
        return JSON.stringify(e);
      } catch (e) {
        return '"[Circular]"';
      }
    }
    t.exports = function (e, t, r) {
      var i = (r && r.stringify) || n;
      if ("object" == typeof e && null !== e) {
        var o = t.length + 1;
        if (1 === o) return e;
        var s = Array(o);
        s[0] = i(e);
        for (var a = 1; a < o; a++) s[a] = i(t[a]);
        return s.join(" ");
      }
      if ("string" != typeof e) return e;
      var c = t.length;
      if (0 === c) return e;
      for (var u = "", l = 0, p = -1, h = (e && e.length) || 0, d = 0; d < h;) {
        if (37 === e.charCodeAt(d) && d + 1 < h) {
          switch (((p = p > -1 ? p : 0), e.charCodeAt(d + 1))) {
            case 100:
            case 102:
              if (l >= c || null == t[l]) break;
              (p < d && (u += e.slice(p, d)), (u += Number(t[l])), (p = d + 2), d++);
              break;
            case 105:
              if (l >= c || null == t[l]) break;
              (p < d && (u += e.slice(p, d)), (u += Math.floor(Number(t[l]))), (p = d + 2), d++);
              break;
            case 79:
            case 111:
            case 106:
              if (l >= c || void 0 === t[l]) break;
              p < d && (u += e.slice(p, d));
              var f = typeof t[l];
              if ("string" === f) {
                ((u += "'" + t[l] + "'"), (p = d + 2), d++);
                break;
              }
              if ("function" === f) {
                ((u += t[l].name || "<anonymous>"), (p = d + 2), d++);
                break;
              }
              ((u += i(t[l])), (p = d + 2), d++);
              break;
            case 115:
              if (l >= c) break;
              (p < d && (u += e.slice(p, d)), (u += String(t[l])), (p = d + 2), d++);
              break;
            case 37:
              (p < d && (u += e.slice(p, d)), (u += "%"), (p = d + 2), d++, l--);
          }
          ++l;
        }
        ++d;
      }
      return -1 === p ? e : (p < h && (u += e.slice(p)), u);
    };
  },
  102232,
  (e, t, r) => {
    "use strict";
    let n = e.r(71187);
    t.exports = l;
    let i =
      (function () {
        function e(e) {
          return void 0 !== e && e;
        }
        try {
          if ("u" > typeof globalThis) return globalThis;
          return (
            Object.defineProperty(Object.prototype, "globalThis", {
              get: function () {
                return (delete Object.prototype.globalThis, (this.globalThis = this));
              },
              configurable: !0,
            }),
            globalThis
          );
        } catch (t) {
          return e(self) || e(window) || e(this) || {};
        }
      })().console || {};
    function o(e, t) {
      return "silent" === e ? 1 / 0 : t.levels.values[e];
    }
    let s = Symbol("pino.logFuncs"),
      a = Symbol("pino.hierarchy"),
      c = { error: "log", fatal: "error", warn: "error", info: "log", debug: "log", trace: "log" };
    function u(e, t) {
      let r = { logger: t, parent: e[a] };
      t[a] = r;
    }
    function l(e) {
      var t, r, n;
      let a, f, g;
      (e = e || {}).browser = e.browser || {};
      let m = e.browser.transmit;
      if (m && "function" != typeof m.send) throw Error("pino: transmit option must have a send function");
      let b = e.browser.write || i;
      e.browser.write && (e.browser.asObject = !0);
      let C = e.serializers || {},
        E =
          ((t = e.browser.serialize),
          Array.isArray(t)
            ? t.filter(function (e) {
                return "!stdSerializers.err" !== e;
              })
            : !0 === t && Object.keys(C)),
        w = e.browser.serialize;
      Array.isArray(e.browser.serialize) &&
        e.browser.serialize.indexOf("!stdSerializers.err") > -1 &&
        (w = !1);
      let I = Object.keys(e.customLevels || {}),
        S = ["error", "fatal", "warn", "info", "debug", "trace"].concat(I);
      ("function" == typeof b &&
        S.forEach(function (e) {
          b[e] = b;
        }),
        (!1 === e.enabled || e.browser.disabled) && (e.level = "silent"));
      let k = e.level || "info",
        O = Object.create(b);
      (O.log || (O.log = _),
        (a = {}),
        S.forEach((e) => {
          a[e] = b[e] ? b[e] : i[e] || i[c[e] || "log"] || _;
        }),
        (O[s] = a),
        u({}, O),
        Object.defineProperty(O, "levelVal", {
          get: function () {
            return o(this.level, this);
          },
        }),
        Object.defineProperty(O, "level", {
          get: function () {
            return this._level;
          },
          set: function (e) {
            if ("silent" !== e && !this.levels.values[e]) throw Error("unknown level " + e);
            ((this._level = e),
              p(this, A, O, "error"),
              p(this, A, O, "fatal"),
              p(this, A, O, "warn"),
              p(this, A, O, "info"),
              p(this, A, O, "debug"),
              p(this, A, O, "trace"),
              I.forEach((e) => {
                p(this, A, O, e);
              }));
          },
        }));
      let A = {
        transmit: m,
        serialize: E,
        asObject: e.browser.asObject,
        formatters: e.browser.formatters,
        levels: S,
        timestamp: "function" == typeof (r = e).timestamp ? r.timestamp : !1 === r.timestamp ? v : y,
        messageKey: e.messageKey || "msg",
        onChild: e.onChild || _,
      };
      function R(t, r, n) {
        if (!r) throw Error("missing bindings for child Pino");
        ((n = n || {}), E && r.serializers && (n.serializers = r.serializers));
        let i = n.serializers;
        if (E && i) {
          var o = Object.assign({}, C, i),
            s = !0 === e.browser.serialize ? Object.keys(o) : E;
          (delete r.serializers, h([r], s, o, this._stdErrSerialize));
        }
        function a(e) {
          ((this._childLevel = (0 | e._childLevel) + 1),
            (this.bindings = r),
            o && ((this.serializers = o), (this._serialize = s)),
            m && (this._logEvent = d([].concat(e._logEvent.bindings, r))));
        }
        a.prototype = this;
        let c = new a(this);
        return (
          u(this, c),
          (c.child = function () {
            for (var e = arguments.length, r = Array(e), n = 0; n < e; n++) r[n] = arguments[n];
            return R.call(this, t, ...r);
          }),
          (c.level = n.level || this.level),
          t.onChild(c),
          c
        );
      }
      return (
        (f = e.customLevels || {}),
        (O.levels = {
          values: Object.assign({}, l.levels.values, f),
          labels: Object.assign(
            {},
            l.levels.labels,
            ((g = {}),
            Object.keys((n = f)).forEach(function (e) {
              g[n[e]] = e;
            }),
            g),
          ),
        }),
        (O.level = k),
        (O.setMaxListeners =
          O.getMaxListeners =
          O.emit =
          O.addListener =
          O.on =
          O.prependListener =
          O.once =
          O.prependOnceListener =
          O.removeListener =
          O.removeAllListeners =
          O.listeners =
          O.listenerCount =
          O.eventNames =
          O.write =
          O.flush =
            _),
        (O.serializers = C),
        (O._serialize = E),
        (O._stdErrSerialize = w),
        (O.child = function () {
          for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
          return R.call(this, A, ...t);
        }),
        m && (O._logEvent = d()),
        O
      );
    }
    function p(e, t, r, c) {
      var u, l, p, f, g, m, v;
      if (
        (Object.defineProperty(e, c, {
          value: o(e.level, r) > o(c, r) ? _ : r[s][c],
          writable: !0,
          enumerable: !0,
          configurable: !0,
        }),
        e[c] === _)
      ) {
        if (!t.transmit) return;
        let n = o(t.transmit.level || e.level, r);
        if (o(c, r) < n) return;
      }
      e[c] =
        ((u = e),
        (l = t),
        (p = r),
        (f = c),
        (g = u[s][f]),
        function () {
          let e = l.timestamp(),
            t = Array(arguments.length),
            r = Object.getPrototypeOf && Object.getPrototypeOf(this) === i ? i : this;
          for (var s = 0; s < t.length; s++) t[s] = arguments[s];
          var a = !1;
          if (
            (l.serialize && (h(t, this._serialize, this.serializers, this._stdErrSerialize), (a = !0)),
            l.asObject || l.formatters
              ? g.call(
                  r,
                  (function (e, t, r, i, o) {
                    let { level: s, log: a = (e) => e } = o.formatters || {},
                      c = r.slice(),
                      u = c[0],
                      l = {};
                    (i && (l.time = i),
                      s ? Object.assign(l, s(t, e.levels.values[t])) : (l.level = e.levels.values[t]));
                    let p = (0 | e._childLevel) + 1;
                    if ((p < 1 && (p = 1), null !== u && "object" == typeof u)) {
                      for (; p-- && "object" == typeof c[0];) Object.assign(l, c.shift());
                      u = c.length ? n(c.shift(), c) : void 0;
                    } else "string" == typeof u && (u = n(c.shift(), c));
                    return (void 0 !== u && (l[o.messageKey] = u), a(l));
                  })(this, f, t, e, l),
                )
              : g.apply(r, t),
            l.transmit)
          ) {
            let r = l.transmit.level || u._level,
              n = o(r, p),
              i = o(f, p);
            if (i < n) return;
            !(function (e, t, r) {
              let n = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
                i = t.send,
                o = t.ts,
                s = t.methodLevel,
                a = t.methodValue,
                c = t.val,
                u = e._logEvent.bindings;
              (n ||
                h(
                  r,
                  e._serialize || Object.keys(e.serializers),
                  e.serializers,
                  void 0 === e._stdErrSerialize || e._stdErrSerialize,
                ),
                (e._logEvent.ts = o),
                (e._logEvent.messages = r.filter(function (e) {
                  return -1 === u.indexOf(e);
                })),
                (e._logEvent.level.label = s),
                (e._logEvent.level.value = a),
                i(s, e._logEvent, c),
                (e._logEvent = d(u)));
            })(
              this,
              {
                ts: e,
                methodLevel: f,
                methodValue: i,
                transmitLevel: r,
                transmitValue: p.levels.values[l.transmit.level || u._level],
                send: l.transmit.send,
                val: o(u._level, p),
              },
              t,
              a,
            );
          }
        });
      let y = (function (e) {
        let t = [];
        e.bindings && t.push(e.bindings);
        let r = e[a];
        for (; r.parent;) (r = r.parent).logger.bindings && t.push(r.logger.bindings);
        return t.reverse();
      })(e);
      0 !== y.length &&
        (e[c] =
          ((m = y),
          (v = e[c]),
          function () {
            return v.apply(this, [...m, ...arguments]);
          }));
    }
    function h(e, t, r, n) {
      for (let i in e)
        if (n && e[i] instanceof Error) e[i] = l.stdSerializers.err(e[i]);
        else if ("object" == typeof e[i] && !Array.isArray(e[i]) && t)
          for (let n in e[i]) t.indexOf(n) > -1 && n in r && (e[i][n] = r[n](e[i][n]));
    }
    function d(e) {
      return { ts: 0, messages: [], bindings: e || [], level: { label: "", value: 0 } };
    }
    function f(e) {
      let t = { type: e.constructor.name, msg: e.message, stack: e.stack };
      for (let r in e) void 0 === t[r] && (t[r] = e[r]);
      return t;
    }
    function g() {
      return {};
    }
    function m(e) {
      return e;
    }
    function _() {}
    function v() {
      return !1;
    }
    function y() {
      return Date.now();
    }
    ((l.levels = {
      values: { fatal: 60, error: 50, warn: 40, info: 30, debug: 20, trace: 10 },
      labels: { 10: "trace", 20: "debug", 30: "info", 40: "warn", 50: "error", 60: "fatal" },
    }),
      (l.stdSerializers = {
        mapHttpRequest: g,
        mapHttpResponse: g,
        wrapRequestSerializer: m,
        wrapResponseSerializer: m,
        wrapErrorSerializer: m,
        req: g,
        res: g,
        err: f,
        errWithCause: f,
      }),
      (l.stdTimeFunctions = Object.assign(
        {},
        {
          nullTime: v,
          epochTime: y,
          unixTime: function () {
            return Math.round(Date.now() / 1e3);
          },
          isoTime: function () {
            return new Date(Date.now()).toISOString();
          },
        },
      )),
      (t.exports.default = l),
      (t.exports.pino = l));
  },
  84297,
  (e, t, r) => {
    t.exports = {
      id: "google-analytics",
      description: "Install a Google Analytics tag on your website",
      website: "https://analytics.google.com/analytics/web/",
      scripts: [
        {
          url: "https://www.googletagmanager.com/gtag/js",
          params: ["id"],
          strategy: "worker",
          location: "head",
          action: "append",
        },
        {
          code: "window.dataLayer=window.dataLayer||[];window.gtag=function gtag(){window.dataLayer.push(arguments);};gtag('js',new Date());gtag('config','${args.id}')",
          strategy: "worker",
          location: "head",
          action: "append",
        },
      ],
    };
  },
  892135,
  (e, t, r) => {
    "use strict";
    function n(e, t) {
      let r = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
      return t
        ? Object.keys(e)
            .filter((e) => (r ? !t.includes(e) : t.includes(e)))
            .reduce((t, r) => ((t[r] = e[r]), t), {})
        : {};
    }
    function i(e, t, r, n) {
      let i = n && Object.keys(n).length > 0 ? new URL(Object.values(n)[0], e) : new URL(e);
      return (
        t &&
          r &&
          t.forEach((e) => {
            r[e] && i.searchParams.set(e, r[e]);
          }),
        i.toString()
      );
    }
    function o(e, t, r, n, o) {
      var s;
      if (!t) return `<${e}></${e}>`;
      let a = (null == (s = t.src) ? void 0 : s.url)
          ? Object.assign(Object.assign({}, t), { src: i(t.src.url, t.src.params, n, o) })
          : t,
        c = Object.keys(Object.assign(Object.assign({}, a), r)).reduce((e, t) => {
          let n = null == r ? void 0 : r[t],
            i = a[t],
            o = null != n ? n : i,
            s = !0 === o ? t : `${t}="${o}"`;
          return o ? e + ` ${s}` : e;
        }, "");
      return `<${e}${c}></${e}>`;
    }
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      (r.formatData = r.createHtml = r.formatUrl = void 0),
      (r.formatUrl = i),
      (r.createHtml = o),
      (r.formatData = function (e, t) {
        var r, s, a, c, u;
        let l = n(
            t,
            null == (r = e.scripts)
              ? void 0
              : r.reduce((e, t) => [...e, ...(Array.isArray(t.params) ? t.params : [])], []),
          ),
          p = n(t, null == (a = null == (s = e.html) ? void 0 : s.attributes.src) ? void 0 : a.params),
          h = n(t, [null == (u = null == (c = e.html) ? void 0 : c.attributes.src) ? void 0 : u.slugParam]),
          d = n(t, [...Object.keys(l), ...Object.keys(p), ...Object.keys(h)], !0);
        return Object.assign(Object.assign({}, e), {
          html: e.html ? o(e.html.element, e.html.attributes, d, p, h) : null,
          scripts: e.scripts
            ? e.scripts.map((e) => Object.assign(Object.assign({}, e), { url: i(e.url, e.params, l) }))
            : null,
        });
      }));
  },
  344602,
  (e, t, r) => {
    "use strict";
    var n =
        (e.e && e.e.__rest) ||
        function (e, t) {
          var r = {};
          for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && 0 > t.indexOf(n) && (r[n] = e[n]);
          if (null != e && "function" == typeof Object.getOwnPropertySymbols)
            for (var i = 0, n = Object.getOwnPropertySymbols(e); i < n.length; i++)
              0 > t.indexOf(n[i]) &&
                Object.prototype.propertyIsEnumerable.call(e, n[i]) &&
                (r[n[i]] = e[n[i]]);
          return r;
        },
      i =
        (e.e && e.e.__importDefault) ||
        function (e) {
          return e && e.__esModule ? e : { default: e };
        };
    (Object.defineProperty(r, "__esModule", { value: !0 }), (r.GoogleAnalytics = void 0));
    let o = i(e.r(84297)),
      s = e.r(892135);
    r.GoogleAnalytics = (e) => {
      var t = n(e, []);
      return (0, s.formatData)(o.default, t);
    };
  },
  560262,
  (e, t, r) => {
    t.exports = {
      id: "google-maps-embed",
      description: "Embed a Google Maps embed on your webpage",
      website: "https://developers.google.com/maps/documentation/embed/get-started",
      html: {
        element: "iframe",
        attributes: {
          loading: "lazy",
          src: {
            url: "https://www.google.com/maps/embed/v1/place",
            slugParam: "mode",
            params: ["key", "q", "center", "zoom", "maptype", "language", "region"],
          },
          referrerpolicy: "no-referrer-when-downgrade",
          frameborder: "0",
          style: "border:0",
          allowfullscreen: !0,
          width: null,
          height: null,
        },
      },
    };
  },
  277813,
  (e, t, r) => {
    "use strict";
    var n =
        (e.e && e.e.__rest) ||
        function (e, t) {
          var r = {};
          for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && 0 > t.indexOf(n) && (r[n] = e[n]);
          if (null != e && "function" == typeof Object.getOwnPropertySymbols)
            for (var i = 0, n = Object.getOwnPropertySymbols(e); i < n.length; i++)
              0 > t.indexOf(n[i]) &&
                Object.prototype.propertyIsEnumerable.call(e, n[i]) &&
                (r[n[i]] = e[n[i]]);
          return r;
        },
      i =
        (e.e && e.e.__importDefault) ||
        function (e) {
          return e && e.__esModule ? e : { default: e };
        };
    (Object.defineProperty(r, "__esModule", { value: !0 }), (r.GoogleMapsEmbed = void 0));
    let o = i(e.r(560262)),
      s = e.r(892135);
    r.GoogleMapsEmbed = (e) => {
      var t = n(e, []);
      return (0, s.formatData)(o.default, t);
    };
  },
  640674,
  (e, t, r) => {
    t.exports = {
      id: "youtube-embed",
      description: "Embed a YouTube embed on your webpage.",
      website: "https://github.com/paulirish/lite-youtube-embed",
      html: { element: "lite-youtube", attributes: { videoid: null, playlabel: null } },
      stylesheets: ["https://cdn.jsdelivr.net/gh/paulirish/lite-youtube-embed@master/src/lite-yt-embed.css"],
      scripts: [
        {
          url: "https://cdn.jsdelivr.net/gh/paulirish/lite-youtube-embed@master/src/lite-yt-embed.js",
          strategy: "idle",
          location: "head",
          action: "append",
        },
      ],
    };
  },
  515465,
  (e, t, r) => {
    "use strict";
    var n =
        (e.e && e.e.__rest) ||
        function (e, t) {
          var r = {};
          for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && 0 > t.indexOf(n) && (r[n] = e[n]);
          if (null != e && "function" == typeof Object.getOwnPropertySymbols)
            for (var i = 0, n = Object.getOwnPropertySymbols(e); i < n.length; i++)
              0 > t.indexOf(n[i]) &&
                Object.prototype.propertyIsEnumerable.call(e, n[i]) &&
                (r[n[i]] = e[n[i]]);
          return r;
        },
      i =
        (e.e && e.e.__importDefault) ||
        function (e) {
          return e && e.__esModule ? e : { default: e };
        };
    (Object.defineProperty(r, "__esModule", { value: !0 }), (r.YouTubeEmbed = void 0));
    let o = i(e.r(640674)),
      s = e.r(892135);
    r.YouTubeEmbed = (e) => {
      var t = n(e, []);
      return (0, s.formatData)(o.default, t);
    };
  },
  981498,
  (e, t, r) => {
    "use strict";
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      (r.YouTubeEmbed = r.GoogleMapsEmbed = r.GoogleAnalytics = void 0));
    var n = e.r(344602);
    Object.defineProperty(r, "GoogleAnalytics", {
      enumerable: !0,
      get: function () {
        return n.GoogleAnalytics;
      },
    });
    var i = e.r(277813);
    Object.defineProperty(r, "GoogleMapsEmbed", {
      enumerable: !0,
      get: function () {
        return i.GoogleMapsEmbed;
      },
    });
    var o = e.r(515465);
    Object.defineProperty(r, "YouTubeEmbed", {
      enumerable: !0,
      get: function () {
        return o.YouTubeEmbed;
      },
    });
  },
  523173,
  (e) => {
    "use strict";
    var t,
      r =
        (((t = {}).MAIN_PAGE_VIEW = "MainPageViewed"),
        (t.FUNNEL_START_VIEW = "FunnelStartView"),
        (t.PAGE_CLICKED = "PageClicked"),
        (t.EMAIL_SUBMITTED = "EmailSubmitted"),
        (t.PAYWALL_VIEWED = "PaywallViewed"),
        (t.PAYWALL_PLAN_SELECTED = "PaywallPlanSelected"),
        (t.PAYMENT_FORM_VIEWED = "PaymentFormViewed"),
        (t.PURCHASE_ATTEMPT = "PurchaseAttempt"),
        (t.PURCHASE_SUCCESS = "PurchaseSuccess"),
        (t.SUBSCRIPTION_PURCHASED_SUCCESS = "SubscriptionPurchased"),
        (t.PROMO_PURCHASE_SUCCESS = "PromoPurchase"),
        (t.SUBSCRIPTION_CREATE_ERROR = "SubscriptionCreateError"),
        (t.SUBSCRIPTION_IN_BILLING_CREATED = "SubscriptionInBillingCreated"),
        (t.EMAIL_VIEWED = "EmailPageViewed"),
        (t.VALIDATION_EMAIL_VIEWED = "EmailValidationPageViewed"),
        (t.ANALYZING_VIEWED = "AnalyzingPageViewed"),
        (t.REPORT_VIEWED = "DetailedReportPageView"),
        (t.REPORT_VIEWED_YOUR_RESULTS = "YourResultsPageView"),
        (t.SECOND_PURCHASE_ATTEMPT = "SecondPurchaseAttempt"),
        (t.SECOND_PURCHASE_SUCCESS = "SecondPurchaseSuccess"),
        (t.EMAIL_VALIDATION_RESULT = "EmailValidationClicked"),
        (t.REPORT_BUTTON_CLICKED = "ReportButtonClicked"),
        (t.REPORT_SHARE = "ReportShare"),
        (t.REPORT_DOWNLOAD = "ReportDownload"),
        (t.SOCIALS_CHECK = "SocialsCheck"),
        (t.CONGRATS_VIEWED = "CongratsPageViewed"),
        (t.NAME_VIEWED = "NamePageViewed"),
        (t.MAIN_LOGIN_CLICKED = "MainLoginClicked"),
        (t.GOOGLE_LOGIN_CLICKED = "GoogleLoginClicked"),
        (t.APPLE_LOGIN_CLICKED = "AppleLoginClicked"),
        (t.MICROSOFT_LOGIN_CLICKED = "MicrosoftLoginClicked"),
        (t.YANDEX_LOGIN_CLICKED = "YandexLoginClicked"),
        (t.YAHOO_LOGIN_CLICKED = "YahooLoginClicked"),
        (t.LOGGED_IN_VIA_LOGIN_LINK = "LoggedInViaLoginLink"),
        (t.LOGGED_IN_VIA_GOOGLE_AUTH = "LoggedInViaGoogleAuth"),
        (t.LOBBY_PAGE_VIEWED = "LobbyPageView"),
        (t.PAGE_VIEWED = "PageViewed"),
        (t.EMAIL_SUBMIT_ATTEMPT = "EmailSubmitAttempt"),
        (t.EMAIL_SOCIAL_SIGNUP_CLICKED = "EmailSocialSignupClicked"),
        (t.EMAIL_SOCIAL_SIGNUP_FAILED = "EmailSocialSignupFailed"),
        (t.CLIENT_SESSION_CREATE_ERROR = "ClientSessionCreateError"),
        (t.EMAIL_SUBMIT_ERROR = "EmailSubmitError"),
        (t.PURCHASE_ERROR = "PurchaseError"),
        (t.SECOND_PURCHASE_ERROR = "SecondPurchaseError"),
        (t.PAYMENT_INFO_UPDATED = "PaymentInfoUpdated"),
        (t.PAYMENT_INFO_UPDATER_VIEWED = "PaymentInfoUpdaterViewed"),
        (t.EMAIL_EDIT_CLICKED = "EmailValidationEditClicked"),
        (t.CHECKOUT_SUBSCRIPTION_STATUS = "CheckoutSubscriptionStatus"),
        (t.PAYMENT_3DS_PAYMENT_PROCESSING = "payment_3ds_payment_processing"),
        (t.HELP_CENTER_VIEWED = "HelpCenterViewed"),
        (t.TERMS_LEGAL_EMAIL_CLICKED = "TermsLegalEmailClicked"),
        (t.CANCEL_FLOW_HELP_CENTER_VIEWED = "CancelFlowHelpCenterViewed"),
        (t.CANCEL_FLOW_CONTACT_SUPPORT_VIEWED = "CancelFlowContactSupportViewed"),
        (t.CANCEL_FLOW_CANCELLATION_LINK_CLICKED = "CancelFlowCancellationLinkClicked"),
        (t.CANCEL_FLOW_CANCELLATION_PORTAL_CLICKED = "CancelFlowCancellationPortalClicked"),
        (t.CANCEL_FLOW_HOW_TO_CANCEL_BUTTON_CLICKED = "CancelFlowHowToCancelButtonClicked"),
        (t.CANCEL_FLOW_CONTACT_SUPPORT_BUTTON_CLICKED = "CancelFlowContactSupportButtonClicked"),
        (t.CANCEL_FLOW_ENTER_EMAIL_PAGE_VIEWED = "CancelFlowEnterEmailViewed"),
        (t.CANCEL_FLOW_EMAIL_VERIFICATION_PAGE_VIEWED = "CancelFlowEmailVerificationViewed"),
        (t.CANCEL_FLOW_FEEDBACK_LINK_CLICKED = "CancelFlowCancellationCompleteFeedbackClicked"),
        (t.CANCEL_FLOW_FEEDBACK_LINK_CLICKED_FOR_CUSTOMER_IO = "cancel_flow_feedback_link_clicked"),
        (t.CANCEL_FLOW_EMAIL_CONTINUE_CLICKED = "CancelFlowEmailContinueClicked"),
        (t.CANCEL_FLOW_VERIFICATION_SUBMIT_CLICKED = "CancelFlowVerificationSubmitClicked"),
        (t.CANCEL_FLOW_RESEND_CODE_CLICKED = "CancelFlowResendCodeClicked"),
        (t.CANCEL_FLOW_ARE_YOU_SURE_VIEWED = "CancelFlowAreYouSureViewed"),
        (t.CANCEL_FLOW_ARE_YOU_SURE_CANCEL_CLICKED = "CancelFlowAreYouSureCancelClicked"),
        (t.CANCEL_FLOW_ARE_YOU_SURE_RETURN_CLICKED = "CancelFlowAreYouSureReturnClicked"),
        (t.CANCEL_FLOW_CANCELLATION_COMPLETE_VIEWED = "CancelFlowCancellationCompleteViewed"),
        (t.CANCEL_FLOW_CANCELLATION_COMPLETE_VIEWED_FOR_CUSTOMER_IO =
          "cancel_flow_cancellation_complete_viewed"),
        (t.CANCEL_FLOW_CANCELLATION_COMPLETE_RETURN_CLICKED = "CancelFlowCancellationCompleteReturnClicked"),
        (t.CANCEL_FLOW_REDIRECT_TO_AUTH = "CancelFlowRedirectToAuth"),
        (t.CANCEL_FLOW_UPGRADE_VIEWED = "CancelFlowUpgradeViewed"),
        (t.CANCEL_FLOW_UPGRADE_KEEP_CLICKED = "CancelFlowUpgradeKeepClicked"),
        (t.CANCEL_FLOW_UPGRADE_CANCEL_CLICKED = "CancelFlowUpgradeCancelClicked"),
        (t.CANCEL_FLOW_PLAN_CHANGE_VIEWED = "CancelFlowPlanChangeViewed"),
        (t.CANCEL_FLOW_PLAN_CHANGE_CONFIRM_CLICKED = "CancelFlowPlanChangeConfirmClicked"),
        (t.CANCEL_FLOW_PLAN_CHANGE_BACK_CLICKED = "CancelFlowPlanChangeBackClicked"),
        (t.CANCEL_FLOW_PLAN_UPDATED_VIEWED = "CancelFlowPlanUpdatedViewed"),
        (t.SUBSCRIPTION_DOWNGRADED = "SubscriptionDowngraded"),
        (t.CANCEL_FLOW_RETURNING_CANCEL_CLICKED = "cancel_flow_returning_cancel_clicked"),
        (t.DELETE_ACCOUNT_ENTER_EMAIL_PAGE_VIEWED = "DeleteAccountEnterEmailViewed"),
        (t.DELETE_ACCOUNT_EMAIL_CONTINUE_CLICKED = "DeleteAccountEmailContinueClicked"),
        (t.DELETE_ACCOUNT_EMAIL_VERIFICATION_PAGE_VIEWED = "DeleteAccountEmailVerificationViewed"),
        (t.DELETE_ACCOUNT_VERIFICATION_SUBMIT_CLICKED = "DeleteAccountVerificationSubmitClicked"),
        (t.DELETE_ACCOUNT_RESEND_CODE_CLICKED = "DeleteAccountResendCodeClicked"),
        (t.DELETE_ACCOUNT_ARE_YOU_SURE_VIEWED = "DeleteAccountAreYouSureViewed"),
        (t.DELETE_ACCOUNT_ARE_YOU_SURE_DELETE_CLICKED = "DeleteAccountAreYouSureDeleteClicked"),
        (t.DELETE_ACCOUNT_ARE_YOU_SURE_RETURN_CLICKED = "DeleteAccountAreYouSureReturnClicked"),
        (t.DELETE_ACCOUNT_COMPLETE_VIEWED = "DeleteAccountCompleteViewed"),
        (t.DELETE_ACCOUNT_COMPLETE_RETURN_CLICKED = "DeleteAccountCompleteReturnClicked"),
        (t.DELETE_ACCOUNT_REDIRECT_TO_AUTH = "DeleteAccountRedirectToAuth"),
        (t.PROFILE_TODAY_PAGE_VIEWED = "TodayPageViewed"),
        (t.PROFILE_HEADER_XP_PROGRESS_MODAL_VIEWED = "profile_header_xp_progress_modal_viewed"),
        (t.PROFILE_COURSE_START_WATCH_CLICKED = "profile_course_start_watch_clicked"),
        (t.CONGRATULATIONS_PAGE_SEE_REPORT_CLICKED = "congratulations_page_see_report_clicked"),
        (t.PROFILE_REPORT_STEP_VIEWED = "profile_report_step_viewed"),
        (t.PRODUCT_LOBBY_CLICKED = "ProductLobbyClicked"),
        (t.PRODUCT_GAMES_CLICKED = "ProductGamesClicked"),
        (t.PRODUCT_COURSES_CLICKED = "ProductCoursesClicked"),
        (t.PRODUCT_TESTS_CLICKED = "ProductTestsClicked"),
        (t.PRODUCT_LANGUAGE_CLICKED = "ProductLanguageClicked"),
        (t.PRODUCT_PROFILE_CLICKED = "ProductProfileClicked"),
        (t.PRODUCT_PROFILE_MY_TEST_RESULTS_CLICKED = "ProductProfileMyTestResultsClicked"),
        (t.PRODUCT_PROFILE_SETTINGS_CLICKED = "ProductProfileSettingsClicked"),
        (t.PRODUCT_PROFILE_SUPPORT_CLICKED = "ProductProfileSupportClicked"),
        (t.PRODUCT_PROFILE_MY_SUBSCRIPTION_CLICKED = "ProductProfileMySubscriptionClicked"),
        (t.PRODUCT_PROFILE_LOG_OUT_CLICKED = "ProductProfileLogOutClicked"),
        (t.PROFILE_SUBS_INFO_MODAL_VIEWED = "ProfileSubsInfoModalViewed"),
        (t.PROFILE_SUBS_INFO_MODAL_CANCEL_SUBSCRIPTION_CLICKED =
          "ProfileSubsInfoModalCancelSubscriptionClicked"),
        (t.PROFILE_SUBS_INFO_MODAL_CLOSED = "ProfileSubsInfoModalClosed"),
        (t.PRODUCT_REPORT_DOWNLOAD_CLICKED = "ProductReportDownloadClicked"),
        (t.PRODUCT_REPORT_DOWNLOAD_CERTIFICATE_CLICKED = "ProductReportDownloadCertificateClicked"),
        (t.PRODUCT_REPORT_DOWNLOAD_FULL_REPORT_CLICKED = "ProductReportDownloadFullReportClicked"),
        (t.PRODUCT_REPORT_INVITE_FRIEND_CLICKED = "ProductReportInviteFriendClicked"),
        (t.PRODUCT_REPORT_ADHD_CLICKED = "ProductReportADHDClicked"),
        (t.PRODUCT_REPORT_PERSONALITY_CLICKED = "ProductReportPersonalityClicked"),
        (t.PRODUCT_REPORT_LOVE_STYLE_CLICKED = "ProductReportLoveStyleClicked"),
        (t.PRODUCT_REPORT_CAREER_CLICKED = "ProductReportCareerClicked"),
        (t.PRODUCT_REPORT_EMOTIONAL_CLICKED = "ProductReportEmotionalClicked"),
        (t.GAMIFICATION_CONTINUE_MY_JOURNEY_CLICKED = "ContinueMyJourneyClicked"),
        (t.GAMIFICATION_BANNER_EXPLORE_BUTTON_CLICKED = "BannerExploreButtonClicked"),
        (t.GAMIFICATION_ONBOARDING_MODAL_VIEWED = "GamificationOnboardingModalViewed"),
        (t.GAMIFICATION_ONBOARDING_MODAL_CLOSED = "GamificationOnboardingModalClosed"),
        (t.GAMIFICATION_ONBOARDING_START_TRAINING_CLICKED = "GamificationOnboardingStartTrainingClicked"),
        (t.GAMIFICATION_DAILY_STREAK_INFO_CLICKED = "DailyStreakInfoClicked"),
        (t.GAMIFICATION_TOURNAMENT_INFO_CLICKED = "TournamentInfoClicked"),
        (t.GAMIFICATION_GAME_START_CLICKED = "GameStartClicked"),
        (t.GAMIFICATION_GAME_STARTED_CONTINUE_CLICKED = "GameStartedContinueClicked"),
        (t.GAMIFICATION_GAME_LEVEL_CHECK_CLICKED = "GameQuestionCheckClicked"),
        (t.GAMIFICATION_GAME_LEVEL_WHY_CLICKED = "GameQuestionWhyClicked"),
        (t.GAMIFICATION_GAME_LEVEL_CONTINUE_CLICKED = "GameQuestionContinueClicked"),
        (t.GAMIFICATION_GAME_RESULT_POPUP_VIEWED = "GameResultPopupViewed"),
        (t.GAMIFICATION_GAME_RESULT_CONTINUE_CLICKED = "GameResultContinueClicked"),
        (t.ELEMENT_CLICKED = "ElementClicked"),
        (t.TEST_ANSWER_CLICKED = "TestAnswerClicked"),
        (t.QUIZ_ANSWER_CLICKED = "QuizAnswerClicked"),
        (t.QUIZ_CONTINUE = "QuizContinue"),
        (t.FUNNEL_ANSWER_CLICKED = "funnelAnswerClicked"),
        (t.START_TEST = "StartTest"),
        (t.REPORT_UPDATED_GIVEAWAY_BANNER_PARTICIPATE_CLICKED = "ParticipateClicked"),
        (t.REPORT_UPDATED_GIVEAWAY_BANNER_PARTICIPATE_VIEWED = "ParticipateButtonViewed"),
        (t.REPORT_FEEDBACK_MODAL_VIEWED = "ReportFeedbackModalViewed"),
        (t.REPORT_FEEDBACK_MODAL_LIKE_NO_CLICKED = "ReportFeedbackModalLikeNoClicked"),
        (t.REPORT_FEEDBACK_MODAL_LIKE_YES_CLICKED = "ReportFeedbackModalLikeYesClicked"),
        (t.REPORT_FEEDBACK_MODAL_LEAVE_REVIEW_CLICKED = "ReportFeedbackModalLeaveReviewClicked"),
        (t.REPORT_FEEDBACK_MODAL_MAYBE_LATER_CLICKED = "ReportFeedbackModalMaybeLaterClicked"),
        (t.REPORT_FEEDBACK_MODAL_CLOSED = "ReportFeedbackModalClosed"),
        (t.IN_APP_BROWSER_MODAL_VIEWED = "InAppBrowserModalViewed"),
        (t.RETAKEN_PAY_SCRIPT_CLICKED = "RetakenPayScriptClicked"),
        (t.CONFIRM_PURCHASE_CLICKED = "ConfirmPurchaseClicked"),
        (t.IQ_SCORE_UPDATED_VIEWED = "IQScoreUpdatedViewed"),
        (t.VIEW_UPDATED_REPORT_CLICKED = "ViewUpdatedReportClicked"),
        (t.SCIENCE_BASED_PAGE_VIEWED = "ScienceBasedPageViewed"),
        (t.SCIENCE_BASED_PAGE_CLICKED = "ScienceBasedPageClicked"),
        (t.LAST_QUIZ_QUESTION_PAGE_OPENED = "LastQuizQuestionPageOpened"),
        (t.TRIVIA_OPEN_CLICKED = "TriviaOpenClicked"),
        (t.TRIVIA_START_PAGE_VIEWED = "TriviaStartPageViewed"),
        (t.START_TRIVIA_CLICK = "TriviaStartClicked"),
        (t.TRIVIA_ADD_ON_MODAL_VIEWED = "TriviaAddOnModalViewed"),
        (t.TRIVIA_ADD_ON_BUY_CLICKED = "TriviaAddOnBuyClicked"),
        (t.TRIVIA_ADD_ON_SKIP_CLICKED = "TriviaAddOnSkipClicked"),
        (t.TRIVIA_QUESTION_CLICKED = "TriviaQuestionClicked"),
        (t.TRIVIA_EXERCISE_COMPLETE_VIEWED = "ExerciseCompleteViewed"),
        (t.TRIVIA_TOP_BANNER_CLICKED = "TriviaRefillBannerClicked"),
        (t.TRIVIA_POWER_UP_CLICKED = "PowerUpClicked"),
        (t.TRIVIA_POWER_UP_USED = "PowerUpUsed"),
        (t.TRIVIA_SECTION_VIEWED = "TriviaSectionViewed"),
        (t.TRIVIA_REPORT_BANNER_CLICKED = "TriviaReportBannerClicked"),
        (t.TRIVIA_TEST_LEAVE_AFTER_COMPLETION = "TriviaTestLeaveAfterCompletion"),
        (t.TRIVIA_TEST_CLOSE_BUTTON_CLICKED = "TriviaTestCloseButtonClicked"),
        (t.GLOBAL_ERROR_CAUGHT = "GlobalErrorCaught"),
        (t.NAME_AT_CERTIFICATE_ENTER_CLICKED = "NameAtCertificateEnterClicked"),
        (t.CERTIFICATE_VERIFY_PAGE_VIEWED = "CertificateVerifyPageViewed"),
        (t.CERTIFICATE_VERIFY_START_TEST_CLICKED = "CertificateVerifyStartTestClicked"),
        (t.CERTIFICATE_VERIFY_REPORT_PROBLEM_CLICKED = "CertificateVerifyReportProblemClicked"),
        (t.CERTIFICATE_VERIFY_TIME_ZONE_HINT_CLICKED = "CertificateVerifyTimeZoneHintClicked"),
        (t.PRINTED_CERTIFICATE_OFFER_PAGE_VIEWED = "PrintCertificateOfferPageViewed"),
        (t.PRINTED_CERTIFICATE_OFFER_BUY_CLICKED = "PrintCertificateOfferBuyClicked"),
        (t.PRINTED_CERTIFICATE_OFFER_SKIP_CLICKED = "PrintCertificateOfferSkipClicked"),
        (t.PRINTED_CERTIFICATE_ADDRESS_SUBMIT_CLICKED = "PrintCertificateAddressSubmitClicked"),
        (t.PRINTED_CERTIFICATE_CONFIRM_PURCHASE_CLICKED = "PrintCertificateConfirmPurchaseClicked"),
        (t.PRINTED_CERTIFICATE_CANCEL_PURCHASE_CLICKED = "PrintCertificateCancelPurchaseClicked"),
        (t.PRINTED_CERTIFICATE_ADDRESS_PAGE_VIEWED = "PrintCertificateAddressViewed"),
        (t.PRINTED_CERTIFICATE_PAY_MODAL_VIEWED = "PrintCertificatePayModalViewed"),
        (t.REPORT_GENERATION_SECTION_VIEWED = "ReportGenerationSectionViewed"),
        (t.PRIORITY_REPORT_BUY_CLICKED = "PriorityReportBuyClicked"),
        (t.REPORT_GENERATION_FAST_TRACK_MODAL_VIEWED = "ReportGenerationFastTrackModalViewed"),
        (t.PRIORITY_REPORT_CONFIRM_CLICKED = "PriorityReportConfirmClicked"),
        (t.PRIORITY_REPORT_CANCEL_CLICKED = "PriorityReportCancelClicked"),
        (t.REPORT_GENERATION_READY_VIEWED = "ReportGenerationReadyViewed"),
        (t.REPORT_GENERATION_CANCEL_REMINDER_VIEWED = "ReportGenerationCancelReminderViewed"),
        (t.REPORT_GENERATION_CANCEL_REMINDER_CANCEL_CLICKED = "ReportGenerationCancelReminderCancelClicked"),
        (t.REPORT_GENERATION_CANCEL_REMINDER_KEEP_CLICKED = "ReportGenerationCancelReminderKeepClicked"),
        (t.FIRST_HOUR_INTERRUPTION_VIEWED = "FirstHourInterruptionViewed"),
        (t.FIRST_HOUR_INTERRUPTION_CONTACT_SUPPORT_CLICKED = "FirstHourInterruptionContactSupportClicked"),
        (t.POST_PAYWALL_INTERSTITIAL_SCREEN_VIEWED = "PostPaywallInterstitialScreenViewed"),
        (t.POST_PAYWALL_INTERSTITIAL_SCREEN_CLICKED = "PostPaywallInterstitialScreenClicked"),
        (t.FEEDBACK_WIDGET_ICON_CLICKED = "FeedbackWidgetIconClicked"),
        (t.FEEDBACK_WIDGET_BUTTON_CLICKED = "FeedbackWidgetButtonClicked"),
        (t.SURVEY_START_VIEWED = "StartPollViewed"),
        (t.SURVEY_FINISH_CLICKED = "FinishPollClicked"),
        (t.SURVEY_ANSWER_CLICKED = "AnswerPollClicked"),
        (t.SURVEY_COMPLETE_VIEWED = "FinishPollViewed"),
        (t.BRAIN_TRAIN_UPSELL_VIEWED = "BrainTrainUpsellViewed"),
        (t.BRAIN_TRAIN_UPSELL_SKIP_CLICKED = "BrainTrainUpsellSkipClicked"),
        (t.BRAIN_TRAIN_UPSELL_BUY_CLICKED = "BrainTrainUpsellBuyClicked"),
        (t.BRAIN_TRAIN_UPSELL_CONFIRMATION_VIEWED = "BrainTrainUpsellConfirmationViewed"),
        (t.BRAIN_TRAIN_UPSELL_CONFIRMATION_CLICKED = "BrainTrainUpsellConfirmationClicked"),
        (t.PRODUCT_REPORT_DOWNLOAD_FULL_REPORT_ERROR = "ProductReportDownloadFullReportError"),
        (t.PRODUCT_REPORT_DOWNLOAD_CERTIFICATE_ERROR = "ProductReportDownloadCertificateError"),
        (t.TRIAL_DECISION_PAGE_VIEWED = "TrialDecisionPageViewed"),
        (t.TRIAL_DECISION_KEEP_CLICKED = "TrialDecisionKeepClicked"),
        (t.TRIAL_DECISION_SKIP_CLICKED = "TrialDecisionSkipClicked"),
        (t.TRIAL_DECISION_CONFIRMATION_MODAL_VIEWED = "TrialDecisionConfirmationModalViewed"),
        (t.TRIAL_DECISION_CONFIRMATION_CLICKED = "TrialDecisionConfirmationClicked"),
        (t.FEEDBACK_MODAL_VIEWED = "FeedbackModalViewed"),
        (t.FEEDBACK_MODAL_CLICKED = "FeedbackModalClicked"),
        (t.HELP_US_FEEDBACK_MODAL_VIEWED = "HelpUsFeedbackModalViewed"),
        (t.HELP_US_FEEDBACK_MODAL_SUBMIT_CLICKED = "HelpUsFeedbackModalSubmitClicked"),
        (t.HELP_US_FEEDBACK_MODAL_SKIP_CLICKED = "HelpUsFeedbackModalSkipClicked"),
        (t.TRUST_PILOT_FEEDBACK_MODAL_VIEWED = "TrustPilotFeedbackModalViewed"),
        (t.TRUST_PILOT_FEEDBACK_MODAL_SUBMIT_CLICKED = "TrustPilotFeedbackModalSubmitClicked"),
        (t.TRUST_PILOT_FEEDBACK_MODAL_SKIP_CLICKED = "TrustPilotFeedbackModalSkipClicked"),
        (t.PROFILE_SETTINGS_MANAGE_SUBS_CLICKED = "ProfileSettingsManageSubsClicked"),
        (t.PROFILE_SETTINGS_EMAIL_CHANGE_REQUESTED = "ProfileSettingsEmailChangeRequested"),
        (t.PROFILE_SETTINGS_EMAIL_VERIFICATION_VIEWED = "ProfileSettingsEmailVerificationViewed"),
        (t.PROFILE_SETTINGS_EMAIL_CODE_SUBMIT_CLICKED = "ProfileSettingsEmailCodeSubmitClicked"),
        (t.PROFILE_SETTINGS_EMAIL_RESEND_CODE_CLICKED = "ProfileSettingsEmailResendCodeClicked"),
        (t.PROFILE_SETTINGS_EMAIL_EDIT_CLICKED = "ProfileSettingsEmailEditClicked"),
        (t.SCRATCH_COUPON_VIEWED = "ScratchCouponViewed"),
        (t.SCRATCH_COUPON_REVEALED = "ScratchCouponRevealed"),
        (t.LESSON_AUDIO_PLAY = "lesson_audio_play"),
        (t.LESSON_AUDIO_COMPLETE = "lesson_audio_complete"),
        t);
    e.s(["EAnalyticEvents", () => r]);
  },
  5117,
  (e) => {
    "use strict";
    var t = e.i(117595),
      r = e.i(725397),
      n = e.i(866897);
    let i = { ACCEPTED: "accepted", REJECTED: "rejected" },
      o = new Set(["GB", ...r.EU_EEA_COUNTRIES]),
      s = (e) => !!e && o.has(e.toUpperCase());
    e.s([
      "COOKIE_CONSENT_VALUE",
      0,
      i,
      "getClientAnalyticsConsent",
      0,
      () => {
        let e = t.default.get(n.ECookieArg.COUNTRY),
          r = t.default.get(n.ECookieArg.COOKIE_CONSENT);
        return {
          gated: !0 === window.__ftCookieBannerEnabled && s(e),
          choice: r,
          allowed: ((e) => {
            let { country: t, choice: r } = e;
            return !(!0 === window.__ftCookieBannerEnabled && s(t)) || r === i.ACCEPTED;
          })({ country: e, choice: r }),
        };
      },
      "getConsentExpiresDays",
      0,
      (e) => (e === i.REJECTED ? 180 : 365),
      "isAnalyticsGatedRegion",
      0,
      s,
    ]);
  },
  646162,
  (e) => {
    "use strict";
    e.s([
      "resolvePersonalityFunnel",
      0,
      (e, t) => {
        let r = e || "myiq";
        if ("personality" !== r) return r;
        let n = "2" === t ? 2 : "3" === t ? 3 : 1;
        return 2 === n ? "personality-v2" : 3 === n ? "personality-v3" : r;
      },
    ]);
  },
  504001,
  (e) => {
    "use strict";
    var t = e.i(387644);
    e.i(879568);
    var r = e.i(480408),
      n = e.i(866897),
      i = e.i(924254),
      o = e.i(646162);
    e.i(756503);
    var s = e.i(846911);
    e.i(999126);
    var a = e.i(548248);
    e.i(569311);
    var c = e.i(896855);
    e.s([
      "initPeopleAnalytic",
      0,
      (e) => {
        c.mixpanelClient.identify(e);
      },
      "setPeopleAnalytic",
      0,
      (e) => {
        c.mixpanelClient.peopleSet(e);
      },
      "setPeopleAnalyticOnce",
      0,
      (e) => {
        c.mixpanelClient.peopleSetOnce(e);
      },
      "trackClientEvents",
      0,
      (e) => {
        var u;
        let { event: l, user: p, sessionId: h, params: d } = e,
          f = i.accessCookie.getItem(n.ECookieArg.ATTRIBUTION_STORAGE_KEY),
          g = null;
        if (f)
          try {
            g = JSON.parse(f);
          } catch {
            g = null;
          }
        let m = r.attributionUtil.formatForMixpanel(g);
        ((u = r.attributionUtil.formatForMixpanelRegister(g)), c.mixpanelClient.register(u));
        let _ = "true" === i.accessCookie.getItem(n.ECookieArg.PLAN_PICKER_FUNNEL),
          v = {
            build_version: s.envServer.BUILD_VERSION || "unknown",
            user_id: h || p?.id,
            funnel: p?.funnel || "myiq",
            email_validation_status: p?.email_validation_status,
            iq_score: p?.results?.userScore,
            acquisition_source: p?.isFreeVersion || "false",
            personality_type_result: p?.personality_type_result,
            love_language_type_result: p?.love_language_type_result,
            is_promo_version: p?.isPromoVersion,
            is_short_free_version: p?.isShortFreeVersion,
            is_playground_version: p?.isPlaygroundVersion,
            currency_for_pay: p?.currency?.currencyForPay,
            current_currency: p?.currency?.currencyCode,
            xp: p?.total_xp,
            ...d,
            ...m,
          },
          y = "true" === i.accessCookie.getItem(n.ECookieArg.BT_FUNNEL),
          b = v.funnel || "myiq";
        ((v.funnel = _
          ? "plan-picker"
          : (0, o.resolvePersonalityFunnel)(
              y && "myiq" === b ? "myiq-bt" : b,
              i.accessCookie.getItem(n.ECookieArg.PERSONALITY_FUNNEL_VARIANT),
            )),
          (0, a.debugUtil)({ text: `Event Mixpanel - ${l}`, value: v }),
          c.mixpanelClient.track({ eventName: l, props: v }),
          (0, a.debugUtil)({ text: `Event Google Tag - ${l}`, value: v }),
          (0, t.sendGAEvent)("event", l, v));
      },
    ]);
  },
  569311,
  86497,
  896855,
  (e) => {
    "use strict";
    var t,
      r,
      n,
      i,
      o,
      s,
      a,
      c,
      u,
      l,
      p,
      h,
      d,
      f,
      g,
      m,
      _ = e.i(467034),
      v = e.i(247167);
    if ("u" < typeof window) {
      var y = { hostname: "" };
      iO = {
        crypto: {
          randomUUID: function () {
            throw Error("unsupported");
          },
        },
        navigator: { userAgent: "", onLine: !0 },
        document: {
          createElement: function () {
            return {};
          },
          location: y,
          referrer: "",
        },
        screen: { width: 0, height: 0 },
        location: y,
        addEventListener: function () {},
        removeEventListener: function () {},
      };
    } else iO = window;
    function b(e, t) {
      (null == t || t > e.length) && (t = e.length);
      for (var r = 0, n = Array(t); r < t; r++) n[r] = e[r];
      return n;
    }
    function C(e, t, r, n, i, o, s) {
      try {
        var a = e[o](s),
          c = a.value;
      } catch (e) {
        r(e);
        return;
      }
      a.done ? t(c) : Promise.resolve(c).then(n, i);
    }
    function E(e) {
      return function () {
        var t = this,
          r = arguments;
        return new Promise(function (n, i) {
          var o = e.apply(t, r);
          function s(e) {
            C(o, n, i, s, a, "next", e);
          }
          function a(e) {
            C(o, n, i, s, a, "throw", e);
          }
          s(void 0);
        });
      };
    }
    function w(e, t, r) {
      return (w = L()
        ? Reflect.construct
        : function (e, t, r) {
            var n = [null];
            n.push.apply(n, t);
            var i = new (Function.bind.apply(e, n))();
            return (r && T(i, r.prototype), i);
          }).apply(null, arguments);
    }
    function I(e, t, r) {
      return (
        t &&
          (function (e, t) {
            for (var r = 0; r < t.length; r++) {
              var n = t[r];
              ((n.enumerable = n.enumerable || !1),
                (n.configurable = !0),
                "value" in n && (n.writable = !0),
                Object.defineProperty(e, n.key, n));
            }
          })(e.prototype, t),
        e
      );
    }
    function S() {
      return (S =
        Object.assign ||
        function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = arguments[t];
            for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
          }
          return e;
        }).apply(this, arguments);
    }
    function k(e) {
      return (k = Object.setPrototypeOf
        ? Object.getPrototypeOf
        : function (e) {
            return e.__proto__ || Object.getPrototypeOf(e);
          })(e);
    }
    function O(e, t) {
      if ("function" != typeof t && null !== t)
        throw TypeError("Super expression must either be null or a function");
      ((e.prototype = Object.create(t && t.prototype, {
        constructor: { value: e, writable: !0, configurable: !0 },
      })),
        t && T(e, t));
    }
    function A(e, t) {
      return null != t && "u" > typeof Symbol && t[Symbol.hasInstance]
        ? !!t[Symbol.hasInstance](e)
        : e instanceof t;
    }
    function R(e, t) {
      if (null == e) return {};
      var r,
        n,
        i = {},
        o = Object.keys(e);
      for (n = 0; n < o.length; n++) ((r = o[n]), t.indexOf(r) >= 0 || (i[r] = e[r]));
      return i;
    }
    function T(e, t) {
      return (T =
        Object.setPrototypeOf ||
        function (e, t) {
          return ((e.__proto__ = t), e);
        })(e, t);
    }
    function x(e) {
      return e && "u" > typeof Symbol && e.constructor === Symbol ? "symbol" : typeof e;
    }
    function M(e) {
      var t = "function" == typeof Map ? new Map() : void 0;
      return (M = function (e) {
        if (null === e || -1 === Function.toString.call(e).indexOf("[native code]")) return e;
        if ("function" != typeof e) throw TypeError("Super expression must either be null or a function");
        if (void 0 !== t) {
          if (t.has(e)) return t.get(e);
          t.set(e, r);
        }
        function r() {
          return w(e, arguments, k(this).constructor);
        }
        return (
          (r.prototype = Object.create(e.prototype, {
            constructor: { value: r, enumerable: !1, writable: !0, configurable: !0 },
          })),
          T(r, e)
        );
      })(e);
    }
    function L() {
      try {
        var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
      } catch (e) {}
      return (L = function () {
        return !!e;
      })();
    }
    function P(e, t) {
      var r = ("u" > typeof Symbol && e[Symbol.iterator]) || e["@@iterator"];
      if (r) return (r = r.call(e)).next.bind(r);
      if (
        Array.isArray(e) ||
        (r = (function (e) {
          if (e) {
            if ("string" == typeof e) return b(e, void 0);
            var t = Object.prototype.toString.call(e).slice(8, -1);
            if (("Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t))
              return Array.from(t);
            if ("Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)) return b(e, void 0);
          }
        })(e)) ||
        t
      ) {
        r && (e = r);
        var n = 0;
        return function () {
          return n >= e.length ? { done: !0 } : { done: !1, value: e[n++] };
        };
      }
      throw TypeError(
        "Invalid attempt to iterate non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
      );
    }
    function D(e, t) {
      var r,
        n,
        i,
        o,
        s = {
          label: 0,
          sent: function () {
            if (1 & i[0]) throw i[1];
            return i[1];
          },
          trys: [],
          ops: [],
        };
      return (
        (o = { next: a(0), throw: a(1), return: a(2) }),
        "function" == typeof Symbol &&
          (o[Symbol.iterator] = function () {
            return this;
          }),
        o
      );
      function a(o) {
        return function (a) {
          var c = [o, a];
          if (r) throw TypeError("Generator is already executing.");
          for (; s;)
            try {
              if (
                ((r = 1),
                n &&
                  (i = 2 & c[0] ? n.return : c[0] ? n.throw || ((i = n.return) && i.call(n), 0) : n.next) &&
                  !(i = i.call(n, c[1])).done)
              )
                return i;
              switch (((n = 0), i && (c = [2 & c[0], i.value]), c[0])) {
                case 0:
                case 1:
                  i = c;
                  break;
                case 4:
                  return (s.label++, { value: c[1], done: !1 });
                case 5:
                  (s.label++, (n = c[1]), (c = [0]));
                  continue;
                case 7:
                  ((c = s.ops.pop()), s.trys.pop());
                  continue;
                default:
                  if (!(i = (i = s.trys).length > 0 && i[i.length - 1]) && (6 === c[0] || 2 === c[0])) {
                    s = 0;
                    continue;
                  }
                  if (3 === c[0] && (!i || (c[1] > i[0] && c[1] < i[3]))) {
                    s.label = c[1];
                    break;
                  }
                  if (6 === c[0] && s.label < i[1]) {
                    ((s.label = i[1]), (i = c));
                    break;
                  }
                  if (i && s.label < i[2]) {
                    ((s.label = i[2]), s.ops.push(c));
                    break;
                  }
                  (i[2] && s.ops.pop(), s.trys.pop());
                  continue;
              }
              c = t.call(e, s);
            } catch (e) {
              ((c = [6, e]), (n = 0));
            } finally {
              r = i = 0;
            }
          if (5 & c[0]) throw c[1];
          return { value: c[0] ? c[1] : void 0, done: !0 };
        };
      }
    }
    function N(e) {
      var t = "function" == typeof Symbol && Symbol.iterator,
        r = t && e[t],
        n = 0;
      if (r) return r.call(e);
      if (e && "number" == typeof e.length)
        return {
          next: function () {
            return (e && n >= e.length && (e = void 0), { value: e && e[n++], done: !e });
          },
        };
      throw TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }
    var F = Object.defineProperty,
      U = function (e, t, r) {
        var n;
        return (
          (n = (void 0 === t ? "undefined" : x(t)) !== "symbol" ? t + "" : t),
          n in e ? F(e, n, { enumerable: !0, configurable: !0, writable: !0, value: r }) : (e[n] = r)
        );
      },
      B = Object.defineProperty,
      j = function (e, t, r) {
        var n;
        return (
          (n = (void 0 === t ? "undefined" : x(t)) !== "symbol" ? t + "" : t),
          n in e ? B(e, n, { enumerable: !0, configurable: !0, writable: !0, value: r }) : (e[n] = r)
        );
      },
      V =
        (((iv = V || {})[(iv.Document = 0)] = "Document"),
        (iv[(iv.DocumentType = 1)] = "DocumentType"),
        (iv[(iv.Element = 2)] = "Element"),
        (iv[(iv.Text = 3)] = "Text"),
        (iv[(iv.CDATA = 4)] = "CDATA"),
        (iv[(iv.Comment = 5)] = "Comment"),
        iv),
      G = {
        Node: ["childNodes", "parentNode", "parentElement", "textContent"],
        ShadowRoot: ["host", "styleSheets"],
        Element: ["shadowRoot", "querySelector", "querySelectorAll"],
        MutationObserver: [],
      },
      W = {
        Node: ["contains", "getRootNode"],
        ShadowRoot: ["getSelection"],
        Element: [],
        MutationObserver: ["constructor"],
      },
      z = {};
    function K(e) {
      if (z[e]) return z[e];
      var t = globalThis[e],
        r = t.prototype,
        n = e in G ? G[e] : void 0,
        i = !!(
          n &&
          n.every(function (e) {
            var t, n;
            return !!(null == (n = null == (t = Object.getOwnPropertyDescriptor(r, e)) ? void 0 : t.get)
              ? void 0
              : n.toString().includes("[native code]"));
          })
        ),
        o = e in W ? W[e] : void 0,
        s = !!(
          o &&
          o.every(function (e) {
            var t;
            return (
              "function" == typeof r[e] &&
              (null == (t = r[e]) ? void 0 : t.toString().includes("[native code]"))
            );
          })
        );
      if (i && s && !globalThis.Zone) return ((z[e] = t.prototype), t.prototype);
      try {
        var a = document.createElement("iframe");
        document.body.appendChild(a);
        var c = a.contentWindow;
        if (!c) return t.prototype;
        var u = c[e].prototype;
        if ((document.body.removeChild(a), !u)) return r;
        return (z[e] = u);
      } catch (e) {
        return r;
      }
    }
    var q = {};
    function Y(e, t, r) {
      var n,
        i = e + "." + String(r);
      if (q[i]) return q[i].call(t);
      var o = null == (n = Object.getOwnPropertyDescriptor(K(e), r)) ? void 0 : n.get;
      return o ? ((q[i] = o), o.call(t)) : t[r];
    }
    var $ = function (e) {
        return Y("Node", e, "childNodes");
      },
      H = function (e) {
        return Y("Node", e, "parentNode");
      },
      Z = function (e) {
        return Y("Node", e, "parentElement");
      },
      J = function (e) {
        return Y("Node", e, "textContent");
      },
      X = function (e) {
        return e && "shadowRoot" in e ? Y("Element", e, "shadowRoot") : null;
      };
    function Q(e) {
      return e.nodeType === e.ELEMENT_NODE;
    }
    function ee(e) {
      var t,
        r =
          (e && "host" in e && "mode" in e && ((t = e) && "host" in t ? Y("ShadowRoot", t, "host") : null)) ||
          null;
      return !!(r && "shadowRoot" in r && X(r) === e);
    }
    function et(e) {
      return "[object ShadowRoot]" === Object.prototype.toString.call(e);
    }
    function er(e) {
      try {
        var t,
          r = e.rules || e.cssRules;
        if (!r) return null;
        var n = e.href;
        return (
          !n && e.ownerNode && e.ownerNode.ownerDocument && (n = e.ownerNode.ownerDocument.location.href),
          (t = Array.from(r, function (e) {
            return en(e, n);
          }).join("")).includes(" background-clip: text;") &&
            !t.includes(" -webkit-background-clip: text;") &&
            (t = t.replace(
              /\sbackground-clip:\s*text;/g,
              " -webkit-background-clip: text; background-clip: text;",
            )),
          t
        );
      } catch (e) {
        return null;
      }
    }
    function en(e, t) {
      if ("styleSheet" in e) {
        var r;
        try {
          r =
            er(e.styleSheet) ||
            (function (e) {
              var t = e.cssText;
              if (t.split('"').length < 3) return t;
              var r = ["@import", "url(" + JSON.stringify(e.href) + ")"];
              return (
                "" === e.layerName ? r.push("layer") : e.layerName && r.push("layer(" + e.layerName + ")"),
                e.supportsText && r.push("supports(" + e.supportsText + ")"),
                e.media.length && r.push(e.media.mediaText),
                r.join(" ") + ";"
              );
            })(e);
        } catch (t) {
          r = e.cssText;
        }
        return e.styleSheet.href ? ef(r, e.styleSheet.href) : r;
      }
      var n = e.cssText;
      return ("selectorText" in e &&
        e.selectorText.includes(":") &&
        (n = n.replace(/(\[(?:[\w-]+)[^\\])(:(?:[\w-]+)\])/gm, "$1\\$2")),
      t)
        ? ef(n, t)
        : n;
    }
    var ei = (function () {
      function e() {
        (j(this, "idNodeMap", new Map()), j(this, "nodeMetaMap", new WeakMap()));
      }
      var t = e.prototype;
      return (
        (t.getId = function (e) {
          if (!e) return -1;
          var t,
            r = null == (t = this.getMeta(e)) ? void 0 : t.id;
          return null != r ? r : -1;
        }),
        (t.getNode = function (e) {
          return this.idNodeMap.get(e) || null;
        }),
        (t.getIds = function () {
          return Array.from(this.idNodeMap.keys());
        }),
        (t.getMeta = function (e) {
          return this.nodeMetaMap.get(e) || null;
        }),
        (t.removeNodeFromMap = function (e) {
          var t = this,
            r = this.getId(e);
          (this.idNodeMap.delete(r),
            e.childNodes &&
              e.childNodes.forEach(function (e) {
                return t.removeNodeFromMap(e);
              }));
        }),
        (t.has = function (e) {
          return this.idNodeMap.has(e);
        }),
        (t.hasNode = function (e) {
          return this.nodeMetaMap.has(e);
        }),
        (t.add = function (e, t) {
          var r = t.id;
          (this.idNodeMap.set(r, e), this.nodeMetaMap.set(e, t));
        }),
        (t.replace = function (e, t) {
          var r = this.getNode(e);
          if (r) {
            var n = this.nodeMetaMap.get(r);
            n && this.nodeMetaMap.set(t, n);
          }
          this.idNodeMap.set(e, t);
        }),
        (t.reset = function () {
          ((this.idNodeMap = new Map()), (this.nodeMetaMap = new WeakMap()));
        }),
        e
      );
    })();
    function eo(e) {
      var t = e.element,
        r = e.maskInputOptions,
        n = e.tagName,
        i = e.type,
        o = e.value,
        s = e.maskInputFn,
        a = o || "",
        c = i && es(i);
      return ((r[n.toLowerCase()] || (c && r[c])) && (a = s ? s(a, t) : "*".repeat(a.length)), a);
    }
    function es(e) {
      return e.toLowerCase();
    }
    var ea = "__rrweb_original__";
    function ec(e) {
      var t = e.type;
      return e.hasAttribute("data-rr-is-password") ? "password" : t ? es(t) : null;
    }
    function eu(e, t) {
      try {
        r = new URL(e, null != t ? t : window.location.href);
      } catch (e) {
        return null;
      }
      var r,
        n,
        i = r.pathname.match(/\.([0-9a-z]+)(?:$)/i);
      return null != (n = null == i ? void 0 : i[1]) ? n : null;
    }
    var el = /url\((?:(')([^']*)'|(")(.*?)"|([^)]*))\)/gm,
      ep = /^(?:[a-z+]+:)?\/\//i,
      eh = /^www\..*/i,
      ed = /^(data:)([^,]*),(.*)/i;
    function ef(e, t) {
      return (e || "").replace(el, function (e, r, n, i, o, s) {
        var a = n || o || s,
          c = r || i || "";
        if (!a) return e;
        if (ep.test(a) || eh.test(a) || ed.test(a)) return "url(" + c + a + c + ")";
        if ("/" === a[0])
          return (
            "url(" +
            c +
            ((t.indexOf("//") > -1 ? t.split("/").slice(0, 3).join("/") : t.split("/")[0]).split("?")[0] +
              a) +
            c +
            ")"
          );
        var u = t.split("/"),
          l = a.split("/");
        u.pop();
        for (var p, h, d = P(l); !(h = d()).done;) {
          var f = h.value;
          "." !== f && (".." === f ? u.pop() : u.push(f));
        }
        return "url(" + c + u.join("/") + c + ")";
      });
    }
    function eg(e, t) {
      return (void 0 === t && (t = !1), t)
        ? e.replace(/(\/\*[^*]*\*\/)|[\s;]/g, "")
        : e.replace(/(\/\*[^*]*\*\/)|[\s;]/g, "").replace(/0px/g, "0");
    }
    var em = 1,
      e_ = RegExp("[^a-z0-9-_:]");
    function ev() {
      return em++;
    }
    var ey = /^[^ \t\n\r\u000c]+/,
      eb = /^[, \t\n\r\u000c]+/,
      eC = new WeakMap();
    function eE(e, t) {
      return t && "" !== t.trim() ? ew(e, t) : t;
    }
    function ew(e, t) {
      var r = eC.get(e);
      if ((r || ((r = e.createElement("a")), eC.set(e, r)), t)) {
        if (t.startsWith("blob:") || t.startsWith("data:")) return t;
      } else t = "";
      return (r.setAttribute("href", t), r.href);
    }
    function eI(e, t, r, n) {
      if (!n) return n;
      if (
        "src" === r ||
        ("href" === r && ("use" !== t || "#" !== n[0])) ||
        ("xlink:href" === r && "#" !== n[0])
      )
        return eE(e, n);
      if ("background" === r && ("table" === t || "td" === t || "th" === t)) return eE(e, n);
      if ("srcset" === r)
        return (function (e, t) {
          if ("" === t.trim()) return t;
          var r = 0;
          function n(e) {
            var n,
              i = e.exec(t.substring(r));
            return i ? ((n = i[0]), (r += n.length), n) : "";
          }
          for (var i = []; n(eb), !(r >= t.length);) {
            var o = n(ey);
            if ("," === o.slice(-1)) ((o = eE(e, o.substring(0, o.length - 1))), i.push(o));
            else {
              var s = "";
              o = eE(e, o);
              for (var a = !1; ;) {
                var c = t.charAt(r);
                if ("" === c) {
                  i.push((o + s).trim());
                  break;
                }
                if (a) ")" === c && (a = !1);
                else if ("," === c) {
                  ((r += 1), i.push((o + s).trim()));
                  break;
                } else "(" === c && (a = !0);
                ((s += c), (r += 1));
              }
            }
          }
          return i.join(", ");
        })(e, n);
      if ("style" === r) return ef(n, ew(e));
      else if ("object" === t && "data" === r) return eE(e, n);
      return n;
    }
    function eS(e, t, r) {
      return ("video" === e || "audio" === e) && "autoplay" === t;
    }
    function ek(e, t, r) {
      if (!e) return !1;
      if (e.nodeType !== e.ELEMENT_NODE) return !!r && ek(H(e), t, r);
      for (var n = e.classList.length; n--;) {
        var i = e.classList[n];
        if (t.test(i)) return !0;
      }
      return !!r && ek(H(e), t, r);
    }
    function eO(e, t, r, n) {
      var i;
      if (Q(e)) {
        if (!$((i = e)).length) return !1;
      } else {
        if (null === Z(e)) return !1;
        i = Z(e);
      }
      try {
        if ("string" == typeof t) {
          if (n) {
            if (i.closest("." + t)) return !0;
          } else if (i.classList.contains(t)) return !0;
        } else if (ek(i, t, n)) return !0;
        if (r) {
          if (n) {
            if (i.closest(r)) return !0;
          } else if (i.matches(r)) return !0;
        }
      } catch (e) {}
      return !1;
    }
    function eA(e) {
      return null == e ? "" : e.toLowerCase();
    }
    function eR(e, t) {
      var r = t.doc,
        n = t.mirror,
        i = t.blockClass,
        o = t.blockSelector,
        s = t.maskTextClass,
        a = t.maskTextSelector,
        c = t.skipChild,
        u = void 0 !== c && c,
        l = t.inlineStylesheet,
        p = void 0 === l || l,
        h = t.maskInputOptions,
        d = void 0 === h ? {} : h,
        f = t.maskTextFn,
        g = t.maskInputFn,
        m = t.slimDOMOptions,
        _ = t.dataURLOptions,
        v = void 0 === _ ? {} : _,
        y = t.inlineImages,
        b = void 0 !== y && y,
        C = t.recordCanvas,
        E = void 0 !== C && C,
        w = t.onSerialize,
        I = t.onIframeLoad,
        S = t.iframeLoadTimeout,
        k = void 0 === S ? 5e3 : S,
        O = t.onStylesheetLoad,
        R = t.stylesheetLoadTimeout,
        T = void 0 === R ? 5e3 : R,
        x = t.keepIframeSrcFn,
        M =
          void 0 === x
            ? function () {
                return !1;
              }
            : x,
        L = t.newlyAddedElement,
        D = t.cssCaptured,
        N = t.needsMask,
        F = t.preserveWhiteSpace,
        U = void 0 === F || F;
      N || (N = eO(e, s, a, void 0 === N));
      var B = (function (e, t) {
        var r,
          n,
          i,
          o,
          s,
          a,
          c,
          u,
          l,
          p,
          h,
          d = t.doc,
          f = t.mirror,
          g = t.blockClass,
          m = t.blockSelector,
          _ = t.needsMask,
          v = t.inlineStylesheet,
          y = t.maskInputOptions,
          b = t.maskTextFn,
          C = t.maskInputFn,
          E = t.dataURLOptions,
          w = t.inlineImages,
          I = t.recordCanvas,
          S = t.keepIframeSrcFn,
          k = t.newlyAddedElement,
          O = t.cssCaptured,
          R = (function (e, t) {
            if (t.hasNode(e)) {
              var r = t.getId(e);
              return 1 === r ? void 0 : r;
            }
          })(d, f);
        switch (e.nodeType) {
          case e.DOCUMENT_NODE:
            if ("CSS1Compat" !== e.compatMode)
              return { type: V.Document, childNodes: [], compatMode: e.compatMode };
            return { type: V.Document, childNodes: [] };
          case e.DOCUMENT_TYPE_NODE:
            return {
              type: V.DocumentType,
              name: e.name,
              publicId: e.publicId,
              systemId: e.systemId,
              rootId: R,
            };
          case e.ELEMENT_NODE:
            return (function (e, t) {
              for (
                var r,
                  n = t.doc,
                  i = t.blockClass,
                  o = t.blockSelector,
                  s = t.inlineStylesheet,
                  a = t.maskInputOptions,
                  c = void 0 === a ? {} : a,
                  u = t.maskInputFn,
                  l = t.dataURLOptions,
                  p = void 0 === l ? {} : l,
                  h = t.inlineImages,
                  d = t.recordCanvas,
                  f = t.keepIframeSrcFn,
                  g = t.newlyAddedElement,
                  m = t.rootId,
                  _ = (function (e, t, r) {
                    try {
                      if ("string" == typeof t) {
                        if (e.classList.contains(t)) return !0;
                      } else
                        for (var n = e.classList.length; n--;) {
                          var i = e.classList[n];
                          if (t.test(i)) return !0;
                        }
                      if (r) return e.matches(r);
                    } catch (e) {}
                    return !1;
                  })(e, i, o),
                  v = (function (e) {
                    if (A(e, HTMLFormElement)) return "form";
                    var t = es(e.tagName);
                    return e_.test(t) ? "div" : t;
                  })(e),
                  y = {},
                  b = e.attributes.length,
                  C = 0;
                C < b;
                C++
              ) {
                var E = e.attributes[C];
                eS(v, E.name, E.value) || (y[E.name] = eI(n, v, es(E.name), E.value));
              }
              if ("link" === v && s) {
                var w = Array.from(n.styleSheets).find(function (t) {
                    return t.href === e.href;
                  }),
                  I = null;
                (w && (I = er(w)), I && (delete y.rel, delete y.href, (y._cssText = I)));
              }
              if ("style" === v && e.sheet) {
                var S = er(e.sheet);
                S &&
                  (e.childNodes.length > 1 &&
                    (S = (function (e, t, r) {
                      void 0 === r && (r = !1);
                      var n = Array.from(t.childNodes),
                        i = [],
                        o = 0;
                      if (n.length > 1 && e && "string" == typeof e) {
                        for (var s = eg(e, r), a = s.length / e.length, c = 1; c < n.length; c++)
                          if (n[c].textContent && "string" == typeof n[c].textContent) {
                            for (
                              var u = eg(n[c].textContent, r), l = 3;
                              l < u.length &&
                              (u[l].match(/[a-zA-Z0-9]/) || -1 !== u.indexOf(u.substring(0, l), 1));
                              l++
                            );
                            for (; l < u.length; l++) {
                              var p = u.substring(0, l),
                                h = s.split(p),
                                d = -1;
                              if (2 === h.length) d = h[0].length;
                              else if (h.length > 2 && "" === h[0] && "" !== n[c - 1].textContent)
                                d = s.indexOf(p, 1);
                              else if (1 === h.length) {
                                if (((p = p.substring(0, p.length - 1)), (h = s.split(p)).length <= 1))
                                  return (i.push(e), i);
                                l = 101;
                              } else l === u.length - 1 && (d = s.indexOf(p));
                              if (h.length >= 2 && l > 100) {
                                var f = n[c - 1].textContent;
                                if (f && "string" == typeof f) {
                                  var g = eg(f).length;
                                  d = s.indexOf(p, g);
                                }
                                -1 === d && (d = h[0].length);
                              }
                              if (-1 !== d) {
                                for (var m = Math.floor(d / a); m > 0 && m < e.length;) {
                                  if ((o += 1) > 50 * n.length) return (i.push(e), i);
                                  var _ = eg(e.substring(0, m), r);
                                  if (_.length === d) {
                                    (i.push(e.substring(0, m)), (e = e.substring(m)), (s = s.substring(d)));
                                    break;
                                  }
                                  _.length < d
                                    ? (m += Math.max(1, Math.floor((d - _.length) / a)))
                                    : (m -= Math.max(1, Math.floor((_.length - d) * a)));
                                }
                                break;
                              }
                            }
                          }
                      }
                      return (i.push(e), i);
                    })(S, e).join("/* rr_split */")),
                  (y._cssText = S));
              }
              if ("input" === v || "textarea" === v || "select" === v) {
                var k = e.value,
                  O = e.checked;
                "radio" !== y.type && "checkbox" !== y.type && "submit" !== y.type && "button" !== y.type && k
                  ? (y.value = eo({
                      element: e,
                      type: ec(e),
                      tagName: v,
                      value: k,
                      maskInputOptions: c,
                      maskInputFn: u,
                    }))
                  : O && (y.checked = O);
              }
              if (
                ("option" === v && (e.selected && !c.select ? (y.selected = !0) : delete y.selected),
                "dialog" === v &&
                  e.open &&
                  (y.rr_open_mode = e.matches("dialog:modal") ? "modal" : "non-modal"),
                "canvas" === v && d)
              ) {
                if ("2d" === e.__context)
                  !(function (e) {
                    var t = e.getContext("2d");
                    if (!t) return !0;
                    for (var r = 0; r < e.width; r += 50)
                      for (var n = 0; n < e.height; n += 50) {
                        var i = t.getImageData;
                        if (
                          new Uint32Array(
                            (ea in i ? i[ea] : i).call(
                              t,
                              r,
                              n,
                              Math.min(50, e.width - r),
                              Math.min(50, e.height - n),
                            ).data.buffer,
                          ).some(function (e) {
                            return 0 !== e;
                          })
                        )
                          return !1;
                      }
                    return !0;
                  })(e) && (y.rr_dataURL = e.toDataURL(p.type, p.quality));
                else if (!("__context" in e)) {
                  var R = e.toDataURL(p.type, p.quality),
                    T = n.createElement("canvas");
                  ((T.width = e.width),
                    (T.height = e.height),
                    R !== T.toDataURL(p.type, p.quality) && (y.rr_dataURL = R));
                }
              }
              if ("img" === v && h) {
                iR || (iT = (iR = n.createElement("canvas")).getContext("2d"));
                var x = e.currentSrc || e.getAttribute("src") || "<unknown-src>",
                  M = e.crossOrigin,
                  L = function () {
                    e.removeEventListener("load", L);
                    try {
                      ((iR.width = e.naturalWidth),
                        (iR.height = e.naturalHeight),
                        iT.drawImage(e, 0, 0),
                        (y.rr_dataURL = iR.toDataURL(p.type, p.quality)));
                    } catch (t) {
                      if ("anonymous" !== e.crossOrigin) {
                        ((e.crossOrigin = "anonymous"),
                          e.complete && 0 !== e.naturalWidth ? L() : e.addEventListener("load", L));
                        return;
                      }
                      console.warn("Cannot inline img src=" + x + "! Error: " + t);
                    }
                    "anonymous" === e.crossOrigin &&
                      (M ? (y.crossOrigin = M) : e.removeAttribute("crossorigin"));
                  };
                e.complete && 0 !== e.naturalWidth ? L() : e.addEventListener("load", L);
              }
              if ("audio" === v || "video" === v) {
                var P = y;
                ((P.rr_mediaState = e.paused ? "paused" : "played"),
                  (P.rr_mediaCurrentTime = e.currentTime),
                  (P.rr_mediaPlaybackRate = e.playbackRate),
                  (P.rr_mediaMuted = e.muted),
                  (P.rr_mediaLoop = e.loop),
                  (P.rr_mediaVolume = e.volume));
              }
              if (
                (!(void 0 !== g && g) &&
                  (e.scrollLeft && (y.rr_scrollLeft = e.scrollLeft),
                  e.scrollTop && (y.rr_scrollTop = e.scrollTop)),
                _)
              ) {
                var D = e.getBoundingClientRect(),
                  N = D.width,
                  F = D.height;
                y = { class: y.class, rr_width: "" + N + "px", rr_height: "" + F + "px" };
              }
              "iframe" !== v || f(y.src) || (e.contentDocument || (y.rr_src = y.src), delete y.src);
              try {
                customElements.get(v) && (r = !0);
              } catch (e) {}
              return {
                type: V.Element,
                tagName: v,
                attributes: y,
                childNodes: [],
                isSVG: !!("svg" === e.tagName || e.ownerSVGElement) || void 0,
                needBlock: _,
                rootId: m,
                isCustom: r,
              };
            })(e, {
              doc: d,
              blockClass: g,
              blockSelector: m,
              inlineStylesheet: v,
              maskInputOptions: void 0 === y ? {} : y,
              maskInputFn: C,
              dataURLOptions: void 0 === E ? {} : E,
              inlineImages: w,
              recordCanvas: I,
              keepIframeSrcFn: S,
              newlyAddedElement: void 0 !== k && k,
              rootId: R,
            });
          case e.TEXT_NODE:
            return (
              (r = e),
              (i = (n = { doc: d, needsMask: _, maskTextFn: b, rootId: R, cssCaptured: void 0 !== O && O })
                .needsMask),
              (o = n.maskTextFn),
              (s = n.rootId),
              (a = n.cssCaptured),
              (u = (c = H(r)) && c.tagName),
              (l = ""),
              (p = "STYLE" === u || void 0),
              (h = "SCRIPT" === u || void 0)
                ? (l = "SCRIPT_PLACEHOLDER")
                : !a && ((l = J(r)), p && l && (l = ef(l, ew(n.doc)))),
              !p && !h && l && i && (l = o ? o(l, Z(r)) : l.replace(/[\S]/g, "*")),
              { type: V.Text, textContent: l || "", rootId: s }
            );
          case e.CDATA_SECTION_NODE:
            return { type: V.CDATA, textContent: "", rootId: R };
          case e.COMMENT_NODE:
            return { type: V.Comment, textContent: J(e) || "", rootId: R };
          default:
            return !1;
        }
      })(e, {
        doc: r,
        mirror: n,
        blockClass: i,
        blockSelector: o,
        needsMask: N,
        inlineStylesheet: p,
        maskInputOptions: d,
        maskTextFn: f,
        maskInputFn: g,
        dataURLOptions: v,
        inlineImages: b,
        recordCanvas: E,
        keepIframeSrcFn: M,
        newlyAddedElement: void 0 !== L && L,
        cssCaptured: void 0 !== D && D,
      });
      if (!B) return (console.warn(e, "not serialized"), null);
      K = n.hasNode(e)
        ? n.getId(e)
        : !(function (e, t) {
              if (t.comment && e.type === V.Comment) return !0;
              if (e.type === V.Element) {
                if (
                  t.script &&
                  ("script" === e.tagName ||
                    ("link" === e.tagName &&
                      (("preload" === e.attributes.rel && "script" === e.attributes.as) ||
                        "modulepreload" === e.attributes.rel)) ||
                    ("link" === e.tagName &&
                      "prefetch" === e.attributes.rel &&
                      "string" == typeof e.attributes.href &&
                      "js" === eu(e.attributes.href)))
                )
                  return !0;
                else if (
                  t.headFavicon &&
                  (("link" === e.tagName && "shortcut icon" === e.attributes.rel) ||
                    ("meta" === e.tagName &&
                      (eA(e.attributes.name).match(/^msapplication-tile(image|color)$/) ||
                        "application-name" === eA(e.attributes.name) ||
                        "icon" === eA(e.attributes.rel) ||
                        "apple-touch-icon" === eA(e.attributes.rel) ||
                        "shortcut icon" === eA(e.attributes.rel))))
                )
                  return !0;
                else if ("meta" === e.tagName) {
                  if (t.headMetaDescKeywords && eA(e.attributes.name).match(/^description|keywords$/))
                    return !0;
                  else if (
                    t.headMetaSocial &&
                    (eA(e.attributes.property).match(/^(og|twitter|fb):/) ||
                      eA(e.attributes.name).match(/^(og|twitter):/) ||
                      "pinterest" === eA(e.attributes.name))
                  )
                    return !0;
                  else if (
                    t.headMetaRobots &&
                    ("robots" === eA(e.attributes.name) ||
                      "googlebot" === eA(e.attributes.name) ||
                      "bingbot" === eA(e.attributes.name))
                  )
                    return !0;
                  else if (t.headMetaHttpEquiv && void 0 !== e.attributes["http-equiv"]) return !0;
                  else if (
                    t.headMetaAuthorship &&
                    ("author" === eA(e.attributes.name) ||
                      "generator" === eA(e.attributes.name) ||
                      "framework" === eA(e.attributes.name) ||
                      "publisher" === eA(e.attributes.name) ||
                      "progid" === eA(e.attributes.name) ||
                      eA(e.attributes.property).match(/^article:/) ||
                      eA(e.attributes.property).match(/^product:/))
                  )
                    return !0;
                  else if (
                    t.headMetaVerification &&
                    ("google-site-verification" === eA(e.attributes.name) ||
                      "yandex-verification" === eA(e.attributes.name) ||
                      "csrf-token" === eA(e.attributes.name) ||
                      "p:domain_verify" === eA(e.attributes.name) ||
                      "verify-v1" === eA(e.attributes.name) ||
                      "verification" === eA(e.attributes.name) ||
                      "shopify-checkout-api-token" === eA(e.attributes.name))
                  )
                    return !0;
                }
              }
              return !1;
            })(B, m) &&
            (U || B.type !== V.Text || B.textContent.replace(/^\s+|\s+$/gm, "").length)
          ? ev()
          : -2;
      var j = Object.assign(B, { id: K });
      if ((n.add(e, j), -2 === K)) return null;
      w && w(e);
      var G = !u;
      if (j.type === V.Element) {
        ((G = G && !j.needBlock), delete j.needBlock);
        var W = X(e);
        W && et(W) && (j.isShadowHost = !0);
      }
      if ((j.type === V.Document || j.type === V.Element) && G) {
        m.headWhitespace && j.type === V.Element && "head" === j.tagName && (U = !1);
        var z = {
          doc: r,
          mirror: n,
          blockClass: i,
          blockSelector: o,
          needsMask: N,
          maskTextClass: s,
          maskTextSelector: a,
          skipChild: u,
          inlineStylesheet: p,
          maskInputOptions: d,
          maskTextFn: f,
          maskInputFn: g,
          slimDOMOptions: m,
          dataURLOptions: v,
          inlineImages: b,
          recordCanvas: E,
          preserveWhiteSpace: U,
          onSerialize: w,
          onIframeLoad: I,
          iframeLoadTimeout: k,
          onStylesheetLoad: O,
          stylesheetLoadTimeout: T,
          keepIframeSrcFn: M,
          cssCaptured: !1,
        };
        if (j.type === V.Element && "textarea" === j.tagName && void 0 !== j.attributes.value);
        else {
          j.type === V.Element &&
            void 0 !== j.attributes._cssText &&
            "string" == typeof j.attributes._cssText &&
            (z.cssCaptured = !0);
          for (var K, q, Y = P(Array.from($(e))); !(q = Y()).done;) {
            var en = eR(q.value, z);
            en && j.childNodes.push(en);
          }
        }
        var ei = null;
        if (Q(e) && (ei = X(e)))
          for (var el, ep = P(Array.from($(ei))); !(el = ep()).done;) {
            var eh = eR(el.value, z);
            eh && (et(ei) && (eh.isShadow = !0), j.childNodes.push(eh));
          }
      }
      var ed = H(e);
      return (
        ed && ee(ed) && et(ed) && (j.isShadow = !0),
        j.type === V.Element &&
          "iframe" === j.tagName &&
          (function (e, t, r) {
            var n,
              i = e.contentWindow;
            if (i) {
              var o = !1;
              try {
                n = i.document.readyState;
              } catch (e) {
                return;
              }
              if ("complete" !== n) {
                var s = setTimeout(function () {
                  o || (t(), (o = !0));
                }, r);
                e.addEventListener("load", function () {
                  (clearTimeout(s), (o = !0), t());
                });
                return;
              }
              var a = "about:blank";
              if (i.location.href !== a || e.src === a || "" === e.src)
                return (setTimeout(t, 0), e.addEventListener("load", t));
              e.addEventListener("load", t);
            }
          })(
            e,
            function () {
              var t = e.contentDocument;
              if (t && I) {
                var r = eR(t, {
                  doc: t,
                  mirror: n,
                  blockClass: i,
                  blockSelector: o,
                  needsMask: N,
                  maskTextClass: s,
                  maskTextSelector: a,
                  skipChild: !1,
                  inlineStylesheet: p,
                  maskInputOptions: d,
                  maskTextFn: f,
                  maskInputFn: g,
                  slimDOMOptions: m,
                  dataURLOptions: v,
                  inlineImages: b,
                  recordCanvas: E,
                  preserveWhiteSpace: U,
                  onSerialize: w,
                  onIframeLoad: I,
                  iframeLoadTimeout: k,
                  onStylesheetLoad: O,
                  stylesheetLoadTimeout: T,
                  keepIframeSrcFn: M,
                });
                r && I(e, r);
              }
            },
            k,
          ),
        j.type === V.Element &&
          "link" === j.tagName &&
          "string" == typeof j.attributes.rel &&
          ("stylesheet" === j.attributes.rel ||
            ("preload" === j.attributes.rel &&
              "string" == typeof j.attributes.href &&
              "css" === eu(j.attributes.href))) &&
          (function (e, t, r) {
            var n,
              i = !1;
            try {
              n = e.sheet;
            } catch (e) {
              return;
            }
            if (!n) {
              var o = setTimeout(function () {
                i || (t(), (i = !0));
              }, r);
              e.addEventListener("load", function () {
                (clearTimeout(o), (i = !0), t());
              });
            }
          })(
            e,
            function () {
              if (O) {
                var t = eR(e, {
                  doc: r,
                  mirror: n,
                  blockClass: i,
                  blockSelector: o,
                  needsMask: N,
                  maskTextClass: s,
                  maskTextSelector: a,
                  skipChild: !1,
                  inlineStylesheet: p,
                  maskInputOptions: d,
                  maskTextFn: f,
                  maskInputFn: g,
                  slimDOMOptions: m,
                  dataURLOptions: v,
                  inlineImages: b,
                  recordCanvas: E,
                  preserveWhiteSpace: U,
                  onSerialize: w,
                  onIframeLoad: I,
                  iframeLoadTimeout: k,
                  onStylesheetLoad: O,
                  stylesheetLoadTimeout: T,
                  keepIframeSrcFn: M,
                });
                t && O(e, t);
              }
            },
            T,
          ),
        j
      );
    }
    var eT = { exports: {} },
      ex = String,
      eM = function () {
        return {
          isColorSupported: !1,
          reset: ex,
          bold: ex,
          dim: ex,
          italic: ex,
          underline: ex,
          inverse: ex,
          hidden: ex,
          strikethrough: ex,
          black: ex,
          red: ex,
          green: ex,
          yellow: ex,
          blue: ex,
          magenta: ex,
          cyan: ex,
          white: ex,
          gray: ex,
          bgBlack: ex,
          bgRed: ex,
          bgGreen: ex,
          bgYellow: ex,
          bgBlue: ex,
          bgMagenta: ex,
          bgCyan: ex,
          bgWhite: ex,
        };
      };
    ((eT.exports = eM()), (eT.exports.createColors = eM));
    var eL = eT.exports,
      eP = (function (e) {
        if (e.__esModule) return e;
        var t = e.default;
        if ("function" == typeof t) {
          var r = function e() {
            return A(this, e) ? Reflect.construct(t, arguments, this.constructor) : t.apply(this, arguments);
          };
          r.prototype = t.prototype;
        } else r = {};
        return (
          Object.defineProperty(r, "__esModule", { value: !0 }),
          Object.keys(e).forEach(function (t) {
            var n = Object.getOwnPropertyDescriptor(e, t);
            Object.defineProperty(
              r,
              t,
              n.get
                ? n
                : {
                    enumerable: !0,
                    get: function () {
                      return e[t];
                    },
                  },
            );
          }),
          r
        );
      })(
        Object.freeze(
          Object.defineProperty({ __proto__: null, default: {} }, Symbol.toStringTag, { value: "Module" }),
        ),
      ),
      eD = (function (e) {
        function t(r, n, i, o, s, a) {
          var c;
          return (
            ((c = e.call(this, r) || this).name = "CssSyntaxError"),
            (c.reason = r),
            s && (c.file = s),
            o && (c.source = o),
            a && (c.plugin = a),
            void 0 !== n &&
              void 0 !== i &&
              ("number" == typeof n
                ? ((c.line = n), (c.column = i))
                : ((c.line = n.line), (c.column = n.column), (c.endLine = i.line), (c.endColumn = i.column))),
            c.setMessage(),
            Error.captureStackTrace && Error.captureStackTrace(c, t),
            c
          );
        }
        O(t, e);
        var r = t.prototype;
        return (
          (r.setMessage = function () {
            ((this.message = this.plugin ? this.plugin + ": " : ""),
              (this.message += this.file ? this.file : "<css input>"),
              void 0 !== this.line && (this.message += ":" + this.line + ":" + this.column),
              (this.message += ": " + this.reason));
          }),
          (r.showSourceCode = function (e) {
            var t,
              r,
              n = this;
            if (!this.source) return "";
            var i = this.source;
            (null == e && (e = eL.isColorSupported), eP && e && (i = eP(i)));
            var o = i.split(/\r?\n/),
              s = Math.max(this.line - 3, 0),
              a = Math.min(this.line + 2, o.length),
              c = String(a).length;
            if (e) {
              var u = eL.createColors(!0),
                l = u.bold,
                p = u.gray,
                h = u.red;
              ((t = function (e) {
                return l(h(e));
              }),
                (r = function (e) {
                  return p(e);
                }));
            } else
              t = r = function (e) {
                return e;
              };
            return o
              .slice(s, a)
              .map(function (e, i) {
                var o = s + 1 + i,
                  a = " " + (" " + o).slice(-c) + " | ";
                if (o === n.line) {
                  var u = r(a.replace(/\d/g, " ")) + e.slice(0, n.column - 1).replace(/[^\t]/g, " ");
                  return t(">") + r(a) + e + "\n " + u + t("^");
                }
                return " " + r(a) + e;
              })
              .join("\n");
          }),
          (r.toString = function () {
            var e = this.showSourceCode();
            return (e && (e = "\n\n" + e + "\n"), this.name + ": " + this.message + e);
          }),
          t
        );
      })(M(Error));
    eD.default = eD;
    var eN = {};
    ((eN.isClean = Symbol("isClean")), (eN.my = Symbol("my")));
    var eF = {
        after: "\n",
        beforeClose: "\n",
        beforeComment: "\n",
        beforeDecl: "\n",
        beforeOpen: " ",
        beforeRule: "\n",
        colon: ": ",
        commentLeft: " ",
        commentRight: " ",
        emptyBody: "",
        indent: "    ",
        semicolon: !1,
      },
      eU = (function () {
        function e(e) {
          this.builder = e;
        }
        var t = e.prototype;
        return (
          (t.atrule = function (e, t) {
            var r = "@" + e.name,
              n = e.params ? this.rawValue(e, "params") : "";
            if ((void 0 !== e.raws.afterName ? (r += e.raws.afterName) : n && (r += " "), e.nodes))
              this.block(e, r + n);
            else {
              var i = (e.raws.between || "") + (t ? ";" : "");
              this.builder(r + n + i, e);
            }
          }),
          (t.beforeAfter = function (e, t) {
            for (
              var r =
                  "decl" === e.type
                    ? this.raw(e, null, "beforeDecl")
                    : "comment" === e.type
                      ? this.raw(e, null, "beforeComment")
                      : "before" === t
                        ? this.raw(e, null, "beforeRule")
                        : this.raw(e, null, "beforeClose"),
                n = e.parent,
                i = 0;
              n && "root" !== n.type;
            )
              ((i += 1), (n = n.parent));
            if (r.includes("\n")) {
              var o = this.raw(e, null, "indent");
              if (o.length) for (var s = 0; s < i; s++) r += o;
            }
            return r;
          }),
          (t.block = function (e, t) {
            var r,
              n = this.raw(e, "between", "beforeOpen");
            (this.builder(t + n + "{", e, "start"),
              e.nodes && e.nodes.length
                ? (this.body(e), (r = this.raw(e, "after")))
                : (r = this.raw(e, "after", "emptyBody")),
              r && this.builder(r),
              this.builder("}", e, "end"));
          }),
          (t.body = function (e) {
            for (var t = e.nodes.length - 1; t > 0 && "comment" === e.nodes[t].type;) t -= 1;
            for (var r = this.raw(e, "semicolon"), n = 0; n < e.nodes.length; n++) {
              var i = e.nodes[n],
                o = this.raw(i, "before");
              (o && this.builder(o), this.stringify(i, t !== n || r));
            }
          }),
          (t.comment = function (e) {
            var t = this.raw(e, "left", "commentLeft"),
              r = this.raw(e, "right", "commentRight");
            this.builder("/*" + t + e.text + r + "*/", e);
          }),
          (t.decl = function (e, t) {
            var r = this.raw(e, "between", "colon"),
              n = e.prop + r + this.rawValue(e, "value");
            (e.important && (n += e.raws.important || " !important"), t && (n += ";"), this.builder(n, e));
          }),
          (t.document = function (e) {
            this.body(e);
          }),
          (t.raw = function (e, t, r) {
            if ((r || (r = t), t && void 0 !== (n = e.raws[t]))) return n;
            var n,
              i = e.parent;
            if (
              "before" === r &&
              (!i || ("root" === i.type && i.first === e) || (i && "document" === i.type))
            )
              return "";
            if (!i) return eF[r];
            var o = e.root();
            if ((o.rawCache || (o.rawCache = {}), void 0 !== o.rawCache[r])) return o.rawCache[r];
            if ("before" === r || "after" === r) return this.beforeAfter(e, r);
            var s,
              a = "raw" + ((s = r)[0].toUpperCase() + s.slice(1));
            return (
              this[a]
                ? (n = this[a](o, e))
                : o.walk(function (e) {
                    if (void 0 !== (n = e.raws[t])) return !1;
                  }),
              void 0 === n && (n = eF[r]),
              (o.rawCache[r] = n),
              n
            );
          }),
          (t.rawBeforeClose = function (e) {
            var t;
            return (
              e.walk(function (e) {
                if (e.nodes && e.nodes.length > 0 && void 0 !== e.raws.after)
                  return ((t = e.raws.after).includes("\n") && (t = t.replace(/[^\n]+$/, "")), !1);
              }),
              t && (t = t.replace(/\S/g, "")),
              t
            );
          }),
          (t.rawBeforeComment = function (e, t) {
            var r;
            return (
              e.walkComments(function (e) {
                if (void 0 !== e.raws.before)
                  return ((r = e.raws.before).includes("\n") && (r = r.replace(/[^\n]+$/, "")), !1);
              }),
              void 0 === r ? (r = this.raw(t, null, "beforeDecl")) : r && (r = r.replace(/\S/g, "")),
              r
            );
          }),
          (t.rawBeforeDecl = function (e, t) {
            var r;
            return (
              e.walkDecls(function (e) {
                if (void 0 !== e.raws.before)
                  return ((r = e.raws.before).includes("\n") && (r = r.replace(/[^\n]+$/, "")), !1);
              }),
              void 0 === r ? (r = this.raw(t, null, "beforeRule")) : r && (r = r.replace(/\S/g, "")),
              r
            );
          }),
          (t.rawBeforeOpen = function (e) {
            var t;
            return (
              e.walk(function (e) {
                if ("decl" !== e.type && void 0 !== (t = e.raws.between)) return !1;
              }),
              t
            );
          }),
          (t.rawBeforeRule = function (e) {
            var t;
            return (
              e.walk(function (r) {
                if (r.nodes && (r.parent !== e || e.first !== r) && void 0 !== r.raws.before)
                  return ((t = r.raws.before).includes("\n") && (t = t.replace(/[^\n]+$/, "")), !1);
              }),
              t && (t = t.replace(/\S/g, "")),
              t
            );
          }),
          (t.rawColon = function (e) {
            var t;
            return (
              e.walkDecls(function (e) {
                if (void 0 !== e.raws.between) return ((t = e.raws.between.replace(/[^\s:]/g, "")), !1);
              }),
              t
            );
          }),
          (t.rawEmptyBody = function (e) {
            var t;
            return (
              e.walk(function (e) {
                if (e.nodes && 0 === e.nodes.length && void 0 !== (t = e.raws.after)) return !1;
              }),
              t
            );
          }),
          (t.rawIndent = function (e) {
            var t;
            return e.raws.indent
              ? e.raws.indent
              : (e.walk(function (r) {
                  var n = r.parent;
                  if (n && n !== e && n.parent && n.parent === e && void 0 !== r.raws.before) {
                    var i = r.raws.before.split("\n");
                    return ((t = (t = i[i.length - 1]).replace(/\S/g, "")), !1);
                  }
                }),
                t);
          }),
          (t.rawSemicolon = function (e) {
            var t;
            return (
              e.walk(function (e) {
                if (e.nodes && e.nodes.length && "decl" === e.last.type && void 0 !== (t = e.raws.semicolon))
                  return !1;
              }),
              t
            );
          }),
          (t.rawValue = function (e, t) {
            var r = e[t],
              n = e.raws[t];
            return n && n.value === r ? n.raw : r;
          }),
          (t.root = function (e) {
            (this.body(e), e.raws.after && this.builder(e.raws.after));
          }),
          (t.rule = function (e) {
            (this.block(e, this.rawValue(e, "selector")),
              e.raws.ownSemicolon && this.builder(e.raws.ownSemicolon, e, "end"));
          }),
          (t.stringify = function (e, t) {
            if (!this[e.type])
              throw Error(
                "Unknown AST node type " + e.type + ". Maybe you need to change PostCSS stringifier.",
              );
            this[e.type](e, t);
          }),
          e
        );
      })();
    function eB(e, t) {
      new eU(t).stringify(e);
    }
    ((eU.default = eU), (eB.default = eB));
    var ej = eN.isClean,
      eV = eN.my,
      eG = (function () {
        function e(e) {
          for (var t in (void 0 === e && (e = {}), (this.raws = {}), (this[ej] = !1), (this[eV] = !0), e))
            if ("nodes" === t) {
              this.nodes = [];
              for (var r, n = P(e[t]); !(r = n()).done;) {
                var i = r.value;
                "function" == typeof i.clone ? this.append(i.clone()) : this.append(i);
              }
            } else this[t] = e[t];
        }
        var t = e.prototype;
        return (
          (t.addToError = function (e) {
            if (((e.postcssNode = this), e.stack && this.source && /\n\s{4}at /.test(e.stack))) {
              var t = this.source;
              e.stack = e.stack.replace(
                /\n\s{4}at /,
                "$&" + t.input.from + ":" + t.start.line + ":" + t.start.column + "$&",
              );
            }
            return e;
          }),
          (t.after = function (e) {
            return (this.parent.insertAfter(this, e), this);
          }),
          (t.assign = function (e) {
            for (var t in (void 0 === e && (e = {}), e)) this[t] = e[t];
            return this;
          }),
          (t.before = function (e) {
            return (this.parent.insertBefore(this, e), this);
          }),
          (t.cleanRaws = function (e) {
            (delete this.raws.before, delete this.raws.after, e || delete this.raws.between);
          }),
          (t.clone = function (e) {
            void 0 === e && (e = {});
            var t = (function e(t, r) {
              var n = new t.constructor();
              for (var i in t)
                if (Object.prototype.hasOwnProperty.call(t, i) && "proxyCache" !== i) {
                  var o = t[i],
                    s = void 0 === o ? "undefined" : x(o);
                  "parent" === i && "object" === s
                    ? r && (n[i] = r)
                    : "source" === i
                      ? (n[i] = o)
                      : Array.isArray(o)
                        ? (n[i] = o.map(function (t) {
                            return e(t, n);
                          }))
                        : ("object" === s && null !== o && (o = e(o)), (n[i] = o));
                }
              return n;
            })(this);
            for (var r in e) t[r] = e[r];
            return t;
          }),
          (t.cloneAfter = function (e) {
            void 0 === e && (e = {});
            var t = this.clone(e);
            return (this.parent.insertAfter(this, t), t);
          }),
          (t.cloneBefore = function (e) {
            void 0 === e && (e = {});
            var t = this.clone(e);
            return (this.parent.insertBefore(this, t), t);
          }),
          (t.error = function (e, t) {
            if ((void 0 === t && (t = {}), this.source)) {
              var r = this.rangeBy(t),
                n = r.end,
                i = r.start;
              return this.source.input.error(
                e,
                { column: i.column, line: i.line },
                { column: n.column, line: n.line },
                t,
              );
            }
            return new eD(e);
          }),
          (t.getProxyProcessor = function () {
            return {
              get: function (e, t) {
                return "proxyOf" === t
                  ? e
                  : "root" === t
                    ? function () {
                        return e.root().toProxy();
                      }
                    : e[t];
              },
              set: function (e, t, r) {
                return (
                  e[t] === r ||
                  ((e[t] = r),
                  ("prop" === t ||
                    "value" === t ||
                    "name" === t ||
                    "params" === t ||
                    "important" === t ||
                    "text" === t) &&
                    e.markDirty(),
                  !0)
                );
              },
            };
          }),
          (t.markDirty = function () {
            if (this[ej]) {
              this[ej] = !1;
              for (var e = this; (e = e.parent);) e[ej] = !1;
            }
          }),
          (t.next = function () {
            if (this.parent) {
              var e = this.parent.index(this);
              return this.parent.nodes[e + 1];
            }
          }),
          (t.positionBy = function (e, t) {
            var r = this.source.start;
            if (e.index) r = this.positionInside(e.index, t);
            else if (e.word) {
              var n = (t = this.toString()).indexOf(e.word);
              -1 !== n && (r = this.positionInside(n, t));
            }
            return r;
          }),
          (t.positionInside = function (e, t) {
            for (
              var r = t || this.toString(), n = this.source.start.column, i = this.source.start.line, o = 0;
              o < e;
              o++
            )
              "\n" === r[o] ? ((n = 1), (i += 1)) : (n += 1);
            return { column: n, line: i };
          }),
          (t.prev = function () {
            if (this.parent) {
              var e = this.parent.index(this);
              return this.parent.nodes[e - 1];
            }
          }),
          (t.rangeBy = function (e) {
            var t = { column: this.source.start.column, line: this.source.start.line },
              r = this.source.end
                ? { column: this.source.end.column + 1, line: this.source.end.line }
                : { column: t.column + 1, line: t.line };
            if (e.word) {
              var n = this.toString(),
                i = n.indexOf(e.word);
              -1 !== i && ((t = this.positionInside(i, n)), (r = this.positionInside(i + e.word.length, n)));
            } else
              (e.start
                ? (t = { column: e.start.column, line: e.start.line })
                : e.index && (t = this.positionInside(e.index)),
                e.end
                  ? (r = { column: e.end.column, line: e.end.line })
                  : "number" == typeof e.endIndex
                    ? (r = this.positionInside(e.endIndex))
                    : e.index && (r = this.positionInside(e.index + 1)));
            return (
              (r.line < t.line || (r.line === t.line && r.column <= t.column)) &&
                (r = { column: t.column + 1, line: t.line }),
              { end: r, start: t }
            );
          }),
          (t.raw = function (e, t) {
            return new eU().raw(this, e, t);
          }),
          (t.remove = function () {
            return (this.parent && this.parent.removeChild(this), (this.parent = void 0), this);
          }),
          (t.replaceWith = function () {
            for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
            if (this.parent) {
              for (var n, i = this, o = !1, s = P(t); !(n = s()).done;) {
                var a = n.value;
                a === this
                  ? (o = !0)
                  : o
                    ? (this.parent.insertAfter(i, a), (i = a))
                    : this.parent.insertBefore(i, a);
              }
              o || this.remove();
            }
            return this;
          }),
          (t.root = function () {
            for (var e = this; e.parent && "document" !== e.parent.type;) e = e.parent;
            return e;
          }),
          (t.toJSON = function (e, t) {
            var r = {},
              n = null == t;
            t = t || new Map();
            var i = 0;
            for (var o in this)
              if (Object.prototype.hasOwnProperty.call(this, o) && "parent" !== o && "proxyCache" !== o) {
                var s = this[o];
                if (Array.isArray(s))
                  r[o] = s.map(function (e) {
                    return (void 0 === e ? "undefined" : x(e)) === "object" && e.toJSON
                      ? e.toJSON(null, t)
                      : e;
                  });
                else if ((void 0 === s ? "undefined" : x(s)) === "object" && s.toJSON)
                  r[o] = s.toJSON(null, t);
                else if ("source" === o) {
                  var a = t.get(s.input);
                  (null == a && ((a = i), t.set(s.input, i), i++),
                    (r[o] = { end: s.end, inputId: a, start: s.start }));
                } else r[o] = s;
              }
            return (
              n &&
                (r.inputs = [].concat(t.keys()).map(function (e) {
                  return e.toJSON();
                })),
              r
            );
          }),
          (t.toProxy = function () {
            return (
              this.proxyCache || (this.proxyCache = new Proxy(this, this.getProxyProcessor())),
              this.proxyCache
            );
          }),
          (t.toString = function (e) {
            (void 0 === e && (e = eB), e.stringify && (e = e.stringify));
            var t = "";
            return (
              e(this, function (e) {
                t += e;
              }),
              t
            );
          }),
          (t.warn = function (e, t, r) {
            var n = { node: this };
            for (var i in r) n[i] = r[i];
            return e.warn(t, n);
          }),
          I(e, [
            {
              key: "proxyOf",
              get: function () {
                return this;
              },
            },
          ]),
          e
        );
      })();
    eG.default = eG;
    var eW = (function (e) {
      function t(t) {
        var r;
        return (
          t && void 0 !== t.value && "string" != typeof t.value && (t = S({}, t, { value: String(t.value) })),
          ((r = e.call(this, t) || this).type = "decl"),
          r
        );
      }
      return (
        O(t, e),
        I(t, [
          {
            key: "variable",
            get: function () {
              return this.prop.startsWith("--") || "$" === this.prop[0];
            },
          },
        ]),
        t
      );
    })(eG);
    eW.default = eW;
    var ez = eP.SourceMapConsumer,
      eK = eP.SourceMapGenerator,
      eq = eP.existsSync,
      eY = eP.readFileSync,
      e$ = eP.dirname,
      eH = eP.join,
      eZ = (function () {
        function e(e, t) {
          if (!1 !== t.map) {
            (this.loadAnnotation(e), (this.inline = this.startWith(this.annotation, "data:")));
            var r = t.map ? t.map.prev : void 0,
              n = this.loadMap(t.from, r);
            (!this.mapFile && t.from && (this.mapFile = t.from),
              this.mapFile && (this.root = e$(this.mapFile)),
              n && (this.text = n));
          }
        }
        var t = e.prototype;
        return (
          (t.consumer = function () {
            return (this.consumerCache || (this.consumerCache = new ez(this.text)), this.consumerCache);
          }),
          (t.decodeInline = function (e) {
            if (/^data:application\/json;charset=utf-?8,/.test(e) || /^data:application\/json,/.test(e))
              return decodeURIComponent(e.substr(RegExp.lastMatch.length));
            if (
              /^data:application\/json;charset=utf-?8;base64,/.test(e) ||
              /^data:application\/json;base64,/.test(e)
            ) {
              var t;
              return ((t = e.substr(RegExp.lastMatch.length)), _.Buffer.from(t, "base64").toString());
            }
            throw Error("Unsupported source map encoding " + e.match(/data:application\/json;([^,]+),/)[1]);
          }),
          (t.getAnnotationURL = function (e) {
            return e.replace(/^\/\*\s*# sourceMappingURL=/, "").trim();
          }),
          (t.isMap = function (e) {
            return (
              (void 0 === e ? "undefined" : x(e)) === "object" &&
              ("string" == typeof e.mappings || "string" == typeof e._mappings || Array.isArray(e.sections))
            );
          }),
          (t.loadAnnotation = function (e) {
            var t = e.match(/\/\*\s*# sourceMappingURL=/gm);
            if (t) {
              var r = e.lastIndexOf(t.pop()),
                n = e.indexOf("*/", r);
              r > -1 && n > -1 && (this.annotation = this.getAnnotationURL(e.substring(r, n)));
            }
          }),
          (t.loadFile = function (e) {
            if (((this.root = e$(e)), eq(e))) return ((this.mapFile = e), eY(e, "utf-8").toString().trim());
          }),
          (t.loadMap = function (e, t) {
            if (!1 === t) return !1;
            if (t)
              if ("string" == typeof t) return t;
              else if ("function" == typeof t) {
                var r = t(e);
                if (r) {
                  var n = this.loadFile(r);
                  if (!n) throw Error("Unable to load previous source map: " + r.toString());
                  return n;
                }
              } else if (A(t, ez)) return eK.fromSourceMap(t).toString();
              else if (A(t, eK)) return t.toString();
              else if (this.isMap(t)) return JSON.stringify(t);
              else throw Error("Unsupported previous source map format: " + t.toString());
            else if (this.inline) return this.decodeInline(this.annotation);
            else if (this.annotation) {
              var i = this.annotation;
              return (e && (i = eH(e$(e), i)), this.loadFile(i));
            }
          }),
          (t.startWith = function (e, t) {
            return !!e && e.substr(0, t.length) === t;
          }),
          (t.withContent = function () {
            return !!(this.consumer().sourcesContent && this.consumer().sourcesContent.length > 0);
          }),
          e
        );
      })();
    eZ.default = eZ;
    var eJ = eP.SourceMapConsumer,
      eX = eP.SourceMapGenerator,
      eQ = eP.fileURLToPath,
      e0 = eP.pathToFileURL,
      e1 = eP.isAbsolute,
      e2 = eP.resolve,
      e3 = function (e) {
        void 0 === e && (e = 21);
        for (var t = "", r = e; r--;)
          t += "useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict"[(64 * Math.random()) | 0];
        return t;
      },
      e4 = Symbol("fromOffsetCache"),
      e5 = !!(eJ && eX),
      e9 = !!(e2 && e1),
      e6 = (function () {
        function e(e, t) {
          if (
            (void 0 === t && (t = {}),
            null == e || ((void 0 === e ? "undefined" : x(e)) === "object" && !e.toString))
          )
            throw Error("PostCSS received " + e + " instead of CSS string");
          if (
            ((this.css = e.toString()),
            "\uFEFF" === this.css[0] || "￾" === this.css[0]
              ? ((this.hasBOM = !0), (this.css = this.css.slice(1)))
              : (this.hasBOM = !1),
            t.from &&
              (!e9 || /^\w+:\/\//.test(t.from) || e1(t.from)
                ? (this.file = t.from)
                : (this.file = e2(t.from))),
            e9 && e5)
          ) {
            var r = new eZ(this.css, t);
            if (r.text) {
              this.map = r;
              var n = r.consumer().file;
              !this.file && n && (this.file = this.mapResolve(n));
            }
          }
          (this.file || (this.id = "<input css " + e3(6) + ">"), this.map && (this.map.file = this.from));
        }
        var t = e.prototype;
        return (
          (t.error = function (e, t, r, n) {
            if ((void 0 === n && (n = {}), t && (void 0 === t ? "undefined" : x(t)) === "object")) {
              var i,
                o,
                s,
                a = t,
                c = r;
              if ("number" == typeof a.offset) {
                var u = this.fromOffset(a.offset);
                ((t = u.line), (r = u.col));
              } else ((t = a.line), (r = a.column));
              if ("number" == typeof c.offset) {
                var l = this.fromOffset(c.offset);
                ((o = l.line), (s = l.col));
              } else ((o = c.line), (s = c.column));
            } else if (!r) {
              var p = this.fromOffset(t);
              ((t = p.line), (r = p.col));
            }
            var h = this.origin(t, r, o, s);
            return (
              ((i = h
                ? new eD(
                    e,
                    void 0 === h.endLine ? h.line : { column: h.column, line: h.line },
                    void 0 === h.endLine ? h.column : { column: h.endColumn, line: h.endLine },
                    h.source,
                    h.file,
                    n.plugin,
                  )
                : new eD(
                    e,
                    void 0 === o ? t : { column: r, line: t },
                    void 0 === o ? r : { column: s, line: o },
                    this.css,
                    this.file,
                    n.plugin,
                  )).input = { column: r, endColumn: s, endLine: o, line: t, source: this.css }),
              this.file && (e0 && (i.input.url = e0(this.file).toString()), (i.input.file = this.file)),
              i
            );
          }),
          (t.fromOffset = function (e) {
            if (this[e4]) a = this[e4];
            else {
              var t = this.css.split("\n");
              a = Array(t.length);
              for (var r = 0, n = 0, i = t.length; n < i; n++) ((a[n] = r), (r += t[n].length + 1));
              this[e4] = a;
            }
            s = a[a.length - 1];
            var o = 0;
            if (e >= s) o = a.length - 1;
            else
              for (var s, a, c, u = a.length - 2; o < u;)
                if (e < a[(c = o + ((u - o) >> 1))]) u = c - 1;
                else if (e >= a[c + 1]) o = c + 1;
                else {
                  o = c;
                  break;
                }
            return { col: e - a[o] + 1, line: o + 1 };
          }),
          (t.mapResolve = function (e) {
            return /^\w+:\/\//.test(e) ? e : e2(this.map.consumer().sourceRoot || this.map.root || ".", e);
          }),
          (t.origin = function (e, t, r, n) {
            if (!this.map) return !1;
            var i,
              o,
              s = this.map.consumer(),
              a = s.originalPositionFor({ column: t, line: e });
            if (!a.source) return !1;
            ("number" == typeof r && (i = s.originalPositionFor({ column: n, line: r })),
              (o = e1(a.source)
                ? e0(a.source)
                : new URL(a.source, this.map.consumer().sourceRoot || e0(this.map.mapFile))));
            var c = {
              column: a.column,
              endColumn: i && i.column,
              endLine: i && i.line,
              line: a.line,
              url: o.toString(),
            };
            if ("file:" === o.protocol)
              if (eQ) c.file = eQ(o);
              else throw Error("file: protocol is not available in this PostCSS build");
            var u = s.sourceContentFor(a.source);
            return (u && (c.source = u), c);
          }),
          (t.toJSON = function () {
            for (var e = {}, t = 0, r = ["hasBOM", "css", "file", "id"]; t < r.length; t++) {
              var n = r[t];
              null != this[n] && (e[n] = this[n]);
            }
            return (
              this.map && ((e.map = S({}, this.map)), e.map.consumerCache && (e.map.consumerCache = void 0)),
              e
            );
          }),
          I(e, [
            {
              key: "from",
              get: function () {
                return this.file || this.id;
              },
            },
          ]),
          e
        );
      })();
    ((e6.default = e6), eP && eP.registerInput && eP.registerInput(e6));
    var e8 = eP.SourceMapConsumer,
      e7 = eP.SourceMapGenerator,
      te = eP.dirname,
      tt = eP.relative,
      tr = eP.resolve,
      tn = eP.sep,
      ti = eP.pathToFileURL,
      to = !!(e8 && e7),
      ts = !!(te && tr && tt && tn),
      ta = (function () {
        function e(e, t, r, n) {
          ((this.stringify = e),
            (this.mapOpts = r.map || {}),
            (this.root = t),
            (this.opts = r),
            (this.css = n),
            (this.originalCSS = n),
            (this.usesFileUrls = !this.mapOpts.from && this.mapOpts.absolute),
            (this.memoizedFileURLs = new Map()),
            (this.memoizedPaths = new Map()),
            (this.memoizedURLs = new Map()));
        }
        var t = e.prototype;
        return (
          (t.addAnnotation = function () {
            var e = this.isInline()
                ? "data:application/json;base64," + this.toBase64(this.map.toString())
                : "string" == typeof this.mapOpts.annotation
                  ? this.mapOpts.annotation
                  : "function" == typeof this.mapOpts.annotation
                    ? this.mapOpts.annotation(this.opts.to, this.root)
                    : this.outputFile() + ".map",
              t = "\n";
            (this.css.includes("\r\n") && (t = "\r\n"),
              (this.css += t + "/*# sourceMappingURL=" + e + " */"));
          }),
          (t.applyPrevMaps = function () {
            for (var e, t = P(this.previous()); !(e = t()).done;) {
              var r = e.value,
                n = this.toUrl(this.path(r.file)),
                i = r.root || te(r.file),
                o = void 0;
              (!1 === this.mapOpts.sourcesContent
                ? (o = new e8(r.text)).sourcesContent && (o.sourcesContent = null)
                : (o = r.consumer()),
                this.map.applySourceMap(o, n, this.toUrl(this.path(i))));
            }
          }),
          (t.clearAnnotation = function () {
            if (!1 !== this.mapOpts.annotation)
              if (this.root)
                for (var e, t = this.root.nodes.length - 1; t >= 0; t--)
                  "comment" === (e = this.root.nodes[t]).type &&
                    0 === e.text.indexOf("# sourceMappingURL=") &&
                    this.root.removeChild(t);
              else this.css && (this.css = this.css.replace(/\n*?\/\*#[\S\s]*?\*\/$/gm, ""));
          }),
          (t.generate = function () {
            if ((this.clearAnnotation(), ts && to && this.isMap())) return this.generateMap();
            var e = "";
            return (
              this.stringify(this.root, function (t) {
                e += t;
              }),
              [e]
            );
          }),
          (t.generateMap = function () {
            if (this.root) this.generateString();
            else if (1 === this.previous().length) {
              var e = this.previous()[0].consumer();
              ((e.file = this.outputFile()), (this.map = e7.fromSourceMap(e, { ignoreInvalidMapping: !0 })));
            } else
              ((this.map = new e7({ file: this.outputFile(), ignoreInvalidMapping: !0 })),
                this.map.addMapping({
                  generated: { column: 0, line: 1 },
                  original: { column: 0, line: 1 },
                  source: this.opts.from ? this.toUrl(this.path(this.opts.from)) : "<no source>",
                }));
            return (this.isSourcesContent() && this.setSourcesContent(),
            this.root && this.previous().length > 0 && this.applyPrevMaps(),
            this.isAnnotation() && this.addAnnotation(),
            this.isInline())
              ? [this.css]
              : [this.css, this.map];
          }),
          (t.generateString = function () {
            var e,
              t,
              r = this;
            ((this.css = ""), (this.map = new e7({ file: this.outputFile(), ignoreInvalidMapping: !0 })));
            var n = 1,
              i = 1,
              o = "<no source>",
              s = { generated: { column: 0, line: 0 }, original: { column: 0, line: 0 }, source: "" };
            this.stringify(this.root, function (a, c, u) {
              if (
                ((r.css += a),
                c &&
                  "end" !== u &&
                  ((s.generated.line = n),
                  (s.generated.column = i - 1),
                  c.source && c.source.start
                    ? ((s.source = r.sourcePath(c)),
                      (s.original.line = c.source.start.line),
                      (s.original.column = c.source.start.column - 1))
                    : ((s.source = o), (s.original.line = 1), (s.original.column = 0)),
                  r.map.addMapping(s)),
                (e = a.match(/\n/g))
                  ? ((n += e.length), (t = a.lastIndexOf("\n")), (i = a.length - t))
                  : (i += a.length),
                c && "start" !== u)
              ) {
                var l = c.parent || { raws: {} };
                (!("decl" === c.type || ("atrule" === c.type && !c.nodes)) ||
                  c !== l.last ||
                  l.raws.semicolon) &&
                  (c.source && c.source.end
                    ? ((s.source = r.sourcePath(c)),
                      (s.original.line = c.source.end.line),
                      (s.original.column = c.source.end.column - 1),
                      (s.generated.line = n),
                      (s.generated.column = i - 2))
                    : ((s.source = o),
                      (s.original.line = 1),
                      (s.original.column = 0),
                      (s.generated.line = n),
                      (s.generated.column = i - 1)),
                  r.map.addMapping(s));
              }
            });
          }),
          (t.isAnnotation = function () {
            return (
              !!this.isInline() ||
              (void 0 !== this.mapOpts.annotation
                ? this.mapOpts.annotation
                : !this.previous().length ||
                  this.previous().some(function (e) {
                    return e.annotation;
                  }))
            );
          }),
          (t.isInline = function () {
            if (void 0 !== this.mapOpts.inline) return this.mapOpts.inline;
            var e = this.mapOpts.annotation;
            return (
              (void 0 === e || !0 === e) &&
              (!this.previous().length ||
                this.previous().some(function (e) {
                  return e.inline;
                }))
            );
          }),
          (t.isMap = function () {
            return void 0 !== this.opts.map ? !!this.opts.map : this.previous().length > 0;
          }),
          (t.isSourcesContent = function () {
            return void 0 !== this.mapOpts.sourcesContent
              ? this.mapOpts.sourcesContent
              : !this.previous().length ||
                  this.previous().some(function (e) {
                    return e.withContent();
                  });
          }),
          (t.outputFile = function () {
            return this.opts.to
              ? this.path(this.opts.to)
              : this.opts.from
                ? this.path(this.opts.from)
                : "to.css";
          }),
          (t.path = function (e) {
            if (this.mapOpts.absolute || 60 === e.charCodeAt(0) || /^\w+:\/\//.test(e)) return e;
            var t = this.memoizedPaths.get(e);
            if (t) return t;
            var r = this.opts.to ? te(this.opts.to) : ".";
            "string" == typeof this.mapOpts.annotation && (r = te(tr(r, this.mapOpts.annotation)));
            var n = tt(r, e);
            return (this.memoizedPaths.set(e, n), n);
          }),
          (t.previous = function () {
            var e = this;
            if (!this.previousMaps)
              if (((this.previousMaps = []), this.root))
                this.root.walk(function (t) {
                  if (t.source && t.source.input.map) {
                    var r = t.source.input.map;
                    e.previousMaps.includes(r) || e.previousMaps.push(r);
                  }
                });
              else {
                var t = new e6(this.originalCSS, this.opts);
                t.map && this.previousMaps.push(t.map);
              }
            return this.previousMaps;
          }),
          (t.setSourcesContent = function () {
            var e = this,
              t = {};
            if (this.root)
              this.root.walk(function (r) {
                if (r.source) {
                  var n = r.source.input.from;
                  if (n && !t[n]) {
                    t[n] = !0;
                    var i = e.usesFileUrls ? e.toFileUrl(n) : e.toUrl(e.path(n));
                    e.map.setSourceContent(i, r.source.input.css);
                  }
                }
              });
            else if (this.css) {
              var r = this.opts.from ? this.toUrl(this.path(this.opts.from)) : "<no source>";
              this.map.setSourceContent(r, this.css);
            }
          }),
          (t.sourcePath = function (e) {
            return this.mapOpts.from
              ? this.toUrl(this.mapOpts.from)
              : this.usesFileUrls
                ? this.toFileUrl(e.source.input.from)
                : this.toUrl(this.path(e.source.input.from));
          }),
          (t.toBase64 = function (e) {
            return _.Buffer.from(e).toString("base64");
          }),
          (t.toFileUrl = function (e) {
            var t = this.memoizedFileURLs.get(e);
            if (t) return t;
            if (ti) {
              var r = ti(e).toString();
              return (this.memoizedFileURLs.set(e, r), r);
            }
            throw Error("`map.absolute` option is not available in this PostCSS build");
          }),
          (t.toUrl = function (e) {
            var t = this.memoizedURLs.get(e);
            if (t) return t;
            "\\" === tn && (e = e.replace(/\\/g, "/"));
            var r = encodeURI(e).replace(/[#?]/g, encodeURIComponent);
            return (this.memoizedURLs.set(e, r), r);
          }),
          e
        );
      })(),
      tc = (function (e) {
        function t(t) {
          var r;
          return (((r = e.call(this, t) || this).type = "comment"), r);
        }
        return (O(t, e), t);
      })(eG);
    tc.default = tc;
    var tu = eN.isClean,
      tl = eN.my,
      tp = (function (e) {
        function t() {
          return e.apply(this, arguments) || this;
        }
        O(t, e);
        var r = t.prototype;
        return (
          (r.append = function () {
            for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
            for (var n, i = P(t); !(n = i()).done;)
              for (var o, s = n.value, a = this.normalize(s, this.last), c = P(a); !(o = c()).done;) {
                var u = o.value;
                this.proxyOf.nodes.push(u);
              }
            return (this.markDirty(), this);
          }),
          (r.cleanRaws = function (t) {
            if ((e.prototype.cleanRaws.call(this, t), this.nodes))
              for (var r, n = P(this.nodes); !(r = n()).done;) r.value.cleanRaws(t);
          }),
          (r.each = function (e) {
            if (this.proxyOf.nodes) {
              for (
                var t, r, n = this.getIterator();
                this.indexes[n] < this.proxyOf.nodes.length &&
                ((t = this.indexes[n]), !1 !== (r = e(this.proxyOf.nodes[t], t)));
              )
                this.indexes[n] += 1;
              return (delete this.indexes[n], r);
            }
          }),
          (r.every = function (e) {
            return this.nodes.every(e);
          }),
          (r.getIterator = function () {
            (this.lastEach || (this.lastEach = 0), this.indexes || (this.indexes = {}), (this.lastEach += 1));
            var e = this.lastEach;
            return ((this.indexes[e] = 0), e);
          }),
          (r.getProxyProcessor = function () {
            return {
              get: function (e, t) {
                if ("proxyOf" === t) return e;
                if (!e[t]) return e[t];
                if ("each" === t || ("string" == typeof t && t.startsWith("walk")))
                  return function () {
                    for (var r = arguments.length, n = Array(r), i = 0; i < r; i++) n[i] = arguments[i];
                    return e[t].apply(
                      e,
                      [].concat(
                        n.map(function (e) {
                          return "function" == typeof e
                            ? function (t, r) {
                                return e(t.toProxy(), r);
                              }
                            : e;
                        }),
                      ),
                    );
                  };
                if ("every" === t || "some" === t)
                  return function (r) {
                    return e[t](function (e) {
                      for (var t = arguments.length, n = Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++)
                        n[i - 1] = arguments[i];
                      return r.apply(void 0, [].concat([e.toProxy()], n));
                    });
                  };
                if ("root" === t)
                  return function () {
                    return e.root().toProxy();
                  };
                else if ("nodes" === t)
                  return e.nodes.map(function (e) {
                    return e.toProxy();
                  });
                else if ("first" === t || "last" === t) return e[t].toProxy();
                else return e[t];
              },
              set: function (e, t, r) {
                return (
                  e[t] === r ||
                  ((e[t] = r), ("name" === t || "params" === t || "selector" === t) && e.markDirty(), !0)
                );
              },
            };
          }),
          (r.index = function (e) {
            return "number" == typeof e ? e : (e.proxyOf && (e = e.proxyOf), this.proxyOf.nodes.indexOf(e));
          }),
          (r.insertAfter = function (e, t) {
            var r,
              n = this.index(e),
              i = this.normalize(t, this.proxyOf.nodes[n]).reverse();
            n = this.index(e);
            for (var o, s = P(i); !(o = s()).done;) {
              var a = o.value;
              this.proxyOf.nodes.splice(n + 1, 0, a);
            }
            for (var c in this.indexes) n < (r = this.indexes[c]) && (this.indexes[c] = r + i.length);
            return (this.markDirty(), this);
          }),
          (r.insertBefore = function (e, t) {
            var r,
              n = this.index(e),
              i = 0 === n && "prepend",
              o = this.normalize(t, this.proxyOf.nodes[n], i).reverse();
            n = this.index(e);
            for (var s, a = P(o); !(s = a()).done;) {
              var c = s.value;
              this.proxyOf.nodes.splice(n, 0, c);
            }
            for (var u in this.indexes) n <= (r = this.indexes[u]) && (this.indexes[u] = r + o.length);
            return (this.markDirty(), this);
          }),
          (r.normalize = function (e, r) {
            var n = this;
            if ("string" == typeof e)
              e = (function e(t) {
                return t.map(function (t) {
                  return (t.nodes && (t.nodes = e(t.nodes)), delete t.source, t);
                });
              })(ix(e).nodes);
            else if (void 0 === e) e = [];
            else if (Array.isArray(e)) {
              e = e.slice(0);
              for (var i, o = P(e); !(i = o()).done;) {
                var s = i.value;
                s.parent && s.parent.removeChild(s, "ignore");
              }
            } else if ("root" === e.type && "document" !== this.type) {
              e = e.nodes.slice(0);
              for (var a, c = P(e); !(a = c()).done;) {
                var u = a.value;
                u.parent && u.parent.removeChild(u, "ignore");
              }
            } else if (e.type) e = [e];
            else if (e.prop) {
              if (void 0 === e.value) throw Error("Value field is missed in node creation");
              ("string" != typeof e.value && (e.value = String(e.value)), (e = [new eW(e)]));
            } else if (e.selector) e = [new iM(e)];
            else if (e.name) e = [new iL(e)];
            else if (e.text) e = [new tc(e)];
            else throw Error("Unknown node type in node creation");
            return e.map(function (e) {
              return (
                e[tl] || t.rebuild(e),
                (e = e.proxyOf).parent && e.parent.removeChild(e),
                e[tu] &&
                  (function e(t) {
                    if (((t[tu] = !1), t.proxyOf.nodes))
                      for (var r, n = P(t.proxyOf.nodes); !(r = n()).done;) e(r.value);
                  })(e),
                void 0 === e.raws.before &&
                  r &&
                  void 0 !== r.raws.before &&
                  (e.raws.before = r.raws.before.replace(/\S/g, "")),
                (e.parent = n.proxyOf),
                e
              );
            });
          }),
          (r.prepend = function () {
            for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
            t = t.reverse();
            for (var n, i = P(t); !(n = i()).done;) {
              for (
                var o, s = n.value, a = this.normalize(s, this.first, "prepend").reverse(), c = P(a);
                !(o = c()).done;
              ) {
                var u = o.value;
                this.proxyOf.nodes.unshift(u);
              }
              for (var l in this.indexes) this.indexes[l] = this.indexes[l] + a.length;
            }
            return (this.markDirty(), this);
          }),
          (r.push = function (e) {
            return ((e.parent = this), this.proxyOf.nodes.push(e), this);
          }),
          (r.removeAll = function () {
            for (var e, t = P(this.proxyOf.nodes); !(e = t()).done;) e.value.parent = void 0;
            return ((this.proxyOf.nodes = []), this.markDirty(), this);
          }),
          (r.removeChild = function (e) {
            var t;
            for (var r in ((e = this.index(e)),
            (this.proxyOf.nodes[e].parent = void 0),
            this.proxyOf.nodes.splice(e, 1),
            this.indexes))
              (t = this.indexes[r]) >= e && (this.indexes[r] = t - 1);
            return (this.markDirty(), this);
          }),
          (r.replaceValues = function (e, t, r) {
            return (
              r || ((r = t), (t = {})),
              this.walkDecls(function (n) {
                (t.props && !t.props.includes(n.prop)) ||
                  ((!t.fast || n.value.includes(t.fast)) && (n.value = n.value.replace(e, r)));
              }),
              this.markDirty(),
              this
            );
          }),
          (r.some = function (e) {
            return this.nodes.some(e);
          }),
          (r.walk = function (e) {
            return this.each(function (t, r) {
              var n;
              try {
                n = e(t, r);
              } catch (e) {
                throw t.addToError(e);
              }
              return (!1 !== n && t.walk && (n = t.walk(e)), n);
            });
          }),
          (r.walkAtRules = function (e, t) {
            return t
              ? A(e, RegExp)
                ? this.walk(function (r, n) {
                    if ("atrule" === r.type && e.test(r.name)) return t(r, n);
                  })
                : this.walk(function (r, n) {
                    if ("atrule" === r.type && r.name === e) return t(r, n);
                  })
              : ((t = e),
                this.walk(function (e, r) {
                  if ("atrule" === e.type) return t(e, r);
                }));
          }),
          (r.walkComments = function (e) {
            return this.walk(function (t, r) {
              if ("comment" === t.type) return e(t, r);
            });
          }),
          (r.walkDecls = function (e, t) {
            return t
              ? A(e, RegExp)
                ? this.walk(function (r, n) {
                    if ("decl" === r.type && e.test(r.prop)) return t(r, n);
                  })
                : this.walk(function (r, n) {
                    if ("decl" === r.type && r.prop === e) return t(r, n);
                  })
              : ((t = e),
                this.walk(function (e, r) {
                  if ("decl" === e.type) return t(e, r);
                }));
          }),
          (r.walkRules = function (e, t) {
            return t
              ? A(e, RegExp)
                ? this.walk(function (r, n) {
                    if ("rule" === r.type && e.test(r.selector)) return t(r, n);
                  })
                : this.walk(function (r, n) {
                    if ("rule" === r.type && r.selector === e) return t(r, n);
                  })
              : ((t = e),
                this.walk(function (e, r) {
                  if ("rule" === e.type) return t(e, r);
                }));
          }),
          I(t, [
            {
              key: "first",
              get: function () {
                if (this.proxyOf.nodes) return this.proxyOf.nodes[0];
              },
            },
            {
              key: "last",
              get: function () {
                if (this.proxyOf.nodes) return this.proxyOf.nodes[this.proxyOf.nodes.length - 1];
              },
            },
          ]),
          t
        );
      })(eG);
    ((tp.registerParse = function (e) {
      ix = e;
    }),
      (tp.registerRule = function (e) {
        iM = e;
      }),
      (tp.registerAtRule = function (e) {
        iL = e;
      }),
      (tp.registerRoot = function (e) {
        iP = e;
      }),
      (tp.default = tp),
      (tp.rebuild = function (e) {
        ("atrule" === e.type
          ? Object.setPrototypeOf(e, iL.prototype)
          : "rule" === e.type
            ? Object.setPrototypeOf(e, iM.prototype)
            : "decl" === e.type
              ? Object.setPrototypeOf(e, eW.prototype)
              : "comment" === e.type
                ? Object.setPrototypeOf(e, tc.prototype)
                : "root" === e.type && Object.setPrototypeOf(e, iP.prototype),
          (e[tl] = !0),
          e.nodes &&
            e.nodes.forEach(function (e) {
              tp.rebuild(e);
            }));
      }));
    var th = (function (e) {
      function t(t) {
        var r;
        return ((r = e.call(this, S({ type: "document" }, t)) || this).nodes || (r.nodes = []), r);
      }
      return (
        O(t, e),
        (t.prototype.toResult = function (e) {
          return (void 0 === e && (e = {}), new iD(new iN(), this, e).stringify());
        }),
        t
      );
    })(tp);
    ((th.registerLazyResult = function (e) {
      iD = e;
    }),
      (th.registerProcessor = function (e) {
        iN = e;
      }),
      (th.default = th));
    var td = (function () {
      function e(e, t) {
        if ((void 0 === t && (t = {}), (this.type = "warning"), (this.text = e), t.node && t.node.source)) {
          var r = t.node.rangeBy(t);
          ((this.line = r.start.line),
            (this.column = r.start.column),
            (this.endLine = r.end.line),
            (this.endColumn = r.end.column));
        }
        for (var n in t) this[n] = t[n];
      }
      return (
        (e.prototype.toString = function () {
          return this.node
            ? this.node.error(this.text, { index: this.index, plugin: this.plugin, word: this.word }).message
            : this.plugin
              ? this.plugin + ": " + this.text
              : this.text;
        }),
        e
      );
    })();
    td.default = td;
    var tf = (function () {
      function e(e, t, r) {
        ((this.processor = e),
          (this.messages = []),
          (this.root = t),
          (this.opts = r),
          (this.css = void 0),
          (this.map = void 0));
      }
      var t = e.prototype;
      return (
        (t.toString = function () {
          return this.css;
        }),
        (t.warn = function (e, t) {
          (void 0 === t && (t = {}),
            !t.plugin &&
              this.lastPlugin &&
              this.lastPlugin.postcssPlugin &&
              (t.plugin = this.lastPlugin.postcssPlugin));
          var r = new td(e, t);
          return (this.messages.push(r), r);
        }),
        (t.warnings = function () {
          return this.messages.filter(function (e) {
            return "warning" === e.type;
          });
        }),
        I(e, [
          {
            key: "content",
            get: function () {
              return this.css;
            },
          },
        ]),
        e
      );
    })();
    tf.default = tf;
    var tg = /[\t\n\f\r "#'()/;[\\\]{}]/g,
      tm = /[\t\n\f\r !"#'():;@[\\\]{}]|\/(?=\*)/g,
      t_ = /.[\r\n"'(/\\]/,
      tv = /[\da-f]/i,
      ty = (function (e) {
        function t(t) {
          var r;
          return (((r = e.call(this, t) || this).type = "atrule"), r);
        }
        O(t, e);
        var r = t.prototype;
        return (
          (r.append = function () {
            for (var t, r = arguments.length, n = Array(r), i = 0; i < r; i++) n[i] = arguments[i];
            return (
              this.proxyOf.nodes || (this.nodes = []),
              (t = e.prototype.append).call.apply(t, [].concat([this], n))
            );
          }),
          (r.prepend = function () {
            for (var t, r = arguments.length, n = Array(r), i = 0; i < r; i++) n[i] = arguments[i];
            return (
              this.proxyOf.nodes || (this.nodes = []),
              (t = e.prototype.prepend).call.apply(t, [].concat([this], n))
            );
          }),
          t
        );
      })(tp);
    ((ty.default = ty), tp.registerAtRule(ty));
    var tb = (function (e) {
      function t(t) {
        var r;
        return (((r = e.call(this, t) || this).type = "root"), r.nodes || (r.nodes = []), r);
      }
      O(t, e);
      var r = t.prototype;
      return (
        (r.normalize = function (t, r, n) {
          var i = e.prototype.normalize.call(this, t);
          if (r) {
            if ("prepend" === n)
              this.nodes.length > 1 ? (r.raws.before = this.nodes[1].raws.before) : delete r.raws.before;
            else if (this.first !== r)
              for (var o, s = P(i); !(o = s()).done;) o.value.raws.before = r.raws.before;
          }
          return i;
        }),
        (r.removeChild = function (t, r) {
          var n = this.index(t);
          return (
            !r && 0 === n && this.nodes.length > 1 && (this.nodes[1].raws.before = this.nodes[n].raws.before),
            e.prototype.removeChild.call(this, t)
          );
        }),
        (r.toResult = function (e) {
          return (void 0 === e && (e = {}), new iF(new iU(), this, e).stringify());
        }),
        t
      );
    })(tp);
    ((tb.registerLazyResult = function (e) {
      iF = e;
    }),
      (tb.registerProcessor = function (e) {
        iU = e;
      }),
      (tb.default = tb),
      tp.registerRoot(tb));
    var tC = {
      comma: function (e) {
        return tC.split(e, [","], !0);
      },
      space: function (e) {
        return tC.split(e, [" ", "\n", "	"]);
      },
      split: function (e, t, r) {
        for (var n, i = [], o = "", s = !1, a = 0, c = !1, u = "", l = !1, p = P(e); !(n = p()).done;) {
          var h = n.value;
          (l
            ? (l = !1)
            : "\\" === h
              ? (l = !0)
              : c
                ? h === u && (c = !1)
                : '"' === h || "'" === h
                  ? ((c = !0), (u = h))
                  : "(" === h
                    ? (a += 1)
                    : ")" === h
                      ? a > 0 && (a -= 1)
                      : 0 === a && t.includes(h) && (s = !0),
            s ? ("" !== o && i.push(o.trim()), (o = ""), (s = !1)) : (o += h));
        }
        return ((r || "" !== o) && i.push(o.trim()), i);
      },
    };
    tC.default = tC;
    var tE = (function (e) {
      function t(t) {
        var r;
        return (((r = e.call(this, t) || this).type = "rule"), r.nodes || (r.nodes = []), r);
      }
      return (
        O(t, e),
        I(t, [
          {
            key: "selectors",
            get: function () {
              return tC.comma(this.selector);
            },
            set: function (e) {
              var t = this.selector ? this.selector.match(/,\s*/) : null,
                r = t ? t[0] : "," + this.raw("between", "beforeOpen");
              this.selector = e.join(r);
            },
          },
        ]),
        t
      );
    })(tp);
    ((tE.default = tE), tp.registerRule(tE));
    var tw = function (e, t) {
        void 0 === t && (t = {});
        var r,
          n,
          i,
          o,
          s,
          a,
          c,
          u,
          l,
          p,
          h = e.css.valueOf(),
          d = t.ignoreErrors,
          f = h.length,
          g = 0,
          m = [],
          _ = [];
        function v(t) {
          throw e.error("Unclosed " + t, g);
        }
        return {
          back: function (e) {
            _.push(e);
          },
          endOfFile: function () {
            return 0 === _.length && g >= f;
          },
          nextToken: function (e) {
            if (_.length) return _.pop();
            if (!(g >= f)) {
              var t = !!e && e.ignoreUnclosed;
              switch ((r = h.charCodeAt(g))) {
                case 10:
                case 32:
                case 9:
                case 13:
                case 12:
                  n = g;
                  do ((n += 1), (r = h.charCodeAt(n)));
                  while (32 === r || 10 === r || 9 === r || 13 === r || 12 === r);
                  ((p = ["space", h.slice(g, n)]), (g = n - 1));
                  break;
                case 91:
                case 93:
                case 123:
                case 125:
                case 58:
                case 59:
                case 41:
                  var y = String.fromCharCode(r);
                  p = [y, y, g];
                  break;
                case 40:
                  if (
                    ((u = m.length ? m.pop()[1] : ""),
                    (l = h.charCodeAt(g + 1)),
                    "url" === u &&
                      39 !== l &&
                      34 !== l &&
                      32 !== l &&
                      10 !== l &&
                      9 !== l &&
                      12 !== l &&
                      13 !== l)
                  ) {
                    n = g;
                    do {
                      if (((a = !1), -1 === (n = h.indexOf(")", n + 1))))
                        if (d || t) {
                          n = g;
                          break;
                        } else v("bracket");
                      for (c = n; 92 === h.charCodeAt(c - 1);) ((c -= 1), (a = !a));
                    } while (a);
                    ((p = ["brackets", h.slice(g, n + 1), g, n]), (g = n));
                  } else
                    ((n = h.indexOf(")", g + 1)),
                      (o = h.slice(g, n + 1)),
                      -1 === n || t_.test(o) ? (p = ["(", "(", g]) : ((p = ["brackets", o, g, n]), (g = n)));
                  break;
                case 39:
                case 34:
                  ((i = 39 === r ? "'" : '"'), (n = g));
                  do {
                    if (((a = !1), -1 === (n = h.indexOf(i, n + 1))))
                      if (d || t) {
                        n = g + 1;
                        break;
                      } else v("string");
                    for (c = n; 92 === h.charCodeAt(c - 1);) ((c -= 1), (a = !a));
                  } while (a);
                  ((p = ["string", h.slice(g, n + 1), g, n]), (g = n));
                  break;
                case 64:
                  ((tg.lastIndex = g + 1),
                    tg.test(h),
                    (n = 0 === tg.lastIndex ? h.length - 1 : tg.lastIndex - 2),
                    (p = ["at-word", h.slice(g, n + 1), g, n]),
                    (g = n));
                  break;
                case 92:
                  for (n = g, s = !0; 92 === h.charCodeAt(n + 1);) ((n += 1), (s = !s));
                  if (
                    ((r = h.charCodeAt(n + 1)),
                    s &&
                      47 !== r &&
                      32 !== r &&
                      10 !== r &&
                      9 !== r &&
                      13 !== r &&
                      12 !== r &&
                      ((n += 1), tv.test(h.charAt(n))))
                  ) {
                    for (; tv.test(h.charAt(n + 1));) n += 1;
                    32 === h.charCodeAt(n + 1) && (n += 1);
                  }
                  ((p = ["word", h.slice(g, n + 1), g, n]), (g = n));
                  break;
                default:
                  (47 === r && 42 === h.charCodeAt(g + 1)
                    ? (0 === (n = h.indexOf("*/", g + 2) + 1) && (d || t ? (n = h.length) : v("comment")),
                      (p = ["comment", h.slice(g, n + 1), g, n]))
                    : ((tm.lastIndex = g + 1),
                      tm.test(h),
                      (n = 0 === tm.lastIndex ? h.length - 1 : tm.lastIndex - 2),
                      (p = ["word", h.slice(g, n + 1), g, n]),
                      m.push(p)),
                    (g = n));
              }
              return (g++, p);
            }
          },
          position: function () {
            return g;
          },
        };
      },
      tI = { empty: !0, space: !0 },
      tS = (function () {
        function e(e) {
          ((this.input = e),
            (this.root = new tb()),
            (this.current = this.root),
            (this.spaces = ""),
            (this.semicolon = !1),
            this.createTokenizer(),
            (this.root.source = { input: e, start: { column: 1, line: 1, offset: 0 } }));
        }
        var t = e.prototype;
        return (
          (t.atrule = function (e) {
            var t,
              r,
              n,
              i = new ty();
            ((i.name = e[1].slice(1)), "" === i.name && this.unnamedAtrule(i, e), this.init(i, e[2]));
            for (var o = !1, s = !1, a = [], c = []; !this.tokenizer.endOfFile();) {
              if (
                ("(" === (t = (e = this.tokenizer.nextToken())[0]) || "[" === t
                  ? c.push("(" === t ? ")" : "]")
                  : "{" === t && c.length > 0
                    ? c.push("}")
                    : t === c[c.length - 1] && c.pop(),
                0 === c.length)
              )
                if (";" === t) {
                  ((i.source.end = this.getPosition(e[2])), i.source.end.offset++, (this.semicolon = !0));
                  break;
                } else if ("{" === t) {
                  s = !0;
                  break;
                } else if ("}" === t) {
                  if (a.length > 0) {
                    for (n = a.length - 1, r = a[n]; r && "space" === r[0];) r = a[--n];
                    r && ((i.source.end = this.getPosition(r[3] || r[2])), i.source.end.offset++);
                  }
                  this.end(e);
                  break;
                } else a.push(e);
              else a.push(e);
              if (this.tokenizer.endOfFile()) {
                o = !0;
                break;
              }
            }
            ((i.raws.between = this.spacesAndCommentsFromEnd(a)),
              a.length
                ? ((i.raws.afterName = this.spacesAndCommentsFromStart(a)),
                  this.raw(i, "params", a),
                  o &&
                    ((e = a[a.length - 1]),
                    (i.source.end = this.getPosition(e[3] || e[2])),
                    i.source.end.offset++,
                    (this.spaces = i.raws.between),
                    (i.raws.between = "")))
                : ((i.raws.afterName = ""), (i.params = "")),
              s && ((i.nodes = []), (this.current = i)));
          }),
          (t.checkMissedSemicolon = function (e) {
            var t,
              r = this.colon(e);
            if (!1 !== r) {
              for (var n = 0, i = r - 1; i >= 0 && ("space" === (t = e[i])[0] || 2 !== (n += 1)); i--);
              throw this.input.error("Missed semicolon", "word" === t[0] ? t[3] + 1 : t[2]);
            }
          }),
          (t.colon = function (e) {
            for (var t, r, n, i = 0, o = P(e.entries()); !(n = o()).done;) {
              var s = n.value,
                a = s[0],
                c = s[1];
              if (("(" === (t = c[0]) && (i += 1), ")" === t && (i -= 1), 0 === i && ":" === t))
                if (r)
                  if ("word" === r[0] && "progid" === r[1]) continue;
                  else return a;
                else this.doubleColon(c);
              r = c;
            }
            return !1;
          }),
          (t.comment = function (e) {
            var t = new tc();
            (this.init(t, e[2]), (t.source.end = this.getPosition(e[3] || e[2])), t.source.end.offset++);
            var r = e[1].slice(2, -2);
            if (/^\s*$/.test(r)) ((t.text = ""), (t.raws.left = r), (t.raws.right = ""));
            else {
              var n = r.match(/^(\s*)([^]*\S)(\s*)$/);
              ((t.text = n[2]), (t.raws.left = n[1]), (t.raws.right = n[3]));
            }
          }),
          (t.createTokenizer = function () {
            this.tokenizer = tw(this.input);
          }),
          (t.decl = function (e, t) {
            var r,
              n,
              i = new eW();
            this.init(i, e[0][2]);
            var o = e[e.length - 1];
            for (
              ";" === o[0] && ((this.semicolon = !0), e.pop()),
                i.source.end = this.getPosition(
                  o[3] ||
                    o[2] ||
                    (function (e) {
                      for (var t = e.length - 1; t >= 0; t--) {
                        var r = e[t],
                          n = r[3] || r[2];
                        if (n) return n;
                      }
                    })(e),
                ),
                i.source.end.offset++;
              "word" !== e[0][0];
            )
              (1 === e.length && this.unknownWord(e), (i.raws.before += e.shift()[1]));
            for (i.source.start = this.getPosition(e[0][2]), i.prop = ""; e.length;) {
              var s = e[0][0];
              if (":" === s || "space" === s || "comment" === s) break;
              i.prop += e.shift()[1];
            }
            for (i.raws.between = ""; e.length;) {
              if (":" === (r = e.shift())[0]) {
                i.raws.between += r[1];
                break;
              }
              ("word" === r[0] && /\w/.test(r[1]) && this.unknownWord([r]), (i.raws.between += r[1]));
            }
            ("_" === i.prop[0] || "*" === i.prop[0]) &&
              ((i.raws.before += i.prop[0]), (i.prop = i.prop.slice(1)));
            for (var a = []; e.length && ("space" === (n = e[0][0]) || "comment" === n);) a.push(e.shift());
            this.precheckMissedSemicolon(e);
            for (var c = e.length - 1; c >= 0; c--) {
              if ("!important" === (r = e[c])[1].toLowerCase()) {
                i.important = !0;
                var u = this.stringFrom(e, c);
                " !important" !== (u = this.spacesFromEnd(e) + u) && (i.raws.important = u);
                break;
              }
              if ("important" === r[1].toLowerCase()) {
                for (var l = e.slice(0), p = "", h = c; h > 0; h--) {
                  var d = l[h][0];
                  if (0 === p.trim().indexOf("!") && "space" !== d) break;
                  p = l.pop()[1] + p;
                }
                0 === p.trim().indexOf("!") && ((i.important = !0), (i.raws.important = p), (e = l));
              }
              if ("space" !== r[0] && "comment" !== r[0]) break;
            }
            (e.some(function (e) {
              return "space" !== e[0] && "comment" !== e[0];
            }) &&
              ((i.raws.between += a
                .map(function (e) {
                  return e[1];
                })
                .join("")),
              (a = [])),
              this.raw(i, "value", a.concat(e), t),
              i.value.includes(":") && !t && this.checkMissedSemicolon(e));
          }),
          (t.doubleColon = function (e) {
            throw this.input.error("Double colon", { offset: e[2] }, { offset: e[2] + e[1].length });
          }),
          (t.emptyRule = function (e) {
            var t = new tE();
            (this.init(t, e[2]), (t.selector = ""), (t.raws.between = ""), (this.current = t));
          }),
          (t.end = function (e) {
            (this.current.nodes &&
              this.current.nodes.length &&
              (this.current.raws.semicolon = this.semicolon),
              (this.semicolon = !1),
              (this.current.raws.after = (this.current.raws.after || "") + this.spaces),
              (this.spaces = ""),
              this.current.parent
                ? ((this.current.source.end = this.getPosition(e[2])),
                  this.current.source.end.offset++,
                  (this.current = this.current.parent))
                : this.unexpectedClose(e));
          }),
          (t.endFile = function () {
            (this.current.parent && this.unclosedBlock(),
              this.current.nodes &&
                this.current.nodes.length &&
                (this.current.raws.semicolon = this.semicolon),
              (this.current.raws.after = (this.current.raws.after || "") + this.spaces),
              (this.root.source.end = this.getPosition(this.tokenizer.position())));
          }),
          (t.freeSemicolon = function (e) {
            if (((this.spaces += e[1]), this.current.nodes)) {
              var t = this.current.nodes[this.current.nodes.length - 1];
              t &&
                "rule" === t.type &&
                !t.raws.ownSemicolon &&
                ((t.raws.ownSemicolon = this.spaces), (this.spaces = ""));
            }
          }),
          (t.getPosition = function (e) {
            var t = this.input.fromOffset(e);
            return { column: t.col, line: t.line, offset: e };
          }),
          (t.init = function (e, t) {
            (this.current.push(e),
              (e.source = { input: this.input, start: this.getPosition(t) }),
              (e.raws.before = this.spaces),
              (this.spaces = ""),
              "comment" !== e.type && (this.semicolon = !1));
          }),
          (t.other = function (e) {
            for (
              var t = !1, r = null, n = !1, i = null, o = [], s = e[1].startsWith("--"), a = [], c = e;
              c;
            ) {
              if (((r = c[0]), a.push(c), "(" === r || "[" === r))
                (i || (i = c), o.push("(" === r ? ")" : "]"));
              else if (s && n && "{" === r) (i || (i = c), o.push("}"));
              else if (0 === o.length)
                if (";" === r)
                  if (n) return void this.decl(a, s);
                  else break;
                else if ("{" === r) return void this.rule(a);
                else if ("}" === r) {
                  (this.tokenizer.back(a.pop()), (t = !0));
                  break;
                } else ":" === r && (n = !0);
              else r === o[o.length - 1] && (o.pop(), 0 === o.length && (i = null));
              c = this.tokenizer.nextToken();
            }
            if ((this.tokenizer.endOfFile() && (t = !0), o.length > 0 && this.unclosedBracket(i), t && n)) {
              if (!s)
                for (; a.length && ("space" === (c = a[a.length - 1][0]) || "comment" === c);)
                  this.tokenizer.back(a.pop());
              this.decl(a, s);
            } else this.unknownWord(a);
          }),
          (t.parse = function () {
            for (var e; !this.tokenizer.endOfFile();)
              switch ((e = this.tokenizer.nextToken())[0]) {
                case "space":
                  this.spaces += e[1];
                  break;
                case ";":
                  this.freeSemicolon(e);
                  break;
                case "}":
                  this.end(e);
                  break;
                case "comment":
                  this.comment(e);
                  break;
                case "at-word":
                  this.atrule(e);
                  break;
                case "{":
                  this.emptyRule(e);
                  break;
                default:
                  this.other(e);
              }
            this.endFile();
          }),
          (t.precheckMissedSemicolon = function () {}),
          (t.raw = function (e, t, r, n) {
            for (var i, o, s, a, c = r.length, u = "", l = !0, p = 0; p < c; p += 1)
              "space" !== (o = (i = r[p])[0]) || p !== c - 1 || n
                ? "comment" === o
                  ? ((a = r[p - 1] ? r[p - 1][0] : "empty"),
                    (s = r[p + 1] ? r[p + 1][0] : "empty"),
                    tI[a] || tI[s] || "," === u.slice(-1) ? (l = !1) : (u += i[1]))
                  : (u += i[1])
                : (l = !1);
            if (!l) {
              var h = r.reduce(function (e, t) {
                return e + t[1];
              }, "");
              e.raws[t] = { raw: h, value: u };
            }
            e[t] = u;
          }),
          (t.rule = function (e) {
            e.pop();
            var t = new tE();
            (this.init(t, e[0][2]),
              (t.raws.between = this.spacesAndCommentsFromEnd(e)),
              this.raw(t, "selector", e),
              (this.current = t));
          }),
          (t.spacesAndCommentsFromEnd = function (e) {
            for (var t, r = ""; e.length && ("space" === (t = e[e.length - 1][0]) || "comment" === t);)
              r = e.pop()[1] + r;
            return r;
          }),
          (t.spacesAndCommentsFromStart = function (e) {
            for (var t, r = ""; e.length && ("space" === (t = e[0][0]) || "comment" === t);)
              r += e.shift()[1];
            return r;
          }),
          (t.spacesFromEnd = function (e) {
            for (var t = ""; e.length && "space" === e[e.length - 1][0];) t = e.pop()[1] + t;
            return t;
          }),
          (t.stringFrom = function (e, t) {
            for (var r = "", n = t; n < e.length; n++) r += e[n][1];
            return (e.splice(t, e.length - t), r);
          }),
          (t.unclosedBlock = function () {
            var e = this.current.source.start;
            throw this.input.error("Unclosed block", e.line, e.column);
          }),
          (t.unclosedBracket = function (e) {
            throw this.input.error("Unclosed bracket", { offset: e[2] }, { offset: e[2] + 1 });
          }),
          (t.unexpectedClose = function (e) {
            throw this.input.error("Unexpected }", { offset: e[2] }, { offset: e[2] + 1 });
          }),
          (t.unknownWord = function (e) {
            throw this.input.error("Unknown word", { offset: e[0][2] }, { offset: e[0][2] + e[0][1].length });
          }),
          (t.unnamedAtrule = function (e, t) {
            throw this.input.error("At-rule without name", { offset: t[2] }, { offset: t[2] + t[1].length });
          }),
          e
        );
      })();
    function tk(e, t) {
      var r = new tS(new e6(e, t));
      try {
        r.parse();
      } catch (e) {
        throw e;
      }
      return r.root;
    }
    ((tk.default = tk), tp.registerParse(tk));
    var tO = eN.isClean,
      tA = eN.my,
      tR = {
        atrule: "AtRule",
        comment: "Comment",
        decl: "Declaration",
        document: "Document",
        root: "Root",
        rule: "Rule",
      },
      tT = {
        AtRule: !0,
        AtRuleExit: !0,
        Comment: !0,
        CommentExit: !0,
        Declaration: !0,
        DeclarationExit: !0,
        Document: !0,
        DocumentExit: !0,
        Once: !0,
        OnceExit: !0,
        postcssPlugin: !0,
        prepare: !0,
        Root: !0,
        RootExit: !0,
        Rule: !0,
        RuleExit: !0,
      },
      tx = { Once: !0, postcssPlugin: !0, prepare: !0 };
    function tM(e) {
      return (void 0 === e ? "undefined" : x(e)) === "object" && "function" == typeof e.then;
    }
    function tL(e) {
      var t = !1,
        r = tR[e.type];
      return ("decl" === e.type
        ? (t = e.prop.toLowerCase())
        : "atrule" === e.type && (t = e.name.toLowerCase()),
      t && e.append)
        ? [r, r + "-" + t, 0, r + "Exit", r + "Exit-" + t]
        : t
          ? [r, r + "-" + t, r + "Exit", r + "Exit-" + t]
          : e.append
            ? [r, 0, r + "Exit"]
            : [r, r + "Exit"];
    }
    function tP(e) {
      return {
        eventIndex: 0,
        events:
          "document" === e.type
            ? ["Document", 0, "DocumentExit"]
            : "root" === e.type
              ? ["Root", 0, "RootExit"]
              : tL(e),
        iterator: 0,
        node: e,
        visitorIndex: 0,
        visitors: [],
      };
    }
    function tD(e) {
      return (
        (e[tO] = !1),
        e.nodes &&
          e.nodes.forEach(function (e) {
            return tD(e);
          }),
        e
      );
    }
    var tN = {},
      tF = (function () {
        function e(t, r, n) {
          var i,
            o = this;
          if (
            ((this.stringified = !1),
            (this.processed = !1),
            (void 0 === r ? "undefined" : x(r)) === "object" &&
              null !== r &&
              ("root" === r.type || "document" === r.type))
          )
            i = tD(r);
          else if (A(r, e) || A(r, tf))
            ((i = tD(r.root)),
              r.map &&
                (void 0 === n.map && (n.map = {}),
                n.map.inline || (n.map.inline = !1),
                (n.map.prev = r.map)));
          else {
            var s = tk;
            (n.syntax && (s = n.syntax.parse), n.parser && (s = n.parser), s.parse && (s = s.parse));
            try {
              i = s(r, n);
            } catch (e) {
              ((this.processed = !0), (this.error = e));
            }
            i && !i[tA] && tp.rebuild(i);
          }
          ((this.result = new tf(t, i, n)),
            (this.helpers = S({}, tN, { postcss: tN, result: this.result })),
            (this.plugins = this.processor.plugins.map(function (e) {
              return (void 0 === e ? "undefined" : x(e)) === "object" && e.prepare
                ? S({}, e, e.prepare(o.result))
                : e;
            })));
        }
        var t = e.prototype;
        return (
          (t.async = function () {
            return this.error
              ? Promise.reject(this.error)
              : this.processed
                ? Promise.resolve(this.result)
                : (this.processing || (this.processing = this.runAsync()), this.processing);
          }),
          (t.catch = function (e) {
            return this.async().catch(e);
          }),
          (t.finally = function (e) {
            return this.async().then(e, e);
          }),
          (t.getAsyncError = function () {
            throw Error("Use process(css).then(cb) to work with async plugins");
          }),
          (t.handleError = function (e, t) {
            var r = this.result.lastPlugin;
            try {
              (t && t.addToError(e),
                (this.error = e),
                "CssSyntaxError" !== e.name || e.plugin
                  ? r.postcssVersion
                  : ((e.plugin = r.postcssPlugin), e.setMessage()));
            } catch (e) {
              console && console.error && console.error(e);
            }
            return e;
          }),
          (t.prepareVisitors = function () {
            var e = this;
            this.listeners = {};
            for (
              var t,
                r = function (t, r, n) {
                  (e.listeners[r] || (e.listeners[r] = []), e.listeners[r].push([t, n]));
                },
                n = P(this.plugins);
              !(t = n()).done;
            ) {
              var i = t.value;
              if ((void 0 === i ? "undefined" : x(i)) === "object")
                for (var o in i) {
                  if (!tT[o] && /^[A-Z]/.test(o))
                    throw Error(
                      "Unknown event " +
                        o +
                        " in " +
                        i.postcssPlugin +
                        ". Try to update PostCSS (" +
                        this.processor.version +
                        " now).",
                    );
                  if (!tx[o])
                    if ("object" === x(i[o]))
                      for (var s in i[o]) r(i, "*" === s ? o : o + "-" + s.toLowerCase(), i[o][s]);
                    else "function" == typeof i[o] && r(i, o, i[o]);
                }
            }
            this.hasListener = Object.keys(this.listeners).length > 0;
          }),
          (t.runAsync = function () {
            var e = this;
            return E(function () {
              var t, r, n, i, o, s, a, c, u, l, p, h;
              return D(this, function (d) {
                switch (d.label) {
                  case 0:
                    ((e.plugin = 0), (t = 0), (d.label = 1));
                  case 1:
                    if (!(t < e.plugins.length)) return [3, 6];
                    if (((r = e.plugins[t]), !tM((n = e.runOnRoot(r))))) return [3, 5];
                    d.label = 2;
                  case 2:
                    return (d.trys.push([2, 4, , 5]), [4, n]);
                  case 3:
                    return (d.sent(), [3, 5]);
                  case 4:
                    throw ((i = d.sent()), e.handleError(i));
                  case 5:
                    return (t++, [3, 1]);
                  case 6:
                    if ((e.prepareVisitors(), !e.hasListener)) return [3, 18];
                    ((o = e.result.root), (d.label = 7));
                  case 7:
                    if (o[tO]) return [3, 14];
                    ((o[tO] = !0), (s = [tP(o)]), (d.label = 8));
                  case 8:
                    if (!(s.length > 0)) return [3, 13];
                    if (!tM((a = e.visitTick(s)))) return [3, 12];
                    d.label = 9;
                  case 9:
                    return (d.trys.push([9, 11, , 12]), [4, a]);
                  case 10:
                    return (d.sent(), [3, 12]);
                  case 11:
                    throw ((c = d.sent()), (u = s[s.length - 1].node), e.handleError(c, u));
                  case 12:
                    return [3, 8];
                  case 13:
                    return [3, 7];
                  case 14:
                    if (!e.listeners.OnceExit) return [3, 18];
                    ((l = function () {
                      var t, r, n, i;
                      return D(this, function (s) {
                        switch (s.label) {
                          case 0:
                            ((r = (t = h.value)[0]), (n = t[1]), (e.result.lastPlugin = r), (s.label = 1));
                          case 1:
                            if ((s.trys.push([1, 6, , 7]), "document" !== o.type)) return [3, 3];
                            return [
                              4,
                              Promise.all(
                                o.nodes.map(function (t) {
                                  return n(t, e.helpers);
                                }),
                              ),
                            ];
                          case 2:
                            return (s.sent(), [3, 5]);
                          case 3:
                            return [4, n(o, e.helpers)];
                          case 4:
                            (s.sent(), (s.label = 5));
                          case 5:
                            return [3, 7];
                          case 6:
                            throw ((i = s.sent()), e.handleError(i));
                          case 7:
                            return [2];
                        }
                      });
                    }),
                      (p = P(e.listeners.OnceExit)),
                      (d.label = 15));
                  case 15:
                    if ((h = p()).done) return [3, 18];
                    return [5, N(l())];
                  case 16:
                    (d.sent(), (d.label = 17));
                  case 17:
                    return [3, 15];
                  case 18:
                    return ((e.processed = !0), [2, e.stringify()]);
                }
              });
            })();
          }),
          (t.runOnRoot = function (e) {
            var t = this;
            this.result.lastPlugin = e;
            try {
              if ((void 0 === e ? "undefined" : x(e)) === "object" && e.Once) {
                if ("document" === this.result.root.type) {
                  var r = this.result.root.nodes.map(function (r) {
                    return e.Once(r, t.helpers);
                  });
                  if (tM(r[0])) return Promise.all(r);
                  return r;
                }
                return e.Once(this.result.root, this.helpers);
              }
              if ("function" == typeof e) return e(this.result.root, this.result);
            } catch (e) {
              throw this.handleError(e);
            }
          }),
          (t.stringify = function () {
            if (this.error) throw this.error;
            if (this.stringified) return this.result;
            ((this.stringified = !0), this.sync());
            var e = this.result.opts,
              t = eB;
            (e.syntax && (t = e.syntax.stringify),
              e.stringifier && (t = e.stringifier),
              t.stringify && (t = t.stringify));
            var r = new ta(t, this.result.root, this.result.opts).generate();
            return ((this.result.css = r[0]), (this.result.map = r[1]), this.result);
          }),
          (t.sync = function () {
            if (this.error) throw this.error;
            if (this.processed) return this.result;
            if (((this.processed = !0), this.processing)) throw this.getAsyncError();
            for (var e, t = P(this.plugins); !(e = t()).done;) {
              var r = e.value;
              if (tM(this.runOnRoot(r))) throw this.getAsyncError();
            }
            if ((this.prepareVisitors(), this.hasListener)) {
              for (var n = this.result.root; !n[tO];) ((n[tO] = !0), this.walkSync(n));
              if (this.listeners.OnceExit)
                if ("document" === n.type)
                  for (var i, o = P(n.nodes); !(i = o()).done;) {
                    var s = i.value;
                    this.visitSync(this.listeners.OnceExit, s);
                  }
                else this.visitSync(this.listeners.OnceExit, n);
            }
            return this.result;
          }),
          (t.then = function (e, t) {
            return this.async().then(e, t);
          }),
          (t.toString = function () {
            return this.css;
          }),
          (t.visitSync = function (e, t) {
            for (var r, n = P(e); !(r = n()).done;) {
              var i = r.value,
                o = i[0],
                s = i[1];
              this.result.lastPlugin = o;
              var a = void 0;
              try {
                a = s(t, this.helpers);
              } catch (e) {
                throw this.handleError(e, t.proxyOf);
              }
              if ("root" !== t.type && "document" !== t.type && !t.parent) return !0;
              if (tM(a)) throw this.getAsyncError();
            }
          }),
          (t.visitTick = function (e) {
            var t = e[e.length - 1],
              r = t.node,
              n = t.visitors;
            if ("root" !== r.type && "document" !== r.type && !r.parent) return void e.pop();
            if (n.length > 0 && t.visitorIndex < n.length) {
              var i = n[t.visitorIndex],
                o = i[0],
                s = i[1];
              ((t.visitorIndex += 1),
                t.visitorIndex === n.length && ((t.visitors = []), (t.visitorIndex = 0)),
                (this.result.lastPlugin = o));
              try {
                return s(r.toProxy(), this.helpers);
              } catch (e) {
                throw this.handleError(e, r);
              }
            }
            if (0 !== t.iterator) {
              for (var a, c = t.iterator; (a = r.nodes[r.indexes[c]]);)
                if (((r.indexes[c] += 1), !a[tO])) {
                  ((a[tO] = !0), e.push(tP(a)));
                  return;
                }
              ((t.iterator = 0), delete r.indexes[c]);
            }
            for (var u = t.events; t.eventIndex < u.length;) {
              var l = u[t.eventIndex];
              if (((t.eventIndex += 1), 0 === l)) {
                r.nodes && r.nodes.length && ((r[tO] = !0), (t.iterator = r.getIterator()));
                return;
              }
              if (this.listeners[l]) {
                t.visitors = this.listeners[l];
                return;
              }
            }
            e.pop();
          }),
          (t.walkSync = function (e) {
            var t = this;
            e[tO] = !0;
            for (var r, n = tL(e), i = P(n); !(r = i()).done;) {
              var o = r.value;
              if (0 === o)
                e.nodes &&
                  e.each(function (e) {
                    e[tO] || t.walkSync(e);
                  });
              else {
                var s = this.listeners[o];
                if (s && this.visitSync(s, e.toProxy())) return;
              }
            }
          }),
          (t.warnings = function () {
            return this.sync().warnings();
          }),
          I(e, [
            {
              key: "content",
              get: function () {
                return this.stringify().content;
              },
            },
            {
              key: "css",
              get: function () {
                return this.stringify().css;
              },
            },
            {
              key: "map",
              get: function () {
                return this.stringify().map;
              },
            },
            {
              key: "messages",
              get: function () {
                return this.sync().messages;
              },
            },
            {
              key: "opts",
              get: function () {
                return this.result.opts;
              },
            },
            {
              key: "processor",
              get: function () {
                return this.result.processor;
              },
            },
            {
              key: "root",
              get: function () {
                return this.sync().root;
              },
            },
            {
              key: Symbol.toStringTag,
              get: function () {
                return "LazyResult";
              },
            },
          ]),
          e
        );
      })();
    ((tF.registerPostcss = function (e) {
      tN = e;
    }),
      (tF.default = tF),
      tb.registerLazyResult(tF),
      th.registerLazyResult(tF));
    var tU = (function () {
      function e(e, t, r) {
        ((t = t.toString()),
          (this.stringified = !1),
          (this._processor = e),
          (this._css = t),
          (this._opts = r),
          (this._map = void 0),
          (this.result = new tf(this._processor, n, this._opts)),
          (this.result.css = t));
        var n,
          i = this;
        Object.defineProperty(this.result, "root", {
          get: function () {
            return i.root;
          },
        });
        var o = new ta(eB, n, this._opts, t);
        if (o.isMap()) {
          var s = o.generate(),
            a = s[0],
            c = s[1];
          (a && (this.result.css = a), c && (this.result.map = c));
        } else (o.clearAnnotation(), (this.result.css = o.css));
      }
      var t = e.prototype;
      return (
        (t.async = function () {
          return this.error ? Promise.reject(this.error) : Promise.resolve(this.result);
        }),
        (t.catch = function (e) {
          return this.async().catch(e);
        }),
        (t.finally = function (e) {
          return this.async().then(e, e);
        }),
        (t.sync = function () {
          if (this.error) throw this.error;
          return this.result;
        }),
        (t.then = function (e, t) {
          return this.async().then(e, t);
        }),
        (t.toString = function () {
          return this._css;
        }),
        (t.warnings = function () {
          return [];
        }),
        I(e, [
          {
            key: "content",
            get: function () {
              return this.result.css;
            },
          },
          {
            key: "css",
            get: function () {
              return this.result.css;
            },
          },
          {
            key: "map",
            get: function () {
              return this.result.map;
            },
          },
          {
            key: "messages",
            get: function () {
              return [];
            },
          },
          {
            key: "opts",
            get: function () {
              return this.result.opts;
            },
          },
          {
            key: "processor",
            get: function () {
              return this.result.processor;
            },
          },
          {
            key: "root",
            get: function () {
              var e;
              if (this._root) return this._root;
              try {
                e = tk(this._css, this._opts);
              } catch (e) {
                this.error = e;
              }
              if (!this.error) return ((this._root = e), e);
              throw this.error;
            },
          },
          {
            key: Symbol.toStringTag,
            get: function () {
              return "NoWorkResult";
            },
          },
        ]),
        e
      );
    })();
    tU.default = tU;
    var tB = (function () {
      function e(e) {
        (void 0 === e && (e = []), (this.version = "8.4.38"), (this.plugins = this.normalize(e)));
      }
      var t = e.prototype;
      return (
        (t.normalize = function (e) {
          for (var t, r = [], n = P(e); !(t = n()).done;) {
            var i = t.value;
            if (
              (!0 === i.postcss ? (i = i()) : i.postcss && (i = i.postcss),
              (void 0 === i ? "undefined" : x(i)) === "object" && Array.isArray(i.plugins))
            )
              r = r.concat(i.plugins);
            else if ((void 0 === i ? "undefined" : x(i)) === "object" && i.postcssPlugin) r.push(i);
            else if ("function" == typeof i) r.push(i);
            else if ((void 0 === i ? "undefined" : x(i)) === "object" && (i.parse || i.stringify));
            else throw Error(i + " is not a PostCSS plugin");
          }
          return r;
        }),
        (t.process = function (e, t) {
          return (void 0 === t && (t = {}), this.plugins.length || t.parser || t.stringifier || t.syntax)
            ? new tF(this, e, t)
            : new tU(this, e, t);
        }),
        (t.use = function (e) {
          return ((this.plugins = this.plugins.concat(this.normalize([e]))), this);
        }),
        e
      );
    })();
    function tj(e, t) {
      if (Array.isArray(e))
        return e.map(function (e) {
          return tj(e);
        });
      var r = e.inputs,
        n = R(e, ["inputs"]);
      if (r) {
        t = [];
        for (var i, o = P(r); !(i = o()).done;) {
          var s = i.value,
            a = S({}, s, { __proto__: e6.prototype });
          (a.map && (a.map = S({}, a.map, { __proto__: eZ.prototype })), t.push(a));
        }
      }
      if (
        (n.nodes &&
          (n.nodes = e.nodes.map(function (e) {
            return tj(e, t);
          })),
        n.source)
      ) {
        var c = n.source,
          u = c.inputId;
        ((n.source = R(c, ["inputId"])), null != u && (n.source.input = t[u]));
      }
      if ("root" === n.type) return new tb(n);
      if ("decl" === n.type) return new eW(n);
      if ("rule" === n.type) return new tE(n);
      if ("comment" === n.type) return new tc(n);
      if ("atrule" === n.type) return new ty(n);
      else throw Error("Unknown node type: " + e.type);
    }
    function tV() {
      for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
      return (1 === t.length && Array.isArray(t[0]) && (t = t[0]), new tB(t));
    }
    ((tB.default = tB),
      tb.registerProcessor(tB),
      th.registerProcessor(tB),
      (tj.default = tj),
      (tV.plugin = function (e, t) {
        var r,
          n = !1;
        function i() {
          for (var r = arguments.length, i = Array(r), o = 0; o < r; o++) i[o] = arguments[o];
          console &&
            console.warn &&
            !n &&
            ((n = !0),
            console.warn(
              e +
                ": postcss.plugin was deprecated. Migration guide:\nhttps://evilmartians.com/chronicles/postcss-8-plugin-migration",
            ),
            v.default.env.LANG &&
              v.default.env.LANG.startsWith("cn") &&
              console.warn(
                e + ": 里面 postcss.plugin 被弃用. 迁移指南:\nhttps://www.w3ctech.com/topic/2226",
              ));
          var s = t.apply(void 0, [].concat(i));
          return ((s.postcssPlugin = e), (s.postcssVersion = new tB().version), s);
        }
        return (
          Object.defineProperty(i, "postcss", {
            get: function () {
              return (r || (r = i()), r);
            },
          }),
          (i.process = function (e, t, r) {
            return tV([i(r)]).process(e, t);
          }),
          i
        );
      }),
      (tV.stringify = eB),
      (tV.parse = tk),
      (tV.fromJSON = tj),
      (tV.list = tC),
      (tV.comment = function (e) {
        return new tc(e);
      }),
      (tV.atRule = function (e) {
        return new ty(e);
      }),
      (tV.decl = function (e) {
        return new eW(e);
      }),
      (tV.rule = function (e) {
        return new tE(e);
      }),
      (tV.root = function (e) {
        return new tb(e);
      }),
      (tV.document = function (e) {
        return new th(e);
      }),
      (tV.CssSyntaxError = eD),
      (tV.Declaration = eW),
      (tV.Container = tp),
      (tV.Processor = tB),
      (tV.Document = th),
      (tV.Comment = tc),
      (tV.Warning = td),
      (tV.AtRule = ty),
      (tV.Result = tf),
      (tV.Input = e6),
      (tV.Rule = tE),
      (tV.Root = tb),
      (tV.Node = eG),
      tF.registerPostcss(tV),
      (tV.default = tV));
    var tG = tV && tV.__esModule && Object.prototype.hasOwnProperty.call(tV, "default") ? tV.default : tV;
    (tG.stringify,
      tG.fromJSON,
      tG.plugin,
      tG.parse,
      tG.list,
      tG.document,
      tG.comment,
      tG.atRule,
      tG.rule,
      tG.decl,
      tG.root,
      tG.CssSyntaxError,
      tG.Declaration,
      tG.Container,
      tG.Processor,
      tG.Document,
      tG.Comment,
      tG.Warning,
      tG.AtRule,
      tG.Result,
      tG.Input,
      tG.Rule,
      tG.Root,
      tG.Node);
    var tW = Object.defineProperty,
      tz = function (e, t, r) {
        var n;
        return (
          (n = (void 0 === t ? "undefined" : x(t)) !== "symbol" ? t + "" : t),
          n in e ? tW(e, n, { enumerable: !0, configurable: !0, writable: !0, value: r }) : (e[n] = r)
        );
      },
      tK = { exports: {} },
      tq = String,
      tY = function () {
        return {
          isColorSupported: !1,
          reset: tq,
          bold: tq,
          dim: tq,
          italic: tq,
          underline: tq,
          inverse: tq,
          hidden: tq,
          strikethrough: tq,
          black: tq,
          red: tq,
          green: tq,
          yellow: tq,
          blue: tq,
          magenta: tq,
          cyan: tq,
          white: tq,
          gray: tq,
          bgBlack: tq,
          bgRed: tq,
          bgGreen: tq,
          bgYellow: tq,
          bgBlue: tq,
          bgMagenta: tq,
          bgCyan: tq,
          bgWhite: tq,
        };
      };
    ((tK.exports = tY()), (tK.exports.createColors = tY));
    var t$ = tK.exports,
      tH = (function (e) {
        if (e.__esModule) return e;
        var t = e.default;
        if ("function" == typeof t) {
          var r = function e() {
            return A(this, e) ? Reflect.construct(t, arguments, this.constructor) : t.apply(this, arguments);
          };
          r.prototype = t.prototype;
        } else r = {};
        return (
          Object.defineProperty(r, "__esModule", { value: !0 }),
          Object.keys(e).forEach(function (t) {
            var n = Object.getOwnPropertyDescriptor(e, t);
            Object.defineProperty(
              r,
              t,
              n.get
                ? n
                : {
                    enumerable: !0,
                    get: function () {
                      return e[t];
                    },
                  },
            );
          }),
          r
        );
      })(
        Object.freeze(
          Object.defineProperty({ __proto__: null, default: {} }, Symbol.toStringTag, { value: "Module" }),
        ),
      ),
      tZ = (function (e) {
        function t(r, n, i, o, s, a) {
          var c;
          return (
            ((c = e.call(this, r) || this).name = "CssSyntaxError"),
            (c.reason = r),
            s && (c.file = s),
            o && (c.source = o),
            a && (c.plugin = a),
            void 0 !== n &&
              void 0 !== i &&
              ("number" == typeof n
                ? ((c.line = n), (c.column = i))
                : ((c.line = n.line), (c.column = n.column), (c.endLine = i.line), (c.endColumn = i.column))),
            c.setMessage(),
            Error.captureStackTrace && Error.captureStackTrace(c, t),
            c
          );
        }
        O(t, e);
        var r = t.prototype;
        return (
          (r.setMessage = function () {
            ((this.message = this.plugin ? this.plugin + ": " : ""),
              (this.message += this.file ? this.file : "<css input>"),
              void 0 !== this.line && (this.message += ":" + this.line + ":" + this.column),
              (this.message += ": " + this.reason));
          }),
          (r.showSourceCode = function (e) {
            var t,
              r,
              n = this;
            if (!this.source) return "";
            var i = this.source;
            (null == e && (e = t$.isColorSupported), tH && e && (i = tH(i)));
            var o = i.split(/\r?\n/),
              s = Math.max(this.line - 3, 0),
              a = Math.min(this.line + 2, o.length),
              c = String(a).length;
            if (e) {
              var u = t$.createColors(!0),
                l = u.bold,
                p = u.gray,
                h = u.red;
              ((t = function (e) {
                return l(h(e));
              }),
                (r = function (e) {
                  return p(e);
                }));
            } else
              t = r = function (e) {
                return e;
              };
            return o
              .slice(s, a)
              .map(function (e, i) {
                var o = s + 1 + i,
                  a = " " + (" " + o).slice(-c) + " | ";
                if (o === n.line) {
                  var u = r(a.replace(/\d/g, " ")) + e.slice(0, n.column - 1).replace(/[^\t]/g, " ");
                  return t(">") + r(a) + e + "\n " + u + t("^");
                }
                return " " + r(a) + e;
              })
              .join("\n");
          }),
          (r.toString = function () {
            var e = this.showSourceCode();
            return (e && (e = "\n\n" + e + "\n"), this.name + ": " + this.message + e);
          }),
          t
        );
      })(M(Error));
    tZ.default = tZ;
    var tJ = {};
    ((tJ.isClean = Symbol("isClean")), (tJ.my = Symbol("my")));
    var tX = {
        after: "\n",
        beforeClose: "\n",
        beforeComment: "\n",
        beforeDecl: "\n",
        beforeOpen: " ",
        beforeRule: "\n",
        colon: ": ",
        commentLeft: " ",
        commentRight: " ",
        emptyBody: "",
        indent: "    ",
        semicolon: !1,
      },
      tQ = (function () {
        function e(e) {
          this.builder = e;
        }
        var t = e.prototype;
        return (
          (t.atrule = function (e, t) {
            var r = "@" + e.name,
              n = e.params ? this.rawValue(e, "params") : "";
            if ((void 0 !== e.raws.afterName ? (r += e.raws.afterName) : n && (r += " "), e.nodes))
              this.block(e, r + n);
            else {
              var i = (e.raws.between || "") + (t ? ";" : "");
              this.builder(r + n + i, e);
            }
          }),
          (t.beforeAfter = function (e, t) {
            for (
              var r =
                  "decl" === e.type
                    ? this.raw(e, null, "beforeDecl")
                    : "comment" === e.type
                      ? this.raw(e, null, "beforeComment")
                      : "before" === t
                        ? this.raw(e, null, "beforeRule")
                        : this.raw(e, null, "beforeClose"),
                n = e.parent,
                i = 0;
              n && "root" !== n.type;
            )
              ((i += 1), (n = n.parent));
            if (r.includes("\n")) {
              var o = this.raw(e, null, "indent");
              if (o.length) for (var s = 0; s < i; s++) r += o;
            }
            return r;
          }),
          (t.block = function (e, t) {
            var r,
              n = this.raw(e, "between", "beforeOpen");
            (this.builder(t + n + "{", e, "start"),
              e.nodes && e.nodes.length
                ? (this.body(e), (r = this.raw(e, "after")))
                : (r = this.raw(e, "after", "emptyBody")),
              r && this.builder(r),
              this.builder("}", e, "end"));
          }),
          (t.body = function (e) {
            for (var t = e.nodes.length - 1; t > 0 && "comment" === e.nodes[t].type;) t -= 1;
            for (var r = this.raw(e, "semicolon"), n = 0; n < e.nodes.length; n++) {
              var i = e.nodes[n],
                o = this.raw(i, "before");
              (o && this.builder(o), this.stringify(i, t !== n || r));
            }
          }),
          (t.comment = function (e) {
            var t = this.raw(e, "left", "commentLeft"),
              r = this.raw(e, "right", "commentRight");
            this.builder("/*" + t + e.text + r + "*/", e);
          }),
          (t.decl = function (e, t) {
            var r = this.raw(e, "between", "colon"),
              n = e.prop + r + this.rawValue(e, "value");
            (e.important && (n += e.raws.important || " !important"), t && (n += ";"), this.builder(n, e));
          }),
          (t.document = function (e) {
            this.body(e);
          }),
          (t.raw = function (e, t, r) {
            if ((r || (r = t), t && void 0 !== (n = e.raws[t]))) return n;
            var n,
              i = e.parent;
            if (
              "before" === r &&
              (!i || ("root" === i.type && i.first === e) || (i && "document" === i.type))
            )
              return "";
            if (!i) return tX[r];
            var o = e.root();
            if ((o.rawCache || (o.rawCache = {}), void 0 !== o.rawCache[r])) return o.rawCache[r];
            if ("before" === r || "after" === r) return this.beforeAfter(e, r);
            var s,
              a = "raw" + ((s = r)[0].toUpperCase() + s.slice(1));
            return (
              this[a]
                ? (n = this[a](o, e))
                : o.walk(function (e) {
                    if (void 0 !== (n = e.raws[t])) return !1;
                  }),
              void 0 === n && (n = tX[r]),
              (o.rawCache[r] = n),
              n
            );
          }),
          (t.rawBeforeClose = function (e) {
            var t;
            return (
              e.walk(function (e) {
                if (e.nodes && e.nodes.length > 0 && void 0 !== e.raws.after)
                  return ((t = e.raws.after).includes("\n") && (t = t.replace(/[^\n]+$/, "")), !1);
              }),
              t && (t = t.replace(/\S/g, "")),
              t
            );
          }),
          (t.rawBeforeComment = function (e, t) {
            var r;
            return (
              e.walkComments(function (e) {
                if (void 0 !== e.raws.before)
                  return ((r = e.raws.before).includes("\n") && (r = r.replace(/[^\n]+$/, "")), !1);
              }),
              void 0 === r ? (r = this.raw(t, null, "beforeDecl")) : r && (r = r.replace(/\S/g, "")),
              r
            );
          }),
          (t.rawBeforeDecl = function (e, t) {
            var r;
            return (
              e.walkDecls(function (e) {
                if (void 0 !== e.raws.before)
                  return ((r = e.raws.before).includes("\n") && (r = r.replace(/[^\n]+$/, "")), !1);
              }),
              void 0 === r ? (r = this.raw(t, null, "beforeRule")) : r && (r = r.replace(/\S/g, "")),
              r
            );
          }),
          (t.rawBeforeOpen = function (e) {
            var t;
            return (
              e.walk(function (e) {
                if ("decl" !== e.type && void 0 !== (t = e.raws.between)) return !1;
              }),
              t
            );
          }),
          (t.rawBeforeRule = function (e) {
            var t;
            return (
              e.walk(function (r) {
                if (r.nodes && (r.parent !== e || e.first !== r) && void 0 !== r.raws.before)
                  return ((t = r.raws.before).includes("\n") && (t = t.replace(/[^\n]+$/, "")), !1);
              }),
              t && (t = t.replace(/\S/g, "")),
              t
            );
          }),
          (t.rawColon = function (e) {
            var t;
            return (
              e.walkDecls(function (e) {
                if (void 0 !== e.raws.between) return ((t = e.raws.between.replace(/[^\s:]/g, "")), !1);
              }),
              t
            );
          }),
          (t.rawEmptyBody = function (e) {
            var t;
            return (
              e.walk(function (e) {
                if (e.nodes && 0 === e.nodes.length && void 0 !== (t = e.raws.after)) return !1;
              }),
              t
            );
          }),
          (t.rawIndent = function (e) {
            var t;
            return e.raws.indent
              ? e.raws.indent
              : (e.walk(function (r) {
                  var n = r.parent;
                  if (n && n !== e && n.parent && n.parent === e && void 0 !== r.raws.before) {
                    var i = r.raws.before.split("\n");
                    return ((t = (t = i[i.length - 1]).replace(/\S/g, "")), !1);
                  }
                }),
                t);
          }),
          (t.rawSemicolon = function (e) {
            var t;
            return (
              e.walk(function (e) {
                if (e.nodes && e.nodes.length && "decl" === e.last.type && void 0 !== (t = e.raws.semicolon))
                  return !1;
              }),
              t
            );
          }),
          (t.rawValue = function (e, t) {
            var r = e[t],
              n = e.raws[t];
            return n && n.value === r ? n.raw : r;
          }),
          (t.root = function (e) {
            (this.body(e), e.raws.after && this.builder(e.raws.after));
          }),
          (t.rule = function (e) {
            (this.block(e, this.rawValue(e, "selector")),
              e.raws.ownSemicolon && this.builder(e.raws.ownSemicolon, e, "end"));
          }),
          (t.stringify = function (e, t) {
            if (!this[e.type])
              throw Error(
                "Unknown AST node type " + e.type + ". Maybe you need to change PostCSS stringifier.",
              );
            this[e.type](e, t);
          }),
          e
        );
      })();
    function t0(e, t) {
      new tQ(t).stringify(e);
    }
    ((tQ.default = tQ), (t0.default = t0));
    var t1 = tJ.isClean,
      t2 = tJ.my,
      t3 = (function () {
        function e(e) {
          for (var t in (void 0 === e && (e = {}), (this.raws = {}), (this[t1] = !1), (this[t2] = !0), e))
            if ("nodes" === t) {
              this.nodes = [];
              for (var r, n = P(e[t]); !(r = n()).done;) {
                var i = r.value;
                "function" == typeof i.clone ? this.append(i.clone()) : this.append(i);
              }
            } else this[t] = e[t];
        }
        var t = e.prototype;
        return (
          (t.addToError = function (e) {
            if (((e.postcssNode = this), e.stack && this.source && /\n\s{4}at /.test(e.stack))) {
              var t = this.source;
              e.stack = e.stack.replace(
                /\n\s{4}at /,
                "$&" + t.input.from + ":" + t.start.line + ":" + t.start.column + "$&",
              );
            }
            return e;
          }),
          (t.after = function (e) {
            return (this.parent.insertAfter(this, e), this);
          }),
          (t.assign = function (e) {
            for (var t in (void 0 === e && (e = {}), e)) this[t] = e[t];
            return this;
          }),
          (t.before = function (e) {
            return (this.parent.insertBefore(this, e), this);
          }),
          (t.cleanRaws = function (e) {
            (delete this.raws.before, delete this.raws.after, e || delete this.raws.between);
          }),
          (t.clone = function (e) {
            void 0 === e && (e = {});
            var t = (function e(t, r) {
              var n = new t.constructor();
              for (var i in t)
                if (Object.prototype.hasOwnProperty.call(t, i) && "proxyCache" !== i) {
                  var o = t[i],
                    s = void 0 === o ? "undefined" : x(o);
                  "parent" === i && "object" === s
                    ? r && (n[i] = r)
                    : "source" === i
                      ? (n[i] = o)
                      : Array.isArray(o)
                        ? (n[i] = o.map(function (t) {
                            return e(t, n);
                          }))
                        : ("object" === s && null !== o && (o = e(o)), (n[i] = o));
                }
              return n;
            })(this);
            for (var r in e) t[r] = e[r];
            return t;
          }),
          (t.cloneAfter = function (e) {
            void 0 === e && (e = {});
            var t = this.clone(e);
            return (this.parent.insertAfter(this, t), t);
          }),
          (t.cloneBefore = function (e) {
            void 0 === e && (e = {});
            var t = this.clone(e);
            return (this.parent.insertBefore(this, t), t);
          }),
          (t.error = function (e, t) {
            if ((void 0 === t && (t = {}), this.source)) {
              var r = this.rangeBy(t),
                n = r.end,
                i = r.start;
              return this.source.input.error(
                e,
                { column: i.column, line: i.line },
                { column: n.column, line: n.line },
                t,
              );
            }
            return new tZ(e);
          }),
          (t.getProxyProcessor = function () {
            return {
              get: function (e, t) {
                return "proxyOf" === t
                  ? e
                  : "root" === t
                    ? function () {
                        return e.root().toProxy();
                      }
                    : e[t];
              },
              set: function (e, t, r) {
                return (
                  e[t] === r ||
                  ((e[t] = r),
                  ("prop" === t ||
                    "value" === t ||
                    "name" === t ||
                    "params" === t ||
                    "important" === t ||
                    "text" === t) &&
                    e.markDirty(),
                  !0)
                );
              },
            };
          }),
          (t.markDirty = function () {
            if (this[t1]) {
              this[t1] = !1;
              for (var e = this; (e = e.parent);) e[t1] = !1;
            }
          }),
          (t.next = function () {
            if (this.parent) {
              var e = this.parent.index(this);
              return this.parent.nodes[e + 1];
            }
          }),
          (t.positionBy = function (e, t) {
            var r = this.source.start;
            if (e.index) r = this.positionInside(e.index, t);
            else if (e.word) {
              var n = (t = this.toString()).indexOf(e.word);
              -1 !== n && (r = this.positionInside(n, t));
            }
            return r;
          }),
          (t.positionInside = function (e, t) {
            for (
              var r = t || this.toString(), n = this.source.start.column, i = this.source.start.line, o = 0;
              o < e;
              o++
            )
              "\n" === r[o] ? ((n = 1), (i += 1)) : (n += 1);
            return { column: n, line: i };
          }),
          (t.prev = function () {
            if (this.parent) {
              var e = this.parent.index(this);
              return this.parent.nodes[e - 1];
            }
          }),
          (t.rangeBy = function (e) {
            var t = { column: this.source.start.column, line: this.source.start.line },
              r = this.source.end
                ? { column: this.source.end.column + 1, line: this.source.end.line }
                : { column: t.column + 1, line: t.line };
            if (e.word) {
              var n = this.toString(),
                i = n.indexOf(e.word);
              -1 !== i && ((t = this.positionInside(i, n)), (r = this.positionInside(i + e.word.length, n)));
            } else
              (e.start
                ? (t = { column: e.start.column, line: e.start.line })
                : e.index && (t = this.positionInside(e.index)),
                e.end
                  ? (r = { column: e.end.column, line: e.end.line })
                  : "number" == typeof e.endIndex
                    ? (r = this.positionInside(e.endIndex))
                    : e.index && (r = this.positionInside(e.index + 1)));
            return (
              (r.line < t.line || (r.line === t.line && r.column <= t.column)) &&
                (r = { column: t.column + 1, line: t.line }),
              { end: r, start: t }
            );
          }),
          (t.raw = function (e, t) {
            return new tQ().raw(this, e, t);
          }),
          (t.remove = function () {
            return (this.parent && this.parent.removeChild(this), (this.parent = void 0), this);
          }),
          (t.replaceWith = function () {
            for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
            if (this.parent) {
              for (var n, i = this, o = !1, s = P(t); !(n = s()).done;) {
                var a = n.value;
                a === this
                  ? (o = !0)
                  : o
                    ? (this.parent.insertAfter(i, a), (i = a))
                    : this.parent.insertBefore(i, a);
              }
              o || this.remove();
            }
            return this;
          }),
          (t.root = function () {
            for (var e = this; e.parent && "document" !== e.parent.type;) e = e.parent;
            return e;
          }),
          (t.toJSON = function (e, t) {
            var r = {},
              n = null == t;
            t = t || new Map();
            var i = 0;
            for (var o in this)
              if (Object.prototype.hasOwnProperty.call(this, o) && "parent" !== o && "proxyCache" !== o) {
                var s = this[o];
                if (Array.isArray(s))
                  r[o] = s.map(function (e) {
                    return (void 0 === e ? "undefined" : x(e)) === "object" && e.toJSON
                      ? e.toJSON(null, t)
                      : e;
                  });
                else if ((void 0 === s ? "undefined" : x(s)) === "object" && s.toJSON)
                  r[o] = s.toJSON(null, t);
                else if ("source" === o) {
                  var a = t.get(s.input);
                  (null == a && ((a = i), t.set(s.input, i), i++),
                    (r[o] = { end: s.end, inputId: a, start: s.start }));
                } else r[o] = s;
              }
            return (
              n &&
                (r.inputs = [].concat(t.keys()).map(function (e) {
                  return e.toJSON();
                })),
              r
            );
          }),
          (t.toProxy = function () {
            return (
              this.proxyCache || (this.proxyCache = new Proxy(this, this.getProxyProcessor())),
              this.proxyCache
            );
          }),
          (t.toString = function (e) {
            (void 0 === e && (e = t0), e.stringify && (e = e.stringify));
            var t = "";
            return (
              e(this, function (e) {
                t += e;
              }),
              t
            );
          }),
          (t.warn = function (e, t, r) {
            var n = { node: this };
            for (var i in r) n[i] = r[i];
            return e.warn(t, n);
          }),
          I(e, [
            {
              key: "proxyOf",
              get: function () {
                return this;
              },
            },
          ]),
          e
        );
      })();
    t3.default = t3;
    var t4 = (function (e) {
      function t(t) {
        var r;
        return (
          t && void 0 !== t.value && "string" != typeof t.value && (t = S({}, t, { value: String(t.value) })),
          ((r = e.call(this, t) || this).type = "decl"),
          r
        );
      }
      return (
        O(t, e),
        I(t, [
          {
            key: "variable",
            get: function () {
              return this.prop.startsWith("--") || "$" === this.prop[0];
            },
          },
        ]),
        t
      );
    })(t3);
    t4.default = t4;
    var t5 = tH.SourceMapConsumer,
      t9 = tH.SourceMapGenerator,
      t6 = tH.existsSync,
      t8 = tH.readFileSync,
      t7 = tH.dirname,
      re = tH.join,
      rt = (function () {
        function e(e, t) {
          if (!1 !== t.map) {
            (this.loadAnnotation(e), (this.inline = this.startWith(this.annotation, "data:")));
            var r = t.map ? t.map.prev : void 0,
              n = this.loadMap(t.from, r);
            (!this.mapFile && t.from && (this.mapFile = t.from),
              this.mapFile && (this.root = t7(this.mapFile)),
              n && (this.text = n));
          }
        }
        var t = e.prototype;
        return (
          (t.consumer = function () {
            return (this.consumerCache || (this.consumerCache = new t5(this.text)), this.consumerCache);
          }),
          (t.decodeInline = function (e) {
            if (/^data:application\/json;charset=utf-?8,/.test(e) || /^data:application\/json,/.test(e))
              return decodeURIComponent(e.substr(RegExp.lastMatch.length));
            if (
              /^data:application\/json;charset=utf-?8;base64,/.test(e) ||
              /^data:application\/json;base64,/.test(e)
            ) {
              var t;
              return ((t = e.substr(RegExp.lastMatch.length)), _.Buffer.from(t, "base64").toString());
            }
            throw Error("Unsupported source map encoding " + e.match(/data:application\/json;([^,]+),/)[1]);
          }),
          (t.getAnnotationURL = function (e) {
            return e.replace(/^\/\*\s*# sourceMappingURL=/, "").trim();
          }),
          (t.isMap = function (e) {
            return (
              (void 0 === e ? "undefined" : x(e)) === "object" &&
              ("string" == typeof e.mappings || "string" == typeof e._mappings || Array.isArray(e.sections))
            );
          }),
          (t.loadAnnotation = function (e) {
            var t = e.match(/\/\*\s*# sourceMappingURL=/gm);
            if (t) {
              var r = e.lastIndexOf(t.pop()),
                n = e.indexOf("*/", r);
              r > -1 && n > -1 && (this.annotation = this.getAnnotationURL(e.substring(r, n)));
            }
          }),
          (t.loadFile = function (e) {
            if (((this.root = t7(e)), t6(e))) return ((this.mapFile = e), t8(e, "utf-8").toString().trim());
          }),
          (t.loadMap = function (e, t) {
            if (!1 === t) return !1;
            if (t)
              if ("string" == typeof t) return t;
              else if ("function" == typeof t) {
                var r = t(e);
                if (r) {
                  var n = this.loadFile(r);
                  if (!n) throw Error("Unable to load previous source map: " + r.toString());
                  return n;
                }
              } else if (A(t, t5)) return t9.fromSourceMap(t).toString();
              else if (A(t, t9)) return t.toString();
              else if (this.isMap(t)) return JSON.stringify(t);
              else throw Error("Unsupported previous source map format: " + t.toString());
            else if (this.inline) return this.decodeInline(this.annotation);
            else if (this.annotation) {
              var i = this.annotation;
              return (e && (i = re(t7(e), i)), this.loadFile(i));
            }
          }),
          (t.startWith = function (e, t) {
            return !!e && e.substr(0, t.length) === t;
          }),
          (t.withContent = function () {
            return !!(this.consumer().sourcesContent && this.consumer().sourcesContent.length > 0);
          }),
          e
        );
      })();
    rt.default = rt;
    var rr = tH.SourceMapConsumer,
      rn = tH.SourceMapGenerator,
      ri = tH.fileURLToPath,
      ro = tH.pathToFileURL,
      rs = tH.isAbsolute,
      ra = tH.resolve,
      rc = function (e) {
        void 0 === e && (e = 21);
        for (var t = "", r = e; r--;)
          t += "useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict"[(64 * Math.random()) | 0];
        return t;
      },
      ru = Symbol("fromOffsetCache"),
      rl = !!(rr && rn),
      rp = !!(ra && rs),
      rh = (function () {
        function e(e, t) {
          if (
            (void 0 === t && (t = {}),
            null == e || ((void 0 === e ? "undefined" : x(e)) === "object" && !e.toString))
          )
            throw Error("PostCSS received " + e + " instead of CSS string");
          if (
            ((this.css = e.toString()),
            "\uFEFF" === this.css[0] || "￾" === this.css[0]
              ? ((this.hasBOM = !0), (this.css = this.css.slice(1)))
              : (this.hasBOM = !1),
            t.from &&
              (!rp || /^\w+:\/\//.test(t.from) || rs(t.from)
                ? (this.file = t.from)
                : (this.file = ra(t.from))),
            rp && rl)
          ) {
            var r = new rt(this.css, t);
            if (r.text) {
              this.map = r;
              var n = r.consumer().file;
              !this.file && n && (this.file = this.mapResolve(n));
            }
          }
          (this.file || (this.id = "<input css " + rc(6) + ">"), this.map && (this.map.file = this.from));
        }
        var t = e.prototype;
        return (
          (t.error = function (e, t, r, n) {
            if ((void 0 === n && (n = {}), t && (void 0 === t ? "undefined" : x(t)) === "object")) {
              var i,
                o,
                s,
                a = t,
                c = r;
              if ("number" == typeof a.offset) {
                var u = this.fromOffset(a.offset);
                ((t = u.line), (r = u.col));
              } else ((t = a.line), (r = a.column));
              if ("number" == typeof c.offset) {
                var l = this.fromOffset(c.offset);
                ((o = l.line), (s = l.col));
              } else ((o = c.line), (s = c.column));
            } else if (!r) {
              var p = this.fromOffset(t);
              ((t = p.line), (r = p.col));
            }
            var h = this.origin(t, r, o, s);
            return (
              ((i = h
                ? new tZ(
                    e,
                    void 0 === h.endLine ? h.line : { column: h.column, line: h.line },
                    void 0 === h.endLine ? h.column : { column: h.endColumn, line: h.endLine },
                    h.source,
                    h.file,
                    n.plugin,
                  )
                : new tZ(
                    e,
                    void 0 === o ? t : { column: r, line: t },
                    void 0 === o ? r : { column: s, line: o },
                    this.css,
                    this.file,
                    n.plugin,
                  )).input = { column: r, endColumn: s, endLine: o, line: t, source: this.css }),
              this.file && (ro && (i.input.url = ro(this.file).toString()), (i.input.file = this.file)),
              i
            );
          }),
          (t.fromOffset = function (e) {
            if (this[ru]) a = this[ru];
            else {
              var t = this.css.split("\n");
              a = Array(t.length);
              for (var r = 0, n = 0, i = t.length; n < i; n++) ((a[n] = r), (r += t[n].length + 1));
              this[ru] = a;
            }
            s = a[a.length - 1];
            var o = 0;
            if (e >= s) o = a.length - 1;
            else
              for (var s, a, c, u = a.length - 2; o < u;)
                if (e < a[(c = o + ((u - o) >> 1))]) u = c - 1;
                else if (e >= a[c + 1]) o = c + 1;
                else {
                  o = c;
                  break;
                }
            return { col: e - a[o] + 1, line: o + 1 };
          }),
          (t.mapResolve = function (e) {
            return /^\w+:\/\//.test(e) ? e : ra(this.map.consumer().sourceRoot || this.map.root || ".", e);
          }),
          (t.origin = function (e, t, r, n) {
            if (!this.map) return !1;
            var i,
              o,
              s = this.map.consumer(),
              a = s.originalPositionFor({ column: t, line: e });
            if (!a.source) return !1;
            ("number" == typeof r && (i = s.originalPositionFor({ column: n, line: r })),
              (o = rs(a.source)
                ? ro(a.source)
                : new URL(a.source, this.map.consumer().sourceRoot || ro(this.map.mapFile))));
            var c = {
              column: a.column,
              endColumn: i && i.column,
              endLine: i && i.line,
              line: a.line,
              url: o.toString(),
            };
            if ("file:" === o.protocol)
              if (ri) c.file = ri(o);
              else throw Error("file: protocol is not available in this PostCSS build");
            var u = s.sourceContentFor(a.source);
            return (u && (c.source = u), c);
          }),
          (t.toJSON = function () {
            for (var e = {}, t = 0, r = ["hasBOM", "css", "file", "id"]; t < r.length; t++) {
              var n = r[t];
              null != this[n] && (e[n] = this[n]);
            }
            return (
              this.map && ((e.map = S({}, this.map)), e.map.consumerCache && (e.map.consumerCache = void 0)),
              e
            );
          }),
          I(e, [
            {
              key: "from",
              get: function () {
                return this.file || this.id;
              },
            },
          ]),
          e
        );
      })();
    ((rh.default = rh), tH && tH.registerInput && tH.registerInput(rh));
    var rd = tH.SourceMapConsumer,
      rf = tH.SourceMapGenerator,
      rg = tH.dirname,
      rm = tH.relative,
      r_ = tH.resolve,
      rv = tH.sep,
      ry = tH.pathToFileURL,
      rb = !!(rd && rf),
      rC = !!(rg && r_ && rm && rv),
      rE = (function () {
        function e(e, t, r, n) {
          ((this.stringify = e),
            (this.mapOpts = r.map || {}),
            (this.root = t),
            (this.opts = r),
            (this.css = n),
            (this.originalCSS = n),
            (this.usesFileUrls = !this.mapOpts.from && this.mapOpts.absolute),
            (this.memoizedFileURLs = new Map()),
            (this.memoizedPaths = new Map()),
            (this.memoizedURLs = new Map()));
        }
        var t = e.prototype;
        return (
          (t.addAnnotation = function () {
            var e = this.isInline()
                ? "data:application/json;base64," + this.toBase64(this.map.toString())
                : "string" == typeof this.mapOpts.annotation
                  ? this.mapOpts.annotation
                  : "function" == typeof this.mapOpts.annotation
                    ? this.mapOpts.annotation(this.opts.to, this.root)
                    : this.outputFile() + ".map",
              t = "\n";
            (this.css.includes("\r\n") && (t = "\r\n"),
              (this.css += t + "/*# sourceMappingURL=" + e + " */"));
          }),
          (t.applyPrevMaps = function () {
            for (var e, t = P(this.previous()); !(e = t()).done;) {
              var r = e.value,
                n = this.toUrl(this.path(r.file)),
                i = r.root || rg(r.file),
                o = void 0;
              (!1 === this.mapOpts.sourcesContent
                ? (o = new rd(r.text)).sourcesContent && (o.sourcesContent = null)
                : (o = r.consumer()),
                this.map.applySourceMap(o, n, this.toUrl(this.path(i))));
            }
          }),
          (t.clearAnnotation = function () {
            if (!1 !== this.mapOpts.annotation)
              if (this.root)
                for (var e, t = this.root.nodes.length - 1; t >= 0; t--)
                  "comment" === (e = this.root.nodes[t]).type &&
                    0 === e.text.indexOf("# sourceMappingURL=") &&
                    this.root.removeChild(t);
              else this.css && (this.css = this.css.replace(/\n*?\/\*#[\S\s]*?\*\/$/gm, ""));
          }),
          (t.generate = function () {
            if ((this.clearAnnotation(), rC && rb && this.isMap())) return this.generateMap();
            var e = "";
            return (
              this.stringify(this.root, function (t) {
                e += t;
              }),
              [e]
            );
          }),
          (t.generateMap = function () {
            if (this.root) this.generateString();
            else if (1 === this.previous().length) {
              var e = this.previous()[0].consumer();
              ((e.file = this.outputFile()), (this.map = rf.fromSourceMap(e, { ignoreInvalidMapping: !0 })));
            } else
              ((this.map = new rf({ file: this.outputFile(), ignoreInvalidMapping: !0 })),
                this.map.addMapping({
                  generated: { column: 0, line: 1 },
                  original: { column: 0, line: 1 },
                  source: this.opts.from ? this.toUrl(this.path(this.opts.from)) : "<no source>",
                }));
            return (this.isSourcesContent() && this.setSourcesContent(),
            this.root && this.previous().length > 0 && this.applyPrevMaps(),
            this.isAnnotation() && this.addAnnotation(),
            this.isInline())
              ? [this.css]
              : [this.css, this.map];
          }),
          (t.generateString = function () {
            var e,
              t,
              r = this;
            ((this.css = ""), (this.map = new rf({ file: this.outputFile(), ignoreInvalidMapping: !0 })));
            var n = 1,
              i = 1,
              o = "<no source>",
              s = { generated: { column: 0, line: 0 }, original: { column: 0, line: 0 }, source: "" };
            this.stringify(this.root, function (a, c, u) {
              if (
                ((r.css += a),
                c &&
                  "end" !== u &&
                  ((s.generated.line = n),
                  (s.generated.column = i - 1),
                  c.source && c.source.start
                    ? ((s.source = r.sourcePath(c)),
                      (s.original.line = c.source.start.line),
                      (s.original.column = c.source.start.column - 1))
                    : ((s.source = o), (s.original.line = 1), (s.original.column = 0)),
                  r.map.addMapping(s)),
                (e = a.match(/\n/g))
                  ? ((n += e.length), (t = a.lastIndexOf("\n")), (i = a.length - t))
                  : (i += a.length),
                c && "start" !== u)
              ) {
                var l = c.parent || { raws: {} };
                (!("decl" === c.type || ("atrule" === c.type && !c.nodes)) ||
                  c !== l.last ||
                  l.raws.semicolon) &&
                  (c.source && c.source.end
                    ? ((s.source = r.sourcePath(c)),
                      (s.original.line = c.source.end.line),
                      (s.original.column = c.source.end.column - 1),
                      (s.generated.line = n),
                      (s.generated.column = i - 2))
                    : ((s.source = o),
                      (s.original.line = 1),
                      (s.original.column = 0),
                      (s.generated.line = n),
                      (s.generated.column = i - 1)),
                  r.map.addMapping(s));
              }
            });
          }),
          (t.isAnnotation = function () {
            return (
              !!this.isInline() ||
              (void 0 !== this.mapOpts.annotation
                ? this.mapOpts.annotation
                : !this.previous().length ||
                  this.previous().some(function (e) {
                    return e.annotation;
                  }))
            );
          }),
          (t.isInline = function () {
            if (void 0 !== this.mapOpts.inline) return this.mapOpts.inline;
            var e = this.mapOpts.annotation;
            return (
              (void 0 === e || !0 === e) &&
              (!this.previous().length ||
                this.previous().some(function (e) {
                  return e.inline;
                }))
            );
          }),
          (t.isMap = function () {
            return void 0 !== this.opts.map ? !!this.opts.map : this.previous().length > 0;
          }),
          (t.isSourcesContent = function () {
            return void 0 !== this.mapOpts.sourcesContent
              ? this.mapOpts.sourcesContent
              : !this.previous().length ||
                  this.previous().some(function (e) {
                    return e.withContent();
                  });
          }),
          (t.outputFile = function () {
            return this.opts.to
              ? this.path(this.opts.to)
              : this.opts.from
                ? this.path(this.opts.from)
                : "to.css";
          }),
          (t.path = function (e) {
            if (this.mapOpts.absolute || 60 === e.charCodeAt(0) || /^\w+:\/\//.test(e)) return e;
            var t = this.memoizedPaths.get(e);
            if (t) return t;
            var r = this.opts.to ? rg(this.opts.to) : ".";
            "string" == typeof this.mapOpts.annotation && (r = rg(r_(r, this.mapOpts.annotation)));
            var n = rm(r, e);
            return (this.memoizedPaths.set(e, n), n);
          }),
          (t.previous = function () {
            var e = this;
            if (!this.previousMaps)
              if (((this.previousMaps = []), this.root))
                this.root.walk(function (t) {
                  if (t.source && t.source.input.map) {
                    var r = t.source.input.map;
                    e.previousMaps.includes(r) || e.previousMaps.push(r);
                  }
                });
              else {
                var t = new rh(this.originalCSS, this.opts);
                t.map && this.previousMaps.push(t.map);
              }
            return this.previousMaps;
          }),
          (t.setSourcesContent = function () {
            var e = this,
              t = {};
            if (this.root)
              this.root.walk(function (r) {
                if (r.source) {
                  var n = r.source.input.from;
                  if (n && !t[n]) {
                    t[n] = !0;
                    var i = e.usesFileUrls ? e.toFileUrl(n) : e.toUrl(e.path(n));
                    e.map.setSourceContent(i, r.source.input.css);
                  }
                }
              });
            else if (this.css) {
              var r = this.opts.from ? this.toUrl(this.path(this.opts.from)) : "<no source>";
              this.map.setSourceContent(r, this.css);
            }
          }),
          (t.sourcePath = function (e) {
            return this.mapOpts.from
              ? this.toUrl(this.mapOpts.from)
              : this.usesFileUrls
                ? this.toFileUrl(e.source.input.from)
                : this.toUrl(this.path(e.source.input.from));
          }),
          (t.toBase64 = function (e) {
            return _.Buffer.from(e).toString("base64");
          }),
          (t.toFileUrl = function (e) {
            var t = this.memoizedFileURLs.get(e);
            if (t) return t;
            if (ry) {
              var r = ry(e).toString();
              return (this.memoizedFileURLs.set(e, r), r);
            }
            throw Error("`map.absolute` option is not available in this PostCSS build");
          }),
          (t.toUrl = function (e) {
            var t = this.memoizedURLs.get(e);
            if (t) return t;
            "\\" === rv && (e = e.replace(/\\/g, "/"));
            var r = encodeURI(e).replace(/[#?]/g, encodeURIComponent);
            return (this.memoizedURLs.set(e, r), r);
          }),
          e
        );
      })(),
      rw = (function (e) {
        function t(t) {
          var r;
          return (((r = e.call(this, t) || this).type = "comment"), r);
        }
        return (O(t, e), t);
      })(t3);
    rw.default = rw;
    var rI = tJ.isClean,
      rS = tJ.my,
      rk = (function (e) {
        function t() {
          return e.apply(this, arguments) || this;
        }
        O(t, e);
        var r = t.prototype;
        return (
          (r.append = function () {
            for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
            for (var n, i = P(t); !(n = i()).done;)
              for (var o, s = n.value, a = this.normalize(s, this.last), c = P(a); !(o = c()).done;) {
                var u = o.value;
                this.proxyOf.nodes.push(u);
              }
            return (this.markDirty(), this);
          }),
          (r.cleanRaws = function (t) {
            if ((e.prototype.cleanRaws.call(this, t), this.nodes))
              for (var r, n = P(this.nodes); !(r = n()).done;) r.value.cleanRaws(t);
          }),
          (r.each = function (e) {
            if (this.proxyOf.nodes) {
              for (
                var t, r, n = this.getIterator();
                this.indexes[n] < this.proxyOf.nodes.length &&
                ((t = this.indexes[n]), !1 !== (r = e(this.proxyOf.nodes[t], t)));
              )
                this.indexes[n] += 1;
              return (delete this.indexes[n], r);
            }
          }),
          (r.every = function (e) {
            return this.nodes.every(e);
          }),
          (r.getIterator = function () {
            (this.lastEach || (this.lastEach = 0), this.indexes || (this.indexes = {}), (this.lastEach += 1));
            var e = this.lastEach;
            return ((this.indexes[e] = 0), e);
          }),
          (r.getProxyProcessor = function () {
            return {
              get: function (e, t) {
                if ("proxyOf" === t) return e;
                if (!e[t]) return e[t];
                if ("each" === t || ("string" == typeof t && t.startsWith("walk")))
                  return function () {
                    for (var r = arguments.length, n = Array(r), i = 0; i < r; i++) n[i] = arguments[i];
                    return e[t].apply(
                      e,
                      [].concat(
                        n.map(function (e) {
                          return "function" == typeof e
                            ? function (t, r) {
                                return e(t.toProxy(), r);
                              }
                            : e;
                        }),
                      ),
                    );
                  };
                if ("every" === t || "some" === t)
                  return function (r) {
                    return e[t](function (e) {
                      for (var t = arguments.length, n = Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++)
                        n[i - 1] = arguments[i];
                      return r.apply(void 0, [].concat([e.toProxy()], n));
                    });
                  };
                if ("root" === t)
                  return function () {
                    return e.root().toProxy();
                  };
                else if ("nodes" === t)
                  return e.nodes.map(function (e) {
                    return e.toProxy();
                  });
                else if ("first" === t || "last" === t) return e[t].toProxy();
                else return e[t];
              },
              set: function (e, t, r) {
                return (
                  e[t] === r ||
                  ((e[t] = r), ("name" === t || "params" === t || "selector" === t) && e.markDirty(), !0)
                );
              },
            };
          }),
          (r.index = function (e) {
            return "number" == typeof e ? e : (e.proxyOf && (e = e.proxyOf), this.proxyOf.nodes.indexOf(e));
          }),
          (r.insertAfter = function (e, t) {
            var r,
              n = this.index(e),
              i = this.normalize(t, this.proxyOf.nodes[n]).reverse();
            n = this.index(e);
            for (var o, s = P(i); !(o = s()).done;) {
              var a = o.value;
              this.proxyOf.nodes.splice(n + 1, 0, a);
            }
            for (var c in this.indexes) n < (r = this.indexes[c]) && (this.indexes[c] = r + i.length);
            return (this.markDirty(), this);
          }),
          (r.insertBefore = function (e, t) {
            var r,
              n = this.index(e),
              i = 0 === n && "prepend",
              o = this.normalize(t, this.proxyOf.nodes[n], i).reverse();
            n = this.index(e);
            for (var s, a = P(o); !(s = a()).done;) {
              var c = s.value;
              this.proxyOf.nodes.splice(n, 0, c);
            }
            for (var u in this.indexes) n <= (r = this.indexes[u]) && (this.indexes[u] = r + o.length);
            return (this.markDirty(), this);
          }),
          (r.normalize = function (e, r) {
            var n = this;
            if ("string" == typeof e)
              e = (function e(t) {
                return t.map(function (t) {
                  return (t.nodes && (t.nodes = e(t.nodes)), delete t.source, t);
                });
              })(iB(e).nodes);
            else if (void 0 === e) e = [];
            else if (Array.isArray(e)) {
              e = e.slice(0);
              for (var i, o = P(e); !(i = o()).done;) {
                var s = i.value;
                s.parent && s.parent.removeChild(s, "ignore");
              }
            } else if ("root" === e.type && "document" !== this.type) {
              e = e.nodes.slice(0);
              for (var a, c = P(e); !(a = c()).done;) {
                var u = a.value;
                u.parent && u.parent.removeChild(u, "ignore");
              }
            } else if (e.type) e = [e];
            else if (e.prop) {
              if (void 0 === e.value) throw Error("Value field is missed in node creation");
              ("string" != typeof e.value && (e.value = String(e.value)), (e = [new t4(e)]));
            } else if (e.selector) e = [new ij(e)];
            else if (e.name) e = [new iV(e)];
            else if (e.text) e = [new rw(e)];
            else throw Error("Unknown node type in node creation");
            return e.map(function (e) {
              return (
                e[rS] || t.rebuild(e),
                (e = e.proxyOf).parent && e.parent.removeChild(e),
                e[rI] &&
                  (function e(t) {
                    if (((t[rI] = !1), t.proxyOf.nodes))
                      for (var r, n = P(t.proxyOf.nodes); !(r = n()).done;) e(r.value);
                  })(e),
                void 0 === e.raws.before &&
                  r &&
                  void 0 !== r.raws.before &&
                  (e.raws.before = r.raws.before.replace(/\S/g, "")),
                (e.parent = n.proxyOf),
                e
              );
            });
          }),
          (r.prepend = function () {
            for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
            t = t.reverse();
            for (var n, i = P(t); !(n = i()).done;) {
              for (
                var o, s = n.value, a = this.normalize(s, this.first, "prepend").reverse(), c = P(a);
                !(o = c()).done;
              ) {
                var u = o.value;
                this.proxyOf.nodes.unshift(u);
              }
              for (var l in this.indexes) this.indexes[l] = this.indexes[l] + a.length;
            }
            return (this.markDirty(), this);
          }),
          (r.push = function (e) {
            return ((e.parent = this), this.proxyOf.nodes.push(e), this);
          }),
          (r.removeAll = function () {
            for (var e, t = P(this.proxyOf.nodes); !(e = t()).done;) e.value.parent = void 0;
            return ((this.proxyOf.nodes = []), this.markDirty(), this);
          }),
          (r.removeChild = function (e) {
            var t;
            for (var r in ((e = this.index(e)),
            (this.proxyOf.nodes[e].parent = void 0),
            this.proxyOf.nodes.splice(e, 1),
            this.indexes))
              (t = this.indexes[r]) >= e && (this.indexes[r] = t - 1);
            return (this.markDirty(), this);
          }),
          (r.replaceValues = function (e, t, r) {
            return (
              r || ((r = t), (t = {})),
              this.walkDecls(function (n) {
                (t.props && !t.props.includes(n.prop)) ||
                  ((!t.fast || n.value.includes(t.fast)) && (n.value = n.value.replace(e, r)));
              }),
              this.markDirty(),
              this
            );
          }),
          (r.some = function (e) {
            return this.nodes.some(e);
          }),
          (r.walk = function (e) {
            return this.each(function (t, r) {
              var n;
              try {
                n = e(t, r);
              } catch (e) {
                throw t.addToError(e);
              }
              return (!1 !== n && t.walk && (n = t.walk(e)), n);
            });
          }),
          (r.walkAtRules = function (e, t) {
            return t
              ? A(e, RegExp)
                ? this.walk(function (r, n) {
                    if ("atrule" === r.type && e.test(r.name)) return t(r, n);
                  })
                : this.walk(function (r, n) {
                    if ("atrule" === r.type && r.name === e) return t(r, n);
                  })
              : ((t = e),
                this.walk(function (e, r) {
                  if ("atrule" === e.type) return t(e, r);
                }));
          }),
          (r.walkComments = function (e) {
            return this.walk(function (t, r) {
              if ("comment" === t.type) return e(t, r);
            });
          }),
          (r.walkDecls = function (e, t) {
            return t
              ? A(e, RegExp)
                ? this.walk(function (r, n) {
                    if ("decl" === r.type && e.test(r.prop)) return t(r, n);
                  })
                : this.walk(function (r, n) {
                    if ("decl" === r.type && r.prop === e) return t(r, n);
                  })
              : ((t = e),
                this.walk(function (e, r) {
                  if ("decl" === e.type) return t(e, r);
                }));
          }),
          (r.walkRules = function (e, t) {
            return t
              ? A(e, RegExp)
                ? this.walk(function (r, n) {
                    if ("rule" === r.type && e.test(r.selector)) return t(r, n);
                  })
                : this.walk(function (r, n) {
                    if ("rule" === r.type && r.selector === e) return t(r, n);
                  })
              : ((t = e),
                this.walk(function (e, r) {
                  if ("rule" === e.type) return t(e, r);
                }));
          }),
          I(t, [
            {
              key: "first",
              get: function () {
                if (this.proxyOf.nodes) return this.proxyOf.nodes[0];
              },
            },
            {
              key: "last",
              get: function () {
                if (this.proxyOf.nodes) return this.proxyOf.nodes[this.proxyOf.nodes.length - 1];
              },
            },
          ]),
          t
        );
      })(t3);
    ((rk.registerParse = function (e) {
      iB = e;
    }),
      (rk.registerRule = function (e) {
        ij = e;
      }),
      (rk.registerAtRule = function (e) {
        iV = e;
      }),
      (rk.registerRoot = function (e) {
        iG = e;
      }),
      (rk.default = rk),
      (rk.rebuild = function (e) {
        ("atrule" === e.type
          ? Object.setPrototypeOf(e, iV.prototype)
          : "rule" === e.type
            ? Object.setPrototypeOf(e, ij.prototype)
            : "decl" === e.type
              ? Object.setPrototypeOf(e, t4.prototype)
              : "comment" === e.type
                ? Object.setPrototypeOf(e, rw.prototype)
                : "root" === e.type && Object.setPrototypeOf(e, iG.prototype),
          (e[rS] = !0),
          e.nodes &&
            e.nodes.forEach(function (e) {
              rk.rebuild(e);
            }));
      }));
    var rO = (function (e) {
      function t(t) {
        var r;
        return ((r = e.call(this, S({ type: "document" }, t)) || this).nodes || (r.nodes = []), r);
      }
      return (
        O(t, e),
        (t.prototype.toResult = function (e) {
          return (void 0 === e && (e = {}), new iW(new iz(), this, e).stringify());
        }),
        t
      );
    })(rk);
    ((rO.registerLazyResult = function (e) {
      iW = e;
    }),
      (rO.registerProcessor = function (e) {
        iz = e;
      }),
      (rO.default = rO));
    var rA = (function () {
      function e(e, t) {
        if ((void 0 === t && (t = {}), (this.type = "warning"), (this.text = e), t.node && t.node.source)) {
          var r = t.node.rangeBy(t);
          ((this.line = r.start.line),
            (this.column = r.start.column),
            (this.endLine = r.end.line),
            (this.endColumn = r.end.column));
        }
        for (var n in t) this[n] = t[n];
      }
      return (
        (e.prototype.toString = function () {
          return this.node
            ? this.node.error(this.text, { index: this.index, plugin: this.plugin, word: this.word }).message
            : this.plugin
              ? this.plugin + ": " + this.text
              : this.text;
        }),
        e
      );
    })();
    rA.default = rA;
    var rR = (function () {
      function e(e, t, r) {
        ((this.processor = e),
          (this.messages = []),
          (this.root = t),
          (this.opts = r),
          (this.css = void 0),
          (this.map = void 0));
      }
      var t = e.prototype;
      return (
        (t.toString = function () {
          return this.css;
        }),
        (t.warn = function (e, t) {
          (void 0 === t && (t = {}),
            !t.plugin &&
              this.lastPlugin &&
              this.lastPlugin.postcssPlugin &&
              (t.plugin = this.lastPlugin.postcssPlugin));
          var r = new rA(e, t);
          return (this.messages.push(r), r);
        }),
        (t.warnings = function () {
          return this.messages.filter(function (e) {
            return "warning" === e.type;
          });
        }),
        I(e, [
          {
            key: "content",
            get: function () {
              return this.css;
            },
          },
        ]),
        e
      );
    })();
    rR.default = rR;
    var rT = /[\t\n\f\r "#'()/;[\\\]{}]/g,
      rx = /[\t\n\f\r !"#'():;@[\\\]{}]|\/(?=\*)/g,
      rM = /.[\r\n"'(/\\]/,
      rL = /[\da-f]/i,
      rP = (function (e) {
        function t(t) {
          var r;
          return (((r = e.call(this, t) || this).type = "atrule"), r);
        }
        O(t, e);
        var r = t.prototype;
        return (
          (r.append = function () {
            for (var t, r = arguments.length, n = Array(r), i = 0; i < r; i++) n[i] = arguments[i];
            return (
              this.proxyOf.nodes || (this.nodes = []),
              (t = e.prototype.append).call.apply(t, [].concat([this], n))
            );
          }),
          (r.prepend = function () {
            for (var t, r = arguments.length, n = Array(r), i = 0; i < r; i++) n[i] = arguments[i];
            return (
              this.proxyOf.nodes || (this.nodes = []),
              (t = e.prototype.prepend).call.apply(t, [].concat([this], n))
            );
          }),
          t
        );
      })(rk);
    ((rP.default = rP), rk.registerAtRule(rP));
    var rD = (function (e) {
      function t(t) {
        var r;
        return (((r = e.call(this, t) || this).type = "root"), r.nodes || (r.nodes = []), r);
      }
      O(t, e);
      var r = t.prototype;
      return (
        (r.normalize = function (t, r, n) {
          var i = e.prototype.normalize.call(this, t);
          if (r) {
            if ("prepend" === n)
              this.nodes.length > 1 ? (r.raws.before = this.nodes[1].raws.before) : delete r.raws.before;
            else if (this.first !== r)
              for (var o, s = P(i); !(o = s()).done;) o.value.raws.before = r.raws.before;
          }
          return i;
        }),
        (r.removeChild = function (t, r) {
          var n = this.index(t);
          return (
            !r && 0 === n && this.nodes.length > 1 && (this.nodes[1].raws.before = this.nodes[n].raws.before),
            e.prototype.removeChild.call(this, t)
          );
        }),
        (r.toResult = function (e) {
          return (void 0 === e && (e = {}), new iK(new iq(), this, e).stringify());
        }),
        t
      );
    })(rk);
    ((rD.registerLazyResult = function (e) {
      iK = e;
    }),
      (rD.registerProcessor = function (e) {
        iq = e;
      }),
      (rD.default = rD),
      rk.registerRoot(rD));
    var rN = {
      comma: function (e) {
        return rN.split(e, [","], !0);
      },
      space: function (e) {
        return rN.split(e, [" ", "\n", "	"]);
      },
      split: function (e, t, r) {
        for (var n, i = [], o = "", s = !1, a = 0, c = !1, u = "", l = !1, p = P(e); !(n = p()).done;) {
          var h = n.value;
          (l
            ? (l = !1)
            : "\\" === h
              ? (l = !0)
              : c
                ? h === u && (c = !1)
                : '"' === h || "'" === h
                  ? ((c = !0), (u = h))
                  : "(" === h
                    ? (a += 1)
                    : ")" === h
                      ? a > 0 && (a -= 1)
                      : 0 === a && t.includes(h) && (s = !0),
            s ? ("" !== o && i.push(o.trim()), (o = ""), (s = !1)) : (o += h));
        }
        return ((r || "" !== o) && i.push(o.trim()), i);
      },
    };
    rN.default = rN;
    var rF = (function (e) {
      function t(t) {
        var r;
        return (((r = e.call(this, t) || this).type = "rule"), r.nodes || (r.nodes = []), r);
      }
      return (
        O(t, e),
        I(t, [
          {
            key: "selectors",
            get: function () {
              return rN.comma(this.selector);
            },
            set: function (e) {
              var t = this.selector ? this.selector.match(/,\s*/) : null,
                r = t ? t[0] : "," + this.raw("between", "beforeOpen");
              this.selector = e.join(r);
            },
          },
        ]),
        t
      );
    })(rk);
    ((rF.default = rF), rk.registerRule(rF));
    var rU = function (e, t) {
        void 0 === t && (t = {});
        var r,
          n,
          i,
          o,
          s,
          a,
          c,
          u,
          l,
          p,
          h = e.css.valueOf(),
          d = t.ignoreErrors,
          f = h.length,
          g = 0,
          m = [],
          _ = [];
        function v(t) {
          throw e.error("Unclosed " + t, g);
        }
        return {
          back: function (e) {
            _.push(e);
          },
          endOfFile: function () {
            return 0 === _.length && g >= f;
          },
          nextToken: function (e) {
            if (_.length) return _.pop();
            if (!(g >= f)) {
              var t = !!e && e.ignoreUnclosed;
              switch ((r = h.charCodeAt(g))) {
                case 10:
                case 32:
                case 9:
                case 13:
                case 12:
                  n = g;
                  do ((n += 1), (r = h.charCodeAt(n)));
                  while (32 === r || 10 === r || 9 === r || 13 === r || 12 === r);
                  ((p = ["space", h.slice(g, n)]), (g = n - 1));
                  break;
                case 91:
                case 93:
                case 123:
                case 125:
                case 58:
                case 59:
                case 41:
                  var y = String.fromCharCode(r);
                  p = [y, y, g];
                  break;
                case 40:
                  if (
                    ((u = m.length ? m.pop()[1] : ""),
                    (l = h.charCodeAt(g + 1)),
                    "url" === u &&
                      39 !== l &&
                      34 !== l &&
                      32 !== l &&
                      10 !== l &&
                      9 !== l &&
                      12 !== l &&
                      13 !== l)
                  ) {
                    n = g;
                    do {
                      if (((a = !1), -1 === (n = h.indexOf(")", n + 1))))
                        if (d || t) {
                          n = g;
                          break;
                        } else v("bracket");
                      for (c = n; 92 === h.charCodeAt(c - 1);) ((c -= 1), (a = !a));
                    } while (a);
                    ((p = ["brackets", h.slice(g, n + 1), g, n]), (g = n));
                  } else
                    ((n = h.indexOf(")", g + 1)),
                      (o = h.slice(g, n + 1)),
                      -1 === n || rM.test(o) ? (p = ["(", "(", g]) : ((p = ["brackets", o, g, n]), (g = n)));
                  break;
                case 39:
                case 34:
                  ((i = 39 === r ? "'" : '"'), (n = g));
                  do {
                    if (((a = !1), -1 === (n = h.indexOf(i, n + 1))))
                      if (d || t) {
                        n = g + 1;
                        break;
                      } else v("string");
                    for (c = n; 92 === h.charCodeAt(c - 1);) ((c -= 1), (a = !a));
                  } while (a);
                  ((p = ["string", h.slice(g, n + 1), g, n]), (g = n));
                  break;
                case 64:
                  ((rT.lastIndex = g + 1),
                    rT.test(h),
                    (n = 0 === rT.lastIndex ? h.length - 1 : rT.lastIndex - 2),
                    (p = ["at-word", h.slice(g, n + 1), g, n]),
                    (g = n));
                  break;
                case 92:
                  for (n = g, s = !0; 92 === h.charCodeAt(n + 1);) ((n += 1), (s = !s));
                  if (
                    ((r = h.charCodeAt(n + 1)),
                    s &&
                      47 !== r &&
                      32 !== r &&
                      10 !== r &&
                      9 !== r &&
                      13 !== r &&
                      12 !== r &&
                      ((n += 1), rL.test(h.charAt(n))))
                  ) {
                    for (; rL.test(h.charAt(n + 1));) n += 1;
                    32 === h.charCodeAt(n + 1) && (n += 1);
                  }
                  ((p = ["word", h.slice(g, n + 1), g, n]), (g = n));
                  break;
                default:
                  (47 === r && 42 === h.charCodeAt(g + 1)
                    ? (0 === (n = h.indexOf("*/", g + 2) + 1) && (d || t ? (n = h.length) : v("comment")),
                      (p = ["comment", h.slice(g, n + 1), g, n]))
                    : ((rx.lastIndex = g + 1),
                      rx.test(h),
                      (n = 0 === rx.lastIndex ? h.length - 1 : rx.lastIndex - 2),
                      (p = ["word", h.slice(g, n + 1), g, n]),
                      m.push(p)),
                    (g = n));
              }
              return (g++, p);
            }
          },
          position: function () {
            return g;
          },
        };
      },
      rB = { empty: !0, space: !0 },
      rj = (function () {
        function e(e) {
          ((this.input = e),
            (this.root = new rD()),
            (this.current = this.root),
            (this.spaces = ""),
            (this.semicolon = !1),
            this.createTokenizer(),
            (this.root.source = { input: e, start: { column: 1, line: 1, offset: 0 } }));
        }
        var t = e.prototype;
        return (
          (t.atrule = function (e) {
            var t,
              r,
              n,
              i = new rP();
            ((i.name = e[1].slice(1)), "" === i.name && this.unnamedAtrule(i, e), this.init(i, e[2]));
            for (var o = !1, s = !1, a = [], c = []; !this.tokenizer.endOfFile();) {
              if (
                ("(" === (t = (e = this.tokenizer.nextToken())[0]) || "[" === t
                  ? c.push("(" === t ? ")" : "]")
                  : "{" === t && c.length > 0
                    ? c.push("}")
                    : t === c[c.length - 1] && c.pop(),
                0 === c.length)
              )
                if (";" === t) {
                  ((i.source.end = this.getPosition(e[2])), i.source.end.offset++, (this.semicolon = !0));
                  break;
                } else if ("{" === t) {
                  s = !0;
                  break;
                } else if ("}" === t) {
                  if (a.length > 0) {
                    for (n = a.length - 1, r = a[n]; r && "space" === r[0];) r = a[--n];
                    r && ((i.source.end = this.getPosition(r[3] || r[2])), i.source.end.offset++);
                  }
                  this.end(e);
                  break;
                } else a.push(e);
              else a.push(e);
              if (this.tokenizer.endOfFile()) {
                o = !0;
                break;
              }
            }
            ((i.raws.between = this.spacesAndCommentsFromEnd(a)),
              a.length
                ? ((i.raws.afterName = this.spacesAndCommentsFromStart(a)),
                  this.raw(i, "params", a),
                  o &&
                    ((e = a[a.length - 1]),
                    (i.source.end = this.getPosition(e[3] || e[2])),
                    i.source.end.offset++,
                    (this.spaces = i.raws.between),
                    (i.raws.between = "")))
                : ((i.raws.afterName = ""), (i.params = "")),
              s && ((i.nodes = []), (this.current = i)));
          }),
          (t.checkMissedSemicolon = function (e) {
            var t,
              r = this.colon(e);
            if (!1 !== r) {
              for (var n = 0, i = r - 1; i >= 0 && ("space" === (t = e[i])[0] || 2 !== (n += 1)); i--);
              throw this.input.error("Missed semicolon", "word" === t[0] ? t[3] + 1 : t[2]);
            }
          }),
          (t.colon = function (e) {
            for (var t, r, n, i = 0, o = P(e.entries()); !(n = o()).done;) {
              var s = n.value,
                a = s[0],
                c = s[1];
              if (("(" === (t = c[0]) && (i += 1), ")" === t && (i -= 1), 0 === i && ":" === t))
                if (r)
                  if ("word" === r[0] && "progid" === r[1]) continue;
                  else return a;
                else this.doubleColon(c);
              r = c;
            }
            return !1;
          }),
          (t.comment = function (e) {
            var t = new rw();
            (this.init(t, e[2]), (t.source.end = this.getPosition(e[3] || e[2])), t.source.end.offset++);
            var r = e[1].slice(2, -2);
            if (/^\s*$/.test(r)) ((t.text = ""), (t.raws.left = r), (t.raws.right = ""));
            else {
              var n = r.match(/^(\s*)([^]*\S)(\s*)$/);
              ((t.text = n[2]), (t.raws.left = n[1]), (t.raws.right = n[3]));
            }
          }),
          (t.createTokenizer = function () {
            this.tokenizer = rU(this.input);
          }),
          (t.decl = function (e, t) {
            var r,
              n,
              i = new t4();
            this.init(i, e[0][2]);
            var o = e[e.length - 1];
            for (
              ";" === o[0] && ((this.semicolon = !0), e.pop()),
                i.source.end = this.getPosition(
                  o[3] ||
                    o[2] ||
                    (function (e) {
                      for (var t = e.length - 1; t >= 0; t--) {
                        var r = e[t],
                          n = r[3] || r[2];
                        if (n) return n;
                      }
                    })(e),
                ),
                i.source.end.offset++;
              "word" !== e[0][0];
            )
              (1 === e.length && this.unknownWord(e), (i.raws.before += e.shift()[1]));
            for (i.source.start = this.getPosition(e[0][2]), i.prop = ""; e.length;) {
              var s = e[0][0];
              if (":" === s || "space" === s || "comment" === s) break;
              i.prop += e.shift()[1];
            }
            for (i.raws.between = ""; e.length;) {
              if (":" === (r = e.shift())[0]) {
                i.raws.between += r[1];
                break;
              }
              ("word" === r[0] && /\w/.test(r[1]) && this.unknownWord([r]), (i.raws.between += r[1]));
            }
            ("_" === i.prop[0] || "*" === i.prop[0]) &&
              ((i.raws.before += i.prop[0]), (i.prop = i.prop.slice(1)));
            for (var a = []; e.length && ("space" === (n = e[0][0]) || "comment" === n);) a.push(e.shift());
            this.precheckMissedSemicolon(e);
            for (var c = e.length - 1; c >= 0; c--) {
              if ("!important" === (r = e[c])[1].toLowerCase()) {
                i.important = !0;
                var u = this.stringFrom(e, c);
                " !important" !== (u = this.spacesFromEnd(e) + u) && (i.raws.important = u);
                break;
              }
              if ("important" === r[1].toLowerCase()) {
                for (var l = e.slice(0), p = "", h = c; h > 0; h--) {
                  var d = l[h][0];
                  if (0 === p.trim().indexOf("!") && "space" !== d) break;
                  p = l.pop()[1] + p;
                }
                0 === p.trim().indexOf("!") && ((i.important = !0), (i.raws.important = p), (e = l));
              }
              if ("space" !== r[0] && "comment" !== r[0]) break;
            }
            (e.some(function (e) {
              return "space" !== e[0] && "comment" !== e[0];
            }) &&
              ((i.raws.between += a
                .map(function (e) {
                  return e[1];
                })
                .join("")),
              (a = [])),
              this.raw(i, "value", a.concat(e), t),
              i.value.includes(":") && !t && this.checkMissedSemicolon(e));
          }),
          (t.doubleColon = function (e) {
            throw this.input.error("Double colon", { offset: e[2] }, { offset: e[2] + e[1].length });
          }),
          (t.emptyRule = function (e) {
            var t = new rF();
            (this.init(t, e[2]), (t.selector = ""), (t.raws.between = ""), (this.current = t));
          }),
          (t.end = function (e) {
            (this.current.nodes &&
              this.current.nodes.length &&
              (this.current.raws.semicolon = this.semicolon),
              (this.semicolon = !1),
              (this.current.raws.after = (this.current.raws.after || "") + this.spaces),
              (this.spaces = ""),
              this.current.parent
                ? ((this.current.source.end = this.getPosition(e[2])),
                  this.current.source.end.offset++,
                  (this.current = this.current.parent))
                : this.unexpectedClose(e));
          }),
          (t.endFile = function () {
            (this.current.parent && this.unclosedBlock(),
              this.current.nodes &&
                this.current.nodes.length &&
                (this.current.raws.semicolon = this.semicolon),
              (this.current.raws.after = (this.current.raws.after || "") + this.spaces),
              (this.root.source.end = this.getPosition(this.tokenizer.position())));
          }),
          (t.freeSemicolon = function (e) {
            if (((this.spaces += e[1]), this.current.nodes)) {
              var t = this.current.nodes[this.current.nodes.length - 1];
              t &&
                "rule" === t.type &&
                !t.raws.ownSemicolon &&
                ((t.raws.ownSemicolon = this.spaces), (this.spaces = ""));
            }
          }),
          (t.getPosition = function (e) {
            var t = this.input.fromOffset(e);
            return { column: t.col, line: t.line, offset: e };
          }),
          (t.init = function (e, t) {
            (this.current.push(e),
              (e.source = { input: this.input, start: this.getPosition(t) }),
              (e.raws.before = this.spaces),
              (this.spaces = ""),
              "comment" !== e.type && (this.semicolon = !1));
          }),
          (t.other = function (e) {
            for (
              var t = !1, r = null, n = !1, i = null, o = [], s = e[1].startsWith("--"), a = [], c = e;
              c;
            ) {
              if (((r = c[0]), a.push(c), "(" === r || "[" === r))
                (i || (i = c), o.push("(" === r ? ")" : "]"));
              else if (s && n && "{" === r) (i || (i = c), o.push("}"));
              else if (0 === o.length)
                if (";" === r)
                  if (n) return void this.decl(a, s);
                  else break;
                else if ("{" === r) return void this.rule(a);
                else if ("}" === r) {
                  (this.tokenizer.back(a.pop()), (t = !0));
                  break;
                } else ":" === r && (n = !0);
              else r === o[o.length - 1] && (o.pop(), 0 === o.length && (i = null));
              c = this.tokenizer.nextToken();
            }
            if ((this.tokenizer.endOfFile() && (t = !0), o.length > 0 && this.unclosedBracket(i), t && n)) {
              if (!s)
                for (; a.length && ("space" === (c = a[a.length - 1][0]) || "comment" === c);)
                  this.tokenizer.back(a.pop());
              this.decl(a, s);
            } else this.unknownWord(a);
          }),
          (t.parse = function () {
            for (var e; !this.tokenizer.endOfFile();)
              switch ((e = this.tokenizer.nextToken())[0]) {
                case "space":
                  this.spaces += e[1];
                  break;
                case ";":
                  this.freeSemicolon(e);
                  break;
                case "}":
                  this.end(e);
                  break;
                case "comment":
                  this.comment(e);
                  break;
                case "at-word":
                  this.atrule(e);
                  break;
                case "{":
                  this.emptyRule(e);
                  break;
                default:
                  this.other(e);
              }
            this.endFile();
          }),
          (t.precheckMissedSemicolon = function () {}),
          (t.raw = function (e, t, r, n) {
            for (var i, o, s, a, c = r.length, u = "", l = !0, p = 0; p < c; p += 1)
              "space" !== (o = (i = r[p])[0]) || p !== c - 1 || n
                ? "comment" === o
                  ? ((a = r[p - 1] ? r[p - 1][0] : "empty"),
                    (s = r[p + 1] ? r[p + 1][0] : "empty"),
                    rB[a] || rB[s] || "," === u.slice(-1) ? (l = !1) : (u += i[1]))
                  : (u += i[1])
                : (l = !1);
            if (!l) {
              var h = r.reduce(function (e, t) {
                return e + t[1];
              }, "");
              e.raws[t] = { raw: h, value: u };
            }
            e[t] = u;
          }),
          (t.rule = function (e) {
            e.pop();
            var t = new rF();
            (this.init(t, e[0][2]),
              (t.raws.between = this.spacesAndCommentsFromEnd(e)),
              this.raw(t, "selector", e),
              (this.current = t));
          }),
          (t.spacesAndCommentsFromEnd = function (e) {
            for (var t, r = ""; e.length && ("space" === (t = e[e.length - 1][0]) || "comment" === t);)
              r = e.pop()[1] + r;
            return r;
          }),
          (t.spacesAndCommentsFromStart = function (e) {
            for (var t, r = ""; e.length && ("space" === (t = e[0][0]) || "comment" === t);)
              r += e.shift()[1];
            return r;
          }),
          (t.spacesFromEnd = function (e) {
            for (var t = ""; e.length && "space" === e[e.length - 1][0];) t = e.pop()[1] + t;
            return t;
          }),
          (t.stringFrom = function (e, t) {
            for (var r = "", n = t; n < e.length; n++) r += e[n][1];
            return (e.splice(t, e.length - t), r);
          }),
          (t.unclosedBlock = function () {
            var e = this.current.source.start;
            throw this.input.error("Unclosed block", e.line, e.column);
          }),
          (t.unclosedBracket = function (e) {
            throw this.input.error("Unclosed bracket", { offset: e[2] }, { offset: e[2] + 1 });
          }),
          (t.unexpectedClose = function (e) {
            throw this.input.error("Unexpected }", { offset: e[2] }, { offset: e[2] + 1 });
          }),
          (t.unknownWord = function (e) {
            throw this.input.error("Unknown word", { offset: e[0][2] }, { offset: e[0][2] + e[0][1].length });
          }),
          (t.unnamedAtrule = function (e, t) {
            throw this.input.error("At-rule without name", { offset: t[2] }, { offset: t[2] + t[1].length });
          }),
          e
        );
      })();
    function rV(e, t) {
      var r = new rj(new rh(e, t));
      try {
        r.parse();
      } catch (e) {
        throw e;
      }
      return r.root;
    }
    ((rV.default = rV), rk.registerParse(rV));
    var rG = tJ.isClean,
      rW = tJ.my,
      rz = {
        atrule: "AtRule",
        comment: "Comment",
        decl: "Declaration",
        document: "Document",
        root: "Root",
        rule: "Rule",
      },
      rK = {
        AtRule: !0,
        AtRuleExit: !0,
        Comment: !0,
        CommentExit: !0,
        Declaration: !0,
        DeclarationExit: !0,
        Document: !0,
        DocumentExit: !0,
        Once: !0,
        OnceExit: !0,
        postcssPlugin: !0,
        prepare: !0,
        Root: !0,
        RootExit: !0,
        Rule: !0,
        RuleExit: !0,
      },
      rq = { Once: !0, postcssPlugin: !0, prepare: !0 };
    function rY(e) {
      return (void 0 === e ? "undefined" : x(e)) === "object" && "function" == typeof e.then;
    }
    function r$(e) {
      var t = !1,
        r = rz[e.type];
      return ("decl" === e.type
        ? (t = e.prop.toLowerCase())
        : "atrule" === e.type && (t = e.name.toLowerCase()),
      t && e.append)
        ? [r, r + "-" + t, 0, r + "Exit", r + "Exit-" + t]
        : t
          ? [r, r + "-" + t, r + "Exit", r + "Exit-" + t]
          : e.append
            ? [r, 0, r + "Exit"]
            : [r, r + "Exit"];
    }
    function rH(e) {
      return {
        eventIndex: 0,
        events:
          "document" === e.type
            ? ["Document", 0, "DocumentExit"]
            : "root" === e.type
              ? ["Root", 0, "RootExit"]
              : r$(e),
        iterator: 0,
        node: e,
        visitorIndex: 0,
        visitors: [],
      };
    }
    function rZ(e) {
      return (
        (e[rG] = !1),
        e.nodes &&
          e.nodes.forEach(function (e) {
            return rZ(e);
          }),
        e
      );
    }
    var rJ = {},
      rX = (function () {
        function e(t, r, n) {
          var i,
            o = this;
          if (
            ((this.stringified = !1),
            (this.processed = !1),
            (void 0 === r ? "undefined" : x(r)) === "object" &&
              null !== r &&
              ("root" === r.type || "document" === r.type))
          )
            i = rZ(r);
          else if (A(r, e) || A(r, rR))
            ((i = rZ(r.root)),
              r.map &&
                (void 0 === n.map && (n.map = {}),
                n.map.inline || (n.map.inline = !1),
                (n.map.prev = r.map)));
          else {
            var s = rV;
            (n.syntax && (s = n.syntax.parse), n.parser && (s = n.parser), s.parse && (s = s.parse));
            try {
              i = s(r, n);
            } catch (e) {
              ((this.processed = !0), (this.error = e));
            }
            i && !i[rW] && rk.rebuild(i);
          }
          ((this.result = new rR(t, i, n)),
            (this.helpers = S({}, rJ, { postcss: rJ, result: this.result })),
            (this.plugins = this.processor.plugins.map(function (e) {
              return (void 0 === e ? "undefined" : x(e)) === "object" && e.prepare
                ? S({}, e, e.prepare(o.result))
                : e;
            })));
        }
        var t = e.prototype;
        return (
          (t.async = function () {
            return this.error
              ? Promise.reject(this.error)
              : this.processed
                ? Promise.resolve(this.result)
                : (this.processing || (this.processing = this.runAsync()), this.processing);
          }),
          (t.catch = function (e) {
            return this.async().catch(e);
          }),
          (t.finally = function (e) {
            return this.async().then(e, e);
          }),
          (t.getAsyncError = function () {
            throw Error("Use process(css).then(cb) to work with async plugins");
          }),
          (t.handleError = function (e, t) {
            var r = this.result.lastPlugin;
            try {
              (t && t.addToError(e),
                (this.error = e),
                "CssSyntaxError" !== e.name || e.plugin
                  ? r.postcssVersion
                  : ((e.plugin = r.postcssPlugin), e.setMessage()));
            } catch (e) {
              console && console.error && console.error(e);
            }
            return e;
          }),
          (t.prepareVisitors = function () {
            var e = this;
            this.listeners = {};
            for (
              var t,
                r = function (t, r, n) {
                  (e.listeners[r] || (e.listeners[r] = []), e.listeners[r].push([t, n]));
                },
                n = P(this.plugins);
              !(t = n()).done;
            ) {
              var i = t.value;
              if ((void 0 === i ? "undefined" : x(i)) === "object")
                for (var o in i) {
                  if (!rK[o] && /^[A-Z]/.test(o))
                    throw Error(
                      "Unknown event " +
                        o +
                        " in " +
                        i.postcssPlugin +
                        ". Try to update PostCSS (" +
                        this.processor.version +
                        " now).",
                    );
                  if (!rq[o])
                    if ("object" === x(i[o]))
                      for (var s in i[o]) r(i, "*" === s ? o : o + "-" + s.toLowerCase(), i[o][s]);
                    else "function" == typeof i[o] && r(i, o, i[o]);
                }
            }
            this.hasListener = Object.keys(this.listeners).length > 0;
          }),
          (t.runAsync = function () {
            var e = this;
            return E(function () {
              var t, r, n, i, o, s, a, c, u, l, p, h;
              return D(this, function (d) {
                switch (d.label) {
                  case 0:
                    ((e.plugin = 0), (t = 0), (d.label = 1));
                  case 1:
                    if (!(t < e.plugins.length)) return [3, 6];
                    if (((r = e.plugins[t]), !rY((n = e.runOnRoot(r))))) return [3, 5];
                    d.label = 2;
                  case 2:
                    return (d.trys.push([2, 4, , 5]), [4, n]);
                  case 3:
                    return (d.sent(), [3, 5]);
                  case 4:
                    throw ((i = d.sent()), e.handleError(i));
                  case 5:
                    return (t++, [3, 1]);
                  case 6:
                    if ((e.prepareVisitors(), !e.hasListener)) return [3, 18];
                    ((o = e.result.root), (d.label = 7));
                  case 7:
                    if (o[rG]) return [3, 14];
                    ((o[rG] = !0), (s = [rH(o)]), (d.label = 8));
                  case 8:
                    if (!(s.length > 0)) return [3, 13];
                    if (!rY((a = e.visitTick(s)))) return [3, 12];
                    d.label = 9;
                  case 9:
                    return (d.trys.push([9, 11, , 12]), [4, a]);
                  case 10:
                    return (d.sent(), [3, 12]);
                  case 11:
                    throw ((c = d.sent()), (u = s[s.length - 1].node), e.handleError(c, u));
                  case 12:
                    return [3, 8];
                  case 13:
                    return [3, 7];
                  case 14:
                    if (!e.listeners.OnceExit) return [3, 18];
                    ((l = function () {
                      var t, r, n, i;
                      return D(this, function (s) {
                        switch (s.label) {
                          case 0:
                            ((r = (t = h.value)[0]), (n = t[1]), (e.result.lastPlugin = r), (s.label = 1));
                          case 1:
                            if ((s.trys.push([1, 6, , 7]), "document" !== o.type)) return [3, 3];
                            return [
                              4,
                              Promise.all(
                                o.nodes.map(function (t) {
                                  return n(t, e.helpers);
                                }),
                              ),
                            ];
                          case 2:
                            return (s.sent(), [3, 5]);
                          case 3:
                            return [4, n(o, e.helpers)];
                          case 4:
                            (s.sent(), (s.label = 5));
                          case 5:
                            return [3, 7];
                          case 6:
                            throw ((i = s.sent()), e.handleError(i));
                          case 7:
                            return [2];
                        }
                      });
                    }),
                      (p = P(e.listeners.OnceExit)),
                      (d.label = 15));
                  case 15:
                    if ((h = p()).done) return [3, 18];
                    return [5, N(l())];
                  case 16:
                    (d.sent(), (d.label = 17));
                  case 17:
                    return [3, 15];
                  case 18:
                    return ((e.processed = !0), [2, e.stringify()]);
                }
              });
            })();
          }),
          (t.runOnRoot = function (e) {
            var t = this;
            this.result.lastPlugin = e;
            try {
              if ((void 0 === e ? "undefined" : x(e)) === "object" && e.Once) {
                if ("document" === this.result.root.type) {
                  var r = this.result.root.nodes.map(function (r) {
                    return e.Once(r, t.helpers);
                  });
                  if (rY(r[0])) return Promise.all(r);
                  return r;
                }
                return e.Once(this.result.root, this.helpers);
              }
              if ("function" == typeof e) return e(this.result.root, this.result);
            } catch (e) {
              throw this.handleError(e);
            }
          }),
          (t.stringify = function () {
            if (this.error) throw this.error;
            if (this.stringified) return this.result;
            ((this.stringified = !0), this.sync());
            var e = this.result.opts,
              t = t0;
            (e.syntax && (t = e.syntax.stringify),
              e.stringifier && (t = e.stringifier),
              t.stringify && (t = t.stringify));
            var r = new rE(t, this.result.root, this.result.opts).generate();
            return ((this.result.css = r[0]), (this.result.map = r[1]), this.result);
          }),
          (t.sync = function () {
            if (this.error) throw this.error;
            if (this.processed) return this.result;
            if (((this.processed = !0), this.processing)) throw this.getAsyncError();
            for (var e, t = P(this.plugins); !(e = t()).done;) {
              var r = e.value;
              if (rY(this.runOnRoot(r))) throw this.getAsyncError();
            }
            if ((this.prepareVisitors(), this.hasListener)) {
              for (var n = this.result.root; !n[rG];) ((n[rG] = !0), this.walkSync(n));
              if (this.listeners.OnceExit)
                if ("document" === n.type)
                  for (var i, o = P(n.nodes); !(i = o()).done;) {
                    var s = i.value;
                    this.visitSync(this.listeners.OnceExit, s);
                  }
                else this.visitSync(this.listeners.OnceExit, n);
            }
            return this.result;
          }),
          (t.then = function (e, t) {
            return this.async().then(e, t);
          }),
          (t.toString = function () {
            return this.css;
          }),
          (t.visitSync = function (e, t) {
            for (var r, n = P(e); !(r = n()).done;) {
              var i = r.value,
                o = i[0],
                s = i[1];
              this.result.lastPlugin = o;
              var a = void 0;
              try {
                a = s(t, this.helpers);
              } catch (e) {
                throw this.handleError(e, t.proxyOf);
              }
              if ("root" !== t.type && "document" !== t.type && !t.parent) return !0;
              if (rY(a)) throw this.getAsyncError();
            }
          }),
          (t.visitTick = function (e) {
            var t = e[e.length - 1],
              r = t.node,
              n = t.visitors;
            if ("root" !== r.type && "document" !== r.type && !r.parent) return void e.pop();
            if (n.length > 0 && t.visitorIndex < n.length) {
              var i = n[t.visitorIndex],
                o = i[0],
                s = i[1];
              ((t.visitorIndex += 1),
                t.visitorIndex === n.length && ((t.visitors = []), (t.visitorIndex = 0)),
                (this.result.lastPlugin = o));
              try {
                return s(r.toProxy(), this.helpers);
              } catch (e) {
                throw this.handleError(e, r);
              }
            }
            if (0 !== t.iterator) {
              for (var a, c = t.iterator; (a = r.nodes[r.indexes[c]]);)
                if (((r.indexes[c] += 1), !a[rG])) {
                  ((a[rG] = !0), e.push(rH(a)));
                  return;
                }
              ((t.iterator = 0), delete r.indexes[c]);
            }
            for (var u = t.events; t.eventIndex < u.length;) {
              var l = u[t.eventIndex];
              if (((t.eventIndex += 1), 0 === l)) {
                r.nodes && r.nodes.length && ((r[rG] = !0), (t.iterator = r.getIterator()));
                return;
              }
              if (this.listeners[l]) {
                t.visitors = this.listeners[l];
                return;
              }
            }
            e.pop();
          }),
          (t.walkSync = function (e) {
            var t = this;
            e[rG] = !0;
            for (var r, n = r$(e), i = P(n); !(r = i()).done;) {
              var o = r.value;
              if (0 === o)
                e.nodes &&
                  e.each(function (e) {
                    e[rG] || t.walkSync(e);
                  });
              else {
                var s = this.listeners[o];
                if (s && this.visitSync(s, e.toProxy())) return;
              }
            }
          }),
          (t.warnings = function () {
            return this.sync().warnings();
          }),
          I(e, [
            {
              key: "content",
              get: function () {
                return this.stringify().content;
              },
            },
            {
              key: "css",
              get: function () {
                return this.stringify().css;
              },
            },
            {
              key: "map",
              get: function () {
                return this.stringify().map;
              },
            },
            {
              key: "messages",
              get: function () {
                return this.sync().messages;
              },
            },
            {
              key: "opts",
              get: function () {
                return this.result.opts;
              },
            },
            {
              key: "processor",
              get: function () {
                return this.result.processor;
              },
            },
            {
              key: "root",
              get: function () {
                return this.sync().root;
              },
            },
            {
              key: Symbol.toStringTag,
              get: function () {
                return "LazyResult";
              },
            },
          ]),
          e
        );
      })();
    ((rX.registerPostcss = function (e) {
      rJ = e;
    }),
      (rX.default = rX),
      rD.registerLazyResult(rX),
      rO.registerLazyResult(rX));
    var rQ = (function () {
      function e(e, t, r) {
        ((t = t.toString()),
          (this.stringified = !1),
          (this._processor = e),
          (this._css = t),
          (this._opts = r),
          (this._map = void 0),
          (this.result = new rR(this._processor, n, this._opts)),
          (this.result.css = t));
        var n,
          i = this;
        Object.defineProperty(this.result, "root", {
          get: function () {
            return i.root;
          },
        });
        var o = new rE(t0, n, this._opts, t);
        if (o.isMap()) {
          var s = o.generate(),
            a = s[0],
            c = s[1];
          (a && (this.result.css = a), c && (this.result.map = c));
        } else (o.clearAnnotation(), (this.result.css = o.css));
      }
      var t = e.prototype;
      return (
        (t.async = function () {
          return this.error ? Promise.reject(this.error) : Promise.resolve(this.result);
        }),
        (t.catch = function (e) {
          return this.async().catch(e);
        }),
        (t.finally = function (e) {
          return this.async().then(e, e);
        }),
        (t.sync = function () {
          if (this.error) throw this.error;
          return this.result;
        }),
        (t.then = function (e, t) {
          return this.async().then(e, t);
        }),
        (t.toString = function () {
          return this._css;
        }),
        (t.warnings = function () {
          return [];
        }),
        I(e, [
          {
            key: "content",
            get: function () {
              return this.result.css;
            },
          },
          {
            key: "css",
            get: function () {
              return this.result.css;
            },
          },
          {
            key: "map",
            get: function () {
              return this.result.map;
            },
          },
          {
            key: "messages",
            get: function () {
              return [];
            },
          },
          {
            key: "opts",
            get: function () {
              return this.result.opts;
            },
          },
          {
            key: "processor",
            get: function () {
              return this.result.processor;
            },
          },
          {
            key: "root",
            get: function () {
              var e;
              if (this._root) return this._root;
              try {
                e = rV(this._css, this._opts);
              } catch (e) {
                this.error = e;
              }
              if (!this.error) return ((this._root = e), e);
              throw this.error;
            },
          },
          {
            key: Symbol.toStringTag,
            get: function () {
              return "NoWorkResult";
            },
          },
        ]),
        e
      );
    })();
    rQ.default = rQ;
    var r0 = (function () {
      function e(e) {
        (void 0 === e && (e = []), (this.version = "8.4.38"), (this.plugins = this.normalize(e)));
      }
      var t = e.prototype;
      return (
        (t.normalize = function (e) {
          for (var t, r = [], n = P(e); !(t = n()).done;) {
            var i = t.value;
            if (
              (!0 === i.postcss ? (i = i()) : i.postcss && (i = i.postcss),
              (void 0 === i ? "undefined" : x(i)) === "object" && Array.isArray(i.plugins))
            )
              r = r.concat(i.plugins);
            else if ((void 0 === i ? "undefined" : x(i)) === "object" && i.postcssPlugin) r.push(i);
            else if ("function" == typeof i) r.push(i);
            else if ((void 0 === i ? "undefined" : x(i)) === "object" && (i.parse || i.stringify));
            else throw Error(i + " is not a PostCSS plugin");
          }
          return r;
        }),
        (t.process = function (e, t) {
          return (void 0 === t && (t = {}), this.plugins.length || t.parser || t.stringifier || t.syntax)
            ? new rX(this, e, t)
            : new rQ(this, e, t);
        }),
        (t.use = function (e) {
          return ((this.plugins = this.plugins.concat(this.normalize([e]))), this);
        }),
        e
      );
    })();
    function r1(e, t) {
      if (Array.isArray(e))
        return e.map(function (e) {
          return r1(e);
        });
      var r = e.inputs,
        n = R(e, ["inputs"]);
      if (r) {
        t = [];
        for (var i, o = P(r); !(i = o()).done;) {
          var s = i.value,
            a = S({}, s, { __proto__: rh.prototype });
          (a.map && (a.map = S({}, a.map, { __proto__: rt.prototype })), t.push(a));
        }
      }
      if (
        (n.nodes &&
          (n.nodes = e.nodes.map(function (e) {
            return r1(e, t);
          })),
        n.source)
      ) {
        var c = n.source,
          u = c.inputId;
        ((n.source = R(c, ["inputId"])), null != u && (n.source.input = t[u]));
      }
      if ("root" === n.type) return new rD(n);
      if ("decl" === n.type) return new t4(n);
      if ("rule" === n.type) return new rF(n);
      if ("comment" === n.type) return new rw(n);
      if ("atrule" === n.type) return new rP(n);
      else throw Error("Unknown node type: " + e.type);
    }
    function r2() {
      for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
      return (1 === t.length && Array.isArray(t[0]) && (t = t[0]), new r0(t));
    }
    ((r0.default = r0),
      rD.registerProcessor(r0),
      rO.registerProcessor(r0),
      (r1.default = r1),
      (r2.plugin = function (e, t) {
        var r,
          n = !1;
        function i() {
          for (var r = arguments.length, i = Array(r), o = 0; o < r; o++) i[o] = arguments[o];
          console &&
            console.warn &&
            !n &&
            ((n = !0),
            console.warn(
              e +
                ": postcss.plugin was deprecated. Migration guide:\nhttps://evilmartians.com/chronicles/postcss-8-plugin-migration",
            ),
            v.default.env.LANG &&
              v.default.env.LANG.startsWith("cn") &&
              console.warn(
                e + ": 里面 postcss.plugin 被弃用. 迁移指南:\nhttps://www.w3ctech.com/topic/2226",
              ));
          var s = t.apply(void 0, [].concat(i));
          return ((s.postcssPlugin = e), (s.postcssVersion = new r0().version), s);
        }
        return (
          Object.defineProperty(i, "postcss", {
            get: function () {
              return (r || (r = i()), r);
            },
          }),
          (i.process = function (e, t, r) {
            return r2([i(r)]).process(e, t);
          }),
          i
        );
      }),
      (r2.stringify = t0),
      (r2.parse = rV),
      (r2.fromJSON = r1),
      (r2.list = rN),
      (r2.comment = function (e) {
        return new rw(e);
      }),
      (r2.atRule = function (e) {
        return new rP(e);
      }),
      (r2.decl = function (e) {
        return new t4(e);
      }),
      (r2.rule = function (e) {
        return new rF(e);
      }),
      (r2.root = function (e) {
        return new rD(e);
      }),
      (r2.document = function (e) {
        return new rO(e);
      }),
      (r2.CssSyntaxError = tZ),
      (r2.Declaration = t4),
      (r2.Container = rk),
      (r2.Processor = r0),
      (r2.Document = rO),
      (r2.Comment = rw),
      (r2.Warning = rA),
      (r2.AtRule = rP),
      (r2.Result = rR),
      (r2.Input = rh),
      (r2.Rule = rF),
      (r2.Root = rD),
      (r2.Node = t3),
      rX.registerPostcss(r2),
      (r2.default = r2));
    var r3 = r2 && r2.__esModule && Object.prototype.hasOwnProperty.call(r2, "default") ? r2.default : r2;
    (r3.stringify,
      r3.fromJSON,
      r3.plugin,
      r3.parse,
      r3.list,
      r3.document,
      r3.comment,
      r3.atRule,
      r3.rule,
      r3.decl,
      r3.root,
      r3.CssSyntaxError,
      r3.Declaration,
      r3.Container,
      r3.Processor,
      r3.Document,
      r3.Comment,
      r3.Warning,
      r3.AtRule,
      r3.Result,
      r3.Input,
      r3.Rule,
      r3.Root,
      r3.Node);
    var r4 = (function () {
        function e() {
          for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
          (tz(this, "parentElement", null),
            tz(this, "parentNode", null),
            tz(this, "ownerDocument"),
            tz(this, "firstChild", null),
            tz(this, "lastChild", null),
            tz(this, "previousSibling", null),
            tz(this, "nextSibling", null),
            tz(this, "ELEMENT_NODE", 1),
            tz(this, "TEXT_NODE", 3),
            tz(this, "nodeType"),
            tz(this, "nodeName"),
            tz(this, "RRNodeType"));
        }
        var t = e.prototype;
        return (
          (t.contains = function (t) {
            if (!A(t, e) || t.ownerDocument !== this.ownerDocument) return !1;
            if (t === this) return !0;
            for (; t.parentNode;) {
              if (t.parentNode === this) return !0;
              t = t.parentNode;
            }
            return !1;
          }),
          (t.appendChild = function (e) {
            throw Error(
              "RRDomException: Failed to execute 'appendChild' on 'RRNode': This RRNode type does not support this method.",
            );
          }),
          (t.insertBefore = function (e, t) {
            throw Error(
              "RRDomException: Failed to execute 'insertBefore' on 'RRNode': This RRNode type does not support this method.",
            );
          }),
          (t.removeChild = function (e) {
            throw Error(
              "RRDomException: Failed to execute 'removeChild' on 'RRNode': This RRNode type does not support this method.",
            );
          }),
          (t.toString = function () {
            return "RRNode";
          }),
          I(e, [
            {
              key: "childNodes",
              get: function () {
                for (var e = [], t = this.firstChild; t;) (e.push(t), (t = t.nextSibling));
                return e;
              },
            },
          ]),
          e
        );
      })(),
      r5 = {
        Node: ["childNodes", "parentNode", "parentElement", "textContent"],
        ShadowRoot: ["host", "styleSheets"],
        Element: ["shadowRoot", "querySelector", "querySelectorAll"],
        MutationObserver: [],
      },
      r9 = {
        Node: ["contains", "getRootNode"],
        ShadowRoot: ["getSelection"],
        Element: [],
        MutationObserver: ["constructor"],
      },
      r6 = {};
    function r8(e) {
      if (r6[e]) return r6[e];
      var t = globalThis[e],
        r = t.prototype,
        n = e in r5 ? r5[e] : void 0,
        i = !!(
          n &&
          n.every(function (e) {
            var t, n;
            return !!(null == (n = null == (t = Object.getOwnPropertyDescriptor(r, e)) ? void 0 : t.get)
              ? void 0
              : n.toString().includes("[native code]"));
          })
        ),
        o = e in r9 ? r9[e] : void 0,
        s = !!(
          o &&
          o.every(function (e) {
            var t;
            return (
              "function" == typeof r[e] &&
              (null == (t = r[e]) ? void 0 : t.toString().includes("[native code]"))
            );
          })
        );
      if (i && s && !globalThis.Zone) return ((r6[e] = t.prototype), t.prototype);
      try {
        var a = document.createElement("iframe");
        document.body.appendChild(a);
        var c = a.contentWindow;
        if (!c) return t.prototype;
        var u = c[e].prototype;
        if ((document.body.removeChild(a), !u)) return r;
        return (r6[e] = u);
      } catch (e) {
        return r;
      }
    }
    var r7 = {};
    function ne(e, t, r) {
      var n,
        i = e + "." + String(r);
      if (r7[i]) return r7[i].call(t);
      var o = null == (n = Object.getOwnPropertyDescriptor(r8(e), r)) ? void 0 : n.get;
      return o ? ((r7[i] = o), o.call(t)) : t[r];
    }
    var nt = {};
    function nr(e, t, r) {
      var n = e + "." + String(r);
      if (nt[n]) return nt[n].bind(t);
      var i = r8(e)[r];
      return "function" != typeof i ? t[r] : ((nt[n] = i), i.bind(t));
    }
    function nn(e, t, r) {
      try {
        if (!(t in e)) return function () {};
        var n = e[t],
          i = r(n);
        return (
          "function" == typeof i &&
            ((i.prototype = i.prototype || {}),
            Object.defineProperties(i, { __rrweb_original__: { enumerable: !1, value: n } })),
          (e[t] = i),
          function () {
            e[t] = n;
          }
        );
      } catch (e) {
        return function () {};
      }
    }
    var ni = function (e) {
        return ne("Node", e, "childNodes");
      },
      no = function (e) {
        return ne("Node", e, "parentNode");
      },
      ns = function (e) {
        return ne("Node", e, "parentElement");
      },
      na = function (e) {
        return ne("Node", e, "textContent");
      },
      nc = function (e, t) {
        return nr("Node", e, "contains")(t);
      },
      nu = function (e) {
        return nr("Node", e, "getRootNode")();
      },
      nl = function (e) {
        return e && "host" in e ? ne("ShadowRoot", e, "host") : null;
      },
      np = function (e) {
        return e && "shadowRoot" in e ? ne("Element", e, "shadowRoot") : null;
      };
    function nh(e, t, r) {
      void 0 === r && (r = document);
      var n = { capture: !0, passive: !0 };
      return (
        r.addEventListener(e, t, n),
        function () {
          return r.removeEventListener(e, t, n);
        }
      );
    }
    var nd =
        "Please stop import mirror directly. Instead of that,\r\nnow you can use replayer.getMirror() to access the mirror instance of a replayer,\r\nor you can use record.mirror to access the mirror instance during recording.",
      nf = {
        map: {},
        getId: function () {
          return (console.error(nd), -1);
        },
        getNode: function () {
          return (console.error(nd), null);
        },
        removeNodeFromMap: function () {
          console.error(nd);
        },
        has: function () {
          return (console.error(nd), !1);
        },
        reset: function () {
          console.error(nd);
        },
      };
    function ng(e, t, r) {
      void 0 === r && (r = {});
      var n = null,
        i = 0;
      return function () {
        for (var o = arguments.length, s = Array(o), a = 0; a < o; a++) s[a] = arguments[a];
        var c = Date.now();
        i || !1 !== r.leading || (i = c);
        var u = t - (c - i),
          l = this;
        u <= 0 || u > t
          ? (n && (clearTimeout(n), (n = null)), (i = c), e.apply(l, s))
          : n ||
            !1 === r.trailing ||
            (n = setTimeout(function () {
              ((i = !1 === r.leading ? 0 : Date.now()), (n = null), e.apply(l, s));
            }, u));
      };
    }
    function nm(e, t, r, n, i) {
      void 0 === i && (i = window);
      var o = i.Object.getOwnPropertyDescriptor(e, t);
      return (
        i.Object.defineProperty(
          e,
          t,
          n
            ? r
            : {
                set: function (e) {
                  var t = this;
                  (setTimeout(function () {
                    r.set.call(t, e);
                  }, 0),
                    o && o.set && o.set.call(this, e));
                },
              },
        ),
        function () {
          return nm(e, t, o || {}, !0);
        }
      );
    }
    "u" > typeof window &&
      window.Proxy &&
      window.Reflect &&
      (nf = new Proxy(nf, {
        get: function (e, t, r) {
          return ("map" === t && console.error(nd), Reflect.get(e, t, r));
        },
      }));
    var n_ = Date.now;
    function nv(e) {
      var t,
        r,
        n,
        i,
        o = e.document;
      return {
        left: o.scrollingElement
          ? o.scrollingElement.scrollLeft
          : void 0 !== e.pageXOffset
            ? e.pageXOffset
            : o.documentElement.scrollLeft ||
              ((null == o ? void 0 : o.body) && (null == (t = ns(o.body)) ? void 0 : t.scrollLeft)) ||
              (null == (r = null == o ? void 0 : o.body) ? void 0 : r.scrollLeft) ||
              0,
        top: o.scrollingElement
          ? o.scrollingElement.scrollTop
          : void 0 !== e.pageYOffset
            ? e.pageYOffset
            : (null == o ? void 0 : o.documentElement.scrollTop) ||
              ((null == o ? void 0 : o.body) && (null == (n = ns(o.body)) ? void 0 : n.scrollTop)) ||
              (null == (i = null == o ? void 0 : o.body) ? void 0 : i.scrollTop) ||
              0,
      };
    }
    function ny() {
      return (
        window.innerHeight ||
        (document.documentElement && document.documentElement.clientHeight) ||
        (document.body && document.body.clientHeight)
      );
    }
    function nb() {
      return (
        window.innerWidth ||
        (document.documentElement && document.documentElement.clientWidth) ||
        (document.body && document.body.clientWidth)
      );
    }
    function nC(e) {
      return e ? (e.nodeType === e.ELEMENT_NODE ? e : ns(e)) : null;
    }
    function nE(e, t, r, n) {
      if (!e) return !1;
      var i = nC(e);
      if (!i) return !1;
      try {
        if ("string" == typeof t) {
          if (i.classList.contains(t) || (n && null !== i.closest("." + t))) return !0;
        } else if (ek(i, t, n)) return !0;
      } catch (e) {}
      return !!(r && (i.matches(r) || (n && null !== i.closest(r)))) || !1;
    }
    function nw(e, t, r) {
      return ("TITLE" === e.tagName && !!r.headTitleMutations) || -2 === t.getId(e);
    }
    function nI(e) {
      return !!e.changedTouches;
    }
    function nS(e, t) {
      return !!("IFRAME" === e.nodeName && t.getMeta(e));
    }
    function nk(e, t) {
      return !!(
        "LINK" === e.nodeName &&
        e.nodeType === e.ELEMENT_NODE &&
        e.getAttribute &&
        "stylesheet" === e.getAttribute("rel") &&
        t.getMeta(e)
      );
    }
    function nO(e) {
      return !!e && (A(e, r4) && "shadowRoot" in e ? !!e.shadowRoot : !!np(e));
    }
    /[1-9][0-9]{12}/.test(Date.now().toString()) ||
      (n_ = function () {
        return new Date().getTime();
      });
    var nA = (function () {
      function e() {
        (U(this, "id", 1), U(this, "styleIDMap", new WeakMap()), U(this, "idStyleMap", new Map()));
      }
      var t = e.prototype;
      return (
        (t.getId = function (e) {
          var t;
          return null != (t = this.styleIDMap.get(e)) ? t : -1;
        }),
        (t.has = function (e) {
          return this.styleIDMap.has(e);
        }),
        (t.add = function (e, t) {
          var r;
          return this.has(e)
            ? this.getId(e)
            : ((r = void 0 === t ? this.id++ : t), this.styleIDMap.set(e, r), this.idStyleMap.set(r, e), r);
        }),
        (t.getStyle = function (e) {
          return this.idStyleMap.get(e) || null;
        }),
        (t.reset = function () {
          ((this.styleIDMap = new WeakMap()), (this.idStyleMap = new Map()), (this.id = 1));
        }),
        (t.generateId = function () {
          return this.id++;
        }),
        e
      );
    })();
    function nR(e) {
      var t,
        r = null;
      return (
        "getRootNode" in e &&
          (null == (t = nu(e)) ? void 0 : t.nodeType) === Node.DOCUMENT_FRAGMENT_NODE &&
          nl(nu(e)) &&
          (r = nl(nu(e))),
        r
      );
    }
    function nT(e) {
      var t,
        r,
        n = e.ownerDocument;
      return (
        !!n &&
        (nc(n, e) ||
          (!!(r = (t = e).ownerDocument) &&
            nc(
              r,
              (function (e) {
                for (var t, r = e; (t = nR(r));) r = t;
                return r;
              })(t),
            )))
      );
    }
    var nx =
        (((iy = nx || {})[(iy.DomContentLoaded = 0)] = "DomContentLoaded"),
        (iy[(iy.Load = 1)] = "Load"),
        (iy[(iy.FullSnapshot = 2)] = "FullSnapshot"),
        (iy[(iy.IncrementalSnapshot = 3)] = "IncrementalSnapshot"),
        (iy[(iy.Meta = 4)] = "Meta"),
        (iy[(iy.Custom = 5)] = "Custom"),
        (iy[(iy.Plugin = 6)] = "Plugin"),
        iy),
      nM =
        (((ib = nM || {})[(ib.Mutation = 0)] = "Mutation"),
        (ib[(ib.MouseMove = 1)] = "MouseMove"),
        (ib[(ib.MouseInteraction = 2)] = "MouseInteraction"),
        (ib[(ib.Scroll = 3)] = "Scroll"),
        (ib[(ib.ViewportResize = 4)] = "ViewportResize"),
        (ib[(ib.Input = 5)] = "Input"),
        (ib[(ib.TouchMove = 6)] = "TouchMove"),
        (ib[(ib.MediaInteraction = 7)] = "MediaInteraction"),
        (ib[(ib.StyleSheetRule = 8)] = "StyleSheetRule"),
        (ib[(ib.CanvasMutation = 9)] = "CanvasMutation"),
        (ib[(ib.Font = 10)] = "Font"),
        (ib[(ib.Log = 11)] = "Log"),
        (ib[(ib.Drag = 12)] = "Drag"),
        (ib[(ib.StyleDeclaration = 13)] = "StyleDeclaration"),
        (ib[(ib.Selection = 14)] = "Selection"),
        (ib[(ib.AdoptedStyleSheet = 15)] = "AdoptedStyleSheet"),
        (ib[(ib.CustomElement = 16)] = "CustomElement"),
        ib),
      nL =
        (((iC = nL || {})[(iC.MouseUp = 0)] = "MouseUp"),
        (iC[(iC.MouseDown = 1)] = "MouseDown"),
        (iC[(iC.Click = 2)] = "Click"),
        (iC[(iC.ContextMenu = 3)] = "ContextMenu"),
        (iC[(iC.DblClick = 4)] = "DblClick"),
        (iC[(iC.Focus = 5)] = "Focus"),
        (iC[(iC.Blur = 6)] = "Blur"),
        (iC[(iC.TouchStart = 7)] = "TouchStart"),
        (iC[(iC.TouchMove_Departed = 8)] = "TouchMove_Departed"),
        (iC[(iC.TouchEnd = 9)] = "TouchEnd"),
        (iC[(iC.TouchCancel = 10)] = "TouchCancel"),
        iC),
      nP =
        (((iE = nP || {})[(iE.Mouse = 0)] = "Mouse"),
        (iE[(iE.Pen = 1)] = "Pen"),
        (iE[(iE.Touch = 2)] = "Touch"),
        iE),
      nD =
        (((iw = nD || {})[(iw["2D"] = 0)] = "2D"),
        (iw[(iw.WebGL = 1)] = "WebGL"),
        (iw[(iw.WebGL2 = 2)] = "WebGL2"),
        iw),
      nN =
        (((iI = nN || {})[(iI.Play = 0)] = "Play"),
        (iI[(iI.Pause = 1)] = "Pause"),
        (iI[(iI.Seeked = 2)] = "Seeked"),
        (iI[(iI.VolumeChange = 3)] = "VolumeChange"),
        (iI[(iI.RateChange = 4)] = "RateChange"),
        iI),
      nF =
        (((iS = nF || {})[(iS.Document = 0)] = "Document"),
        (iS[(iS.DocumentType = 1)] = "DocumentType"),
        (iS[(iS.Element = 2)] = "Element"),
        (iS[(iS.Text = 3)] = "Text"),
        (iS[(iS.CDATA = 4)] = "CDATA"),
        (iS[(iS.Comment = 5)] = "Comment"),
        iS),
      nU = (function () {
        function e() {
          (U(this, "length", 0), U(this, "head", null), U(this, "tail", null));
        }
        var t = e.prototype;
        return (
          (t.get = function (e) {
            if (e >= this.length) throw Error("Position outside of list range");
            for (var t = this.head, r = 0; r < e; r++) t = (null == t ? void 0 : t.next) || null;
            return t;
          }),
          (t.addNode = function (e) {
            var t = { value: e, previous: null, next: null };
            if (((e.__ln = t), e.previousSibling && "__ln" in e.previousSibling)) {
              var r = e.previousSibling.__ln.next;
              ((t.next = r),
                (t.previous = e.previousSibling.__ln),
                (e.previousSibling.__ln.next = t),
                r && (r.previous = t));
            } else if (e.nextSibling && "__ln" in e.nextSibling && e.nextSibling.__ln.previous) {
              var n = e.nextSibling.__ln.previous;
              ((t.previous = n),
                (t.next = e.nextSibling.__ln),
                (e.nextSibling.__ln.previous = t),
                n && (n.next = t));
            } else (this.head && (this.head.previous = t), (t.next = this.head), (this.head = t));
            (null === t.next && (this.tail = t), this.length++);
          }),
          (t.removeNode = function (e) {
            var t = e.__ln;
            this.head &&
              (t.previous
                ? ((t.previous.next = t.next),
                  t.next ? (t.next.previous = t.previous) : (this.tail = t.previous))
                : ((this.head = t.next), this.head ? (this.head.previous = null) : (this.tail = null)),
              e.__ln && delete e.__ln,
              this.length--);
          }),
          e
        );
      })(),
      nB = function (e, t) {
        return e + "@" + t;
      },
      nj = (function () {
        function e() {
          var e = this;
          (U(this, "frozen", !1),
            U(this, "locked", !1),
            U(this, "texts", []),
            U(this, "attributes", []),
            U(this, "attributeMap", new WeakMap()),
            U(this, "removes", []),
            U(this, "mapRemoves", []),
            U(this, "movedMap", {}),
            U(this, "addedSet", new Set()),
            U(this, "movedSet", new Set()),
            U(this, "droppedSet", new Set()),
            U(this, "removesSubTreeCache", new Set()),
            U(this, "mutationCb"),
            U(this, "blockClass"),
            U(this, "blockSelector"),
            U(this, "maskTextClass"),
            U(this, "maskTextSelector"),
            U(this, "inlineStylesheet"),
            U(this, "maskInputOptions"),
            U(this, "maskTextFn"),
            U(this, "maskInputFn"),
            U(this, "keepIframeSrcFn"),
            U(this, "recordCanvas"),
            U(this, "inlineImages"),
            U(this, "slimDOMOptions"),
            U(this, "dataURLOptions"),
            U(this, "doc"),
            U(this, "mirror"),
            U(this, "iframeManager"),
            U(this, "stylesheetManager"),
            U(this, "shadowDomManager"),
            U(this, "canvasManager"),
            U(this, "processedNodeManager"),
            U(this, "unattachedDoc"),
            U(this, "processMutations", function (t) {
              (t.forEach(e.processMutation), e.emit());
            }),
            U(this, "emit", function () {
              if (!e.frozen && !e.locked) {
                for (
                  var t = [],
                    r = new Set(),
                    n = new nU(),
                    i = function (t) {
                      for (var r = t, n = -2; -2 === n;) n = (r = r && r.nextSibling) && e.mirror.getId(r);
                      return n;
                    },
                    o = function (o) {
                      var s = no(o);
                      if (s && nT(o)) {
                        var a = !1;
                        if (o.nodeType === Node.TEXT_NODE) {
                          var c = s.tagName;
                          if ("TEXTAREA" === c) return;
                          "STYLE" === c && e.addedSet.has(s) && (a = !0);
                        }
                        var u = ee(s) ? e.mirror.getId(nR(o)) : e.mirror.getId(s),
                          l = i(o);
                        if (-1 === u || -1 === l) return n.addNode(o);
                        var p = eR(o, {
                          doc: e.doc,
                          mirror: e.mirror,
                          blockClass: e.blockClass,
                          blockSelector: e.blockSelector,
                          maskTextClass: e.maskTextClass,
                          maskTextSelector: e.maskTextSelector,
                          skipChild: !0,
                          newlyAddedElement: !0,
                          inlineStylesheet: e.inlineStylesheet,
                          maskInputOptions: e.maskInputOptions,
                          maskTextFn: e.maskTextFn,
                          maskInputFn: e.maskInputFn,
                          slimDOMOptions: e.slimDOMOptions,
                          dataURLOptions: e.dataURLOptions,
                          recordCanvas: e.recordCanvas,
                          inlineImages: e.inlineImages,
                          onSerialize: function (t) {
                            (nS(t, e.mirror) && e.iframeManager.addIframe(t),
                              nk(t, e.mirror) && e.stylesheetManager.trackLinkElement(t),
                              nO(o) && e.shadowDomManager.addShadowRoot(np(o), e.doc));
                          },
                          onIframeLoad: function (t, r) {
                            (e.iframeManager.attachIframe(t, r), e.shadowDomManager.observeAttachShadow(t));
                          },
                          onStylesheetLoad: function (t, r) {
                            e.stylesheetManager.attachLinkElement(t, r);
                          },
                          cssCaptured: a,
                        });
                        p && (t.push({ parentId: u, nextId: l, node: p }), r.add(p.id));
                      }
                    };
                  e.mapRemoves.length;
                )
                  e.mirror.removeNodeFromMap(e.mapRemoves.shift());
                for (var s, a = P(e.movedSet); !(s = a()).done;) {
                  var c = s.value;
                  (!nG(e.removesSubTreeCache, c, e.mirror) || e.movedSet.has(no(c))) && o(c);
                }
                for (var u, l = P(e.addedSet); !(u = l()).done;) {
                  var p = u.value;
                  nW(e.droppedSet, p) || nG(e.removesSubTreeCache, p, e.mirror)
                    ? nW(e.movedSet, p)
                      ? o(p)
                      : e.droppedSet.add(p)
                    : o(p);
                }
                for (var h = null; n.length;) {
                  var d = null;
                  if (h) {
                    var f = e.mirror.getId(no(h.value)),
                      g = i(h.value);
                    -1 !== f && -1 !== g && (d = h);
                  }
                  if (!d)
                    for (var m = n.tail; m;) {
                      var _ = m;
                      if (((m = m.previous), _)) {
                        var v = e.mirror.getId(no(_.value));
                        if (-1 === i(_.value)) continue;
                        if (-1 !== v) {
                          d = _;
                          break;
                        }
                        var y = no(_.value);
                        if (y && y.nodeType === Node.DOCUMENT_FRAGMENT_NODE) {
                          var b = nl(y);
                          if (-1 !== e.mirror.getId(b)) {
                            d = _;
                            break;
                          }
                        }
                      }
                    }
                  if (!d) {
                    for (; n.head;) n.removeNode(n.head.value);
                    break;
                  }
                  ((h = d.previous), n.removeNode(d.value), o(d.value));
                }
                var C = {
                  texts: e.texts
                    .map(function (t) {
                      var r = t.node,
                        n = no(r);
                      return (
                        n && "TEXTAREA" === n.tagName && e.genTextAreaValueMutation(n),
                        { id: e.mirror.getId(r), value: t.value }
                      );
                    })
                    .filter(function (e) {
                      return !r.has(e.id);
                    })
                    .filter(function (t) {
                      return e.mirror.has(t.id);
                    }),
                  attributes: e.attributes
                    .map(function (t) {
                      var r = t.attributes;
                      if ("string" == typeof r.style) {
                        var n = JSON.stringify(t.styleDiff),
                          i = JSON.stringify(t._unchangedStyles);
                        n.length < r.style.length &&
                          (n + i).split("var(").length === r.style.split("var(").length &&
                          (r.style = t.styleDiff);
                      }
                      return { id: e.mirror.getId(t.node), attributes: r };
                    })
                    .filter(function (e) {
                      return !r.has(e.id);
                    })
                    .filter(function (t) {
                      return e.mirror.has(t.id);
                    }),
                  removes: e.removes,
                  adds: t,
                };
                (C.texts.length || C.attributes.length || C.removes.length || C.adds.length) &&
                  ((e.texts = []),
                  (e.attributes = []),
                  (e.attributeMap = new WeakMap()),
                  (e.removes = []),
                  (e.addedSet = new Set()),
                  (e.movedSet = new Set()),
                  (e.droppedSet = new Set()),
                  (e.removesSubTreeCache = new Set()),
                  (e.movedMap = {}),
                  e.mutationCb(C));
              }
            }),
            U(this, "genTextAreaValueMutation", function (t) {
              var r = e.attributeMap.get(t);
              r ||
                ((r = { node: t, attributes: {}, styleDiff: {}, _unchangedStyles: {} }),
                e.attributes.push(r),
                e.attributeMap.set(t, r));
              var n = Array.from(ni(t), function (e) {
                return na(e) || "";
              }).join("");
              r.attributes.value = eo({
                element: t,
                maskInputOptions: e.maskInputOptions,
                tagName: t.tagName,
                type: ec(t),
                value: n,
                maskInputFn: e.maskInputFn,
              });
            }),
            U(this, "processMutation", function (t) {
              if (!nw(t.target, e.mirror, e.slimDOMOptions))
                switch (t.type) {
                  case "characterData":
                    var r = na(t.target);
                    nE(t.target, e.blockClass, e.blockSelector, !1) ||
                      r === t.oldValue ||
                      e.texts.push({
                        value:
                          eO(t.target, e.maskTextClass, e.maskTextSelector, !0) && r
                            ? e.maskTextFn
                              ? e.maskTextFn(r, nC(t.target))
                              : r.replace(/[\S]/g, "*")
                            : r,
                        node: t.target,
                      });
                    break;
                  case "attributes":
                    var n = t.target,
                      i = t.attributeName,
                      o = t.target.getAttribute(i);
                    if ("value" === i) {
                      var s = ec(n);
                      o = eo({
                        element: n,
                        maskInputOptions: e.maskInputOptions,
                        tagName: n.tagName,
                        type: s,
                        value: o,
                        maskInputFn: e.maskInputFn,
                      });
                    }
                    if (nE(t.target, e.blockClass, e.blockSelector, !1) || o === t.oldValue) return;
                    var a = e.attributeMap.get(t.target);
                    if ("IFRAME" === n.tagName && "src" === i && !e.keepIframeSrcFn(o))
                      if (n.contentDocument) return;
                      else i = "rr_src";
                    if (
                      (a ||
                        ((a = { node: t.target, attributes: {}, styleDiff: {}, _unchangedStyles: {} }),
                        e.attributes.push(a),
                        e.attributeMap.set(t.target, a)),
                      "type" === i &&
                        "INPUT" === n.tagName &&
                        "password" === (t.oldValue || "").toLowerCase() &&
                        n.setAttribute("data-rr-is-password", "true"),
                      !eS(n.tagName, i))
                    )
                      if (((a.attributes[i] = eI(e.doc, es(n.tagName), es(i), o)), "style" === i)) {
                        if (!e.unattachedDoc)
                          try {
                            e.unattachedDoc = document.implementation.createHTMLDocument();
                          } catch (t) {
                            e.unattachedDoc = e.doc;
                          }
                        var c = e.unattachedDoc.createElement("span");
                        t.oldValue && c.setAttribute("style", t.oldValue);
                        for (var u, l = P(Array.from(n.style)); !(u = l()).done;) {
                          var p = u.value,
                            h = n.style.getPropertyValue(p),
                            d = n.style.getPropertyPriority(p);
                          h !== c.style.getPropertyValue(p) || d !== c.style.getPropertyPriority(p)
                            ? "" === d
                              ? (a.styleDiff[p] = h)
                              : (a.styleDiff[p] = [h, d])
                            : (a._unchangedStyles[p] = [h, d]);
                        }
                        for (var f, g = P(Array.from(c.style)); !(f = g()).done;) {
                          var m = f.value;
                          "" === n.style.getPropertyValue(m) && (a.styleDiff[m] = !1);
                        }
                      } else
                        "open" === i &&
                          "DIALOG" === n.tagName &&
                          (n.matches("dialog:modal")
                            ? (a.attributes.rr_open_mode = "modal")
                            : (a.attributes.rr_open_mode = "non-modal"));
                    break;
                  case "childList":
                    if (nE(t.target, e.blockClass, e.blockSelector, !0)) return;
                    if ("TEXTAREA" === t.target.tagName) return void e.genTextAreaValueMutation(t.target);
                    (t.addedNodes.forEach(function (r) {
                      return e.genAdds(r, t.target);
                    }),
                      t.removedNodes.forEach(function (r) {
                        var n = e.mirror.getId(r),
                          i = ee(t.target) ? e.mirror.getId(nl(t.target)) : e.mirror.getId(t.target);
                        nE(t.target, e.blockClass, e.blockSelector, !1) ||
                          nw(r, e.mirror, e.slimDOMOptions) ||
                          -1 === e.mirror.getId(r) ||
                          (e.addedSet.has(r)
                            ? (nV(e.addedSet, r), e.droppedSet.add(r))
                            : (e.addedSet.has(t.target) && -1 === n) ||
                              (function e(t, r) {
                                if (ee(t)) return !1;
                                var n = r.getId(t);
                                if (!r.has(n)) return !0;
                                var i = no(t);
                                return (!i || i.nodeType !== t.DOCUMENT_NODE) && (!i || e(i, r));
                              })(t.target, e.mirror) ||
                              (e.movedSet.has(r) && e.movedMap[nB(n, i)]
                                ? nV(e.movedSet, r)
                                : (e.removes.push({
                                    parentId: i,
                                    id: n,
                                    isShadow: !!(ee(t.target) && et(t.target)) || void 0,
                                  }),
                                  (function (e, t) {
                                    for (var r = [e]; r.length;) {
                                      var n = r.pop();
                                      t.has(n) ||
                                        (t.add(n),
                                        ni(n).forEach(function (e) {
                                          return r.push(e);
                                        }));
                                    }
                                  })(r, e.removesSubTreeCache))),
                          e.mapRemoves.push(r));
                      }));
                }
            }),
            U(this, "genAdds", function (t, r) {
              if (!e.processedNodeManager.inOtherBuffer(t, e) && !(e.addedSet.has(t) || e.movedSet.has(t))) {
                if (e.mirror.hasNode(t)) {
                  if (nw(t, e.mirror, e.slimDOMOptions)) return;
                  e.movedSet.add(t);
                  var n = null;
                  (r && e.mirror.hasNode(r) && (n = e.mirror.getId(r)),
                    n && -1 !== n && (e.movedMap[nB(e.mirror.getId(t), n)] = !0));
                } else (e.addedSet.add(t), e.droppedSet.delete(t));
                !nE(t, e.blockClass, e.blockSelector, !1) &&
                  (ni(t).forEach(function (t) {
                    return e.genAdds(t);
                  }),
                  nO(t) &&
                    ni(np(t)).forEach(function (r) {
                      (e.processedNodeManager.add(r, e), e.genAdds(r, t));
                    }));
              }
            }));
        }
        var t = e.prototype;
        return (
          (t.init = function (e) {
            var t = this;
            [
              "mutationCb",
              "blockClass",
              "blockSelector",
              "maskTextClass",
              "maskTextSelector",
              "inlineStylesheet",
              "maskInputOptions",
              "maskTextFn",
              "maskInputFn",
              "keepIframeSrcFn",
              "recordCanvas",
              "inlineImages",
              "slimDOMOptions",
              "dataURLOptions",
              "doc",
              "mirror",
              "iframeManager",
              "stylesheetManager",
              "shadowDomManager",
              "canvasManager",
              "processedNodeManager",
            ].forEach(function (r) {
              t[r] = e[r];
            });
          }),
          (t.freeze = function () {
            ((this.frozen = !0), this.canvasManager.freeze());
          }),
          (t.unfreeze = function () {
            ((this.frozen = !1), this.canvasManager.unfreeze(), this.emit());
          }),
          (t.isFrozen = function () {
            return this.frozen;
          }),
          (t.lock = function () {
            ((this.locked = !0), this.canvasManager.lock());
          }),
          (t.unlock = function () {
            ((this.locked = !1), this.canvasManager.unlock(), this.emit());
          }),
          (t.reset = function () {
            (this.shadowDomManager.reset(), this.canvasManager.reset());
          }),
          e
        );
      })();
    function nV(e, t) {
      (e.delete(t),
        ni(t).forEach(function (t) {
          return nV(e, t);
        }));
    }
    function nG(e, t, r) {
      var n, i;
      return 0 !== e.size && ((n = e), !!(i = no(t)) && n.has(i));
    }
    function nW(e, t) {
      return (
        0 !== e.size &&
        (function e(t, r) {
          var n = no(r);
          return !!n && (!!t.has(n) || e(t, n));
        })(e, t)
      );
    }
    var nz = function (e) {
        return iY
          ? function () {
              for (var t = arguments.length, r = Array(t), n = 0; n < t; n++) r[n] = arguments[n];
              try {
                return e.apply(void 0, [].concat(r));
              } catch (e) {
                if (iY && !0 === iY(e)) return;
                throw e;
              }
            }
          : e;
      },
      nK = [];
    function nq(e) {
      try {
        if ("composedPath" in e) {
          var t = e.composedPath();
          if (t.length) return t[0];
        } else if ("path" in e && e.path.length) return e.path[0];
      } catch (e) {}
      return e && e.target;
    }
    function nY(e, t) {
      var r = new nj();
      (nK.push(r), r.init(e));
      var n = new (r8("MutationObserver").constructor)(nz(r.processMutations.bind(r)));
      return (
        n.observe(t, {
          attributes: !0,
          attributeOldValue: !0,
          characterData: !0,
          characterDataOldValue: !0,
          childList: !0,
          subtree: !0,
        }),
        n
      );
    }
    function n$(e) {
      var t = e.scrollCb,
        r = e.doc,
        n = e.mirror,
        i = e.blockClass,
        o = e.blockSelector,
        s = e.sampling;
      return nh(
        "scroll",
        nz(
          ng(
            nz(function (e) {
              var s = nq(e);
              if (!(!s || nE(s, i, o, !0))) {
                var a = n.getId(s);
                if (s === r && r.defaultView) {
                  var c = nv(r.defaultView);
                  t({ id: a, x: c.left, y: c.top });
                } else t({ id: a, x: s.scrollLeft, y: s.scrollTop });
              }
            }),
            s.scroll || 100,
          ),
        ),
        r,
      );
    }
    var nH = ["INPUT", "TEXTAREA", "SELECT"],
      nZ = new WeakMap();
    function nJ(e) {
      var t = [];
      if (
        (n1("CSSGroupingRule") && A(e.parentRule, CSSGroupingRule)) ||
        (n1("CSSMediaRule") && A(e.parentRule, CSSMediaRule)) ||
        (n1("CSSSupportsRule") && A(e.parentRule, CSSSupportsRule)) ||
        (n1("CSSConditionRule") && A(e.parentRule, CSSConditionRule))
      ) {
        var r = Array.from(e.parentRule.cssRules).indexOf(e);
        t.unshift(r);
      } else if (e.parentStyleSheet) {
        var n = Array.from(e.parentStyleSheet.cssRules).indexOf(e);
        t.unshift(n);
      }
      return t;
    }
    function nX(e, t, r) {
      var n, i;
      return e ? (e.ownerNode ? (n = t.getId(e.ownerNode)) : (i = r.getId(e)), { styleId: i, id: n }) : {};
    }
    function nQ(e, t) {
      var r,
        n,
        i,
        o = e.mirror,
        s = e.stylesheetManager,
        a = null;
      a = "#document" === t.nodeName ? o.getId(t) : o.getId(nl(t));
      var c =
          "#document" === t.nodeName
            ? null == (r = t.defaultView)
              ? void 0
              : r.Document
            : null == (i = null == (n = t.ownerDocument) ? void 0 : n.defaultView)
              ? void 0
              : i.ShadowRoot,
        u = (null == c ? void 0 : c.prototype)
          ? Object.getOwnPropertyDescriptor(null == c ? void 0 : c.prototype, "adoptedStyleSheets")
          : void 0;
      return null !== a && -1 !== a && c && u
        ? (Object.defineProperty(t, "adoptedStyleSheets", {
            configurable: u.configurable,
            enumerable: u.enumerable,
            get: function () {
              var e;
              return null == (e = u.get) ? void 0 : e.call(this);
            },
            set: function (e) {
              var t,
                r = null == (t = u.set) ? void 0 : t.call(this, e);
              if (null !== a && -1 !== a)
                try {
                  s.adoptStyleSheets(e, a);
                } catch (e) {}
              return r;
            },
          }),
          nz(function () {
            Object.defineProperty(t, "adoptedStyleSheets", {
              configurable: u.configurable,
              enumerable: u.enumerable,
              get: u.get,
              set: u.set,
            });
          }))
        : function () {};
    }
    function n0(e, t) {
      void 0 === t && (t = {});
      var r = e.doc.defaultView;
      if (!r) return function () {};
      ((d = t),
        (f = e.mutationCb),
        (g = e.mousemoveCb),
        (m = e.mouseInteractionCb),
        (_ = e.scrollCb),
        (v = e.viewportResizeCb),
        (y = e.inputCb),
        (b = e.mediaInteractionCb),
        (C = e.styleSheetRuleCb),
        (E = e.styleDeclarationCb),
        (w = e.canvasMutationCb),
        (I = e.fontCb),
        (k = e.selectionCb),
        (O = e.customElementCb),
        (e.mutationCb = function () {
          for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
          (d.mutation && d.mutation.apply(d, [].concat(t)), f.apply(void 0, [].concat(t)));
        }),
        (e.mousemoveCb = function () {
          for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
          (d.mousemove && d.mousemove.apply(d, [].concat(t)), g.apply(void 0, [].concat(t)));
        }),
        (e.mouseInteractionCb = function () {
          for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
          (d.mouseInteraction && d.mouseInteraction.apply(d, [].concat(t)), m.apply(void 0, [].concat(t)));
        }),
        (e.scrollCb = function () {
          for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
          (d.scroll && d.scroll.apply(d, [].concat(t)), _.apply(void 0, [].concat(t)));
        }),
        (e.viewportResizeCb = function () {
          for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
          (d.viewportResize && d.viewportResize.apply(d, [].concat(t)), v.apply(void 0, [].concat(t)));
        }),
        (e.inputCb = function () {
          for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
          (d.input && d.input.apply(d, [].concat(t)), y.apply(void 0, [].concat(t)));
        }),
        (e.mediaInteractionCb = function () {
          for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
          (d.mediaInteaction && d.mediaInteaction.apply(d, [].concat(t)), b.apply(void 0, [].concat(t)));
        }),
        (e.styleSheetRuleCb = function () {
          for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
          (d.styleSheetRule && d.styleSheetRule.apply(d, [].concat(t)), C.apply(void 0, [].concat(t)));
        }),
        (e.styleDeclarationCb = function () {
          for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
          (d.styleDeclaration && d.styleDeclaration.apply(d, [].concat(t)), E.apply(void 0, [].concat(t)));
        }),
        (e.canvasMutationCb = function () {
          for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
          (d.canvasMutation && d.canvasMutation.apply(d, [].concat(t)), w.apply(void 0, [].concat(t)));
        }),
        (e.fontCb = function () {
          for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
          (d.font && d.font.apply(d, [].concat(t)), I.apply(void 0, [].concat(t)));
        }),
        (e.selectionCb = function () {
          for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
          (d.selection && d.selection.apply(d, [].concat(t)), k.apply(void 0, [].concat(t)));
        }),
        (e.customElementCb = function () {
          for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
          (d.customElement && d.customElement.apply(d, [].concat(t)), O.apply(void 0, [].concat(t)));
        }),
        e.recordDOM && (eu = nY(e, e.doc)));
      var n = (function (e) {
          var t,
            r = e.mousemoveCb,
            n = e.sampling,
            i = e.doc,
            o = e.mirror;
          if (!1 === n.mousemove) return function () {};
          var s = "number" == typeof n.mousemove ? n.mousemove : 50,
            a = "number" == typeof n.mousemoveCallback ? n.mousemoveCallback : 500,
            c = [],
            u = ng(
              nz(function (e) {
                var n = Date.now() - t;
                (r(
                  c.map(function (e) {
                    return ((e.timeOffset -= n), e);
                  }),
                  e,
                ),
                  (c = []),
                  (t = null));
              }),
              a,
            ),
            l = nz(
              ng(
                nz(function (e) {
                  var r = nq(e),
                    n = nI(e) ? e.changedTouches[0] : e,
                    i = n.clientX,
                    s = n.clientY;
                  (t || (t = n_()),
                    c.push({ x: i, y: s, id: o.getId(r), timeOffset: n_() - t }),
                    u(
                      "u" > typeof DragEvent && A(e, DragEvent)
                        ? nM.Drag
                        : A(e, MouseEvent)
                          ? nM.MouseMove
                          : nM.TouchMove,
                    ));
                }),
                s,
                { trailing: !1 },
              ),
            ),
            p = [nh("mousemove", l, i), nh("touchmove", l, i), nh("drag", l, i)];
          return nz(function () {
            p.forEach(function (e) {
              return e();
            });
          });
        })(e),
        i = (function (e) {
          var t = e.mouseInteractionCb,
            r = e.doc,
            n = e.mirror,
            i = e.blockClass,
            o = e.blockSelector,
            s = e.sampling;
          if (!1 === s.mouseInteraction) return function () {};
          var a = !0 === s.mouseInteraction || void 0 === s.mouseInteraction ? {} : s.mouseInteraction,
            c = [],
            u = null;
          return (
            Object.keys(nL)
              .filter(function (e) {
                return Number.isNaN(Number(e)) && !e.endsWith("_Departed") && !1 !== a[e];
              })
              .forEach(function (e) {
                var s = es(e),
                  a = function (r) {
                    var s = nq(r);
                    if (!nE(s, i, o, !0)) {
                      var a = null,
                        c = e;
                      if ("pointerType" in r) {
                        switch (r.pointerType) {
                          case "mouse":
                            a = nP.Mouse;
                            break;
                          case "touch":
                            a = nP.Touch;
                            break;
                          case "pen":
                            a = nP.Pen;
                        }
                        a === nP.Touch
                          ? nL[e] === nL.MouseDown
                            ? (c = "TouchStart")
                            : nL[e] === nL.MouseUp && (c = "TouchEnd")
                          : nP.Pen;
                      } else nI(r) && (a = nP.Touch);
                      null !== a
                        ? ((u = a),
                          ((c.startsWith("Touch") && a === nP.Touch) ||
                            (c.startsWith("Mouse") && a === nP.Mouse)) &&
                            (a = null))
                        : nL[e] === nL.Click && ((a = u), (u = null));
                      var l = nI(r) ? r.changedTouches[0] : r;
                      if (l) {
                        var p = n.getId(s),
                          h = l.clientX,
                          d = l.clientY;
                        nz(t)(S({ type: nL[c], id: p, x: h, y: d }, null !== a && { pointerType: a }));
                      }
                    }
                  };
                if (window.PointerEvent)
                  switch (nL[e]) {
                    case nL.MouseDown:
                    case nL.MouseUp:
                      s = s.replace("mouse", "pointer");
                      break;
                    case nL.TouchStart:
                    case nL.TouchEnd:
                      return;
                  }
                c.push(nh(s, a, r));
              }),
            nz(function () {
              c.forEach(function (e) {
                return e();
              });
            })
          );
        })(e),
        o = n$(e),
        s =
          ((R = { win: r }),
          (T = e.viewportResizeCb),
          (x = R.win),
          (M = -1),
          (L = -1),
          nh(
            "resize",
            nz(
              ng(
                nz(function () {
                  var e = ny(),
                    t = nb();
                  (M !== e || L !== t) && (T({ width: Number(t), height: Number(e) }), (M = e), (L = t));
                }),
                200,
              ),
            ),
            x,
          )),
        a = (function (e) {
          var t = e.inputCb,
            r = e.doc,
            n = e.mirror,
            i = e.blockClass,
            o = e.blockSelector,
            s = e.ignoreClass,
            a = e.ignoreSelector,
            c = e.maskInputOptions,
            u = e.maskInputFn,
            l = e.sampling,
            p = e.userTriggeredOnInput;
          function h(e) {
            var t = nq(e),
              n = e.isTrusted,
              l = t && t.tagName;
            if (
              (t && "OPTION" === l && (t = ns(t)), !(!t || !l || 0 > nH.indexOf(l) || nE(t, i, o, !0))) &&
              !(t.classList.contains(s) || (a && t.matches(a)))
            ) {
              var h = t.value,
                f = !1,
                g = ec(t) || "";
              ("radio" === g || "checkbox" === g
                ? (f = t.checked)
                : (c[l.toLowerCase()] || c[g]) &&
                  (h = eo({
                    element: t,
                    maskInputOptions: c,
                    tagName: l,
                    type: g,
                    value: h,
                    maskInputFn: u,
                  })),
                d(t, p ? { text: h, isChecked: f, userTriggered: n } : { text: h, isChecked: f }));
              var m = t.name;
              "radio" === g &&
                m &&
                f &&
                r.querySelectorAll('input[type="radio"][name="' + m + '"]').forEach(function (e) {
                  if (e !== t) {
                    var r = e.value;
                    d(e, p ? { text: r, isChecked: !f, userTriggered: !1 } : { text: r, isChecked: !f });
                  }
                });
            }
          }
          function d(e, r) {
            var i = nZ.get(e);
            if (!i || i.text !== r.text || i.isChecked !== r.isChecked) {
              nZ.set(e, r);
              var o = n.getId(e);
              nz(t)(S({}, r, { id: o }));
            }
          }
          var f = ("last" === l.input ? ["change"] : ["input", "change"]).map(function (e) {
              return nh(e, nz(h), r);
            }),
            g = r.defaultView;
          if (!g)
            return function () {
              f.forEach(function (e) {
                return e();
              });
            };
          var m = g.Object.getOwnPropertyDescriptor(g.HTMLInputElement.prototype, "value"),
            _ = [
              [g.HTMLInputElement.prototype, "value"],
              [g.HTMLInputElement.prototype, "checked"],
              [g.HTMLSelectElement.prototype, "value"],
              [g.HTMLTextAreaElement.prototype, "value"],
              [g.HTMLSelectElement.prototype, "selectedIndex"],
              [g.HTMLOptionElement.prototype, "selected"],
            ];
          return (
            m &&
              m.set &&
              f.push.apply(
                f,
                [].concat(
                  _.map(function (e) {
                    return nm(
                      e[0],
                      e[1],
                      {
                        set: function () {
                          nz(h)({ target: this, isTrusted: !1 });
                        },
                      },
                      !1,
                      g,
                    );
                  }),
                ),
              ),
            nz(function () {
              f.forEach(function (e) {
                return e();
              });
            })
          );
        })(e),
        c =
          ((D = e.mediaInteractionCb),
          (N = e.blockClass),
          (F = e.blockSelector),
          (U = e.mirror),
          (B = e.sampling),
          (j = e.doc),
          (G = [
            nh(
              "play",
              (V = nz(function (e) {
                return ng(
                  nz(function (t) {
                    var r = nq(t);
                    if (!(!r || nE(r, N, F, !0))) {
                      var n = r.currentTime,
                        i = r.volume,
                        o = r.muted,
                        s = r.playbackRate,
                        a = r.loop;
                      D({
                        type: e,
                        id: U.getId(r),
                        currentTime: n,
                        volume: i,
                        muted: o,
                        playbackRate: s,
                        loop: a,
                      });
                    }
                  }),
                  B.media || 500,
                );
              }))(nN.Play),
              j,
            ),
            nh("pause", V(nN.Pause), j),
            nh("seeked", V(nN.Seeked), j),
            nh("volumechange", V(nN.VolumeChange), j),
            nh("ratechange", V(nN.RateChange), j),
          ]),
          nz(function () {
            G.forEach(function (e) {
              return e();
            });
          })),
        u = function () {},
        l = function () {},
        p = function () {},
        h = function () {};
      e.recordDOM &&
        ((u = (function (e, t) {
          var r,
            n,
            i = e.styleSheetRuleCb,
            o = e.mirror,
            s = e.stylesheetManager,
            a = t.win;
          if (!a.CSSStyleSheet || !a.CSSStyleSheet.prototype) return function () {};
          var c = a.CSSStyleSheet.prototype.insertRule;
          ((a.CSSStyleSheet.prototype.insertRule = new Proxy(c, {
            apply: nz(function (e, t, r) {
              var n = r[0],
                a = r[1],
                c = nX(t, o, s.styleMirror),
                u = c.id,
                l = c.styleId;
              return (
                ((u && -1 !== u) || (l && -1 !== l)) &&
                  i({ id: u, styleId: l, adds: [{ rule: n, index: a }] }),
                e.apply(t, r)
              );
            }),
          })),
            (a.CSSStyleSheet.prototype.addRule = function (e, t, r) {
              return (
                void 0 === r && (r = this.cssRules.length),
                a.CSSStyleSheet.prototype.insertRule.apply(this, [e + " { " + t + " }", r])
              );
            }));
          var u = a.CSSStyleSheet.prototype.deleteRule;
          ((a.CSSStyleSheet.prototype.deleteRule = new Proxy(u, {
            apply: nz(function (e, t, r) {
              var n = r[0],
                a = nX(t, o, s.styleMirror),
                c = a.id,
                u = a.styleId;
              return (
                ((c && -1 !== c) || (u && -1 !== u)) && i({ id: c, styleId: u, removes: [{ index: n }] }),
                e.apply(t, r)
              );
            }),
          })),
            (a.CSSStyleSheet.prototype.removeRule = function (e) {
              return a.CSSStyleSheet.prototype.deleteRule.apply(this, [e]);
            }),
            a.CSSStyleSheet.prototype.replace &&
              ((r = a.CSSStyleSheet.prototype.replace),
              (a.CSSStyleSheet.prototype.replace = new Proxy(r, {
                apply: nz(function (e, t, r) {
                  var n = r[0],
                    a = nX(t, o, s.styleMirror),
                    c = a.id,
                    u = a.styleId;
                  return (
                    ((c && -1 !== c) || (u && -1 !== u)) && i({ id: c, styleId: u, replace: n }),
                    e.apply(t, r)
                  );
                }),
              }))),
            a.CSSStyleSheet.prototype.replaceSync &&
              ((n = a.CSSStyleSheet.prototype.replaceSync),
              (a.CSSStyleSheet.prototype.replaceSync = new Proxy(n, {
                apply: nz(function (e, t, r) {
                  var n = r[0],
                    a = nX(t, o, s.styleMirror),
                    c = a.id,
                    u = a.styleId;
                  return (
                    ((c && -1 !== c) || (u && -1 !== u)) && i({ id: c, styleId: u, replaceSync: n }),
                    e.apply(t, r)
                  );
                }),
              }))));
          var l = {};
          n2("CSSGroupingRule")
            ? (l.CSSGroupingRule = a.CSSGroupingRule)
            : (n2("CSSMediaRule") && (l.CSSMediaRule = a.CSSMediaRule),
              n2("CSSConditionRule") && (l.CSSConditionRule = a.CSSConditionRule),
              n2("CSSSupportsRule") && (l.CSSSupportsRule = a.CSSSupportsRule));
          var p = {};
          return (
            Object.entries(l).forEach(function (e) {
              var t = e[0],
                r = e[1];
              ((p[t] = { insertRule: r.prototype.insertRule, deleteRule: r.prototype.deleteRule }),
                (r.prototype.insertRule = new Proxy(p[t].insertRule, {
                  apply: nz(function (e, t, r) {
                    var n = r[0],
                      a = r[1],
                      c = nX(t.parentStyleSheet, o, s.styleMirror),
                      u = c.id,
                      l = c.styleId;
                    return (
                      ((u && -1 !== u) || (l && -1 !== l)) &&
                        i({ id: u, styleId: l, adds: [{ rule: n, index: [].concat(nJ(t), [a || 0]) }] }),
                      e.apply(t, r)
                    );
                  }),
                })),
                (r.prototype.deleteRule = new Proxy(p[t].deleteRule, {
                  apply: nz(function (e, t, r) {
                    var n = r[0],
                      a = nX(t.parentStyleSheet, o, s.styleMirror),
                      c = a.id,
                      u = a.styleId;
                    return (
                      ((c && -1 !== c) || (u && -1 !== u)) &&
                        i({ id: c, styleId: u, removes: [{ index: [].concat(nJ(t), [n]) }] }),
                      e.apply(t, r)
                    );
                  }),
                })));
            }),
            nz(function () {
              ((a.CSSStyleSheet.prototype.insertRule = c),
                (a.CSSStyleSheet.prototype.deleteRule = u),
                r && (a.CSSStyleSheet.prototype.replace = r),
                n && (a.CSSStyleSheet.prototype.replaceSync = n),
                Object.entries(l).forEach(function (e) {
                  var t = e[0],
                    r = e[1];
                  ((r.prototype.insertRule = p[t].insertRule), (r.prototype.deleteRule = p[t].deleteRule));
                }));
            })
          );
        })(e, { win: r })),
        (l = nQ(e, e.doc)),
        (W = e.styleDeclarationCb),
        (z = e.mirror),
        (K = e.ignoreCSSAttributes),
        (q = e.stylesheetManager),
        ($ = (Y = { win: r }.win).CSSStyleDeclaration.prototype.setProperty),
        (Y.CSSStyleDeclaration.prototype.setProperty = new Proxy($, {
          apply: nz(function (e, t, r) {
            var n,
              i = r[0],
              o = r[1],
              s = r[2];
            if (K.has(i)) return $.apply(t, [i, o, s]);
            var a = nX(null == (n = t.parentRule) ? void 0 : n.parentStyleSheet, z, q.styleMirror),
              c = a.id,
              u = a.styleId;
            return (
              ((c && -1 !== c) || (u && -1 !== u)) &&
                W({
                  id: c,
                  styleId: u,
                  set: { property: i, value: o, priority: s },
                  index: nJ(t.parentRule),
                }),
              e.apply(t, r)
            );
          }),
        })),
        (H = Y.CSSStyleDeclaration.prototype.removeProperty),
        (Y.CSSStyleDeclaration.prototype.removeProperty = new Proxy(H, {
          apply: nz(function (e, t, r) {
            var n,
              i = r[0];
            if (K.has(i)) return H.apply(t, [i]);
            var o = nX(null == (n = t.parentRule) ? void 0 : n.parentStyleSheet, z, q.styleMirror),
              s = o.id,
              a = o.styleId;
            return (
              ((s && -1 !== s) || (a && -1 !== a)) &&
                W({ id: s, styleId: a, remove: { property: i }, index: nJ(t.parentRule) }),
              e.apply(t, r)
            );
          }),
        })),
        (p = nz(function () {
          ((Y.CSSStyleDeclaration.prototype.setProperty = $),
            (Y.CSSStyleDeclaration.prototype.removeProperty = H));
        })),
        e.collectFonts &&
          (h = (function (e) {
            var t = e.fontCb,
              r = e.doc,
              n = r.defaultView;
            if (!n) return function () {};
            var i = [],
              o = new WeakMap(),
              s = n.FontFace;
            n.FontFace = function (e, t, r) {
              var n = new s(e, t, r);
              return (
                o.set(n, {
                  family: e,
                  buffer: "string" != typeof t,
                  descriptors: r,
                  fontSource: "string" == typeof t ? t : JSON.stringify(Array.from(new Uint8Array(t))),
                }),
                n
              );
            };
            var a = nn(r.fonts, "add", function (e) {
              return function (r) {
                return (
                  setTimeout(
                    nz(function () {
                      var e = o.get(r);
                      e && (t(e), o.delete(r));
                    }),
                    0,
                  ),
                  e.apply(this, [r])
                );
              };
            });
            return (
              i.push(function () {
                n.FontFace = s;
              }),
              i.push(a),
              nz(function () {
                i.forEach(function (e) {
                  return e();
                });
              })
            );
          })(e)));
      for (
        var d,
          f,
          g,
          m,
          _,
          v,
          y,
          b,
          C,
          E,
          w,
          I,
          k,
          O,
          R,
          T,
          x,
          M,
          L,
          D,
          N,
          F,
          U,
          B,
          j,
          V,
          G,
          W,
          z,
          K,
          q,
          Y,
          $,
          H,
          Z,
          J,
          X,
          Q,
          ee,
          et,
          er,
          en,
          ei,
          ea,
          eu,
          el,
          ep =
            ((Z = e.doc),
            (J = e.mirror),
            (X = e.blockClass),
            (Q = e.blockSelector),
            (ee = e.selectionCb),
            (et = !0),
            (er = nz(function () {
              var e = Z.getSelection();
              if (e && (!et || null == e || !e.isCollapsed)) {
                et = e.isCollapsed || !1;
                for (var t = [], r = e.rangeCount || 0, n = 0; n < r; n++) {
                  var i = e.getRangeAt(n),
                    o = i.startContainer,
                    s = i.startOffset,
                    a = i.endContainer,
                    c = i.endOffset;
                  nE(o, X, Q, !0) ||
                    nE(a, X, Q, !0) ||
                    t.push({ start: J.getId(o), startOffset: s, end: J.getId(a), endOffset: c });
                }
                ee({ ranges: t });
              }
            }))(),
            nh("selectionchange", er)),
          eh =
            ((en = e.doc),
            (ei = e.customElementCb),
            (ea = en.defaultView) && ea.customElements
              ? nn(ea.customElements, "define", function (e) {
                  return function (t, r, n) {
                    try {
                      ei({ define: { name: t } });
                    } catch (e) {
                      console.warn("Custom element callback failed for " + t);
                    }
                    return e.apply(this, [t, r, n]);
                  };
                })
              : function () {}),
          ed = [],
          ef = P(e.plugins);
        !(el = ef()).done;
      ) {
        var eg = el.value;
        ed.push(eg.observer(eg.callback, r, eg.options));
      }
      return nz(function () {
        (nK.forEach(function (e) {
          return e.reset();
        }),
          null == eu || eu.disconnect(),
          n(),
          i(),
          o(),
          s(),
          a(),
          c(),
          u(),
          l(),
          p(),
          h(),
          ep(),
          eh(),
          ed.forEach(function (e) {
            return e();
          }));
      });
    }
    function n1(e) {
      return void 0 !== window[e];
    }
    function n2(e) {
      return !!(
        void 0 !== window[e] &&
        window[e].prototype &&
        "insertRule" in window[e].prototype &&
        "deleteRule" in window[e].prototype
      );
    }
    for (
      var n3 = (function () {
          function e(e) {
            (U(this, "iframeIdToRemoteIdMap", new WeakMap()),
              U(this, "iframeRemoteIdToIdMap", new WeakMap()),
              (this.generateIdFn = e));
          }
          var t = e.prototype;
          return (
            (t.getId = function (e, t, r, n) {
              var i = r || this.getIdToRemoteIdMap(e),
                o = n || this.getRemoteIdToIdMap(e),
                s = i.get(t);
              return (s || ((s = this.generateIdFn()), i.set(t, s), o.set(s, t)), s);
            }),
            (t.getIds = function (e, t) {
              var r = this,
                n = this.getIdToRemoteIdMap(e),
                i = this.getRemoteIdToIdMap(e);
              return t.map(function (t) {
                return r.getId(e, t, n, i);
              });
            }),
            (t.getRemoteId = function (e, t, r) {
              var n = r || this.getRemoteIdToIdMap(e);
              if ("number" != typeof t) return t;
              var i = n.get(t);
              return i || -1;
            }),
            (t.getRemoteIds = function (e, t) {
              var r = this,
                n = this.getRemoteIdToIdMap(e);
              return t.map(function (t) {
                return r.getRemoteId(e, t, n);
              });
            }),
            (t.reset = function (e) {
              if (!e) {
                ((this.iframeIdToRemoteIdMap = new WeakMap()), (this.iframeRemoteIdToIdMap = new WeakMap()));
                return;
              }
              (this.iframeIdToRemoteIdMap.delete(e), this.iframeRemoteIdToIdMap.delete(e));
            }),
            (t.getIdToRemoteIdMap = function (e) {
              var t = this.iframeIdToRemoteIdMap.get(e);
              return (t || ((t = new Map()), this.iframeIdToRemoteIdMap.set(e, t)), t);
            }),
            (t.getRemoteIdToIdMap = function (e) {
              var t = this.iframeRemoteIdToIdMap.get(e);
              return (t || ((t = new Map()), this.iframeRemoteIdToIdMap.set(e, t)), t);
            }),
            e
          );
        })(),
        n4 = (function () {
          function e(e) {
            (U(this, "iframes", new WeakMap()),
              U(this, "crossOriginIframeMap", new WeakMap()),
              U(this, "crossOriginIframeMirror", new n3(ev)),
              U(this, "crossOriginIframeStyleMirror"),
              U(this, "crossOriginIframeRootIdMap", new WeakMap()),
              U(this, "mirror"),
              U(this, "mutationCb"),
              U(this, "wrappedEmit"),
              U(this, "loadListener"),
              U(this, "stylesheetManager"),
              U(this, "recordCrossOriginIframes"),
              (this.mutationCb = e.mutationCb),
              (this.wrappedEmit = e.wrappedEmit),
              (this.stylesheetManager = e.stylesheetManager),
              (this.recordCrossOriginIframes = e.recordCrossOriginIframes),
              (this.crossOriginIframeStyleMirror = new n3(
                this.stylesheetManager.styleMirror.generateId.bind(this.stylesheetManager.styleMirror),
              )),
              (this.mirror = e.mirror),
              this.recordCrossOriginIframes &&
                window.addEventListener("message", this.handleMessage.bind(this)));
          }
          var t = e.prototype;
          return (
            (t.addIframe = function (e) {
              (this.iframes.set(e, !0), e.contentWindow && this.crossOriginIframeMap.set(e.contentWindow, e));
            }),
            (t.addLoadListener = function (e) {
              this.loadListener = e;
            }),
            (t.attachIframe = function (e, t) {
              var r, n;
              (this.mutationCb({
                adds: [{ parentId: this.mirror.getId(e), nextId: null, node: t }],
                removes: [],
                texts: [],
                attributes: [],
                isAttachIframe: !0,
              }),
                this.recordCrossOriginIframes &&
                  (null == (r = e.contentWindow) ||
                    r.addEventListener("message", this.handleMessage.bind(this))),
                null == (n = this.loadListener) || n.call(this, e),
                e.contentDocument &&
                  e.contentDocument.adoptedStyleSheets &&
                  e.contentDocument.adoptedStyleSheets.length > 0 &&
                  this.stylesheetManager.adoptStyleSheets(
                    e.contentDocument.adoptedStyleSheets,
                    this.mirror.getId(e.contentDocument),
                  ));
            }),
            (t.handleMessage = function (e) {
              if ("rrweb" === e.data.type && e.origin === e.data.origin && e.source) {
                var t = this.crossOriginIframeMap.get(e.source);
                if (t) {
                  var r = this.transformCrossOriginEvent(t, e.data.event);
                  r && this.wrappedEmit(r, e.data.isCheckout);
                }
              }
            }),
            (t.transformCrossOriginEvent = function (e, t) {
              var r,
                n = this;
              switch (t.type) {
                case nx.FullSnapshot:
                  (this.crossOriginIframeMirror.reset(e),
                    this.crossOriginIframeStyleMirror.reset(e),
                    this.replaceIdOnNode(t.data.node, e));
                  var i = t.data.node.id;
                  return (
                    this.crossOriginIframeRootIdMap.set(e, i),
                    this.patchRootIdOnNode(t.data.node, i),
                    {
                      timestamp: t.timestamp,
                      type: nx.IncrementalSnapshot,
                      data: {
                        source: nM.Mutation,
                        adds: [{ parentId: this.mirror.getId(e), nextId: null, node: t.data.node }],
                        removes: [],
                        texts: [],
                        attributes: [],
                        isAttachIframe: !0,
                      },
                    }
                  );
                case nx.Meta:
                case nx.Load:
                case nx.DomContentLoaded:
                  break;
                case nx.Plugin:
                  return t;
                case nx.Custom:
                  return (this.replaceIds(t.data.payload, e, ["id", "parentId", "previousId", "nextId"]), t);
                case nx.IncrementalSnapshot:
                  switch (t.data.source) {
                    case nM.Mutation:
                      return (
                        t.data.adds.forEach(function (t) {
                          (n.replaceIds(t, e, ["parentId", "nextId", "previousId"]),
                            n.replaceIdOnNode(t.node, e));
                          var r = n.crossOriginIframeRootIdMap.get(e);
                          r && n.patchRootIdOnNode(t.node, r);
                        }),
                        t.data.removes.forEach(function (t) {
                          n.replaceIds(t, e, ["parentId", "id"]);
                        }),
                        t.data.attributes.forEach(function (t) {
                          n.replaceIds(t, e, ["id"]);
                        }),
                        t.data.texts.forEach(function (t) {
                          n.replaceIds(t, e, ["id"]);
                        }),
                        t
                      );
                    case nM.Drag:
                    case nM.TouchMove:
                    case nM.MouseMove:
                      return (
                        t.data.positions.forEach(function (t) {
                          n.replaceIds(t, e, ["id"]);
                        }),
                        t
                      );
                    case nM.ViewportResize:
                      return !1;
                    case nM.MediaInteraction:
                    case nM.MouseInteraction:
                    case nM.Scroll:
                    case nM.CanvasMutation:
                    case nM.Input:
                      return (this.replaceIds(t.data, e, ["id"]), t);
                    case nM.StyleSheetRule:
                    case nM.StyleDeclaration:
                      return (
                        this.replaceIds(t.data, e, ["id"]),
                        this.replaceStyleIds(t.data, e, ["styleId"]),
                        t
                      );
                    case nM.Font:
                      return t;
                    case nM.Selection:
                      return (
                        t.data.ranges.forEach(function (t) {
                          n.replaceIds(t, e, ["start", "end"]);
                        }),
                        t
                      );
                    case nM.AdoptedStyleSheet:
                      return (
                        this.replaceIds(t.data, e, ["id"]),
                        this.replaceStyleIds(t.data, e, ["styleIds"]),
                        null == (r = t.data.styles) ||
                          r.forEach(function (t) {
                            n.replaceStyleIds(t, e, ["styleId"]);
                          }),
                        t
                      );
                  }
              }
              return !1;
            }),
            (t.replace = function (e, t, r, n) {
              for (var i, o = P(n); !(i = o()).done;) {
                var s = i.value;
                (Array.isArray(t[s]) || "number" == typeof t[s]) &&
                  (Array.isArray(t[s]) ? (t[s] = e.getIds(r, t[s])) : (t[s] = e.getId(r, t[s])));
              }
              return t;
            }),
            (t.replaceIds = function (e, t, r) {
              return this.replace(this.crossOriginIframeMirror, e, t, r);
            }),
            (t.replaceStyleIds = function (e, t, r) {
              return this.replace(this.crossOriginIframeStyleMirror, e, t, r);
            }),
            (t.replaceIdOnNode = function (e, t) {
              var r = this;
              (this.replaceIds(e, t, ["id", "rootId"]),
                ("childNodes" in e) &&
                  e.childNodes.forEach(function (e) {
                    r.replaceIdOnNode(e, t);
                  }));
            }),
            (t.patchRootIdOnNode = function (e, t) {
              var r = this;
              (e.type === nF.Document || e.rootId || (e.rootId = t),
                ("childNodes" in e) &&
                  e.childNodes.forEach(function (e) {
                    r.patchRootIdOnNode(e, t);
                  }));
            }),
            e
          );
        })(),
        n5 = (function () {
          function e(e) {
            (U(this, "shadowDoms", new WeakSet()),
              U(this, "mutationCb"),
              U(this, "scrollCb"),
              U(this, "bypassOptions"),
              U(this, "mirror"),
              U(this, "restoreHandlers", []),
              (this.mutationCb = e.mutationCb),
              (this.scrollCb = e.scrollCb),
              (this.bypassOptions = e.bypassOptions),
              (this.mirror = e.mirror),
              this.init());
          }
          var t = e.prototype;
          return (
            (t.init = function () {
              (this.reset(), this.patchAttachShadow(Element, document));
            }),
            (t.addShadowRoot = function (e, t) {
              var r = this;
              if (et(e) && !this.shadowDoms.has(e)) {
                this.shadowDoms.add(e);
                var n = nY(
                  S({}, this.bypassOptions, {
                    doc: t,
                    mutationCb: this.mutationCb,
                    mirror: this.mirror,
                    shadowDomManager: this,
                  }),
                  e,
                );
                (this.restoreHandlers.push(function () {
                  return n.disconnect();
                }),
                  this.restoreHandlers.push(
                    n$(S({}, this.bypassOptions, { scrollCb: this.scrollCb, doc: e, mirror: this.mirror })),
                  ),
                  setTimeout(function () {
                    (e.adoptedStyleSheets &&
                      e.adoptedStyleSheets.length > 0 &&
                      r.bypassOptions.stylesheetManager.adoptStyleSheets(
                        e.adoptedStyleSheets,
                        r.mirror.getId(nl(e)),
                      ),
                      r.restoreHandlers.push(
                        nQ({ mirror: r.mirror, stylesheetManager: r.bypassOptions.stylesheetManager }, e),
                      ));
                  }, 0));
              }
            }),
            (t.observeAttachShadow = function (e) {
              e.contentWindow &&
                e.contentDocument &&
                this.patchAttachShadow(e.contentWindow.Element, e.contentDocument);
            }),
            (t.patchAttachShadow = function (e, t) {
              var r = this;
              this.restoreHandlers.push(
                nn(e.prototype, "attachShadow", function (e) {
                  return function (n) {
                    var i = e.call(this, n),
                      o = np(this);
                    return (o && nT(this) && r.addShadowRoot(o, t), i);
                  };
                }),
              );
            }),
            (t.reset = function () {
              (this.restoreHandlers.forEach(function (e) {
                try {
                  e();
                } catch (e) {}
              }),
                (this.restoreHandlers = []),
                (this.shadowDoms = new WeakSet()));
            }),
            e
          );
        })(),
        n9 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
        n6 = "u" < typeof Uint8Array ? [] : new Uint8Array(256),
        n8 = 0;
      n8 < n9.length;
      n8++
    )
      n6[n9.charCodeAt(n8)] = n8;
    var n7 = function (e) {
        var t,
          r = new Uint8Array(e),
          n = r.length,
          i = "";
        for (t = 0; t < n; t += 3)
          ((i += n9[r[t] >> 2]),
            (i += n9[((3 & r[t]) << 4) | (r[t + 1] >> 4)]),
            (i += n9[((15 & r[t + 1]) << 2) | (r[t + 2] >> 6)]),
            (i += n9[63 & r[t + 2]]));
        return (
          n % 3 == 2
            ? (i = i.substring(0, i.length - 1) + "=")
            : n % 3 == 1 && (i = i.substring(0, i.length - 2) + "=="),
          i
        );
      },
      ie = new Map(),
      it = function (e, t, r) {
        if (e && (ii(e, t) || (void 0 === e ? "undefined" : x(e)) === "object")) {
          var n,
            i = e.constructor.name,
            o = ((n = ie.get(r)) || ((n = new Map()), ie.set(r, n)), n.has(i) || n.set(i, []), n.get(i)),
            s = o.indexOf(e);
          return (-1 === s && ((s = o.length), o.push(e)), s);
        }
      },
      ir = function (e, t, r) {
        return e.map(function (e) {
          return (function e(t, r, n) {
            if (A(t, Array))
              return t.map(function (t) {
                return e(t, r, n);
              });
            if (null === t);
            else if (
              A(t, Float32Array) ||
              A(t, Float64Array) ||
              A(t, Int32Array) ||
              A(t, Uint32Array) ||
              A(t, Uint8Array) ||
              A(t, Uint16Array) ||
              A(t, Int16Array) ||
              A(t, Int8Array) ||
              A(t, Uint8ClampedArray)
            )
              return { rr_type: t.constructor.name, args: [Object.values(t)] };
            else if (A(t, ArrayBuffer)) return { rr_type: t.constructor.name, base64: n7(t) };
            else if (A(t, DataView))
              return { rr_type: t.constructor.name, args: [e(t.buffer, r, n), t.byteOffset, t.byteLength] };
            else if (A(t, HTMLImageElement)) return { rr_type: t.constructor.name, src: t.src };
            else if (A(t, HTMLCanvasElement)) return { rr_type: "HTMLImageElement", src: t.toDataURL() };
            else if (A(t, ImageData))
              return { rr_type: t.constructor.name, args: [e(t.data, r, n), t.width, t.height] };
            else if (ii(t, r) || (void 0 === t ? "undefined" : x(t)) === "object")
              return { rr_type: t.constructor.name, index: it(t, r, n) };
            return t;
          })(e, t, r);
        });
      },
      ii = function (e, t) {
        return !![
          "WebGLActiveInfo",
          "WebGLBuffer",
          "WebGLFramebuffer",
          "WebGLProgram",
          "WebGLRenderbuffer",
          "WebGLShader",
          "WebGLShaderPrecisionFormat",
          "WebGLTexture",
          "WebGLUniformLocation",
          "WebGLVertexArrayObject",
          "WebGLVertexArrayObjectOES",
        ]
          .filter(function (e) {
            return "function" == typeof t[e];
          })
          .find(function (r) {
            return A(e, t[r]);
          });
      };
    function io(e, t, r, n) {
      var i = [];
      try {
        var o = nn(e.HTMLCanvasElement.prototype, "getContext", function (e) {
          return function (i) {
            for (var o = arguments.length, s = Array(o > 1 ? o - 1 : 0), a = 1; a < o; a++)
              s[a - 1] = arguments[a];
            if (!nE(this, t, r, !0)) {
              var c = "experimental-webgl" === i ? "webgl" : i;
              if (("__context" in this || (this.__context = c), n && ["webgl", "webgl2"].includes(c)))
                if (s[0] && "object" === x(s[0])) {
                  var u = s[0];
                  u.preserveDrawingBuffer || (u.preserveDrawingBuffer = !0);
                } else s.splice(0, 1, { preserveDrawingBuffer: !0 });
            }
            return e.apply(this, [].concat([i], s));
          };
        });
        i.push(o);
      } catch (e) {
        console.error("failed to patch HTMLCanvasElement.prototype.getContext");
      }
      return function () {
        i.forEach(function (e) {
          return e();
        });
      };
    }
    function is(e, t, r, n, i, o) {
      for (var s, a = [], c = Object.getOwnPropertyNames(e), u = P(c); !(s = u()).done;)
        !(function () {
          var c = s.value;
          if (!["isContextLost", "canvas", "drawingBufferWidth", "drawingBufferHeight"].includes(c))
            try {
              if ("function" != typeof e[c]) return "continue";
              var u = nn(e, c, function (e) {
                return function () {
                  for (var s = arguments.length, a = Array(s), u = 0; u < s; u++) a[u] = arguments[u];
                  var l = e.apply(this, a);
                  if ((it(l, o, this), "tagName" in this.canvas && !nE(this.canvas, n, i, !0))) {
                    var p = ir(a, o, this);
                    r(this.canvas, { type: t, property: c, args: p });
                  }
                  return l;
                };
              });
              a.push(u);
            } catch (n) {
              a.push(
                nm(e, c, {
                  set: function (e) {
                    r(this.canvas, { type: t, property: c, args: [e], setter: !0 });
                  },
                }),
              );
            }
        })();
      return a;
    }
    var ia =
        "KGZ1bmN0aW9uKCkgewogICJ1c2Ugc3RyaWN0IjsKICB2YXIgY2hhcnMgPSAiQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODkrLyI7CiAgdmFyIGxvb2t1cCA9IHR5cGVvZiBVaW50OEFycmF5ID09PSAidW5kZWZpbmVkIiA/IFtdIDogbmV3IFVpbnQ4QXJyYXkoMjU2KTsKICBmb3IgKHZhciBpID0gMDsgaSA8IGNoYXJzLmxlbmd0aDsgaSsrKSB7CiAgICBsb29rdXBbY2hhcnMuY2hhckNvZGVBdChpKV0gPSBpOwogIH0KICB2YXIgZW5jb2RlID0gZnVuY3Rpb24oYXJyYXlidWZmZXIpIHsKICAgIHZhciBieXRlcyA9IG5ldyBVaW50OEFycmF5KGFycmF5YnVmZmVyKSwgaTIsIGxlbiA9IGJ5dGVzLmxlbmd0aCwgYmFzZTY0ID0gIiI7CiAgICBmb3IgKGkyID0gMDsgaTIgPCBsZW47IGkyICs9IDMpIHsKICAgICAgYmFzZTY0ICs9IGNoYXJzW2J5dGVzW2kyXSA+PiAyXTsKICAgICAgYmFzZTY0ICs9IGNoYXJzWyhieXRlc1tpMl0gJiAzKSA8PCA0IHwgYnl0ZXNbaTIgKyAxXSA+PiA0XTsKICAgICAgYmFzZTY0ICs9IGNoYXJzWyhieXRlc1tpMiArIDFdICYgMTUpIDw8IDIgfCBieXRlc1tpMiArIDJdID4+IDZdOwogICAgICBiYXNlNjQgKz0gY2hhcnNbYnl0ZXNbaTIgKyAyXSAmIDYzXTsKICAgIH0KICAgIGlmIChsZW4gJSAzID09PSAyKSB7CiAgICAgIGJhc2U2NCA9IGJhc2U2NC5zdWJzdHJpbmcoMCwgYmFzZTY0Lmxlbmd0aCAtIDEpICsgIj0iOwogICAgfSBlbHNlIGlmIChsZW4gJSAzID09PSAxKSB7CiAgICAgIGJhc2U2NCA9IGJhc2U2NC5zdWJzdHJpbmcoMCwgYmFzZTY0Lmxlbmd0aCAtIDIpICsgIj09IjsKICAgIH0KICAgIHJldHVybiBiYXNlNjQ7CiAgfTsKICBjb25zdCBsYXN0QmxvYk1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7CiAgY29uc3QgdHJhbnNwYXJlbnRCbG9iTWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTsKICBhc3luYyBmdW5jdGlvbiBnZXRUcmFuc3BhcmVudEJsb2JGb3Iod2lkdGgsIGhlaWdodCwgZGF0YVVSTE9wdGlvbnMpIHsKICAgIGNvbnN0IGlkID0gYCR7d2lkdGh9LSR7aGVpZ2h0fWA7CiAgICBpZiAoIk9mZnNjcmVlbkNhbnZhcyIgaW4gZ2xvYmFsVGhpcykgewogICAgICBpZiAodHJhbnNwYXJlbnRCbG9iTWFwLmhhcyhpZCkpIHJldHVybiB0cmFuc3BhcmVudEJsb2JNYXAuZ2V0KGlkKTsKICAgICAgY29uc3Qgb2Zmc2NyZWVuID0gbmV3IE9mZnNjcmVlbkNhbnZhcyh3aWR0aCwgaGVpZ2h0KTsKICAgICAgb2Zmc2NyZWVuLmdldENvbnRleHQoIjJkIik7CiAgICAgIGNvbnN0IGJsb2IgPSBhd2FpdCBvZmZzY3JlZW4uY29udmVydFRvQmxvYihkYXRhVVJMT3B0aW9ucyk7CiAgICAgIGNvbnN0IGFycmF5QnVmZmVyID0gYXdhaXQgYmxvYi5hcnJheUJ1ZmZlcigpOwogICAgICBjb25zdCBiYXNlNjQgPSBlbmNvZGUoYXJyYXlCdWZmZXIpOwogICAgICB0cmFuc3BhcmVudEJsb2JNYXAuc2V0KGlkLCBiYXNlNjQpOwogICAgICByZXR1cm4gYmFzZTY0OwogICAgfSBlbHNlIHsKICAgICAgcmV0dXJuICIiOwogICAgfQogIH0KICBjb25zdCB3b3JrZXIgPSBzZWxmOwogIHdvcmtlci5vbm1lc3NhZ2UgPSBhc3luYyBmdW5jdGlvbihlKSB7CiAgICBpZiAoIk9mZnNjcmVlbkNhbnZhcyIgaW4gZ2xvYmFsVGhpcykgewogICAgICBjb25zdCB7IGlkLCBiaXRtYXAsIHdpZHRoLCBoZWlnaHQsIGRhdGFVUkxPcHRpb25zIH0gPSBlLmRhdGE7CiAgICAgIGNvbnN0IHRyYW5zcGFyZW50QmFzZTY0ID0gZ2V0VHJhbnNwYXJlbnRCbG9iRm9yKAogICAgICAgIHdpZHRoLAogICAgICAgIGhlaWdodCwKICAgICAgICBkYXRhVVJMT3B0aW9ucwogICAgICApOwogICAgICBjb25zdCBvZmZzY3JlZW4gPSBuZXcgT2Zmc2NyZWVuQ2FudmFzKHdpZHRoLCBoZWlnaHQpOwogICAgICBjb25zdCBjdHggPSBvZmZzY3JlZW4uZ2V0Q29udGV4dCgiMmQiKTsKICAgICAgY3R4LmRyYXdJbWFnZShiaXRtYXAsIDAsIDApOwogICAgICBiaXRtYXAuY2xvc2UoKTsKICAgICAgY29uc3QgYmxvYiA9IGF3YWl0IG9mZnNjcmVlbi5jb252ZXJ0VG9CbG9iKGRhdGFVUkxPcHRpb25zKTsKICAgICAgY29uc3QgdHlwZSA9IGJsb2IudHlwZTsKICAgICAgY29uc3QgYXJyYXlCdWZmZXIgPSBhd2FpdCBibG9iLmFycmF5QnVmZmVyKCk7CiAgICAgIGNvbnN0IGJhc2U2NCA9IGVuY29kZShhcnJheUJ1ZmZlcik7CiAgICAgIGlmICghbGFzdEJsb2JNYXAuaGFzKGlkKSAmJiBhd2FpdCB0cmFuc3BhcmVudEJhc2U2NCA9PT0gYmFzZTY0KSB7CiAgICAgICAgbGFzdEJsb2JNYXAuc2V0KGlkLCBiYXNlNjQpOwogICAgICAgIHJldHVybiB3b3JrZXIucG9zdE1lc3NhZ2UoeyBpZCB9KTsKICAgICAgfQogICAgICBpZiAobGFzdEJsb2JNYXAuZ2V0KGlkKSA9PT0gYmFzZTY0KSByZXR1cm4gd29ya2VyLnBvc3RNZXNzYWdlKHsgaWQgfSk7CiAgICAgIHdvcmtlci5wb3N0TWVzc2FnZSh7CiAgICAgICAgaWQsCiAgICAgICAgdHlwZSwKICAgICAgICBiYXNlNjQsCiAgICAgICAgd2lkdGgsCiAgICAgICAgaGVpZ2h0CiAgICAgIH0pOwogICAgICBsYXN0QmxvYk1hcC5zZXQoaWQsIGJhc2U2NCk7CiAgICB9IGVsc2UgewogICAgICByZXR1cm4gd29ya2VyLnBvc3RNZXNzYWdlKHsgaWQ6IGUuZGF0YS5pZCB9KTsKICAgIH0KICB9Owp9KSgpOwovLyMgc291cmNlTWFwcGluZ1VSTD1pbWFnZS1iaXRtYXAtZGF0YS11cmwtd29ya2VyLUlKcEM3Z19iLmpzLm1hcAo=",
      ic =
        "u" > typeof window &&
        window.Blob &&
        new Blob(
          [
            Uint8Array.from(atob(ia), function (e) {
              return e.charCodeAt(0);
            }),
          ],
          { type: "text/javascript;charset=utf-8" },
        );
    function iu(e) {
      var t;
      try {
        if (!(t = ic && (window.URL || window.webkitURL).createObjectURL(ic))) throw "";
        var r = new Worker(t, { name: null == e ? void 0 : e.name });
        return (
          r.addEventListener("error", function () {
            (window.URL || window.webkitURL).revokeObjectURL(t);
          }),
          r
        );
      } catch (t) {
        return new Worker("data:text/javascript;base64," + ia, { name: null == e ? void 0 : e.name });
      } finally {
        t && (window.URL || window.webkitURL).revokeObjectURL(t);
      }
    }
    var il = (function () {
        function e(e) {
          var t = this;
          (U(this, "pendingCanvasMutations", new Map()),
            U(this, "rafStamps", { latestId: 0, invokeId: null }),
            U(this, "mirror"),
            U(this, "mutationCb"),
            U(this, "resetObservers"),
            U(this, "frozen", !1),
            U(this, "locked", !1),
            U(this, "processMutation", function (e, r) {
              (((t.rafStamps.invokeId && t.rafStamps.latestId !== t.rafStamps.invokeId) ||
                !t.rafStamps.invokeId) &&
                (t.rafStamps.invokeId = t.rafStamps.latestId),
                t.pendingCanvasMutations.has(e) || t.pendingCanvasMutations.set(e, []),
                t.pendingCanvasMutations.get(e).push(r));
            }));
          var r = e.sampling,
            n = void 0 === r ? "all" : r,
            i = e.win,
            o = e.blockClass,
            s = e.blockSelector,
            a = e.recordCanvas,
            c = e.dataURLOptions;
          ((this.mutationCb = e.mutationCb),
            (this.mirror = e.mirror),
            a && "all" === n && this.initCanvasMutationObserver(i, o, s),
            a && "number" == typeof n && this.initCanvasFPSObserver(n, i, o, s, { dataURLOptions: c }));
        }
        var t = e.prototype;
        return (
          (t.reset = function () {
            (this.pendingCanvasMutations.clear(), this.resetObservers && this.resetObservers());
          }),
          (t.freeze = function () {
            this.frozen = !0;
          }),
          (t.unfreeze = function () {
            this.frozen = !1;
          }),
          (t.lock = function () {
            this.locked = !0;
          }),
          (t.unlock = function () {
            this.locked = !1;
          }),
          (t.initCanvasFPSObserver = function (e, t, r, n, i) {
            var o,
              s = this,
              a = io(t, r, n, !0),
              c = new Map(),
              u = new iu();
            u.onmessage = function (e) {
              var t = e.data.id;
              if ((c.set(t, !1), "base64" in e.data)) {
                var r = e.data,
                  n = r.base64,
                  i = r.type,
                  o = r.width,
                  a = r.height;
                s.mutationCb({
                  id: t,
                  type: nD["2D"],
                  commands: [
                    { property: "clearRect", args: [0, 0, o, a] },
                    {
                      property: "drawImage",
                      args: [
                        {
                          rr_type: "ImageBitmap",
                          args: [{ rr_type: "Blob", data: [{ rr_type: "ArrayBuffer", base64: n }], type: i }],
                        },
                        0,
                        0,
                      ],
                    },
                  ],
                });
              }
            };
            var l = 1e3 / e,
              p = 0,
              h = function () {
                var e = [];
                return (
                  t.document.querySelectorAll("canvas").forEach(function (t) {
                    nE(t, r, n, !0) || e.push(t);
                  }),
                  e
                );
              },
              d = function (e) {
                if (p && e - p < l) {
                  o = requestAnimationFrame(d);
                  return;
                }
                ((p = e),
                  h().forEach(
                    E(function (e) {
                      var t, r, n, o;
                      return D(this, function (a) {
                        switch (a.label) {
                          case 0:
                            if (((r = s.mirror.getId(e)), c.get(r) || 0 === e.width || 0 === e.height))
                              return [2];
                            return (
                              c.set(r, !0),
                              ["webgl", "webgl2"].includes(e.__context) &&
                                (null ==
                                (t =
                                  null == (n = e.getContext(e.__context)) ? void 0 : n.getContextAttributes())
                                  ? void 0
                                  : t.preserveDrawingBuffer) === !1 &&
                                n.clear(n.COLOR_BUFFER_BIT),
                              [4, createImageBitmap(e)]
                            );
                          case 1:
                            return (
                              (o = a.sent()),
                              u.postMessage(
                                {
                                  id: r,
                                  bitmap: o,
                                  width: e.width,
                                  height: e.height,
                                  dataURLOptions: i.dataURLOptions,
                                },
                                [o],
                              ),
                              [2]
                            );
                        }
                      });
                    }),
                  ),
                  (o = requestAnimationFrame(d)));
              };
            ((o = requestAnimationFrame(d)),
              (this.resetObservers = function () {
                (a(), cancelAnimationFrame(o));
              }));
          }),
          (t.initCanvasMutationObserver = function (e, t, r) {
            (this.startRAFTimestamping(), this.startPendingCanvasMutationFlusher());
            var n,
              i,
              o = io(e, t, r, !1),
              s = (function (e, t, r, n) {
                for (
                  var i,
                    o = [],
                    s = Object.getOwnPropertyNames(t.CanvasRenderingContext2D.prototype),
                    a = P(s);
                  !(i = a()).done;
                )
                  !(function () {
                    var s = i.value;
                    try {
                      if ("function" != typeof t.CanvasRenderingContext2D.prototype[s]) return "continue";
                      var a = nn(t.CanvasRenderingContext2D.prototype, s, function (i) {
                        return function () {
                          for (var o = this, a = arguments.length, c = Array(a), u = 0; u < a; u++)
                            c[u] = arguments[u];
                          return (
                            nE(this.canvas, r, n, !0) ||
                              setTimeout(function () {
                                var r = ir(c, t, o);
                                e(o.canvas, { type: nD["2D"], property: s, args: r });
                              }, 0),
                            i.apply(this, c)
                          );
                        };
                      });
                      o.push(a);
                    } catch (r) {
                      var c = nm(t.CanvasRenderingContext2D.prototype, s, {
                        set: function (t) {
                          e(this.canvas, { type: nD["2D"], property: s, args: [t], setter: !0 });
                        },
                      });
                      o.push(c);
                    }
                  })();
                return function () {
                  o.forEach(function (e) {
                    return e();
                  });
                };
              })(this.processMutation.bind(this), e, t, r),
              a =
                ((n = this.processMutation.bind(this)),
                (i = []).push.apply(
                  i,
                  [].concat(is(e.WebGLRenderingContext.prototype, nD.WebGL, n, t, r, e)),
                ),
                void 0 !== e.WebGL2RenderingContext &&
                  i.push.apply(i, [].concat(is(e.WebGL2RenderingContext.prototype, nD.WebGL2, n, t, r, e))),
                function () {
                  i.forEach(function (e) {
                    return e();
                  });
                });
            this.resetObservers = function () {
              (o(), s(), a());
            };
          }),
          (t.startPendingCanvasMutationFlusher = function () {
            var e = this;
            requestAnimationFrame(function () {
              return e.flushPendingCanvasMutations();
            });
          }),
          (t.startRAFTimestamping = function () {
            var e = this,
              t = function (r) {
                ((e.rafStamps.latestId = r), requestAnimationFrame(t));
              };
            requestAnimationFrame(t);
          }),
          (t.flushPendingCanvasMutations = function () {
            var e = this;
            (this.pendingCanvasMutations.forEach(function (t, r) {
              var n = e.mirror.getId(r);
              e.flushPendingCanvasMutationFor(r, n);
            }),
              requestAnimationFrame(function () {
                return e.flushPendingCanvasMutations();
              }));
          }),
          (t.flushPendingCanvasMutationFor = function (e, t) {
            if (!this.frozen && !this.locked) {
              var r = this.pendingCanvasMutations.get(e);
              if (r && -1 !== t) {
                var n = r.map(function (e) {
                    return (e.type, R(e, ["type"]));
                  }),
                  i = r[0].type;
                (this.mutationCb({ id: t, type: i, commands: n }), this.pendingCanvasMutations.delete(e));
              }
            }
          }),
          e
        );
      })(),
      ip = (function () {
        function e(e) {
          (U(this, "trackedLinkElements", new WeakSet()),
            U(this, "mutationCb"),
            U(this, "adoptedStyleSheetCb"),
            U(this, "styleMirror", new nA()),
            (this.mutationCb = e.mutationCb),
            (this.adoptedStyleSheetCb = e.adoptedStyleSheetCb));
        }
        var t = e.prototype;
        return (
          (t.attachLinkElement = function (e, t) {
            ("_cssText" in t.attributes &&
              this.mutationCb({
                adds: [],
                removes: [],
                texts: [],
                attributes: [{ id: t.id, attributes: t.attributes }],
              }),
              this.trackLinkElement(e));
          }),
          (t.trackLinkElement = function (e) {
            this.trackedLinkElements.has(e) ||
              (this.trackedLinkElements.add(e), this.trackStylesheetInLinkElement(e));
          }),
          (t.adoptStyleSheets = function (e, t) {
            if (0 !== e.length) {
              for (var r, n, i = { id: t, styleIds: [] }, o = [], s = P(e); !(n = s()).done;)
                ((r = this),
                  (function () {
                    var e = n.value,
                      t = void 0;
                    (r.styleMirror.has(e)
                      ? (t = r.styleMirror.getId(e))
                      : ((t = r.styleMirror.add(e)),
                        o.push({
                          styleId: t,
                          rules: Array.from(e.rules || CSSRule, function (t, r) {
                            return { rule: en(t, e.href), index: r };
                          }),
                        })),
                      i.styleIds.push(t));
                  })());
              (o.length > 0 && (i.styles = o), this.adoptedStyleSheetCb(i));
            }
          }),
          (t.reset = function () {
            (this.styleMirror.reset(), (this.trackedLinkElements = new WeakSet()));
          }),
          (t.trackStylesheetInLinkElement = function (e) {}),
          e
        );
      })(),
      ih = (function () {
        function e() {
          (U(this, "nodeMap", new WeakMap()), U(this, "active", !1));
        }
        var t = e.prototype;
        return (
          (t.inOtherBuffer = function (e, t) {
            var r = this.nodeMap.get(e);
            return (
              r &&
              Array.from(r).some(function (e) {
                return e !== t;
              })
            );
          }),
          (t.add = function (e, t) {
            var r = this;
            (this.active ||
              ((this.active = !0),
              requestAnimationFrame(function () {
                ((r.nodeMap = new WeakMap()), (r.active = !1));
              })),
              this.nodeMap.set(e, (this.nodeMap.get(e) || new Set()).add(t)));
          }),
          (t.destroy = function () {}),
          e
        );
      })(),
      id = !1;
    try {
      if (
        2 !==
        Array.from([1], function (e) {
          return 2 * e;
        })[0]
      ) {
        var ig = document.createElement("iframe");
        (document.body.appendChild(ig),
          (Array.from = (null == (iA = ig.contentWindow) ? void 0 : iA.Array.from) || Array.from),
          document.body.removeChild(ig));
      }
    } catch (e) {
      console.debug("Unable to override Array.from", e);
    }
    var im = new ei();
    function i_(e) {
      void 0 === e && (e = {});
      var t = e.emit,
        r = e.checkoutEveryNms,
        n = e.checkoutEveryNth,
        i = e.blockClass,
        o = void 0 === i ? "rr-block" : i,
        s = e.blockSelector,
        a = void 0 === s ? null : s,
        c = e.ignoreClass,
        u = void 0 === c ? "rr-ignore" : c,
        l = e.ignoreSelector,
        p = void 0 === l ? null : l,
        h = e.maskTextClass,
        d = void 0 === h ? "rr-mask" : h,
        f = e.maskTextSelector,
        g = void 0 === f ? null : f,
        m = e.inlineStylesheet,
        _ = void 0 === m || m,
        v = e.maskAllInputs,
        y = e.maskInputOptions,
        b = e.slimDOMOptions,
        C = e.maskInputFn,
        E = e.maskTextFn,
        w = e.hooks,
        I = e.packFn,
        k = e.sampling,
        O = void 0 === k ? {} : k,
        A = e.dataURLOptions,
        R = void 0 === A ? {} : A,
        T = e.mousemoveWait,
        x = e.recordDOM,
        M = void 0 === x || x,
        L = e.recordCanvas,
        D = void 0 !== L && L,
        N = e.recordCrossOriginIframes,
        F = void 0 !== N && N,
        U = e.recordAfter,
        B = void 0 === U ? ("DOMContentLoaded" === e.recordAfter ? e.recordAfter : "load") : U,
        j = e.userTriggeredOnInput,
        V = void 0 !== j && j,
        G = e.collectFonts,
        W = void 0 !== G && G,
        z = e.inlineImages,
        K = void 0 !== z && z,
        q = e.plugins,
        Y = e.keepIframeSrcFn,
        $ =
          void 0 === Y
            ? function () {
                return !1;
              }
            : Y,
        H = e.ignoreCSSAttributes,
        Z = void 0 === H ? new Set([]) : H;
      iY = e.errorHandler;
      var J = !F || window.parent === window,
        X = !1;
      if (!J)
        try {
          window.parent.document && (X = !1);
        } catch (e) {
          X = !0;
        }
      if (J && !t) throw Error("emit function is required");
      if (!J && !X) return function () {};
      (void 0 !== T && void 0 === O.mousemove && (O.mousemove = T), im.reset());
      var Q =
          !0 === v
            ? {
                color: !0,
                date: !0,
                "datetime-local": !0,
                email: !0,
                month: !0,
                number: !0,
                range: !0,
                search: !0,
                tel: !0,
                text: !0,
                time: !0,
                url: !0,
                week: !0,
                textarea: !0,
                select: !0,
                password: !0,
              }
            : void 0 !== y
              ? y
              : { password: !0 },
        ee =
          !0 === b || "all" === b
            ? {
                script: !0,
                comment: !0,
                headFavicon: !0,
                headWhitespace: !0,
                headMetaSocial: !0,
                headMetaRobots: !0,
                headMetaHttpEquiv: !0,
                headMetaVerification: !0,
                headMetaAuthorship: "all" === b,
                headMetaDescKeywords: "all" === b,
                headTitleMutations: "all" === b,
              }
            : b || {};
      (void 0 === en && (en = window),
        "NodeList" in en &&
          !en.NodeList.prototype.forEach &&
          (en.NodeList.prototype.forEach = Array.prototype.forEach),
        "DOMTokenList" in en &&
          !en.DOMTokenList.prototype.forEach &&
          (en.DOMTokenList.prototype.forEach = Array.prototype.forEach));
      var et = 0,
        er = function (e) {
          for (var t, r = P(q || []); !(t = r()).done;) {
            var n = t.value;
            n.eventProcessor && (e = n.eventProcessor(e));
          }
          return (I && !X && (e = I(e)), e);
        };
      i$ = function (e, i) {
        var o;
        if (
          ((e.timestamp = n_()),
          (null == (o = nK[0]) ? void 0 : o.isFrozen()) &&
            e.type !== nx.FullSnapshot &&
            (e.type !== nx.IncrementalSnapshot || e.data.source !== nM.Mutation) &&
            nK.forEach(function (e) {
              return e.unfreeze();
            }),
          J)
        )
          null == t || t(er(e), i);
        else if (X) {
          var s = { type: "rrweb", event: er(e), origin: window.location.origin, isCheckout: i };
          window.parent.postMessage(s, "*");
        }
        if (e.type === nx.FullSnapshot) ((eo = e), (et = 0));
        else if (e.type === nx.IncrementalSnapshot) {
          if (e.data.source === nM.Mutation && e.data.isAttachIframe) return;
          et++;
          var a = n && et >= n,
            c = r && e.timestamp - eo.timestamp > r;
          (a || c) && iH(!0);
        }
      };
      for (
        var en,
          eo,
          es,
          ea = function (e) {
            i$({ type: nx.IncrementalSnapshot, data: S({ source: nM.Mutation }, e) });
          },
          ec = function (e) {
            return i$({ type: nx.IncrementalSnapshot, data: S({ source: nM.Scroll }, e) });
          },
          eu = function (e) {
            return i$({ type: nx.IncrementalSnapshot, data: S({ source: nM.CanvasMutation }, e) });
          },
          el = new ip({
            mutationCb: ea,
            adoptedStyleSheetCb: function (e) {
              return i$({ type: nx.IncrementalSnapshot, data: S({ source: nM.AdoptedStyleSheet }, e) });
            },
          }),
          ep = new n4({
            mirror: im,
            mutationCb: ea,
            stylesheetManager: el,
            recordCrossOriginIframes: F,
            wrappedEmit: i$,
          }),
          eh = P(q || []);
        !(es = eh()).done;
      ) {
        var ed = es.value;
        ed.getMirror &&
          ed.getMirror({
            nodeMirror: im,
            crossOriginIframeMirror: ep.crossOriginIframeMirror,
            crossOriginIframeStyleMirror: ep.crossOriginIframeStyleMirror,
          });
      }
      var ef = new ih();
      iZ = new il({
        recordCanvas: D,
        mutationCb: eu,
        win: window,
        blockClass: o,
        blockSelector: a,
        mirror: im,
        sampling: O.canvas,
        dataURLOptions: R,
      });
      var eg = new n5({
        mutationCb: ea,
        scrollCb: ec,
        bypassOptions: {
          blockClass: o,
          blockSelector: a,
          maskTextClass: d,
          maskTextSelector: g,
          inlineStylesheet: _,
          maskInputOptions: Q,
          dataURLOptions: R,
          maskTextFn: E,
          maskInputFn: C,
          recordCanvas: D,
          inlineImages: K,
          sampling: O,
          slimDOMOptions: ee,
          iframeManager: ep,
          stylesheetManager: el,
          canvasManager: iZ,
          keepIframeSrcFn: $,
          processedNodeManager: ef,
        },
        mirror: im,
      });
      iH = function (e) {
        if ((void 0 === e && (e = !1), M)) {
          (i$({ type: nx.Meta, data: { href: window.location.href, width: nb(), height: ny() } }, e),
            el.reset(),
            eg.init(),
            nK.forEach(function (e) {
              return e.lock();
            }));
          var t,
            r,
            n,
            i,
            s,
            c,
            u,
            l,
            p,
            h,
            f,
            m,
            v,
            y,
            b,
            w,
            I,
            S,
            k,
            O,
            A,
            T,
            x,
            L,
            P =
              ((t = document),
              (i =
                void 0 ===
                (n = (r = {
                  mirror: im,
                  blockClass: o,
                  blockSelector: a,
                  maskTextClass: d,
                  maskTextSelector: g,
                  inlineStylesheet: _,
                  maskAllInputs: Q,
                  maskTextFn: E,
                  maskInputFn: C,
                  slimDOM: ee,
                  dataURLOptions: R,
                  recordCanvas: D,
                  inlineImages: K,
                  onSerialize: function (e) {
                    (nS(e, im) && ep.addIframe(e),
                      nk(e, im) && el.trackLinkElement(e),
                      nO(e) && eg.addShadowRoot(np(e), document));
                  },
                  onIframeLoad: function (e, t) {
                    (ep.attachIframe(e, t), eg.observeAttachShadow(e));
                  },
                  onStylesheetLoad: function (e, t) {
                    el.attachLinkElement(e, t);
                  },
                  keepIframeSrcFn: $,
                }).mirror)
                  ? new ei()
                  : n),
              (s = r.blockClass),
              (c = r.blockSelector),
              (u = r.maskTextClass),
              (l = r.maskTextSelector),
              (p = r.inlineStylesheet),
              (h = r.inlineImages),
              (f = r.recordCanvas),
              (v = void 0 !== (m = r.maskAllInputs) && m),
              (y = r.maskTextFn),
              (b = r.maskInputFn),
              (I = void 0 !== (w = r.slimDOM) && w),
              (S = r.dataURLOptions),
              (k = r.preserveWhiteSpace),
              (O = r.onSerialize),
              (A = r.onIframeLoad),
              (T = r.iframeLoadTimeout),
              (x = r.onStylesheetLoad),
              eR(t, {
                doc: t,
                mirror: i,
                blockClass: void 0 === s ? "rr-block" : s,
                blockSelector: void 0 === c ? null : c,
                maskTextClass: void 0 === u ? "rr-mask" : u,
                maskTextSelector: void 0 === l ? null : l,
                skipChild: !1,
                inlineStylesheet: void 0 === p || p,
                maskInputOptions:
                  !0 === v
                    ? {
                        color: !0,
                        date: !0,
                        "datetime-local": !0,
                        email: !0,
                        month: !0,
                        number: !0,
                        range: !0,
                        search: !0,
                        tel: !0,
                        text: !0,
                        time: !0,
                        url: !0,
                        week: !0,
                        textarea: !0,
                        select: !0,
                        password: !0,
                      }
                    : !1 === v
                      ? { password: !0 }
                      : v,
                maskTextFn: y,
                maskInputFn: b,
                slimDOMOptions:
                  !0 === I || "all" === I
                    ? {
                        script: !0,
                        comment: !0,
                        headFavicon: !0,
                        headWhitespace: !0,
                        headMetaDescKeywords: "all" === I,
                        headMetaSocial: !0,
                        headMetaRobots: !0,
                        headMetaHttpEquiv: !0,
                        headMetaAuthorship: !0,
                        headMetaVerification: !0,
                      }
                    : !1 === I
                      ? {}
                      : I,
                dataURLOptions: S,
                inlineImages: void 0 !== h && h,
                recordCanvas: void 0 !== f && f,
                preserveWhiteSpace: k,
                onSerialize: O,
                onIframeLoad: A,
                iframeLoadTimeout: T,
                onStylesheetLoad: x,
                stylesheetLoadTimeout: r.stylesheetLoadTimeout,
                keepIframeSrcFn:
                  void 0 === (L = r.keepIframeSrcFn)
                    ? function () {
                        return !1;
                      }
                    : L,
                newlyAddedElement: !1,
              }));
          if (!P) return console.warn("Failed to snapshot the document");
          (i$({ type: nx.FullSnapshot, data: { node: P, initialOffset: nv(window) } }, e),
            nK.forEach(function (e) {
              return e.unlock();
            }),
            document.adoptedStyleSheets &&
              document.adoptedStyleSheets.length > 0 &&
              el.adoptStyleSheets(document.adoptedStyleSheets, im.getId(document)));
        }
      };
      try {
        var em = [],
          e_ = function (e) {
            var t;
            return nz(n0)(
              {
                mutationCb: ea,
                mousemoveCb: function (e, t) {
                  return i$({ type: nx.IncrementalSnapshot, data: { source: t, positions: e } });
                },
                mouseInteractionCb: function (e) {
                  return i$({ type: nx.IncrementalSnapshot, data: S({ source: nM.MouseInteraction }, e) });
                },
                scrollCb: ec,
                viewportResizeCb: function (e) {
                  return i$({ type: nx.IncrementalSnapshot, data: S({ source: nM.ViewportResize }, e) });
                },
                inputCb: function (e) {
                  return i$({ type: nx.IncrementalSnapshot, data: S({ source: nM.Input }, e) });
                },
                mediaInteractionCb: function (e) {
                  return i$({ type: nx.IncrementalSnapshot, data: S({ source: nM.MediaInteraction }, e) });
                },
                styleSheetRuleCb: function (e) {
                  return i$({ type: nx.IncrementalSnapshot, data: S({ source: nM.StyleSheetRule }, e) });
                },
                styleDeclarationCb: function (e) {
                  return i$({ type: nx.IncrementalSnapshot, data: S({ source: nM.StyleDeclaration }, e) });
                },
                canvasMutationCb: eu,
                fontCb: function (e) {
                  return i$({ type: nx.IncrementalSnapshot, data: S({ source: nM.Font }, e) });
                },
                selectionCb: function (e) {
                  i$({ type: nx.IncrementalSnapshot, data: S({ source: nM.Selection }, e) });
                },
                customElementCb: function (e) {
                  i$({ type: nx.IncrementalSnapshot, data: S({ source: nM.CustomElement }, e) });
                },
                blockClass: o,
                ignoreClass: u,
                ignoreSelector: p,
                maskTextClass: d,
                maskTextSelector: g,
                maskInputOptions: Q,
                inlineStylesheet: _,
                sampling: O,
                recordDOM: M,
                recordCanvas: D,
                inlineImages: K,
                userTriggeredOnInput: V,
                collectFonts: W,
                doc: e,
                maskInputFn: C,
                maskTextFn: E,
                keepIframeSrcFn: $,
                blockSelector: a,
                slimDOMOptions: ee,
                dataURLOptions: R,
                mirror: im,
                iframeManager: ep,
                stylesheetManager: el,
                shadowDomManager: eg,
                processedNodeManager: ef,
                canvasManager: iZ,
                ignoreCSSAttributes: Z,
                plugins:
                  (null ==
                  (t =
                    null == q
                      ? void 0
                      : q.filter(function (e) {
                          return e.observer;
                        }))
                    ? void 0
                    : t.map(function (e) {
                        return {
                          observer: e.observer,
                          options: e.options,
                          callback: function (t) {
                            return i$({ type: nx.Plugin, data: { plugin: e.name, payload: t } });
                          },
                        };
                      })) || [],
              },
              w,
            );
          };
        ep.addLoadListener(function (e) {
          try {
            em.push(e_(e.contentDocument));
          } catch (e) {
            console.warn(e);
          }
        });
        var ev = function () {
          (iH(), em.push(e_(document)), (id = !0));
        };
        return (
          "interactive" === document.readyState || "complete" === document.readyState
            ? ev()
            : (em.push(
                nh("DOMContentLoaded", function () {
                  (i$({ type: nx.DomContentLoaded, data: {} }), "DOMContentLoaded" === B && ev());
                }),
              ),
              em.push(
                nh(
                  "load",
                  function () {
                    (i$({ type: nx.Load, data: {} }), "load" === B && ev());
                  },
                  window,
                ),
              )),
          function () {
            (em.forEach(function (e) {
              try {
                e();
              } catch (e) {
                String(e).toLowerCase().includes("cross-origin") || console.warn(e);
              }
            }),
              ef.destroy(),
              (id = !1),
              (iY = void 0));
          }
        );
      } catch (e) {
        console.warn(e);
      }
    }
    ((i_.addCustomEvent = function (e, t) {
      if (!id) throw Error("please add custom event after start recording");
      i$({ type: nx.Custom, data: { tag: e, payload: t } });
    }),
      (i_.freezePage = function () {
        nK.forEach(function (e) {
          return e.freeze();
        });
      }),
      (i_.takeFullSnapshot = function (e) {
        if (!id) throw Error("please take full snapshot after start recording");
        iH(e);
      }),
      (i_.mirror = im),
      ((ik = iJ || (iJ = {}))[(ik.NotStarted = 0)] = "NotStarted"),
      (ik[(ik.Running = 1)] = "Running"),
      (ik[(ik.Stopped = 2)] = "Stopped"),
      i_.addCustomEvent,
      i_.freezePage,
      i_.takeFullSnapshot);
    var iv,
      iy,
      ib,
      iC,
      iE,
      iw,
      iI,
      iS,
      ik,
      iO,
      iA,
      iR,
      iT,
      ix,
      iM,
      iL,
      iP,
      iD,
      iN,
      iF,
      iU,
      iB,
      ij,
      iV,
      iG,
      iW,
      iz,
      iK,
      iq,
      iY,
      i$,
      iH,
      iZ,
      iJ,
      iX,
      iQ,
      i0,
      i1 = iO.setImmediate,
      i2 = Object.prototype.toString,
      i3 =
        void 0 !== i1
          ? function (e) {
              return i1(e);
            }
          : setTimeout;
    try {
      (Object.defineProperty({}, "x", {}),
        (iX = function (e, t, r, n) {
          return Object.defineProperty(e, t, { value: r, writable: !0, configurable: !1 !== n });
        }));
    } catch (e) {
      iX = function (e, t, r) {
        return ((e[t] = r), e);
      };
    }
    function i4(e, t) {
      (i0.add(e, t), iQ || (iQ = i3(i0.drain)));
    }
    function i5(e) {
      var t,
        r = typeof e;
      return (
        null !== e && ("object" === r || "function" === r) && (t = e.then),
        "function" == typeof t && t
      );
    }
    function i9() {
      for (var e = 0; e < this.chain.length; e++)
        !(function (e, t, r) {
          var n, i;
          try {
            !1 === t
              ? r.reject(e.msg)
              : (n = !0 === t ? e.msg : t.call(void 0, e.msg)) === r.promise
                ? r.reject(TypeError("Promise-chain cycle"))
                : (i = i5(n))
                  ? i.call(n, r.resolve, r.reject)
                  : r.resolve(n);
          } catch (e) {
            r.reject(e);
          }
        })(this, 1 === this.state ? this.chain[e].success : this.chain[e].failure, this.chain[e]);
      this.chain.length = 0;
    }
    function i6(e) {
      var t,
        r = this;
      if (!r.triggered) {
        ((r.triggered = !0), r.def && (r = r.def));
        try {
          (t = i5(e))
            ? i4(function () {
                var n = new oe(r);
                try {
                  t.call(
                    e,
                    function () {
                      i6.apply(n, arguments);
                    },
                    function () {
                      i8.apply(n, arguments);
                    },
                  );
                } catch (e) {
                  i8.call(n, e);
                }
              })
            : ((r.msg = e), (r.state = 1), r.chain.length > 0 && i4(i9, r));
        } catch (e) {
          i8.call(new oe(r), e);
        }
      }
    }
    function i8(e) {
      var t = this;
      !t.triggered &&
        ((t.triggered = !0),
        t.def && (t = t.def),
        (t.msg = e),
        (t.state = 2),
        t.chain.length > 0 && i4(i9, t));
    }
    function i7(e, t, r, n) {
      for (var i = 0; i < t.length; i++)
        !(function (i) {
          e.resolve(t[i]).then(function (e) {
            r(i, e);
          }, n);
        })(i);
    }
    function oe(e) {
      ((this.def = e), (this.triggered = !1));
    }
    function ot(e) {
      ((this.promise = e), (this.state = 0), (this.triggered = !1), (this.chain = []), (this.msg = void 0));
    }
    function or(e) {
      if ("function" != typeof e) throw TypeError("Not a function");
      if (0 !== this.__NPO__) throw TypeError("Not a promise");
      this.__NPO__ = 1;
      var t = new ot(this);
      ((this.then = function (e, r) {
        var n = { success: "function" != typeof e || e, failure: "function" == typeof r && r };
        return (
          (n.promise = new this.constructor(function (e, t) {
            if ("function" != typeof e || "function" != typeof t) throw TypeError("Not a function");
            ((n.resolve = e), (n.reject = t));
          })),
          t.chain.push(n),
          0 !== t.state && i4(i9, t),
          n.promise
        );
      }),
        (this.catch = function (e) {
          return this.then(void 0, e);
        }));
      try {
        e.call(
          void 0,
          function (e) {
            i6.call(t, e);
          },
          function (e) {
            i8.call(t, e);
          },
        );
      } catch (e) {
        i8.call(t, e);
      }
    }
    i0 = (function () {
      var e, t, r;
      function n(e, t) {
        ((this.fn = e), (this.self = t), (this.next = void 0));
      }
      return {
        add: function (i, o) {
          ((r = new n(i, o)), t ? (t.next = r) : (e = r), (t = r), (r = void 0));
        },
        drain: function () {
          var r = e;
          for (e = t = iQ = void 0; r;) (r.fn.call(r.self), (r = r.next));
        },
      };
    })();
    var on = iX({}, "constructor", or, !1);
    ((or.prototype = on),
      iX(on, "__NPO__", 0, !1),
      iX(or, "resolve", function (e) {
        return e && "object" == typeof e && 1 === e.__NPO__
          ? e
          : new this(function (t, r) {
              if ("function" != typeof t || "function" != typeof r) throw TypeError("Not a function");
              t(e);
            });
      }),
      iX(or, "reject", function (e) {
        return new this(function (t, r) {
          if ("function" != typeof t || "function" != typeof r) throw TypeError("Not a function");
          r(e);
        });
      }),
      iX(or, "all", function (e) {
        var t = this;
        return "[object Array]" !== i2.call(e)
          ? t.reject(TypeError("Not an array"))
          : 0 === e.length
            ? t.resolve([])
            : new t(function (r, n) {
                if ("function" != typeof r || "function" != typeof n) throw TypeError("Not a function");
                var i = e.length,
                  o = Array(i),
                  s = 0;
                i7(
                  t,
                  e,
                  function (e, t) {
                    ((o[e] = t), ++s === i && r(o));
                  },
                  n,
                );
              });
      }),
      iX(or, "race", function (e) {
        var t = this;
        return "[object Array]" !== i2.call(e)
          ? t.reject(TypeError("Not an array"))
          : new t(function (r, n) {
              if ("function" != typeof r || "function" != typeof n) throw TypeError("Not a function");
              i7(
                t,
                e,
                function (e, t) {
                  r(t);
                },
                n,
              );
            });
      }),
      (f = "u" > typeof Promise && -1 !== Promise.toString().indexOf("[native code]") ? Promise : or));
    var oi = { DEBUG: !1, LIB_VERSION: "2.70.0" },
      oo = Array.prototype,
      os = Function.prototype,
      oa = Object.prototype,
      oc = oo.slice,
      ou = oa.toString,
      ol = oa.hasOwnProperty,
      op = iO.console,
      oh = iO.navigator,
      od = iO.document,
      of = iO.opera,
      og = iO.screen,
      om = oh.userAgent,
      o_ = os.bind,
      ov = oo.forEach,
      oy = oo.indexOf,
      ob = oo.map,
      oC = Array.isArray,
      oE = {},
      ow = {
        trim: function (e) {
          return e.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
        },
      },
      oI = {
        log: function () {
          if (oi.DEBUG && !ow.isUndefined(op) && op)
            try {
              op.log.apply(op, arguments);
            } catch (e) {
              ow.each(arguments, function (e) {
                op.log(e);
              });
            }
        },
        warn: function () {
          if (oi.DEBUG && !ow.isUndefined(op) && op) {
            var e = ["Mixpanel warning:"].concat(ow.toArray(arguments));
            try {
              op.warn.apply(op, e);
            } catch (t) {
              ow.each(e, function (e) {
                op.warn(e);
              });
            }
          }
        },
        error: function () {
          if (oi.DEBUG && !ow.isUndefined(op) && op) {
            var e = ["Mixpanel error:"].concat(ow.toArray(arguments));
            try {
              op.error.apply(op, e);
            } catch (t) {
              ow.each(e, function (e) {
                op.error(e);
              });
            }
          }
        },
        critical: function () {
          if (!ow.isUndefined(op) && op) {
            var e = ["Mixpanel error:"].concat(ow.toArray(arguments));
            try {
              op.error.apply(op, e);
            } catch (t) {
              ow.each(e, function (e) {
                op.error(e);
              });
            }
          }
        },
      },
      oS = function (e, t) {
        return function () {
          return ((arguments[0] = "[" + t + "] " + arguments[0]), e.apply(oI, arguments));
        };
      },
      ok = function (e) {
        return { log: oS(oI.log, e), error: oS(oI.error, e), critical: oS(oI.critical, e) };
      },
      oO = function (e) {
        return function () {
          try {
            return e.apply(this, arguments);
          } catch (e) {
            (oI.critical("Implementation error. Please turn on debug and contact support@mixpanel.com."),
              oi.DEBUG && oI.critical(e));
          }
        };
      },
      oA = function (e) {
        var t = e.prototype;
        for (var r in t) "function" == typeof t[r] && (t[r] = oO(t[r]));
      };
    ((ow.bind = function (e, t) {
      var r, n;
      if (o_ && e.bind === o_) return o_.apply(e, oc.call(arguments, 1));
      if (!ow.isFunction(e)) throw TypeError();
      return (
        (r = oc.call(arguments, 2)),
        (n = function () {
          if (!(this instanceof n)) return e.apply(t, r.concat(oc.call(arguments)));
          var i = {};
          i.prototype = e.prototype;
          var o = new i();
          i.prototype = null;
          var s = e.apply(o, r.concat(oc.call(arguments)));
          return Object(s) === s ? s : o;
        })
      );
    }),
      (ow.each = function (e, t, r) {
        if (null != e) {
          if (ov && e.forEach === ov) e.forEach(t, r);
          else if (e.length === +e.length) {
            for (var n = 0, i = e.length; n < i; n++) if (n in e && t.call(r, e[n], n, e) === oE) return;
          } else for (var o in e) if (ol.call(e, o) && t.call(r, e[o], o, e) === oE) return;
        }
      }),
      (ow.extend = function (e) {
        return (
          ow.each(oc.call(arguments, 1), function (t) {
            for (var r in t) void 0 !== t[r] && (e[r] = t[r]);
          }),
          e
        );
      }),
      (ow.isArray =
        oC ||
        function (e) {
          return "[object Array]" === ou.call(e);
        }),
      (ow.isFunction = function (e) {
        try {
          return /^\s*\bfunction\b/.test(e);
        } catch (e) {
          return !1;
        }
      }),
      (ow.isArguments = function (e) {
        return !!(e && ol.call(e, "callee"));
      }),
      (ow.toArray = function (e) {
        return e
          ? e.toArray
            ? e.toArray()
            : ow.isArray(e) || ow.isArguments(e)
              ? oc.call(e)
              : ow.values(e)
          : [];
      }),
      (ow.map = function (e, t, r) {
        if (ob && e.map === ob) return e.map(t, r);
        var n = [];
        return (
          ow.each(e, function (e) {
            n.push(t.call(r, e));
          }),
          n
        );
      }),
      (ow.keys = function (e) {
        var t = [];
        return (
          null === e ||
            ow.each(e, function (e, r) {
              t[t.length] = r;
            }),
          t
        );
      }),
      (ow.values = function (e) {
        var t = [];
        return (
          null === e ||
            ow.each(e, function (e) {
              t[t.length] = e;
            }),
          t
        );
      }),
      (ow.include = function (e, t) {
        var r = !1;
        return null === e
          ? r
          : oy && e.indexOf === oy
            ? -1 != e.indexOf(t)
            : (ow.each(e, function (e) {
                if (r || (r = e === t)) return oE;
              }),
              r);
      }),
      (ow.includes = function (e, t) {
        return -1 !== e.indexOf(t);
      }),
      (ow.inherit = function (e, t) {
        return ((e.prototype = new t()), (e.prototype.constructor = e), (e.superclass = t.prototype), e);
      }),
      (ow.isObject = function (e) {
        return e === Object(e) && !ow.isArray(e);
      }),
      (ow.isEmptyObject = function (e) {
        if (ow.isObject(e)) {
          for (var t in e) if (ol.call(e, t)) return !1;
          return !0;
        }
        return !1;
      }),
      (ow.isUndefined = function (e) {
        return void 0 === e;
      }),
      (ow.isString = function (e) {
        return "[object String]" == ou.call(e);
      }),
      (ow.isDate = function (e) {
        return "[object Date]" == ou.call(e);
      }),
      (ow.isNumber = function (e) {
        return "[object Number]" == ou.call(e);
      }),
      (ow.isElement = function (e) {
        return !!(e && 1 === e.nodeType);
      }),
      (ow.encodeDates = function (e) {
        return (
          ow.each(e, function (t, r) {
            ow.isDate(t) ? (e[r] = ow.formatDate(t)) : ow.isObject(t) && (e[r] = ow.encodeDates(t));
          }),
          e
        );
      }),
      (ow.timestamp = function () {
        return (
          (Date.now =
            Date.now ||
            function () {
              return +new Date();
            }),
          Date.now()
        );
      }),
      (ow.formatDate = function (e) {
        function t(e) {
          return e < 10 ? "0" + e : e;
        }
        return (
          e.getUTCFullYear() +
          "-" +
          t(e.getUTCMonth() + 1) +
          "-" +
          t(e.getUTCDate()) +
          "T" +
          t(e.getUTCHours()) +
          ":" +
          t(e.getUTCMinutes()) +
          ":" +
          t(e.getUTCSeconds())
        );
      }),
      (ow.strip_empty_properties = function (e) {
        var t = {};
        return (
          ow.each(e, function (e, r) {
            ow.isString(e) && e.length > 0 && (t[r] = e);
          }),
          t
        );
      }),
      (ow.truncate = function (e, t) {
        var r;
        return (
          "string" == typeof e
            ? (r = e.slice(0, t))
            : ow.isArray(e)
              ? ((r = []),
                ow.each(e, function (e) {
                  r.push(ow.truncate(e, t));
                }))
              : ow.isObject(e)
                ? ((r = {}),
                  ow.each(e, function (e, n) {
                    r[n] = ow.truncate(e, t);
                  }))
                : (r = e),
          r
        );
      }),
      (ow.JSONEncode = function (e) {
        var t = function (e) {
            var t =
                /[\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
              r = { "\b": "\\b", "	": "\\t", "\n": "\\n", "\f": "\\f", "\r": "\\r", '"': '\\"', "\\": "\\\\" };
            return (
              (t.lastIndex = 0),
              t.test(e)
                ? '"' +
                  e.replace(t, function (e) {
                    var t = r[e];
                    return "string" == typeof t
                      ? t
                      : "\\u" + ("0000" + e.charCodeAt(0).toString(16)).slice(-4);
                  }) +
                  '"'
                : '"' + e + '"'
            );
          },
          r = function (e, n) {
            var i = "",
              o = 0,
              s = "",
              a = "",
              c = 0,
              u = i,
              l = [],
              p = n[e];
            switch (
              (p && "object" == typeof p && "function" == typeof p.toJSON && (p = p.toJSON(e)), typeof p)
            ) {
              case "string":
                return t(p);
              case "number":
                return isFinite(p) ? String(p) : "null";
              case "boolean":
              case "null":
                return String(p);
              case "object":
                if (!p) return "null";
                if (((i += "    "), (l = []), "[object Array]" === ou.apply(p))) {
                  for (c = p.length, o = 0; o < c; o += 1) l[o] = r(o, p) || "null";
                  return (
                    (a =
                      0 === l.length
                        ? "[]"
                        : i
                          ? "[\n" + i + l.join(",\n" + i) + "\n" + u + "]"
                          : "[" + l.join(",") + "]"),
                    (i = u),
                    a
                  );
                }
                for (s in p) ol.call(p, s) && (a = r(s, p)) && l.push(t(s) + (i ? ": " : ":") + a);
                return (
                  (a = 0 === l.length ? "{}" : i ? "{" + l.join(",") + u + "}" : "{" + l.join(",") + "}"),
                  (i = u),
                  a
                );
            }
          };
        return r("", { "": e });
      }),
      (o = { '"': '"', "\\": "\\", "/": "/", b: "\b", f: "\f", n: "\n", r: "\r", t: "	" }),
      (s = function (e) {
        var r = SyntaxError(e);
        throw ((r.at = t), (r.text = n), r);
      }),
      (a = function (e) {
        return (
          e && e !== r && s("Expected '" + e + "' instead of '" + r + "'"),
          (r = n.charAt(t)),
          (t += 1),
          r
        );
      }),
      (c = function () {
        var e,
          t = "";
        for ("-" === r && ((t = "-"), a("-")); r >= "0" && r <= "9";) ((t += r), a());
        if ("." === r) for (t += "."; a() && r >= "0" && r <= "9";) t += r;
        if ("e" === r || "E" === r)
          for (t += r, a(), ("-" === r || "+" === r) && ((t += r), a()); r >= "0" && r <= "9";)
            ((t += r), a());
        if (isFinite((e = +t))) return e;
        s("Bad number");
      }),
      (u = function () {
        var e,
          t,
          n,
          i = "";
        if ('"' === r)
          for (; a();) {
            if ('"' === r) return (a(), i);
            if ("\\" === r)
              if ((a(), "u" === r)) {
                for (t = 0, n = 0; t < 4 && isFinite((e = parseInt(a(), 16))); t += 1) n = 16 * n + e;
                i += String.fromCharCode(n);
              } else if ("string" == typeof o[r]) i += o[r];
              else break;
            else i += r;
          }
        s("Bad string");
      }),
      (l = function () {
        for (; r && r <= " ";) a();
      }),
      (p = function () {
        switch (r) {
          case "t":
            return (a("t"), a("r"), a("u"), a("e"), !0);
          case "f":
            return (a("f"), a("a"), a("l"), a("s"), a("e"), !1);
          case "n":
            return (a("n"), a("u"), a("l"), a("l"), null);
        }
        s('Unexpected "' + r + '"');
      }),
      (h = function () {
        var e = [];
        if ("[" === r) {
          if ((a("["), l(), "]" === r)) return (a("]"), e);
          for (; r;) {
            if ((e.push(i()), l(), "]" === r)) return (a("]"), e);
            (a(","), l());
          }
        }
        s("Bad array");
      }),
      (d = function () {
        var e,
          t = {};
        if ("{" === r) {
          if ((a("{"), l(), "}" === r)) return (a("}"), t);
          for (; r;) {
            if (
              ((e = u()),
              l(),
              a(":"),
              Object.hasOwnProperty.call(t, e) && s('Duplicate key "' + e + '"'),
              (t[e] = i()),
              l(),
              "}" === r)
            )
              return (a("}"), t);
            (a(","), l());
          }
        }
        s("Bad object");
      }),
      (i = function () {
        switch ((l(), r)) {
          case "{":
            return d();
          case "[":
            return h();
          case '"':
            return u();
          case "-":
            return c();
          default:
            return r >= "0" && r <= "9" ? c() : p();
        }
      }),
      (ow.JSONDecode = function (e) {
        var o;
        return ((n = e), (t = 0), (r = " "), (o = i()), l(), r && s("Syntax error"), o);
      }),
      (ow.base64Encode = function (e) {
        var t,
          r,
          n,
          i,
          o,
          s,
          a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
          c = 0,
          u = 0,
          l = "",
          p = [];
        if (!e) return e;
        e = ow.utf8Encode(e);
        do
          ((t = e.charCodeAt(c++)),
            (r = ((s = (t << 16) | (e.charCodeAt(c++) << 8) | e.charCodeAt(c++)) >> 18) & 63),
            (n = (s >> 12) & 63),
            (i = (s >> 6) & 63),
            (o = 63 & s),
            (p[u++] = a.charAt(r) + a.charAt(n) + a.charAt(i) + a.charAt(o)));
        while (c < e.length);
        switch (((l = p.join("")), e.length % 3)) {
          case 1:
            l = l.slice(0, -2) + "==";
            break;
          case 2:
            l = l.slice(0, -1) + "=";
        }
        return l;
      }),
      (ow.utf8Encode = function (e) {
        e = (e + "").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
        var t,
          r,
          n,
          i = "",
          o = 0;
        for (t = r = 0, o = e.length, n = 0; n < o; n++) {
          var s = e.charCodeAt(n),
            a = null;
          (s < 128
            ? r++
            : (a =
                s > 127 && s < 2048
                  ? String.fromCharCode((s >> 6) | 192, (63 & s) | 128)
                  : String.fromCharCode((s >> 12) | 224, ((s >> 6) & 63) | 128, (63 & s) | 128)),
            null !== a && (r > t && (i += e.substring(t, r)), (i += a), (t = r = n + 1)));
        }
        return (r > t && (i += e.substring(t, e.length)), i);
      }),
      (ow.UUID = function () {
        try {
          return iO.crypto.randomUUID();
        } catch (r) {
          for (var e = Array(36), t = 0; t < 36; t++) e[t] = Math.floor(16 * Math.random());
          return (
            (e[14] = 4),
            (e[19] = e[19] &= -5),
            (e[19] = e[19] |= 8),
            (e[8] = e[13] = e[18] = e[23] = "-"),
            ow
              .map(e, function (e) {
                return e.toString(16);
              })
              .join("")
          );
        }
      }));
    var oR = [
      "ahrefsbot",
      "ahrefssiteaudit",
      "amazonbot",
      "baiduspider",
      "bingbot",
      "bingpreview",
      "chrome-lighthouse",
      "facebookexternal",
      "petalbot",
      "pinterest",
      "screaming frog",
      "yahoo! slurp",
      "yandex",
      "adsbot-google",
      "apis-google",
      "duplexweb-google",
      "feedfetcher-google",
      "google favicon",
      "google web preview",
      "google-read-aloud",
      "googlebot",
      "googleweblight",
      "mediapartners-google",
      "storebot-google",
    ];
    ((ow.isBlockedUA = function (e) {
      var t;
      for (e = e.toLowerCase(), t = 0; t < oR.length; t++) if (-1 !== e.indexOf(oR[t])) return !0;
      return !1;
    }),
      (ow.HTTPBuildQuery = function (e, t) {
        var r,
          n,
          i = [];
        return (
          ow.isUndefined(t) && (t = "&"),
          ow.each(e, function (e, t) {
            ((r = encodeURIComponent(e.toString())),
              (n = encodeURIComponent(t)),
              (i[i.length] = n + "=" + r));
          }),
          i.join(t)
        );
      }),
      (ow.getQueryParam = function (e, t) {
        var r = RegExp("[\\?&]" + (t = t.replace(/[[]/g, "\\[").replace(/[\]]/g, "\\]")) + "=([^&#]*)").exec(
          e,
        );
        if (null === r || (r && "string" != typeof r[1] && r[1].length)) return "";
        var n = r[1];
        try {
          n = decodeURIComponent(n);
        } catch (e) {
          oI.error("Skipping decoding for malformed query param: " + n);
        }
        return n.replace(/\+/g, " ");
      }),
      (ow.cookie = {
        get: function (e) {
          for (var t = e + "=", r = od.cookie.split(";"), n = 0; n < r.length; n++) {
            for (var i = r[n]; " " == i.charAt(0);) i = i.substring(1, i.length);
            if (0 === i.indexOf(t)) return decodeURIComponent(i.substring(t.length, i.length));
          }
          return null;
        },
        parse: function (e) {
          var t;
          try {
            t = ow.JSONDecode(ow.cookie.get(e)) || {};
          } catch (e) {}
          return t;
        },
        set_seconds: function (e, t, r, n, i, o, s) {
          var a = "",
            c = "",
            u = "";
          if (s) a = "; domain=" + s;
          else if (n) {
            var l = oG(od.location.hostname);
            a = l ? "; domain=." + l : "";
          }
          if (r) {
            var p = new Date();
            (p.setTime(p.getTime() + 1e3 * r), (c = "; expires=" + p.toGMTString()));
          }
          (o && ((i = !0), (u = "; SameSite=None")),
            i && (u += "; secure"),
            (od.cookie = e + "=" + encodeURIComponent(t) + c + "; path=/" + a + u));
        },
        set: function (e, t, r, n, i, o, s) {
          var a = "",
            c = "",
            u = "";
          if (s) a = "; domain=" + s;
          else if (n) {
            var l = oG(od.location.hostname);
            a = l ? "; domain=." + l : "";
          }
          if (r) {
            var p = new Date();
            (p.setTime(p.getTime() + 24 * r * 36e5), (c = "; expires=" + p.toGMTString()));
          }
          (o && ((i = !0), (u = "; SameSite=None")), i && (u += "; secure"));
          var h = e + "=" + encodeURIComponent(t) + c + "; path=/" + a + u;
          return ((od.cookie = h), h);
        },
        remove: function (e, t, r) {
          ow.cookie.set(e, "", -1, t, !1, !1, r);
        },
      }));
    var oT = function (e) {
        var t = !0;
        try {
          var r = "__mplss_" + oB(8);
          (e.setItem(r, "xyz"), "xyz" !== e.getItem(r) && (t = !1), e.removeItem(r));
        } catch (e) {
          t = !1;
        }
        return t;
      },
      ox = null,
      oM = function (e, t) {
        return null === ox || t ? (ox = oT(e || iO.localStorage)) : ox;
      },
      oL = null;
    function oP(e, t, r) {
      var n = function (e) {
        oI.error(t + " error: " + e);
      };
      return {
        is_supported: function (n) {
          var i = r(e, n);
          return (i || oI.error(t + " unsupported"), i);
        },
        error: n,
        get: function (t) {
          try {
            return e.getItem(t);
          } catch (e) {
            n(e);
          }
          return null;
        },
        parse: function (t) {
          try {
            return ow.JSONDecode(e.getItem(t)) || {};
          } catch (e) {}
          return null;
        },
        set: function (t, r) {
          try {
            e.setItem(t, r);
          } catch (e) {
            n(e);
          }
        },
        remove: function (t) {
          try {
            e.removeItem(t);
          } catch (e) {
            n(e);
          }
        },
      };
    }
    ((ow.localStorage = oP(iO.localStorage, "localStorage", oM)),
      (ow.sessionStorage = oP(iO.sessionStorage, "sessionStorage", function (e, t) {
        return null === oL || t ? (oL = oT(e || iO.sessionStorage)) : oL;
      })),
      (ow.register_event = (function () {
        function e(t) {
          return (t && ((t.preventDefault = e.preventDefault), (t.stopPropagation = e.stopPropagation)), t);
        }
        return (
          (e.preventDefault = function () {
            this.returnValue = !1;
          }),
          (e.stopPropagation = function () {
            this.cancelBubble = !0;
          }),
          function (t, r, n, i, o) {
            if (!t) return void oI.error("No valid element provided to register_event");
            if (t.addEventListener && !i) t.addEventListener(r, n, !!o);
            else {
              var s,
                a,
                c,
                u = "on" + r,
                l = t[u];
              t[u] =
                ((s = t),
                (a = n),
                (c = l),
                function (t) {
                  if ((t = t || e(iO.event))) {
                    var r,
                      n,
                      i = !0;
                    return (
                      ow.isFunction(c) && (r = c(t)),
                      (n = a.call(s, t)),
                      (!1 === r || !1 === n) && (i = !1),
                      i
                    );
                  }
                });
            }
          }
        );
      })()));
    var oD = RegExp('^(\\w*)\\[(\\w+)([=~\\|\\^\\$\\*]?)=?"?([^\\]"]*)"?\\]$');
    ow.dom_query = (function () {
      function e(e) {
        return e.all ? e.all : e.getElementsByTagName("*");
      }
      var t = /[\t\r\n]/g;
      function r(r) {
        if (!od.getElementsByTagName) return [];
        var n = r.split(" "),
          i = [od];
        for (f = 0; f < n.length; f++) {
          if ((l = n[f].replace(/^\s+/, "").replace(/\s+$/, "")).indexOf("#") > -1) {
            b = (p = l.split("#"))[0];
            var o = p[1],
              s = od.getElementById(o);
            if (!s || (b && s.nodeName.toLowerCase() != b)) return [];
            i = [s];
            continue;
          }
          if (l.indexOf(".") > -1) {
            b = (p = l.split("."))[0];
            var a,
              c = p[1];
            for (b || (b = "*"), h = [], d = 0, g = 0; g < i.length; g++)
              for (_ = "*" == b ? e(i[g]) : i[g].getElementsByTagName(b), m = 0; m < _.length; m++)
                h[d++] = _[m];
            for (g = 0, i = [], v = 0; g < h.length; g++)
              h[g].className &&
                ow.isString(h[g].className) &&
                ((a = h[g]), (" " + a.className + " ").replace(t, " ").indexOf(" " + c + " ") >= 0) &&
                (i[v++] = h[g]);
            continue;
          }
          var u = l.match(oD);
          if (u) {
            var l,
              p,
              h,
              d,
              f,
              g,
              m,
              _,
              v,
              y,
              b = u[1],
              C = u[2],
              E = u[3],
              w = u[4];
            for (b || (b = "*"), h = [], d = 0, g = 0; g < i.length; g++)
              for (_ = "*" == b ? e(i[g]) : i[g].getElementsByTagName(b), m = 0; m < _.length; m++)
                h[d++] = _[m];
            switch (((i = []), (v = 0), E)) {
              case "=":
                y = function (e) {
                  return e.getAttribute(C) == w;
                };
                break;
              case "~":
                y = function (e) {
                  return e.getAttribute(C).match(RegExp("\\b" + w + "\\b"));
                };
                break;
              case "|":
                y = function (e) {
                  return e.getAttribute(C).match(RegExp("^" + w + "-?"));
                };
                break;
              case "^":
                y = function (e) {
                  return 0 === e.getAttribute(C).indexOf(w);
                };
                break;
              case "$":
                y = function (e) {
                  return e.getAttribute(C).lastIndexOf(w) == e.getAttribute(C).length - w.length;
                };
                break;
              case "*":
                y = function (e) {
                  return e.getAttribute(C).indexOf(w) > -1;
                };
                break;
              default:
                y = function (e) {
                  return e.getAttribute(C);
                };
            }
            for (g = 0, i = [], v = 0; g < h.length; g++) y(h[g]) && (i[v++] = h[g]);
            continue;
          }
          for (b = l, h = [], d = 0, g = 0; g < i.length; g++)
            for (_ = i[g].getElementsByTagName(b), m = 0; m < _.length; m++) h[d++] = _[m];
          i = h;
        }
        return i;
      }
      return function (e) {
        return ow.isElement(e) ? [e] : ow.isObject(e) && !ow.isUndefined(e.length) ? e : r.call(this, e);
      };
    })();
    var oN = [
        "utm_source",
        "utm_medium",
        "utm_campaign",
        "utm_content",
        "utm_term",
        "utm_id",
        "utm_source_platform",
        "utm_campaign_id",
        "utm_creative_format",
        "utm_marketing_tactic",
      ],
      oF = [
        "dclid",
        "fbclid",
        "gclid",
        "ko_click_id",
        "li_fat_id",
        "msclkid",
        "sccid",
        "ttclid",
        "twclid",
        "wbraid",
      ];
    ow.info = {
      campaignParams: function (e) {
        var t = "",
          r = {};
        return (
          ow.each(oN, function (n) {
            (t = ow.getQueryParam(od.URL, n)).length ? (r[n] = t) : void 0 !== e && (r[n] = e);
          }),
          r
        );
      },
      clickParams: function () {
        var e = "",
          t = {};
        return (
          ow.each(oF, function (r) {
            (e = ow.getQueryParam(od.URL, r)).length && (t[r] = e);
          }),
          t
        );
      },
      marketingParams: function () {
        return ow.extend(ow.info.campaignParams(), ow.info.clickParams());
      },
      searchEngine: function (e) {
        return 0 === e.search("https?://(.*)google.([^/?]*)")
          ? "google"
          : 0 === e.search("https?://(.*)bing.com")
            ? "bing"
            : 0 === e.search("https?://(.*)yahoo.com")
              ? "yahoo"
              : 0 === e.search("https?://(.*)duckduckgo.com")
                ? "duckduckgo"
                : null;
      },
      searchInfo: function (e) {
        var t = ow.info.searchEngine(e),
          r = {};
        if (null !== t) {
          r.$search_engine = t;
          var n = ow.getQueryParam(e, "yahoo" != t ? "q" : "p");
          n.length && (r.mp_keyword = n);
        }
        return r;
      },
      browser: function (e, t, r) {
        if (((t = t || ""), r || ow.includes(e, " OPR/")))
          return ow.includes(e, "Mini") ? "Opera Mini" : "Opera";
        if (/(BlackBerry|PlayBook|BB10)/i.test(e)) return "BlackBerry";
        if (ow.includes(e, "IEMobile") || ow.includes(e, "WPDesktop")) return "Internet Explorer Mobile";
        if (ow.includes(e, "SamsungBrowser/")) return "Samsung Internet";
        if (ow.includes(e, "Edge") || ow.includes(e, "Edg/")) return "Microsoft Edge";
        else if (ow.includes(e, "FBIOS")) return "Facebook Mobile";
        else if (ow.includes(e, "Whale/")) return "Whale Browser";
        else if (ow.includes(e, "Chrome")) return "Chrome";
        else if (ow.includes(e, "CriOS")) return "Chrome iOS";
        else if (ow.includes(e, "UCWEB") || ow.includes(e, "UCBrowser")) return "UC Browser";
        else if (ow.includes(e, "FxiOS")) return "Firefox iOS";
        else if (ow.includes(t, "Apple")) return ow.includes(e, "Mobile") ? "Mobile Safari" : "Safari";
        else if (ow.includes(e, "Android")) return "Android Mobile";
        else if (ow.includes(e, "Konqueror")) return "Konqueror";
        else if (ow.includes(e, "Firefox")) return "Firefox";
        else if (ow.includes(e, "MSIE") || ow.includes(e, "Trident/")) return "Internet Explorer";
        else if (ow.includes(e, "Gecko")) return "Mozilla";
        else return "";
      },
      browserVersion: function (e, t, r) {
        var n = {
          "Internet Explorer Mobile": /rv:(\d+(\.\d+)?)/,
          "Microsoft Edge": /Edge?\/(\d+(\.\d+)?)/,
          Chrome: /Chrome\/(\d+(\.\d+)?)/,
          "Chrome iOS": /CriOS\/(\d+(\.\d+)?)/,
          "UC Browser": /(UCBrowser|UCWEB)\/(\d+(\.\d+)?)/,
          Safari: /Version\/(\d+(\.\d+)?)/,
          "Mobile Safari": /Version\/(\d+(\.\d+)?)/,
          Opera: /(Opera|OPR)\/(\d+(\.\d+)?)/,
          Firefox: /Firefox\/(\d+(\.\d+)?)/,
          "Firefox iOS": /FxiOS\/(\d+(\.\d+)?)/,
          Konqueror: /Konqueror:(\d+(\.\d+)?)/,
          BlackBerry: /BlackBerry (\d+(\.\d+)?)/,
          "Android Mobile": /android\s(\d+(\.\d+)?)/,
          "Samsung Internet": /SamsungBrowser\/(\d+(\.\d+)?)/,
          "Internet Explorer": /(rv:|MSIE )(\d+(\.\d+)?)/,
          Mozilla: /rv:(\d+(\.\d+)?)/,
          "Whale Browser": /Whale\/(\d+(\.\d+)?)/,
        }[ow.info.browser(e, t, r)];
        if (void 0 === n) return null;
        var i = e.match(n);
        return i ? parseFloat(i[i.length - 2]) : null;
      },
      os: function () {
        if (/Windows/i.test(om))
          return /Phone/.test(om) || /WPDesktop/.test(om) ? "Windows Phone" : "Windows";
        if (/(iPhone|iPad|iPod)/.test(om)) return "iOS";
        if (/Android/.test(om)) return "Android";
        if (/(BlackBerry|PlayBook|BB10)/i.test(om)) return "BlackBerry";
        if (/Mac/i.test(om)) return "Mac OS X";
        else if (/Linux/.test(om)) return "Linux";
        else if (/CrOS/.test(om)) return "Chrome OS";
        else return "";
      },
      device: function (e) {
        if (/Windows Phone/i.test(e) || /WPDesktop/.test(e)) return "Windows Phone";
        if (/iPad/.test(e)) return "iPad";
        if (/iPod/.test(e)) return "iPod Touch";
        if (/iPhone/.test(e)) return "iPhone";
        if (/(BlackBerry|PlayBook|BB10)/i.test(e)) return "BlackBerry";
        else if (/Android/.test(e)) return "Android";
        else return "";
      },
      referringDomain: function (e) {
        var t = e.split("/");
        return t.length >= 3 ? t[2] : "";
      },
      currentUrl: function () {
        return iO.location.href;
      },
      properties: function (e) {
        return (
          "object" != typeof e && (e = {}),
          ow.extend(
            ow.strip_empty_properties({
              $os: ow.info.os(),
              $browser: ow.info.browser(om, oh.vendor, of),
              $referrer: od.referrer,
              $referring_domain: ow.info.referringDomain(od.referrer),
              $device: ow.info.device(om),
            }),
            {
              $current_url: ow.info.currentUrl(),
              $browser_version: ow.info.browserVersion(om, oh.vendor, of),
              $screen_height: og.height,
              $screen_width: og.width,
              mp_lib: "web",
              $lib_version: oi.LIB_VERSION,
              $insert_id: oB(),
              time: ow.timestamp() / 1e3,
            },
            ow.strip_empty_properties(e),
          )
        );
      },
      people_properties: function () {
        return ow.extend(
          ow.strip_empty_properties({ $os: ow.info.os(), $browser: ow.info.browser(om, oh.vendor, of) }),
          { $browser_version: ow.info.browserVersion(om, oh.vendor, of) },
        );
      },
      mpPageViewProperties: function () {
        return ow.strip_empty_properties({
          current_page_title: od.title,
          current_domain: iO.location.hostname,
          current_url_path: iO.location.pathname,
          current_url_protocol: iO.location.protocol,
          current_url_search: iO.location.search,
        });
      },
    };
    var oU = function (e, t) {
        var r = null,
          n = [];
        return function (i) {
          var o = this;
          return (
            n.push(i),
            r ||
              (r = new f(function (i) {
                setTimeout(function () {
                  var t = e.apply(o, [n]);
                  ((r = null), (n = []), i(t));
                }, t);
              })),
            r
          );
        };
      },
      oB = function (e) {
        var t = Math.random().toString(36).substring(2, 10) + Math.random().toString(36).substring(2, 10);
        return e ? t.substring(0, e) : t;
      },
      oj = /[a-z0-9][a-z0-9-]*\.[a-z]+$/i,
      oV = /[a-z0-9][a-z0-9-]+\.[a-z.]{2,6}$/i,
      oG = function (e) {
        var t = oV,
          r = e.split("."),
          n = r[r.length - 1];
        (n.length > 4 || "com" === n || "org" === n) && (t = oj);
        var i = e.match(t);
        return i ? i[0] : "";
      },
      oW = function () {
        var e = iO.navigator.onLine;
        return ow.isUndefined(e) || e;
      },
      oz = function () {},
      oK = null,
      oq = null;
    ("u" > typeof JSON && ((oK = JSON.stringify), (oq = JSON.parse)),
      (oK = oK || ow.JSONEncode),
      (oq = oq || ow.JSONDecode),
      (ow.info = ow.info),
      (ow.info.browser = ow.info.browser),
      (ow.info.browserVersion = ow.info.browserVersion),
      (ow.info.device = ow.info.device),
      (ow.info.properties = ow.info.properties),
      (ow.isBlockedUA = ow.isBlockedUA),
      (ow.isEmptyObject = ow.isEmptyObject),
      (ow.isObject = ow.isObject),
      (ow.JSONDecode = ow.JSONDecode),
      (ow.JSONEncode = ow.JSONEncode),
      (ow.toArray = ow.toArray),
      (ow.NPO = or));
    var oY = "mixpanelRecordingEvents",
      o$ = "mixpanelRecordingRegistry",
      oH = [oY, o$],
      oZ = function (e) {
        ((this.dbPromise = null), (this.storeName = e));
      };
    function oJ(e, t) {
      o8(!0, e, t);
    }
    function oX(e, t) {
      o8(!1, e, t);
    }
    function oQ(e, t) {
      return "1" === o6(e, t);
    }
    function o0(e, t) {
      if (
        (function (e) {
          if (e && e.ignoreDnt) return !1;
          var t = (e && e.window) || iO,
            r = t.navigator || {},
            n = !1;
          return (
            ow.each([r.doNotTrack, r.msDoNotTrack, t.doNotTrack], function (e) {
              ow.includes([!0, 1, "1", "yes"], e) && (n = !0);
            }),
            n
          );
        })(t)
      )
        return (
          oI.warn(
            'This browser has "Do Not Track" enabled. This will prevent the Mixpanel SDK from sending any data. To ignore the "Do Not Track" browser setting, initialize the Mixpanel instance with the config "ignore_dnt: true"',
          ),
          !0
        );
      var r = "0" === o6(e, t);
      return (
        r &&
          oI.warn(
            "You are opted out of Mixpanel tracking. This will prevent the Mixpanel SDK from sending any data.",
          ),
        r
      );
    }
    function o1(e) {
      return o7(e, function (e) {
        return this.get_config(e);
      });
    }
    function o2(e) {
      return o7(e, function (e) {
        return this._get_config(e);
      });
    }
    function o3(e) {
      return o7(e, function (e) {
        return this._get_config(e);
      });
    }
    function o4(e, t) {
      o5((t = t || {})).remove(o9(e, t), !!t.crossSubdomainCookie, t.cookieDomain);
    }
    function o5(e) {
      return "localStorage" === (e = e || {}).persistenceType ? ow.localStorage : ow.cookie;
    }
    function o9(e, t) {
      return ((t = t || {}).persistencePrefix || "__mp_opt_in_out_") + e;
    }
    function o6(e, t) {
      return o5(t).get(o9(e, t));
    }
    function o8(e, t, r) {
      ow.isString(t) && t.length
        ? (o5((r = r || {})).set(
            o9(t, r),
            +!!e,
            ow.isNumber(r.cookieExpiration) ? r.cookieExpiration : null,
            !!r.crossSubdomainCookie,
            !!r.secureCookie,
            !!r.crossSiteCookie,
            r.cookieDomain,
          ),
          r.track && e && r.track(r.trackEventName || "$opt_in", r.trackProperties, { send_immediately: !0 }))
        : oI.error("gdpr." + (e ? "optIn" : "optOut") + " called with an invalid token");
    }
    function o7(e, t) {
      return function () {
        var r = !1;
        try {
          var n = t.call(this, "token"),
            i = t.call(this, "ignore_dnt"),
            o = t.call(this, "opt_out_tracking_persistence_type"),
            s = t.call(this, "opt_out_tracking_cookie_prefix"),
            a = t.call(this, "window");
          n && (r = o0(n, { ignoreDnt: i, persistenceType: o, persistencePrefix: s, window: a }));
        } catch (e) {
          oI.error("Unexpected error when checking tracking opt-out status: " + e);
        }
        if (!r) return e.apply(this, arguments);
        var c = arguments[arguments.length - 1];
        "function" == typeof c && c(0);
      };
    }
    ((oZ.prototype._openDb = function () {
      return new f(function (e, t) {
        var r = iO.indexedDB.open("mixpanelBrowserDb", 1);
        ((r.onerror = function () {
          t(r.error);
        }),
          (r.onsuccess = function () {
            e(r.result);
          }),
          (r.onupgradeneeded = function (e) {
            var t = e.target.result;
            oH.forEach(function (e) {
              t.createObjectStore(e);
            });
          }));
      });
    }),
      (oZ.prototype.init = function () {
        return iO.indexedDB
          ? (this.dbPromise || (this.dbPromise = this._openDb()),
            this.dbPromise.then(function (e) {
              return e instanceof iO.IDBDatabase ? f.resolve() : f.reject(e);
            }))
          : f.reject("indexedDB is not supported in this browser");
      }),
      (oZ.prototype.isInitialized = function () {
        return !!this.dbPromise;
      }),
      (oZ.prototype.makeTransaction = function (e, t) {
        var r = this.storeName,
          n = function (n) {
            return new f(function (i, o) {
              var s = n.transaction(r, e);
              ((s.oncomplete = function () {
                i(s);
              }),
                (s.onabort = s.onerror =
                  function () {
                    o(s.error);
                  }),
                t(s.objectStore(r)));
            });
          };
        return this.dbPromise.then(n).catch(
          function (e) {
            return e && "InvalidStateError" === e.name
              ? ((this.dbPromise = this._openDb()), this.dbPromise.then(n))
              : f.reject(e);
          }.bind(this),
        );
      }),
      (oZ.prototype.setItem = function (e, t) {
        return this.makeTransaction("readwrite", function (r) {
          r.put(t, e);
        });
      }),
      (oZ.prototype.getItem = function (e) {
        var t;
        return this.makeTransaction("readonly", function (r) {
          t = r.get(e);
        }).then(function () {
          return t.result;
        });
      }),
      (oZ.prototype.removeItem = function (e) {
        return this.makeTransaction("readwrite", function (t) {
          t.delete(e);
        });
      }),
      (oZ.prototype.getAll = function () {
        var e;
        return this.makeTransaction("readonly", function (t) {
          e = t.getAll();
        }).then(function () {
          return e.result;
        });
      }));
    var se = ok("lock"),
      st = function (e, t) {
        ((t = t || {}),
          (this.storageKey = e),
          (this.storage = t.storage || iO.localStorage),
          (this.pollIntervalMS = t.pollIntervalMS || 100),
          (this.timeoutMS = t.timeoutMS || 2e3),
          (this.promiseImpl = t.promiseImpl || f));
      };
    st.prototype.withLock = function (e, t) {
      return new this.promiseImpl(
        ow.bind(function (r, n) {
          var i = t || new Date().getTime() + "|" + Math.random(),
            o = new Date().getTime(),
            s = this.storageKey,
            a = this.pollIntervalMS,
            c = this.timeoutMS,
            u = this.storage,
            l = s + ":X",
            p = s + ":Y",
            h = s + ":Z",
            d = function (e) {
              if (new Date().getTime() - o > c) {
                (se.error("Timeout waiting for mutex on " + s + "; clearing lock. [" + i + "]"),
                  u.removeItem(h),
                  u.removeItem(p),
                  m());
                return;
              }
              setTimeout(
                function () {
                  try {
                    e();
                  } catch (e) {
                    n(e);
                  }
                },
                a * (Math.random() + 0.1),
              );
            },
            f = function (e, t) {
              e()
                ? t()
                : d(function () {
                    f(e, t);
                  });
            },
            g = function () {
              var e = u.getItem(p);
              return (
                (!e || e === i) &&
                (u.setItem(p, i),
                u.getItem(p) === i ||
                  (oM(u, !0) || n(Error("localStorage support dropped while acquiring lock")), !1))
              );
            },
            m = function () {
              (u.setItem(l, i),
                f(g, function () {
                  u.getItem(l) === i
                    ? _()
                    : d(function () {
                        u.getItem(p) !== i
                          ? m()
                          : f(function () {
                              return !u.getItem(h);
                            }, _);
                      });
                }));
            },
            _ = function () {
              u.setItem(h, "1");
              var t = function () {
                (u.removeItem(h),
                  u.getItem(p) === i && u.removeItem(p),
                  u.getItem(l) === i && u.removeItem(l));
              };
              e()
                .then(function (e) {
                  (t(), r(e));
                })
                .catch(function (e) {
                  (t(), n(e));
                });
            };
          try {
            if (oM(u, !0)) m();
            else throw Error("localStorage support check failed");
          } catch (e) {
            n(e);
          }
        }, this),
      );
    };
    var sr = function (e) {
      this.storage = e || iO.localStorage;
    };
    ((sr.prototype.init = function () {
      return f.resolve();
    }),
      (sr.prototype.isInitialized = function () {
        return !0;
      }),
      (sr.prototype.setItem = function (e, t) {
        return new f(
          ow.bind(function (r, n) {
            try {
              this.storage.setItem(e, oK(t));
            } catch (e) {
              n(e);
            }
            r();
          }, this),
        );
      }),
      (sr.prototype.getItem = function (e) {
        return new f(
          ow.bind(function (t, r) {
            var n;
            try {
              n = oq(this.storage.getItem(e));
            } catch (e) {
              r(e);
            }
            t(n);
          }, this),
        );
      }),
      (sr.prototype.removeItem = function (e) {
        return new f(
          ow.bind(function (t, r) {
            try {
              this.storage.removeItem(e);
            } catch (e) {
              r(e);
            }
            t();
          }, this),
        );
      }));
    var sn = ok("batch"),
      si = function (e, t) {
        ((t = t || {}),
          (this.storageKey = e),
          (this.usePersistence = t.usePersistence),
          this.usePersistence &&
            ((this.queueStorage = t.queueStorage || new sr()),
            (this.lock = new st(e, {
              storage: t.sharedLockStorage || iO.localStorage,
              timeoutMS: t.sharedLockTimeoutMS,
            }))),
          (this.reportError = t.errorReporter || ow.bind(sn.error, sn)),
          (this.pid = t.pid || null),
          (this.memQueue = []),
          (this.initialized = !1),
          t.enqueueThrottleMs
            ? (this.enqueuePersisted = oU(ow.bind(this._enqueuePersisted, this), t.enqueueThrottleMs))
            : (this.enqueuePersisted = ow.bind(function (e) {
                return this._enqueuePersisted([e]);
              }, this)));
      };
    ((si.prototype.ensureInit = function () {
      return this.initialized || !this.usePersistence
        ? f.resolve()
        : this.queueStorage
            .init()
            .then(
              ow.bind(function () {
                this.initialized = !0;
              }, this),
            )
            .catch(
              ow.bind(function (e) {
                (this.reportError("Error initializing queue persistence. Disabling persistence", e),
                  (this.initialized = !0),
                  (this.usePersistence = !1));
              }, this),
            );
    }),
      (si.prototype.enqueue = function (e, t) {
        var r = { id: oB(), flushAfter: new Date().getTime() + 2 * t, payload: e };
        return this.usePersistence ? this.enqueuePersisted(r) : (this.memQueue.push(r), f.resolve(!0));
      }),
      (si.prototype._enqueuePersisted = function (e) {
        var t = ow.bind(function () {
          return this.ensureInit()
            .then(
              ow.bind(function () {
                return this.readFromStorage();
              }, this),
            )
            .then(
              ow.bind(function (t) {
                return this.saveToStorage(t.concat(e));
              }, this),
            )
            .then(
              ow.bind(function (t) {
                return (t && (this.memQueue = this.memQueue.concat(e)), t);
              }, this),
            )
            .catch(
              ow.bind(function (t) {
                return (this.reportError("Error enqueueing items", t, e), !1);
              }, this),
            );
        }, this);
        return this.lock.withLock(t, this.pid).catch(
          ow.bind(function (e) {
            return (this.reportError("Error acquiring storage lock", e), !1);
          }, this),
        );
      }),
      (si.prototype.fillBatch = function (e) {
        var t = this.memQueue.slice(0, e);
        return this.usePersistence && t.length < e
          ? this.ensureInit()
              .then(
                ow.bind(function () {
                  return this.readFromStorage();
                }, this),
              )
              .then(
                ow.bind(function (r) {
                  if (r.length) {
                    var n = {};
                    ow.each(t, function (e) {
                      n[e.id] = !0;
                    });
                    for (var i = 0; i < r.length; i++) {
                      var o = r[i];
                      if (
                        new Date().getTime() > o.flushAfter &&
                        !n[o.id] &&
                        ((o.orphaned = !0), t.push(o), t.length >= e)
                      )
                        break;
                    }
                  }
                  return t;
                }, this),
              )
          : f.resolve(t);
      }));
    var so = function (e, t) {
      var r = [];
      return (
        ow.each(e, function (e) {
          e.id && !t[e.id] && r.push(e);
        }),
        r
      );
    };
    si.prototype.removeItemsByID = function (e) {
      var t = {};
      if (
        (ow.each(e, function (e) {
          t[e] = !0;
        }),
        (this.memQueue = so(this.memQueue, t)),
        !this.usePersistence)
      )
        return f.resolve(!0);
      var r = ow.bind(function () {
        return this.ensureInit()
          .then(
            ow.bind(function () {
              return this.readFromStorage();
            }, this),
          )
          .then(
            ow.bind(function (e) {
              return ((e = so(e, t)), this.saveToStorage(e));
            }, this),
          )
          .then(
            ow.bind(function () {
              return this.readFromStorage();
            }, this),
          )
          .then(
            ow.bind(function (e) {
              for (var r = 0; r < e.length; r++) {
                var n = e[r];
                if (n.id && t[n.id]) throw Error("Item not removed from storage");
              }
              return !0;
            }, this),
          )
          .catch(
            ow.bind(function (t) {
              return (this.reportError("Error removing items", t, e), !1);
            }, this),
          );
      }, this);
      return this.lock.withLock(r, this.pid).catch(
        ow.bind(function (e) {
          return (
            this.reportError("Error acquiring storage lock", e),
            !oM(this.lock.storage, !0) &&
              r()
                .then(
                  ow.bind(function (e) {
                    return (
                      e ||
                      this.queueStorage.removeItem(this.storageKey).then(function () {
                        return e;
                      })
                    );
                  }, this),
                )
                .catch(
                  ow.bind(function (e) {
                    return (this.reportError("Error clearing queue", e), !1);
                  }, this),
                )
          );
        }, this),
      );
    };
    var ss = function (e, t) {
      var r = [];
      return (
        ow.each(e, function (e) {
          var n = e.id;
          if (n in t) {
            var i = t[n];
            null !== i && ((e.payload = i), r.push(e));
          } else r.push(e);
        }),
        r
      );
    };
    ((si.prototype.updatePayloads = function (e) {
      return ((this.memQueue = ss(this.memQueue, e)), this.usePersistence)
        ? this.lock
            .withLock(
              ow.bind(function () {
                return this.ensureInit()
                  .then(
                    ow.bind(function () {
                      return this.readFromStorage();
                    }, this),
                  )
                  .then(
                    ow.bind(function (t) {
                      return ((t = ss(t, e)), this.saveToStorage(t));
                    }, this),
                  )
                  .catch(
                    ow.bind(function (t) {
                      return (this.reportError("Error updating items", e, t), !1);
                    }, this),
                  );
              }, this),
              this.pid,
            )
            .catch(
              ow.bind(function (e) {
                return (this.reportError("Error acquiring storage lock", e), !1);
              }, this),
            )
        : f.resolve(!0);
    }),
      (si.prototype.readFromStorage = function () {
        return this.ensureInit()
          .then(
            ow.bind(function () {
              return this.queueStorage.getItem(this.storageKey);
            }, this),
          )
          .then(
            ow.bind(function (e) {
              return (
                e && !ow.isArray(e) && (this.reportError("Invalid storage entry:", e), (e = null)),
                e || []
              );
            }, this),
          )
          .catch(
            ow.bind(function (e) {
              return (this.reportError("Error retrieving queue", e), []);
            }, this),
          );
      }),
      (si.prototype.saveToStorage = function (e) {
        return this.ensureInit()
          .then(
            ow.bind(function () {
              return this.queueStorage.setItem(this.storageKey, e);
            }, this),
          )
          .then(function () {
            return !0;
          })
          .catch(
            ow.bind(function (e) {
              return (this.reportError("Error saving queue", e), !1);
            }, this),
          );
      }),
      (si.prototype.clear = function () {
        return ((this.memQueue = []), this.usePersistence)
          ? this.ensureInit().then(
              ow.bind(function () {
                return this.queueStorage.removeItem(this.storageKey);
              }, this),
            )
          : f.resolve();
      }));
    var sa = ok("batch"),
      sc = function (e, t) {
        ((this.errorReporter = t.errorReporter),
          (this.queue = new si(e, {
            errorReporter: ow.bind(this.reportError, this),
            queueStorage: t.queueStorage,
            sharedLockStorage: t.sharedLockStorage,
            sharedLockTimeoutMS: t.sharedLockTimeoutMS,
            usePersistence: t.usePersistence,
            enqueueThrottleMs: t.enqueueThrottleMs,
          })),
          (this.libConfig = t.libConfig),
          (this.sendRequest = t.sendRequestFunc),
          (this.beforeSendHook = t.beforeSendHook),
          (this.stopAllBatching = t.stopAllBatchingFunc),
          (this.batchSize = this.libConfig.batch_size),
          (this.flushInterval = this.libConfig.batch_flush_interval_ms),
          (this.stopped = !this.libConfig.batch_autostart),
          (this.consecutiveRemovalFailures = 0),
          (this.itemIdsSentSuccessfully = {}),
          (this.flushOnlyOnInterval = t.flushOnlyOnInterval || !1),
          (this._flushPromise = null));
      };
    ((sc.prototype.enqueue = function (e) {
      return this.queue.enqueue(e, this.flushInterval);
    }),
      (sc.prototype.start = function () {
        return ((this.stopped = !1), (this.consecutiveRemovalFailures = 0), this.flush());
      }),
      (sc.prototype.stop = function () {
        ((this.stopped = !0), this.timeoutID && (clearTimeout(this.timeoutID), (this.timeoutID = null)));
      }),
      (sc.prototype.clear = function () {
        return this.queue.clear();
      }),
      (sc.prototype.resetBatchSize = function () {
        this.batchSize = this.libConfig.batch_size;
      }),
      (sc.prototype.resetFlush = function () {
        this.scheduleFlush(this.libConfig.batch_flush_interval_ms);
      }),
      (sc.prototype.scheduleFlush = function (e) {
        ((this.flushInterval = e),
          this.stopped ||
            (this.timeoutID = setTimeout(
              ow.bind(function () {
                this.stopped || (this._flushPromise = this.flush());
              }, this),
              this.flushInterval,
            )));
      }),
      (sc.prototype.sendRequestPromise = function (e, t) {
        return new f(
          ow.bind(function (r) {
            this.sendRequest(e, t, r);
          }, this),
        );
      }),
      (sc.prototype.flush = function (e) {
        if (this.requestInProgress) return (sa.log("Flush: Request already in progress"), f.resolve());
        ((this.requestInProgress = !0), (e = e || {}));
        var t = this.libConfig.batch_request_timeout_ms,
          r = new Date().getTime(),
          n = this.batchSize;
        return this.queue
          .fillBatch(n)
          .then(
            ow.bind(function (i) {
              var o = i.length === n,
                s = [],
                a = {};
              if (
                (ow.each(
                  i,
                  function (e) {
                    var t = e.payload;
                    if ((this.beforeSendHook && !e.orphaned && (t = this.beforeSendHook(t)), t)) {
                      t.event &&
                        t.properties &&
                        (t.properties = ow.extend({}, t.properties, {
                          mp_sent_by_lib_version: oi.LIB_VERSION,
                        }));
                      var r = !0,
                        n = e.id;
                      (n
                        ? (this.itemIdsSentSuccessfully[n] || 0) > 5 &&
                          (this.reportError("[dupe] item ID sent too many times, not sending", {
                            item: e,
                            batchSize: i.length,
                            timesSent: this.itemIdsSentSuccessfully[n],
                          }),
                          (r = !1))
                        : this.reportError("[dupe] found item with no ID", { item: e }),
                        r && s.push(t));
                    }
                    a[e.id] = t;
                  },
                  this,
                ),
                s.length < 1)
              )
                return ((this.requestInProgress = !1), this.resetFlush(), f.resolve());
              var c = ow.bind(function () {
                  return this.queue
                    .removeItemsByID(
                      ow.map(i, function (e) {
                        return e.id;
                      }),
                    )
                    .then(
                      ow.bind(function (e) {
                        return (ow.each(
                          i,
                          ow.bind(function (e) {
                            var t = e.id;
                            t
                              ? ((this.itemIdsSentSuccessfully[t] = this.itemIdsSentSuccessfully[t] || 0),
                                this.itemIdsSentSuccessfully[t]++,
                                this.itemIdsSentSuccessfully[t] > 5 &&
                                  this.reportError("[dupe] item ID sent too many times", {
                                    item: e,
                                    batchSize: i.length,
                                    timesSent: this.itemIdsSentSuccessfully[t],
                                  }))
                              : this.reportError("[dupe] found item with no ID while removing", { item: e });
                          }, this),
                        ),
                        e)
                          ? ((this.consecutiveRemovalFailures = 0), this.flushOnlyOnInterval && !o)
                            ? (this.resetFlush(), f.resolve())
                            : this.flush()
                          : (++this.consecutiveRemovalFailures > 5
                              ? (this.reportError("Too many queue failures; disabling batching system."),
                                this.stopAllBatching())
                              : this.resetFlush(),
                            f.resolve());
                      }, this),
                    );
                }, this),
                u = ow.bind(function (o) {
                  this.requestInProgress = !1;
                  try {
                    if (e.unloading) return this.queue.updatePayloads(a);
                    if (ow.isObject(o) && "timeout" === o.error && new Date().getTime() - r >= t)
                      return (this.reportError("Network timeout; retrying"), this.flush());
                    if (
                      ow.isObject(o) &&
                      (o.httpStatusCode >= 500 ||
                        429 === o.httpStatusCode ||
                        (o.httpStatusCode <= 0 && !oW()) ||
                        "timeout" === o.error)
                    ) {
                      var s = 2 * this.flushInterval;
                      return (
                        o.retryAfter && (s = 1e3 * parseInt(o.retryAfter, 10) || s),
                        (s = Math.min(6e5, s)),
                        this.reportError("Error; retry in " + s + " ms"),
                        this.scheduleFlush(s),
                        f.resolve()
                      );
                    } else {
                      if (!ow.isObject(o) || 413 !== o.httpStatusCode) return c();
                      if (!(i.length > 1))
                        return (
                          this.reportError("Single-event request too large; dropping", i),
                          this.resetBatchSize(),
                          c()
                        );
                      var u = Math.max(1, Math.floor(n / 2));
                      return (
                        (this.batchSize = Math.min(this.batchSize, u, i.length - 1)),
                        this.reportError("413 response; reducing batch size to " + this.batchSize),
                        this.resetFlush(),
                        f.resolve()
                      );
                    }
                  } catch (e) {
                    (this.reportError("Error handling API response", e), this.resetFlush());
                  }
                }, this),
                l = { method: "POST", verbose: !0, ignore_json_errors: !0, timeout_ms: t };
              return (
                e.unloading && (l.transport = "sendBeacon"),
                sa.log("MIXPANEL REQUEST:", s),
                this.sendRequestPromise(s, l).then(u)
              );
            }, this),
          )
          .catch(
            ow.bind(function (e) {
              (this.reportError("Error flushing request queue", e), this.resetFlush());
            }, this),
          );
      }),
      (sc.prototype.reportError = function (e, t) {
        if ((sa.error.apply(sa.error, arguments), this.errorReporter))
          try {
            (t instanceof Error || (t = Error(e)), this.errorReporter(e, t));
          } catch (e) {
            sa.error(e);
          }
      }));
    var su = function (e) {
        var t = Date.now();
        return !e || t > e.maxExpires || t > e.idleExpires;
      },
      sl = ok("recorder"),
      sp = iO.CompressionStream,
      sh = {
        batch_size: 1e3,
        batch_flush_interval_ms: 1e4,
        batch_request_timeout_ms: 9e4,
        batch_autostart: !0,
      },
      sd = new Set([
        nM.MouseMove,
        nM.MouseInteraction,
        nM.Scroll,
        nM.ViewportResize,
        nM.Input,
        nM.TouchMove,
        nM.MediaInteraction,
        nM.Drag,
        nM.Selection,
      ]),
      sf = function (e) {
        ((this._mixpanel = e.mixpanelInstance),
          (this._onIdleTimeout = e.onIdleTimeout || oz),
          (this._onMaxLengthReached = e.onMaxLengthReached || oz),
          (this._onBatchSent = e.onBatchSent || oz),
          (this._rrwebRecord = e.rrwebRecord || null),
          (this._stopRecording = null),
          (this.replayId = e.replayId),
          (this.batchStartUrl = e.batchStartUrl || null),
          (this.replayStartUrl = e.replayStartUrl || null),
          (this.idleExpires = e.idleExpires || null),
          (this.maxExpires = e.maxExpires || null),
          (this.replayStartTime = e.replayStartTime || null),
          (this.seqNo = e.seqNo || 0),
          (this.idleTimeoutId = null),
          (this.maxTimeoutId = null),
          (this.recordMaxMs = 864e5),
          (this.recordMinMs = 0));
        var t = oM(e.sharedLockStorage, !0) && !this.getConfig("disable_persistence");
        ((this.batcherKey =
          "__mprec_" + this.getConfig("name") + "_" + this.getConfig("token") + "_" + this.replayId),
          (this.queueStorage = new oZ(oY)),
          (this.batcher = new sc(this.batcherKey, {
            errorReporter: this.reportError.bind(this),
            flushOnlyOnInterval: !0,
            libConfig: sh,
            sendRequestFunc: this.flushEventsWithOptOut.bind(this),
            queueStorage: this.queueStorage,
            sharedLockStorage: e.sharedLockStorage,
            usePersistence: t,
            stopAllBatchingFunc: this.stopRecording.bind(this),
            enqueueThrottleMs: 250,
            sharedLockTimeoutMS: 1e4,
          })));
      };
    ((sf.prototype.getUserIdInfo = function () {
      if (this.finalFlushUserIdInfo) return this.finalFlushUserIdInfo;
      var e = { distinct_id: String(this._mixpanel.get_distinct_id()) },
        t = this._mixpanel.get_property("$device_id");
      t && (e.$device_id = t);
      var r = this._mixpanel.get_property("$user_id");
      return (r && (e.$user_id = r), e);
    }),
      (sf.prototype.unloadPersistedData = function () {
        return (
          this.batcher.stop(),
          this.batcher.flush().then(
            function () {
              return this.queueStorage.removeItem(this.batcherKey);
            }.bind(this),
          )
        );
      }),
      (sf.prototype.getConfig = function (e) {
        return this._mixpanel.get_config(e);
      }),
      (sf.prototype.get_config = function (e) {
        return this.getConfig(e);
      }),
      (sf.prototype.startRecording = function (e) {
        if (null === this._rrwebRecord) return void this.reportError("rrweb record function not provided. ");
        if (null !== this._stopRecording)
          return void sl.log("Recording already in progress, skipping startRecording.");
        ((this.recordMaxMs = this.getConfig("record_max_ms")),
          this.recordMaxMs > 864e5 &&
            ((this.recordMaxMs = 864e5),
            sl.critical("record_max_ms cannot be greater than 86400000ms. Capping value.")),
          this.maxExpires || (this.maxExpires = new Date().getTime() + this.recordMaxMs),
          (this.recordMinMs = this.getConfig("record_min_ms")),
          this.recordMinMs > 8e3 &&
            ((this.recordMinMs = 8e3),
            sl.critical("record_min_ms cannot be greater than 8000ms. Capping value.")),
          this.replayStartTime ||
            ((this.replayStartTime = new Date().getTime()),
            (this.batchStartUrl = ow.info.currentUrl()),
            (this.replayStartUrl = ow.info.currentUrl())),
          e || this.recordMinMs > 0 ? this.batcher.stop() : this.batcher.start());
        var t = function () {
          clearTimeout(this.idleTimeoutId);
          var e = this.getConfig("record_idle_timeout_ms");
          ((this.idleTimeoutId = setTimeout(this._onIdleTimeout, e)),
            (this.idleExpires = new Date().getTime() + e));
        }.bind(this);
        t();
        var r = this.getConfig("record_block_selector");
        ("" === r || null === r) && (r = void 0);
        try {
          this._stopRecording = this._rrwebRecord({
            emit: function (e) {
              this.idleExpires && this.idleExpires < e.timestamp
                ? this._onIdleTimeout()
                : (e.type === nx.IncrementalSnapshot &&
                    sd.has(e.data.source) &&
                    (this.batcher.stopped &&
                      new Date().getTime() - this.replayStartTime >= this.recordMinMs &&
                      this.batcher.start(),
                    t()),
                  (this.__enqueuePromise = this.batcher.enqueue(e)));
            }.bind(this),
            blockClass: this.getConfig("record_block_class"),
            blockSelector: r,
            collectFonts: this.getConfig("record_collect_fonts"),
            dataURLOptions: { type: "image/webp", quality: 0.6 },
            maskAllInputs: !0,
            maskTextClass: this.getConfig("record_mask_text_class"),
            maskTextSelector: this.getConfig("record_mask_text_selector"),
            recordCanvas: this.getConfig("record_canvas"),
            sampling: { canvas: 15 },
          });
        } catch (e) {
          this.reportError("Unexpected error when starting rrweb recording.", e);
        }
        if ("function" != typeof this._stopRecording) {
          (this.reportError("rrweb failed to start, skipping this recording."),
            (this._stopRecording = null),
            this.stopRecording());
          return;
        }
        var n = this.maxExpires - new Date().getTime();
        this.maxTimeoutId = setTimeout(this._onMaxLengthReached.bind(this), n);
      }),
      (sf.prototype.stopRecording = function (e) {
        var t;
        if (((this.finalFlushUserIdInfo = this.getUserIdInfo()), !this.isRrwebStopped())) {
          try {
            this._stopRecording();
          } catch (e) {
            this.reportError("Error with rrweb stopRecording", e);
          }
          this._stopRecording = null;
        }
        return (
          this.batcher.stopped ? (t = this.batcher.clear()) : e || (t = this.batcher.flush()),
          this.batcher.stop(),
          clearTimeout(this.idleTimeoutId),
          clearTimeout(this.maxTimeoutId),
          t
        );
      }),
      (sf.prototype.isRrwebStopped = function () {
        return null === this._stopRecording;
      }),
      (sf.prototype.flushEventsWithOptOut = function (e, t, r) {
        var n = function (e) {
          0 === e && (this.stopRecording(), r({ error: "Tracking has been opted out, stopping recording." }));
        }.bind(this);
        this._flushEvents(e, t, r, n);
      }),
      (sf.prototype.serialize = function () {
        var e;
        try {
          e = this._mixpanel.get_tab_id();
        } catch (t) {
          (this.reportError("Error getting tab ID for serialization ", t), (e = null));
        }
        return {
          replayId: this.replayId,
          seqNo: this.seqNo,
          replayStartTime: this.replayStartTime,
          batchStartUrl: this.batchStartUrl,
          replayStartUrl: this.replayStartUrl,
          idleExpires: this.idleExpires,
          maxExpires: this.maxExpires,
          tabId: e,
        };
      }),
      (sf.deserialize = function (e, t) {
        return new sf(
          ow.extend({}, t, {
            replayId: e.replayId,
            batchStartUrl: e.batchStartUrl,
            replayStartUrl: e.replayStartUrl,
            idleExpires: e.idleExpires,
            maxExpires: e.maxExpires,
            replayStartTime: e.replayStartTime,
            seqNo: e.seqNo,
            sharedLockStorage: t.sharedLockStorage,
          }),
        );
      }),
      (sf.prototype._sendRequest = function (e, t, r, n) {
        var i = function (t, r) {
            (200 === t.status &&
              this.replayId === e &&
              (this.seqNo++, (this.batchStartUrl = ow.info.currentUrl())),
              this._onBatchSent(),
              n({
                status: 0,
                httpStatusCode: t.status,
                responseBody: r,
                retryAfter: t.headers.get("Retry-After"),
              }));
          }.bind(this),
          o =
            (this._mixpanel.get_api_host && this._mixpanel.get_api_host("record")) ||
            this.getConfig("api_host");
        iO.fetch(o + "/" + this.getConfig("api_routes").record + "?" + new URLSearchParams(t), {
          method: "POST",
          headers: {
            Authorization: "Basic " + btoa(this.getConfig("token") + ":"),
            "Content-Type": "application/octet-stream",
          },
          body: r,
        })
          .then(function (e) {
            e.json()
              .then(function (t) {
                i(e, t);
              })
              .catch(function (e) {
                n({ error: e });
              });
          })
          .catch(function (e) {
            n({ error: e, httpStatusCode: 0 });
          });
      }),
      (sf.prototype._flushEvents = o1(function (e, t, r) {
        var n = e.length;
        if (n > 0) {
          for (var i = this.replayId, o = 1 / 0, s = -1 / 0, a = !1, c = 0; c < n; c++)
            ((o = Math.min(o, e[c].timestamp)),
              (s = Math.max(s, e[c].timestamp)),
              e[c].type === nx.FullSnapshot && (a = !0));
          if (0 === this.seqNo) {
            if (!a) {
              (r({ error: "First batch does not contain a full snapshot. Aborting recording." }),
                this.stopRecording(!0));
              return;
            }
            this.replayStartTime = o;
          } else
            this.replayStartTime ||
              (this.reportError(
                "Replay start time not set but seqNo is not 0. Using current batch start time as a fallback.",
              ),
              (this.replayStartTime = o));
          var u = s - this.replayStartTime,
            l = {
              $current_url: this.batchStartUrl,
              $lib_version: oi.LIB_VERSION,
              batch_start_time: o / 1e3,
              mp_lib: "web",
              replay_id: i,
              replay_length_ms: u,
              replay_start_time: this.replayStartTime / 1e3,
              replay_start_url: this.replayStartUrl,
              seq: this.seqNo,
            },
            p = JSON.stringify(e);
          (Object.assign(l, this.getUserIdInfo()),
            sp
              ? new Response(new Blob([p], { type: "application/json" }).stream().pipeThrough(new sp("gzip")))
                  .blob()
                  .then(
                    function (e) {
                      ((l.format = "gzip"), this._sendRequest(i, l, e, r));
                    }.bind(this),
                  )
              : ((l.format = "body"), this._sendRequest(i, l, p, r)));
        }
      })),
      (sf.prototype.reportError = function (e, t) {
        sl.error.apply(sl.error, arguments);
        try {
          (t || e instanceof Error || (e = Error(e)), this.getConfig("error_reporter")(e, t));
        } catch (e) {
          sl.error(e);
        }
      }));
    var sg = function (e) {
      ((this.idb = new oZ(o$)),
        (this.errorReporter = e.errorReporter),
        (this.mixpanelInstance = e.mixpanelInstance),
        (this.sharedLockStorage = e.sharedLockStorage));
    };
    ((sg.prototype.isPersistenceEnabled = function () {
      return !this.mixpanelInstance.get_config("disable_persistence");
    }),
      (sg.prototype.handleError = function (e) {
        this.errorReporter("IndexedDB error: ", e);
      }),
      (sg.prototype.setActiveRecording = function (e) {
        if (!this.isPersistenceEnabled()) return f.resolve();
        var t = e.tabId;
        return t
          ? this.idb
              .init()
              .then(
                function () {
                  return this.idb.setItem(t, e);
                }.bind(this),
              )
              .catch(this.handleError.bind(this))
          : (console.warn("No tab ID is set, cannot persist recording metadata."), f.resolve());
      }),
      (sg.prototype.getActiveRecording = function () {
        return this.isPersistenceEnabled()
          ? this.idb
              .init()
              .then(
                function () {
                  return this.idb.getItem(this.mixpanelInstance.get_tab_id());
                }.bind(this),
              )
              .then(
                function (e) {
                  return su(e) ? null : e;
                }.bind(this),
              )
              .catch(this.handleError.bind(this))
          : f.resolve(null);
      }),
      (sg.prototype.clearActiveRecording = function () {
        return this.isPersistenceEnabled() ? this.markActiveRecordingExpired() : this.deleteActiveRecording();
      }),
      (sg.prototype.markActiveRecordingExpired = function () {
        return this.getActiveRecording()
          .then(
            function (e) {
              if (e) return ((e.maxExpires = 0), this.setActiveRecording(e));
            }.bind(this),
          )
          .catch(this.handleError.bind(this));
      }),
      (sg.prototype.deleteActiveRecording = function () {
        return this.idb.isInitialized()
          ? this.idb.removeItem(this.mixpanelInstance.get_tab_id()).catch(this.handleError.bind(this))
          : f.resolve();
      }),
      (sg.prototype.flushInactiveRecordings = function () {
        return this.isPersistenceEnabled()
          ? this.idb
              .init()
              .then(
                function () {
                  return this.idb.getAll();
                }.bind(this),
              )
              .then(
                function (e) {
                  var t = e
                    .filter(function (e) {
                      return su(e);
                    })
                    .map(
                      function (e) {
                        return sf
                          .deserialize(e, {
                            mixpanelInstance: this.mixpanelInstance,
                            sharedLockStorage: this.sharedLockStorage,
                          })
                          .unloadPersistedData()
                          .then(
                            function () {
                              return this.idb.removeItem(e.tabId);
                            }.bind(this),
                          )
                          .catch(this.handleError.bind(this));
                      }.bind(this),
                    );
                  return f.all(t);
                }.bind(this),
              )
              .catch(this.handleError.bind(this))
          : f.resolve([]);
      }));
    var sm = ok("recorder"),
      s_ = function (e, t, r) {
        ((this.mixpanelInstance = e),
          (this.rrwebRecord = t || i_),
          (this.sharedLockStorage = r),
          (this.recordingRegistry = new sg({
            mixpanelInstance: this.mixpanelInstance,
            errorReporter: sm.error,
            sharedLockStorage: r,
          })),
          (this._flushInactivePromise = this.recordingRegistry.flushInactiveRecordings()),
          (this.activeRecording = null),
          (this.stopRecordingInProgress = !1));
      };
    ((s_.prototype.startRecording = function (e) {
      if (((e = e || {}), this.activeRecording && !this.activeRecording.isRrwebStopped()))
        return void sm.log("Recording already in progress, skipping startRecording.");
      var t = function () {
          (sm.log("Idle timeout reached, restarting recording."), this.resetRecording());
        }.bind(this),
        r = function () {
          (sm.log("Max recording length reached, stopping recording."), this.resetRecording());
        }.bind(this),
        n = function () {
          (this.recordingRegistry.setActiveRecording(this.activeRecording.serialize()),
            (this.__flushPromise = this.activeRecording.batcher._flushPromise));
        }.bind(this),
        i = {
          mixpanelInstance: this.mixpanelInstance,
          onBatchSent: n,
          onIdleTimeout: t,
          onMaxLengthReached: r,
          replayId: ow.UUID(),
          rrwebRecord: this.rrwebRecord,
          sharedLockStorage: this.sharedLockStorage,
        };
      return (
        e.activeSerializedRecording
          ? (this.activeRecording = sf.deserialize(e.activeSerializedRecording, i))
          : (this.activeRecording = new sf(i)),
        this.activeRecording.startRecording(e.shouldStopBatcher),
        this.recordingRegistry.setActiveRecording(this.activeRecording.serialize())
      );
    }),
      (s_.prototype.stopRecording = function () {
        return (
          (this.stopRecordingInProgress = !0),
          this._stopCurrentRecording(!1, !0)
            .then(
              function () {
                return this.recordingRegistry.clearActiveRecording();
              }.bind(this),
            )
            .then(
              function () {
                this.stopRecordingInProgress = !1;
              }.bind(this),
            )
        );
      }),
      (s_.prototype.pauseRecording = function () {
        return this._stopCurrentRecording(!1);
      }),
      (s_.prototype._stopCurrentRecording = function (e, t) {
        if (this.activeRecording) {
          var r = this.activeRecording.stopRecording(e);
          return (t && (this.activeRecording = null), r);
        }
        return f.resolve();
      }),
      (s_.prototype.resumeRecording = function (e) {
        return this.activeRecording && this.activeRecording.isRrwebStopped()
          ? (this.activeRecording.startRecording(!1), f.resolve(null))
          : this.recordingRegistry.getActiveRecording().then(
              function (t) {
                return t && !this.stopRecordingInProgress
                  ? this.startRecording({ activeSerializedRecording: t })
                  : e
                    ? this.startRecording({ shouldStopBatcher: !1 })
                    : (sm.log("No resumable recording found."), null);
              }.bind(this),
            );
      }),
      (s_.prototype.resetRecording = function () {
        (this.stopRecording(), this.startRecording({ shouldStopBatcher: !0 }));
      }),
      (s_.prototype.getActiveReplayId = function () {
        return this.activeRecording && !this.activeRecording.isRrwebStopped()
          ? this.activeRecording.replayId
          : null;
      }),
      Object.defineProperty(s_.prototype, "replayId", {
        get: function () {
          return this.getActiveReplayId();
        },
      }),
      (iO.__mp_recorder = s_));
    var sv = "change",
      sy = "click",
      sb = "hashchange",
      sC = "mp_locationchange",
      sE = "popstate",
      sw = "scrollend",
      sI = "submit",
      sS = ["clientX", "clientY", "offsetX", "offsetY", "pageX", "pageY", "screenX", "screenY", "x", "y"],
      sk = ["mp-include"],
      sO = ["mp-no-track"],
      sA = sO.concat(["mp-sensitive"]),
      sR = ["aria-label", "aria-labelledby", "aria-describedby", "href", "name", "role", "title", "type"],
      sT = ok("autocapture");
    function sx(e) {
      for (var t = {}, r = sM(e).split(" "), n = 0; n < r.length; n++) {
        var i = r[n];
        i && (t[i] = !0);
      }
      return t;
    }
    function sM(e) {
      switch (typeof e.className) {
        case "string":
          return e.className;
        case "object":
          return e.className.baseVal || e.getAttribute("class") || "";
        default:
          return "";
      }
    }
    function sL(e, t, r, n, i, o) {
      var s = { $classes: sM(e).split(" "), $tag_name: e.tagName.toLowerCase() },
        a = e.id;
      (a && (s.$id = a),
        sj(e, t, i, o) &&
          ow.each(sR.concat(n), function (t) {
            if (e.hasAttribute(t) && !r[t]) {
              var n = e.getAttribute(t);
              sV(n) && (s["$attr-" + t] = n);
            }
          }));
      for (
        var c = 1, u = 1, l = e;
        (l = (function (e) {
          if (e.previousElementSibling) return e.previousElementSibling;
          do e = e.previousSibling;
          while (e && !sF(e));
          return e;
        })(l));
      )
        (c++, l.tagName === e.tagName && u++);
      return ((s.$nth_child = c), (s.$nth_of_type = u), s);
    }
    function sP(e, t, r, n) {
      var i = "";
      return (
        sj(e, t, r, n) &&
          e.childNodes &&
          e.childNodes.length &&
          ow.each(e.childNodes, function (e) {
            sB(e) &&
              e.textContent &&
              (i += ow
                .trim(e.textContent)
                .split(/(\s+)/)
                .filter(sV)
                .join("")
                .replace(/[\r\n]/g, " ")
                .replace(/[ ]+/g, " ")
                .substring(0, 255));
          }),
        ow.trim(i)
      );
    }
    function sD(e, t, r, n) {
      if (r)
        try {
          if (!r(e, t)) return !1;
        } catch (e) {
          return (sT.critical("Error while checking element in allowElementCallback", e), !1);
        }
      if (!n.length) return !0;
      for (var i = 0; i < n.length; i++) {
        var o = n[i];
        try {
          if (e.matches(o)) return !0;
        } catch (e) {
          sT.critical("Error while checking selector: " + o, e);
        }
      }
      return !1;
    }
    function sN(e, t, r, n) {
      if (r)
        try {
          if (r(e, t)) return !0;
        } catch (e) {
          return (sT.critical("Error while checking element in blockElementCallback", e), !0);
        }
      if (n && n.length)
        for (i = 0; i < n.length; i++) {
          var i,
            o = n[i];
          try {
            if (e.matches(o)) return !0;
          } catch (e) {
            sT.critical("Error while checking selector: " + o, e);
          }
        }
      var s = sx(e);
      for (i = 0; i < sO.length; i++) if (s[sO[i]]) return !0;
      return !1;
    }
    function sF(e) {
      return e && 1 === e.nodeType;
    }
    function sU(e, t) {
      return e && e.tagName && e.tagName.toLowerCase() === t.toLowerCase();
    }
    function sB(e) {
      return e && 3 === e.nodeType;
    }
    function sj(e, t, r, n) {
      if (!sD(e, t, r, n)) return !1;
      for (var i, o = e; o.parentNode && !sU(o, "body"); o = o.parentNode) {
        var s = sx(o);
        for (i = 0; i < sA.length; i++) if (s[sA[i]]) return !1;
      }
      var a = sx(e);
      for (i = 0; i < sk.length; i++) if (a[sk[i]]) return !0;
      if (
        sU(e, "input") ||
        sU(e, "select") ||
        sU(e, "textarea") ||
        "true" === e.getAttribute("contenteditable")
      )
        return !1;
      var c = e.type || "";
      if ("string" == typeof c)
        switch (c.toLowerCase()) {
          case "hidden":
          case "password":
            return !1;
        }
      var u = e.name || e.id || "";
      return (
        !(
          "string" == typeof u &&
          /^cc|cardnum|ccnum|creditcard|csc|cvc|cvv|exp|pass|pwd|routing|seccode|securitycode|securitynum|socialsec|socsec|ssn/i.test(
            u.replace(/[^a-zA-Z0-9]/g, ""),
          )
        ) && !0
      );
    }
    function sV(e) {
      if (null === e || ow.isUndefined(e)) return !1;
      if (
        "string" == typeof e &&
        ((e = ow.trim(e)),
        /^(?:(4[0-9]{12}(?:[0-9]{3})?)|(5[1-5][0-9]{14})|(6(?:011|5[0-9]{2})[0-9]{12})|(3[47][0-9]{13})|(3(?:0[0-5]|[68][0-9])[0-9]{11})|((?:2131|1800|35[0-9]{3})[0-9]{11}))$/.test(
          (e || "").replace(/[- ]/g, ""),
        ) || /(^\d{3}-?\d{2}-?\d{4}$)/.test(e))
      )
        return !1;
      return !0;
    }
    function sG() {
      this.clicks = [];
    }
    sG.prototype.isRageClick = function (e, t, r) {
      var n = (r = r || {}).threshold_px || 30,
        i = r.timeout_ms || 1e3,
        o = r.click_count || 4,
        s = Date.now(),
        a = this.clicks[this.clicks.length - 1];
      if (a && s - a.timestamp < i && Math.sqrt(Math.pow(e - a.x, 2) + Math.pow(t - a.y, 2)) < n) {
        if ((this.clicks.push({ x: e, y: t, timestamp: s }), this.clicks.length >= o))
          return ((this.clicks = []), !0);
      } else this.clicks = [{ x: e, y: t, timestamp: s }];
      return !1;
    };
    var sW = "autocapture",
      sz = "full-url",
      sK = "allow_selectors",
      sq = "allow_url_regexes",
      sY = "block_attrs",
      s$ = "block_element_callback",
      sH = "block_selectors",
      sZ = "block_url_regexes",
      sJ = "capture_extra_attrs",
      sX = "capture_text_content",
      sQ = "scroll_capture_all",
      s0 = "scroll_depth_percent_checkpoints",
      s1 = "click",
      s2 = "input",
      s3 = "pageview",
      s4 = "rage_click",
      s5 = "scroll",
      s9 = "submit",
      s6 = {};
    ((s6[sK] = []),
      (s6[sq] = []),
      (s6[sY] = []),
      (s6[s$] = null),
      (s6[sH] = []),
      (s6[sZ] = []),
      (s6[sJ] = []),
      (s6[sX] = !1),
      (s6[sQ] = !1),
      (s6[s0] = [25, 50, 75, 100]),
      (s6[s1] = !0),
      (s6[s2] = !0),
      (s6[s3] = sz),
      (s6[s4] = !0),
      (s6[s5] = !0),
      (s6[s9] = !0));
    var s8 = { $mp_autocapture: !0 },
      s7 = "$mp_click",
      ae = "$mp_rage_click",
      at = function (e) {
        this.mp = e;
      };
    ((at.prototype.init = function () {
      !(function () {
        try {
          return !!od.createElement("div").matches;
        } catch (e) {
          return !1;
        }
      })()
        ? sT.critical("Autocapture unavailable: missing required DOM APIs")
        : (this.initPageviewTracking(),
          this.initClickTracking(),
          this.initInputTracking(),
          this.initScrollTracking(),
          this.initSubmitTracking(),
          this.initRageClickTracking());
    }),
      (at.prototype.getFullConfig = function () {
        var e = this.mp.get_config(sW);
        return e ? (ow.isObject(e) ? ow.extend({}, s6, e) : s6) : {};
      }),
      (at.prototype.getConfig = function (e) {
        return this.getFullConfig()[e];
      }),
      (at.prototype.currentUrlBlocked = function () {
        var e,
          t = ow.info.currentUrl(),
          r = this.getConfig(sq) || [];
        if (r.length) {
          var n = !1;
          for (e = 0; e < r.length; e++) {
            var i = r[e];
            try {
              if (t.match(i)) {
                n = !0;
                break;
              }
            } catch (e) {
              return (sT.critical("Error while checking block URL regex: " + i, e), !0);
            }
          }
          if (!n) return !0;
        }
        var o = this.getConfig(sZ) || [];
        if (!o || !o.length) return !1;
        for (e = 0; e < o.length; e++)
          try {
            if (t.match(o[e])) return !0;
          } catch (t) {
            return (sT.critical("Error while checking block URL regex: " + o[e], t), !0);
          }
        return !1;
      }),
      (at.prototype.pageviewTrackingConfig = function () {
        return this.mp.get_config(sW) ? this.getConfig(s3) : this.mp.get_config("track_pageview");
      }),
      (at.prototype.trackDomEvent = function (e, t) {
        if (!this.currentUrlBlocked()) {
          var r =
              this.mp.is_recording_heatmap_data() &&
              ((t === s7 && !this.getConfig(s1)) || (t === ae && !this._getRageClickConfig())),
            n = (function (e, t) {
              var r = t.allowElementCallback,
                n = t.allowSelectors || [],
                i = t.blockAttrs || [],
                o = t.blockElementCallback,
                s = t.blockSelectors || [],
                a = t.captureTextContent || !1,
                c = t.captureExtraAttrs || [],
                u = t.capturedForHeatMap || !1,
                l = {};
              ow.each(i, function (e) {
                l[e] = !0;
              });
              var p = null,
                h = void 0 === e.target ? e.srcElement : e.target;
              if (
                (sB(h) && (h = h.parentNode),
                (function (e, t) {
                  if (!e || sU(e, "html") || !sF(e)) return !1;
                  switch (e.tagName.toLowerCase()) {
                    case "form":
                      return t.type === sI;
                    case "input":
                      if (-1 === ["button", "submit"].indexOf(e.getAttribute("type"))) return t.type === sv;
                      return t.type === sy;
                    case "select":
                    case "textarea":
                      return t.type === sv;
                    default:
                      return t.type === sy;
                  }
                })(h, e) &&
                  sD(h, e, r, n) &&
                  !sN(h, e, o, s))
              ) {
                for (var d = [h], f = h; f.parentNode && !sU(f, "body");)
                  (d.push(f.parentNode), (f = f.parentNode));
                var g,
                  m = [],
                  _ = !1;
                if (
                  (ow.each(
                    d,
                    function (t) {
                      var i = sj(t, e, r, n);
                      (l.href ||
                        "a" !== t.tagName.toLowerCase() ||
                        ((g = t.getAttribute("href")), (g = i && sV(g) && g)),
                        sN(t, e, o, s) && (_ = !0),
                        m.push(sL(t, e, l, c, r, n)));
                    },
                    this,
                  ),
                  !_)
                ) {
                  var v = od.documentElement;
                  if (
                    ((p = {
                      $event_type: e.type,
                      $host: iO.location.host,
                      $pathname: iO.location.pathname,
                      $elements: m,
                      $el_attr__href: g,
                      $viewportHeight: Math.max(v.clientHeight, iO.innerHeight || 0),
                      $viewportWidth: Math.max(v.clientWidth, iO.innerWidth || 0),
                      $pageHeight: od.body.offsetHeight || 0,
                      $pageWidth: od.body.offsetWidth || 0,
                    }),
                    ow.each(c, function (e) {
                      if (!l[e] && h.hasAttribute(e)) {
                        var t = h.getAttribute(e);
                        sV(t) && (p["$el_attr__" + e] = t);
                      }
                    }),
                    a && (y = sP(h, e, r, n)) && y.length && (p.$el_text = y),
                    e.type === sy &&
                      (ow.each(sS, function (t) {
                        t in e && (p["$" + t] = e[t]);
                      }),
                      u && (p.$captured_for_heatmap = !0),
                      (h = (function (e) {
                        for (var t = e.target, r = e.composedPath(), n = 0; n < r.length; n++) {
                          var i = r[n];
                          if (
                            sU(i, "a") ||
                            sU(i, "button") ||
                            sU(i, "input") ||
                            sU(i, "select") ||
                            (i.getAttribute && "button" === i.getAttribute("role"))
                          ) {
                            t = i;
                            break;
                          }
                          if (i === t) break;
                        }
                        return t;
                      })(e))),
                    a)
                  ) {
                    var y = sP(h, e, r, n);
                    y && y.length && (p.$el_text = y);
                  }
                  if (h) {
                    if (!sD(h, e, r, n) || sN(h, e, o, s)) return null;
                    var b = sL(h, e, l, c, r, n);
                    ((p.$target = b),
                      (p.$el_classes = b.$classes),
                      ow.extend(p, ow.strip_empty_properties({ $el_id: b.$id, $el_tag_name: b.$tag_name })));
                  }
                }
              }
              return p;
            })(e, {
              allowElementCallback: this.getConfig("allow_element_callback"),
              allowSelectors: this.getConfig(sK),
              blockAttrs: this.getConfig(sY),
              blockElementCallback: this.getConfig(s$),
              blockSelectors: this.getConfig(sH),
              captureExtraAttrs: this.getConfig(sJ),
              captureTextContent: this.getConfig(sX),
              capturedForHeatMap: r,
            });
          n && (ow.extend(n, s8), this.mp.track(t, n));
        }
      }),
      (at.prototype._getRageClickConfig = function () {
        var e = this.getConfig(s4);
        return e ? (!0 === e ? {} : "object" == typeof e ? e : {}) : null;
      }),
      (at.prototype.initClickTracking = function () {
        (iO.removeEventListener(sy, this.listenerClick),
          (this.getConfig(s1) || this.mp.get_config("record_heatmap_data")) &&
            (sT.log("Initializing click tracking"),
            (this.listenerClick = iO.addEventListener(
              sy,
              function (e) {
                (this.getConfig(s1) || this.mp.is_recording_heatmap_data()) && this.trackDomEvent(e, s7);
              }.bind(this),
            ))));
      }),
      (at.prototype.initInputTracking = function () {
        (iO.removeEventListener(sv, this.listenerChange),
          this.getConfig(s2) &&
            (sT.log("Initializing input tracking"),
            (this.listenerChange = iO.addEventListener(
              sv,
              function (e) {
                this.getConfig(s2) && this.trackDomEvent(e, "$mp_input_change");
              }.bind(this),
            ))));
      }),
      (at.prototype.initPageviewTracking = function () {
        if (
          (iO.removeEventListener(sE, this.listenerPopstate),
          iO.removeEventListener(sb, this.listenerHashchange),
          iO.removeEventListener(sC, this.listenerLocationchange),
          this.pageviewTrackingConfig())
        ) {
          sT.log("Initializing pageview tracking");
          var e = "",
            t = !1;
          (this.currentUrlBlocked() || (t = this.mp.track_pageview(s8)),
            t && (e = ow.info.currentUrl()),
            (this.listenerPopstate = iO.addEventListener(sE, function () {
              iO.dispatchEvent(new Event(sC));
            })),
            (this.listenerHashchange = iO.addEventListener(sb, function () {
              iO.dispatchEvent(new Event(sC));
            })));
          var r = iO.history.pushState;
          "function" == typeof r &&
            (iO.history.pushState = function (e, t, n) {
              (r.call(iO.history, e, t, n), iO.dispatchEvent(new Event(sC)));
            });
          var n = iO.history.replaceState;
          ("function" == typeof n &&
            (iO.history.replaceState = function (e, t, r) {
              (n.call(iO.history, e, t, r), iO.dispatchEvent(new Event(sC)));
            }),
            (this.listenerLocationchange = iO.addEventListener(
              sC,
              oO(
                function () {
                  if (!this.currentUrlBlocked()) {
                    var t = ow.info.currentUrl(),
                      r = !1,
                      n = t.split("#")[0].split("?")[0] !== e.split("#")[0].split("?")[0],
                      i = this.pageviewTrackingConfig();
                    (i === sz
                      ? (r = t !== e)
                      : "url-with-path-and-query-string" === i
                        ? (r = t.split("#")[0] !== e.split("#")[0])
                        : "url-with-path" === i && (r = n),
                      r &&
                        (this.mp.track_pageview(s8) && (e = t),
                        n &&
                          ((this.lastScrollCheckpoint = 0),
                          sT.log("Path change: re-initializing scroll depth checkpoints"))));
                  }
                }.bind(this),
              ),
            )));
        }
      }),
      (at.prototype.initRageClickTracking = function () {
        (iO.removeEventListener(sy, this.listenerRageClick),
          (this._getRageClickConfig() || this.mp.get_config("record_heatmap_data")) &&
            (sT.log("Initializing rage click tracking"),
            this._rageClickTracker || (this._rageClickTracker = new sG()),
            (this.listenerRageClick = function (e) {
              var t = this._getRageClickConfig();
              (t || this.mp.is_recording_heatmap_data()) &&
                !this.currentUrlBlocked() &&
                this._rageClickTracker.isRageClick(e.pageX, e.pageY, t) &&
                this.trackDomEvent(e, ae);
            }.bind(this)),
            iO.addEventListener(sy, this.listenerRageClick)));
      }),
      (at.prototype.initScrollTracking = function () {
        (iO.removeEventListener(sw, this.listenerScroll),
          this.getConfig(s5) &&
            (sT.log("Initializing scroll tracking"),
            (this.lastScrollCheckpoint = 0),
            (this.listenerScroll = iO.addEventListener(
              sw,
              oO(
                function () {
                  if (this.getConfig(s5) && !this.currentUrlBlocked()) {
                    var e = this.getConfig(sQ),
                      t = (this.getConfig(s0) || []).slice().sort(function (e, t) {
                        return e - t;
                      }),
                      r = iO.scrollY,
                      n = ow.extend({ $scroll_top: r }, s8);
                    try {
                      var i = od.body.scrollHeight,
                        o = Math.round((r / (i - iO.innerHeight)) * 100);
                      if (((n.$scroll_height = i), (n.$scroll_percentage = o), o > this.lastScrollCheckpoint))
                        for (var s = 0; s < t.length; s++) {
                          var a = t[s];
                          o >= a &&
                            this.lastScrollCheckpoint < a &&
                            ((n.$scroll_checkpoint = a), (this.lastScrollCheckpoint = a), (e = !0));
                        }
                    } catch (e) {
                      sT.critical("Error while calculating scroll percentage", e);
                    }
                    e && this.mp.track("$mp_scroll", n);
                  }
                }.bind(this),
              ),
            ))));
      }),
      (at.prototype.initSubmitTracking = function () {
        (iO.removeEventListener(sI, this.listenerSubmit),
          this.getConfig(s9) &&
            (sT.log("Initializing submit tracking"),
            (this.listenerSubmit = iO.addEventListener(
              sI,
              function (e) {
                this.getConfig(s9) && this.trackDomEvent(e, "$mp_submit");
              }.bind(this),
            ))));
      }),
      oA(at));
    var ar = iO.fetch,
      an = ok("flags"),
      ai = "flags",
      ao = "context",
      as = {};
    as[ao] = {};
    var aa = function (e) {
      ((this.getFullApiRoute = e.getFullApiRoute),
        (this.getMpConfig = e.getConfigFunc),
        (this.setMpConfig = e.setConfigFunc),
        (this.getMpProperty = e.getPropertyFunc),
        (this.track = e.trackingFunc));
    };
    ((aa.prototype.init = function () {
      ar && "u" > typeof Promise && "u" > typeof Map && "u" > typeof Set
        ? ((this.flags = null), this.fetchFlags(), (this.trackedFeatures = new Set()))
        : an.critical("Feature Flags unavailable: missing minimum required APIs");
    }),
      (aa.prototype.getFullConfig = function () {
        var e = this.getMpConfig(ai);
        return e ? (ow.isObject(e) ? ow.extend({}, as, e) : as) : {};
      }),
      (aa.prototype.getConfig = function (e) {
        return this.getFullConfig()[e];
      }),
      (aa.prototype.isSystemEnabled = function () {
        return !!this.getMpConfig(ai);
      }),
      (aa.prototype.updateContext = function (e, t) {
        if (!this.isSystemEnabled())
          return (an.critical("Feature Flags not enabled, cannot update context"), Promise.resolve());
        var r = this.getMpConfig(ai);
        ow.isObject(r) || (r = {});
        var n = t && t.replace ? {} : this.getConfig(ao);
        return ((r[ao] = ow.extend({}, n, e)), this.setMpConfig(ai, r), this.fetchFlags());
      }),
      (aa.prototype.areFlagsReady = function () {
        return (this.isSystemEnabled() || an.error("Feature Flags not enabled"), !!this.flags);
      }),
      (aa.prototype.fetchFlags = function () {
        if (!this.isSystemEnabled()) return Promise.resolve();
        var e = this.getMpProperty("distinct_id"),
          t = this.getMpProperty("$device_id");
        an.log("Fetching flags for distinct ID: " + e);
        var r = ow.extend({ distinct_id: e, device_id: t }, this.getConfig(ao)),
          n = new URLSearchParams();
        (n.set("context", JSON.stringify(r)),
          n.set("token", this.getMpConfig("token")),
          n.set("mp_lib", "web"),
          n.set("$lib_version", oi.LIB_VERSION));
        var i = this.getFullApiRoute() + "?" + n.toString();
        return (
          (this._fetchInProgressStartTime = Date.now()),
          (this.fetchPromise = iO
            .fetch(i, {
              method: "GET",
              headers: { Authorization: "Basic " + btoa(this.getMpConfig("token") + ":") },
            })
            .then(
              function (e) {
                return (
                  this.markFetchComplete(),
                  e
                    .json()
                    .then(
                      function (e) {
                        var t = e.flags;
                        if (!t) throw Error("No flags in API response");
                        var r = new Map();
                        (ow.each(t, function (e, t) {
                          r.set(t, { key: e.variant_key, value: e.variant_value });
                        }),
                          (this.flags = r));
                      }.bind(this),
                    )
                    .catch(
                      function (e) {
                        (this.markFetchComplete(), an.error(e));
                      }.bind(this),
                    )
                );
              }.bind(this),
            )
            .catch(
              function (e) {
                (this.markFetchComplete(), an.error(e));
              }.bind(this),
            )),
          this.fetchPromise
        );
      }),
      (aa.prototype.markFetchComplete = function () {
        this._fetchInProgressStartTime
          ? ((this._fetchStartTime = this._fetchInProgressStartTime),
            (this._fetchCompleteTime = Date.now()),
            (this._fetchLatency = this._fetchCompleteTime - this._fetchStartTime),
            (this._fetchInProgressStartTime = null))
          : an.error("Fetch in progress started time not set, cannot mark fetch complete");
      }),
      (aa.prototype.getVariant = function (e, t) {
        return this.fetchPromise
          ? this.fetchPromise
              .then(
                function () {
                  return this.getVariantSync(e, t);
                }.bind(this),
              )
              .catch(function (e) {
                return (an.error(e), t);
              })
          : new Promise(function (e) {
              (an.critical("Feature Flags not initialized"), e(t));
            });
      }),
      (aa.prototype.getVariantSync = function (e, t) {
        if (!this.areFlagsReady()) return (an.log("Flags not loaded yet"), t);
        var r = this.flags.get(e);
        return r ? (this.trackFeatureCheck(e, r), r) : (an.log('No flag found: "' + e + '"'), t);
      }),
      (aa.prototype.getVariantValue = function (e, t) {
        return this.getVariant(e, { value: t })
          .then(function (e) {
            return e.value;
          })
          .catch(function (e) {
            return (an.error(e), t);
          });
      }),
      (aa.prototype.getFeatureData = function (e, t) {
        return (
          an.critical(
            "mixpanel.flags.get_feature_data() is deprecated and will be removed in a future release. Use mixpanel.flags.get_variant_value() instead.",
          ),
          this.getVariantValue(e, t)
        );
      }),
      (aa.prototype.getVariantValueSync = function (e, t) {
        return this.getVariantSync(e, { value: t }).value;
      }),
      (aa.prototype.isEnabled = function (e, t) {
        return this.getVariantValue(e)
          .then(
            function () {
              return this.isEnabledSync(e, t);
            }.bind(this),
          )
          .catch(function (e) {
            return (an.error(e), t);
          });
      }),
      (aa.prototype.isEnabledSync = function (e, t) {
        t = t || !1;
        var r = this.getVariantValueSync(e, t);
        return (
          !0 !== r &&
            !1 !== r &&
            (an.error(
              'Feature flag "' + e + '" value: ' + r + " is not a boolean; returning fallback value: " + t,
            ),
            (r = t)),
          r
        );
      }),
      (aa.prototype.trackFeatureCheck = function (e, t) {
        this.trackedFeatures.has(e) ||
          (this.trackedFeatures.add(e),
          this.track("$experiment_started", {
            "Experiment name": e,
            "Variant name": t.key,
            $experiment_type: "feature_flag",
            "Variant fetch start time": new Date(this._fetchStartTime).toISOString(),
            "Variant fetch complete time": new Date(this._fetchCompleteTime).toISOString(),
            "Variant fetch latency (ms)": this._fetchLatency,
          }));
      }),
      oA(aa),
      (aa.prototype.are_flags_ready = aa.prototype.areFlagsReady),
      (aa.prototype.get_variant = aa.prototype.getVariant),
      (aa.prototype.get_variant_sync = aa.prototype.getVariantSync),
      (aa.prototype.get_variant_value = aa.prototype.getVariantValue),
      (aa.prototype.get_variant_value_sync = aa.prototype.getVariantValueSync),
      (aa.prototype.is_enabled = aa.prototype.isEnabled),
      (aa.prototype.is_enabled_sync = aa.prototype.isEnabledSync),
      (aa.prototype.update_context = aa.prototype.updateContext),
      (aa.prototype.get_feature_data = aa.prototype.getFeatureData));
    var ac = function () {};
    ((ac.prototype.create_properties = function () {}),
      (ac.prototype.event_handler = function () {}),
      (ac.prototype.after_track_handler = function () {}),
      (ac.prototype.init = function (e) {
        return ((this.mp = e), this);
      }),
      (ac.prototype.track = function (e, t, r, n) {
        var i = this,
          o = ow.dom_query(e);
        return 0 === o.length
          ? void oI.error("The DOM query (" + e + ") returned 0 elements")
          : (ow.each(
              o,
              function (e) {
                ow.register_event(e, this.override_event, function (e) {
                  var o = {},
                    s = i.create_properties(r, this),
                    a = i.mp.get_config("track_links_timeout");
                  (i.event_handler(e, this, o),
                    window.setTimeout(i.track_callback(n, s, o, !0), a),
                    i.mp.track(t, s, i.track_callback(n, s, o)));
                });
              },
              this,
            ),
            !0);
      }),
      (ac.prototype.track_callback = function (e, t, r, n) {
        n = n || !1;
        var i = this;
        return function () {
          r.callback_fired ||
            ((r.callback_fired = !0), (e && !1 === e(n, t)) || i.after_track_handler(t, r, n));
        };
      }),
      (ac.prototype.create_properties = function (e, t) {
        return "function" == typeof e ? e(t) : ow.extend({}, e);
      }));
    var au = function () {
      this.override_event = "click";
    };
    (ow.inherit(au, ac),
      (au.prototype.create_properties = function (e, t) {
        var r = au.superclass.create_properties.apply(this, arguments);
        return (t.href && (r.url = t.href), r);
      }),
      (au.prototype.event_handler = function (e, t, r) {
        ((r.new_tab = 2 === e.which || e.metaKey || e.ctrlKey || "_blank" === t.target),
          (r.href = t.href),
          r.new_tab || e.preventDefault());
      }),
      (au.prototype.after_track_handler = function (e, t) {
        t.new_tab ||
          setTimeout(function () {
            window.location = t.href;
          }, 0);
      }));
    var al = function () {
      this.override_event = "submit";
    };
    (ow.inherit(al, ac),
      (al.prototype.event_handler = function (e, t, r) {
        ((r.element = t), e.preventDefault());
      }),
      (al.prototype.after_track_handler = function (e, t) {
        setTimeout(function () {
          t.element.submit();
        }, 0);
      }));
    var ap = "$set",
      ah = "$set_once",
      ad = "$unset",
      af = "$add",
      ag = "$append",
      am = "$union",
      a_ = "$remove",
      av = {
        set_action: function (e, t) {
          var r = {},
            n = {};
          return (
            ow.isObject(e)
              ? ow.each(
                  e,
                  function (e, t) {
                    this._is_reserved_property(t) || (n[t] = e);
                  },
                  this,
                )
              : (n[e] = t),
            (r[ap] = n),
            r
          );
        },
        unset_action: function (e) {
          var t = {},
            r = [];
          return (
            ow.isArray(e) || (e = [e]),
            ow.each(
              e,
              function (e) {
                this._is_reserved_property(e) || r.push(e);
              },
              this,
            ),
            (t[ad] = r),
            t
          );
        },
        set_once_action: function (e, t) {
          var r = {},
            n = {};
          return (
            ow.isObject(e)
              ? ow.each(
                  e,
                  function (e, t) {
                    this._is_reserved_property(t) || (n[t] = e);
                  },
                  this,
                )
              : (n[e] = t),
            (r[ah] = n),
            r
          );
        },
        union_action: function (e, t) {
          var r = {},
            n = {};
          return (
            ow.isObject(e)
              ? ow.each(
                  e,
                  function (e, t) {
                    this._is_reserved_property(t) || (n[t] = ow.isArray(e) ? e : [e]);
                  },
                  this,
                )
              : (n[e] = ow.isArray(t) ? t : [t]),
            (r[am] = n),
            r
          );
        },
        append_action: function (e, t) {
          var r = {},
            n = {};
          return (
            ow.isObject(e)
              ? ow.each(
                  e,
                  function (e, t) {
                    this._is_reserved_property(t) || (n[t] = e);
                  },
                  this,
                )
              : (n[e] = t),
            (r[ag] = n),
            r
          );
        },
        remove_action: function (e, t) {
          var r = {},
            n = {};
          return (
            ow.isObject(e)
              ? ow.each(
                  e,
                  function (e, t) {
                    this._is_reserved_property(t) || (n[t] = e);
                  },
                  this,
                )
              : (n[e] = t),
            (r[a_] = n),
            r
          );
        },
        delete_action: function () {
          var e = {};
          return ((e.$delete = ""), e);
        },
      },
      ay = function () {};
    (ow.extend(ay.prototype, av),
      (ay.prototype._init = function (e, t, r) {
        ((this._mixpanel = e), (this._group_key = t), (this._group_id = r));
      }),
      (ay.prototype.set = o3(function (e, t, r) {
        var n = this.set_action(e, t);
        return (ow.isObject(e) && (r = t), this._send_request(n, r));
      })),
      (ay.prototype.set_once = o3(function (e, t, r) {
        var n = this.set_once_action(e, t);
        return (ow.isObject(e) && (r = t), this._send_request(n, r));
      })),
      (ay.prototype.unset = o3(function (e, t) {
        var r = this.unset_action(e);
        return this._send_request(r, t);
      })),
      (ay.prototype.union = o3(function (e, t, r) {
        ow.isObject(e) && (r = t);
        var n = this.union_action(e, t);
        return this._send_request(n, r);
      })),
      (ay.prototype.delete = o3(function (e) {
        var t = this.delete_action();
        return this._send_request(t, e);
      })),
      (ay.prototype.remove = o3(function (e, t, r) {
        var n = this.remove_action(e, t);
        return this._send_request(n, r);
      })),
      (ay.prototype._send_request = function (e, t) {
        ((e.$group_key = this._group_key),
          (e.$group_id = this._group_id),
          (e.$token = this._get_config("token")));
        var r = ow.encodeDates(e);
        return this._mixpanel._track_or_batch(
          {
            type: "groups",
            data: r,
            endpoint: this._mixpanel.get_api_host("groups") + "/" + this._get_config("api_routes").groups,
            batcher: this._mixpanel.request_batchers.groups,
          },
          t,
        );
      }),
      (ay.prototype._is_reserved_property = function (e) {
        return "$group_key" === e || "$group_id" === e;
      }),
      (ay.prototype._get_config = function (e) {
        return this._mixpanel.get_config(e);
      }),
      (ay.prototype.toString = function () {
        return this._mixpanel.toString() + ".group." + this._group_key + "." + this._group_id;
      }),
      (ay.prototype.remove = ay.prototype.remove),
      (ay.prototype.set = ay.prototype.set),
      (ay.prototype.set_once = ay.prototype.set_once),
      (ay.prototype.union = ay.prototype.union),
      (ay.prototype.unset = ay.prototype.unset),
      (ay.prototype.toString = ay.prototype.toString));
    var ab = function () {};
    (ow.extend(ab.prototype, av),
      (ab.prototype._init = function (e) {
        this._mixpanel = e;
      }),
      (ab.prototype.set = o2(function (e, t, r) {
        var n = this.set_action(e, t);
        return (
          ow.isObject(e) && (r = t),
          this._get_config("save_referrer") &&
            this._mixpanel.persistence.update_referrer_info(document.referrer),
          (n[ap] = ow.extend({}, ow.info.people_properties(), n[ap])),
          this._send_request(n, r)
        );
      })),
      (ab.prototype.set_once = o2(function (e, t, r) {
        var n = this.set_once_action(e, t);
        return (ow.isObject(e) && (r = t), this._send_request(n, r));
      })),
      (ab.prototype.unset = o2(function (e, t) {
        var r = this.unset_action(e);
        return this._send_request(r, t);
      })),
      (ab.prototype.increment = o2(function (e, t, r) {
        var n = {},
          i = {};
        return (
          ow.isObject(e)
            ? (ow.each(
                e,
                function (e, t) {
                  if (!this._is_reserved_property(t))
                    if (isNaN(parseFloat(e)))
                      return void oI.error(
                        "Invalid increment value passed to mixpanel.people.increment - must be a number",
                      );
                    else i[t] = e;
                },
                this,
              ),
              (r = t))
            : (ow.isUndefined(t) && (t = 1), (i[e] = t)),
          (n[af] = i),
          this._send_request(n, r)
        );
      })),
      (ab.prototype.append = o2(function (e, t, r) {
        ow.isObject(e) && (r = t);
        var n = this.append_action(e, t);
        return this._send_request(n, r);
      })),
      (ab.prototype.remove = o2(function (e, t, r) {
        ow.isObject(e) && (r = t);
        var n = this.remove_action(e, t);
        return this._send_request(n, r);
      })),
      (ab.prototype.union = o2(function (e, t, r) {
        ow.isObject(e) && (r = t);
        var n = this.union_action(e, t);
        return this._send_request(n, r);
      })),
      (ab.prototype.track_charge = o2(function () {
        oI.error("mixpanel.people.track_charge() is deprecated and no longer has any effect.");
      })),
      (ab.prototype.clear_charges = function (e) {
        return this.set("$transactions", [], e);
      }),
      (ab.prototype.delete_user = function () {
        if (!this._identify_called())
          return void oI.error("mixpanel.people.delete_user() requires you to call identify() first");
        var e = { $delete: this._mixpanel.get_distinct_id() };
        return this._send_request(e);
      }),
      (ab.prototype.toString = function () {
        return this._mixpanel.toString() + ".people";
      }),
      (ab.prototype._send_request = function (e, t) {
        ((e.$token = this._get_config("token")), (e.$distinct_id = this._mixpanel.get_distinct_id()));
        var r = this._mixpanel.get_property("$device_id"),
          n = this._mixpanel.get_property("$user_id"),
          i = this._mixpanel.get_property("$had_persisted_distinct_id");
        (r && (e.$device_id = r), n && (e.$user_id = n), i && (e.$had_persisted_distinct_id = i));
        var o = ow.encodeDates(e);
        return this._identify_called()
          ? this._mixpanel._track_or_batch(
              {
                type: "people",
                data: o,
                endpoint: this._mixpanel.get_api_host("people") + "/" + this._get_config("api_routes").engage,
                batcher: this._mixpanel.request_batchers.people,
              },
              t,
            )
          : (this._enqueue(e),
            ow.isUndefined(t) || t(this._get_config("verbose") ? { status: -1, error: null } : -1),
            ow.truncate(o, 255));
      }),
      (ab.prototype._get_config = function (e) {
        return this._mixpanel.get_config(e);
      }),
      (ab.prototype._identify_called = function () {
        return !0 === this._mixpanel._flags.identify_called;
      }),
      (ab.prototype._enqueue = function (e) {
        ap in e
          ? this._mixpanel.persistence._add_to_people_queue(ap, e)
          : ah in e
            ? this._mixpanel.persistence._add_to_people_queue(ah, e)
            : ad in e
              ? this._mixpanel.persistence._add_to_people_queue(ad, e)
              : af in e
                ? this._mixpanel.persistence._add_to_people_queue(af, e)
                : ag in e
                  ? this._mixpanel.persistence._add_to_people_queue(ag, e)
                  : a_ in e
                    ? this._mixpanel.persistence._add_to_people_queue(a_, e)
                    : am in e
                      ? this._mixpanel.persistence._add_to_people_queue(am, e)
                      : oI.error("Invalid call to _enqueue():", e);
      }),
      (ab.prototype._flush_one_queue = function (e, t, r, n) {
        var i = this,
          o = ow.extend({}, this._mixpanel.persistence.load_queue(e)),
          s = o;
        !ow.isUndefined(o) &&
          ow.isObject(o) &&
          !ow.isEmptyObject(o) &&
          (i._mixpanel.persistence._pop_from_people_queue(e, o),
          i._mixpanel.persistence.save(),
          n && (s = n(o)),
          t.call(i, s, function (t, n) {
            (0 === t && i._mixpanel.persistence._add_to_people_queue(e, o), ow.isUndefined(r) || r(t, n));
          }));
      }),
      (ab.prototype._flush = function (e, t, r, n, i, o, s) {
        var a = this;
        (this._flush_one_queue(ap, this.set, e),
          this._flush_one_queue(ah, this.set_once, n),
          this._flush_one_queue(ad, this.unset, o, function (e) {
            return ow.keys(e);
          }),
          this._flush_one_queue(af, this.increment, t),
          this._flush_one_queue(am, this.union, i));
        var c = this._mixpanel.persistence.load_queue(ag);
        if (!ow.isUndefined(c) && ow.isArray(c) && c.length)
          for (
            var u,
              l = function (e, t) {
                (0 === e && a._mixpanel.persistence._add_to_people_queue(ag, u),
                  ow.isUndefined(r) || r(e, t));
              },
              p = c.length - 1;
            p >= 0;
            p--
          )
            ((u = (c = this._mixpanel.persistence.load_queue(ag)).pop()),
              a._mixpanel.persistence.save(),
              ow.isEmptyObject(u) || a.append(u, l));
        var h = this._mixpanel.persistence.load_queue(a_);
        if (!ow.isUndefined(h) && ow.isArray(h) && h.length)
          for (
            var d,
              f = function (e, t) {
                (0 === e && a._mixpanel.persistence._add_to_people_queue(a_, d),
                  ow.isUndefined(s) || s(e, t));
              },
              g = h.length - 1;
            g >= 0;
            g--
          )
            ((d = (h = this._mixpanel.persistence.load_queue(a_)).pop()),
              a._mixpanel.persistence.save(),
              ow.isEmptyObject(d) || a.remove(d, f));
      }),
      (ab.prototype._is_reserved_property = function (e) {
        return (
          "$distinct_id" === e ||
          "$token" === e ||
          "$device_id" === e ||
          "$user_id" === e ||
          "$had_persisted_distinct_id" === e
        );
      }),
      (ab.prototype.set = ab.prototype.set),
      (ab.prototype.set_once = ab.prototype.set_once),
      (ab.prototype.unset = ab.prototype.unset),
      (ab.prototype.increment = ab.prototype.increment),
      (ab.prototype.append = ab.prototype.append),
      (ab.prototype.remove = ab.prototype.remove),
      (ab.prototype.union = ab.prototype.union),
      (ab.prototype.track_charge = ab.prototype.track_charge),
      (ab.prototype.clear_charges = ab.prototype.clear_charges),
      (ab.prototype.delete_user = ab.prototype.delete_user),
      (ab.prototype.toString = ab.prototype.toString));
    var aC = "__mps",
      aE = "__mpso",
      aw = "__mpus",
      aI = "__mpa",
      aS = "__mpap",
      ak = "__mpr",
      aO = "__mpu",
      aA = "$people_distinct_id",
      aR = "__alias",
      aT = "__timers",
      ax = [aC, aE, aw, aI, aS, ak, aO, aA, aR, aT],
      aM = function (e) {
        ((this.props = {}),
          (this.campaign_params_saved = !1),
          e.persistence_name
            ? (this.name = "mp_" + e.persistence_name)
            : (this.name = "mp_" + e.token + "_mixpanel"));
        var t = e.persistence;
        ("cookie" !== t &&
          "localStorage" !== t &&
          (oI.critical("Unknown persistence type " + t + "; falling back to cookie"),
          (t = e.persistence = "cookie")),
          "localStorage" === t && ow.localStorage.is_supported()
            ? (this.storage = ow.localStorage)
            : (this.storage = ow.cookie),
          this.load(),
          this.update_config(e),
          this.upgrade(),
          this.save());
      };
    ((aM.prototype.properties = function () {
      var e = {};
      return (
        this.load(),
        ow.each(this.props, function (t, r) {
          ow.include(ax, r) || (e[r] = t);
        }),
        e
      );
    }),
      (aM.prototype.load = function () {
        if (!this.disabled) {
          var e = this.storage.parse(this.name);
          e && (this.props = ow.extend({}, e));
        }
      }),
      (aM.prototype.upgrade = function () {
        var e, t;
        this.storage === ow.localStorage
          ? ((e = ow.cookie.parse(this.name)),
            ow.cookie.remove(this.name),
            ow.cookie.remove(this.name, !0),
            e && this.register_once(e))
          : this.storage === ow.cookie &&
            ((t = ow.localStorage.parse(this.name)),
            ow.localStorage.remove(this.name),
            t && this.register_once(t));
      }),
      (aM.prototype.save = function () {
        this.disabled ||
          this.storage.set(
            this.name,
            oK(this.props),
            this.expire_days,
            this.cross_subdomain,
            this.secure,
            this.cross_site,
            this.cookie_domain,
          );
      }),
      (aM.prototype.load_prop = function (e) {
        return (this.load(), this.props[e]);
      }),
      (aM.prototype.remove = function () {
        (this.storage.remove(this.name, !1, this.cookie_domain),
          this.storage.remove(this.name, !0, this.cookie_domain));
      }),
      (aM.prototype.clear = function () {
        (this.remove(), (this.props = {}));
      }),
      (aM.prototype.register_once = function (e, t, r) {
        return (
          !!ow.isObject(e) &&
          (void 0 === t && (t = "None"),
          (this.expire_days = void 0 === r ? this.default_expiry : r),
          this.load(),
          ow.each(
            e,
            function (e, r) {
              (this.props.hasOwnProperty(r) && this.props[r] !== t) || (this.props[r] = e);
            },
            this,
          ),
          this.save(),
          !0)
        );
      }),
      (aM.prototype.register = function (e, t) {
        return (
          !!ow.isObject(e) &&
          ((this.expire_days = void 0 === t ? this.default_expiry : t),
          this.load(),
          ow.extend(this.props, e),
          this.save(),
          !0)
        );
      }),
      (aM.prototype.unregister = function (e) {
        (this.load(), e in this.props && (delete this.props[e], this.save()));
      }),
      (aM.prototype.update_search_keyword = function (e) {
        this.register(ow.info.searchInfo(e));
      }),
      (aM.prototype.update_referrer_info = function (e) {
        this.register_once(
          {
            $initial_referrer: e || "$direct",
            $initial_referring_domain: ow.info.referringDomain(e) || "$direct",
          },
          "",
        );
      }),
      (aM.prototype.get_referrer_info = function () {
        return ow.strip_empty_properties({
          $initial_referrer: this.props.$initial_referrer,
          $initial_referring_domain: this.props.$initial_referring_domain,
        });
      }),
      (aM.prototype.update_config = function (e) {
        ((this.default_expiry = this.expire_days = e.cookie_expiration),
          this.set_disabled(e.disable_persistence),
          this.set_cookie_domain(e.cookie_domain),
          this.set_cross_site(e.cross_site_cookie),
          this.set_cross_subdomain(e.cross_subdomain_cookie),
          this.set_secure(e.secure_cookie));
      }),
      (aM.prototype.set_disabled = function (e) {
        ((this.disabled = e), this.disabled ? this.remove() : this.save());
      }),
      (aM.prototype.set_cookie_domain = function (e) {
        e !== this.cookie_domain && (this.remove(), (this.cookie_domain = e), this.save());
      }),
      (aM.prototype.set_cross_site = function (e) {
        e !== this.cross_site && ((this.cross_site = e), this.remove(), this.save());
      }),
      (aM.prototype.set_cross_subdomain = function (e) {
        e !== this.cross_subdomain && ((this.cross_subdomain = e), this.remove(), this.save());
      }),
      (aM.prototype.get_cross_subdomain = function () {
        return this.cross_subdomain;
      }),
      (aM.prototype.set_secure = function (e) {
        e !== this.secure && ((this.secure = !!e), this.remove(), this.save());
      }),
      (aM.prototype._add_to_people_queue = function (e, t) {
        var r = this._get_queue_key(e),
          n = t[e],
          i = this._get_or_create_queue(ap),
          o = this._get_or_create_queue(ah),
          s = this._get_or_create_queue(ad),
          a = this._get_or_create_queue(af),
          c = this._get_or_create_queue(am),
          u = this._get_or_create_queue(a_, []),
          l = this._get_or_create_queue(ag, []);
        (r === aC
          ? (ow.extend(i, n),
            this._pop_from_people_queue(af, n),
            this._pop_from_people_queue(am, n),
            this._pop_from_people_queue(ad, n))
          : r === aE
            ? (ow.each(n, function (e, t) {
                t in o || (o[t] = e);
              }),
              this._pop_from_people_queue(ad, n))
            : r === aw
              ? ow.each(n, function (e) {
                  (ow.each([i, o, a, c], function (t) {
                    e in t && delete t[e];
                  }),
                    ow.each(l, function (t) {
                      e in t && delete t[e];
                    }),
                    (s[e] = !0));
                })
              : r === aI
                ? (ow.each(
                    n,
                    function (e, t) {
                      t in i ? (i[t] += e) : (t in a || (a[t] = 0), (a[t] += e));
                    },
                    this,
                  ),
                  this._pop_from_people_queue(ad, n))
                : r === aO
                  ? (ow.each(n, function (e, t) {
                      ow.isArray(e) &&
                        (t in c || (c[t] = []),
                        ow.each(e, function (e) {
                          ow.include(c[t], e) || c[t].push(e);
                        }));
                    }),
                    this._pop_from_people_queue(ad, n))
                  : r === ak
                    ? (u.push(n), this._pop_from_people_queue(ag, n))
                    : r === aS && (l.push(n), this._pop_from_people_queue(ad, n)),
          oI.log("MIXPANEL PEOPLE REQUEST (QUEUED, PENDING IDENTIFY):"),
          oI.log(t),
          this.save());
      }),
      (aM.prototype._pop_from_people_queue = function (e, t) {
        var r = this.props[this._get_queue_key(e)];
        ow.isUndefined(r) ||
          ow.each(
            t,
            function (t, n) {
              e === ag || e === a_
                ? ow.each(r, function (e) {
                    e[n] === t && delete e[n];
                  })
                : delete r[n];
            },
            this,
          );
      }),
      (aM.prototype.load_queue = function (e) {
        return this.load_prop(this._get_queue_key(e));
      }),
      (aM.prototype._get_queue_key = function (e) {
        return e === ap
          ? aC
          : e === ah
            ? aE
            : e === ad
              ? aw
              : e === af
                ? aI
                : e === ag
                  ? aS
                  : e === a_
                    ? ak
                    : e === am
                      ? aO
                      : void oI.error("Invalid queue:", e);
      }),
      (aM.prototype._get_or_create_queue = function (e, t) {
        var r = this._get_queue_key(e);
        return ((t = ow.isUndefined(t) ? {} : t), this.props[r] || (this.props[r] = t));
      }),
      (aM.prototype.set_event_timer = function (e, t) {
        var r = this.load_prop(aT) || {};
        ((r[e] = t), (this.props[aT] = r), this.save());
      }),
      (aM.prototype.remove_event_timer = function (e) {
        var t = (this.load_prop(aT) || {})[e];
        return (ow.isUndefined(t) || (delete this.props[aT][e], this.save()), t);
      }));
    var aL = function (e, t) {
        throw Error(e + " not available in this build.");
      },
      aP = function (e) {
        return e;
      },
      aD = "mixpanel",
      aN = "base64",
      aF = "$device:",
      aU = iO.XMLHttpRequest && "withCredentials" in new XMLHttpRequest(),
      aB = !aU && -1 === om.indexOf("MSIE") && -1 === om.indexOf("Mozilla"),
      aj = null;
    oh.sendBeacon &&
      (aj = function () {
        return oh.sendBeacon.apply(oh, arguments);
      });
    var aV = { track: "track/", engage: "engage/", groups: "groups/", record: "record/", flags: "flags/" },
      aG = {
        api_host: "https://api-js.mixpanel.com",
        api_hosts: {},
        api_routes: aV,
        api_extra_query_params: {},
        api_method: "POST",
        api_transport: "XHR",
        api_payload_format: aN,
        app_host: "https://mixpanel.com",
        autocapture: !1,
        cdn: "https://cdn.mxpnl.com",
        cross_site_cookie: !1,
        cross_subdomain_cookie: !0,
        error_reporter: oz,
        flags: !1,
        persistence: "cookie",
        persistence_name: "",
        cookie_domain: "",
        cookie_name: "",
        loaded: oz,
        mp_loader: null,
        track_marketing: !0,
        track_pageview: !1,
        skip_first_touch_marketing: !1,
        store_google: !0,
        stop_utm_persistence: !1,
        save_referrer: !0,
        test: !1,
        verbose: !1,
        img: !1,
        debug: !1,
        track_links_timeout: 300,
        cookie_expiration: 365,
        upgrade: !1,
        disable_persistence: !1,
        disable_cookie: !1,
        secure_cookie: !1,
        ip: !0,
        opt_out_tracking_by_default: !1,
        opt_out_persistence_by_default: !1,
        opt_out_tracking_persistence_type: "localStorage",
        opt_out_tracking_cookie_prefix: null,
        property_blacklist: [],
        xhr_headers: {},
        ignore_dnt: !1,
        batch_requests: !0,
        batch_size: 50,
        batch_flush_interval_ms: 5e3,
        batch_request_timeout_ms: 9e4,
        batch_autostart: !0,
        hooks: {},
        record_block_class: RegExp("^(mp-block|fs-exclude|amp-block|rr-block|ph-no-capture)$"),
        record_block_selector: "img, video, audio",
        record_canvas: !1,
        record_collect_fonts: !1,
        record_heatmap_data: !1,
        record_idle_timeout_ms: 18e5,
        record_mask_text_class: RegExp("^(mp-mask|fs-mask|amp-mask|rr-mask|ph-mask)$"),
        record_mask_text_selector: "*",
        record_max_ms: 864e5,
        record_min_ms: 0,
        record_sessions_percent: 0,
        recorder_src: "https://cdn.mxpnl.com/libs/mixpanel-recorder.min.js",
      },
      aW = !1,
      az = function () {},
      aK = function (e, t, r) {
        var n,
          i = r === aD ? m : m[r];
        if (i && 0 === g) n = i;
        else {
          if (i && !ow.isArray(i)) return void oI.error("You have already initialized " + r);
          n = new az();
        }
        if (
          ((n._cached_groups = {}),
          n._init(e, t, r),
          (n.people = new ab()),
          n.people._init(n),
          !n.get_config("skip_first_touch_marketing"))
        ) {
          var o = ow.info.campaignParams(null),
            s = {},
            a = !1;
          (ow.each(o, function (e, t) {
            ((s["initial_" + t] = e), e && (a = !0));
          }),
            a && n.people.set_once(s));
        }
        return (
          (oi.DEBUG = oi.DEBUG || n.get_config("debug")),
          !ow.isUndefined(i) &&
            ow.isArray(i) &&
            (n._execute_array.call(n.people, i.people), n._execute_array(i)),
          n
        );
      };
    ((az.prototype.init = function (e, t, r) {
      if (ow.isUndefined(r))
        return void this.report_error("You must name your new library: init(token, config, name)");
      if (r === aD)
        return void this.report_error(
          "You must initialize the main mixpanel object right after you include the Mixpanel js snippet",
        );
      var n = aK(e, t, r);
      return ((m[r] = n), n._loaded(), n);
    }),
      (az.prototype._init = function (e, t, r) {
        ((t = t || {}), (this.__loaded = !0), (this.config = {}));
        var n = {};
        if (
          ("api_payload_format" in t ||
            ((t.api_host || aG.api_host).match(/\.mixpanel\.com/) && (n.api_payload_format = "json")),
          this.set_config(
            ow.extend({}, aG, n, t, {
              name: r,
              token: e,
              callback_fn: (r === aD ? r : aD + "." + r) + "._jsc",
            }),
          ),
          (this._jsc = oz),
          (this.__dom_loaded_queue = []),
          (this.__request_queue = []),
          (this.__disabled_events = []),
          (this._flags = { disable_all_events: !1, identify_called: !1 }),
          (this.request_batchers = {}),
          (this._batch_requests = this.get_config("batch_requests")),
          this._batch_requests)
        )
          if (ow.localStorage.is_supported(!0) && aU) {
            if ((this.init_batchers(), aj && iO.addEventListener)) {
              var i = ow.bind(function () {
                this.request_batchers.events.stopped || this.request_batchers.events.flush({ unloading: !0 });
              }, this);
              (iO.addEventListener("pagehide", function (e) {
                e.persisted && i();
              }),
                iO.addEventListener("visibilitychange", function () {
                  "hidden" === od.visibilityState && i();
                }));
            }
          } else
            ((this._batch_requests = !1),
              oI.log("Turning off Mixpanel request-queueing; needs XHR and localStorage support"),
              ow.each(this.get_batcher_configs(), function (e) {
                (oI.log("Clearing batch queue " + e.queue_key), ow.localStorage.remove(e.queue_key));
              }));
        ((this.persistence = this.cookie = new aM(this.config)),
          (this.unpersisted_superprops = {}),
          this._gdpr_init());
        var o = ow.UUID();
        (this.get_distinct_id() || this.register_once({ distinct_id: aF + o, $device_id: o }, ""),
          (this.flags = new aa({
            getFullApiRoute: ow.bind(function () {
              return this.get_api_host("flags") + "/" + this.get_config("api_routes").flags;
            }, this),
            getConfigFunc: ow.bind(this.get_config, this),
            setConfigFunc: ow.bind(this.set_config, this),
            getPropertyFunc: ow.bind(this.get_property, this),
            trackingFunc: ow.bind(this.track, this),
          })),
          this.flags.init(),
          (this.flags = this.flags),
          (this.autocapture = new at(this)),
          this.autocapture.init(),
          this._init_tab_id(),
          this._check_and_start_session_recording());
      }),
      (az.prototype._init_tab_id = function () {
        if (this.get_config("disable_persistence"))
          oI.log("Tab ID initialization skipped due to disable_persistence config");
        else if (ow.sessionStorage.is_supported())
          try {
            var e = this.get_config("name") + "_" + this.get_config("token"),
              t = "mp_tab_id_" + e,
              r = "mp_gen_new_tab_id_" + e;
            ((ow.sessionStorage.get(r) || !ow.sessionStorage.get(t)) &&
              ow.sessionStorage.set(t, "$tab-" + ow.UUID()),
              ow.sessionStorage.set(r, "1"),
              (this.tab_id = ow.sessionStorage.get(t)),
              iO.addEventListener("beforeunload", function () {
                ow.sessionStorage.remove(r);
              }));
          } catch (e) {
            this.report_error("Error initializing tab id", e);
          }
        else this.report_error("Session storage is not supported, cannot keep track of unique tab ID.");
      }),
      (az.prototype.get_tab_id = function () {
        return this.tab_id || null;
      }),
      (az.prototype._should_load_recorder = function () {
        if (this.get_config("disable_persistence"))
          return (
            oI.log("Load recorder check skipped due to disable_persistence config"),
            Promise.resolve(!1)
          );
        var e = new oZ(o$),
          t = this.get_tab_id();
        return e
          .init()
          .then(function () {
            return e.getAll();
          })
          .then(function (e) {
            for (var r = 0; r < e.length; r++) if (su(e[r]) || e[r].tabId === t) return !0;
            return !1;
          })
          .catch(
            ow.bind(function (e) {
              this.report_error("Error checking recording registry", e);
            }, this),
          );
      }),
      (az.prototype._check_and_start_session_recording = o1(function (e) {
        if (!iO.MutationObserver)
          return void oI.critical("Browser does not support MutationObserver; skipping session recording");
        var t = ow.bind(function (e) {
            var t = ow.bind(function () {
              ((this._recorder = this._recorder || new iO.__mp_recorder(this)),
                this._recorder.resumeRecording(e));
            }, this);
            ow.isUndefined(iO.__mp_recorder) ? aL(this.get_config("recorder_src"), t) : t();
          }, this),
          r =
            this.get_config("record_sessions_percent") > 0 &&
            100 * Math.random() <= this.get_config("record_sessions_percent");
        e || r
          ? t(!0)
          : this._should_load_recorder().then(function (e) {
              e && t(!1);
            });
      })),
      (az.prototype.start_session_recording = function () {
        this._check_and_start_session_recording(!0);
      }),
      (az.prototype.stop_session_recording = function () {
        return this._recorder ? this._recorder.stopRecording() : Promise.resolve();
      }),
      (az.prototype.pause_session_recording = function () {
        return this._recorder ? this._recorder.pauseRecording() : Promise.resolve();
      }),
      (az.prototype.resume_session_recording = function () {
        return this._recorder ? this._recorder.resumeRecording() : Promise.resolve();
      }),
      (az.prototype.is_recording_heatmap_data = function () {
        return this._get_session_replay_id() && this.get_config("record_heatmap_data");
      }),
      (az.prototype.get_session_recording_properties = function () {
        var e = {},
          t = this._get_session_replay_id();
        return (t && (e.$mp_replay_id = t), e);
      }),
      (az.prototype.get_session_replay_url = function () {
        var e = null,
          t = this._get_session_replay_id();
        return (
          t &&
            (e =
              "https://mixpanel.com/projects/replay-redirect?" +
              ow.HTTPBuildQuery({
                replay_id: t,
                distinct_id: this.get_distinct_id(),
                token: this.get_config("token"),
              })),
          e
        );
      }),
      (az.prototype._get_session_replay_id = function () {
        var e = null;
        return (this._recorder && (e = this._recorder.replayId), e || null);
      }),
      (az.prototype.__get_recorder = function () {
        return this._recorder;
      }),
      (az.prototype._loaded = function () {
        if (
          (this.get_config("loaded")(this),
          this._set_default_superprops(),
          this.people.set_once(this.persistence.get_referrer_info()),
          this.get_config("store_google") && this.get_config("stop_utm_persistence"))
        ) {
          var e = ow.info.campaignParams(null);
          ow.each(
            e,
            function (e, t) {
              this.unregister(t);
            }.bind(this),
          );
        }
      }),
      (az.prototype._set_default_superprops = function () {
        (this.persistence.update_search_keyword(od.referrer),
          this.get_config("store_google") &&
            !this.get_config("stop_utm_persistence") &&
            this.register(ow.info.campaignParams()),
          this.get_config("save_referrer") && this.persistence.update_referrer_info(od.referrer));
      }),
      (az.prototype._dom_loaded = function () {
        (ow.each(
          this.__dom_loaded_queue,
          function (e) {
            this._track_dom.apply(this, e);
          },
          this,
        ),
          this.has_opted_out_tracking() ||
            ow.each(
              this.__request_queue,
              function (e) {
                this._send_request.apply(this, e);
              },
              this,
            ),
          delete this.__dom_loaded_queue,
          delete this.__request_queue);
      }),
      (az.prototype._track_dom = function (e, t) {
        if (this.get_config("img"))
          return (this.report_error("You can't use DOM tracking functions with img = true."), !1);
        if (!aW) return (this.__dom_loaded_queue.push([e, t]), !1);
        var r = new e().init(this);
        return r.track.apply(r, t);
      }),
      (az.prototype._prepare_callback = function (e, t) {
        if (ow.isUndefined(e)) return null;
        if (aU)
          return function (r) {
            e(r, t);
          };
        var r = this._jsc,
          n = "" + Math.floor(1e8 * Math.random()),
          i = this.get_config("callback_fn") + "[" + n + "]";
        return (
          (r[n] = function (i) {
            (delete r[n], e(i, t));
          }),
          i
        );
      }),
      (az.prototype._send_request = function (e, t, r, n) {
        var i = !0;
        if (aB) return (this.__request_queue.push(arguments), i);
        var o = {
            method: this.get_config("api_method"),
            transport: this.get_config("api_transport"),
            verbose: this.get_config("verbose"),
          },
          s = null;
        (!n && (ow.isFunction(r) || "string" == typeof r) && ((n = r), (r = null)),
          (r = ow.extend(o, r || {})),
          aU || (r.method = "GET"));
        var a = "POST" === r.method,
          c = aj && a && "sendbeacon" === r.transport.toLowerCase(),
          u = r.verbose;
        (t.verbose && (u = !0),
          this.get_config("test") && (t.test = 1),
          u && (t.verbose = 1),
          this.get_config("img") && (t.img = 1),
          !aU && (n ? (t.callback = n) : (u || this.get_config("test")) && (t.callback = "(function(){})")),
          (t.ip = +!!this.get_config("ip")),
          (t._ = new Date().getTime().toString()),
          a && ((s = "data=" + encodeURIComponent(t.data)), delete t.data),
          ow.extend(t, this.get_config("api_extra_query_params")),
          (e += "?" + ow.HTTPBuildQuery(t)));
        var l = this;
        if ("img" in t) {
          var p = od.createElement("img");
          ((p.src = e), od.body.appendChild(p));
        } else if (c) {
          try {
            i = aj(e, s);
          } catch (e) {
            (l.report_error(e), (i = !1));
          }
          try {
            n && n(+!!i);
          } catch (e) {
            l.report_error(e);
          }
        } else if (aU)
          try {
            var h = new XMLHttpRequest();
            h.open(r.method, e, !0);
            var d = this.get_config("xhr_headers");
            if (
              (a && (d["Content-Type"] = "application/x-www-form-urlencoded"),
              ow.each(d, function (e, t) {
                h.setRequestHeader(t, e);
              }),
              r.timeout_ms && void 0 !== h.timeout)
            ) {
              h.timeout = r.timeout_ms;
              var f = new Date().getTime();
            }
            ((h.withCredentials = !0),
              (h.onreadystatechange = function () {
                if (4 === h.readyState) {
                  if (200 === h.status) {
                    if (n)
                      if (u) {
                        try {
                          e = ow.JSONDecode(h.responseText);
                        } catch (t) {
                          if ((l.report_error(t), !r.ignore_json_errors)) return;
                          e = h.responseText;
                        }
                        n(e);
                      } else n(Number(h.responseText));
                  } else if (
                    ((t =
                      h.timeout && !h.status && new Date().getTime() - f >= h.timeout
                        ? "timeout"
                        : "Bad HTTP status: " + h.status + " " + h.statusText),
                    l.report_error(t),
                    n)
                  )
                    if (u) {
                      var e,
                        t,
                        i = h.responseHeaders || {};
                      n({ status: 0, httpStatusCode: h.status, error: t, retryAfter: i["Retry-After"] });
                    } else n(0);
                }
              }),
              h.send(s));
          } catch (e) {
            (l.report_error(e), (i = !1));
          }
        else {
          var g = od.createElement("script");
          ((g.type = "text/javascript"), (g.async = !0), (g.defer = !0), (g.src = e));
          var m = od.getElementsByTagName("script")[0];
          m.parentNode.insertBefore(g, m);
        }
        return i;
      }),
      (az.prototype._execute_array = function (e) {
        var t,
          r = [],
          n = [],
          i = [];
        ow.each(
          e,
          function (e) {
            e &&
              ((t = e[0]),
              ow.isArray(t)
                ? i.push(e)
                : "function" == typeof e
                  ? e.call(this)
                  : ow.isArray(e) && "alias" === t
                    ? r.push(e)
                    : ow.isArray(e) && -1 !== t.indexOf("track") && "function" == typeof this[t]
                      ? i.push(e)
                      : n.push(e));
          },
          this,
        );
        var o = function (e, t) {
          ow.each(
            e,
            function (e) {
              if (ow.isArray(e[0])) {
                var r = t;
                ow.each(e, function (e) {
                  r = r[e[0]].apply(r, e.slice(1));
                });
              } else this[e[0]].apply(this, e.slice(1));
            },
            t,
          );
        };
        (o(r, this), o(n, this), o(i, this));
      }),
      (az.prototype.are_batchers_initialized = function () {
        return !!this.request_batchers.events;
      }),
      (az.prototype.get_batcher_configs = function () {
        var e = "__mpq_" + this.get_config("token");
        return (
          (this._batcher_configs = this._batcher_configs || {
            events: { type: "events", api_name: "track", queue_key: e + "_ev" },
            people: { type: "people", api_name: "engage", queue_key: e + "_pp" },
            groups: { type: "groups", api_name: "groups", queue_key: e + "_gr" },
          }),
          this._batcher_configs
        );
      }),
      (az.prototype.init_batchers = function () {
        if (!this.are_batchers_initialized()) {
          var e = ow.bind(function (e) {
              return new sc(e.queue_key, {
                libConfig: this.config,
                errorReporter: this.get_config("error_reporter"),
                sendRequestFunc: ow.bind(function (t, r, n) {
                  var i = this.get_config("api_routes");
                  this._send_request(
                    this.get_api_host(e.api_name) + "/" + i[e.api_name],
                    this._encode_data_for_request(t),
                    r,
                    this._prepare_callback(n, t),
                  );
                }, this),
                beforeSendHook: ow.bind(function (t) {
                  return this._run_hook("before_send_" + e.type, t);
                }, this),
                stopAllBatchingFunc: ow.bind(this.stop_batch_senders, this),
                usePersistence: !0,
              });
            }, this),
            t = this.get_batcher_configs();
          this.request_batchers = { events: e(t.events), people: e(t.people), groups: e(t.groups) };
        }
        this.get_config("batch_autostart") && this.start_batch_senders();
      }),
      (az.prototype.start_batch_senders = function () {
        ((this._batchers_were_started = !0),
          this.are_batchers_initialized() &&
            ((this._batch_requests = !0),
            ow.each(this.request_batchers, function (e) {
              e.start();
            })));
      }),
      (az.prototype.stop_batch_senders = function () {
        ((this._batch_requests = !1),
          ow.each(this.request_batchers, function (e) {
            (e.stop(), e.clear());
          }));
      }),
      (az.prototype.push = function (e) {
        this._execute_array([e]);
      }),
      (az.prototype.disable = function (e) {
        void 0 === e
          ? (this._flags.disable_all_events = !0)
          : (this.__disabled_events = this.__disabled_events.concat(e));
      }),
      (az.prototype._encode_data_for_request = function (e) {
        var t = oK(e);
        return (this.get_config("api_payload_format") === aN && (t = ow.base64Encode(t)), { data: t });
      }),
      (az.prototype._track_or_batch = function (e, t) {
        var r = ow.truncate(e.data, 255),
          n = e.endpoint,
          i = e.batcher,
          o = e.should_send_immediately,
          s = e.send_request_options || {};
        t = t || oz;
        var a = !0,
          c = ow.bind(function () {
            return (s.skip_hooks || (r = this._run_hook("before_send_" + e.type, r)), r)
              ? (oI.log("MIXPANEL REQUEST:"),
                oI.log(r),
                this._send_request(n, this._encode_data_for_request(r), s, this._prepare_callback(t, r)))
              : null;
          }, this);
        return (
          this._batch_requests && !o
            ? i.enqueue(r).then(function (e) {
                e ? t(1, r) : c();
              })
            : (a = c()),
          a && r
        );
      }),
      (az.prototype.track = o1(function (e, t, r, n) {
        n || "function" != typeof r || ((n = r), (r = null));
        var i = (r = r || {}).transport;
        i && (r.transport = i);
        var o = r.send_immediately;
        if (("function" != typeof n && (n = oz), ow.isUndefined(e)))
          return void this.report_error("No event name provided to mixpanel.track");
        if (this._event_is_disabled(e)) return void n(0);
        (t = ow.extend({}, t)).token = this.get_config("token");
        var s = this.persistence.remove_event_timer(e);
        if (!ow.isUndefined(s)) {
          var a = new Date().getTime() - s;
          t.$duration = parseFloat((a / 1e3).toFixed(3));
        }
        this._set_default_superprops();
        var c = this.get_config("track_marketing") ? ow.info.marketingParams() : {};
        t = ow.extend(
          {},
          ow.info.properties({ mp_loader: this.get_config("mp_loader") }),
          c,
          this.persistence.properties(),
          this.unpersisted_superprops,
          this.get_session_recording_properties(),
          t,
        );
        var u = this.get_config("property_blacklist");
        ow.isArray(u)
          ? ow.each(u, function (e) {
              delete t[e];
            })
          : this.report_error("Invalid value for property_blacklist config: " + u);
        var l = { event: e, properties: t };
        return this._track_or_batch(
          {
            type: "events",
            data: l,
            endpoint: this.get_api_host("events") + "/" + this.get_config("api_routes").track,
            batcher: this.request_batchers.events,
            should_send_immediately: o,
            send_request_options: r,
          },
          n,
        );
      })),
      (az.prototype.set_group = o1(function (e, t, r) {
        ow.isArray(t) || (t = [t]);
        var n = {};
        return ((n[e] = t), this.register(n), this.people.set(e, t, r));
      })),
      (az.prototype.add_group = o1(function (e, t, r) {
        var n = this.get_property(e),
          i = {};
        return (
          void 0 === n
            ? ((i[e] = [t]), this.register(i))
            : -1 === n.indexOf(t) && (n.push(t), (i[e] = n), this.register(i)),
          this.people.union(e, t, r)
        );
      })),
      (az.prototype.remove_group = o1(function (e, t, r) {
        var n = this.get_property(e);
        if (void 0 !== n) {
          var i = n.indexOf(t);
          (i > -1 && (n.splice(i, 1), this.register({ group_key: n })), 0 === n.length && this.unregister(e));
        }
        return this.people.remove(e, t, r);
      })),
      (az.prototype.track_with_groups = o1(function (e, t, r, n) {
        var i = ow.extend({}, t || {});
        return (
          ow.each(r, function (e, t) {
            null != e && (i[t] = e);
          }),
          this.track(e, i, n)
        );
      })),
      (az.prototype._create_map_key = function (e, t) {
        return e + "_" + JSON.stringify(t);
      }),
      (az.prototype._remove_group_from_cache = function (e, t) {
        delete this._cached_groups[this._create_map_key(e, t)];
      }),
      (az.prototype.get_group = function (e, t) {
        var r = this._create_map_key(e, t),
          n = this._cached_groups[r];
        return (
          (void 0 === n || n._group_key !== e || n._group_id !== t) &&
            ((n = new ay())._init(this, e, t), (this._cached_groups[r] = n)),
          n
        );
      }),
      (az.prototype.track_pageview = o1(function (e, t) {
        "object" != typeof e && (e = {});
        var r = (t = t || {}).event_name || "$mp_web_page_view",
          n = ow.extend(ow.info.mpPageViewProperties(), ow.info.campaignParams(), ow.info.clickParams()),
          i = ow.extend({}, n, e);
        return this.track(r, i);
      })),
      (az.prototype.track_links = function () {
        return this._track_dom.call(this, au, arguments);
      }),
      (az.prototype.track_forms = function () {
        return this._track_dom.call(this, al, arguments);
      }),
      (az.prototype.time_event = function (e) {
        ow.isUndefined(e)
          ? this.report_error("No event name provided to mixpanel.time_event")
          : this._event_is_disabled(e) || this.persistence.set_event_timer(e, new Date().getTime());
      }));
    var aq = { persistent: !0 },
      aY = function (e) {
        var t;
        return ((t = ow.isObject(e) ? e : ow.isUndefined(e) ? {} : { days: e }), ow.extend({}, aq, t));
      };
    ((az.prototype.register = function (e, t) {
      var r = aY(t);
      r.persistent ? this.persistence.register(e, r.days) : ow.extend(this.unpersisted_superprops, e);
    }),
      (az.prototype.register_once = function (e, t, r) {
        var n = aY(r);
        n.persistent
          ? this.persistence.register_once(e, t, n.days)
          : (void 0 === t && (t = "None"),
            ow.each(
              e,
              function (e, r) {
                (this.unpersisted_superprops.hasOwnProperty(r) && this.unpersisted_superprops[r] !== t) ||
                  (this.unpersisted_superprops[r] = e);
              },
              this,
            ));
      }),
      (az.prototype.unregister = function (e, t) {
        (t = aY(t)).persistent ? this.persistence.unregister(e) : delete this.unpersisted_superprops[e];
      }),
      (az.prototype._register_single = function (e, t) {
        var r = {};
        ((r[e] = t), this.register(r));
      }),
      (az.prototype.identify = function (e, t, r, n, i, o, s, a) {
        var c = this.get_distinct_id();
        if (e && c !== e) {
          if ("string" == typeof e && 0 === e.indexOf(aF))
            return (this.report_error("distinct_id cannot have $device: prefix"), -1);
          this.register({ $user_id: e });
        }
        (this.get_property("$device_id") ||
          this.register_once({ $had_persisted_distinct_id: !0, $device_id: c }, ""),
          e !== c && e !== this.get_property(aR) && (this.unregister(aR), this.register({ distinct_id: e })),
          (this._flags.identify_called = !0),
          this.people._flush(t, r, n, i, o, s, a),
          e !== c && this.track("$identify", { distinct_id: e, $anon_distinct_id: c }, { skip_hooks: !0 }),
          e !== c && this.flags.fetchFlags());
      }),
      (az.prototype.reset = function () {
        (this.stop_session_recording(), this.persistence.clear(), (this._flags.identify_called = !1));
        var e = ow.UUID();
        (this.register_once({ distinct_id: aF + e, $device_id: e }, ""),
          this._check_and_start_session_recording());
      }),
      (az.prototype.get_distinct_id = function () {
        return this.get_property("distinct_id");
      }),
      (az.prototype.alias = function (e, t) {
        if (e === this.get_property(aA))
          return (this.report_error("Attempting to create alias for existing People user - aborting."), -2);
        var r = this;
        return (ow.isUndefined(t) && (t = this.get_distinct_id()), e !== t)
          ? (this._register_single(aR, e),
            this.track("$create_alias", { alias: e, distinct_id: t }, { skip_hooks: !0 }, function () {
              r.identify(e);
            }))
          : (this.report_error("alias matches current distinct_id - skipping api call."),
            this.identify(e),
            -1);
      }),
      (az.prototype.name_tag = function (e) {
        this._register_single("mp_name_tag", e);
      }),
      (az.prototype.set_config = function (e) {
        ow.isObject(e) &&
          (ow.extend(this.config, e),
          e.batch_size &&
            ow.each(this.request_batchers, function (e) {
              e.resetBatchSize();
            }),
          this.get_config("persistence_name") || (this.config.persistence_name = this.config.cookie_name),
          this.get_config("disable_persistence") ||
            (this.config.disable_persistence = this.config.disable_cookie),
          this.persistence && this.persistence.update_config(this.config),
          (oi.DEBUG = oi.DEBUG || this.get_config("debug")),
          ("autocapture" in e || "record_heatmap_data" in e) && this.autocapture && this.autocapture.init());
      }),
      (az.prototype.get_config = function (e) {
        return this.config[e];
      }),
      (az.prototype._run_hook = function (e) {
        var t = (this.config.hooks[e] || aP).apply(this, oc.call(arguments, 1));
        return (void 0 === t && (this.report_error(e + " hook did not return a value"), (t = null)), t);
      }),
      (az.prototype.get_property = function (e) {
        return this.persistence.load_prop([e]);
      }),
      (az.prototype.get_api_host = function (e) {
        return this.get_config("api_hosts")[e] || this.get_config("api_host");
      }),
      (az.prototype.toString = function () {
        var e = this.get_config("name");
        return (e !== aD && (e = aD + "." + e), e);
      }),
      (az.prototype._event_is_disabled = function (e) {
        return ow.isBlockedUA(om) || this._flags.disable_all_events || ow.include(this.__disabled_events, e);
      }),
      (az.prototype._gdpr_init = function () {
        ("localStorage" === this.get_config("opt_out_tracking_persistence_type") &&
          ow.localStorage.is_supported() &&
          (!this.has_opted_in_tracking() &&
            this.has_opted_in_tracking({ persistence_type: "cookie" }) &&
            this.opt_in_tracking({ enable_persistence: !1 }),
          !this.has_opted_out_tracking() &&
            this.has_opted_out_tracking({ persistence_type: "cookie" }) &&
            this.opt_out_tracking({ clear_persistence: !1 }),
          this.clear_opt_in_out_tracking({ persistence_type: "cookie", enable_persistence: !1 })),
          this.has_opted_out_tracking()
            ? this._gdpr_update_persistence({ clear_persistence: !0 })
            : !this.has_opted_in_tracking() &&
              (this.get_config("opt_out_tracking_by_default") || ow.cookie.get("mp_optout")) &&
              (ow.cookie.remove("mp_optout"),
              this.opt_out_tracking({
                clear_persistence: this.get_config("opt_out_persistence_by_default"),
              })));
      }),
      (az.prototype._gdpr_update_persistence = function (e) {
        var t;
        if (e && e.clear_persistence) t = !0;
        else {
          if (!e || !e.enable_persistence) return;
          t = !1;
        }
        (this.get_config("disable_persistence") ||
          this.persistence.disabled === t ||
          this.persistence.set_disabled(t),
          t
            ? (this.stop_batch_senders(), this.stop_session_recording())
            : this._batchers_were_started && this.start_batch_senders());
      }),
      (az.prototype._gdpr_call_func = function (e, t) {
        return (
          (t = ow.extend(
            {
              track: ow.bind(this.track, this),
              persistence_type: this.get_config("opt_out_tracking_persistence_type"),
              cookie_prefix: this.get_config("opt_out_tracking_cookie_prefix"),
              cookie_expiration: this.get_config("cookie_expiration"),
              cross_site_cookie: this.get_config("cross_site_cookie"),
              cross_subdomain_cookie: this.get_config("cross_subdomain_cookie"),
              cookie_domain: this.get_config("cookie_domain"),
              secure_cookie: this.get_config("secure_cookie"),
              ignore_dnt: this.get_config("ignore_dnt"),
            },
            t,
          )),
          ow.localStorage.is_supported() || (t.persistence_type = "cookie"),
          e(this.get_config("token"), {
            track: t.track,
            trackEventName: t.track_event_name,
            trackProperties: t.track_properties,
            persistenceType: t.persistence_type,
            persistencePrefix: t.cookie_prefix,
            cookieDomain: t.cookie_domain,
            cookieExpiration: t.cookie_expiration,
            crossSiteCookie: t.cross_site_cookie,
            crossSubdomainCookie: t.cross_subdomain_cookie,
            secureCookie: t.secure_cookie,
            ignoreDnt: t.ignore_dnt,
          })
        );
      }),
      (az.prototype.opt_in_tracking = function (e) {
        ((e = ow.extend({ enable_persistence: !0 }, e)),
          this._gdpr_call_func(oJ, e),
          this._gdpr_update_persistence(e));
      }),
      (az.prototype.opt_out_tracking = function (e) {
        ((e = ow.extend({ clear_persistence: !0, delete_user: !0 }, e)).delete_user &&
          this.people &&
          this.people._identify_called() &&
          (this.people.delete_user(), this.people.clear_charges()),
          this._gdpr_call_func(oX, e),
          this._gdpr_update_persistence(e));
      }),
      (az.prototype.has_opted_in_tracking = function (e) {
        return this._gdpr_call_func(oQ, e);
      }),
      (az.prototype.has_opted_out_tracking = function (e) {
        return this._gdpr_call_func(o0, e);
      }),
      (az.prototype.clear_opt_in_out_tracking = function (e) {
        ((e = ow.extend({ enable_persistence: !0 }, e)),
          this._gdpr_call_func(o4, e),
          this._gdpr_update_persistence(e));
      }),
      (az.prototype.report_error = function (e, t) {
        oI.error.apply(oI.error, arguments);
        try {
          (t || e instanceof Error || (e = Error(e)), this.get_config("error_reporter")(e, t));
        } catch (e) {
          oI.error(e);
        }
      }),
      (az.prototype.init = az.prototype.init),
      (az.prototype.reset = az.prototype.reset),
      (az.prototype.disable = az.prototype.disable),
      (az.prototype.time_event = az.prototype.time_event),
      (az.prototype.track = az.prototype.track),
      (az.prototype.track_links = az.prototype.track_links),
      (az.prototype.track_forms = az.prototype.track_forms),
      (az.prototype.track_pageview = az.prototype.track_pageview),
      (az.prototype.register = az.prototype.register),
      (az.prototype.register_once = az.prototype.register_once),
      (az.prototype.unregister = az.prototype.unregister),
      (az.prototype.identify = az.prototype.identify),
      (az.prototype.alias = az.prototype.alias),
      (az.prototype.name_tag = az.prototype.name_tag),
      (az.prototype.set_config = az.prototype.set_config),
      (az.prototype.get_config = az.prototype.get_config),
      (az.prototype.get_api_host = az.prototype.get_api_host),
      (az.prototype.get_property = az.prototype.get_property),
      (az.prototype.get_distinct_id = az.prototype.get_distinct_id),
      (az.prototype.toString = az.prototype.toString),
      (az.prototype.opt_out_tracking = az.prototype.opt_out_tracking),
      (az.prototype.opt_in_tracking = az.prototype.opt_in_tracking),
      (az.prototype.has_opted_out_tracking = az.prototype.has_opted_out_tracking),
      (az.prototype.has_opted_in_tracking = az.prototype.has_opted_in_tracking),
      (az.prototype.clear_opt_in_out_tracking = az.prototype.clear_opt_in_out_tracking),
      (az.prototype.get_group = az.prototype.get_group),
      (az.prototype.set_group = az.prototype.set_group),
      (az.prototype.add_group = az.prototype.add_group),
      (az.prototype.remove_group = az.prototype.remove_group),
      (az.prototype.track_with_groups = az.prototype.track_with_groups),
      (az.prototype.start_batch_senders = az.prototype.start_batch_senders),
      (az.prototype.stop_batch_senders = az.prototype.stop_batch_senders),
      (az.prototype.start_session_recording = az.prototype.start_session_recording),
      (az.prototype.stop_session_recording = az.prototype.stop_session_recording),
      (az.prototype.pause_session_recording = az.prototype.pause_session_recording),
      (az.prototype.resume_session_recording = az.prototype.resume_session_recording),
      (az.prototype.get_session_recording_properties = az.prototype.get_session_recording_properties),
      (az.prototype.get_session_replay_url = az.prototype.get_session_replay_url),
      (az.prototype.get_tab_id = az.prototype.get_tab_id),
      (az.prototype.DEFAULT_API_ROUTES = aV),
      (az.prototype.__get_recorder = az.prototype.__get_recorder),
      (aM.prototype.properties = aM.prototype.properties),
      (aM.prototype.update_search_keyword = aM.prototype.update_search_keyword),
      (aM.prototype.update_referrer_info = aM.prototype.update_referrer_info),
      (aM.prototype.get_cross_subdomain = aM.prototype.get_cross_subdomain),
      (aM.prototype.clear = aM.prototype.clear));
    var a$ = {},
      aH = function () {
        (ow.each(a$, function (e, t) {
          t !== aD && (m[t] = e);
        }),
          (m._ = ow));
      },
      aZ =
        ((aL = function (e, t) {
          t();
        }),
        (g = 0),
        ((m = new az()).init = function (e, t, r) {
          if (r) return (m[r] || ((m[r] = a$[r] = aK(e, t, r)), m[r]._loaded()), m[r]);
          var n = m;
          (a$[aD] ? (n = a$[aD]) : e && ((n = aK(e, t, aD))._loaded(), (a$[aD] = n)),
            (m = n),
            1 === g && (iO[aD] = m),
            aH());
        }),
        m.init(),
        (function () {
          function e() {
            e.done ||
              ((e.done = !0),
              (aW = !0),
              (aB = !1),
              ow.each(a$, function (e) {
                e._dom_loaded();
              }));
          }
          if (od.addEventListener)
            "complete" === od.readyState ? e() : od.addEventListener("DOMContentLoaded", e, !1);
          else if (od.attachEvent) {
            od.attachEvent("onreadystatechange", e);
            var t = !1;
            try {
              t = null === iO.frameElement;
            } catch (e) {}
            od.documentElement.doScroll &&
              t &&
              (function t() {
                try {
                  od.documentElement.doScroll("left");
                } catch (e) {
                  setTimeout(t, 1);
                  return;
                }
                e();
              })();
          }
          ow.register_event(iO, "load", e, !0);
        })(),
        m),
      aJ = e.i(5117);
    e.i(756503);
    var aX = e.i(542516);
    let aQ = new (class {
      constructor() {
        try {
          const e = (0, aJ.getClientAnalyticsConsent)().allowed;
          aZ.init(`${aX.envClient.NEXT_PUBLIC_MIXPANEL_PROJECT_TOKEN}`, {
            debug: "production" !== aX.envClient.NEXT_PUBLIC_NODE_ENV,
            track_pageview: !1,
            persistence: "localStorage",
            api_host: `${aX.envClient.NEXT_PUBLIC_MIXPANEL_API_HOST}`,
            record_collect_fonts: !1,
            record_block_selector: "",
            record_mask_text_selector: 'input, textarea, [contenteditable="true"]',
            ignore_dnt: !0,
            record_heatmap_data: !0,
            record_sessions_percent: 0.5 * !!e,
          });
        } catch {
          return;
        }
      }
      isAllowed() {
        return (0, aJ.getClientAnalyticsConsent)().allowed;
      }
      optIn() {
        this.startSessionRecording();
      }
      optOut() {
        this.stopSessionRecording();
      }
      identify(e) {
        aZ.identify(e);
      }
      peopleSetOnce(e) {
        this.isAllowed() && aZ.people.set_once(e);
      }
      peopleSet(e) {
        this.isAllowed() && aZ.people.set(e);
      }
      register(e) {
        aZ.register(e);
      }
      peopleGetDistinctId() {
        let e = aZ.get_distinct_id();
        return e ? e.split(":").at(-1) : "";
      }
      peopleGetProperty(e) {
        return aZ.get_property(e);
      }
      track(e) {
        if (!this.isAllowed()) return;
        let { eventName: t, props: r } = e;
        aZ.track(t, r);
      }
      startSessionRecording() {
        if (!this.isAllowed()) return;
        let e = aZ.get_session_recording_properties();
        ("$mp_replay_id" in e && e.$mp_replay_id) || aZ.start_session_recording();
      }
      stopSessionRecording() {
        aZ.stop_session_recording();
      }
      reset() {
        aZ.reset();
      }
    })();
    (e.s(["default", 0, aQ], 86497), e.s([], 569311), e.s(["mixpanelClient", 0, aQ], 896855));
  },
  999126,
  548248,
  (e) => {
    "use strict";
    var t = e.i(102232);
    (e.s(
      [
        "debugUtil",
        0,
        (e) => {
          let { text: r, value: n, isActiveOnProd: i = !1 } = e;
          i &&
            (0, t.default)({ timestamp: t.default.stdTimeFunctions.epochTime }).info(
              `[${r}]: ${JSON.stringify(n, null, 2)}`,
            );
        },
      ],
      548248,
    ),
      e.s([], 999126));
  },
]);
