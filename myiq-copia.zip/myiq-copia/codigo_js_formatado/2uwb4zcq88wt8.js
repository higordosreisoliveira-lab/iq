(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  5898,
  976218,
  701708,
  (e) => {
    "use strict";
    var [t, a] = (0, e.i(526823).createContext)({
      name: "CardContext",
      strict: !0,
      errorMessage:
        "useCardContext: `context` is undefined. Seems you forgot to wrap component within <Card />",
    });
    e.s(["CardProvider", 0, t, "useCardContext", 0, a], 976218);
    var s = e.i(984898),
      r = e.i(779754),
      n = (0, s.tv)({
        slots: {
          base: [
            "flex",
            "flex-col",
            "relative",
            "overflow-hidden",
            "h-auto",
            "outline-solid outline-transparent",
            "text-foreground",
            "box-border",
            "bg-content1",
            ...r.dataFocusVisibleClasses,
          ],
          header: [
            "flex",
            "p-3",
            "z-10",
            "w-full",
            "justify-start",
            "items-center",
            "shrink-0",
            "overflow-inherit",
            "color-inherit",
            "subpixel-antialiased",
          ],
          body: [
            "relative",
            "flex",
            "flex-1",
            "w-full",
            "p-3",
            "flex-auto",
            "flex-col",
            "place-content-inherit",
            "align-items-inherit",
            "h-auto",
            "break-words",
            "text-left",
            "overflow-y-auto",
            "subpixel-antialiased",
          ],
          footer: [
            "p-3",
            "h-auto",
            "flex",
            "w-full",
            "items-center",
            "overflow-hidden",
            "color-inherit",
            "subpixel-antialiased",
          ],
        },
        variants: {
          shadow: {
            none: { base: "shadow-none" },
            sm: { base: "shadow-small" },
            md: { base: "shadow-medium" },
            lg: { base: "shadow-large" },
          },
          radius: {
            none: { base: "rounded-none", header: "rounded-none", footer: "rounded-none" },
            sm: { base: "rounded-small", header: "rounded-t-small", footer: "rounded-b-small" },
            md: { base: "rounded-medium", header: "rounded-t-medium", footer: "rounded-b-medium" },
            lg: { base: "rounded-large", header: "rounded-t-large", footer: "rounded-b-large" },
          },
          fullWidth: { true: { base: "w-full" } },
          isHoverable: { true: { base: "data-[hover=true]:bg-content2 dark:data-[hover=true]:bg-content2" } },
          isPressable: { true: { base: "cursor-pointer" } },
          isBlurred: {
            true: {
              base: [
                "bg-background/80",
                "dark:bg-background/20",
                "backdrop-blur-md",
                "backdrop-saturate-150",
              ],
            },
          },
          isFooterBlurred: {
            true: { footer: ["bg-background/10", "backdrop-blur", "backdrop-saturate-150"] },
          },
          isDisabled: { true: { base: "opacity-disabled cursor-not-allowed" } },
          disableAnimation: {
            true: "",
            false: { base: "transition-transform-background motion-reduce:transition-none" },
          },
        },
        compoundVariants: [
          { isPressable: !0, class: "data-[pressed=true]:scale-[0.97] tap-highlight-transparent" },
        ],
        defaultVariants: {
          radius: "lg",
          shadow: "md",
          fullWidth: !1,
          isHoverable: !1,
          isPressable: !1,
          isDisabled: !1,
          isFooterBlurred: !1,
        },
      }),
      l = e.i(271645),
      i = e.i(429427),
      o = e.i(371330),
      c = e.i(868319),
      d = e.i(273830),
      u = e.i(595494),
      m = e.i(75540),
      p = e.i(919477),
      g = e.i(620253),
      h = e.i(984675);
    function f(e) {
      var t, a, s, r;
      let f = (0, u.useProviderContext)(),
        [b, v] = (0, d.mapPropsVariants)(e, n.variantKeys),
        {
          ref: x,
          as: w,
          children: E,
          onClick: C,
          onPress: S,
          autoFocus: _,
          className: y,
          classNames: R,
          allowTextSelectionOnPress: N = !0,
          ...I
        } = b,
        k = (0, g.useDOMRef)(x),
        A = w || (e.isPressable ? "button" : "div"),
        T = "string" == typeof A,
        P = null != (a = null != (t = e.disableAnimation) ? t : null == f ? void 0 : f.disableAnimation) && a,
        j = null != (r = null != (s = e.disableRipple) ? s : null == f ? void 0 : f.disableRipple) && r,
        O = (0, m.clsx)(null == R ? void 0 : R.base, y),
        { onClear: L, onPress: B, ripples: M } = (0, h.useRipple)(),
        U = (0, l.useCallback)(
          (e) => {
            j || P || (k.current && B(e));
          },
          [j, P, k, B],
        ),
        { buttonProps: V, isPressed: z } = (0, c.useAriaButton)(
          {
            onPress: (0, m.chain)(S, U),
            elementType: w,
            isDisabled: !e.isPressable,
            onClick: C,
            allowTextSelectionOnPress: N,
            ...I,
          },
          k,
        ),
        { hoverProps: Q, isHovered: D } = (0, o.useHover)({ isDisabled: !e.isHoverable, ...I }),
        { isFocusVisible: F, isFocused: Z, focusProps: H } = (0, i.useFocusRing)({ autoFocus: _ }),
        W = (0, l.useMemo)(() => n({ ...v, disableAnimation: P }), [(0, m.objectToDeps)(v), P]),
        K = (0, l.useMemo)(
          () => ({
            slots: W,
            classNames: R,
            disableAnimation: P,
            isDisabled: e.isDisabled,
            isFooterBlurred: e.isFooterBlurred,
            fullWidth: e.fullWidth,
          }),
          [W, R, e.isDisabled, e.isFooterBlurred, P, e.fullWidth],
        ),
        Y = (0, l.useCallback)(
          function () {
            let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return {
              ref: k,
              className: W.base({ class: O }),
              tabIndex: e.isPressable ? 0 : -1,
              "data-hover": (0, m.dataAttr)(D),
              "data-pressed": (0, m.dataAttr)(z),
              "data-focus": (0, m.dataAttr)(Z),
              "data-focus-visible": (0, m.dataAttr)(F),
              "data-disabled": (0, m.dataAttr)(e.isDisabled),
              ...(0, m.mergeProps)(
                e.isPressable ? { ...V, ...H, role: "button" } : {},
                e.isHoverable ? Q : {},
                (0, p.filterDOMProps)(I, { enabled: T }),
                (0, p.filterDOMProps)(t),
              ),
            };
          },
          [k, W, O, T, e.isPressable, e.isHoverable, e.isDisabled, D, z, F, V, H, Q, I],
        ),
        q = (0, l.useCallback)(() => ({ ripples: M, onClear: L }), [M, L]);
      return {
        context: K,
        domRef: k,
        Component: A,
        classNames: R,
        children: E,
        isHovered: D,
        isPressed: z,
        disableAnimation: P,
        isPressable: e.isPressable,
        isHoverable: e.isHoverable,
        disableRipple: j,
        handlePress: U,
        isFocusVisible: F,
        getCardProps: Y,
        getRippleProps: q,
      };
    }
    e.s(["useCard", 0, f], 701708);
    var b = e.i(860566),
      v = e.i(843476),
      x = (0, d.forwardRef)((e, a) => {
        let {
          children: s,
          context: r,
          Component: n,
          isPressable: l,
          disableAnimation: i,
          disableRipple: o,
          getCardProps: c,
          getRippleProps: d,
        } = f({ ...e, ref: a });
        return (0, v.jsxs)(n, {
          ...c(),
          children: [
            (0, v.jsx)(t, { value: r, children: s }),
            l && !i && !o && (0, v.jsx)(b.Ripple, { ...d() }),
          ],
        });
      });
    ((x.displayName = "HeroUI.Card"), e.s(["card_default", 0, x], 5898));
  },
  520837,
  (e) => {
    "use strict";
    var t = e.i(5898);
    e.s(["Card", () => t.card_default]);
  },
  358033,
  (e) => {
    "use strict";
    var t = e.i(273830),
      a = e.i(343027),
      s = e.i(429427),
      r = e.i(52841),
      n = e.i(984898),
      l = e.i(779754),
      i = (0, n.tv)({
        slots: {
          base: [
            "relative",
            "max-w-fit",
            "min-w-min",
            "inline-flex",
            "items-center",
            "justify-between",
            "box-border",
            "whitespace-nowrap",
          ],
          content: "flex-1 text-inherit font-normal",
          dot: ["w-2", "h-2", "ml-1", "rounded-full"],
          avatar: "shrink-0",
          closeButton: [
            "z-10",
            "appearance-none",
            "outline-solid outline-transparent",
            "select-none",
            "transition-opacity",
            "opacity-70",
            "hover:opacity-100",
            "cursor-pointer",
            "active:opacity-disabled",
            "tap-highlight-transparent",
          ],
        },
        variants: {
          variant: {
            solid: {},
            bordered: { base: "border-medium bg-transparent" },
            light: { base: "bg-transparent" },
            flat: {},
            faded: { base: "border-medium" },
            shadow: {},
            dot: { base: "border-medium border-default text-foreground bg-transparent" },
          },
          color: {
            default: { dot: "bg-default-400" },
            primary: { dot: "bg-primary" },
            secondary: { dot: "bg-secondary" },
            success: { dot: "bg-success" },
            warning: { dot: "bg-warning" },
            danger: { dot: "bg-danger" },
          },
          size: {
            sm: {
              base: "px-1 h-6 text-tiny",
              content: "px-1",
              closeButton: "text-medium",
              avatar: "w-4 h-4",
            },
            md: {
              base: "px-1 h-7 text-small",
              content: "px-2",
              closeButton: "text-large",
              avatar: "w-5 h-5",
            },
            lg: { base: "px-2 h-8 text-medium", content: "px-2", closeButton: "text-xl", avatar: "w-6 h-6" },
          },
          radius: {
            none: { base: "rounded-none" },
            sm: { base: "rounded-small" },
            md: { base: "rounded-medium" },
            lg: { base: "rounded-large" },
            full: { base: "rounded-full" },
          },
          isOneChar: { true: {}, false: {} },
          isCloseable: { true: {}, false: {} },
          hasStartContent: { true: {} },
          hasEndContent: { true: {} },
          isDisabled: { true: { base: "opacity-disabled pointer-events-none" } },
          isCloseButtonFocusVisible: { true: { closeButton: [...l.ringClasses, "ring-1", "rounded-full"] } },
        },
        defaultVariants: { variant: "solid", color: "default", size: "md", radius: "full", isDisabled: !1 },
        compoundVariants: [
          { variant: "solid", color: "default", class: { base: r.colorVariants.solid.default } },
          { variant: "solid", color: "primary", class: { base: r.colorVariants.solid.primary } },
          { variant: "solid", color: "secondary", class: { base: r.colorVariants.solid.secondary } },
          { variant: "solid", color: "success", class: { base: r.colorVariants.solid.success } },
          { variant: "solid", color: "warning", class: { base: r.colorVariants.solid.warning } },
          { variant: "solid", color: "danger", class: { base: r.colorVariants.solid.danger } },
          { variant: "shadow", color: "default", class: { base: r.colorVariants.shadow.default } },
          { variant: "shadow", color: "primary", class: { base: r.colorVariants.shadow.primary } },
          { variant: "shadow", color: "secondary", class: { base: r.colorVariants.shadow.secondary } },
          { variant: "shadow", color: "success", class: { base: r.colorVariants.shadow.success } },
          { variant: "shadow", color: "warning", class: { base: r.colorVariants.shadow.warning } },
          { variant: "shadow", color: "danger", class: { base: r.colorVariants.shadow.danger } },
          { variant: "bordered", color: "default", class: { base: r.colorVariants.bordered.default } },
          { variant: "bordered", color: "primary", class: { base: r.colorVariants.bordered.primary } },
          { variant: "bordered", color: "secondary", class: { base: r.colorVariants.bordered.secondary } },
          { variant: "bordered", color: "success", class: { base: r.colorVariants.bordered.success } },
          { variant: "bordered", color: "warning", class: { base: r.colorVariants.bordered.warning } },
          { variant: "bordered", color: "danger", class: { base: r.colorVariants.bordered.danger } },
          { variant: "flat", color: "default", class: { base: r.colorVariants.flat.default } },
          { variant: "flat", color: "primary", class: { base: r.colorVariants.flat.primary } },
          { variant: "flat", color: "secondary", class: { base: r.colorVariants.flat.secondary } },
          { variant: "flat", color: "success", class: { base: r.colorVariants.flat.success } },
          { variant: "flat", color: "warning", class: { base: r.colorVariants.flat.warning } },
          { variant: "flat", color: "danger", class: { base: r.colorVariants.flat.danger } },
          { variant: "faded", color: "default", class: { base: r.colorVariants.faded.default } },
          { variant: "faded", color: "primary", class: { base: r.colorVariants.faded.primary } },
          { variant: "faded", color: "secondary", class: { base: r.colorVariants.faded.secondary } },
          { variant: "faded", color: "success", class: { base: r.colorVariants.faded.success } },
          { variant: "faded", color: "warning", class: { base: r.colorVariants.faded.warning } },
          { variant: "faded", color: "danger", class: { base: r.colorVariants.faded.danger } },
          { variant: "light", color: "default", class: { base: r.colorVariants.light.default } },
          { variant: "light", color: "primary", class: { base: r.colorVariants.light.primary } },
          { variant: "light", color: "secondary", class: { base: r.colorVariants.light.secondary } },
          { variant: "light", color: "success", class: { base: r.colorVariants.light.success } },
          { variant: "light", color: "warning", class: { base: r.colorVariants.light.warning } },
          { variant: "light", color: "danger", class: { base: r.colorVariants.light.danger } },
          {
            isOneChar: !0,
            hasStartContent: !1,
            hasEndContent: !1,
            size: "sm",
            class: { base: "w-5 h-5 min-w-5 min-h-5" },
          },
          {
            isOneChar: !0,
            hasStartContent: !1,
            hasEndContent: !1,
            size: "md",
            class: { base: "w-6 h-6 min-w-6 min-h-6" },
          },
          {
            isOneChar: !0,
            hasStartContent: !1,
            hasEndContent: !1,
            size: "lg",
            class: { base: "w-7 h-7 min-w-7 min-h-7" },
          },
          {
            isOneChar: !0,
            isCloseable: !1,
            hasStartContent: !1,
            hasEndContent: !1,
            class: { base: "px-0 justify-center", content: "px-0 flex-none" },
          },
          {
            isOneChar: !0,
            isCloseable: !0,
            hasStartContent: !1,
            hasEndContent: !1,
            class: { base: "w-auto" },
          },
          { isOneChar: !0, variant: "dot", class: { base: "w-auto h-7 px-1 items-center", content: "px-2" } },
          { hasStartContent: !0, size: "sm", class: { content: "pl-0.5" } },
          { hasStartContent: !0, size: ["md", "lg"], class: { content: "pl-1" } },
          { hasEndContent: !0, size: "sm", class: { content: "pr-0.5" } },
          { hasEndContent: !0, size: ["md", "lg"], class: { content: "pr-1" } },
        ],
      }),
      o = e.i(620253),
      c = e.i(75540),
      d = e.i(271645),
      u = e.i(619110),
      m = e.i(843476),
      p = (0, t.forwardRef)((e, r) => {
        let {
            Component: n,
            children: l,
            slots: p,
            classNames: g,
            isDot: h,
            isCloseable: f,
            startContent: b,
            endContent: v,
            getCloseButtonProps: x,
            getChipProps: w,
          } = (function (e) {
            let [r, n] = (0, t.mapPropsVariants)(e, i.variantKeys),
              {
                ref: l,
                as: u,
                children: m,
                avatar: p,
                startContent: g,
                endContent: h,
                onClose: f,
                classNames: b,
                className: v,
                ...x
              } = r,
              w = (0, o.useDOMRef)(l),
              E = (0, c.clsx)(null == b ? void 0 : b.base, v),
              C = !!f,
              S = "dot" === e.variant,
              { focusProps: _, isFocusVisible: y } = (0, s.useFocusRing)(),
              R = (0, d.useMemo)(() => "string" == typeof m && (null == m ? void 0 : m.length) === 1, [m]),
              N = (0, d.useMemo)(() => !!p || !!g, [p, g]),
              I = (0, d.useMemo)(() => !!h || C, [h, C]),
              k = (0, d.useMemo)(
                () =>
                  i({
                    ...n,
                    hasStartContent: N,
                    hasEndContent: I,
                    isOneChar: R,
                    isCloseable: C,
                    isCloseButtonFocusVisible: y,
                  }),
                [(0, c.objectToDeps)(n), y, N, I, R, C],
              ),
              { pressProps: A } = (0, a.usePress)({
                isDisabled: !!(null == e ? void 0 : e.isDisabled),
                onPress: f,
              }),
              T = (e) =>
                (0, d.isValidElement)(e)
                  ? (0, d.cloneElement)(e, { className: (0, c.clsx)("max-h-[80%]", e.props.className) })
                  : null;
            return {
              Component: u || "div",
              children: m,
              slots: k,
              classNames: b,
              isDot: S,
              isCloseable: C,
              startContent:
                ((0, d.isValidElement)(p)
                  ? (0, d.cloneElement)(p, { className: k.avatar({ class: null == b ? void 0 : b.avatar }) })
                  : null) || T(g),
              endContent: T(h),
              getCloseButtonProps: () => ({
                role: "button",
                tabIndex: 0,
                className: k.closeButton({ class: null == b ? void 0 : b.closeButton }),
                "aria-label": "close chip",
                ...(0, c.mergeProps)(A, _),
              }),
              getChipProps: () => ({ ref: w, className: k.base({ class: E }), ...x }),
            };
          })({ ...e, ref: r }),
          E = (0, d.useMemo)(
            () =>
              h && !b ? (0, m.jsx)("span", { className: p.dot({ class: null == g ? void 0 : g.dot }) }) : b,
            [p, b, h],
          ),
          C = (0, d.useMemo)(
            () => (f ? (0, m.jsx)("span", { ...x(), children: v || (0, m.jsx)(u.CloseFilledIcon, {}) }) : v),
            [v, f, x],
          );
        return (0, m.jsxs)(n, {
          ...w(),
          children: [
            E,
            (0, m.jsx)("span", {
              className: p.content({ class: null == g ? void 0 : g.content }),
              children: l,
            }),
            C,
          ],
        });
      });
    ((p.displayName = "HeroUI.Chip"), e.s(["Chip", 0, p], 358033));
  },
  619110,
  (e) => {
    "use strict";
    var t = e.i(843476);
    e.s([
      "CloseFilledIcon",
      0,
      (e) =>
        (0, t.jsx)("svg", {
          "aria-hidden": "true",
          focusable: "false",
          height: "1em",
          role: "presentation",
          viewBox: "0 0 24 24",
          width: "1em",
          ...e,
          children: (0, t.jsx)("path", {
            d: "M12 2a10 10 0 1010 10A10.016 10.016 0 0012 2zm3.36 12.3a.754.754 0 010 1.06.748.748 0 01-1.06 0l-2.3-2.3-2.3 2.3a.748.748 0 01-1.06 0 .754.754 0 010-1.06l2.3-2.3-2.3-2.3A.75.75 0 019.7 8.64l2.3 2.3 2.3-2.3a.75.75 0 011.06 1.06l-2.3 2.3z",
            fill: "currentColor",
          }),
        }),
    ]);
  },
  31799,
  (e) => {
    "use strict";
    var t = e.i(768834),
      a = e.i(579473),
      s = e.i(60423);
    let r = "retake-quiz-storage",
      n = {
        currentTestType: null,
        currentQuestionId: null,
        userAnswers: null,
        secondsPassed: 0,
        isTimerPaused: !1,
        _hasHydrated: !1,
        isTestCompleted: !1,
        previousIQScore: null,
        newIQScore: null,
      },
      l = (0, t.create)()(
        (0, a.persist)(
          (e, t) => ({
            ...n,
            handleChangeRetakeQuizStore: (t) => e((e) => ({ ...e, ...t })),
            clearRetakeQuizStore: () => {
              let a = t()._hasHydrated;
              e({ ...n, _hasHydrated: a });
            },
            setHasHydrated: (t) => e({ _hasHydrated: t }),
          }),
          {
            name: r,
            onRehydrateStorage: () => (e) => {
              e?.setHasHydrated(!0);
            },
          },
        ),
      );
    e.s([
      "clearRetakeQuizFromLocalStorage",
      0,
      () => {
        s.accessLocalStorage.removeItem(r);
      },
      "useRetakeQuizStore",
      0,
      l,
    ]);
  },
  599545,
  (e) => {
    "use strict";
    var t = e.i(492669);
    e.s(["IconCheckmark", () => t.default]);
  },
  934337,
  194693,
  597521,
  171946,
  703085,
  492669,
  70224,
  19309,
  106502,
  327293,
  230268,
  779450,
  492810,
  216933,
  513833,
  178281,
  358551,
  339998,
  12326,
  482527,
  707945,
  (e) => {
    "use strict";
    var t,
      a,
      s,
      r,
      n,
      l,
      i,
      o,
      c,
      d,
      u,
      m,
      p,
      g,
      h,
      f,
      b,
      v,
      x,
      w,
      E,
      C,
      S,
      _,
      y,
      R,
      N,
      I,
      k,
      A,
      T,
      P,
      j,
      O = e.i(271645);
    function L() {
      return (L = Object.assign.bind()).apply(null, arguments);
    }
    function B() {
      return (B = Object.assign.bind()).apply(null, arguments);
    }
    function M() {
      return (M = Object.assign.bind()).apply(null, arguments);
    }
    function U() {
      return (U = Object.assign.bind()).apply(null, arguments);
    }
    function V() {
      return (V = Object.assign.bind()).apply(null, arguments);
    }
    function z() {
      return (z = Object.assign.bind()).apply(null, arguments);
    }
    function Q() {
      return (Q = Object.assign.bind()).apply(null, arguments);
    }
    function D() {
      return (D = Object.assign.bind()).apply(null, arguments);
    }
    function F() {
      return (F = Object.assign.bind()).apply(null, arguments);
    }
    function Z() {
      return (Z = Object.assign.bind()).apply(null, arguments);
    }
    function H() {
      return (H = Object.assign.bind()).apply(null, arguments);
    }
    function W() {
      return (W = Object.assign.bind()).apply(null, arguments);
    }
    function K() {
      return (K = Object.assign.bind()).apply(null, arguments);
    }
    function Y() {
      return (Y = Object.assign.bind()).apply(null, arguments);
    }
    function q() {
      return (q = Object.assign.bind()).apply(null, arguments);
    }
    function G() {
      return (G = Object.assign.bind()).apply(null, arguments);
    }
    function $() {
      return ($ = Object.assign.bind()).apply(null, arguments);
    }
    function X() {
      return (X = Object.assign.bind()).apply(null, arguments);
    }
    function J() {
      return (J = Object.assign.bind()).apply(null, arguments);
    }
    function ee() {
      return (ee = Object.assign.bind()).apply(null, arguments);
    }
    (e.s(
      [
        "default",
        0,
        (e) =>
          O.createElement(
            "svg",
            L({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 15 14" }, e),
            t ||
              (t = O.createElement("path", {
                fill: "#fff",
                d: "m5.938 1.094.687-.688c.313-.281.781-.281 1.063 0L13.78 6.47c.281.312.281.781 0 1.062l-6.094 6.094c-.28.281-.75.281-1.062 0l-.688-.688a.814.814 0 0 1 0-1.093L9.72 8.25H.75A.72.72 0 0 1 0 7.5v-1a.74.74 0 0 1 .75-.75h8.969L5.938 2.187c-.282-.312-.313-.78 0-1.093",
              })),
          ),
      ],
      194693,
    ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              B({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 8 12" }, e),
              a ||
                (a = O.createElement("path", {
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 1.667,
                  d: "m1.5 11 5-5-5-5",
                })),
            ),
        ],
        597521,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              M({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 25 24" }, e),
              s ||
                (s = O.createElement("path", {
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M5.5 12h14m-7-7 7 7-7 7",
                })),
            ),
        ],
        171946,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              U({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 48 48" }, e),
              r ||
                (r = O.createElement("path", {
                  fill: "#CFD8DC",
                  d: "M5 38V14h38v24c0 2.2-1.8 4-4 4H9c-2.2 0-4-1.8-4-4",
                })),
              n ||
                (n = O.createElement("path", {
                  fill: "#F44336",
                  d: "M43 10v6H5v-6c0-2.2 1.8-4 4-4h30c2.2 0 4 1.8 4 4",
                })),
              l ||
                (l = O.createElement(
                  "g",
                  { fill: "#B71C1C" },
                  O.createElement("circle", { cx: 33, cy: 10, r: 3 }),
                  O.createElement("circle", { cx: 15, cy: 10, r: 3 }),
                )),
              i ||
                (i = O.createElement("path", {
                  fill: "#B0BEC5",
                  d: "M33 3c-1.1 0-2 .9-2 2v5c0 1.1.9 2 2 2s2-.9 2-2V5c0-1.1-.9-2-2-2M15 3c-1.1 0-2 .9-2 2v5c0 1.1.9 2 2 2s2-.9 2-2V5c0-1.1-.9-2-2-2",
                })),
              o ||
                (o = O.createElement("path", {
                  fill: "#90A4AE",
                  d: "M13 20h4v4h-4zm6 0h4v4h-4zm6 0h4v4h-4zm6 0h4v4h-4zm-18 6h4v4h-4zm6 0h4v4h-4zm6 0h4v4h-4zm6 0h4v4h-4zm-18 6h4v4h-4zm6 0h4v4h-4zm6 0h4v4h-4zm6 0h4v4h-4z",
                })),
            ),
        ],
        703085,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              V({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 18 13" }, e),
              c ||
                (c = O.createElement("path", {
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2.333,
                  d: "m1.31 6.8 4.95 4.95 9.899-9.9",
                })),
            ),
        ],
        492669,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              z(
                {
                  xmlns: "http://www.w3.org/2000/svg",
                  fill: "none",
                  stroke: "currentColor",
                  strokeWidth: 1.5,
                  "aria-hidden": "true",
                  className:
                    "checkmark-thin_svg__text-blue-600 checkmark-thin_svg__min-h-6 checkmark-thin_svg__min-w-6 checkmark-thin_svg__max-h-6 checkmark-thin_svg__max-w-6",
                  "data-slot": "icon",
                  viewBox: "0 0 24 24",
                },
                e,
              ),
              d ||
                (d = O.createElement("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  d: "m4.5 12.75 6 6 9-13.5",
                })),
            ),
        ],
        70224,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              Q({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24" }, e),
              u ||
                (u = O.createElement("path", {
                  fill: "currentColor",
                  fillRule: "evenodd",
                  d: "M3.172 5.172C2 6.343 2 8.229 2 12s0 5.657 1.172 6.828S6.229 20 10 20h4c3.771 0 5.657 0 6.828-1.172S22 15.771 22 12s0-5.657-1.172-6.828S17.771 4 14 4h-4C6.229 4 4.343 4 3.172 5.172M18.576 7.52a.75.75 0 0 1-.096 1.056l-2.196 1.83c-.887.74-1.605 1.338-2.24 1.746-.66.425-1.303.693-2.044.693s-1.384-.269-2.045-.693c-.634-.408-1.352-1.007-2.239-1.745L5.52 8.577a.75.75 0 0 1 .96-1.153l2.16 1.799c.933.777 1.58 1.315 2.128 1.667.529.34.888.455 1.233.455s.704-.114 1.233-.455c.547-.352 1.195-.89 2.128-1.667l2.159-1.8a.75.75 0 0 1 1.056.097",
                  clipRule: "evenodd",
                })),
            ),
        ],
        19309,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              D(
                {
                  xmlns: "http://www.w3.org/2000/svg",
                  width: "1em",
                  height: "1em",
                  fill: "none",
                  "aria-hidden": "true",
                  style: { fontSize: 20, lineHeight: 20, float: "left" },
                  viewBox: "0 0 24 24",
                },
                e,
              ),
              m || (m = O.createElement("path", { fill: "#f25022", d: "M0 0h10.931v10.931H0z" })),
              p || (p = O.createElement("path", { fill: "#7fba00", d: "M12.069 0H23v10.931H12.069z" })),
              g || (g = O.createElement("path", { fill: "#00a4ef", d: "M0 12.069h10.931V23H0z" })),
              h || (h = O.createElement("path", { fill: "#ffb900", d: "M12.069 12.069H23V23H12.069z" })),
            ),
        ],
        106502,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              F({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24" }, e),
              f ||
                (f = O.createElement("path", {
                  fill: "currentColor",
                  d: "m11.4 18.161 7.396-7.396a10.3 10.3 0 0 1-3.326-2.234 10.3 10.3 0 0 1-2.235-3.327L5.839 12.6c-.577.577-.866.866-1.114 1.184a6.6 6.6 0 0 0-.749 1.211c-.173.364-.302.752-.56 1.526l-1.362 4.083a1.06 1.06 0 0 0 1.342 1.342l4.083-1.362c.775-.258 1.162-.387 1.526-.56q.647-.308 1.211-.749c.318-.248.607-.537 1.184-1.114m9.448-9.448a3.932 3.932 0 0 0-5.561-5.561l-.887.887.038.111a8.75 8.75 0 0 0 2.092 3.32 8.75 8.75 0 0 0 3.431 2.13z",
                })),
            ),
        ],
        327293,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              Z({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24" }, e),
              b ||
                (b = O.createElement("path", {
                  fill: "none",
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M5 12h14m-7-7v14",
                })),
            ),
        ],
        230268,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              H({ xmlns: "http://www.w3.org/2000/svg", fill: "currentColor", viewBox: "0 0 20 20" }, e),
              v ||
                (v = O.createElement("path", {
                  fillRule: "evenodd",
                  d: "M10 15.27 16.18 18l-1.64-7.03L19 7.24l-7.19-.61L10 0 8.19 6.63 1 7.24l4.46 3.73L3.82 18z",
                  clipRule: "evenodd",
                })),
            ),
        ],
        779450,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              W({ xmlns: "http://www.w3.org/2000/svg", "aria-hidden": "true", viewBox: "0 0 24 24" }, e),
              x ||
                (x = O.createElement("path", {
                  fill: "currentColor",
                  d: "M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z",
                })),
            ),
        ],
        492810,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              K({ xmlns: "http://www.w3.org/2000/svg", fill: "#0d766e", viewBox: "0 0 24 24" }, e),
              w ||
                (w = O.createElement("path", {
                  d: "M19.965 8.521Q20 8.26 20 8c0-2.379-2.143-4.288-4.521-3.965C14.786 2.802 13.466 2 12 2s-2.786.802-3.479 2.035C6.138 3.712 4 5.621 4 8q0 .26.035.521C2.802 9.215 2 10.535 2 12s.802 2.785 2.035 3.479A4 4 0 0 0 4 16c0 2.379 2.138 4.283 4.521 3.965C9.214 21.198 10.534 22 12 22s2.786-.802 3.479-2.035C17.857 20.283 20 18.379 20 16q0-.26-.035-.521C21.198 14.785 22 13.465 22 12s-.802-2.785-2.035-3.479m-9.01 7.895-3.667-3.714 1.424-1.404 2.257 2.286 4.327-4.294 1.408 1.42z",
                })),
            ),
        ],
        216933,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              Y({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 32 32" }, e),
              E ||
                (E = O.createElement("path", {
                  fill: "#0758B4",
                  d: "M14.333 22.056a.5.5 0 0 0-.506-.142 2.147 2.147 0 0 1-2.569-1.219 3.1 3.1 0 0 0-2.678-1.92 2 2 0 0 1-.657-.151.5.5 0 0 0-.66.283l-3.775 9.926a.5.5 0 0 0 .636.647l3.936-1.415 2.001 3.674A.5.5 0 0 0 10.5 32l.034-.001a.5.5 0 0 0 .433-.322l3.465-9.104a.5.5 0 0 0-.099-.517m14.179 6.776-3.775-9.925a.5.5 0 0 0-.66-.283 2 2 0 0 1-.662.152 3.13 3.13 0 0 0-1.608.58c-.476.335-.845.8-1.064 1.339a2.115 2.115 0 0 1-2.566 1.221.5.5 0 0 0-.609.657l3.465 9.105a.5.5 0 0 0 .433.321L21.5 32a.5.5 0 0 0 .439-.261l2-3.674 3.937 1.415a.5.5 0 0 0 .636-.648",
                })),
              C ||
                (C = O.createElement("path", {
                  fill: "#4294FF",
                  d: "M26.989 9.136a2.07 2.07 0 0 1-.689-2.095 3.04 3.04 0 0 0-.49-2.538 3.12 3.12 0 0 0-2.323-1.279 2.13 2.13 0 0 1-1.818-1.298 3.1 3.1 0 0 0-1.913-1.77 3.14 3.14 0 0 0-2.63.313 2.16 2.16 0 0 1-2.253 0 3.145 3.145 0 0 0-3.78.36c-.33.307-.59.68-.761 1.097a2.13 2.13 0 0 1-1.823 1.299 3.12 3.12 0 0 0-2.32 1.278 3.04 3.04 0 0 0-.487 2.543 2.07 2.07 0 0 1-.696 2.095 3.05 3.05 0 0 0 .006 4.723 2.07 2.07 0 0 1 .688 2.095 3.04 3.04 0 0 0 .49 2.538 3.12 3.12 0 0 0 2.324 1.279 2.13 2.13 0 0 1 1.818 1.298 3.1 3.1 0 0 0 1.912 1.77 3.14 3.14 0 0 0 2.63-.313 2.16 2.16 0 0 1 2.252 0 3.146 3.146 0 0 0 3.781-.36c.33-.307.59-.68.762-1.097a2.13 2.13 0 0 1 1.822-1.299 3.12 3.12 0 0 0 2.32-1.278 3.04 3.04 0 0 0 .488-2.543 2.07 2.07 0 0 1 .695-2.094 3.05 3.05 0 0 0-.006-4.724",
                })),
              S ||
                (S = O.createElement("path", {
                  fill: "#FDFEFF",
                  d: "M16 19a7.5 7.5 0 1 0 0-15 7.5 7.5 0 0 0 0 15",
                })),
              _ ||
                (_ = O.createElement("path", {
                  fill: "#0758B4",
                  d: "M20.38 10.182a.5.5 0 0 0-.403-.34l-2.439-.355-1.09-2.208a.52.52 0 0 0-.896 0l-1.09 2.209-2.438.354a.5.5 0 0 0-.278.853l1.765 1.72-.416 2.427a.5.5 0 0 0 .724.527L16 14.223l2.18 1.146a.5.5 0 0 0 .726-.527l-.417-2.428 1.765-1.72a.5.5 0 0 0 .127-.512z",
                })),
            ),
        ],
        513833,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              q(
                {
                  xmlns: "http://www.w3.org/2000/svg",
                  fill: "none",
                  stroke: "currentColor",
                  viewBox: "0 0 24 24",
                },
                e,
              ),
              y ||
                (y = O.createElement("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "m9 5 7 7-7 7",
                })),
            ),
        ],
        178281,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              G({ xmlns: "http://www.w3.org/2000/svg", width: 80, height: 78, fill: "none" }, e),
              R ||
                (R = O.createElement("path", {
                  fill: "currentColor",
                  fillRule: "evenodd",
                  d: "M52.865 48.96c-14.623 0-26.433-11.858-26.433-26.433 0 14.575-11.857 26.432-26.432 26.432 14.575 0 26.432 11.81 26.432 26.386 0-14.575 11.81-26.386 26.433-26.386M80 62.597c-8.014 0-14.482-6.514-14.482-14.481 0 7.967-6.514 14.481-14.481 14.481 7.967 0 14.481 6.468 14.481 14.482A14.46 14.46 0 0 1 80 62.597m-8.342-44.054c-9.748 0-17.622-7.873-17.622-17.621 0 9.748-7.873 17.621-17.621 17.621 9.748 0 17.621 7.874 17.621 17.622 0-9.748 7.874-17.622 17.622-17.622",
                  clipRule: "evenodd",
                })),
            ),
        ],
        358551,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              $({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24" }, e),
              N ||
                (N = O.createElement("path", {
                  fill: "currentColor",
                  d: "M9 3V1h6v2zm2 11h2V8h-2zm1 8q-1.85 0-3.488-.712T5.65 19.35t-1.937-2.863T3 13t.713-3.488T5.65 6.65t2.863-1.937T12 4q1.55 0 2.975.5t2.675 1.45l1.4-1.4 1.4 1.4-1.4 1.4Q20 8.6 20.5 10.025T21 13q0 1.85-.713 3.488T18.35 19.35q-1.225 1.225-2.863 1.938T12 22m0-2q2.9 0 4.95-2.05T19 13t-2.05-4.95T12 6 7.05 8.05 5 13t2.05 4.95T12 20m0-7",
                })),
            ),
        ],
        339998,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              X({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24" }, e),
              I ||
                (I = O.createElement("path", {
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M3 11h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zm0 0a9 9 0 1 1 18 0m0 0v5a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2z",
                })),
              k ||
                (k = O.createElement("path", {
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M21 16v2a4 4 0 0 1-4 4h-5",
                })),
            ),
        ],
        12326,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              J({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24" }, e),
              A || (A = O.createElement("circle", { cx: 12, cy: 6, r: 4, fill: "currentColor" })),
              T ||
                (T = O.createElement("path", {
                  fill: "currentColor",
                  d: "M20 17.5c0 2.485 0 4.5-8 4.5s-8-2.015-8-4.5S7.582 13 12 13s8 2.015 8 4.5",
                })),
            ),
        ],
        482527,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              ee({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 44 44" }, e),
              P || (P = O.createElement("path", { fill: "#FC3F1D", d: "M0 0h44v44H0z" })),
              j ||
                (j = O.createElement("path", {
                  fill: "#fff",
                  d: "M22.952 24.29c1.339 2.933 1.785 3.953 1.785 7.477v4.67h-4.783v-7.875L10.931 8.938h4.99zM28.85 8.938 23 22.233h4.862l5.866-13.295z",
                })),
            ),
        ],
        707945,
      ),
      e.s([], 934337));
  },
  149158,
  (e) => {
    "use strict";
    e.i(842582);
    var t = e.i(76399);
    e.s(["default", 0, () => ((0, t.useCollectParams)(), null)]);
  },
  842582,
  76399,
  (e) => {
    "use strict";
    var t = e.i(618566),
      a = e.i(271645);
    e.i(879568);
    var s = e.i(480408),
      r = e.i(866897),
      n = e.i(924254),
      l = e.i(5117);
    (e.s(
      [
        "useCollectParams",
        0,
        () => {
          let e,
            i = (0, t.useSearchParams)(),
            [o, c] = (0, a.useState)(null),
            [d, u] = (0, a.useState)(!1),
            m = () => {
              let e = i ? new URLSearchParams(i.toString()) : void 0,
                t = s.attributionUtil.collectAttributionData(e);
              (0, l.getClientAnalyticsConsent)().allowed && s.attributionUtil.saveAttributionData(t);
              let a = s.attributionUtil.readAttributionData() ?? t;
              return (c(a), u(!0), a);
            },
            p = () => o || s.attributionUtil.readAttributionData();
          return (
            (0, a.useEffect)(() => {
              d || m();
            }, [i, d]),
            {
              attributionData: p(),
              isInitialized: d,
              initializeAttribution: m,
              getAttributionMetadata: () => {
                let e = p();
                return s.attributionUtil.formatForPaymentMetadata(e);
              },
              clearAttribution: () => {
                (n.accessCookie.removeItem(r.ECookieArg.ATTRIBUTION_STORAGE_KEY), c(null));
              },
              hasAttribution: null !== (e = p()) && Object.keys(e).length > 0,
              getAttributionData: p,
            }
          );
        },
      ],
      76399,
    ),
      e.s([], 842582));
  },
  918149,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(948148),
      s = e.i(663615),
      r = e.i(134404),
      n = e.i(86596);
    e.i(80460);
    var l = e.i(998198),
      i = e.i(202042);
    e.s([
      "default",
      0,
      (e) => {
        let { className: o, hasFunnelFooter: c, insideCard: d } = e,
          u = (0, a.useTranslations)(),
          m = (0, n.useUserStore)((e) => e.user),
          p = m?.currency?.countryCode === "US",
          { priceForView: g } = (0, l.getPaymentPlanPrice)({ paymentPlan: "DEMO_PRICE", user: m || null }),
          { priceForView: h } = (0, l.getPaymentPlanPrice)({ paymentPlan: "MONTH_PRICE", user: m || null }),
          f = (0, l.getCalculatePriceForView)(g, m || null),
          b = (0, l.getCalculatePriceForView)(h, m || null);
        return (0, t.jsx)("p", {
          "data-app-start-disclaimer": !0,
          className: (0, s.cn)(
            "mb-2 pt-2 text-center text-sm text-default-700 md:mb-0 md:mt-0 md:px-0 md:pt-6 [&_a]:underline",
            o,
            c && "pb-[30px] md:pb-0 md:pt-8",
            d && "default-700 px-4 text-base xs-m:text-lg",
          ),
          children: u.rich(p ? "subscription_disclaimer_us" : "subscription_disclaimer", {
            demoPrice: f,
            monthPrice: b,
            bold: (e) => (0, t.jsx)("span", { className: "font-semibold", children: e }),
            terms: (e) => (0, t.jsx)(i.Link, { href: r.EClientRoutes.TERMS, children: e }),
            privacy: (e) => (0, t.jsx)(i.Link, { href: r.EClientRoutes.PRIVACY, children: e }),
          }),
        });
      },
    ]);
  },
  357601,
  95173,
  161312,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(520837),
      s = e.i(663615);
    e.i(934337);
    var r = e.i(599545),
      n = e.i(918149);
    e.s([], 95173);
    var l = n;
    e.s(["GoogleDisclaimerElement", () => l.default], 161312);
    var l = n;
    e.s(
      [
        "default",
        0,
        (e) => {
          let {
            title: n,
            descriptionList: i,
            children: o,
            childrenWrapperClassName: c,
            subTitle: d,
            isTrivia: u,
            variant: m,
            isWhiteBg: p,
            isMinimalisticCard: g,
            isDepression: h,
            withDisclaimer: f,
            withBigDisclaimer: b,
            hasFunnelFooter: v,
            titleClassName: x,
          } = e;
          return (0, t.jsxs)(a.Card, {
            fullWidth: !0,
            className: (0, s.cn)(
              u ? "bg-white p-3 shadow-medium md:p-6" : "bg-transparent px-0 py-6 sm:p-6 md:shadow-medium",
              p ? "mx-auto max-w-[800px] bg-white" : "bg-transparent",
              g && "py-0 shadow-none md:shadow-medium",
            ),
            children: [
              (0, t.jsx)("div", {
                className: "mx-auto flex flex-col items-center px-4",
                children: (0, t.jsx)("h1", {
                  className: (0, s.cn)(
                    u
                      ? "mt-4 flex flex-wrap items-center justify-center whitespace-break-spaces px-4 text-center text-1.5xl font-semibold leading-tight xs-m:mb-4 lg:text-3xl"
                      : "mt-4 flex flex-wrap items-center justify-center text-center text-1.5xl font-semibold xs-m:mb-4",
                    g && "!mt-0 !text-[24px] md:!mt-4",
                    h && "mt-0",
                    x,
                  ),
                  children: n,
                }),
              }),
              d &&
                (0, t.jsx)("div", {
                  className: (0, s.cn)(
                    "mx-auto gap-2 px-4 text-center text-default-700 xs-m:text-lg sm:px-6 lg:max-w-[500px]",
                    h && "mt-2 xs-m:mt-0",
                  ),
                  children: d,
                }),
              i && !u
                ? (0, t.jsxs)("div", {
                    className:
                      "lg:grid lg:grid-cols-[fit-content(500px)] lg:justify-center lg:justify-items-stretch",
                    children: [
                      (0, t.jsx)("div", {
                        className: (0, s.cn)(
                          "dark:text-foreground-700 mb-6 mt-4 flex flex-col gap-4 px-4 sm:px-6 lg:text-lg",
                        ),
                        children: (0, t.jsx)("ul", {
                          className: "mx-auto lg:max-w-[500px]",
                          children: i.map((e, a) =>
                            (0, t.jsxs)(
                              "li",
                              {
                                className: (0, s.cn)("mb-2 flex items-center gap-2 text-default-700"),
                                children: [
                                  e.icon
                                    ? e.icon
                                    : (0, t.jsx)(r.IconCheckmark, {
                                        className: (0, s.cn)(
                                          "h-7 w-7 flex-shrink-0 p-[5px] text-default-600",
                                        ),
                                      }),
                                  (0, t.jsx)("p", {
                                    className: (0, s.cn)(
                                      "default-700",
                                      p ? "xs-m:text-base" : "xs-m:text-lg",
                                    ),
                                    children: e.title,
                                  }),
                                ],
                              },
                              a,
                            ),
                          ),
                        }),
                      }),
                      (0, t.jsx)("div", {
                        className: (0, s.cn)(
                          "mx-auto mb-4 px-4 text-center xs-m:mt-3",
                          c,
                          "myiq" === (f && m) && "mb-0",
                        ),
                        children: o,
                      }),
                    ],
                  })
                : (0, t.jsxs)(t.Fragment, {
                    children: [
                      i &&
                        u &&
                        (0, t.jsx)("div", {
                          className:
                            "dark:text-foreground-700 my-8 flex flex-col gap-4 px-4 sm:px-6 lg:text-lg",
                          children: (0, t.jsx)("ul", {
                            className: "",
                            children: i.map((e, a) =>
                              (0, t.jsxs)(
                                "li",
                                {
                                  className: "mb-2 flex gap-2 text-default-700",
                                  children: [
                                    e.icon
                                      ? e.icon
                                      : (0, t.jsx)(r.IconCheckmark, {
                                          className: "h-7 w-7 flex-shrink-0 p-[5px] text-primary",
                                        }),
                                    (0, t.jsx)("p", {
                                      className: "default-700 xs-m:text-lg",
                                      children: e.title,
                                    }),
                                  ],
                                },
                                a,
                              ),
                            ),
                          }),
                        }),
                      (0, t.jsx)("div", {
                        className: (0, s.cn)(
                          u ? "mb-4 px-4 text-center" : "mx-auto mb-4 px-4 text-center xs-m:mt-3",
                          c,
                          "myiq" === (f && m) && "mb-0",
                        ),
                        children: o,
                      }),
                    ],
                  }),
              f
                ? (0, t.jsx)(l.default, {
                    insideCard: !0,
                    hasFunnelFooter: v,
                    className: b ? "hidden md:block" : void 0,
                  })
                : null,
            ],
          });
        },
      ],
      357601,
    );
  },
  146588,
  (e) => {
    "use strict";
    e.s([
      "BUTTON_CONFIG",
      0,
      (e) => [
        { id: "male", label: e("profile_page_gender_m") },
        { id: "female", label: e("profile_page_gender_f") },
      ],
    ]);
  },
  150551,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(618566),
      s = e.i(861745),
      r = e.i(948148),
      n = e.i(271645),
      l = e.i(663615),
      i = e.i(523173),
      o = e.i(866897),
      c = e.i(157273),
      d = e.i(86596);
    e.i(568267);
    var u = e.i(154692);
    e.i(470618);
    var m = e.i(650507),
      p = e.i(924254),
      g = e.i(60423);
    e.i(756503);
    var h = e.i(542516);
    e.i(470366);
    var f = e.i(504001);
    e.i(569311);
    var b = e.i(896855),
      v = e.i(202042),
      x = e.i(146588);
    e.i(458097);
    var w = e.i(190598);
    e.s(
      [
        "default",
        0,
        (e) => {
          let {
              sessionId: E,
              buttonTitle: C,
              funnel: S,
              isProfile: _,
              isTrivia: y,
              isMinimalisticCard: R,
              withGenderSelect: N,
              isBrainTrain: I,
              extendedAnalytics: k,
            } = e,
            A = (0, r.useTranslations)(),
            T = (0, s.useLocale)(),
            P = (0, a.useSearchParams)(),
            j = I || P?.get("bt") === "1",
            O = j && "myiq" === S && "en" === T ? "myiq-bt" : S,
            L = (0, w.getPageInfo)(O),
            B = (0, w.getRedirectLink)(S, _),
            M = (0, v.useRouter)(),
            [U, V] = (0, n.useState)(!1),
            [z, Q] = (0, n.useState)(null);
          (0, n.useEffect)(() => {
            M.prefetch(B);
          }, [B]);
          let D = (0, d.useUserStore)((e) => e.user),
            F = (0, d.useUserStore)((e) => e.handleChangeUserStore),
            Z = "true" === p.accessCookie.getItem(o.ECookieArg.PLAYGROUND_FUNNEL),
            H = P?.get("promo") === "true" || Z,
            W = P?.get("sf") === "true",
            K = P?.get("promo-special") === "true",
            Y =
              _ &&
              !y &&
              ((e) => {
                if (!e) return !1;
                try {
                  let t = `${e}_${c.StorageKeys.QUIZ_ANSWERS}`,
                    a = g.accessLocalStorage.getItem(t);
                  if (!a) return !1;
                  let s = JSON.parse(a);
                  return Object.keys(s).length > 0;
                } catch {
                  return !1;
                }
              })(S)
                ? `${A("btn_continue")} ${A("report_card_test")}`
                : C,
            q = async (e, t) => {
              if (
                (y &&
                  ((0, f.trackClientEvents)({
                    event: i.EAnalyticEvents.START_TRIVIA_CLICK,
                    params: { content_value: "Start Learning" },
                  }),
                  "production" === h.envClient.NEXT_PUBLIC_APP_ENV &&
                    b.mixpanelClient.startSessionRecording()),
                void 0 !== e && Q(e),
                t && F({ user: { gender: t } }),
                (H || K || W) &&
                  (V(!0),
                  F({
                    user: {
                      isPromoVersion: H ? "true" : "false",
                      isShortFreeVersion: W ? "true" : "false",
                      isSpecialPromo: K,
                      isPlaygroundVersion: Z ? "true" : "false",
                    },
                  })),
                y ||
                  (0, f.trackClientEvents)({
                    event: i.EAnalyticEvents.PAGE_CLICKED,
                    params: { ...L, ...(k && { extendedAnalytics: !0 }) },
                    sessionId: E,
                    user: D,
                  }),
                (0, f.setPeopleAnalytic)({ ...(t && { gender: t }), funnel: O, is_brain_train_1: j }),
                _ ||
                  (g.accessLocalStorage.removeItem(c.StorageKeys.LOVE_LANGUAGE_QUIZ_ANSWERS),
                  g.accessLocalStorage.removeItem(c.StorageKeys.PERSONALITY_QUIZ_ANSWERS),
                  g.accessLocalStorage.removeItem(c.StorageKeys.QUIZ_ANSWERS),
                  g.accessLocalStorage.removeItem((0, w.getRemoveQuizKey)(S)),
                  "depression" === S && g.accessLocalStorage.removeItem(m.DEPRESSION_TIMER_DEADLINE_LS_KEY),
                  F({
                    user: {
                      nextBillingDate: void 0,
                      billingSubscriptionData: void 0,
                      paynextSubscription: void 0,
                      paymentInfo: void 0,
                      isPaynextSubscribed: void 0,
                    },
                  })),
                _)
              )
                return M.replace(B);
              M.push(B);
            };
          return ("myiq" === S || N) && !_
            ? (0, t.jsx)(t.Fragment, {
                children: (0, t.jsx)("div", {
                  className: (0, l.cn)("flex flex-col items-center", R && "w-full lg:mx-auto lg:w-fit"),
                  children: (0, t.jsx)("div", {
                    className: (0, l.cn)("mt-4 flex justify-center gap-3", R && "w-full md:!mt-0 lg:w-fit"),
                    children: (0, x.BUTTON_CONFIG)(A).map((e, a) =>
                      (0, t.jsx)(
                        u.ButtonComponent,
                        {
                          name: "start-btn",
                          dataCy: "start_btn",
                          dataNR: "start-btn",
                          onClick: () => q(a, e.id),
                          isLoading: U && z === a,
                          className: (0, l.cn)(
                            "min-w-[116px] px-6 xs-sm:min-w-[135px] xs-m:min-w-36",
                            R && "mx-0 w-full",
                          ),
                          size: "sm",
                          children: e.label,
                        },
                        a,
                      ),
                    ),
                  }),
                }),
              })
            : (0, t.jsx)(u.ButtonComponent, {
                name: "start-btn",
                dataCy: "start_btn",
                onClick: () => q(),
                isLoading: U,
                size: "md",
                className: (0, l.cn)(
                  "w-full min-w-[116px] px-6 xs-sm:min-w-[135px] xs-m:min-w-36",
                  "depression" === S && "h-auto min-h-14 whitespace-normal py-2 leading-tight",
                ),
                children: y ? A("trivia_block_answers_start_training") : Y,
              });
        },
      ],
      150551,
    );
  },
  458097,
  190598,
  (e) => {
    "use strict";
    var t = e.i(157273),
      a = e.i(134404);
    (e.s(
      [
        "getPageInfo",
        0,
        (e) => {
          switch (e) {
            case "personality":
              return {
                page_name: "startPersonalityTestButtonClicked",
                page_title: "StartPersonalityTest",
                funnel: e,
              };
            case "love_language":
              return { page_name: "startLoveLangTestButtonClicked", page_title: "StartLoveLang", funnel: e };
            case "procrastination":
              return {
                page_name: "startProcrastinationTestButtonClicked",
                page_title: "StartProcrastinationTest",
                funnel: e,
              };
            case "careers":
              return { page_name: "startCareersTestButtonClicked", page_title: "StartCareers", funnel: e };
            case "depression":
              return {
                page_name: "startDepressionTestButtonClicked",
                page_title: "StartDepression",
                funnel: e,
              };
            case "work":
              return { page_name: "startWorkTestButtonClicked", page_title: "StartWork", funnel: e };
            case "burnout":
              return { page_name: "startBurnoutTestButtonClicked", page_title: "StartBurnout", funnel: e };
            case "emotional":
              return {
                page_name: "startEmotionalTestButtonClicked",
                page_title: "StartEmotional",
                funnel: e,
              };
            case "attachment":
              return {
                page_name: "startAttachmentTestButtonClicked",
                page_title: "StartAttachment",
                funnel: e,
              };
            case "adhd":
              return { page_name: "startAdhdTestButtonClicked", page_title: "StartAdhd", funnel: e };
            case "psychological_archetypes":
              return {
                page_name: "startPsychologicalArchetypesTestButtonClicked",
                page_title: "StartPsychologicalArchetypes",
                funnel: e,
              };
            case "time_management":
              return {
                page_name: "startTimeManagementTestButtonClicked",
                page_title: "StartTimeManagement",
                funnel: e,
              };
            case "imposter_syndrome":
              return {
                page_name: "startImposterSyndromeTestButtonClicked",
                page_title: "StartImposterSyndrome",
                funnel: e,
              };
            case "anxiety":
              return { page_name: "startAnxietyTestButtonClicked", page_title: "StartAnxiety", funnel: e };
            case "confidence":
              return {
                page_name: "startConfidenceTestButtonClicked",
                page_title: "StartConfidence",
                funnel: e,
              };
            case "strengths":
              return {
                page_name: "startStrengthsTestButtonClicked",
                page_title: "StartStrengths",
                funnel: e,
              };
            case "autism":
              return { page_name: "startAutismTestButtonClicked", page_title: "StartAutism", funnel: e };
            case "enneagram":
              return {
                page_name: "startEnneagramTestButtonClicked",
                page_title: "StartEnneagram",
                funnel: e,
              };
            default:
              return {
                page_name: "startCertifiedTestButtonClicked",
                page_title: "StartCertified",
                funnel: e,
              };
          }
        },
        "getRedirectLink",
        0,
        (e, t) => {
          switch (e) {
            case "personality":
              return t ? a.EClientRoutes.QUIZ_PERSONALITY_PROFILE : a.EClientRoutes.QUIZ_PERSONALITY;
            case "autism":
              return a.EClientRoutes.QUIZ_AUTISM;
            case "procrastination":
              return a.EClientRoutes.QUIZ_PROCRASTINATION;
            case "careers":
              return a.EClientRoutes.QUIZ_CAREERS;
            case "depression":
              return t ? a.EClientRoutes.QUIZ_DEPRESSION : a.EClientRoutes.QUIZ_DEPRESSION_FUNNEL;
            case "work":
              return a.EClientRoutes.QUIZ_WORK;
            case "burnout":
              return a.EClientRoutes.QUIZ_BURNOUT;
            case "emotional":
              return a.EClientRoutes.QUIZ_EMOTIONAL;
            case "adhd":
              return a.EClientRoutes.QUIZ_ADHD;
            case "time_management":
              return a.EClientRoutes.QUIZ_TIME_MANAGEMENT;
            case "attachment":
              return a.EClientRoutes.QUIZ_ATTACHMENT;
            case "imposter_syndrome":
              return a.EClientRoutes.QUIZ_IMPOSTER_SYNDROME;
            case "psychological_archetypes":
              return a.EClientRoutes.QUIZ_PSYCHOLOGICAL_ARCHETYPES;
            case "anxiety":
              return a.EClientRoutes.QUIZ_ANXIETY;
            case "confidence":
              return a.EClientRoutes.QUIZ_CONFIDENCE;
            case "strengths":
              return a.EClientRoutes.QUIZ_STRENGTHS;
            case "trivia":
              return a.EClientRoutes.QUIZ_TRIVIA;
            case "enneagram":
              return a.EClientRoutes.QUIZ_ENNEAGRAM;
            default:
              return t ? a.EClientRoutes.QUIZ_PROFILE : a.EClientRoutes.QUIZ;
          }
        },
        "getRemoveQuizKey",
        0,
        (e) => {
          switch (e) {
            case "personality":
              return t.StorageKeys.PERSONALITY_QUIZ_ANSWERS;
            case "adhd":
              return t.StorageKeys.ADHD_QUIZ_ANSWERS;
            case "careers":
              return t.StorageKeys.CAREERS_QUIZ_ANSWERS;
            case "time_management":
              return t.StorageKeys.TIME_MANAGEMENT_QUIZ_ANSWERS;
            case "procrastination":
              return t.StorageKeys.PROCRASTINATION_QUIZ_ANSWERS;
            case "imposter_syndrome":
              return t.StorageKeys.IMPOSTER_SYNDROME_QUIZ_ANSWERS;
            case "depression":
              return t.StorageKeys.DEPRESSION_QUIZ_ANSWERS;
            case "work":
              return t.StorageKeys.WORK_QUIZ_ANSWERS;
            case "burnout":
              return t.StorageKeys.BURNOUT_QUIZ_ANSWERS;
            case "emotional":
              return t.StorageKeys.EMOTIONAL_QUIZ_ANSWERS;
            case "attachment":
              return t.StorageKeys.ATTACHMENT_QUIZ_ANSWERS;
            case "psychological_archetypes":
              return t.StorageKeys.PSYCHOLOGICAL_ARCHETYPES_QUIZ_ANSWERS;
            case "anxiety":
              return t.StorageKeys.ANXIETY_QUIZ_ANSWERS;
            case "confidence":
              return t.StorageKeys.CONFIDENCE_QUIZ_ANSWERS;
            case "strengths":
              return t.StorageKeys.STRENGTHS_QUIZ_ANSWERS;
            case "enneagram":
              return t.StorageKeys.ENNEAGRAM_QUIZ_ANSWERS;
            default:
              return "";
          }
        },
      ],
      190598,
    ),
      e.s([], 458097));
  },
  470618,
  650507,
  15012,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(271645),
      s = e.i(60423),
      r = e.i(358033);
    e.i(934337);
    var n = e.i(339998),
      n = n;
    let l = (e) => {
      let { time: a, baseClassName: s, iconClassName: l = " ", timerClassName: i = "", icon: o } = e;
      return (0, t.jsx)(r.Chip, {
        size: "sm",
        className: "h-6",
        classNames: { base: `bg-teal-700/10 min-w-[72px] ${s}` },
        children: (0, t.jsxs)("div", {
          className: "flex items-center justify-start",
          children: [
            o || (0, t.jsx)(n.default, { className: `h-5 w-5 ${l}` }),
            (0, t.jsx)("span", { className: `font-semibold ${i}`, children: a }),
          ],
        }),
      });
    };
    var i = e.i(193636);
    let o = "depression_funnel_deadline";
    e.s(
      [
        "DEPRESSION_TIMER_DEADLINE_LS_KEY",
        0,
        o,
        "DEPRESSION_TIMER_TOTAL_SECONDS",
        0,
        1200,
        "default",
        0,
        (e) => {
          let { baseClassName: r, iconClassName: n, timerClassName: c } = e,
            [d, u] = (0, a.useState)(null);
          return ((0, a.useEffect)(() => {
            let e = s.accessLocalStorage.getItem(o),
              t = e ? Number(e) : NaN,
              a = !e || Number.isNaN(t) ? Date.now() + 12e5 : t;
            a !== t && s.accessLocalStorage.setItem(o, String(a));
            let r = () => {
              u(Math.max(0, Math.round((a - Date.now()) / 1e3)));
            };
            r();
            let n = setInterval(r, 1e3);
            return () => clearInterval(n);
          }, []),
          null === d)
            ? null
            : (0, t.jsx)(l, {
                time: (0, i.getCountdownTimerFormat)(d),
                baseClassName: r,
                iconClassName: n,
                timerClassName: c,
              });
        },
      ],
      650507,
    );
    var c = e.i(31799),
      d = e.i(134404);
    e.i(910661);
    var u = e.i(642871),
      m = e.i(190899),
      p = e.i(202042);
    (e.s(
      [
        "default",
        0,
        (e) => {
          let { baseClassName: s, iconClassName: r, timerClassName: n } = e,
            o = (0, p.useRouter)(),
            g = (0, p.usePathname)() === d.EClientRoutes.RETAKE_QUIZ,
            h = (0, c.useRetakeQuizStore)((e) => e.secondsPassed),
            f = (0, c.useRetakeQuizStore)((e) => e.isTimerPaused),
            b = (0, c.useRetakeQuizStore)((e) => e.handleChangeRetakeQuizStore),
            v = (0, u.useQuizStore)((e) => e.secondsPassed),
            x = g ? h : v,
            w = (0, u.useQuizStore)((e) => e.isQuizFinished),
            E = (0, u.useQuizStore)((e) => e.timerResetKey),
            C = (0, u.useQuizStore)((e) => e.handleChangeQuizStore),
            S = (0, a.useRef)("true" === m.accessSessionStorageUtil.getItem("quiz-language-change")),
            _ = (0, a.useRef)(!1),
            y = (0, a.useRef)(!1),
            [R, N] = (0, a.useState)(() => (x > 0 && !w ? x : 0)),
            [I, k] = (0, a.useState)(Date.now()),
            A = (0, a.useRef)(x),
            [T, P] = (0, a.useState)(!1);
          return ((0, a.useEffect)(() => {
            _.current ||
              ((_.current = !0),
              S.current && m.accessSessionStorageUtil.removeItem("quiz-language-change"),
              x > 0 && !w ? (N(x), (A.current = x)) : (C({ secondsPassed: 0 }), N(0), (A.current = 0)),
              k(Date.now()),
              P(!0));
          }, []),
          (0, a.useEffect)(() => {
            T && !S.current && x > 0 && !w && (N(x), (A.current = x), k(Date.now()));
          }, [x, w, T]),
          (0, a.useEffect)(() => {
            A.current = x;
          }, [x]),
          (0, a.useEffect)(() => {
            E > 0 && (N(0), k(Date.now()));
          }, [E]),
          (0, a.useEffect)(() => {
            g && (y.current && !f && (k(Date.now()), (A.current = h)), (y.current = f));
          }, [g, f, h]),
          (0, a.useEffect)(() => {
            if (g && f) return;
            let e = setTimeout(() => {
              let e = Date.now(),
                t = Math.round((e - I) / 1e3);
              (k(e),
                N((e) => e + 1),
                w ||
                  ((A.current += t), g ? b({ secondsPassed: A.current }) : C({ secondsPassed: A.current })));
            }, 1e3);
            return () => clearInterval(e);
          }, [o, w, R, I, C, g, f]),
          (0, a.useEffect)(() => {
            C({ isQuizFinished: !1 });
          }, []),
          T && null !== R)
            ? (0, t.jsx)(l, {
                time: (0, i.getCountdownTimerFormat)(R),
                baseClassName: s,
                iconClassName: r,
                timerClassName: n,
              })
            : null;
        },
      ],
      15012,
    ),
      e.s([], 470618));
  },
  193636,
  (e) => {
    "use strict";
    e.s([
      "getCountdownTimerFormat",
      0,
      (e) => {
        if (!e || "number" != typeof e || e <= 0) return "00:00";
        let t = String(Math.floor(e / 60)).padStart(2, "0"),
          a = String(e % 60).padStart(2, "0");
        return `${t}:${a}`;
      },
    ]);
  },
]);
