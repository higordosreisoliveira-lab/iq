(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  520947,
  (e) => {
    "use strict";
    var t = {
      ease: [0.36, 0.66, 0.4, 1],
      easeIn: [0.4, 0, 1, 1],
      easeOut: [0, 0, 0.2, 1],
      easeInOut: [0.4, 0, 0.2, 1],
      spring: [0.155, 1.105, 0.295, 1.12],
      springOut: [0.57, -0.15, 0.62, 0.07],
      softSpring: [0.16, 1.11, 0.3, 1.02],
    };
    (t.easeOut, t.easeIn);
    var r = {
      scaleSpring: {
        enter: {
          transform: "scale(1)",
          opacity: 1,
          transition: { type: "spring", bounce: 0, duration: 0.2 },
        },
        exit: { transform: "scale(0.85)", opacity: 0, transition: { type: "easeOut", duration: 0.15 } },
      },
      scaleSpringOpacity: {
        initial: { opacity: 0, transform: "scale(0.8)" },
        enter: {
          opacity: 1,
          transform: "scale(1)",
          transition: { type: "spring", bounce: 0, duration: 0.3 },
        },
        exit: {
          opacity: 0,
          transform: "scale(0.96)",
          transition: { type: "easeOut", bounce: 0, duration: 0.15 },
        },
      },
      scale: { enter: { scale: 1 }, exit: { scale: 0.95 } },
      scaleFadeIn: {
        enter: { transform: "scale(1)", opacity: 1, transition: { duration: 0.25, ease: t.easeIn } },
        exit: { transform: "scale(0.95)", opacity: 0, transition: { duration: 0.2, ease: t.easeOut } },
      },
      scaleInOut: {
        enter: { transform: "scale(1)", opacity: 1, transition: { duration: 0.4, ease: t.ease } },
        exit: { transform: "scale(1.03)", opacity: 0, transition: { duration: 0.3, ease: t.ease } },
      },
      fade: {
        enter: { opacity: 1, transition: { duration: 0.4, ease: t.ease } },
        exit: { opacity: 0, transition: { duration: 0.3, ease: t.ease } },
      },
      collapse: {
        enter: {
          opacity: 1,
          height: "auto",
          transition: {
            height: { type: "spring", bounce: 0, duration: 0.3 },
            opacity: { easings: "ease", duration: 0.4 },
          },
        },
        exit: { opacity: 0, height: 0, transition: { easings: "ease", duration: 0.3 } },
      },
    };
    e.s(["TRANSITION_EASINGS", 0, t, "TRANSITION_VARIANTS", 0, r]);
  },
  370864,
  216601,
  725423,
  260782,
  (e) => {
    "use strict";
    var t = e.i(271645);
    let r = "u" > typeof document ? t.default.useLayoutEffect : () => {};
    e.s(["useLayoutEffect", 0, r], 216601);
    let n = (e) => {
        var t;
        return null != (t = null == e ? void 0 : e.ownerDocument) ? t : document;
      },
      o = (e) => (e && "window" in e && e.window === e ? e : n(e).defaultView || window);
    function i(e) {
      return (
        null !== e &&
        "object" == typeof e &&
        "nodeType" in e &&
        "number" == typeof e.nodeType &&
        e.nodeType === Node.DOCUMENT_FRAGMENT_NODE &&
        "host" in e
      );
    }
    e.s(["getOwnerDocument", 0, n, "getOwnerWindow", 0, o, "isShadowRoot", 0, i], 725423);
    var a = e.i(674750);
    function l(e, t) {
      if (!(0, a.shadowDOM)()) return !!t && !!e && e.contains(t);
      if (!e || !t) return !1;
      let r = t;
      for (; null !== r;) {
        if (r === e) return !0;
        r = "SLOT" === r.tagName && r.assignedSlot ? r.assignedSlot.parentNode : i(r) ? r.host : r.parentNode;
      }
      return !1;
    }
    let u = function () {
      var e;
      let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : document;
      if (!(0, a.shadowDOM)()) return t.activeElement;
      let r = t.activeElement;
      for (; r && "shadowRoot" in r && (null == (e = r.shadowRoot) ? void 0 : e.activeElement);)
        r = r.shadowRoot.activeElement;
      return r;
    };
    function s(e) {
      return (0, a.shadowDOM)() && e.target.shadowRoot && e.composedPath ? e.composedPath()[0] : e.target;
    }
    function c(e) {
      var t;
      if ("u" < typeof window || null == window.navigator) return !1;
      let r = null == (t = window.navigator.userAgentData) ? void 0 : t.brands;
      return (Array.isArray(r) && r.some((t) => e.test(t.brand))) || e.test(window.navigator.userAgent);
    }
    function d(e) {
      var t;
      return (
        "u" > typeof window &&
        null != window.navigator &&
        e.test(
          (null == (t = window.navigator.userAgentData) ? void 0 : t.platform) || window.navigator.platform,
        )
      );
    }
    function f(e) {
      let t = null;
      return () => (null == t && (t = e()), t);
    }
    e.s(["getActiveElement", 0, u, "getEventTarget", 0, s, "nodeContains", 0, l], 260782);
    let h = f(function () {
        return d(/^Mac/i);
      }),
      p = f(function () {
        return d(/^iPhone/i);
      }),
      v = f(function () {
        return d(/^iPad/i) || (h() && navigator.maxTouchPoints > 1);
      }),
      N = f(function () {
        return p() || v();
      });
    (f(function () {
      return h() || N();
    }),
      f(function () {
        return c(/AppleWebKit/i) && !m();
      }));
    let m = f(function () {
        return c(/Chrome/i);
      }),
      b = f(function () {
        return c(/Android/i);
      });
    f(function () {
      return c(/Firefox/i);
    });
    let E = "u" > typeof Element && "checkVisibility" in Element.prototype;
    function g(e, t) {
      return E
        ? e.checkVisibility({ visibilityProperty: !0 }) && !e.closest("[data-react-aria-prevent-focus]")
        : "#comment" !== e.nodeName &&
            (function (e) {
              let t = o(e);
              if (!(e instanceof t.HTMLElement) && !(e instanceof t.SVGElement)) return !1;
              let { display: r, visibility: n } = e.style,
                i = "none" !== r && "hidden" !== n && "collapse" !== n;
              if (i) {
                let { getComputedStyle: t } = e.ownerDocument.defaultView,
                  { display: r, visibility: n } = t(e);
                i = "none" !== r && "hidden" !== n && "collapse" !== n;
              }
              return i;
            })(e) &&
            !e.hasAttribute("hidden") &&
            !e.hasAttribute("data-react-aria-prevent-focus") &&
            ("DETAILS" !== e.nodeName || !t || "SUMMARY" === t.nodeName || e.hasAttribute("open")) &&
            (!e.parentElement || g(e.parentElement, e));
    }
    let T = [
        "input:not([disabled]):not([type=hidden])",
        "select:not([disabled])",
        "textarea:not([disabled])",
        "button:not([disabled])",
        "a[href]",
        "area[href]",
        "summary",
        "iframe",
        "object",
        "embed",
        "audio[controls]",
        "video[controls]",
        '[contenteditable]:not([contenteditable^="false"])',
        "permission",
      ],
      y = T.join(":not([hidden]),") + ",[tabindex]:not([disabled]):not([hidden])";
    T.push('[tabindex]:not([tabindex="-1"]):not([disabled])');
    let w = T.join(':not([hidden]):not([tabindex="-1"]),');
    function R(e) {
      return e.matches(y) && g(e) && !_(e);
    }
    function S(e) {
      return e.matches(w) && g(e) && !_(e);
    }
    function _(e) {
      let t = e;
      for (; null != t;) {
        if (t instanceof t.ownerDocument.defaultView.HTMLElement && t.inert) return !0;
        t = t.parentElement;
      }
      return !1;
    }
    class k {
      get currentNode() {
        return this._currentNode;
      }
      set currentNode(e) {
        if (!l(this.root, e))
          throw Error("Cannot set currentNode to a node that is not contained by the root node.");
        let t = [],
          r = e,
          n = e;
        for (this._currentNode = e; r && r !== this.root;)
          if (r.nodeType === Node.DOCUMENT_FRAGMENT_NODE) {
            let e = r,
              o = this._doc.createTreeWalker(e, this.whatToShow, { acceptNode: this._acceptNode });
            (t.push(o), (o.currentNode = n), this._currentSetFor.add(o), (r = n = e.host));
          } else r = r.parentNode;
        let o = this._doc.createTreeWalker(this.root, this.whatToShow, { acceptNode: this._acceptNode });
        (t.push(o), (o.currentNode = n), this._currentSetFor.add(o), (this._walkerStack = t));
      }
      get doc() {
        return this._doc;
      }
      firstChild() {
        let e = this.currentNode,
          t = this.nextNode();
        return l(e, t) ? (t && (this.currentNode = t), t) : ((this.currentNode = e), null);
      }
      lastChild() {
        let e = this._walkerStack[0].lastChild();
        return (e && (this.currentNode = e), e);
      }
      nextNode() {
        let e = this._walkerStack[0].nextNode();
        if (e) {
          if (e.shadowRoot) {
            var t;
            let r;
            if (
              ("function" == typeof this.filter
                ? (r = this.filter(e))
                : (null == (t = this.filter) ? void 0 : t.acceptNode) && (r = this.filter.acceptNode(e)),
              r === NodeFilter.FILTER_ACCEPT)
            )
              return ((this.currentNode = e), e);
            let n = this.nextNode();
            return (n && (this.currentNode = n), n);
          }
          return (e && (this.currentNode = e), e);
        }
        if (!(this._walkerStack.length > 1)) return null;
        {
          this._walkerStack.shift();
          let e = this.nextNode();
          return (e && (this.currentNode = e), e);
        }
      }
      previousNode() {
        let e = this._walkerStack[0];
        if (e.currentNode === e.root) {
          if (this._currentSetFor.has(e) && (this._currentSetFor.delete(e), this._walkerStack.length > 1)) {
            this._walkerStack.shift();
            let e = this.previousNode();
            return (e && (this.currentNode = e), e);
          }
          return null;
        }
        let t = e.previousNode();
        if (t) {
          if (t.shadowRoot) {
            var r;
            let e;
            if (
              ("function" == typeof this.filter
                ? (e = this.filter(t))
                : (null == (r = this.filter) ? void 0 : r.acceptNode) && (e = this.filter.acceptNode(t)),
              e === NodeFilter.FILTER_ACCEPT)
            )
              return (t && (this.currentNode = t), t);
            let n = this.lastChild();
            return (n && (this.currentNode = n), n);
          }
          return (t && (this.currentNode = t), t);
        }
        if (!(this._walkerStack.length > 1)) return null;
        {
          this._walkerStack.shift();
          let e = this.previousNode();
          return (e && (this.currentNode = e), e);
        }
      }
      nextSibling() {
        return null;
      }
      previousSibling() {
        return null;
      }
      parentNode() {
        return null;
      }
      constructor(e, t, r, n) {
        ((this._walkerStack = []),
          (this._currentSetFor = new Set()),
          (this._acceptNode = (e) => {
            if (e.nodeType === Node.ELEMENT_NODE) {
              var t;
              let r = e.shadowRoot;
              if (r) {
                let e = this._doc.createTreeWalker(r, this.whatToShow, { acceptNode: this._acceptNode });
                return (this._walkerStack.unshift(e), NodeFilter.FILTER_ACCEPT);
              }
              if ("function" == typeof this.filter) return this.filter(e);
              if (null == (t = this.filter) ? void 0 : t.acceptNode) return this.filter.acceptNode(e);
              if (null === this.filter) return NodeFilter.FILTER_ACCEPT;
            }
            return NodeFilter.FILTER_SKIP;
          }),
          (this._doc = e),
          (this.root = t),
          (this.filter = null != n ? n : null),
          (this.whatToShow = null != r ? r : NodeFilter.SHOW_ALL),
          (this._currentNode = t),
          this._walkerStack.unshift(e.createTreeWalker(t, r, this._acceptNode)));
        const o = t.shadowRoot;
        if (o) {
          const e = this._doc.createTreeWalker(o, this.whatToShow, { acceptNode: this._acceptNode });
          this._walkerStack.unshift(e);
        }
      }
    }
    var L = e.i(346996),
      C = e.i(700864);
    let x = t.default.createContext(null),
      F = "react-aria-focus-scope-restore",
      A = null;
    function M(e) {
      return e[0].parentElement;
    }
    function O(e) {
      let t = H.getTreeNode(A);
      for (; t && t.scopeRef !== e;) {
        if (t.contain) return !1;
        t = t.parent;
      }
      return !0;
    }
    function I(e, t) {
      return !!e && !!t && t.some((t) => t.contains(e));
    }
    function P(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
      if (e instanceof Element && e.closest("[data-react-aria-top-layer]")) return !0;
      for (let { scopeRef: r } of H.traverse(H.getTreeNode(t))) if (r && I(e, r.current)) return !0;
      return !1;
    }
    function D(e, t) {
      var r;
      let n = null == (r = H.getTreeNode(t)) ? void 0 : r.parent;
      for (; n;) {
        if (n.scopeRef === e) return !0;
        n = n.parent;
      }
      return !1;
    }
    function K(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
      if (null == e || t) {
        if (null != e)
          try {
            e.focus();
          } catch {}
      } else
        try {
          (0, C.focusSafely)(e);
        } catch {}
    }
    function W(e) {
      let t = !(arguments.length > 1) || void 0 === arguments[1] || arguments[1],
        r = e[0].previousElementSibling,
        n = M(e),
        o = z(n, { tabbable: t }, e);
      o.currentNode = r;
      let i = o.nextNode();
      return (t && !i && (((o = z((n = M(e)), { tabbable: !1 }, e)).currentNode = r), (i = o.nextNode())), i);
    }
    function U(e) {
      let t = !(arguments.length > 1) || void 0 === arguments[1] || arguments[1];
      K(W(e, t));
    }
    function V(e) {
      let t = H.getTreeNode(A);
      for (; t && t.scopeRef !== e;) {
        if (t.nodeToRestore) return !1;
        t = t.parent;
      }
      return (null == t ? void 0 : t.scopeRef) === e;
    }
    function j(e) {
      e.dispatchEvent(new CustomEvent(F, { bubbles: !0, cancelable: !0 })) && K(e);
    }
    function z(e, t, r) {
      var o, i, l;
      let u = (null == t ? void 0 : t.tabbable) ? S : R,
        s = n((null == e ? void 0 : e.nodeType) === Node.ELEMENT_NODE ? e : null),
        c =
          ((o = e || s),
          (i = NodeFilter.SHOW_ELEMENT),
          (l = {
            acceptNode(e) {
              var o;
              return (null == t || null == (o = t.from) ? void 0 : o.contains(e)) ||
                ((null == t ? void 0 : t.tabbable) &&
                  "INPUT" === e.tagName &&
                  "radio" === e.getAttribute("type") &&
                  (!(function (e) {
                    if (e.checked) return !0;
                    let t = [];
                    if (e.form) {
                      var r, o;
                      let n = null == (o = e.form) || null == (r = o.elements) ? void 0 : r.namedItem(e.name);
                      t = [...(null != n ? n : [])];
                    } else
                      t = [
                        ...n(e).querySelectorAll(`input[type="radio"][name="${CSS.escape(e.name)}"]`),
                      ].filter((e) => !e.form);
                    return !!t && !t.some((e) => e.checked);
                  })(e) ||
                    ("INPUT" === c.currentNode.tagName &&
                      "radio" === c.currentNode.type &&
                      c.currentNode.name === e.name)))
                ? NodeFilter.FILTER_REJECT
                : u(e) && (!r || I(e, r)) && (!(null == t ? void 0 : t.accept) || t.accept(e))
                  ? NodeFilter.FILTER_ACCEPT
                  : NodeFilter.FILTER_SKIP;
            },
          }),
          (0, a.shadowDOM)() ? new k(s, o, i, l) : s.createTreeWalker(o, i, l));
      return ((null == t ? void 0 : t.from) && (c.currentNode = t.from), c);
    }
    class G {
      addChild(e) {
        (this.children.add(e), (e.parent = this));
      }
      removeChild(e) {
        (this.children.delete(e), (e.parent = void 0));
      }
      constructor(e) {
        ((this.children = new Set()), (this.contain = !1), (this.scopeRef = e.scopeRef));
      }
    }
    let H = new (class e {
      get size() {
        return this.fastMap.size;
      }
      getTreeNode(e) {
        return this.fastMap.get(e);
      }
      addTreeNode(e, t, r) {
        let n = this.fastMap.get(null != t ? t : null);
        if (!n) return;
        let o = new G({ scopeRef: e });
        (n.addChild(o), (o.parent = n), this.fastMap.set(e, o), r && (o.nodeToRestore = r));
      }
      addNode(e) {
        this.fastMap.set(e.scopeRef, e);
      }
      removeTreeNode(e) {
        if (null === e) return;
        let t = this.fastMap.get(e);
        if (!t) return;
        let r = t.parent;
        for (let e of this.traverse())
          e !== t &&
            t.nodeToRestore &&
            e.nodeToRestore &&
            t.scopeRef &&
            t.scopeRef.current &&
            I(e.nodeToRestore, t.scopeRef.current) &&
            (e.nodeToRestore = t.nodeToRestore);
        let n = t.children;
        (r && (r.removeChild(t), n.size > 0 && n.forEach((e) => r && r.addChild(e))),
          this.fastMap.delete(t.scopeRef));
      }
      *traverse() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.root;
        if ((null != e.scopeRef && (yield e), e.children.size > 0))
          for (let t of e.children) yield* this.traverse(t);
      }
      clone() {
        var t, r;
        let n = new e();
        for (let e of this.traverse())
          n.addTreeNode(
            e.scopeRef,
            null != (r = null == (t = e.parent) ? void 0 : t.scopeRef) ? r : null,
            e.nodeToRestore,
          );
        return n;
      }
      constructor() {
        ((this.fastMap = new Map()),
          (this.root = new G({ scopeRef: null })),
          this.fastMap.set(null, this.root));
      }
    })();
    e.s(
      [
        "FocusScope",
        0,
        function (e) {
          var o, i, a, l, c, d, f, h, p, v;
          let N,
            E,
            g,
            T,
            { children: y, contain: w, restoreFocus: R, autoFocus: S } = e,
            _ = (0, t.useRef)(null),
            k = (0, t.useRef)(null),
            C = (0, t.useRef)([]),
            { parentNode: q } = (0, t.useContext)(x) || {},
            B = (0, t.useMemo)(() => new G({ scopeRef: C }), [C]);
          (r(() => {
            let e = q || H.root;
            if (H.getTreeNode(e.scopeRef) && A && !D(A, e.scopeRef)) {
              let t = H.getTreeNode(A);
              t && (e = t);
            }
            (e.addChild(B), H.addNode(B));
          }, [B, q]),
            r(() => {
              let e = H.getTreeNode(C);
              e && (e.contain = !!w);
            }, [w]),
            r(() => {
              var e;
              let t = null == (e = _.current) ? void 0 : e.nextSibling,
                r = [],
                n = (e) => e.stopPropagation();
              for (; t && t !== k.current;) (r.push(t), t.addEventListener(F, n), (t = t.nextSibling));
              return (
                (C.current = r),
                () => {
                  for (let e of r) e.removeEventListener(F, n);
                }
              );
            }, [y]),
            r(() => {
              if (i || a) return;
              let e = o.current,
                t = n(e ? e[0] : void 0),
                r = (e) => {
                  let t = s(e);
                  I(t, o.current) ? (A = o) : P(t) || (A = null);
                };
              return (
                t.addEventListener("focusin", r, !1),
                null == e || e.forEach((e) => e.addEventListener("focusin", r, !1)),
                () => {
                  (t.removeEventListener("focusin", r, !1),
                    null == e || e.forEach((e) => e.removeEventListener("focusin", r, !1)));
                }
              );
            }, [(o = C), (i = R), (a = w)]),
            (l = C),
            (c = w),
            (N = (0, t.useRef)(void 0)),
            (E = (0, t.useRef)(void 0)),
            r(() => {
              let e = l.current;
              if (!c) {
                E.current && (cancelAnimationFrame(E.current), (E.current = void 0));
                return;
              }
              let t = n(e ? e[0] : void 0),
                r = (e) => {
                  if ("Tab" !== e.key || e.altKey || e.ctrlKey || e.metaKey || !O(l) || e.isComposing) return;
                  let r = u(t),
                    n = l.current;
                  if (!n || !I(r, n)) return;
                  let o = z(M(n), { tabbable: !0 }, n);
                  if (!r) return;
                  o.currentNode = r;
                  let i = e.shiftKey ? o.previousNode() : o.nextNode();
                  (i ||
                    ((o.currentNode = e.shiftKey
                      ? n[n.length - 1].nextElementSibling
                      : n[0].previousElementSibling),
                    (i = e.shiftKey ? o.previousNode() : o.nextNode())),
                    e.preventDefault(),
                    i && K(i, !0));
                },
                o = (e) => {
                  (!A || D(A, l)) && I(s(e), l.current)
                    ? ((A = l), (N.current = s(e)))
                    : O(l) && !P(s(e), l)
                      ? N.current
                        ? N.current.focus()
                        : A && A.current && U(A.current)
                      : O(l) && (N.current = s(e));
                },
                i = (e) => {
                  (E.current && cancelAnimationFrame(E.current),
                    (E.current = requestAnimationFrame(() => {
                      let r = (0, L.getInteractionModality)(),
                        n = ("virtual" === r || null === r) && b() && m(),
                        o = u(t);
                      if (!n && o && O(l) && !P(o, l)) {
                        A = l;
                        let t = s(e);
                        if (t && t.isConnected) {
                          var i;
                          ((N.current = t), null == (i = N.current) || i.focus());
                        } else A.current && U(A.current);
                      }
                    })));
                };
              return (
                t.addEventListener("keydown", r, !1),
                t.addEventListener("focusin", o, !1),
                null == e || e.forEach((e) => e.addEventListener("focusin", o, !1)),
                null == e || e.forEach((e) => e.addEventListener("focusout", i, !1)),
                () => {
                  (t.removeEventListener("keydown", r, !1),
                    t.removeEventListener("focusin", o, !1),
                    null == e || e.forEach((e) => e.removeEventListener("focusin", o, !1)),
                    null == e || e.forEach((e) => e.removeEventListener("focusout", i, !1)));
                }
              );
            }, [l, c]),
            r(
              () => () => {
                E.current && cancelAnimationFrame(E.current);
              },
              [E],
            ),
            (d = C),
            (f = R),
            (h = w),
            (g = (0, t.useRef)("u" > typeof document ? u(n(d.current ? d.current[0] : void 0)) : null)),
            r(() => {
              let e = d.current,
                t = n(e ? e[0] : void 0);
              if (!f || h) return;
              let r = () => {
                (!A || D(A, d)) && I(u(t), d.current) && (A = d);
              };
              return (
                t.addEventListener("focusin", r, !1),
                null == e || e.forEach((e) => e.addEventListener("focusin", r, !1)),
                () => {
                  (t.removeEventListener("focusin", r, !1),
                    null == e || e.forEach((e) => e.removeEventListener("focusin", r, !1)));
                }
              );
            }, [d, h]),
            r(() => {
              let e = n(d.current ? d.current[0] : void 0);
              if (!f) return;
              let t = (t) => {
                if ("Tab" !== t.key || t.altKey || t.ctrlKey || t.metaKey || !O(d) || t.isComposing) return;
                let r = e.activeElement;
                if (!P(r, d) || !V(d)) return;
                let n = H.getTreeNode(d);
                if (!n) return;
                let o = n.nodeToRestore,
                  i = z(e.body, { tabbable: !0 });
                i.currentNode = r;
                let a = t.shiftKey ? i.previousNode() : i.nextNode();
                if (
                  ((o && o.isConnected && o !== e.body) || ((o = void 0), (n.nodeToRestore = void 0)),
                  (!a || !P(a, d)) && o)
                ) {
                  i.currentNode = o;
                  do a = t.shiftKey ? i.previousNode() : i.nextNode();
                  while (P(a, d));
                  (t.preventDefault(), t.stopPropagation(), a) ? K(a, !0) : P(o) ? K(o, !0) : r.blur();
                }
              };
              return (
                h || e.addEventListener("keydown", t, !0),
                () => {
                  h || e.removeEventListener("keydown", t, !0);
                }
              );
            }, [d, f, h]),
            r(() => {
              var e;
              let t = n(d.current ? d.current[0] : void 0);
              if (!f) return;
              let r = H.getTreeNode(d);
              if (r)
                return (
                  (r.nodeToRestore = null != (e = g.current) ? e : void 0),
                  () => {
                    let e = H.getTreeNode(d);
                    if (!e) return;
                    let r = e.nodeToRestore,
                      n = u(t);
                    if (f && r && ((n && P(n, d)) || (n === t.body && V(d)))) {
                      let e = H.clone();
                      requestAnimationFrame(() => {
                        if (t.activeElement === t.body) {
                          let t = e.getTreeNode(d);
                          for (; t;) {
                            if (t.nodeToRestore && t.nodeToRestore.isConnected)
                              return void j(t.nodeToRestore);
                            t = t.parent;
                          }
                          for (t = e.getTreeNode(d); t;) {
                            if (t.scopeRef && t.scopeRef.current && H.getTreeNode(t.scopeRef))
                              return void j(W(t.scopeRef.current, !0));
                            t = t.parent;
                          }
                        }
                      });
                    }
                  }
                );
            }, [d, f]),
            (p = C),
            (v = S),
            (T = t.default.useRef(v)),
            (0, t.useEffect)(() => {
              (T.current &&
                ((A = p),
                !I(u(n(p.current ? p.current[0] : void 0)), A.current) && p.current && U(p.current)),
                (T.current = !1));
            }, [p]),
            (0, t.useEffect)(() => {
              let e = u(n(C.current ? C.current[0] : void 0)),
                t = null;
              if (I(e, C.current)) {
                for (let r of H.traverse()) r.scopeRef && I(e, r.scopeRef.current) && (t = r);
                t === H.getTreeNode(C) && (A = t.scopeRef);
              }
            }, [C]),
            r(
              () => () => {
                var e, t, r;
                let n =
                  null != (r = null == (t = H.getTreeNode(C)) || null == (e = t.parent) ? void 0 : e.scopeRef)
                    ? r
                    : null;
                ((C === A || D(C, A)) && (!n || H.getTreeNode(n)) && (A = n), H.removeTreeNode(C));
              },
              [C],
            ));
          let J = (0, t.useMemo)(() => {
              var e;
              return (
                (e = C),
                {
                  focusNext() {
                    var t;
                    let r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                      o = e.current,
                      { from: i, tabbable: a, wrap: l, accept: s } = r,
                      c = i || u(n(null != (t = o[0]) ? t : void 0)),
                      d = o[0].previousElementSibling,
                      f = z(M(o), { tabbable: a, accept: s }, o);
                    f.currentNode = I(c, o) ? c : d;
                    let h = f.nextNode();
                    return (!h && l && ((f.currentNode = d), (h = f.nextNode())), h && K(h, !0), h);
                  },
                  focusPrevious() {
                    var t;
                    let r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                      o = e.current,
                      { from: i, tabbable: a, wrap: l, accept: s } = r,
                      c = i || u(n(null != (t = o[0]) ? t : void 0)),
                      d = o[o.length - 1].nextElementSibling,
                      f = z(M(o), { tabbable: a, accept: s }, o);
                    f.currentNode = I(c, o) ? c : d;
                    let h = f.previousNode();
                    return (!h && l && ((f.currentNode = d), (h = f.previousNode())), h && K(h, !0), h);
                  },
                  focusFirst() {
                    let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                      r = e.current,
                      { tabbable: n, accept: o } = t,
                      i = z(M(r), { tabbable: n, accept: o }, r);
                    i.currentNode = r[0].previousElementSibling;
                    let a = i.nextNode();
                    return (a && K(a, !0), a);
                  },
                  focusLast() {
                    let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                      r = e.current,
                      { tabbable: n, accept: o } = t,
                      i = z(M(r), { tabbable: n, accept: o }, r);
                    i.currentNode = r[r.length - 1].nextElementSibling;
                    let a = i.previousNode();
                    return (a && K(a, !0), a);
                  },
                }
              );
            }, []),
            Y = (0, t.useMemo)(() => ({ focusManager: J, parentNode: B }), [B, J]);
          return t.default.createElement(
            x.Provider,
            { value: Y },
            t.default.createElement("span", { "data-focus-scope-start": !0, hidden: !0, ref: _ }),
            y,
            t.default.createElement("span", { "data-focus-scope-end": !0, hidden: !0, ref: k }),
          );
        },
        "getFocusableTreeWalker",
        0,
        z,
        "isElementInChildOfActiveScope",
        0,
        function (e) {
          return P(e, A);
        },
      ],
      370864,
    );
  },
]);
