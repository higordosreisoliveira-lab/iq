(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  358261,
  function (o) {
    o.n(o.i(896085));
  },
]);
