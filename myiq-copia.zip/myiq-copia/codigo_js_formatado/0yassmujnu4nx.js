(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  972383,
  (e, t, r) => {
    "use strict";
    (e.i(247167), Object.defineProperty(r, "__esModule", { value: !0 }));
    var n = {
      ErrorBoundary: function () {
        return y;
      },
      ErrorBoundaryHandler: function () {
        return p;
      },
    };
    for (var o in n) Object.defineProperty(r, o, { enumerable: !0, get: n[o] });
    let u = e.r(190809),
      l = e.r(843476),
      a = u._(e.r(271645)),
      i = e.r(590373),
      d = e.r(265713);
    e.r(178377);
    let s = e.r(912354),
      c = e.r(82604),
      f = e.r(8372),
      _ = "u" > typeof window && (0, c.isBot)(window.navigator.userAgent);
    class p extends a.default.Component {
      static #e = (this.contextType = f.AppRouterContext);
      constructor(e) {
        (super(e),
          (this.reset = () => {
            this.setState({ error: null });
          }),
          (this.retry = () => {
            (0, a.startTransition)(() => {
              (this.context?.refresh(), this.reset());
            });
          }),
          (this.state = { error: null, previousPathname: this.props.pathname }));
      }
      static getDerivedStateFromError(e) {
        if ((0, d.isNextRouterError)(e)) throw e;
        return { error: { thrownValue: e } };
      }
      static getDerivedStateFromProps(e, t) {
        let { error: r } = t;
        return e.pathname !== t.previousPathname && t.error
          ? { error: null, previousPathname: e.pathname }
          : { error: t.error, previousPathname: e.pathname };
      }
      render() {
        if (this.state.error && !_) {
          let e = this.state.error.thrownValue;
          return (
            (0, s.handleISRError)({ error: e }),
            (0, l.jsxs)(l.Fragment, {
              children: [
                this.props.errorStyles,
                this.props.errorScripts,
                (0, l.jsx)(this.props.errorComponent, { error: e, reset: this.reset, retry: this.retry }),
              ],
            })
          );
        }
        return this.props.children;
      }
    }
    function y(e) {
      let { errorComponent: t, errorStyles: r, errorScripts: n, children: o } = e,
        u = (0, i.useUntrackedPathname)();
      return t
        ? (0, l.jsx)(p, { pathname: u, errorComponent: t, errorStyles: r, errorScripts: n, children: o })
        : (0, l.jsx)(l.Fragment, { children: o });
    }
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  912354,
  (e, t, r) => {
    "use strict";
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "handleISRError", {
        enumerable: !0,
        get: function () {
          return o;
        },
      }));
    let n = e.r(901425);
    function o(e) {
      let { error: t } = e;
      if (n.workAsyncStorage) {
        let e = n.workAsyncStorage.getStore();
        if (e?.isStaticGeneration) throw (t && console.error(t), t);
      }
    }
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  178377,
  (e, t, r) => {
    "use strict";
    (e.i(247167), Object.defineProperty(r, "__esModule", { value: !0 }));
    var n = {
      handleHardNavError: function () {
        return l;
      },
      useNavFailureHandler: function () {
        return a;
      },
    };
    for (var o in n) Object.defineProperty(r, o, { enumerable: !0, get: n[o] });
    e.r(271645);
    let u = e.r(451191);
    function l(e) {
      return (
        "u" > typeof window &&
        !!window.next.__pendingUrl &&
        (0, u.createHrefFromUrl)(new URL(window.location.href)) !==
          (0, u.createHrefFromUrl)(window.next.__pendingUrl) &&
        (console.error("Error occurred during navigation, falling back to hard navigation", e),
        (window.location.href = window.next.__pendingUrl.toString()),
        !0)
      );
    }
    function a() {}
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  590373,
  (e, t, r) => {
    "use strict";
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "useUntrackedPathname", {
        enumerable: !0,
        get: function () {
          return l;
        },
      }));
    let n = e.r(271645),
      o = e.r(261994),
      u = e.r(901425);
    function l() {
      return !(function () {
        if ("u" < typeof window) {
          let e = u.workUnitAsyncStorage.getStore();
          if (!e) return !1;
          switch (e.type) {
            case "prerender":
            case "prerender-client":
            case "prerender-ppr":
            case "validation-client":
              let t = e.fallbackRouteParams;
              return !!t && t.size > 0;
          }
        }
        return !1;
      })()
        ? (0, n.useContext)(o.PathnameContext)
        : null;
    }
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  358442,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      RedirectBoundary: function () {
        return _;
      },
      RedirectErrorBoundary: function () {
        return f;
      },
    };
    for (var o in n) Object.defineProperty(r, o, { enumerable: !0, get: n[o] });
    let u = e.r(190809),
      l = e.r(843476),
      a = u._(e.r(271645)),
      i = e.r(976562),
      d = e.r(124063),
      s = e.r(968391);
    function c(e) {
      let { redirect: t, reset: r, redirectType: n } = e,
        o = (0, i.useRouter)();
      return (
        (0, a.useEffect)(() => {
          a.default.startTransition(() => {
            ("push" === n ? o.push(t, {}) : o.replace(t, {}), r());
          });
        }, [t, n, r, o]),
        null
      );
    }
    class f extends a.default.Component {
      constructor(e) {
        (super(e), (this.state = { redirect: null, redirectType: null }));
      }
      static getDerivedStateFromError(e) {
        if ((0, s.isRedirectError)(e)) {
          let t = (0, d.getURLFromRedirectError)(e),
            r = (0, d.getRedirectTypeFromError)(e);
          return "handled" in e ? { redirect: null, redirectType: null } : { redirect: t, redirectType: r };
        }
        throw e;
      }
      render() {
        let { redirect: e, redirectType: t } = this.state;
        return null !== e && null !== t
          ? (0, l.jsx)(c, { redirect: e, redirectType: t, reset: () => this.setState({ redirect: null }) })
          : this.props.children;
      }
    }
    function _(e) {
      let { children: t } = e,
        r = (0, i.useRouter)();
      return (0, l.jsx)(f, { router: r, children: t });
    }
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  270725,
  (e, t, r) => {
    "use strict";
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "createRouterCacheKey", {
        enumerable: !0,
        get: function () {
          return o;
        },
      }));
    let n = e.r(813258);
    function o(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
      return Array.isArray(e)
        ? `${e[0]}|${e[1]}|${e[2]}`
        : t && e.startsWith(n.PAGE_SEGMENT_KEY)
          ? n.PAGE_SEGMENT_KEY
          : e;
    }
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  201244,
  (e, t, r) => {
    "use strict";
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "unresolvedThenable", {
        enumerable: !0,
        get: function () {
          return n;
        },
      }));
    let n = { then: () => {} };
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  922737,
  (e, t, r) => {
    "use strict";
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "setAttributesFromProps", {
        enumerable: !0,
        get: function () {
          return l;
        },
      }));
    let n = {
        acceptCharset: "accept-charset",
        className: "class",
        htmlFor: "for",
        httpEquiv: "http-equiv",
        noModule: "noModule",
      },
      o = ["onLoad", "onReady", "dangerouslySetInnerHTML", "children", "onError", "strategy", "stylesheets"];
    function u(e) {
      return ["async", "defer", "noModule"].includes(e);
    }
    function l(e, t) {
      for (let [r, l] of Object.entries(t)) {
        if (!t.hasOwnProperty(r) || o.includes(r) || void 0 === l) continue;
        let a = n[r] || r.toLowerCase();
        ("SCRIPT" === e.tagName && u(a) ? (e[a] = !!l) : e.setAttribute(a, String(l)),
          (!1 === l || ("SCRIPT" === e.tagName && u(a) && (!l || "false" === l))) &&
            (e.setAttribute(a, ""), e.removeAttribute(a)));
      }
    }
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  954839,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      METADATA_BOUNDARY_NAME: function () {
        return u;
      },
      OUTLET_BOUNDARY_NAME: function () {
        return a;
      },
      ROOT_LAYOUT_BOUNDARY_NAME: function () {
        return i;
      },
      VIEWPORT_BOUNDARY_NAME: function () {
        return l;
      },
    };
    for (var o in n) Object.defineProperty(r, o, { enumerable: !0, get: n[o] });
    let u = "__next_metadata_boundary__",
      l = "__next_viewport_boundary__",
      a = "__next_outlet_boundary__",
      i = "__next_root_layout_boundary__";
  },
  897367,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      MetadataBoundary: function () {
        return a;
      },
      OutletBoundary: function () {
        return d;
      },
      RootLayoutBoundary: function () {
        return s;
      },
      ViewportBoundary: function () {
        return i;
      },
    };
    for (var o in n) Object.defineProperty(r, o, { enumerable: !0, get: n[o] });
    let u = e.r(954839),
      l = {
        [u.METADATA_BOUNDARY_NAME]: function (e) {
          let { children: t } = e;
          return t;
        },
        [u.VIEWPORT_BOUNDARY_NAME]: function (e) {
          let { children: t } = e;
          return t;
        },
        [u.OUTLET_BOUNDARY_NAME]: function (e) {
          let { children: t } = e;
          return t;
        },
        [u.ROOT_LAYOUT_BOUNDARY_NAME]: function (e) {
          let { children: t } = e;
          return t;
        },
      },
      a = l[u.METADATA_BOUNDARY_NAME.slice(0)],
      i = l[u.VIEWPORT_BOUNDARY_NAME.slice(0)],
      d = l[u.OUTLET_BOUNDARY_NAME.slice(0)],
      s = l[u.ROOT_LAYOUT_BOUNDARY_NAME.slice(0)];
  },
  742732,
  (e, t, r) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "HeadManagerContext", {
        enumerable: !0,
        get: function () {
          return n;
        },
      }));
    let n = e.r(555682)._(e.r(271645)).default.createContext({});
  },
]);
