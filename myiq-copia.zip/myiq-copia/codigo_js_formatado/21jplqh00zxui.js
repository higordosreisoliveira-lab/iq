(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  686707,
  (e) => {
    "use strict";
    var s = e.i(843476);
    let l = (e) => {
      let { filled: l } = e;
      return (0, s.jsx)("span", {
        children: (0, s.jsxs)("svg", {
          className: "h-[20.8px] w-[20.8px] sm:h-6 sm:w-6",
          viewBox: "0 0 20 20",
          fill: l ? "#00b67a" : "#DCDCE6",
          xmlns: "http://www.w3.org/2000/svg",
          children: [
            (0, s.jsx)("rect", { width: "20", height: "20", rx: "2" }),
            (0, s.jsx)("path", {
              d: "M10 3.5l1.55 4.77H16.5l-4.03 2.93 1.55 4.77L10 13.04l-4.02 2.93 1.55-4.77L3.5 8.27h4.95L10 3.5z",
              fill: "white",
            }),
          ],
        }),
      });
    };
    e.s([
      "default",
      0,
      (e) => {
        let { rating: t } = e;
        return (0, s.jsx)("div", {
          className: "flex items-center gap-0.5 sm:gap-1",
          children: [1, 2, 3, 4, 5].map((e) => (0, s.jsx)(l, { filled: e <= t }, e)),
        });
      },
    ]);
  },
  952837,
  function (e) {
    e.n(e.i(686707));
  },
]);
