(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  262389,
  (e) => {
    "use strict";
    var a = e.i(976218),
      s = e.i(273830),
      t = e.i(620253),
      l = e.i(75540),
      r = e.i(843476),
      i = (0, s.forwardRef)((e, s) => {
        var i;
        let { as: n, className: d, children: o, ...c } = e,
          u = (0, t.useDOMRef)(s),
          { slots: m, classNames: x } = (0, a.useCardContext)(),
          p = (0, l.clsx)(null == x ? void 0 : x.footer, d);
        return (0, r.jsx)(n || "div", {
          ref: u,
          className: null == (i = m.footer) ? void 0 : i.call(m, { class: p }),
          ...c,
          children: o,
        });
      });
    ((i.displayName = "HeroUI.CardFooter"), e.s(["card_footer_default", 0, i]));
  },
  901775,
  (e) => {
    "use strict";
    var a = e.i(262389);
    e.s(["CardFooter", () => a.card_footer_default]);
  },
  557050,
  (e) => {
    e.v((a) => Promise.all(["static/chunks/1q2-_sktf0gwd.js"].map((a) => e.l(a))).then(() => a(864526)));
  },
  575898,
  (e) => {
    e.v((a) => Promise.all(["static/chunks/21jplqh00zxui.js"].map((a) => e.l(a))).then(() => a(952837)));
  },
  436306,
  (e) => {
    "use strict";
    var a = e.i(843476),
      s = e.i(520837),
      t = e.i(876898),
      l = e.i(901775),
      r = e.i(592021),
      i = e.i(770703);
    let n = (0, i.default)(() => e.A(557050), { loadableGenerated: { modules: [864526] } }),
      d = (0, i.default)(() => e.A(575898), { loadableGenerated: { modules: [952837] } });
    e.s(
      [
        "default",
        0,
        (e) => {
          let { review: i, isClickable: o, whiteCards: c } = e,
            u = !!o && !!i?.reviewUrl;
          return (0, a.jsxs)(s.Card, {
            as: u ? "a" : void 0,
            ...(u ? { href: i?.reviewUrl ?? void 0, target: "_blank", rel: "noopener noreferrer" } : {}),
            isPressable: u,
            disableRipple: !0,
            className: `h-full min-h-[200px] w-full gap-3 overflow-hidden rounded-2xl px-6 py-6 !antialiased ${c ? "border border-[#E6E7EB] bg-white" : "bg-[#F5F6F8]"} ${u ? "cursor-pointer transition-shadow" : ""}`,
            shadow: "none",
            children: [
              (0, a.jsxs)(r.CardHeader, {
                className: "flex items-center justify-between gap-2 p-0",
                children: [(0, a.jsx)(d, { rating: i?.rating ?? 5 }), (0, a.jsx)(n, {})],
              }),
              (0, a.jsxs)(t.CardBody, {
                className: "gap-2 p-0 !antialiased",
                children: [
                  i?.title
                    ? (0, a.jsx)("p", {
                        className: "text-md text-start font-semibold leading-snug text-[#191919]",
                        children: i.title,
                      })
                    : null,
                  (0, a.jsx)("p", {
                    className: "text-start text-sm leading-[1.55] text-grey-custom",
                    children: i?.review,
                  }),
                ],
              }),
              (0, a.jsxs)(l.CardFooter, {
                className: "flex items-center gap-1.5 rounded-b-none p-0 text-sm",
                children: [
                  i?.name
                    ? (0, a.jsx)("span", { className: "font-semibold text-[#191919]", children: i.name })
                    : null,
                  i?.name && i?.displayLocation
                    ? (0, a.jsx)("span", { className: "text-grey-light", children: "·" })
                    : null,
                  i?.displayLocation
                    ? (0, a.jsx)("span", { className: "text-grey-light", children: i.displayLocation })
                    : null,
                ],
              }),
            ],
          });
        },
      ],
      436306,
    );
  },
  188600,
  function (e) {
    e.n(e.i(436306));
  },
]);
