(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  744616,
  (e) => {
    "use strict";
    var t = e.i(843476),
      s = e.i(861745);
    e.s([
      "default",
      0,
      () => {
        let e = (0, s.useMessages)().it_paywall_v1_active ? "Invitato" : "Invited";
        return (0, t.jsxs)("div", {
          className: "flex shrink-0 items-center gap-1.5 text-[13px] text-grey-custom max-xs-sm:hidden",
          children: [
            (0, t.jsx)("span", {
              className: "flex h-4 w-4 items-center justify-center rounded-full bg-divider",
              children: (0, t.jsx)("svg", {
                width: "10",
                height: "10",
                viewBox: "0 0 12 12",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: (0, t.jsx)("path", {
                  d: "M2.5 6.2l2.2 2.2 4.6-4.8",
                  stroke: "white",
                  strokeWidth: "1.8",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                }),
              }),
            }),
            (0, t.jsx)("span", { className: "underline", children: e }),
          ],
        });
      },
    ]);
  },
  864526,
  function (e) {
    e.n(e.i(744616));
  },
]);
