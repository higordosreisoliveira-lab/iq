(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  825853,
  (t) => {
    t.v((o) => Promise.all(["static/chunks/3xt7moko7jvra.js"].map((o) => t.l(o))).then(() => o(360625)));
  },
  722619,
  (t) => {
    t.v((o) => Promise.all(["static/chunks/0suwvi5lio8qa.js"].map((o) => t.l(o))).then(() => o(215302)));
  },
]);
