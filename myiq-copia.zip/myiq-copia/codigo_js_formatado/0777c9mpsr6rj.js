(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  214545,
  (e) => {
    "use strict";
    var t = e.i(843476),
      s = e.i(948148),
      i = e.i(742214);
    e.i(340609);
    var a = e.i(90147);
    (e.s([], 888081),
      e.i(888081),
      e.s(
        [
          "PostPaymentProcessingModalComponent",
          0,
          () => {
            let e = (0, s.useTranslations)();
            return (0, t.jsx)(i.ModalContent, {
              className:
                "mx-0 my-0 w-full max-w-full select-none overflow-y-auto rounded-b-none rounded-t-[var(--ds-semantic-radius-sheet)] bg-[var(--ds-semantic-color-surface-page)] p-0 sm:mx-6 sm:max-w-md sm:rounded-[var(--ds-semantic-radius-card)]",
              children: (0, t.jsxs)("div", {
                className:
                  "flex flex-col items-center gap-4 px-6 pb-[max(32px,env(safe-area-inset-bottom))] pt-8 text-center sm:pb-8",
                children: [
                  (0, t.jsx)("h1", {
                    className:
                      "text-[length:var(--ds-primitive-typography-scale-body-lg-font-size)] font-semibold leading-[var(--ds-primitive-typography-scale-body-lg-line-height)] tracking-[var(--ds-primitive-typography-scale-body-lg-letter-spacing)] text-[var(--ds-semantic-color-text-primary)]",
                    children: e("checkout_page_processing_modal_title"),
                  }),
                  (0, t.jsx)(a.Spinner, { size: "lg" }),
                  (0, t.jsx)("p", {
                    className:
                      "text-[length:var(--ds-primitive-typography-scale-body-sm-font-size)] leading-[var(--ds-primitive-typography-scale-body-sm-line-height)] tracking-[var(--ds-primitive-typography-scale-body-sm-letter-spacing)] text-[var(--ds-semantic-color-text-muted)]",
                    children: e("checkout_page_processing_modal_description"),
                  }),
                ],
              }),
            });
          },
        ],
        214545,
      ));
  },
  889900,
  function (e) {
    e.n(e.i(214545));
  },
  340609,
  90147,
  (e) => {
    "use strict";
    var t = e.i(23877);
    (e.s([], 340609), e.s(["Spinner", () => t.default], 90147));
  },
  23877,
  (e) => {
    "use strict";
    var t = e.i(843476),
      s = e.i(112041);
    e.s(["default", 0, (e) => (0, t.jsx)(s.Spinner, { ...e })]);
  },
]);
