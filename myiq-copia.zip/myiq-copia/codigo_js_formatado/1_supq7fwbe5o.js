(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  971416,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(263970);
    (e.s([], 147632),
      e.i(147632),
      e.s(
        [
          "BurgerBtnComponent",
          0,
          (e) => {
            let { className: a } = e,
              o = (0, r.useGlobalStore)((e) => e.isMobileMenuVisible),
              n = (0, r.useGlobalStore)((e) => e.handleChangeGlobalStore);
            return (0, t.jsx)("div", {
              onClick: () => n({ isMobileMenuVisible: !o }),
              className: `relative flex h-11 w-11 cursor-pointer items-center justify-end transition-[bg_var(--transition)] ${a}`,
              children: (0, t.jsx)("div", {
                className: `relative h-[1.5px] w-[16.5px] bg-black transition-[all_var(--transition)] before:absolute before:left-0 before:h-[1.5px] before:w-[16.5px] before:rounded-full before:bg-black before:transition-[transform_var(--transition)] before:content-[''] after:absolute after:left-0 after:h-[1.5px] after:w-[16.5px] after:rounded-full after:bg-black after:transition-[transform_var(--transition)] after:content-[''] ${o ? "bg-transparent before:translate-y-0 before:rotate-45 after:translate-y-0 after:-rotate-45" : "before:translate-y-[-5px] after:translate-y-[5px]"}`,
              }),
            });
          },
        ],
        971416,
      ));
  },
  194025,
  function (e) {
    e.n(e.i(971416));
  },
]);
