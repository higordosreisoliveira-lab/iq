(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  15535,
  (t) => {
    "use strict";
    t.i(203068);
    var o = t.i(797982);
    t.s(["LangComponent", () => o.default]);
  },
  464901,
  function (t) {
    t.n(t.i(15535));
  },
]);
