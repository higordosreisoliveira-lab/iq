(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  730986,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
  },
  416637,
  (e, t, r) => {
    "use strict";
    var n = e.i(247167);
    Object.defineProperty(r, "__esModule", { value: !0 });
    let i = e.r(843740),
      o = e.r(413575);
    r.default = class {
      constructor() {
        ((this.proxyPath = "/_betterstack"),
          (this.shouldSendEdgeReport = !1),
          (this.token = "9LaiZJ2JFWZzTK5RBLcRAuak"),
          (this.environment = "production"),
          (this.ingestingUrl = "https://s2340140.us-east-9.betterstackdata.com"),
          (this.region = n.default.env.REGION || void 0),
          (this.customEndpoint = n.default.env.NEXT_PUBLIC_BETTER_STACK_CUSTOM_ENDPOINT));
      }
      isEnvVarsSet() {
        return !!(this.ingestingUrl && this.token) || !!this.customEndpoint;
      }
      getIngestURL(e) {
        return this.ingestingUrl || "";
      }
      getLogsEndpoint() {
        return o.isBrowser && this.customEndpoint
          ? this.customEndpoint
          : o.isBrowser
            ? `${this.proxyPath}/logs`
            : this.getIngestURL(i.EndpointType.logs);
      }
      getWebVitalsEndpoint() {
        return o.isBrowser && this.customEndpoint
          ? this.customEndpoint
          : o.isBrowser
            ? `${this.proxyPath}/web-vitals`
            : this.getIngestURL(i.EndpointType.webVitals);
      }
      wrapWebVitalsObject(e) {
        return e.map((e) => ({
          webVital: e,
          dt: new Date().getTime(),
          platform: { environment: this.environment, source: "web-vital" },
          source: "web-vital",
        }));
      }
      injectPlatformMetadata(e, t) {
        ((e.source = t), (e.platform = { environment: this.environment, region: this.region, source: t }));
      }
      getHeaderOrDefault(e, t, r) {
        return e.headers[t] ? e.headers[t] : r;
      }
    };
  },
  566902,
  (e, t, r) => {
    "use strict";
    var n = e.i(247167),
      i =
        (e.e && e.e.__importDefault) ||
        function (e) {
          return e && e.__esModule ? e : { default: e };
        };
    Object.defineProperty(r, "__esModule", { value: !0 });
    let o = i(e.r(416637)),
      s = n.default.env.SITE_ID,
      a = n.default.env.BUILD_ID,
      l = n.default.env.CONTEXT,
      u = n.default.env.DEPLOYMENT_URL,
      c = n.default.env.DEPLOYMENT_ID;
    class d extends o.default {
      wrapWebVitalsObject(e) {
        return e.map((e) => ({
          webVital: e,
          dt: new Date().getTime(),
          netlify: {
            environment: this.environment,
            source: "web-vital",
            siteId: s,
            buildId: a,
            context: l,
            deploymentUrl: u,
            deploymentId: c,
          },
        }));
      }
      injectPlatformMetadata(e, t) {
        e.netlify = {
          environment: this.environment,
          region: "edge" === t ? n.default.env.DENO_REGION : n.default.env.AWS_REGION,
          source: t,
          siteId: s,
          buildId: a,
          context: l,
          deploymentUrl: u,
          deploymentId: "edge" === t ? n.default.env.DENO_DEPLOYMENT_ID : c,
        };
      }
    }
    r.default = d;
  },
  197328,
  (e, t, r) => {
    "use strict";
    var n = e.i(247167),
      i =
        (e.e && e.e.__importDefault) ||
        function (e) {
          return e && e.__esModule ? e : { default: e };
        };
    Object.defineProperty(r, "__esModule", { value: !0 });
    let o = i(e.r(416637));
    class s extends o.default {
      constructor() {
        (super(...arguments),
          (this.shouldSendEdgeReport = !0),
          (this.region = n.default.env.VERCEL_REGION || void 0),
          (this.environment = n.default.env.VERCEL_ENV || "production"));
      }
      wrapWebVitalsObject(e) {
        return e.map((e) => ({
          webVital: e,
          dt: new Date().getTime(),
          vercel: {
            environment: this.environment,
            source: "web-vital",
            deploymentId: n.default.env.VERCEL_DEPLOYMENT_ID,
            deploymentUrl: n.default.env.NEXT_PUBLIC_VERCEL_URL,
            project: n.default.env.NEXT_PUBLIC_VERCEL_PROJECT_PRODUCTION_URL,
            git: {
              commit: n.default.env.NEXT_PUBLIC_VERCEL_GIT_COMMIT_SHA,
              repo: n.default.env.NEXT_PUBLIC_VERCEL_GIT_REPO_SLUG,
              ref: n.default.env.NEXT_PUBLIC_VERCEL_GIT_COMMIT_REF,
            },
          },
        }));
      }
      injectPlatformMetadata(e, t) {
        e.vercel = {
          environment: this.environment,
          region: this.region,
          source: t,
          deploymentId: n.default.env.VERCEL_DEPLOYMENT_ID,
          deploymentUrl: n.default.env.NEXT_PUBLIC_VERCEL_URL,
          project: n.default.env.NEXT_PUBLIC_VERCEL_PROJECT_PRODUCTION_URL,
          git: {
            commit: n.default.env.NEXT_PUBLIC_VERCEL_GIT_COMMIT_SHA,
            repo: n.default.env.NEXT_PUBLIC_VERCEL_GIT_REPO_SLUG,
            ref: n.default.env.NEXT_PUBLIC_VERCEL_GIT_COMMIT_REF,
          },
        };
      }
    }
    r.default = s;
  },
  843740,
  (e, t, r) => {
    "use strict";
    var n,
      i,
      o = e.i(247167),
      s =
        (e.e && e.e.__awaiter) ||
        function (e, t, r, n) {
          return new (r || (r = Promise))(function (i, o) {
            function s(e) {
              try {
                l(n.next(e));
              } catch (e) {
                o(e);
              }
            }
            function a(e) {
              try {
                l(n.throw(e));
              } catch (e) {
                o(e);
              }
            }
            function l(e) {
              var t;
              e.done
                ? i(e.value)
                : ((t = e.value) instanceof r
                    ? t
                    : new r(function (e) {
                        e(t);
                      })
                  ).then(s, a);
            }
            l((n = n.apply(e, t || [])).next());
          });
        };
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      (r.throttle = r.requestToJSON = r.EndpointType = r.isNoPrettyPrint = void 0),
      (r.isNoPrettyPrint = "true" == o.default.env.BETTER_STACK_NO_PRETTY_PRINT),
      ((n = i || (r.EndpointType = i = {})).webVitals = "web-vitals"),
      (n.logs = "logs"),
      (r.requestToJSON = function (e) {
        var t;
        return s(this, void 0, void 0, function* () {
          let r,
            n,
            i,
            o,
            s = {};
          e.headers.forEach((e, t) => {
            s[t] = e;
          });
          let a = {};
          if ("cookies" in e)
            e.cookies.getAll().forEach((e) => {
              a[e.name] = e.value;
            });
          else {
            let e = s.cookie;
            e &&
              (a = Object.fromEntries(
                e.split(";").map((e) => {
                  let [t, r] = e.trim().split("=");
                  return [t, r];
                }),
              ));
          }
          if ("nextUrl" in e) {
            let t = e.nextUrl;
            r = {
              basePath: t.basePath,
              buildId: t.buildId,
              hash: t.hash,
              host: t.host,
              hostname: t.hostname,
              href: t.href,
              origin: t.origin,
              password: t.password,
              pathname: t.pathname,
              port: t.port,
              protocol: t.protocol,
              search: t.search,
              searchParams: Object.fromEntries(t.searchParams.entries()),
              username: t.username,
            };
          }
          if (e.body)
            try {
              let r = e.clone();
              try {
                ((n = yield r.json()), null == (t = r.body) || t.getReader);
              } catch (e) {
                n = yield r.text();
              }
            } catch (e) {
              console.warn("Could not parse request body:", e);
            }
          let l = {
            mode: e.cache,
            credentials: e.credentials,
            redirect: e.redirect,
            referrerPolicy: e.referrerPolicy,
            integrity: e.integrity,
          };
          return (
            "ip" in e && (i = e.ip),
            "geo" in e && (o = e.geo),
            {
              method: e.method,
              url: e.url,
              headers: s,
              cookies: a,
              nextUrl: r,
              ip: i,
              geo: o,
              body: n,
              cache: l,
              mode: e.mode,
              destination: e.destination,
              referrer: e.referrer,
              keepalive: e.keepalive,
              signal: { aborted: e.signal.aborted, reason: e.signal.reason },
            }
          );
        });
      }),
      (r.throttle = (e, t) => {
        let r, n;
        return function () {
          let i = this,
            o = arguments;
          (null == n && (n = Date.now()),
            clearTimeout(r),
            (r = setTimeout(
              () => {
                Date.now() - n >= t && (e.apply(i, o), (n = Date.now()));
              },
              Math.max(t - (Date.now() - n), 0),
            )));
        };
      }));
  },
  827772,
  (e, t, r) => {
    "use strict";
    (Object.defineProperty(r, "__esModule", { value: !0 }), (r.reportWebVitalsWithPath = void 0));
    let n = e.r(413575),
      i = e.r(843740),
      o = n.config.getWebVitalsEndpoint(),
      s = (0, i.throttle)(function () {
        let e = JSON.stringify(n.config.wrapWebVitalsObject(a)),
          t = { "Content-Type": "application/json", "User-Agent": "next-logtail/v" + n.Version };
        n.config.token && (t.Authorization = `Bearer ${n.config.token}`);
        let r = { body: e, method: "POST", keepalive: !0, headers: t };
        function i() {
          fetch(o, r).catch(console.error);
        }
        if (n.isBrowser && n.isVercel && navigator.sendBeacon)
          try {
            navigator.sendBeacon.bind(navigator)(o, e);
          } catch (e) {
            i();
          }
        else i();
        a = [];
      }, 1e3),
      a = [];
    r.reportWebVitalsWithPath = function (e, t) {
      (a.push(Object.assign({ route: t }, e)), n.config.isEnvVarsSet() && s());
    };
  },
  235223,
  (e, t, r) => {
    "use strict";
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      (r.useReportWebVitals = r.BetterStackWebVitals = void 0));
    let n = e.r(618566),
      i = e.r(395816),
      o = e.r(827772),
      s = e.r(271645);
    var a = e.r(716295);
    (Object.defineProperty(r, "BetterStackWebVitals", {
      enumerable: !0,
      get: function () {
        return a.BetterStackWebVitals;
      },
    }),
      (r.useReportWebVitals = function (e) {
        let t = (0, n.usePathname)(),
          r = (0, s.useRef)(e || t);
        "string" == typeof e && e !== r.current
          ? (r.current = t)
          : "string" == typeof e && e === r.current && (r.current = e);
        let a = (0, s.useCallback)((e) => (0, o.reportWebVitalsWithPath)(e, r.current), []);
        (0, i.useReportWebVitals)(a);
      }));
  },
  716295,
  (e, t, r) => {
    "use strict";
    var n =
      (e.e && e.e.__importDefault) ||
      function (e) {
        return e && e.__esModule ? e : { default: e };
      };
    (Object.defineProperty(r, "__esModule", { value: !0 }), (r.BetterStackWebVitals = void 0));
    let i = n(e.r(271645)),
      o = e.r(235223);
    r.BetterStackWebVitals = function (e) {
      let { path: t } = e;
      return ((0, o.useReportWebVitals)(t), i.default.createElement(i.default.Fragment, null));
    };
  },
  915101,
  (e, t, r) => {
    "use strict";
    (Object.defineProperty(r, "__esModule", { value: !0 }), (r.useLogger = r.BetterStackWebVitals = void 0));
    let n = e.r(618566),
      i = e.r(777375),
      o = e.r(271645),
      s = e.r(929879);
    var a = e.r(716295);
    (Object.defineProperty(r, "BetterStackWebVitals", {
      enumerable: !0,
      get: function () {
        return a.BetterStackWebVitals;
      },
    }),
      (r.useLogger = function () {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          t = (0, n.usePathname)(),
          r = (0, s.useDeepCompareMemo)(() => {
            var r;
            return Object.assign(Object.assign({}, e), {
              args: Object.assign(Object.assign({}, null != (r = e.args) ? r : {}), { path: t }),
            });
          }, [e, t]),
          a = (0, o.useMemo)(() => new i.Logger(r), [r]);
        return (
          (0, o.useEffect)(
            () => () => {
              a && a.flush();
            },
            [t],
          ),
          a
        );
      }));
  },
  830470,
  (e, t, r) => {
    "use strict";
    var n =
      (e.e && e.e.__awaiter) ||
      function (e, t, r, n) {
        return new (r || (r = Promise))(function (i, o) {
          function s(e) {
            try {
              l(n.next(e));
            } catch (e) {
              o(e);
            }
          }
          function a(e) {
            try {
              l(n.throw(e));
            } catch (e) {
              o(e);
            }
          }
          function l(e) {
            var t;
            e.done
              ? i(e.value)
              : ((t = e.value) instanceof r
                  ? t
                  : new r(function (e) {
                      e(t);
                    })
                ).then(s, a);
          }
          l((n = n.apply(e, t || [])).next());
        });
      };
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      (r.withBetterStack = r.withBetterStackRouteHandler = r.withBetterStackNextConfig = void 0));
    let i = e.r(413575),
      o = e.r(777375),
      s = e.r(843740);
    function a(e) {
      return Object.assign(Object.assign({}, e), {
        rewrites: () =>
          n(this, void 0, void 0, function* () {
            var t;
            let r = yield null == (t = e.rewrites) ? void 0 : t.call(e),
              n = i.config.getIngestURL(s.EndpointType.webVitals),
              a = i.config.getIngestURL(s.EndpointType.logs);
            if (!n && !a) {
              let e = new o.Logger();
              return (
                e.warn(
                  "Envvars not detected. If this is production please see https://betterstack.com/docs/logs/javascript/nextjs/ for help",
                ),
                e.warn("Sending Web Vitals to /dev/null"),
                e.warn("Sending logs to console"),
                r || []
              );
            }
            let l = [
              { source: `${i.config.proxyPath}/web-vitals`, destination: n, basePath: !1 },
              { source: `${i.config.proxyPath}/logs`, destination: a, basePath: !1 },
            ];
            return r
              ? Array.isArray(r)
                ? r.concat(l)
                : ((r.afterFiles = (r.afterFiles || []).concat(l)), r)
              : l;
          }),
      });
    }
    function l(e, t) {
      return (r, a) =>
        n(this, void 0, void 0, function* () {
          var n, l;
          let u = r.nextUrl.pathname,
            c =
              Array.isArray(null == t ? void 0 : t.logRequestDetails) ||
              (null == t ? void 0 : t.logRequestDetails) === !0
                ? yield (0, s.requestToJSON)(r)
                : void 0,
            d = {
              startTime: new Date().getTime(),
              endTime: new Date().getTime(),
              path: u,
              method: r.method,
              host: r.headers.get("host"),
              userAgent: r.headers.get("user-agent"),
              scheme: r.url.split("://")[0],
              ip: r.headers.get("x-forwarded-for"),
              details: Array.isArray(null == t ? void 0 : t.logRequestDetails)
                ? Object.fromEntries(
                    Object.entries(c).filter((e) => {
                      let [r] = e;
                      return (null == t ? void 0 : t.logRequestDetails).includes(r);
                    }),
                  )
                : c,
            },
            f = new o.Logger({ req: d, source: i.isEdgeRuntime ? "edge" : "lambda" }),
            g = f.with({});
          ((g.config.source = `${i.isEdgeRuntime ? "edge" : "lambda"}-log`), (r.log = g));
          let h =
            a && "object" == typeof a && "params" in a && a.params instanceof Promise
              ? Object.assign(Object.assign({}, a), { params: yield a.params })
              : a;
          try {
            let t = yield e(r, h);
            return (
              (d.endTime = new Date().getTime()),
              (d.statusCode = t.status),
              (d.durationMs = d.endTime - d.startTime),
              i.isVercel ||
                f.logHttpRequest(
                  o.LogLevel.info,
                  `${r.method} ${d.path} ${d.statusCode} in ${d.endTime - d.startTime}ms`,
                  d,
                  {},
                ),
              g.attachResponseStatus(t.status),
              yield f.flush(),
              t
            );
          } catch (a) {
            d.endTime = new Date().getTime();
            let e = 500,
              s = o.LogLevel.error;
            throw (
              a instanceof Error &&
                ("NEXT_NOT_FOUND" === a.message
                  ? ((s = null != (n = null == t ? void 0 : t.notFoundLogLevel) ? n : o.LogLevel.warn),
                    (e = 404))
                  : "NEXT_REDIRECT" === a.message &&
                    ((s = null != (l = null == t ? void 0 : t.redirectLogLevel) ? l : o.LogLevel.info),
                    (e = a.digest ? parseInt(a.digest.split(";")[3]) : 307))),
              (d.statusCode = e),
              (d.durationMs = d.endTime - d.startTime),
              i.isVercel ||
                f.logHttpRequest(
                  s,
                  `${r.method} ${d.path} ${d.statusCode} in ${d.endTime - d.startTime}ms`,
                  d,
                  {},
                ),
              g.log(s, a.message, { error: a }),
              g.attachResponseStatus(e),
              yield f.flush(),
              a
            );
          }
        });
    }
    ((r.withBetterStackNextConfig = a),
      (r.withBetterStackRouteHandler = l),
      (r.withBetterStack = function (e, t) {
        return "function" == typeof e ? l(e, t) : a(e);
      }));
  },
  558268,
  (e, t, r) => {
    "use strict";
    var n =
        (e.e && e.e.__createBinding) ||
        (Object.create
          ? function (e, t, r, n) {
              void 0 === n && (n = r);
              var i = Object.getOwnPropertyDescriptor(t, r);
              ((!i || ("get" in i ? !t.__esModule : i.writable || i.configurable)) &&
                (i = {
                  enumerable: !0,
                  get: function () {
                    return t[r];
                  },
                }),
                Object.defineProperty(e, n, i));
            }
          : function (e, t, r, n) {
              (void 0 === n && (n = r), (e[n] = t[r]));
            }),
      i =
        (e.e && e.e.__exportStar) ||
        function (e, t) {
          for (var r in e) "default" === r || Object.prototype.hasOwnProperty.call(t, r) || n(t, e, r);
        };
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      (r.withLogtailRouteHandler =
        r.withLogtailNextConfig =
        r.withLogtail =
        r.withBetterStackRouteHandler =
        r.withBetterStackNextConfig =
        r.withBetterStack =
        r.throttle =
        r.EndpointType =
        r.LogLevel =
        r.Logger =
        r.log =
          void 0));
    var o = e.r(777375);
    (Object.defineProperty(r, "log", {
      enumerable: !0,
      get: function () {
        return o.log;
      },
    }),
      Object.defineProperty(r, "Logger", {
        enumerable: !0,
        get: function () {
          return o.Logger;
        },
      }),
      Object.defineProperty(r, "LogLevel", {
        enumerable: !0,
        get: function () {
          return o.LogLevel;
        },
      }));
    var s = e.r(843740);
    (Object.defineProperty(r, "EndpointType", {
      enumerable: !0,
      get: function () {
        return s.EndpointType;
      },
    }),
      Object.defineProperty(r, "throttle", {
        enumerable: !0,
        get: function () {
          return s.throttle;
        },
      }),
      i(e.r(730986), r),
      i(e.r(413575), r));
    var a = e.r(830470);
    (Object.defineProperty(r, "withBetterStack", {
      enumerable: !0,
      get: function () {
        return a.withBetterStack;
      },
    }),
      Object.defineProperty(r, "withBetterStackNextConfig", {
        enumerable: !0,
        get: function () {
          return a.withBetterStackNextConfig;
        },
      }),
      Object.defineProperty(r, "withBetterStackRouteHandler", {
        enumerable: !0,
        get: function () {
          return a.withBetterStackRouteHandler;
        },
      }),
      Object.defineProperty(r, "withLogtail", {
        enumerable: !0,
        get: function () {
          return a.withBetterStack;
        },
      }),
      Object.defineProperty(r, "withLogtailNextConfig", {
        enumerable: !0,
        get: function () {
          return a.withBetterStackNextConfig;
        },
      }),
      Object.defineProperty(r, "withLogtailRouteHandler", {
        enumerable: !0,
        get: function () {
          return a.withBetterStackRouteHandler;
        },
      }));
  },
  425706,
  (e, t, r) => {
    t.exports = {
      name: "@logtail/next",
      description: "Better Stack Telemetry Next.js client",
      version: "0.3.1",
      author: "Better Stack <hello@betterstack.com>",
      license: "MIT",
      engines: { node: ">=18" },
      main: "dist/index.js",
      types: "dist/index.d.ts",
      exports: {
        ".": { types: "./dist/index.d.ts", import: "./dist/index.js", require: "./dist/index.js" },
        "./hooks": { types: "./dist/hooks.d.ts", import: "./dist/hooks.js", require: "./dist/hooks.js" },
        "./webVitals": {
          types: "./dist/webVitals/index.d.ts",
          import: "./dist/webVitals/index.js",
          require: "./dist/webVitals/index.js",
        },
      },
      scripts: {
        build: "tsc",
        prepare: "npm run build",
        format: "prettier --write src/*.ts tests/*.ts",
        "check-format": "prettier -c src/*.ts tests/*.ts",
        test: "vitest run tests --coverage",
      },
      repository: { type: "git", url: "git+https://github.com/logtail/logtail-nextjs.git" },
      keywords: [
        "web-vitals",
        "better-stack",
        "logtail",
        "observability",
        "performance",
        "telemetry",
        "nextjs",
      ],
      bugs: { url: "https://github.com/logtail/logtail-nextjs/issues" },
      homepage: "https://github.com/logtail/logtail-nextjs#readme",
      peerDependencies: { next: ">=15.0", react: ">=18.0.0" },
      devDependencies: {
        "@types/node": "^20.4.2",
        "@types/react": "^18.2.15",
        "@vitest/coverage-v8": "^2.1.5",
        prettier: "^3.0.0",
        "ts-node": "^10.9.1",
        typescript: "^5.1.6",
        vitest: "^2.1.5",
      },
      dependencies: { "whatwg-fetch": "^3.6.2", "use-deep-compare": "^1.2.1" },
    };
  },
  413575,
  (e, t, r) => {
    "use strict";
    var n = e.i(247167),
      i =
        (e.e && e.e.__importDefault) ||
        function (e) {
          return e && e.__esModule ? e : { default: e };
        };
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      (r.config =
        r.isEdgeRuntime =
        r.isBrowser =
        r.isWebWorker =
        r.isNetlify =
        r.isVercel =
        r.isVercelIntegration =
        r.Version =
          void 0));
    let o = i(e.r(416637)),
      s = i(e.r(197328)),
      a = i(e.r(566902));
    ((r.Version = e.r(425706).version),
      (r.isVercelIntegration = "https://s2340140.us-east-9.betterstackdata.com"),
      (r.isVercel = n.default.env.NEXT_PUBLIC_VERCEL || n.default.env.VERCEL),
      (r.isNetlify = "true" == n.default.env.NETLIFY),
      (r.isWebWorker =
        "u" > typeof self && void 0 !== globalThis.WorkerGlobalScope && self instanceof WorkerGlobalScope),
      (r.isBrowser = "u" > typeof window || r.isWebWorker),
      (r.isEdgeRuntime = !!globalThis.EdgeRuntime));
    let l = new o.default();
    ((r.config = l),
      r.isVercel ? (r.config = l = new s.default()) : r.isNetlify && (r.config = l = new a.default()));
  },
  279304,
  (e, t, r) => {
    "use strict";
    ((r.Headers = self.Headers),
      (r.Request = self.Request),
      (r.Response = self.Response),
      (r.fetch = self.fetch));
  },
  777375,
  (e, t, r) => {
    "use strict";
    var n,
      i,
      o = e.i(247167),
      s =
        (e.e && e.e.__awaiter) ||
        function (e, t, r, n) {
          return new (r || (r = Promise))(function (i, o) {
            function s(e) {
              try {
                l(n.next(e));
              } catch (e) {
                o(e);
              }
            }
            function a(e) {
              try {
                l(n.throw(e));
              } catch (e) {
                o(e);
              }
            }
            function l(e) {
              var t;
              e.done
                ? i(e.value)
                : ((t = e.value) instanceof r
                    ? t
                    : new r(function (e) {
                        e(t);
                      })
                  ).then(s, a);
            }
            l((n = n.apply(e, t || [])).next());
          });
        };
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      (r.prettyPrint = r.log = r.Logger = r.LogLevel = void 0));
    let a = e.r(413575),
      l = e.r(843740),
      u = a.config.getLogsEndpoint(),
      c = o.default.env.NEXT_PUBLIC_BETTER_STACK_LOG_LEVEL || "debug";
    (((n = i || (r.LogLevel = i = {}))[(n.debug = 0)] = "debug"),
      (n[(n.info = 1)] = "info"),
      (n[(n.warn = 2)] = "warn"),
      (n[(n.error = 3)] = "error"),
      (n[(n.off = 100)] = "off"));
    class d {
      constructor(e = {}) {
        var t = this;
        ((this.initConfig = e),
          (this.logEvents = []),
          (this.throttledSendLogs = (0, l.throttle)(this.sendLogs, 1e3)),
          (this.children = []),
          (this.logLevel = i.debug),
          (this.config = { autoFlush: !0, source: "frontend-log", prettyPrint: g }),
          (this.debug = function (e) {
            let r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            t.log(i.debug, e, r);
          }),
          (this.info = function (e) {
            let r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            t.log(i.info, e, r);
          }),
          (this.warn = function (e) {
            let r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            t.log(i.warn, e, r);
          }),
          (this.error = function (e) {
            let r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            t.log(i.error, e, r);
          }),
          (this.with = (e) => {
            let t = new d(
              Object.assign(Object.assign({}, this.config), {
                args: Object.assign(Object.assign({}, this.config.args), e),
              }),
            );
            return (this.children.push(t), t);
          }),
          (this.withRequest = (e) =>
            new d(
              Object.assign(Object.assign({}, this.config), {
                req: Object.assign(Object.assign({}, this.config.req), e),
              }),
            )),
          (this._transformEvent = function (e, r) {
            let n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
              o = {
                level: i[e].toString(),
                message: r,
                dt: new Date(Date.now()).toISOString(),
                source: t.config.source,
                fields: t.config.args || {},
                "@app": { "next-logtail-version": a.Version },
              };
            if (n instanceof Error)
              o.fields = Object.assign(Object.assign({}, o.fields), {
                message: n.message,
                stack: n.stack,
                name: n.name,
              });
            else if ("object" == typeof n && null !== n && Object.keys(n).length > 0) {
              let e = JSON.parse(JSON.stringify(n, h));
              o.fields = Object.assign(Object.assign({}, o.fields), e);
            } else n && n.length && (o.fields = Object.assign(Object.assign({}, o.fields), { args: n }));
            return (
              a.config.injectPlatformMetadata(o, t.config.source),
              null != t.config.req &&
                ((o.request = t.config.req),
                o.platform
                  ? (o.platform.route = t.config.req.path)
                  : o.vercel && (o.vercel.route = t.config.req.path)),
              o
            );
          }),
          (this.log = function (e, r) {
            let n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
            if (e < t.logLevel || t.logLevel === i.off) return;
            let o = t._transformEvent(e, r, n);
            (t.logEvents.push(o), t.config.autoFlush && t.throttledSendLogs());
          }),
          (this.attachResponseStatus = (e) => {
            this.logEvents = this.logEvents.map((t) => (t.request && (t.request.statusCode = e), t));
          }),
          (this.flush = () =>
            s(this, void 0, void 0, function* () {
              yield Promise.all([this.sendLogs(), ...this.children.map((e) => e.flush())]);
            })),
          void 0 != this.initConfig.logLevel && this.initConfig.logLevel >= 0
            ? (this.logLevel = this.initConfig.logLevel)
            : (this.logLevel = i[c]),
          (this.config = Object.assign(Object.assign({}, this.config), e)));
      }
      logHttpRequest(e, t, r, n) {
        if (e < this.logLevel || this.logLevel === i.off) return;
        let o = this._transformEvent(e, t, n);
        ((o.request = r), this.logEvents.push(o), this.config.autoFlush && this.throttledSendLogs());
      }
      middleware(e, t) {
        var r;
        let n = {
            ip: e.ip,
            region: null == (r = e.geo) ? void 0 : r.region,
            method: e.method,
            host: e.nextUrl.hostname,
            path: e.nextUrl.pathname,
            scheme: e.nextUrl.protocol.split(":")[0],
            referer: e.headers.get("Referer"),
            userAgent: e.headers.get("user-agent"),
          },
          o = `${e.method} ${e.nextUrl.pathname}`;
        return (null == t ? void 0 : t.logRequestDetails)
          ? (0, l.requestToJSON)(e).then((e) => {
              let r = Object.assign(Object.assign({}, n), {
                details: Array.isArray(t.logRequestDetails)
                  ? Object.fromEntries(
                      Object.entries(e).filter((e) => {
                        let [r] = e;
                        return t.logRequestDetails.includes(r);
                      }),
                    )
                  : e,
              });
              return this.logHttpRequest(i.info, o, r, {});
            })
          : this.logHttpRequest(i.info, o, n, {});
      }
      sendLogs() {
        return s(this, void 0, void 0, function* () {
          if (!this.logEvents.length) return;
          if (!a.config.isEnvVarsSet()) {
            (this.logEvents.forEach((e) => (this.config.prettyPrint ? this.config.prettyPrint(e) : g(e))),
              (this.logEvents = []));
            return;
          }
          let t = JSON.stringify(this.logEvents);
          this.logEvents = [];
          let r = { "Content-Type": "application/json", "User-Agent": "next-logtail/v" + a.Version };
          a.config.token && (r.Authorization = `Bearer ${a.config.token}`);
          let n = { body: t, method: "POST", keepalive: !0, headers: r };
          function i() {
            return fetch(u, n).catch(console.error);
          }
          try {
            if ("u" < typeof fetch) return (yield e.r(279304))(u, n).catch(console.error);
            if (!a.isBrowser || !a.isVercel || !navigator.sendBeacon) return i();
            try {
              if (!navigator.sendBeacon.bind(navigator)(u, t)) return i();
            } catch (e) {
              return i();
            }
          } catch (e) {
            (console.warn(`Failed to send logs to BetterStack: ${e}`),
              (this.logEvents = [...this.logEvents, JSON.parse(t)]));
          }
        });
      }
    }
    ((r.Logger = d), (r.log = new d({})));
    let f = {
      info: { terminal: "32", browser: "lightgreen" },
      debug: { terminal: "36", browser: "lightblue" },
      warn: { terminal: "33", browser: "yellow" },
      error: { terminal: "31", browser: "red" },
    };
    function g(e) {
      let t = Object.keys(e.fields).length > 0;
      if (l.isNoPrettyPrint) {
        let r = `${e.level} - ${e.message}`;
        (t && (r += " " + JSON.stringify(e.fields)), console.log(r));
        return;
      }
      let r = "",
        n = [e.level, e.message];
      (a.isBrowser
        ? ((r = "%c%s - %s"), (n = [`color: ${f[e.level].browser};`, ...n]))
        : (r = `\x1b[${f[e.level].terminal}m%s\x1b[0m - %s`),
        t && ((r += " %o"), n.push(e.fields)),
        e.request && ((r += " %o"), n.push(e.request)),
        console.log.apply(console, [r, ...n]));
    }
    function h(e, t) {
      return t instanceof Error
        ? Object.assign(Object.assign({}, t), { name: t.name, message: t.message, stack: t.stack })
        : t;
    }
    r.prettyPrint = g;
  },
  929879,
  (e) => {
    "use strict";
    var t = e.i(271645),
      r = Object.prototype.hasOwnProperty;
    function n(e, t, r) {
      for (r of e.keys()) if (i(r, t)) return r;
    }
    function i(e, t) {
      var o, s, a;
      if (e === t) return !0;
      if (e && t && (o = e.constructor) === t.constructor) {
        if (o === Date) return e.getTime() === t.getTime();
        if (o === RegExp) return e.toString() === t.toString();
        if (o === Array) {
          if ((s = e.length) === t.length) for (; s-- && i(e[s], t[s]););
          return -1 === s;
        }
        if (o === Set) {
          if (e.size !== t.size) return !1;
          for (s of e) if (((a = s) && "object" == typeof a && !(a = n(t, a))) || !t.has(a)) return !1;
          return !0;
        }
        if (o === Map) {
          if (e.size !== t.size) return !1;
          for (s of e)
            if (((a = s[0]) && "object" == typeof a && !(a = n(t, a))) || !i(s[1], t.get(a))) return !1;
          return !0;
        }
        if (o === ArrayBuffer) ((e = new Uint8Array(e)), (t = new Uint8Array(t)));
        else if (o === DataView) {
          if ((s = e.byteLength) === t.byteLength) for (; s-- && e.getInt8(s) === t.getInt8(s););
          return -1 === s;
        }
        if (ArrayBuffer.isView(e)) {
          if ((s = e.byteLength) === t.byteLength) for (; s-- && e[s] === t[s];);
          return -1 === s;
        }
        if (!o || "object" == typeof e) {
          for (o in ((s = 0), e))
            if ((r.call(e, o) && ++s && !r.call(t, o)) || !(o in t) || !i(e[o], t[o])) return !1;
          return Object.keys(t).length === s;
        }
      }
      return e != e && t != t;
    }
    function o(e) {
      let r = t.default.useRef(e),
        n = t.default.useRef(0);
      return (
        i(e, r.current) || ((r.current = e), (n.current += 1)),
        t.default.useMemo(() => r.current, [n.current])
      );
    }
    e.s(
      [
        "useDeepCompareCallback",
        0,
        function (e, r) {
          return t.default.useCallback(e, o(r));
        },
        "useDeepCompareEffect",
        0,
        function (e, r) {
          t.default.useEffect(e, o(r));
        },
        "useDeepCompareImperativeHandle",
        0,
        function (e, r, n) {
          t.default.useImperativeHandle(e, r, o(n));
        },
        "useDeepCompareLayoutEffect",
        0,
        function (e, r) {
          t.default.useLayoutEffect(e, o(r));
        },
        "useDeepCompareMemo",
        0,
        function (e, r) {
          return t.default.useMemo(e, o(r));
        },
      ],
      929879,
    );
  },
  491708,
  (e, t, r) => {
    !(function () {
      "use strict";
      var e = {};
      ((e.d = function (t, r) {
        for (var n in r)
          e.o(r, n) && !e.o(t, n) && Object.defineProperty(t, n, { enumerable: !0, get: r[n] });
      }),
        (e.o = function (e, t) {
          return Object.prototype.hasOwnProperty.call(e, t);
        }),
        (e.r = function (e) {
          ("u" > typeof Symbol &&
            Symbol.toStringTag &&
            Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
            Object.defineProperty(e, "__esModule", { value: !0 }));
        }),
        void 0 !== e && (e.ab = "/ROOT/node_modules/next/dist/compiled/web-vitals/"));
      var r = {};
      (e.r(r),
        e.d(r, {
          CLSThresholds: function () {
            return P;
          },
          FCPThresholds: function () {
            return O;
          },
          FIDThresholds: function () {
            return ee;
          },
          INPThresholds: function () {
            return A;
          },
          LCPThresholds: function () {
            return W;
          },
          TTFBThresholds: function () {
            return $;
          },
          onCLS: function () {
            return S;
          },
          onFCP: function () {
            return j;
          },
          onFID: function () {
            return et;
          },
          onINP: function () {
            return q;
          },
          onLCP: function () {
            return F;
          },
          onTTFB: function () {
            return X;
          },
        }));
      var n,
        i,
        o,
        s,
        a,
        l = -1,
        u = function (e) {
          addEventListener(
            "pageshow",
            function (t) {
              t.persisted && ((l = t.timeStamp), e(t));
            },
            !0,
          );
        },
        c = function () {
          var e =
            self.performance && performance.getEntriesByType && performance.getEntriesByType("navigation")[0];
          if (e && e.responseStart > 0 && e.responseStart < performance.now()) return e;
        },
        d = function () {
          var e = c();
          return (e && e.activationStart) || 0;
        },
        f = function (e, t) {
          var r = c(),
            n = "navigate";
          return (
            l >= 0
              ? (n = "back-forward-cache")
              : r &&
                (document.prerendering || d() > 0
                  ? (n = "prerender")
                  : document.wasDiscarded
                    ? (n = "restore")
                    : r.type && (n = r.type.replace(/_/g, "-"))),
            {
              name: e,
              value: void 0 === t ? -1 : t,
              rating: "good",
              delta: 0,
              entries: [],
              id: "v4-".concat(Date.now(), "-").concat(Math.floor(0x82f79cd8fff * Math.random()) + 1e12),
              navigationType: n,
            }
          );
        },
        g = function (e, t, r) {
          try {
            if (PerformanceObserver.supportedEntryTypes.includes(e)) {
              var n = new PerformanceObserver(function (e) {
                Promise.resolve().then(function () {
                  t(e.getEntries());
                });
              });
              return (n.observe(Object.assign({ type: e, buffered: !0 }, r || {})), n);
            }
          } catch (e) {}
        },
        h = function (e, t, r, n) {
          var i, o;
          return function (s) {
            var a;
            t.value >= 0 &&
              (s || n) &&
              ((o = t.value - (i || 0)) || void 0 === i) &&
              ((i = t.value),
              (t.delta = o),
              (a = t.value),
              (t.rating = a > r[1] ? "poor" : a > r[0] ? "needs-improvement" : "good"),
              e(t));
          };
        },
        p = function (e) {
          requestAnimationFrame(function () {
            return requestAnimationFrame(function () {
              return e();
            });
          });
        },
        m = function (e) {
          document.addEventListener("visibilitychange", function () {
            "hidden" === document.visibilityState && e();
          });
        },
        v = function (e) {
          var t = !1;
          return function () {
            t || (e(), (t = !0));
          };
        },
        b = -1,
        y = function () {
          return "hidden" !== document.visibilityState || document.prerendering ? 1 / 0 : 0;
        },
        E = function (e) {
          "hidden" === document.visibilityState &&
            b > -1 &&
            ((b = "visibilitychange" === e.type ? e.timeStamp : 0), _());
        },
        w = function () {
          (addEventListener("visibilitychange", E, !0), addEventListener("prerenderingchange", E, !0));
        },
        _ = function () {
          (removeEventListener("visibilitychange", E, !0), removeEventListener("prerenderingchange", E, !0));
        },
        T = function () {
          return (
            b < 0 &&
              ((b = y()),
              w(),
              u(function () {
                setTimeout(function () {
                  ((b = y()), w());
                }, 0);
              })),
            {
              get firstHiddenTime() {
                return b;
              },
            }
          );
        },
        L = function (e) {
          document.prerendering
            ? addEventListener(
                "prerenderingchange",
                function () {
                  return e();
                },
                !0,
              )
            : e();
        },
        O = [1800, 3e3],
        j = function (e, t) {
          ((t = t || {}),
            L(function () {
              var r,
                n = T(),
                i = f("FCP"),
                o = g("paint", function (e) {
                  e.forEach(function (e) {
                    "first-contentful-paint" === e.name &&
                      (o.disconnect(),
                      e.startTime < n.firstHiddenTime &&
                        ((i.value = Math.max(e.startTime - d(), 0)), i.entries.push(e), r(!0)));
                  });
                });
              o &&
                ((r = h(e, i, O, t.reportAllChanges)),
                u(function (n) {
                  ((r = h(e, (i = f("FCP")), O, t.reportAllChanges)),
                    p(function () {
                      ((i.value = performance.now() - n.timeStamp), r(!0));
                    }));
                }));
            }));
        },
        P = [0.1, 0.25],
        S = function (e, t) {
          ((t = t || {}),
            j(
              v(function () {
                var r,
                  n = f("CLS", 0),
                  i = 0,
                  o = [],
                  s = function (e) {
                    (e.forEach(function (e) {
                      if (!e.hadRecentInput) {
                        var t = o[0],
                          r = o[o.length - 1];
                        i && e.startTime - r.startTime < 1e3 && e.startTime - t.startTime < 5e3
                          ? ((i += e.value), o.push(e))
                          : ((i = e.value), (o = [e]));
                      }
                    }),
                      i > n.value && ((n.value = i), (n.entries = o), r()));
                  },
                  a = g("layout-shift", s);
                a &&
                  ((r = h(e, n, P, t.reportAllChanges)),
                  m(function () {
                    (s(a.takeRecords()), r(!0));
                  }),
                  u(function () {
                    ((i = 0),
                      (r = h(e, (n = f("CLS", 0)), P, t.reportAllChanges)),
                      p(function () {
                        return r();
                      }));
                  }),
                  setTimeout(r, 0));
              }),
            ));
        },
        R = 0,
        C = 1 / 0,
        k = 0,
        x = function (e) {
          e.forEach(function (e) {
            e.interactionId &&
              ((C = Math.min(C, e.interactionId)),
              (R = (k = Math.max(k, e.interactionId)) ? (k - C) / 7 + 1 : 0));
          });
        },
        I = function () {
          "interactionCount" in performance ||
            n ||
            (n = g("event", x, { type: "event", buffered: !0, durationThreshold: 0 }));
        },
        N = [],
        B = new Map(),
        D = 0,
        V = [],
        M = function (e) {
          if (
            (V.forEach(function (t) {
              return t(e);
            }),
            e.interactionId || "first-input" === e.entryType)
          ) {
            var t = N[N.length - 1],
              r = B.get(e.interactionId);
            if (r || N.length < 10 || e.duration > t.latency) {
              if (r)
                e.duration > r.latency
                  ? ((r.entries = [e]), (r.latency = e.duration))
                  : e.duration === r.latency && e.startTime === r.entries[0].startTime && r.entries.push(e);
              else {
                var n = { id: e.interactionId, latency: e.duration, entries: [e] };
                (B.set(n.id, n), N.push(n));
              }
              (N.sort(function (e, t) {
                return t.latency - e.latency;
              }),
                N.length > 10 &&
                  N.splice(10).forEach(function (e) {
                    return B.delete(e.id);
                  }));
            }
          }
        },
        U = function (e) {
          var t = self.requestIdleCallback || self.setTimeout,
            r = -1;
          return ((e = v(e)), "hidden" === document.visibilityState ? e() : ((r = t(e)), m(e)), r);
        },
        A = [200, 500],
        q = function (e, t) {
          "PerformanceEventTiming" in self &&
            "interactionId" in PerformanceEventTiming.prototype &&
            ((t = t || {}),
            L(function () {
              I();
              var r,
                i,
                o = f("INP"),
                s = function (e) {
                  U(function () {
                    e.forEach(M);
                    var t,
                      r =
                        ((t = Math.min(
                          N.length - 1,
                          Math.floor(((n ? R : performance.interactionCount || 0) - D) / 50),
                        )),
                        N[t]);
                    r && r.latency !== o.value && ((o.value = r.latency), (o.entries = r.entries), i());
                  });
                },
                a = g("event", s, { durationThreshold: null != (r = t.durationThreshold) ? r : 40 });
              ((i = h(e, o, A, t.reportAllChanges)),
                a &&
                  (a.observe({ type: "first-input", buffered: !0 }),
                  m(function () {
                    (s(a.takeRecords()), i(!0));
                  }),
                  u(function () {
                    ((D = 0), (N.length = 0), B.clear(), (i = h(e, (o = f("INP")), A, t.reportAllChanges)));
                  })));
            }));
        },
        W = [2500, 4e3],
        H = {},
        F = function (e, t) {
          ((t = t || {}),
            L(function () {
              var r,
                n = T(),
                i = f("LCP"),
                o = function (e) {
                  (t.reportAllChanges || (e = e.slice(-1)),
                    e.forEach(function (e) {
                      e.startTime < n.firstHiddenTime &&
                        ((i.value = Math.max(e.startTime - d(), 0)), (i.entries = [e]), r());
                    }));
                },
                s = g("largest-contentful-paint", o);
              if (s) {
                r = h(e, i, W, t.reportAllChanges);
                var a = v(function () {
                  H[i.id] || (o(s.takeRecords()), s.disconnect(), (H[i.id] = !0), r(!0));
                });
                (["keydown", "click"].forEach(function (e) {
                  addEventListener(
                    e,
                    function () {
                      return U(a);
                    },
                    !0,
                  );
                }),
                  m(a),
                  u(function (n) {
                    ((r = h(e, (i = f("LCP")), W, t.reportAllChanges)),
                      p(function () {
                        ((i.value = performance.now() - n.timeStamp), (H[i.id] = !0), r(!0));
                      }));
                  }));
              }
            }));
        },
        $ = [800, 1800],
        G = function e(t) {
          document.prerendering
            ? L(function () {
                return e(t);
              })
            : "complete" !== document.readyState
              ? addEventListener(
                  "load",
                  function () {
                    return e(t);
                  },
                  !0,
                )
              : setTimeout(t, 0);
        },
        X = function (e, t) {
          t = t || {};
          var r = f("TTFB"),
            n = h(e, r, $, t.reportAllChanges);
          G(function () {
            var i = c();
            i &&
              ((r.value = Math.max(i.responseStart - d(), 0)),
              (r.entries = [i]),
              n(!0),
              u(function () {
                (n = h(e, (r = f("TTFB", 0)), $, t.reportAllChanges))(!0);
              }));
          });
        },
        J = { passive: !0, capture: !0 },
        z = new Date(),
        Y = function (e, t) {
          i || ((i = t), (o = e), (s = new Date()), Q(removeEventListener), K());
        },
        K = function () {
          if (o >= 0 && o < s - z) {
            var e = {
              entryType: "first-input",
              name: i.type,
              target: i.target,
              cancelable: i.cancelable,
              startTime: i.timeStamp,
              processingStart: i.timeStamp + o,
            };
            (a.forEach(function (t) {
              t(e);
            }),
              (a = []));
          }
        },
        Z = function (e) {
          if (e.cancelable) {
            var t,
              r,
              n,
              i = (e.timeStamp > 1e12 ? new Date() : performance.now()) - e.timeStamp;
            "pointerdown" == e.type
              ? ((t = function () {
                  (Y(i, e), n());
                }),
                (r = function () {
                  n();
                }),
                (n = function () {
                  (removeEventListener("pointerup", t, J), removeEventListener("pointercancel", r, J));
                }),
                addEventListener("pointerup", t, J),
                addEventListener("pointercancel", r, J))
              : Y(i, e);
          }
        },
        Q = function (e) {
          ["mousedown", "keydown", "touchstart", "pointerdown"].forEach(function (t) {
            return e(t, Z, J);
          });
        },
        ee = [100, 300],
        et = function (e, t) {
          ((t = t || {}),
            L(function () {
              var r,
                n = T(),
                s = f("FID"),
                l = function (e) {
                  e.startTime < n.firstHiddenTime &&
                    ((s.value = e.processingStart - e.startTime), s.entries.push(e), r(!0));
                },
                c = function (e) {
                  e.forEach(l);
                },
                d = g("first-input", c);
              ((r = h(e, s, ee, t.reportAllChanges)),
                d &&
                  (m(
                    v(function () {
                      (c(d.takeRecords()), d.disconnect());
                    }),
                  ),
                  u(function () {
                    ((r = h(e, (s = f("FID")), ee, t.reportAllChanges)),
                      (a = []),
                      (o = -1),
                      (i = null),
                      Q(addEventListener),
                      a.push(l),
                      K());
                  })));
            }));
        };
      t.exports = r;
    })();
  },
  208619,
  (e, t, r) => {
    "use strict";
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "useReportWebVitals", {
        enumerable: !0,
        get: function () {
          return o;
        },
      }));
    let n = e.r(271645),
      i = e.r(491708);
    function o(e) {
      (0, n.useEffect)(() => {
        ((0, i.onCLS)(e),
          (0, i.onFID)(e),
          (0, i.onLCP)(e),
          (0, i.onINP)(e),
          (0, i.onFCP)(e),
          (0, i.onTTFB)(e));
      }, [e]);
    }
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  395816,
  (e, t, r) => {
    t.exports = e.r(208619);
  },
  566594,
  979431,
  102241,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(271645),
      n = e.i(523173),
      i = e.i(86596);
    e.i(756503);
    var o = e.i(542516);
    e.i(470366);
    var s = e.i(504001),
      a = e.i(866897),
      l = e.i(930652);
    let u = /^(\d+|[0-9a-f]{8}-[0-9a-f-]{27}|[\w-]{20,})$/i,
      c = (e, t) => ({
        event: "clientErrorReported",
        user_email: e?.email,
        user_id: e?.id,
        session: e?.email ? "signed in" : "anonymous",
        country: document.cookie
          .split("; ")
          .find((e) => e.startsWith(`${a.ECookieArg.COUNTRY}=`))
          ?.split("=")[1],
        error_type: t,
        route_pattern: ((e) => {
          let [t, ...r] = e.split("/").filter(Boolean),
            n = l.routing.locales.includes(t) ? r : [t, ...r];
          return `/${n
            .filter(Boolean)
            .map((e) => (u.test(e) ? ":id" : e))
            .join("/")}`;
        })(window.location.pathname),
      });
    var d = e.i(651501);
    let f = (e) => {
        if ("AbortError" === e.name) return "aborted";
        if ("ChunkLoadError" === e.name) return "chunk-load-error";
        let t = e.message?.toLowerCase() ?? "";
        if (t.includes("failed to load chunk")) return "chunk-load-error";
        if (t.includes("load failed") || t.includes("failed to fetch") || t.includes("networkerror")) {
          let t = e.stack ?? "";
          return t.includes("import(") || t.includes("__webpack") || t.includes("chunk")
            ? "dynamic-import-load-failed"
            : "fetch-load-failed";
        }
        return t.includes("loading chunk") ||
          t.includes("loading css chunk") ||
          t.includes("importing a module script failed") ||
          t.includes("dynamically imported module")
          ? "chunk-load-error"
          : t.includes("timeout")
            ? "timeout"
            : t.includes("cors")
              ? "cors"
              : (e.name ?? "unknown");
      },
      g = ["chunk-load-error"],
      h = "chunk_error_reload_at",
      p = "chunk_error_reload_count",
      m = (e) => {
        if (window.navigator?.onLine === !1 || !g.includes(f(e))) return !1;
        try {
          let e = Number(window.sessionStorage.getItem(h) ?? 0),
            t = Number(window.sessionStorage.getItem(p) ?? 0);
          if (t >= 2 || Date.now() - e < 6e4) return !1;
          return (
            window.sessionStorage.setItem(h, String(Date.now())),
            window.sessionStorage.setItem(p, String(t + 1)),
            !0
          );
        } catch {
          return !1;
        }
      },
      v = [
        "chrome-extension://",
        "moz-extension://",
        "safari-web-extension://",
        "extensions::",
        "webkit.messageHandlers",
        "sendDataToNative",
        "sendPageShowMessage",
        "DarkReader",
        "ResizeObserver loop",
        "jQuery is not defined",
      ],
      b = (e, t) => {
        let r = `${e ?? ""} ${t ?? ""}`;
        return v.some((e) => r.includes(e));
      },
      y = function (e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 5;
        if (e) return e.split("\n").slice(0, t).join("\n");
      },
      E = function (e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
        if (e instanceof d.HTTPError) {
          let { response: r, request: n } = e;
          return {
            error_message: e.message || t,
            error_name: e.name,
            error_type: "http-error",
            response_code: r.status,
            request_method: n.method,
            request_url: n.url,
            error_stack: y(e.stack),
          };
        }
        if (e instanceof Error) {
          let r = f(e);
          return {
            error_message: e.message || t,
            error_name: e.name,
            error_type: r,
            request_url: e.__requestUrl,
            request_method: e.__requestMethod,
            error_stack: y(e.stack),
          };
        }
        if (null !== e && "object" == typeof e)
          try {
            return {
              error_message: t || "Non-Error rejection",
              error_name: "ObjectRejection",
              error_type: "object-rejection",
              rejection_reason_json: JSON.stringify(e),
            };
          } catch {
            return { error_message: String(e), error_type: "object-rejection" };
          }
        return {
          error_message: null != e && "" !== e ? String(e) : t || "Unknown error",
          error_type: "primitive-rejection",
        };
      };
    class w extends r.Component {
      constructor(e) {
        (super(e), (this.state = { hasError: !1, error: null, isReloading: !1 }));
      }
      static getDerivedStateFromError(e) {
        return { hasError: !0, error: e };
      }
      componentDidCatch(e, t) {
        let r = m(e);
        r && this.setState({ isReloading: !0 });
        try {
          (0, s.trackClientEvents)({
            event: n.EAnalyticEvents.GLOBAL_ERROR_CAUGHT,
            user: this.props.user,
            params: { ...E(e), componentStack: t.componentStack, chunk_reload_attempted: r },
          });
        } catch {}
        (console.error("ErrorBoundary caught an error:", e, t), r && window.location.reload());
      }
      render() {
        return this.state.isReloading
          ? null
          : this.state.hasError
            ? (0, t.jsx)("div", {
                className: "flex min-h-screen w-full items-center justify-center bg-white p-4",
                children: (0, t.jsxs)("div", {
                  className: "max-w-md text-center",
                  children: [
                    (0, t.jsx)("h1", {
                      className: "mb-4 text-2xl font-bold text-gray-900",
                      children: "Application Error",
                    }),
                    (0, t.jsx)("p", {
                      className: "mb-4 text-gray-600",
                      children:
                        "Something went wrong. Please try refreshing the page or contact support if the problem persists.",
                    }),
                    this.state.error &&
                      "production" !== o.envClient.NEXT_PUBLIC_NODE_ENV &&
                      (0, t.jsxs)("details", {
                        className: "mt-4 text-left",
                        children: [
                          (0, t.jsx)("summary", {
                            className: "cursor-pointer text-sm text-gray-500",
                            children: "Error Details",
                          }),
                          (0, t.jsx)("pre", {
                            className: "mt-2 overflow-auto rounded bg-gray-100 p-2 text-xs text-gray-800",
                            children: this.state.error.toString(),
                          }),
                        ],
                      }),
                  ],
                }),
              })
            : this.props.children;
      }
    }
    var _ = e.i(558268),
      T = e.i(915101);
    (e.s(
      [
        "GlobalErrorHandler",
        0,
        () => {
          let e = (0, i.useUserStore)((e) => e.user),
            t = (0, T.useLogger)({ source: "GlobalErrorHandler" });
          return (
            (0, r.useEffect)(() => {
              let e;
              return (
                (e = window.fetch),
                (window.fetch = async function (t, r) {
                  let n = "string" == typeof t ? t : t instanceof Request ? t.url : String(t),
                    i = (r?.method ?? (t instanceof Request ? t.method : void 0) ?? "GET").toUpperCase();
                  try {
                    return await e.call(this, t, r);
                  } catch (e) {
                    throw (
                      e instanceof Error &&
                        !(e instanceof d.HTTPError) &&
                        ((e.__requestUrl = n), (e.__requestMethod = i)),
                      e
                    );
                  }
                }),
                () => {
                  window.fetch = e;
                }
              );
            }, []),
            (0, r.useEffect)(() => {
              let r = (r) => {
                  let i = r.error || Error(r.message || "Window error");
                  if (b(i.message || r.message, i.stack)) return;
                  let o = m(i),
                    a = E(i, r.message);
                  (t.log(_.LogLevel.error, i.message || "window.onerror", {
                    ...a,
                    ...c(e, a.error_type),
                    source: "window.onerror",
                    filename: r.filename,
                    lineno: r.lineno,
                    colno: r.colno,
                    pathname: window.location.pathname,
                    href: window.location.href,
                    userId: e?.id,
                    chunk_reload_attempted: o,
                  }),
                    (0, s.trackClientEvents)({
                      event: n.EAnalyticEvents.GLOBAL_ERROR_CAUGHT,
                      user: e,
                      params: {
                        ...E(i, r.message),
                        source: "window.onerror",
                        filename: r.filename,
                        lineno: r.lineno,
                        colno: r.colno,
                        chunk_reload_attempted: o,
                      },
                    }),
                    o && window.location.reload());
                },
                i = (r) => {
                  let { reason: i } = r;
                  if (i instanceof Error && "AbortError" === i.name) return;
                  let o = E(i),
                    a = ((e, t) => {
                      if (e instanceof d.HTTPError) {
                        let { response: t, request: r } = e,
                          n = new URL(r.url).pathname;
                        return `HTTP ${t.status}: ${r.method} ${n}`;
                      }
                      return (e instanceof Error && e.message) || t;
                    })(i, "unhandledrejection");
                  if (b(a, i instanceof Error ? i.stack : void 0)) return;
                  let l = i instanceof Error && m(i);
                  (t.log(_.LogLevel.error, a, {
                    ...o,
                    ...c(e, o.error_type),
                    source: "unhandledrejection",
                    pathname: window.location.pathname,
                    href: window.location.href,
                    userId: e?.id,
                    chunk_reload_attempted: l,
                  }),
                    (0, s.trackClientEvents)({
                      event: n.EAnalyticEvents.GLOBAL_ERROR_CAUGHT,
                      user: e,
                      params: { ...o, source: "unhandledrejection", chunk_reload_attempted: l },
                    }),
                    l && window.location.reload());
                };
              return (
                window.addEventListener("error", r),
                window.addEventListener("unhandledrejection", i),
                () => {
                  (window.removeEventListener("error", r),
                    window.removeEventListener("unhandledrejection", i));
                }
              );
            }, [t, e]),
            null
          );
        },
      ],
      979431,
    ),
      e.s([], 566594),
      e.s(
        [
          "ErrorBoundary",
          0,
          (e) => {
            let { children: r } = e,
              n = (0, i.useUserStore)((e) => e.user);
            return (0, t.jsx)(w, { user: n, children: r });
          },
        ],
        102241,
      ));
  },
]);
