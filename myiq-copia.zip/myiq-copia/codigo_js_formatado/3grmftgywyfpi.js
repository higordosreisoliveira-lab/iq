(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  882983,
  (e) => {
    "use strict";
    var t = e.i(265840),
      i = e.i(271645),
      s = e.i(273830),
      a = e.i(620253),
      r = e.i(75540),
      l = e.i(843476),
      o = (0, s.forwardRef)((e, s) => {
        let { as: o, children: n, className: d, ...u } = e,
          { slots: c, classNames: _, bodyId: f, setBodyMounted: m } = (0, t.useModalContext)(),
          p = (0, a.useDOMRef)(s);
        return (
          (0, i.useEffect)(() => (m(!0), () => m(!1)), [m]),
          (0, l.jsx)(o || "div", {
            ref: p,
            className: c.body({ class: (0, r.clsx)(null == _ ? void 0 : _.body, d) }),
            id: f,
            ...u,
            children: n,
          })
        );
      });
    ((o.displayName = "HeroUI.ModalBody"), e.s(["ModalBody", 0, o], 882983));
  },
  949411,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("clock", [
      ["path", { d: "M12 6v6l4 2", key: "mmk7yg" }],
      ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
    ]);
    e.s(["default", 0, t]);
  },
  531447,
  (e) => {
    "use strict";
    var t = e.i(949411);
    e.s(["ClockIcon", () => t.default]);
  },
  914299,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("heart", [
      [
        "path",
        {
          d: "M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5",
          key: "mvr1a0",
        },
      ],
    ]);
    e.s(["default", 0, t]);
  },
  293625,
  (e) => {
    "use strict";
    var t = e.i(914299);
    e.s(["HeartIcon", () => t.default]);
  },
  661263,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("split", [
      ["path", { d: "M16 3h5v5", key: "1806ms" }],
      ["path", { d: "M8 3H3v5", key: "15dfkv" }],
      ["path", { d: "M12 22v-8.3a4 4 0 0 0-1.172-2.872L3 3", key: "1qrqzj" }],
      ["path", { d: "m15 9 6-6", key: "ko1vev" }],
    ]);
    e.s(["Split", 0, t], 661263);
  },
  547105,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(531447),
      s = e.i(293625),
      a = e.i(661263),
      r = e.i(948148),
      l = e.i(271645);
    e.i(476643);
    var o = e.i(408241),
      n = e.i(712470),
      d = e.i(946684);
    e.i(317197);
    var u = e.i(231529),
      c = e.i(475091),
      _ = e.i(622963),
      f = e.i(86596);
    e.i(568267);
    var m = e.i(154692);
    let p = (e) => {
      let { icon: i, value: s } = e;
      return (0, t.jsxs)("div", {
        className: "flex flex-col items-center justify-center gap-1 rounded-lg py-1.5 text-sm",
        children: [
          (0, t.jsx)("div", {
            className: "flex h-10 w-10 shrink-0 items-center justify-center",
            children: (0, t.jsx)("div", { children: i }),
          }),
          (0, t.jsxs)("span", { className: "text-md font-semibold", children: ["+", s] }),
        ],
      });
    };
    e.s(
      [
        "default",
        0,
        (e) => {
          let { achivedXP: T } = e,
            E = (0, r.useTranslations)(),
            [v, S] = (0, l.useState)(!1),
            A = (0, _.useModalStore)((e) => e.handleChangeModalStore),
            R = (0, o.useTriviaTestStore)((e) => e.handleTriviaTestStore),
            O = (0, o.useTriviaTestStore)((e) => e.fiftyFiftyUses),
            I = (0, o.useTriviaTestStore)((e) => e.extraTimeUses),
            y = (0, o.useTriviaTestStore)((e) => e.hearts),
            C = (0, o.useTriviaTestStore)((e) => e.fiftyFiftyRefillAt),
            h = (0, o.useTriviaTestStore)((e) => e.extraTimeRefillAt),
            x = (0, f.useUserStore)((e) => e.user?.email),
            { data: w } = (0, d.useGetProfileQuery)(x || ""),
            N = w?.data?.user_info,
            { trigger: U } = (0, n.usePatchUserMutation)(),
            L = async () => {
              S(!0);
              let e = O + Number(T?.cutOff || 0),
                t = I + Number(T?.timeUp || 0),
                i = y + Number(T?.powerUp || 0),
                s = T?.id;
              (c.sound.play("levelCompleteScale"),
                R({
                  showLevelUpConfetti: !0,
                  achivedXPBoostId: s,
                  fiftyFiftyUses: e,
                  extraTimeUses: t,
                  hearts: i,
                }),
                N?.email &&
                  (await U({
                    email: N.email,
                    userInfo: {
                      trivia_test_data: {
                        ...N.trivia_test_data,
                        achivedXPBoostId: s,
                        fiftyFiftyUses: e,
                        extraTimeUses: t,
                        hearts: i,
                        fiftyFiftyRefillAt: C || void 0,
                        extraTimeRefillAt: h || void 0,
                      },
                    },
                  })),
                setTimeout(() => {
                  R({ showLevelUpConfetti: !1 });
                }, 5e3),
                A({ isModalVisible: !1, modalComponent: null }));
            };
          return (0, t.jsxs)(u.ModalBodyComponent, {
            title: E("trivia_achieved_bonus_modal_title"),
            subtitle: E("trivia_achieved_bonus_modal_description"),
            children: [
              (0, t.jsxs)("div", {
                className: "mt-3 flex flex-row items-center justify-center gap-12",
                children: [
                  T?.powerUp && T.powerUp > 0
                    ? (0, t.jsx)(p, {
                        icon: (0, t.jsx)(s.HeartIcon, { className: "h-8 w-8 fill-rose-600 text-rose-600" }),
                        value: T?.powerUp || 0,
                      })
                    : null,
                  T?.timeUp && T.timeUp > 0
                    ? (0, t.jsx)(p, {
                        icon: (0, t.jsx)(i.ClockIcon, { className: "h-8 w-8 text-blue-600" }),
                        value: T?.timeUp || 0,
                      })
                    : null,
                  T?.cutOff && T.cutOff > 0
                    ? (0, t.jsx)(p, {
                        icon: (0, t.jsx)(a.Split, { className: "h-8 w-8 text-amber-500" }),
                        value: T?.cutOff || 0,
                      })
                    : null,
                ],
              }),
              (0, t.jsx)("div", {
                className: "mt-5 flex w-full justify-center",
                children: (0, t.jsx)(m.ButtonComponent, {
                  text: E("trivia_achieved_bonus_modal_collect"),
                  size: "sm",
                  className: "mt-auto w-full capitalize xs-base:px-6 lg:w-full lg:min-w-[248px]",
                  onClick: L,
                  isDisabled: v,
                }),
              }),
            ],
          });
        },
      ],
      547105,
    );
  },
  194747,
  function (e) {
    e.n(e.i(547105));
  },
  476643,
  408241,
  (e) => {
    "use strict";
    var t = e.i(768834),
      i = e.i(579473),
      s = e.i(265832);
    let a = {
        timeLeft: s.TIMER_DURATION,
        streak: 0,
        maxStreak: 0,
        earnedXPCurrentLevel: 0,
        correctAnswers: 0,
        currentQuestionIdx: 0,
        isTestCompleted: !1,
        streakMilestonesReached: { streak3: !1, streak5: !1, streak10: !1 },
        hearts: s.HEARTS_CONFIG.INITIAL_HEARTS,
        currentCognitiveSkill: "working-memory",
        currentLevel: 1,
        cognitiveSkillName: "generic",
        questionTimes: [],
        questionStartTime: null,
        fiftyFiftyUses: s.POWER_UPS_CONFIG.INITIAL_FIFTY_FIFTY_USES,
        extraTimeUses: s.POWER_UPS_CONFIG.INITIAL_EXTRA_TIME_USES,
        usedFiftyFiftyOnQuestion: null,
        usedExtraTimeOnQuestion: null,
        disabledAnswers: [],
        achivedXPBoostId: null,
        fiftyFiftyRefillAt: null,
        extraTimeRefillAt: null,
        heartsRefillAt: null,
        progressSaved: !1,
        skillBoosts: { logic: 0, visual: 0, memory: 0 },
        showLevelUpConfetti: !1,
        completionSoundPlayed: !1,
        givenAnswers: [],
        dailyProgress: { date: null, levelsCompleted: 0, dailyTargetsCompleted: 0 },
      },
      r = (0, t.create)()(
        (0, i.persist)(
          (0, i.devtools)(
            (e) => ({
              ...a,
              handleTriviaTestStore: (t) => e((e) => ({ ...e, ...t })),
              resetTriviaTestStore: () => e(a),
              clearStorage: () => {
                (e(a), localStorage.removeItem("trivia-test-storage"));
              },
            }),
            { enabled: !1 },
          ),
          {
            name: "trivia-test-storage",
            partialize: (e) => ({
              currentQuestionIdx: e.currentQuestionIdx,
              streak: e.streak,
              maxStreak: e.maxStreak,
              earnedXPCurrentLevel: e.earnedXPCurrentLevel,
              correctAnswers: e.correctAnswers,
              isTestCompleted: e.isTestCompleted,
              streakMilestonesReached: e.streakMilestonesReached,
              hearts: e.hearts,
              currentCognitiveSkill: e.currentCognitiveSkill,
              currentLevel: e.currentLevel,
              cognitiveSkillName: e.cognitiveSkillName,
              questionTimes: e.questionTimes,
              questionStartTime: e.questionStartTime,
              fiftyFiftyUses: e.fiftyFiftyUses,
              extraTimeUses: e.extraTimeUses,
              usedFiftyFiftyOnQuestion: e.usedFiftyFiftyOnQuestion,
              usedExtraTimeOnQuestion: e.usedExtraTimeOnQuestion,
              disabledAnswers: e.disabledAnswers,
              fiftyFiftyRefillAt: e.fiftyFiftyRefillAt,
              extraTimeRefillAt: e.extraTimeRefillAt,
              heartsRefillAt: e.heartsRefillAt,
              skillBoosts: e.skillBoosts,
              achivedXPBoostId: e.achivedXPBoostId,
              givenAnswers: e.givenAnswers,
              dailyProgress: e.dailyProgress,
              completionSoundPlayed: e.completionSoundPlayed,
            }),
          },
        ),
      );
    (e.s(["useTriviaTestStore", 0, r], 408241), e.s([], 476643));
  },
  317197,
  231529,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(882983),
      s = e.i(742214),
      a = e.i(663615);
    e.i(680460);
    var r = e.i(885944);
    (e.s([], 317197),
      e.s(
        [
          "ModalBodyComponent",
          0,
          (e) => {
            let {
              children: l,
              title: o,
              subtitle: n,
              className: d = "",
              bodyClassName: u,
              titleClassName: c,
            } = e;
            return (0, t.jsx)(s.ModalContent, {
              className: d,
              children: (0, t.jsxs)(i.ModalBody, {
                className: (0, a.cn)(
                  "flex h-full w-full flex-col gap-5 p-5 antialiased md:p-6 [@media(max-height:580px)]:gap-3 [@media(max-height:580px)]:p-4",
                  u,
                ),
                children: [
                  (o || n) &&
                    (0, t.jsx)(r.ModalHeaderComponent, { title: o, subtitle: n, titleClassName: c }),
                  l,
                ],
              }),
            });
          },
        ],
        231529,
      ));
  },
  265832,
  (e) => {
    "use strict";
    e.s([
      "ANIMATION_CONFIG",
      0,
      { COIN_ANIMATION_DURATION: 1200, MIN_INTERVAL_DURATION: 16, NOTIFICATION_DELAY: 1200 },
      "AVERAGE_TIME_FOR_SKILL_BOOST",
      0,
      8e3,
      "DAILY_FULL_COMPLETION_KEYS",
      0,
      [
        "trivia_daily_full_0",
        "trivia_daily_full_1",
        "trivia_daily_full_2",
        "trivia_daily_full_3",
        "trivia_daily_full_4",
        "trivia_daily_full_5",
        "trivia_daily_full_6",
        "trivia_daily_full_7",
      ],
      "DAILY_NOT_FULL_COMPLETION_KEYS",
      0,
      [
        "trivia_daily_more_0",
        "trivia_daily_more_1",
        "trivia_daily_more_2",
        "trivia_daily_more_3",
        "trivia_daily_more_4",
        "trivia_daily_more_5",
        "trivia_daily_more_6",
        "trivia_daily_more_7",
      ],
      "DAILY_PROGRESS_SETS",
      0,
      5,
      "HEARTS_CONFIG",
      0,
      {
        INITIAL_HEARTS: 3,
        PURCHASED_HEARTS: 5,
        HEARTS_LOSS_PER_WRONG_ANSWER: 1,
        HEARTS_ANIMATION_DELAY: 700,
        HEARTS_ANIMATION_DURATION: 600,
      },
      "LEVEL_COMPLETED_BONUS",
      0,
      10,
      "MOVE_TO_TEST_COMPLETION_DELAY",
      0,
      400,
      "PLAY_COIN_REWARD_SOUND_AFTER_DELAY",
      0,
      500,
      "POWER_UPS_CONFIG",
      0,
      { INITIAL_FIFTY_FIFTY_USES: 3, INITIAL_EXTRA_TIME_USES: 3, EXTRA_TIME_SECONDS: 30, REFILL_TIME: 18e5 },
      "SKILL_BOOST_SCORE",
      0,
      0.3,
      "STREAK_BONUS_XP",
      0,
      { STREAK_3: 10, STREAK_5: 20, STREAK_10: 50 },
      "STREAK_MILESTONES",
      0,
      { STREAK_3: 3, STREAK_5: 5, STREAK_10: 10 },
      "TIMER_DURATION",
      0,
      20,
      "TIME_UNTIL_NEXT_TEST",
      0,
      18e5,
      "TRIVIA_COMPLETE_SCREEN_SUBTITLE_KEYS",
      0,
      [
        "trivia_complete_subtitle_0",
        "trivia_complete_subtitle_1",
        "trivia_complete_subtitle_2",
        "trivia_complete_subtitle_3",
        "trivia_complete_subtitle_4",
        "trivia_complete_subtitle_5",
        "trivia_complete_subtitle_6",
        "trivia_complete_subtitle_7",
      ],
      "XP_BOOST_CONFIG",
      0,
      [
        { id: 1, xp: 90, powerUp: 2, timeUp: 0, cutOff: 0 },
        { id: 2, xp: 200, powerUp: 3, timeUp: 1, cutOff: 0 },
        { id: 3, xp: 450, powerUp: 4, timeUp: 1, cutOff: 1 },
        { id: 4, xp: 800, powerUp: 5, timeUp: 2, cutOff: 1 },
        { id: 5, xp: 1400, powerUp: 7, timeUp: 3, cutOff: 2 },
        { id: 6, xp: 2200, powerUp: 10, timeUp: 4, cutOff: 3 },
        { id: 7, xp: 3200, powerUp: 12, timeUp: 5, cutOff: 4 },
        { id: 8, xp: 4500, powerUp: 15, timeUp: 6, cutOff: 5 },
        { id: 9, xp: 6500, powerUp: 18, timeUp: 8, cutOff: 6 },
        { id: 10, xp: 9e3, powerUp: 22, timeUp: 10, cutOff: 8 },
        { id: 11, xp: 13e3, powerUp: 27, timeUp: 12, cutOff: 10 },
        { id: 12, xp: 18e3, powerUp: 35, timeUp: 15, cutOff: 12 },
      ],
      "XP_PER_CORRECT_ANSWER",
      0,
      10,
    ]);
  },
  475091,
  (e) => {
    "use strict";
    let t, i, s, a, r, l, o, n, d, u, c, _, f;
    var m,
      p =
        (((m = {}).CORRECT = "/sounds/correct.mp3"),
        (m.INCORRECT = "/sounds/incorrect.mp3"),
        (m.LEVEL_COMPLETE = "/sounds/level-complete.mp3"),
        (m.START = "/sounds/start.mp3"),
        (m.REWARD = "/sounds/reward.mp3"),
        (m.OPTION_SCALE = "/sounds/scales/option.mp3"),
        (m.LEVEL_COMPLETE_SCALE = "/sounds/scales/final.mp3"),
        (m.CORRECT_SCALE = "/sounds/scales/right.mp3"),
        (m.INCORRECT_SCALE = "/sounds/scales/wrong.mp3"),
        (m.NEXT_SCALE = "/sounds/scales/continue.mp3"),
        (m.TIME_UP = "/sounds/time-up.mp3"),
        (m.INCORRECT_HEART = "/sounds/trivia/fail-heart-2.mp3"),
        (m.REWARD_SOUND_4 = "/sounds/trivia/reward-4.mp3"),
        m);
    let T = {
        correct: p.CORRECT,
        incorrect: p.INCORRECT,
        levelComplete: p.LEVEL_COMPLETE,
        start: p.START,
        reward: p.REWARD,
        optionScale: p.OPTION_SCALE,
        levelCompleteScale: p.LEVEL_COMPLETE_SCALE,
        correctScale: p.CORRECT_SCALE,
        incorrectScale: p.INCORRECT_SCALE,
        nextScale: p.NEXT_SCALE,
        timeUp: p.TIME_UP,
        reward4: p.REWARD_SOUND_4,
        incorrectHeart: p.INCORRECT_HEART,
      },
      E =
        ((t = new (window.AudioContext || window.webkitAudioContext)()),
        (i = new Map()),
        (s = new Map()),
        (a = new Map()),
        (r = new Map()),
        (l = !0),
        (o = () => {
          (t && "closed" !== t.state && t.close().catch(() => {}),
            (t = new (window.AudioContext || window.webkitAudioContext)()),
            (i = new Map()),
            s.clear());
        }),
        (n = () => {
          if (!t) return !1;
          try {
            return (t.createGain().disconnect(), "running" === t.state || "suspended" === t.state);
          } catch {
            return !1;
          }
        }),
        (d = async (e) => {
          if (!t) return null;
          let i = await fetch(e),
            s = await i.arrayBuffer();
          return await t.decodeAudioData(s);
        }),
        (u = async (e) => {
          if (!t) return null;
          if (!i.has(e)) {
            let t = await d(T[e]);
            t && i.set(e, t);
          }
          return i.get(e) || null;
        }),
        (c = async (e) => {
          if (!l || ((t && n()) || o(), !t)) return;
          let i = (a.get(e) || 0) + 1;
          a.set(e, i);
          try {
            if (("suspended" === t.state && (await t.resume()), "running" !== t.state)) {
              if ((o(), !t)) return;
              "suspended" === t.state && (await t.resume());
            }
            if ((r.get(e) || 0) >= i) return;
            let a = await u(e);
            if (!a || (r.get(e) || 0) >= i) return;
            let l = s.get(e) || [];
            if (l.length >= 3) {
              let e = l.shift();
              e && e.stop();
            }
            let n = t.createBufferSource(),
              d = t.createGain();
            ((n.buffer = a),
              (d.gain.value = 0.5),
              n.connect(d),
              d.connect(t.destination),
              s.has(e) || s.set(e, []),
              s.get(e).push(n),
              (n.onended = () => {
                let t = s.get(e);
                if (t) {
                  let i = t.indexOf(n);
                  (i > -1 && t.splice(i, 1), 0 === t.length && s.delete(e));
                }
              }),
              n.start(0));
          } catch {
            o();
          }
        }),
        (_ = async () => {
          if (!t || !n()) return void o();
          if ("suspended" === t.state)
            try {
              await t.resume();
            } catch (e) {
              (console.error("Error resuming AudioContext, recreating:", e), o());
            }
          t && "running" !== t.state && "suspended" !== t.state && o();
        }),
        (f = async () => {
          if (!t || !n()) return void o();
          if ("suspended" === t.state)
            try {
              await t.resume();
            } catch {
              o();
              return;
            }
          t && "running" !== t.state && "suspended" !== t.state && o();
        }),
        ["touchstart", "touchend", "click", "keydown", "mousedown"].forEach((e) => {
          window.addEventListener(e, f, { passive: !0 });
        }),
        document.addEventListener("visibilitychange", () => {
          "visible" === document.visibilityState &&
            setTimeout(() => {
              f();
            }, 100);
        }),
        window.addEventListener("focus", f),
        window.addEventListener("pageshow", (e) => {
          (e.persisted || "visible" === document.visibilityState) &&
            setTimeout(() => {
              f();
            }, 100);
        }),
        {
          play: c,
          stop: (e) => {
            let t = a.get(e) || 0;
            r.set(e, t);
            let i = s.get(e);
            i &&
              i.length > 0 &&
              (i.forEach((e) => {
                e.stop();
              }),
              s.delete(e));
          },
          stopAll: () => {
            (a.forEach((e, t) => {
              r.set(t, e);
            }),
              s.forEach((e) => {
                e.forEach((e) => {
                  e.stop();
                });
              }),
              s.clear());
          },
          toggle: () => (l = !l),
          getState: () => l,
          resume: _,
          getAudioContextState: () => t?.state || "unavailable",
        });
    e.s(["sound", 0, E], 475091);
  },
]);
