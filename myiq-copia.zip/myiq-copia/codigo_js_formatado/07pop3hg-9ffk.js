(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  928092,
  (t) => {
    "use strict";
    var e = t.i(492810);
    t.s(["IconRatingStarBold", () => e.default]);
  },
  22279,
  (t) => {
    "use strict";
    var e = t.i(843476),
      s = t.i(948148),
      i = t.i(663615);
    t.i(376990);
    var a = t.i(338531);
    (t.s([], 464071),
      t.i(464071),
      t.s(
        [
          "RateStatComponent",
          0,
          (t) => {
            let { reviews: n, className: r, isMobileOneStar: l, rating: o = 4.6, ratingForText: c = 4.8 } = t,
              d = (0, s.useTranslations)();
            return (0, e.jsxs)("div", {
              className: (0, i.cn)(
                "z-[9] flex flex-col items-center gap-1 max-sm:justify-center max-sm:px-5 sm:flex-row",
                r,
              ),
              children: [
                (0, e.jsxs)("div", {
                  className:
                    "flex items-center justify-center gap-1.5 font-semibold text-dark-custom text-medium",
                  children: [
                    n?.title,
                    l
                      ? (0, e.jsxs)(e.Fragment, {
                          children: [
                            (0, e.jsx)("span", {
                              className: "sm:hidden",
                              children: (0, e.jsx)(a.RatingStarsComponent, {
                                rating: o,
                                iconSize: 22,
                                starsQuantity: 1,
                              }),
                            }),
                            (0, e.jsx)("span", {
                              className: "hidden sm:flex",
                              children: (0, e.jsx)(a.RatingStarsComponent, { rating: o, iconSize: 22 }),
                            }),
                          ],
                        })
                      : (0, e.jsx)(a.RatingStarsComponent, { rating: o, iconSize: 22 }),
                  ],
                }),
                (0, e.jsx)("div", {
                  className: (0, i.cn)("text-sm"),
                  children: d.rich("review_based_on", {
                    rating: String(c),
                    amount: "1836",
                    span: (t) => (0, e.jsx)("span", { className: "font-semibold", children: t }),
                  }),
                }),
              ],
            });
          },
        ],
        22279,
      ));
  },
  97316,
  function (t) {
    t.n(t.i(22279));
  },
  376990,
  338531,
  (t) => {
    "use strict";
    var e = t.i(843476);
    t.i(934337);
    var s = t.i(779450),
      s = s,
      i = t.i(928092);
    (t.s([], 376990),
      t.s(
        [
          "RatingStarsComponent",
          0,
          (t) => {
            let { rating: a, iconSize: n, starsQuantity: r = 5, ownSize: l, iconType: o = "normal" } = t;
            return (0, e.jsx)("div", {
              className: "relative flex text-gray-300",
              children: Array(r)
                .fill("")
                ?.map((t, r) => {
                  let c;
                  return (0, e.jsxs)(
                    "div",
                    {
                      className: "relative",
                      style: { width: n + 2 * !l, height: n + 2 * !l },
                      children: [
                        "normal" === o
                          ? (0, e.jsx)(s.default, { width: n, height: n, className: "absolute" })
                          : (0, e.jsx)(i.IconRatingStarBold, { width: n, height: n, className: "absolute" }),
                        (0, e.jsx)("div", {
                          className: "absolute top-0 overflow-hidden text-[#f7b635]",
                          style: {
                            width:
                              r < (c = Math.floor(a))
                                ? "100%"
                                : r === c
                                  ? `${Math.round(100 * (a - c))}%`
                                  : "0%",
                          },
                          children:
                            "normal" === o
                              ? (0, e.jsx)(s.default, { width: n, height: n })
                              : (0, e.jsx)(i.IconRatingStarBold, { width: n, height: n }),
                        }),
                      ],
                    },
                    `start-qt-${r}`,
                  );
                }),
            });
          },
        ],
        338531,
      ));
  },
]);
