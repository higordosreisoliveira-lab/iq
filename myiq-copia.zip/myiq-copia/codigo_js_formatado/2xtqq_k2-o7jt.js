(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  660678,
  (e) => {
    "use strict";
    var t = e.i(271645),
      s = e.i(372775),
      a = e.i(912598);
    e.s([
      "HydrationBoundary",
      0,
      (e) => {
        let { children: i, options: r = {}, state: l, queryClient: n } = e,
          c = (0, a.useQueryClient)(n),
          o = t.useRef(r);
        o.current = r;
        let d = t.useMemo(() => {
          if (l) {
            if ("object" != typeof l) return;
            let e = c.getQueryCache(),
              t = l.queries || [],
              a = [],
              i = [];
            for (let s of t) {
              let t = e.get(s.queryHash);
              t
                ? (s.state.dataUpdatedAt > t.state.dataUpdatedAt ||
                    (s.promise &&
                      "pending" !== t.state.status &&
                      "fetching" !== t.state.fetchStatus &&
                      void 0 !== s.dehydratedAt &&
                      s.dehydratedAt > t.state.dataUpdatedAt)) &&
                  i.push(s)
                : a.push(s);
            }
            if ((a.length > 0 && (0, s.hydrate)(c, { queries: a }, o.current), i.length > 0)) return i;
          }
        }, [c, l]);
        return (
          t.useEffect(() => {
            d && (0, s.hydrate)(c, { queries: d }, o.current);
          }, [c, d]),
          i
        );
      },
    ]);
  },
  847517,
  (e) => {
    "use strict";
    var t = e.i(843476),
      s = e.i(861745),
      a = e.i(948148),
      i = e.i(266027);
    e.i(382838);
    var r = e.i(342800),
      l = e.i(353527),
      n = e.i(942905);
    e.i(867107);
    var c = e.i(1693),
      o = e.i(86596);
    e.i(267493);
    var d = e.i(605663);
    e.i(853754);
    var u = e.i(319970);
    e.i(924482);
    var m = e.i(20511);
    e.s([
      "default",
      0,
      (e) => {
        let { pageSlug: p } = e,
          x = (0, a.useTranslations)(),
          h = (0, s.useLocale)(),
          { data: g } = (0, i.useQuery)((0, d.pageQueryOptions)(p, h)),
          b = (0, o.useUserStore)((e) => e.user);
        return (0, t.jsxs)(t.Fragment, {
          children: [
            (0, t.jsx)(m.DemoStaticHeaderComponent, {}),
            (0, t.jsx)("main", {
              className: "flex flex-1 flex-col",
              children: (0, t.jsx)(l.DemoStaticPageLayoutComponent, {
                breadCrumbLabel: x("terms_breadcrumb_label"),
                subtitle: x("static_page_terms_subtitle"),
                title: g?.title || "",
                showBackToTop: !0,
                children: g?.sections?.map((e, s) =>
                  e?.blockType !== "textContent"
                    ? null
                    : (0, t.jsx)(
                        "div",
                        {
                          className: b?.subscriptionId ? "mb-20" : "",
                          children:
                            e?.richDescription && e?.descriptionType === "richText"
                              ? (0, t.jsx)(c.RichText, {
                                  disableTextAlign: !0,
                                  headingIdMap: n.termsHeadingIdMap,
                                  data: e?.richDescription,
                                  className: r.DEMO_STATIC_PAGE_PROSE_CLASS,
                                })
                              : (0, t.jsx)("p", {
                                  className: r.DEMO_STATIC_PAGE_PROSE_CLASS,
                                  children: e?.description,
                                }),
                        },
                        s,
                      ),
                ),
              }),
            }),
            (0, t.jsx)(u.DemoFooterComponent, {}),
          ],
        });
      },
    ]);
  },
  971878,
  404132,
  (e) => {
    "use strict";
    e.i(427930);
    var t = e.i(843476);
    e.i(299649);
    var s = e.i(605766),
      a = e.i(948148),
      i = e.i(134404),
      r = e.i(202042),
      l = e.i(319587);
    let n = (e) => {
      let { items: s, activeId: n } = e,
        c = (0, a.useTranslations)(),
        { scrollToHeading: o } = (0, l.useSmoothScroll)(),
        d = s.length > 1;
      return (0, t.jsxs)("div", {
        className: "flex flex-col gap-7",
        children: [
          d &&
            (0, t.jsxs)("div", {
              className: "flex flex-col gap-3.5",
              children: [
                (0, t.jsx)("p", {
                  className: "text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-400",
                  children: c("static_page_on_this_page"),
                }),
                (0, t.jsx)("nav", {
                  "aria-label": c("static_page_on_this_page"),
                  className: "flex flex-col",
                  children: s.map((e) => {
                    let s = e.id === n,
                      a = 1 === e.level;
                    return (0, t.jsx)(
                      "a",
                      {
                        href: `#${e.id}`,
                        onClick: (t) => {
                          var s;
                          return ((s = e.id), void (t.preventDefault(), o(s)));
                        },
                        "aria-current": s ? "true" : void 0,
                        className: `block cursor-pointer border-l-2 border-solid py-[7px] pe-2 text-[13.5px] font-normal leading-[1.4] transition-colors ${a ? "ps-7" : "ps-4"} ${s ? "border-blue-custom text-blue-custom [-webkit-text-stroke:0.4px_#066fde]" : "border-[#eef0f3] text-slate-500"}`,
                        children: e.label,
                      },
                      e.id,
                    );
                  }),
                }),
              ],
            }),
          (0, t.jsxs)("div", {
            className: "flex flex-col gap-1.5 rounded-[14px] bg-[#f7f8fa] p-5",
            children: [
              (0, t.jsx)("p", {
                className: "text-sm font-bold text-light-black-custom",
                children: c("static_page_questions_title"),
              }),
              (0, t.jsx)("p", {
                className: "text-[13px] leading-[1.55] text-slate-500",
                children: c("static_page_questions_description"),
              }),
              (0, t.jsxs)(r.Link, {
                href: i.EClientRoutes.HELP,
                prefetch: !1,
                className:
                  "mt-1.5 inline-flex w-fit items-center gap-1 text-[13.5px] font-semibold text-blue-custom hover:text-[#0560c2]",
                children: [
                  c("static_page_questions_cta"),
                  (0, t.jsxs)("svg", {
                    width: "14",
                    height: "14",
                    viewBox: "0 0 16 16",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "1.8",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    "aria-hidden": "true",
                    children: [
                      (0, t.jsx)("path", { d: "M3 8h9" }),
                      (0, t.jsx)("path", { d: "M8 4l4 4-4 4" }),
                    ],
                  }),
                ],
              }),
            ],
          }),
        ],
      });
    };
    var c = e.i(271645);
    let o = (e) => {
      let { items: s } = e,
        i = (0, a.useTranslations)(),
        { scrollToHeading: r } = (0, l.useSmoothScroll)(),
        [n, o] = (0, c.useState)(!0);
      return s.length < 2
        ? null
        : (0, t.jsxs)("div", {
            className: "rounded-[14px] border border-[#eef0f3] bg-[#f7f8fa]",
            children: [
              (0, t.jsxs)("button", {
                type: "button",
                "aria-expanded": n,
                className: "flex min-h-12 w-full items-center justify-between gap-3 px-4 py-3 text-start",
                onClick: () => o((e) => !e),
                children: [
                  (0, t.jsxs)("span", {
                    className: "flex items-baseline gap-2",
                    children: [
                      (0, t.jsx)("span", {
                        className: "text-sm font-semibold text-light-black-custom",
                        children: i("static_page_on_this_page"),
                      }),
                      (0, t.jsx)("span", {
                        className: "text-xs text-slate-400",
                        children: i("static_page_sections_count", { count: String(s.length) }),
                      }),
                    ],
                  }),
                  (0, t.jsx)("svg", {
                    width: "16",
                    height: "16",
                    viewBox: "0 0 16 16",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "1.8",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    "aria-hidden": "true",
                    className: `shrink-0 text-slate-400 transition-transform ${n ? "rotate-180" : ""}`,
                    children: (0, t.jsx)("path", { d: "M3.5 6l4.5 4.5L12.5 6" }),
                  }),
                ],
              }),
              n &&
                (0, t.jsx)("nav", {
                  "aria-label": i("static_page_on_this_page"),
                  className: "flex flex-col gap-0.5 border-t border-[#eef0f3] px-4 py-3",
                  children: s.map((e) =>
                    (0, t.jsx)(
                      "a",
                      {
                        href: `#${e.id}`,
                        onClick: (t) => {
                          var s;
                          return ((s = e.id), void (t.preventDefault(), r(s)));
                        },
                        className: `py-1.5 text-sm leading-5 text-slate-500 hover:text-blue-custom ${1 === e.level ? "ps-4" : ""}`,
                        children: e.label,
                      },
                      e.id,
                    ),
                  ),
                }),
            ],
          });
    };
    var d = e.i(219546);
    e.i(545364);
    var u = e.i(714621);
    (e.s([], 971878),
      e.s(
        [
          "StaticPageLayoutComponent",
          0,
          (e) => {
            let { breadCrumbLabel: a, title: i, subtitle: r, isProfile: l = !1, children: c } = e,
              { articleRef: m, items: p, activeId: x } = (0, d.usePageToc)();
            return (0, t.jsxs)(s.ContainerComponent, {
              className: "relative isolate",
              children: [
                (0, t.jsx)("div", {
                  "aria-hidden": "true",
                  className:
                    "pointer-events-none absolute left-1/2 top-0 -z-10 h-[320px] w-screen -translate-x-1/2 bg-gradient-to-b from-[#eef4ff] to-white",
                }),
                (0, t.jsx)("div", {
                  className: "!pt-5 md:!pt-10",
                  children: (0, t.jsx)(u.HelpCenterBreadcrumb, { breadCrumbLabel: a, isProfile: l }),
                }),
                (0, t.jsxs)("div", {
                  className: "pb-14 lg:pb-24",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "border-b border-[#eef0f3] pb-7 pt-6 lg:pb-9 lg:pt-8",
                      children: [
                        (0, t.jsx)("h1", {
                          className:
                            "w-fit text-[28px] font-bold leading-[1.15] tracking-[-0.02em] text-light-black-custom lg:text-4xl",
                          dangerouslySetInnerHTML: { __html: i },
                        }),
                        r &&
                          (0, t.jsx)("p", {
                            className:
                              "mt-3 max-w-[600px] text-[15px] leading-[26px] text-slate-500 lg:text-base",
                            children: r,
                          }),
                      ],
                    }),
                    p.length > 1 &&
                      (0, t.jsx)("div", {
                        className: "mt-6 lg:hidden",
                        children: (0, t.jsx)(o, { items: p }),
                      }),
                    (0, t.jsxs)("div", {
                      className: "mt-8 lg:mt-12 lg:grid lg:grid-cols-[248px_minmax(0,1fr)] lg:gap-16",
                      children: [
                        (0, t.jsx)("aside", {
                          className: "max-lg:hidden",
                          children: (0, t.jsx)("div", {
                            className: "sticky top-28 max-h-[calc(100vh-7rem)] overflow-y-auto pb-8 pe-2",
                            children: (0, t.jsx)(n, { items: p, activeId: x }),
                          }),
                        }),
                        (0, t.jsx)("div", { ref: m, className: "min-w-0 max-w-[680px]", children: c }),
                      ],
                    }),
                  ],
                }),
              ],
            });
          },
        ],
        404132,
      ));
  },
  942905,
  (e) => {
    "use strict";
    e.s([
      "termsHeadingIdMap",
      0,
      [
        { headingNumber: 1, customId: "definitions" },
        { headingNumber: 2, customId: "welcome" },
        { headingNumber: 3, customId: "disclaimers" },
        { headingNumber: 4, customId: "acceptance" },
        { headingNumber: 5, customId: "account-eligibility" },
        { headingNumber: 6, customId: "subscription-services" },
        { headingNumber: 6.1, customId: "plans-and-pricing" },
        { headingNumber: 6.2, customId: "trial-period" },
        { headingNumber: 6.3, customId: "billing-and-payment" },
        { headingNumber: 6.4, customId: "cancellation-process" },
        { headingNumber: 7, customId: "refund-policy" },
        { headingNumber: 8, customId: "intellectual-property" },
        { headingNumber: 9, customId: "user-content" },
        { headingNumber: 10, customId: "sla" },
        { headingNumber: 11, customId: "technical-requirements" },
        { headingNumber: 12, customId: "customer-support" },
        { headingNumber: 13, customId: "liability" },
        { headingNumber: 14, customId: "dispute-resolution" },
        { headingNumber: 15, customId: "service-modifications" },
        { headingNumber: 16, customId: "account-termination" },
        { headingNumber: 17, customId: "legal-information" },
      ],
    ]);
  },
  458278,
  (e) => {
    "use strict";
    var t = e.i(843476),
      s = e.i(861745),
      a = e.i(948148),
      i = e.i(266027);
    e.i(971878);
    var r = e.i(815389),
      l = e.i(404132);
    e.i(867107);
    var n = e.i(1693),
      c = e.i(86596);
    e.i(267493);
    var o = e.i(605663),
      d = e.i(134404),
      u = e.i(942905);
    e.s([
      "default",
      0,
      (e) => {
        let { pageSlug: m } = e,
          p = (0, a.useTranslations)(),
          x = (0, s.useLocale)(),
          { data: h } = (0, i.useQuery)((0, o.pageQueryOptions)(m, x)),
          g = (0, c.useUserStore)((e) => e.user);
        return (0, t.jsx)(l.StaticPageLayoutComponent, {
          breadCrumbLabel: p("terms_breadcrumb_label"),
          title: h?.title || "",
          subtitle: p("static_page_terms_subtitle"),
          currentRoute: d.EClientRoutes.TERMS,
          children: h?.sections?.map((e, s) =>
            e?.blockType !== "textContent"
              ? null
              : (0, t.jsx)(
                  "div",
                  {
                    className: g?.subscriptionId ? "mb-20" : "",
                    children:
                      e?.richDescription && e?.descriptionType === "richText"
                        ? (0, t.jsx)(n.RichText, {
                            headingIdMap: u.termsHeadingIdMap,
                            data: e?.richDescription,
                            className: r.STATIC_PAGE_PROSE_CLASS,
                          })
                        : (0, t.jsx)("p", { className: r.STATIC_PAGE_PROSE_CLASS, children: e?.description }),
                  },
                  s,
                ),
          ),
        });
      },
    ]);
  },
  299649,
  605766,
  (e) => {
    "use strict";
    var t = e.i(843476);
    (e.s([], 299649),
      e.s(
        [
          "ContainerComponent",
          0,
          (e) => {
            let { children: s, className: a, variant: i = "main" } = e;
            return (0, t.jsxs)(t.Fragment, {
              children: [
                "full" === i && (0, t.jsx)("main", { className: `mx-auto w-full pt-16 ${a}`, children: s }),
                "main" === i &&
                  (0, t.jsx)("main", {
                    className: `mx-auto w-full max-w-7xl pt-16 max-[1320px]:px-6 max-md:px-4 ${a}`,
                    children: s,
                  }),
                "header" === i &&
                  (0, t.jsx)("header", {
                    "data-app-header": !0,
                    className: `w-full bg-background/70 backdrop-blur-lg backdrop-saturate-150 ${a}`,
                    children: s,
                  }),
                "footer" === i &&
                  (0, t.jsx)("footer", { "data-app-footer": !0, className: `w-full ${a}`, children: s }),
              ],
            });
          },
        ],
        605766,
      ));
  },
]);
