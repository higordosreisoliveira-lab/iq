"""Espelha o front-end público do myiq.com (HTML, chunks JS/CSS, JSON de API pública).

Só navegação passiva: não preenche e-mail, não faz login, não paga.
Rodar com: py -3.12 crawl_myiq.py
"""
import json
import re
import sys
from pathlib import Path
from urllib.parse import urlparse

from playwright.sync_api import sync_playwright

BASE = "https://myiq.com"
OUT = Path(__file__).parent / "site"
LOG = Path(__file__).parent / "network_log.jsonl"
ROUTES = [
    "/", "/quiz", "/terms", "/privacy", "/cookie", "/help",
    "/help/contact-myiq-support", "/cancellation/auth", "/sign-in",
    "/pricing", "/checkout", "/payment", "/results", "/pt-BR", "/pt-BR/quiz",
]
SAVE_TYPES = ("javascript", "json", "css", "html", "text/plain", "x-component")


def local_path(url: str) -> Path:
    u = urlparse(url)
    path = u.path or "/"
    if path.endswith("/"):
        path += "index.html"
    if u.query and not path.endswith((".js", ".css")):
        path += "__" + u.query
    # Windows não aceita : * ? " < > | em nomes; trunca segmentos gigantes
    parts = [re.sub(r'[<>:"|?*\\=&]', "_", s)[:120] for s in path.split("/") if s]
    return OUT.joinpath(u.netloc.replace(":", "_"), *parts)


def main():
    LOG.unlink(missing_ok=True)
    seen = set()
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/128.0 Safari/537.36",
            viewport={"width": 1366, "height": 900},
            locale="en-US",
        )
        page = ctx.new_page()

        def on_response(resp):
            url = resp.url
            ctype = resp.headers.get("content-type", "")
            rec = {"url": url, "status": resp.status, "type": ctype,
                   "method": resp.request.method}
            if resp.request.method == "POST":
                rec["post"] = (resp.request.post_data or "")[:2000]
            with LOG.open("a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            if url in seen or not any(t in ctype for t in SAVE_TYPES):
                return
            seen.add(url)
            try:
                body = resp.body()
            except Exception:
                return
            try:
                dst = local_path(url)
                if "html" in ctype and dst.suffix != ".html":
                    dst = dst / "index.html"
                elif "x-component" in ctype:
                    dst = dst.with_name(dst.name + ".rsc")
                elif "json" in ctype and dst.suffix != ".json":
                    dst = dst.with_name(dst.name + ".json")
                dst.parent.mkdir(parents=True, exist_ok=True)
                dst.write_bytes(body)
            except OSError as e:
                print(f"[skip] {url[:100]}: {e}", file=sys.stderr)

        page.on("response", on_response)
        for r in ROUTES:
            try:
                page.goto(BASE + r, wait_until="networkidle", timeout=45000)
            except Exception as e:
                print(f"[!] {r}: {e}", file=sys.stderr)
            page.wait_for_timeout(1500)
            (OUT / "_rendered").mkdir(parents=True, exist_ok=True)
            name = (r.strip("/") or "home").replace("/", "_")
            (OUT / "_rendered" / f"{name}.html").write_text(page.content(), encoding="utf-8")
            page.screenshot(path=str(OUT / "_rendered" / f"{name}.png"), full_page=True)
            print(f"[ok] {r} -> {page.url}")
        browser.close()
    print(f"{len(seen)} recursos salvos em {OUT}")


if __name__ == "__main__":
    main()
