(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  919477,
  (e) => {
    "use strict";
    var t = new Set([
        "id",
        "type",
        "style",
        "title",
        "role",
        "tabIndex",
        "htmlFor",
        "width",
        "height",
        "abbr",
        "accept",
        "acceptCharset",
        "accessKey",
        "action",
        "allowFullScreen",
        "allowTransparency",
        "alt",
        "async",
        "autoComplete",
        "autoFocus",
        "autoPlay",
        "cellPadding",
        "cellSpacing",
        "challenge",
        "charset",
        "checked",
        "cite",
        "class",
        "className",
        "cols",
        "colSpan",
        "command",
        "content",
        "contentEditable",
        "contextMenu",
        "controls",
        "coords",
        "crossOrigin",
        "data",
        "dateTime",
        "default",
        "defer",
        "dir",
        "disabled",
        "download",
        "draggable",
        "dropzone",
        "encType",
        "enterKeyHint",
        "for",
        "form",
        "formAction",
        "formEncType",
        "formMethod",
        "formNoValidate",
        "formTarget",
        "frameBorder",
        "headers",
        "hidden",
        "high",
        "href",
        "hrefLang",
        "httpEquiv",
        "icon",
        "inputMode",
        "isMap",
        "itemId",
        "itemProp",
        "itemRef",
        "itemScope",
        "itemType",
        "kind",
        "label",
        "lang",
        "list",
        "loop",
        "manifest",
        "max",
        "maxLength",
        "media",
        "mediaGroup",
        "method",
        "min",
        "minLength",
        "multiple",
        "muted",
        "name",
        "noValidate",
        "open",
        "optimum",
        "pattern",
        "ping",
        "placeholder",
        "poster",
        "preload",
        "radioGroup",
        "referrerPolicy",
        "readOnly",
        "rel",
        "required",
        "rows",
        "rowSpan",
        "sandbox",
        "scope",
        "scoped",
        "scrolling",
        "seamless",
        "selected",
        "shape",
        "size",
        "sizes",
        "slot",
        "sortable",
        "span",
        "spellCheck",
        "src",
        "srcDoc",
        "srcSet",
        "start",
        "step",
        "target",
        "translate",
        "typeMustMatch",
        "useMap",
        "value",
        "wmode",
        "wrap",
      ]),
      r = new Set([
        "onCopy",
        "onCut",
        "onPaste",
        "onLoad",
        "onError",
        "onWheel",
        "onScroll",
        "onCompositionEnd",
        "onCompositionStart",
        "onCompositionUpdate",
        "onKeyDown",
        "onKeyPress",
        "onKeyUp",
        "onFocus",
        "onBlur",
        "onChange",
        "onInput",
        "onSubmit",
        "onClick",
        "onContextMenu",
        "onDoubleClick",
        "onDrag",
        "onDragEnd",
        "onDragEnter",
        "onDragExit",
        "onDragLeave",
        "onDragOver",
        "onDragStart",
        "onDrop",
        "onMouseDown",
        "onMouseEnter",
        "onMouseLeave",
        "onMouseMove",
        "onMouseOut",
        "onMouseOver",
        "onMouseUp",
        "onPointerDown",
        "onPointerEnter",
        "onPointerLeave",
        "onPointerUp",
        "onSelect",
        "onTouchCancel",
        "onTouchEnd",
        "onTouchMove",
        "onTouchStart",
        "onAnimationStart",
        "onAnimationEnd",
        "onAnimationIteration",
        "onTransitionEnd",
      ]),
      n = /^(data-.*)$/,
      i = /^(aria-.*)$/,
      o = /^(on[A-Z].*)$/;
    e.s(
      [
        "filterDOMProps",
        0,
        function (e) {
          let s = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
            {
              labelable: a = !0,
              enabled: l = !0,
              propNames: u,
              omitPropNames: c,
              omitEventNames: d,
              omitDataProps: p,
              omitEventProps: g,
            } = s,
            v = {};
          if (!l) return e;
          for (let s in e)
            !(
              (null == c ? void 0 : c.has(s)) ||
              ((null == d ? void 0 : d.has(s)) && o.test(s)) ||
              (o.test(s) && !r.has(s)) ||
              (p && n.test(s))
            ) &&
              !(g && o.test(s)) &&
              ((Object.prototype.hasOwnProperty.call(e, s) &&
                (t.has(s) || (a && i.test(s)) || (null == u ? void 0 : u.has(s)) || n.test(s))) ||
                o.test(s)) &&
              (v[s] = e[s]);
          return v;
        },
      ],
      919477,
    );
  },
  620253,
  (e) => {
    "use strict";
    var t = e.i(271645);
    ("u" > typeof window && window.document && window.document.createElement,
      e.s([
        "createDOMRef",
        0,
        function (e) {
          return { UNSAFE_getDOMNode: () => e.current };
        },
        "useDOMRef",
        0,
        function (e) {
          let r = (0, t.useRef)(null);
          return ((0, t.useImperativeHandle)(e, () => r.current), r);
        },
      ]));
  },
  779754,
  (e) => {
    "use strict";
    e.s([
      "collapseAdjacentVariantBorders",
      0,
      {
        default: ["[&+.border-medium.border-default]:ms-[calc(var(--heroui-border-width-medium)*-1)]"],
        primary: ["[&+.border-medium.border-primary]:ms-[calc(var(--heroui-border-width-medium)*-1)]"],
        secondary: ["[&+.border-medium.border-secondary]:ms-[calc(var(--heroui-border-width-medium)*-1)]"],
        success: ["[&+.border-medium.border-success]:ms-[calc(var(--heroui-border-width-medium)*-1)]"],
        warning: ["[&+.border-medium.border-warning]:ms-[calc(var(--heroui-border-width-medium)*-1)]"],
        danger: ["[&+.border-medium.border-danger]:ms-[calc(var(--heroui-border-width-medium)*-1)]"],
      },
      "dataFocusVisibleClasses",
      0,
      [
        "outline-solid outline-transparent",
        "data-[focus-visible=true]:z-10",
        "data-[focus-visible=true]:outline-2",
        "data-[focus-visible=true]:outline-focus",
        "data-[focus-visible=true]:outline-offset-2",
      ],
      "groupDataFocusVisibleClasses",
      0,
      [
        "outline-solid outline-transparent",
        "group-data-[focus-visible=true]:z-10",
        "group-data-[focus-visible=true]:ring-2",
        "group-data-[focus-visible=true]:ring-focus",
        "group-data-[focus-visible=true]:ring-offset-2",
        "group-data-[focus-visible=true]:ring-offset-background",
      ],
      "hiddenInputClasses",
      0,
      [
        "font-inherit",
        "text-[100%]",
        "leading-[1.15]",
        "m-0",
        "p-0",
        "overflow-visible",
        "box-border",
        "absolute",
        "top-0",
        "w-full",
        "h-full",
        "opacity-[0.0001]",
        "z-[1]",
        "cursor-pointer",
        "disabled:cursor-default",
      ],
      "ringClasses",
      0,
      [
        "outline-solid outline-transparent",
        "ring-2",
        "ring-focus",
        "ring-offset-2",
        "ring-offset-background",
      ],
      "translateCenterClasses",
      0,
      ["absolute", "top-1/2", "left-1/2", "-translate-x-1/2", "-translate-y-1/2"],
    ]);
  },
  429427,
  (e) => {
    "use strict";
    var t = e.i(346996),
      r = e.i(682234),
      n = e.i(616231),
      i = e.i(271645);
    e.s([
      "useFocusRing",
      0,
      function () {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          { autoFocus: o = !1, isTextInput: s, within: a } = e,
          l = (0, i.useRef)({ isFocused: !1, isFocusVisible: o || (0, t.isFocusVisible)() }),
          [u, c] = (0, i.useState)(!1),
          [d, p] = (0, i.useState)(() => l.current.isFocused && l.current.isFocusVisible),
          g = (0, i.useCallback)(() => p(l.current.isFocused && l.current.isFocusVisible), []),
          v = (0, i.useCallback)(
            (e) => {
              ((l.current.isFocused = e), c(e), g());
            },
            [g],
          );
        (0, t.useFocusVisibleListener)(
          (e) => {
            ((l.current.isFocusVisible = e), g());
          },
          [],
          { isTextInput: s },
        );
        let { focusProps: f } = (0, r.useFocus)({ isDisabled: a, onFocusChange: v }),
          { focusWithinProps: y } = (0, n.useFocusWithin)({ isDisabled: !a, onFocusWithinChange: v });
        return { isFocused: u, isFocusVisible: d, focusProps: a ? y : f };
      },
    ]);
  },
  682234,
  (e) => {
    "use strict";
    var t = e.i(424220),
      r = e.i(271645),
      n = e.i(934203),
      i = e.i(933714);
    e.s([
      "useFocus",
      0,
      function (e) {
        let { isDisabled: o, onFocus: s, onBlur: a, onFocusChange: l } = e,
          u = (0, r.useCallback)(
            (e) => {
              if (e.target === e.currentTarget) return (a && a(e), l && l(!1), !0);
            },
            [a, l],
          ),
          c = (0, t.useSyntheticBlurEvent)(u),
          d = (0, r.useCallback)(
            (e) => {
              let t = (0, n.getOwnerDocument)(e.target),
                r = t ? (0, i.getActiveElement)(t) : (0, i.getActiveElement)();
              e.target === e.currentTarget &&
                r === (0, i.getEventTarget)(e.nativeEvent) &&
                (s && s(e), l && l(!0), c(e));
            },
            [l, s, c],
          );
        return {
          focusProps: { onFocus: !o && (s || l || a) ? d : void 0, onBlur: !o && (a || l) ? u : void 0 },
        };
      },
    ]);
  },
  371330,
  (e) => {
    "use strict";
    e.i(247167);
    var t = e.i(548121),
      r = e.i(934203),
      n = e.i(933714),
      i = e.i(271645);
    let o = !1,
      s = 0;
    function a(e) {
      "touch" === e.pointerType &&
        ((o = !0),
        setTimeout(() => {
          o = !1;
        }, 50));
    }
    function l() {
      if ("u" > typeof document)
        return (
          0 === s && "u" > typeof PointerEvent && document.addEventListener("pointerup", a),
          s++,
          () => {
            !(--s > 0) && "u" > typeof PointerEvent && document.removeEventListener("pointerup", a);
          }
        );
    }
    e.s([
      "useHover",
      0,
      function (e) {
        let { onHoverStart: s, onHoverChange: a, onHoverEnd: u, isDisabled: c } = e,
          [d, p] = (0, i.useState)(!1),
          g = (0, i.useRef)({
            isHovered: !1,
            ignoreEmulatedMouseEvents: !1,
            pointerType: "",
            target: null,
          }).current;
        (0, i.useEffect)(l, []);
        let { addGlobalListener: v, removeAllGlobalListeners: f } = (0, t.useGlobalListeners)(),
          { hoverProps: y, triggerHoverEnd: m } = (0, i.useMemo)(() => {
            let e = (e, t) => {
                let r = g.target;
                ((g.pointerType = ""),
                  (g.target = null),
                  "touch" !== t &&
                    g.isHovered &&
                    r &&
                    ((g.isHovered = !1),
                    f(),
                    u && u({ type: "hoverend", target: r, pointerType: t }),
                    a && a(!1),
                    p(!1)));
              },
              t = {};
            return (
              "u" > typeof PointerEvent &&
                ((t.onPointerEnter = (t) => {
                  (o && "mouse" === t.pointerType) ||
                    ((t, i) => {
                      if (
                        ((g.pointerType = i),
                        c || "touch" === i || g.isHovered || !t.currentTarget.contains(t.target))
                      )
                        return;
                      g.isHovered = !0;
                      let o = t.currentTarget;
                      ((g.target = o),
                        v(
                          (0, r.getOwnerDocument)(t.target),
                          "pointerover",
                          (t) => {
                            g.isHovered &&
                              g.target &&
                              !(0, n.nodeContains)(g.target, t.target) &&
                              e(t, t.pointerType);
                          },
                          { capture: !0 },
                        ),
                        s && s({ type: "hoverstart", target: o, pointerType: i }),
                        a && a(!0),
                        p(!0));
                    })(t, t.pointerType);
                }),
                (t.onPointerLeave = (t) => {
                  !c && t.currentTarget.contains(t.target) && e(t, t.pointerType);
                })),
              { hoverProps: t, triggerHoverEnd: e }
            );
          }, [s, a, u, c, g, v, f]);
        return (
          (0, i.useEffect)(() => {
            c && m({ currentTarget: g.target }, g.pointerType);
          }, [c]),
          { hoverProps: y, isHovered: d }
        );
      },
    ]);
  },
  343027,
  (e) => {
    "use strict";
    var t = e.i(424220),
      r = e.i(663859),
      n = e.i(934203),
      i = e.i(109789);
    let o = "default",
      s = "",
      a = new WeakMap();
    function l(e) {
      if ((0, r.isIOS)())
        "disabled" === o &&
          ((o = "restoring"),
          setTimeout(() => {
            (0, i.runAfterTransition)(() => {
              if ("restoring" === o) {
                let t = (0, n.getOwnerDocument)(e);
                ("none" === t.documentElement.style.webkitUserSelect &&
                  (t.documentElement.style.webkitUserSelect = s || ""),
                  (s = ""),
                  (o = "default"));
              }
            });
          }, 300));
      else if ((e instanceof HTMLElement || e instanceof SVGElement) && e && a.has(e)) {
        let t = a.get(e),
          r = "userSelect" in e.style ? "userSelect" : "webkitUserSelect";
        ("none" === e.style[r] && (e.style[r] = t),
          "" === e.getAttribute("style") && e.removeAttribute("style"),
          a.delete(e));
      }
    }
    var u = e.i(892902);
    function c(e, t, r) {
      if (!t.has(e)) throw TypeError("attempted to " + r + " private field on non-instance");
      return t.get(e);
    }
    function d(e, t, r) {
      var n = c(e, t, "set");
      if (n.set) n.set.call(e, r);
      else {
        if (!n.writable) throw TypeError("attempted to set read only private field");
        n.value = r;
      }
      return r;
    }
    var p = e.i(47682),
      g = e.i(957303),
      v = e.i(548121),
      f = e.i(110514),
      y = e.i(933714),
      m = e.i(312988),
      h = e.i(514480),
      E = e.i(271645);
    function b(e, t) {
      var n, i;
      let o = !(arguments.length > 2) || void 0 === arguments[2] || arguments[2],
        { metaKey: s, ctrlKey: a, altKey: l, shiftKey: u } = t;
      (0, r.isFirefox)() &&
        (null == (i = window.event) || null == (n = i.type) ? void 0 : n.startsWith("key")) &&
        "_blank" === e.target &&
        ((0, r.isMac)() ? (s = !0) : (a = !0));
      let c =
        (0, r.isWebKit)() && (0, r.isMac)() && !(0, r.isIPad)() && 1
          ? new KeyboardEvent("keydown", {
              keyIdentifier: "Enter",
              metaKey: s,
              ctrlKey: a,
              altKey: l,
              shiftKey: u,
            })
          : new MouseEvent("click", {
              metaKey: s,
              ctrlKey: a,
              altKey: l,
              shiftKey: u,
              bubbles: !0,
              cancelable: !0,
            });
      ((b.isOpening = o), (0, h.focusWithoutScrolling)(e), e.dispatchEvent(c), (b.isOpening = !1));
    }
    b.isOpening = !1;
    var T = e.i(109509);
    e.i(174080);
    var P = new WeakMap();
    class w {
      continuePropagation() {
        d(this, P, !1);
      }
      get shouldStopPropagation() {
        var e;
        return ((e = c(this, P, "get")), e.get ? e.get.call(this) : e.value);
      }
      constructor(e, t, r, n) {
        var i;
        (!(function (e, t, r) {
          if (t.has(e)) throw TypeError("Cannot initialize the same private elements twice on an object");
          t.set(e, r);
        })(this, P, { writable: !0, value: void 0 }),
          d(this, P, !0));
        let o = null != (i = null == n ? void 0 : n.target) ? i : r.currentTarget;
        const s = null == o ? void 0 : o.getBoundingClientRect();
        let a,
          l = 0,
          u,
          c = null;
        (null != r.clientX && null != r.clientY && ((u = r.clientX), (c = r.clientY)),
          s &&
            (null != u && null != c
              ? ((a = u - s.left), (l = c - s.top))
              : ((a = s.width / 2), (l = s.height / 2))),
          (this.type = e),
          (this.pointerType = t),
          (this.target = r.currentTarget),
          (this.shiftKey = r.shiftKey),
          (this.metaKey = r.metaKey),
          (this.ctrlKey = r.ctrlKey),
          (this.altKey = r.altKey),
          (this.x = a),
          (this.y = l));
      }
    }
    let S = Symbol("linkClicked"),
      C = "react-aria-pressable-style",
      k = "data-react-aria-pressable";
    function K(e) {
      return "A" === e.tagName && e.hasAttribute("href");
    }
    function M(e, t) {
      let { key: r, code: i } = e,
        o = t.getAttribute("role");
      return (
        ("Enter" === r || " " === r || "Spacebar" === r || "Space" === i) &&
        !(
          (t instanceof (0, n.getOwnerWindow)(t).HTMLInputElement && !I(t, r)) ||
          t instanceof (0, n.getOwnerWindow)(t).HTMLTextAreaElement ||
          t.isContentEditable
        ) &&
        !(("link" === o || (!o && K(t))) && "Enter" !== r)
      );
    }
    function O(e, t) {
      let r = t.clientX,
        n = t.clientY;
      return {
        currentTarget: e,
        shiftKey: t.shiftKey,
        ctrlKey: t.ctrlKey,
        metaKey: t.metaKey,
        altKey: t.altKey,
        clientX: r,
        clientY: n,
      };
    }
    function D(e, t) {
      return e instanceof HTMLInputElement
        ? !I(e, t)
        : !(e instanceof HTMLInputElement) &&
            (e instanceof HTMLButtonElement ? "submit" !== e.type && "reset" !== e.type : !K(e));
    }
    let F = new Set(["checkbox", "radio", "range", "color", "file", "image", "button", "submit", "reset"]);
    function I(e, t) {
      return "checkbox" === e.type || "radio" === e.type ? " " === t : F.has(e.type);
    }
    e.s(
      [
        "usePress",
        0,
        function (e) {
          let {
              onPress: i,
              onPressChange: c,
              onPressStart: d,
              onPressEnd: P,
              onPressUp: F,
              onClick: I,
              isDisabled: L,
              isPressed: x,
              preventFocusOnPress: H,
              shouldCancelOnPointerExit: A,
              allowTextSelectionOnPress: V,
              ref: U,
              ...R
            } = (function (e) {
              let t = (0, E.useContext)(u.PressResponderContext);
              if (t) {
                let { register: r, ...n } = t;
                ((e = (0, p.mergeProps)(n, e)), r());
              }
              return ((0, g.useSyncRef)(t, e.ref), e);
            })(e),
            [W, B] = (0, E.useState)(!1),
            G = (0, E.useRef)({
              isPressed: !1,
              ignoreEmulatedMouseEvents: !1,
              didFirePressStart: !1,
              isTriggeringEvent: !1,
              activePointerId: null,
              target: null,
              isOverTarget: !1,
              pointerType: null,
              disposables: [],
            }),
            { addGlobalListener: z, removeAllGlobalListeners: j } = (0, v.useGlobalListeners)(),
            N = (0, f.useEffectEvent)((e, t) => {
              let r = G.current;
              if (L || r.didFirePressStart) return !1;
              let n = !0;
              if (((r.isTriggeringEvent = !0), d)) {
                let r = new w("pressstart", t, e);
                (d(r), (n = r.shouldStopPropagation));
              }
              return (c && c(!0), (r.isTriggeringEvent = !1), (r.didFirePressStart = !0), B(!0), n);
            }),
            X = (0, f.useEffectEvent)(function (e, t) {
              let r = !(arguments.length > 2) || void 0 === arguments[2] || arguments[2],
                n = G.current;
              if (!n.didFirePressStart) return !1;
              ((n.didFirePressStart = !1), (n.isTriggeringEvent = !0));
              let o = !0;
              if (P) {
                let r = new w("pressend", t, e);
                (P(r), (o = r.shouldStopPropagation));
              }
              if ((c && c(!1), B(!1), i && r && !L)) {
                let r = new w("press", t, e);
                (i(r), o && (o = r.shouldStopPropagation));
              }
              return ((n.isTriggeringEvent = !1), o);
            }),
            Y = (0, f.useEffectEvent)((e, t) => {
              let r = G.current;
              if (L) return !1;
              if (F) {
                r.isTriggeringEvent = !0;
                let n = new w("pressup", t, e);
                return (F(n), (r.isTriggeringEvent = !1), n.shouldStopPropagation);
              }
              return !0;
            }),
            $ = (0, f.useEffectEvent)((e) => {
              let t = G.current;
              if (t.isPressed && t.target) {
                for (let r of (t.didFirePressStart &&
                  null != t.pointerType &&
                  X(O(t.target, e), t.pointerType, !1),
                (t.isPressed = !1),
                (t.isOverTarget = !1),
                (t.activePointerId = null),
                (t.pointerType = null),
                j(),
                V || l(t.target),
                t.disposables))
                  r();
                t.disposables = [];
              }
            }),
            q = (0, f.useEffectEvent)((e) => {
              A && $(e);
            }),
            _ = (0, f.useEffectEvent)((e) => {
              L || null == I || I(e);
            }),
            Z = (0, f.useEffectEvent)((e, r) => {
              if (!L && I) {
                let n = new MouseEvent("click", e);
                ((0, t.setEventTarget)(n, r), I((0, t.createSyntheticEvent)(n)));
              }
            }),
            J = (0, E.useMemo)(() => {
              let e = G.current,
                i = {
                  onKeyDown(t) {
                    if (
                      M(t.nativeEvent, t.currentTarget) &&
                      (0, y.nodeContains)(t.currentTarget, (0, y.getEventTarget)(t.nativeEvent))
                    ) {
                      var i;
                      D((0, y.getEventTarget)(t.nativeEvent), t.key) && t.preventDefault();
                      let o = !0;
                      if (!e.isPressed && !t.repeat) {
                        ((e.target = t.currentTarget),
                          (e.isPressed = !0),
                          (e.pointerType = "keyboard"),
                          (o = N(t, "keyboard")));
                        let r = t.currentTarget;
                        z(
                          (0, n.getOwnerDocument)(t.currentTarget),
                          "keyup",
                          (0, m.chain)((t) => {
                            M(t, r) &&
                              !t.repeat &&
                              (0, y.nodeContains)(r, (0, y.getEventTarget)(t)) &&
                              e.target &&
                              Y(O(e.target, t), "keyboard");
                          }, l),
                          !0,
                        );
                      }
                      (o && t.stopPropagation(),
                        t.metaKey &&
                          (0, r.isMac)() &&
                          (null == (i = e.metaKeyEvents) || i.set(t.key, t.nativeEvent)));
                    } else "Meta" === t.key && (e.metaKeyEvents = new Map());
                  },
                  onClick(t) {
                    if (
                      (!t || (0, y.nodeContains)(t.currentTarget, (0, y.getEventTarget)(t.nativeEvent))) &&
                      t &&
                      0 === t.button &&
                      !e.isTriggeringEvent &&
                      !b.isOpening
                    ) {
                      let r = !0;
                      if (
                        (L && t.preventDefault(),
                        !e.ignoreEmulatedMouseEvents &&
                          !e.isPressed &&
                          ("virtual" === e.pointerType || (0, T.isVirtualClick)(t.nativeEvent)))
                      ) {
                        let e = N(t, "virtual"),
                          n = Y(t, "virtual"),
                          i = X(t, "virtual");
                        (_(t), (r = e && n && i));
                      } else if (e.isPressed && "keyboard" !== e.pointerType) {
                        let n = e.pointerType || t.nativeEvent.pointerType || "virtual",
                          i = Y(O(t.currentTarget, t), n),
                          o = X(O(t.currentTarget, t), n, !0);
                        ((r = i && o), (e.isOverTarget = !1), _(t), $(t));
                      }
                      ((e.ignoreEmulatedMouseEvents = !1), r && t.stopPropagation());
                    }
                  },
                },
                l = (t) => {
                  var r, n, i;
                  if (e.isPressed && e.target && M(t, e.target)) {
                    D((0, y.getEventTarget)(t), t.key) && t.preventDefault();
                    let r = (0, y.getEventTarget)(t),
                      i = (0, y.nodeContains)(e.target, (0, y.getEventTarget)(t));
                    (X(O(e.target, t), "keyboard", i),
                      i && Z(t, e.target),
                      j(),
                      "Enter" !== t.key &&
                        K(e.target) &&
                        (0, y.nodeContains)(e.target, r) &&
                        !t[S] &&
                        ((t[S] = !0), b(e.target, t, !1)),
                      (e.isPressed = !1),
                      null == (n = e.metaKeyEvents) || n.delete(t.key));
                  } else if ("Meta" === t.key && (null == (r = e.metaKeyEvents) ? void 0 : r.size)) {
                    let t = e.metaKeyEvents;
                    for (let r of ((e.metaKeyEvents = void 0), t.values()))
                      null == (i = e.target) || i.dispatchEvent(new KeyboardEvent("keyup", r));
                  }
                };
              if ("u" > typeof PointerEvent) {
                ((i.onPointerDown = (t) => {
                  if (
                    0 !== t.button ||
                    !(0, y.nodeContains)(t.currentTarget, (0, y.getEventTarget)(t.nativeEvent))
                  )
                    return;
                  if ((0, T.isVirtualPointerEvent)(t.nativeEvent)) {
                    e.pointerType = "virtual";
                    return;
                  }
                  e.pointerType = t.pointerType;
                  let i = !0;
                  if (!e.isPressed) {
                    ((e.isPressed = !0),
                      (e.isOverTarget = !0),
                      (e.activePointerId = t.pointerId),
                      (e.target = t.currentTarget),
                      V ||
                        (function (e) {
                          if ((0, r.isIOS)()) {
                            if ("default" === o) {
                              let t = (0, n.getOwnerDocument)(e);
                              ((s = t.documentElement.style.webkitUserSelect),
                                (t.documentElement.style.webkitUserSelect = "none"));
                            }
                            o = "disabled";
                          } else if (e instanceof HTMLElement || e instanceof SVGElement) {
                            let t = "userSelect" in e.style ? "userSelect" : "webkitUserSelect";
                            (a.set(e, e.style[t]), (e.style[t] = "none"));
                          }
                        })(e.target),
                      (i = N(t, e.pointerType)));
                    let c = (0, y.getEventTarget)(t.nativeEvent);
                    ("releasePointerCapture" in c && c.releasePointerCapture(t.pointerId),
                      z((0, n.getOwnerDocument)(t.currentTarget), "pointerup", l, !1),
                      z((0, n.getOwnerDocument)(t.currentTarget), "pointercancel", u, !1));
                  }
                  i && t.stopPropagation();
                }),
                  (i.onMouseDown = (r) => {
                    if (
                      (0, y.nodeContains)(r.currentTarget, (0, y.getEventTarget)(r.nativeEvent)) &&
                      0 === r.button
                    ) {
                      if (H) {
                        let n = (0, t.preventFocus)(r.target);
                        n && e.disposables.push(n);
                      }
                      r.stopPropagation();
                    }
                  }),
                  (i.onPointerUp = (t) => {
                    (0, y.nodeContains)(t.currentTarget, (0, y.getEventTarget)(t.nativeEvent)) &&
                      "virtual" !== e.pointerType &&
                      (0 !== t.button || e.isPressed || Y(t, e.pointerType || t.pointerType));
                  }),
                  (i.onPointerEnter = (t) => {
                    t.pointerId === e.activePointerId &&
                      e.target &&
                      !e.isOverTarget &&
                      null != e.pointerType &&
                      ((e.isOverTarget = !0), N(O(e.target, t), e.pointerType));
                  }),
                  (i.onPointerLeave = (t) => {
                    t.pointerId === e.activePointerId &&
                      e.target &&
                      e.isOverTarget &&
                      null != e.pointerType &&
                      ((e.isOverTarget = !1), X(O(e.target, t), e.pointerType, !1), q(t));
                  }));
                let l = (t) => {
                    if (t.pointerId === e.activePointerId && e.isPressed && 0 === t.button && e.target) {
                      if ((0, y.nodeContains)(e.target, (0, y.getEventTarget)(t)) && null != e.pointerType) {
                        let r = !1,
                          n = setTimeout(() => {
                            e.isPressed &&
                              e.target instanceof HTMLElement &&
                              (r ? $(t) : ((0, h.focusWithoutScrolling)(e.target), e.target.click()));
                          }, 80);
                        (z(t.currentTarget, "click", () => (r = !0), !0),
                          e.disposables.push(() => clearTimeout(n)));
                      } else $(t);
                      e.isOverTarget = !1;
                    }
                  },
                  u = (e) => {
                    $(e);
                  };
                i.onDragStart = (e) => {
                  (0, y.nodeContains)(e.currentTarget, (0, y.getEventTarget)(e.nativeEvent)) && $(e);
                };
              }
              return i;
            }, [z, L, H, j, V, $, q, X, N, Y, _, Z]);
          return (
            (0, E.useEffect)(() => {
              if (!U) return;
              let e = (0, n.getOwnerDocument)(U.current);
              if (!e || !e.head || e.getElementById(C)) return;
              let t = e.createElement("style");
              ((t.id = C),
                (t.textContent = `
@layer {
  [${k}] {
    touch-action: pan-x pan-y pinch-zoom;
  }
}
    `.trim()),
                e.head.prepend(t));
            }, [U]),
            (0, E.useEffect)(() => {
              let e = G.current;
              return () => {
                var t;
                for (let r of (V || l(null != (t = e.target) ? t : void 0), e.disposables)) r();
                e.disposables = [];
              };
            }, [V]),
            { isPressed: x || W, pressProps: (0, p.mergeProps)(R, J, { [k]: !0 }) }
          );
        },
      ],
      343027,
    );
  },
  207670,
  (e) => {
    "use strict";
    function t() {
      for (var e, t, r = 0, n = "", i = arguments.length; r < i; r++)
        (e = arguments[r]) &&
          (t = (function e(t) {
            var r,
              n,
              i = "";
            if ("string" == typeof t || "number" == typeof t) i += t;
            else if ("object" == typeof t)
              if (Array.isArray(t)) {
                var o = t.length;
                for (r = 0; r < o; r++) t[r] && (n = e(t[r])) && (i && (i += " "), (i += n));
              } else for (n in t) t[n] && (i && (i += " "), (i += n));
            return i;
          })(e)) &&
          (n && (n += " "), (n += t));
      return n;
    }
    e.s(["clsx", 0, t, "default", 0, t]);
  },
]);
