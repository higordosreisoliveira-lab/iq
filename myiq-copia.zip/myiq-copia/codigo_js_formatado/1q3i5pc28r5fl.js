(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  99608,
  919056,
  (e) => {
    "use strict";
    var r = ["small", "medium", "large"],
      o = {
        theme: { spacing: ["divider"], radius: r },
        classGroups: {
          shadow: [{ shadow: r }],
          opacity: [{ opacity: ["disabled"] }],
          "font-size": [{ text: ["tiny", ...r] }],
          "border-w": [{ border: r }],
          "bg-image": [
            "bg-stripe-gradient-default",
            "bg-stripe-gradient-primary",
            "bg-stripe-gradient-secondary",
            "bg-stripe-gradient-success",
            "bg-stripe-gradient-warning",
            "bg-stripe-gradient-danger",
          ],
          transition: [
            ".leading-inherit",
            ".bg-img-inherit",
            ".bg-clip-inherit",
            ".text-fill-inherit",
            ".tap-highlight-transparent",
            ".input-search-cancel-button-none",
            ".transition-background",
            ".transition-colors-opacity",
            ".transition-width",
            ".transition-height",
            ".transition-size",
            ".transition-left",
            ".transition-transform-opacity",
            ".transition-transform-background",
            ".transition-transform-colors",
            ".transition-transform-colors-opacity",
            ".scrollbar-hide",
            ".scrollbar-default",
            ".text-tiny",
            ".text-small",
            ".text-medium",
            ".text-large",
            ".spinner-bar-animation",
            ".spinner-dot-animation",
            ".spinner-dot-blink-animation",
          ]
            .filter((e) => e.includes(".transition"))
            .map((e) => e.replace(".", "")),
        },
      };
    e.s(["twMergeConfig", 0, o], 99608);
    let t = (e, r) => {
        if (0 === e.length) return r.classGroupId;
        let o = e[0],
          a = r.nextPart.get(o),
          n = a ? t(e.slice(1), a) : void 0;
        if (n) return n;
        if (0 === r.validators.length) return;
        let s = e.join("-");
        return r.validators.find((e) => {
          let { validator: r } = e;
          return r(s);
        })?.classGroupId;
      },
      a = /^\[(.+)\]$/,
      n = (e, r, o, t) => {
        e.forEach((e) => {
          if ("string" == typeof e) {
            ("" === e ? r : s(r, e)).classGroupId = o;
            return;
          }
          "function" == typeof e
            ? l(e)
              ? n(e(t), r, o, t)
              : r.validators.push({ validator: e, classGroupId: o })
            : Object.entries(e).forEach((e) => {
                let [a, l] = e;
                n(l, s(r, a), o, t);
              });
        });
      },
      s = (e, r) => {
        let o = e;
        return (
          r.split("-").forEach((e) => {
            (o.nextPart.has(e) || o.nextPart.set(e, { nextPart: new Map(), validators: [] }),
              (o = o.nextPart.get(e)));
          }),
          o
        );
      },
      l = (e) => e.isThemeGetter,
      i = /\s+/;
    function d() {
      let e,
        r,
        o = 0,
        t = "";
      for (; o < arguments.length;) (e = arguments[o++]) && (r = c(e)) && (t && (t += " "), (t += r));
      return t;
    }
    let c = (e) => {
      let r;
      if ("string" == typeof e) return e;
      let o = "";
      for (let t = 0; t < e.length; t++) e[t] && (r = c(e[t])) && (o && (o += " "), (o += r));
      return o;
    };
    function m(e) {
      let r, o, s;
      for (var l = arguments.length, c = Array(l > 1 ? l - 1 : 0), m = 1; m < l; m++) c[m - 1] = arguments[m];
      let p = function (l) {
        var i;
        let d;
        return (
          (o = (r = {
            cache: ((e) => {
              if (e < 1) return { get: () => void 0, set: () => {} };
              let r = 0,
                o = new Map(),
                t = new Map(),
                a = (a, n) => {
                  (o.set(a, n), ++r > e && ((r = 0), (t = o), (o = new Map())));
                };
              return {
                get(e) {
                  let r = o.get(e);
                  return void 0 !== r ? r : void 0 !== (r = t.get(e)) ? (a(e, r), r) : void 0;
                },
                set(e, r) {
                  o.has(e) ? o.set(e, r) : a(e, r);
                },
              };
            })((i = c.reduce((e, r) => r(e), e())).cacheSize),
            parseClassName: ((e) => {
              let { prefix: r, experimentalParseClassName: o } = e,
                t = (e) => {
                  let r,
                    o,
                    t = [],
                    a = 0,
                    n = 0,
                    s = 0;
                  for (let r = 0; r < e.length; r++) {
                    let l = e[r];
                    if (0 === a && 0 === n) {
                      if (":" === l) {
                        (t.push(e.slice(s, r)), (s = r + 1));
                        continue;
                      }
                      if ("/" === l) {
                        o = r;
                        continue;
                      }
                    }
                    "[" === l ? a++ : "]" === l ? a-- : "(" === l ? n++ : ")" === l && n--;
                  }
                  let l = 0 === t.length ? e : e.substring(s),
                    i = (r = l).endsWith("!")
                      ? r.substring(0, r.length - 1)
                      : r.startsWith("!")
                        ? r.substring(1)
                        : r;
                  return {
                    modifiers: t,
                    hasImportantModifier: i !== l,
                    baseClassName: i,
                    maybePostfixModifierPosition: o && o > s ? o - s : void 0,
                  };
                };
              if (r) {
                let e = r + ":",
                  o = t;
                t = (r) =>
                  r.startsWith(e)
                    ? o(r.substring(e.length))
                    : {
                        isExternal: !0,
                        modifiers: [],
                        hasImportantModifier: !1,
                        baseClassName: r,
                        maybePostfixModifierPosition: void 0,
                      };
              }
              if (o) {
                let e = t;
                t = (r) => o({ className: r, parseClassName: e });
              }
              return t;
            })(i),
            sortModifiers:
              ((d = Object.fromEntries(i.orderSensitiveModifiers.map((e) => [e, !0]))),
              (e) => {
                if (e.length <= 1) return e;
                let r = [],
                  o = [];
                return (
                  e.forEach((e) => {
                    "[" === e[0] || d[e] ? (r.push(...o.sort(), e), (o = [])) : o.push(e);
                  }),
                  r.push(...o.sort()),
                  r
                );
              }),
            ...((e) => {
              let r = ((e) => {
                  let { theme: r, classGroups: o } = e,
                    t = { nextPart: new Map(), validators: [] };
                  for (let e in o) n(o[e], t, e, r);
                  return t;
                })(e),
                { conflictingClassGroups: o, conflictingClassGroupModifiers: s } = e;
              return {
                getClassGroupId: (e) => {
                  let o = e.split("-");
                  return (
                    "" === o[0] && 1 !== o.length && o.shift(),
                    t(o, r) ||
                      ((e) => {
                        if (a.test(e)) {
                          let r = a.exec(e)[1],
                            o = r?.substring(0, r.indexOf(":"));
                          if (o) return "arbitrary.." + o;
                        }
                      })(e)
                  );
                },
                getConflictingClassGroupIds: (e, r) => {
                  let t = o[e] || [];
                  return r && s[e] ? [...t, ...s[e]] : t;
                },
              };
            })(i),
          }).cache.get),
          (s = r.cache.set),
          (p = u),
          u(l)
        );
      };
      function u(e) {
        let t = o(e);
        if (t) return t;
        let a = ((e, r) => {
          let { parseClassName: o, getClassGroupId: t, getConflictingClassGroupIds: a, sortModifiers: n } = r,
            s = [],
            l = e.trim().split(i),
            d = "";
          for (let e = l.length - 1; e >= 0; e -= 1) {
            let r = l[e],
              {
                isExternal: i,
                modifiers: c,
                hasImportantModifier: m,
                baseClassName: p,
                maybePostfixModifierPosition: u,
              } = o(r);
            if (i) {
              d = r + (d.length > 0 ? " " + d : d);
              continue;
            }
            let b = !!u,
              f = t(b ? p.substring(0, u) : p);
            if (!f) {
              if (!b || !(f = t(p))) {
                d = r + (d.length > 0 ? " " + d : d);
                continue;
              }
              b = !1;
            }
            let g = n(c).join(":"),
              h = m ? g + "!" : g,
              k = h + f;
            if (s.includes(k)) continue;
            s.push(k);
            let x = a(f, b);
            for (let e = 0; e < x.length; ++e) {
              let r = x[e];
              s.push(h + r);
            }
            d = r + (d.length > 0 ? " " + d : d);
          }
          return d;
        })(e, r);
        return (s(e, a), a);
      }
      return function () {
        return p(d.apply(null, arguments));
      };
    }
    let p = (e) => {
        let r = (r) => r[e] || [];
        return ((r.isThemeGetter = !0), r);
      },
      u = /^\[(?:(\w[\w-]*):)?(.+)\]$/i,
      b = /^\((?:(\w[\w-]*):)?(.+)\)$/i,
      f = /^\d+\/\d+$/,
      g = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,
      h =
        /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,
      k = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/,
      x = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,
      w = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,
      y = (e) => f.test(e),
      v = (e) => !!e && !Number.isNaN(Number(e)),
      z = (e) => !!e && Number.isInteger(Number(e)),
      G = (e) => e.endsWith("%") && v(e.slice(0, -1)),
      M = (e) => g.test(e),
      C = () => !0,
      j = (e) => h.test(e) && !k.test(e),
      P = () => !1,
      N = (e) => x.test(e),
      S = (e) => w.test(e),
      I = (e) => !T(e) && !B(e),
      $ = (e) => H(e, V, P),
      T = (e) => u.test(e),
      E = (e) => H(e, X, j),
      O = (e) => H(e, Y, v),
      A = (e) => H(e, L, P),
      W = (e) => H(e, Q, S),
      q = (e) => H(e, ee, N),
      B = (e) => b.test(e),
      K = (e) => J(e, X),
      R = (e) => J(e, Z),
      U = (e) => J(e, L),
      _ = (e) => J(e, V),
      D = (e) => J(e, Q),
      F = (e) => J(e, ee, !0),
      H = (e, r, o) => {
        let t = u.exec(e);
        return !!t && (t[1] ? r(t[1]) : o(t[2]));
      },
      J = function (e, r) {
        let o = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          t = b.exec(e);
        return !!t && (t[1] ? r(t[1]) : o);
      },
      L = (e) => "position" === e || "percentage" === e,
      Q = (e) => "image" === e || "url" === e,
      V = (e) => "length" === e || "size" === e || "bg-size" === e,
      X = (e) => "length" === e,
      Y = (e) => "number" === e,
      Z = (e) => "family-name" === e,
      ee = (e) => "shadow" === e,
      er = () => {
        let e = p("color"),
          r = p("font"),
          o = p("text"),
          t = p("font-weight"),
          a = p("tracking"),
          n = p("leading"),
          s = p("breakpoint"),
          l = p("container"),
          i = p("spacing"),
          d = p("radius"),
          c = p("shadow"),
          m = p("inset-shadow"),
          u = p("text-shadow"),
          b = p("drop-shadow"),
          f = p("blur"),
          g = p("perspective"),
          h = p("aspect"),
          k = p("ease"),
          x = p("animate"),
          w = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"],
          j = () => [
            "center",
            "top",
            "bottom",
            "left",
            "right",
            "top-left",
            "left-top",
            "top-right",
            "right-top",
            "bottom-right",
            "right-bottom",
            "bottom-left",
            "left-bottom",
          ],
          P = () => [...j(), B, T],
          N = () => ["auto", "hidden", "clip", "visible", "scroll"],
          S = () => ["auto", "contain", "none"],
          H = () => [B, T, i],
          J = () => [y, "full", "auto", ...H()],
          L = () => [z, "none", "subgrid", B, T],
          Q = () => ["auto", { span: ["full", z, B, T] }, z, B, T],
          V = () => [z, "auto", B, T],
          X = () => ["auto", "min", "max", "fr", B, T],
          Y = () => [
            "start",
            "end",
            "center",
            "between",
            "around",
            "evenly",
            "stretch",
            "baseline",
            "center-safe",
            "end-safe",
          ],
          Z = () => ["start", "end", "center", "stretch", "center-safe", "end-safe"],
          ee = () => ["auto", ...H()],
          er = () => [
            y,
            "auto",
            "full",
            "dvw",
            "dvh",
            "lvw",
            "lvh",
            "svw",
            "svh",
            "min",
            "max",
            "fit",
            ...H(),
          ],
          eo = () => [e, B, T],
          et = () => [...j(), U, A, { position: [B, T] }],
          ea = () => ["no-repeat", { repeat: ["", "x", "y", "space", "round"] }],
          en = () => ["auto", "cover", "contain", _, $, { size: [B, T] }],
          es = () => [G, K, E],
          el = () => ["", "none", "full", d, B, T],
          ei = () => ["", v, K, E],
          ed = () => ["solid", "dashed", "dotted", "double"],
          ec = () => [
            "normal",
            "multiply",
            "screen",
            "overlay",
            "darken",
            "lighten",
            "color-dodge",
            "color-burn",
            "hard-light",
            "soft-light",
            "difference",
            "exclusion",
            "hue",
            "saturation",
            "color",
            "luminosity",
          ],
          em = () => [v, G, U, A],
          ep = () => ["", "none", f, B, T],
          eu = () => ["none", v, B, T],
          eb = () => ["none", v, B, T],
          ef = () => [v, B, T],
          eg = () => [y, "full", ...H()];
        return {
          cacheSize: 500,
          theme: {
            animate: ["spin", "ping", "pulse", "bounce"],
            aspect: ["video"],
            blur: [M],
            breakpoint: [M],
            color: [C],
            container: [M],
            "drop-shadow": [M],
            ease: ["in", "out", "in-out"],
            font: [I],
            "font-weight": [
              "thin",
              "extralight",
              "light",
              "normal",
              "medium",
              "semibold",
              "bold",
              "extrabold",
              "black",
            ],
            "inset-shadow": [M],
            leading: ["none", "tight", "snug", "normal", "relaxed", "loose"],
            perspective: ["dramatic", "near", "normal", "midrange", "distant", "none"],
            radius: [M],
            shadow: [M],
            spacing: ["px", v],
            text: [M],
            "text-shadow": [M],
            tracking: ["tighter", "tight", "normal", "wide", "wider", "widest"],
          },
          classGroups: {
            aspect: [{ aspect: ["auto", "square", y, T, B, h] }],
            container: ["container"],
            columns: [{ columns: [v, T, B, l] }],
            "break-after": [{ "break-after": w() }],
            "break-before": [{ "break-before": w() }],
            "break-inside": [{ "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"] }],
            "box-decoration": [{ "box-decoration": ["slice", "clone"] }],
            box: [{ box: ["border", "content"] }],
            display: [
              "block",
              "inline-block",
              "inline",
              "flex",
              "inline-flex",
              "table",
              "inline-table",
              "table-caption",
              "table-cell",
              "table-column",
              "table-column-group",
              "table-footer-group",
              "table-header-group",
              "table-row-group",
              "table-row",
              "flow-root",
              "grid",
              "inline-grid",
              "contents",
              "list-item",
              "hidden",
            ],
            sr: ["sr-only", "not-sr-only"],
            float: [{ float: ["right", "left", "none", "start", "end"] }],
            clear: [{ clear: ["left", "right", "both", "none", "start", "end"] }],
            isolation: ["isolate", "isolation-auto"],
            "object-fit": [{ object: ["contain", "cover", "fill", "none", "scale-down"] }],
            "object-position": [{ object: P() }],
            overflow: [{ overflow: N() }],
            "overflow-x": [{ "overflow-x": N() }],
            "overflow-y": [{ "overflow-y": N() }],
            overscroll: [{ overscroll: S() }],
            "overscroll-x": [{ "overscroll-x": S() }],
            "overscroll-y": [{ "overscroll-y": S() }],
            position: ["static", "fixed", "absolute", "relative", "sticky"],
            inset: [{ inset: J() }],
            "inset-x": [{ "inset-x": J() }],
            "inset-y": [{ "inset-y": J() }],
            start: [{ start: J() }],
            end: [{ end: J() }],
            top: [{ top: J() }],
            right: [{ right: J() }],
            bottom: [{ bottom: J() }],
            left: [{ left: J() }],
            visibility: ["visible", "invisible", "collapse"],
            z: [{ z: [z, "auto", B, T] }],
            basis: [{ basis: [y, "full", "auto", l, ...H()] }],
            "flex-direction": [{ flex: ["row", "row-reverse", "col", "col-reverse"] }],
            "flex-wrap": [{ flex: ["nowrap", "wrap", "wrap-reverse"] }],
            flex: [{ flex: [v, y, "auto", "initial", "none", T] }],
            grow: [{ grow: ["", v, B, T] }],
            shrink: [{ shrink: ["", v, B, T] }],
            order: [{ order: [z, "first", "last", "none", B, T] }],
            "grid-cols": [{ "grid-cols": L() }],
            "col-start-end": [{ col: Q() }],
            "col-start": [{ "col-start": V() }],
            "col-end": [{ "col-end": V() }],
            "grid-rows": [{ "grid-rows": L() }],
            "row-start-end": [{ row: Q() }],
            "row-start": [{ "row-start": V() }],
            "row-end": [{ "row-end": V() }],
            "grid-flow": [{ "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"] }],
            "auto-cols": [{ "auto-cols": X() }],
            "auto-rows": [{ "auto-rows": X() }],
            gap: [{ gap: H() }],
            "gap-x": [{ "gap-x": H() }],
            "gap-y": [{ "gap-y": H() }],
            "justify-content": [{ justify: [...Y(), "normal"] }],
            "justify-items": [{ "justify-items": [...Z(), "normal"] }],
            "justify-self": [{ "justify-self": ["auto", ...Z()] }],
            "align-content": [{ content: ["normal", ...Y()] }],
            "align-items": [{ items: [...Z(), { baseline: ["", "last"] }] }],
            "align-self": [{ self: ["auto", ...Z(), { baseline: ["", "last"] }] }],
            "place-content": [{ "place-content": Y() }],
            "place-items": [{ "place-items": [...Z(), "baseline"] }],
            "place-self": [{ "place-self": ["auto", ...Z()] }],
            p: [{ p: H() }],
            px: [{ px: H() }],
            py: [{ py: H() }],
            ps: [{ ps: H() }],
            pe: [{ pe: H() }],
            pt: [{ pt: H() }],
            pr: [{ pr: H() }],
            pb: [{ pb: H() }],
            pl: [{ pl: H() }],
            m: [{ m: ee() }],
            mx: [{ mx: ee() }],
            my: [{ my: ee() }],
            ms: [{ ms: ee() }],
            me: [{ me: ee() }],
            mt: [{ mt: ee() }],
            mr: [{ mr: ee() }],
            mb: [{ mb: ee() }],
            ml: [{ ml: ee() }],
            "space-x": [{ "space-x": H() }],
            "space-x-reverse": ["space-x-reverse"],
            "space-y": [{ "space-y": H() }],
            "space-y-reverse": ["space-y-reverse"],
            size: [{ size: er() }],
            w: [{ w: [l, "screen", ...er()] }],
            "min-w": [{ "min-w": [l, "screen", "none", ...er()] }],
            "max-w": [{ "max-w": [l, "screen", "none", "prose", { screen: [s] }, ...er()] }],
            h: [{ h: ["screen", "lh", ...er()] }],
            "min-h": [{ "min-h": ["screen", "lh", "none", ...er()] }],
            "max-h": [{ "max-h": ["screen", "lh", ...er()] }],
            "font-size": [{ text: ["base", o, K, E] }],
            "font-smoothing": ["antialiased", "subpixel-antialiased"],
            "font-style": ["italic", "not-italic"],
            "font-weight": [{ font: [t, B, O] }],
            "font-stretch": [
              {
                "font-stretch": [
                  "ultra-condensed",
                  "extra-condensed",
                  "condensed",
                  "semi-condensed",
                  "normal",
                  "semi-expanded",
                  "expanded",
                  "extra-expanded",
                  "ultra-expanded",
                  G,
                  T,
                ],
              },
            ],
            "font-family": [{ font: [R, T, r] }],
            "fvn-normal": ["normal-nums"],
            "fvn-ordinal": ["ordinal"],
            "fvn-slashed-zero": ["slashed-zero"],
            "fvn-figure": ["lining-nums", "oldstyle-nums"],
            "fvn-spacing": ["proportional-nums", "tabular-nums"],
            "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
            tracking: [{ tracking: [a, B, T] }],
            "line-clamp": [{ "line-clamp": [v, "none", B, O] }],
            leading: [{ leading: [n, ...H()] }],
            "list-image": [{ "list-image": ["none", B, T] }],
            "list-style-position": [{ list: ["inside", "outside"] }],
            "list-style-type": [{ list: ["disc", "decimal", "none", B, T] }],
            "text-alignment": [{ text: ["left", "center", "right", "justify", "start", "end"] }],
            "placeholder-color": [{ placeholder: eo() }],
            "text-color": [{ text: eo() }],
            "text-decoration": ["underline", "overline", "line-through", "no-underline"],
            "text-decoration-style": [{ decoration: [...ed(), "wavy"] }],
            "text-decoration-thickness": [{ decoration: [v, "from-font", "auto", B, E] }],
            "text-decoration-color": [{ decoration: eo() }],
            "underline-offset": [{ "underline-offset": [v, "auto", B, T] }],
            "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
            "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
            "text-wrap": [{ text: ["wrap", "nowrap", "balance", "pretty"] }],
            indent: [{ indent: H() }],
            "vertical-align": [
              {
                align: [
                  "baseline",
                  "top",
                  "middle",
                  "bottom",
                  "text-top",
                  "text-bottom",
                  "sub",
                  "super",
                  B,
                  T,
                ],
              },
            ],
            whitespace: [{ whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"] }],
            break: [{ break: ["normal", "words", "all", "keep"] }],
            wrap: [{ wrap: ["break-word", "anywhere", "normal"] }],
            hyphens: [{ hyphens: ["none", "manual", "auto"] }],
            content: [{ content: ["none", B, T] }],
            "bg-attachment": [{ bg: ["fixed", "local", "scroll"] }],
            "bg-clip": [{ "bg-clip": ["border", "padding", "content", "text"] }],
            "bg-origin": [{ "bg-origin": ["border", "padding", "content"] }],
            "bg-position": [{ bg: et() }],
            "bg-repeat": [{ bg: ea() }],
            "bg-size": [{ bg: en() }],
            "bg-image": [
              {
                bg: [
                  "none",
                  {
                    linear: [{ to: ["t", "tr", "r", "br", "b", "bl", "l", "tl"] }, z, B, T],
                    radial: ["", B, T],
                    conic: [z, B, T],
                  },
                  D,
                  W,
                ],
              },
            ],
            "bg-color": [{ bg: eo() }],
            "gradient-from-pos": [{ from: es() }],
            "gradient-via-pos": [{ via: es() }],
            "gradient-to-pos": [{ to: es() }],
            "gradient-from": [{ from: eo() }],
            "gradient-via": [{ via: eo() }],
            "gradient-to": [{ to: eo() }],
            rounded: [{ rounded: el() }],
            "rounded-s": [{ "rounded-s": el() }],
            "rounded-e": [{ "rounded-e": el() }],
            "rounded-t": [{ "rounded-t": el() }],
            "rounded-r": [{ "rounded-r": el() }],
            "rounded-b": [{ "rounded-b": el() }],
            "rounded-l": [{ "rounded-l": el() }],
            "rounded-ss": [{ "rounded-ss": el() }],
            "rounded-se": [{ "rounded-se": el() }],
            "rounded-ee": [{ "rounded-ee": el() }],
            "rounded-es": [{ "rounded-es": el() }],
            "rounded-tl": [{ "rounded-tl": el() }],
            "rounded-tr": [{ "rounded-tr": el() }],
            "rounded-br": [{ "rounded-br": el() }],
            "rounded-bl": [{ "rounded-bl": el() }],
            "border-w": [{ border: ei() }],
            "border-w-x": [{ "border-x": ei() }],
            "border-w-y": [{ "border-y": ei() }],
            "border-w-s": [{ "border-s": ei() }],
            "border-w-e": [{ "border-e": ei() }],
            "border-w-t": [{ "border-t": ei() }],
            "border-w-r": [{ "border-r": ei() }],
            "border-w-b": [{ "border-b": ei() }],
            "border-w-l": [{ "border-l": ei() }],
            "divide-x": [{ "divide-x": ei() }],
            "divide-x-reverse": ["divide-x-reverse"],
            "divide-y": [{ "divide-y": ei() }],
            "divide-y-reverse": ["divide-y-reverse"],
            "border-style": [{ border: [...ed(), "hidden", "none"] }],
            "divide-style": [{ divide: [...ed(), "hidden", "none"] }],
            "border-color": [{ border: eo() }],
            "border-color-x": [{ "border-x": eo() }],
            "border-color-y": [{ "border-y": eo() }],
            "border-color-s": [{ "border-s": eo() }],
            "border-color-e": [{ "border-e": eo() }],
            "border-color-t": [{ "border-t": eo() }],
            "border-color-r": [{ "border-r": eo() }],
            "border-color-b": [{ "border-b": eo() }],
            "border-color-l": [{ "border-l": eo() }],
            "divide-color": [{ divide: eo() }],
            "outline-style": [{ outline: [...ed(), "none", "hidden"] }],
            "outline-offset": [{ "outline-offset": [v, B, T] }],
            "outline-w": [{ outline: ["", v, K, E] }],
            "outline-color": [{ outline: eo() }],
            shadow: [{ shadow: ["", "none", c, F, q] }],
            "shadow-color": [{ shadow: eo() }],
            "inset-shadow": [{ "inset-shadow": ["none", m, F, q] }],
            "inset-shadow-color": [{ "inset-shadow": eo() }],
            "ring-w": [{ ring: ei() }],
            "ring-w-inset": ["ring-inset"],
            "ring-color": [{ ring: eo() }],
            "ring-offset-w": [{ "ring-offset": [v, E] }],
            "ring-offset-color": [{ "ring-offset": eo() }],
            "inset-ring-w": [{ "inset-ring": ei() }],
            "inset-ring-color": [{ "inset-ring": eo() }],
            "text-shadow": [{ "text-shadow": ["none", u, F, q] }],
            "text-shadow-color": [{ "text-shadow": eo() }],
            opacity: [{ opacity: [v, B, T] }],
            "mix-blend": [{ "mix-blend": [...ec(), "plus-darker", "plus-lighter"] }],
            "bg-blend": [{ "bg-blend": ec() }],
            "mask-clip": [
              { "mask-clip": ["border", "padding", "content", "fill", "stroke", "view"] },
              "mask-no-clip",
            ],
            "mask-composite": [{ mask: ["add", "subtract", "intersect", "exclude"] }],
            "mask-image-linear-pos": [{ "mask-linear": [v] }],
            "mask-image-linear-from-pos": [{ "mask-linear-from": em() }],
            "mask-image-linear-to-pos": [{ "mask-linear-to": em() }],
            "mask-image-linear-from-color": [{ "mask-linear-from": eo() }],
            "mask-image-linear-to-color": [{ "mask-linear-to": eo() }],
            "mask-image-t-from-pos": [{ "mask-t-from": em() }],
            "mask-image-t-to-pos": [{ "mask-t-to": em() }],
            "mask-image-t-from-color": [{ "mask-t-from": eo() }],
            "mask-image-t-to-color": [{ "mask-t-to": eo() }],
            "mask-image-r-from-pos": [{ "mask-r-from": em() }],
            "mask-image-r-to-pos": [{ "mask-r-to": em() }],
            "mask-image-r-from-color": [{ "mask-r-from": eo() }],
            "mask-image-r-to-color": [{ "mask-r-to": eo() }],
            "mask-image-b-from-pos": [{ "mask-b-from": em() }],
            "mask-image-b-to-pos": [{ "mask-b-to": em() }],
            "mask-image-b-from-color": [{ "mask-b-from": eo() }],
            "mask-image-b-to-color": [{ "mask-b-to": eo() }],
            "mask-image-l-from-pos": [{ "mask-l-from": em() }],
            "mask-image-l-to-pos": [{ "mask-l-to": em() }],
            "mask-image-l-from-color": [{ "mask-l-from": eo() }],
            "mask-image-l-to-color": [{ "mask-l-to": eo() }],
            "mask-image-x-from-pos": [{ "mask-x-from": em() }],
            "mask-image-x-to-pos": [{ "mask-x-to": em() }],
            "mask-image-x-from-color": [{ "mask-x-from": eo() }],
            "mask-image-x-to-color": [{ "mask-x-to": eo() }],
            "mask-image-y-from-pos": [{ "mask-y-from": em() }],
            "mask-image-y-to-pos": [{ "mask-y-to": em() }],
            "mask-image-y-from-color": [{ "mask-y-from": eo() }],
            "mask-image-y-to-color": [{ "mask-y-to": eo() }],
            "mask-image-radial": [{ "mask-radial": [B, T] }],
            "mask-image-radial-from-pos": [{ "mask-radial-from": em() }],
            "mask-image-radial-to-pos": [{ "mask-radial-to": em() }],
            "mask-image-radial-from-color": [{ "mask-radial-from": eo() }],
            "mask-image-radial-to-color": [{ "mask-radial-to": eo() }],
            "mask-image-radial-shape": [{ "mask-radial": ["circle", "ellipse"] }],
            "mask-image-radial-size": [
              { "mask-radial": [{ closest: ["side", "corner"], farthest: ["side", "corner"] }] },
            ],
            "mask-image-radial-pos": [{ "mask-radial-at": j() }],
            "mask-image-conic-pos": [{ "mask-conic": [v] }],
            "mask-image-conic-from-pos": [{ "mask-conic-from": em() }],
            "mask-image-conic-to-pos": [{ "mask-conic-to": em() }],
            "mask-image-conic-from-color": [{ "mask-conic-from": eo() }],
            "mask-image-conic-to-color": [{ "mask-conic-to": eo() }],
            "mask-mode": [{ mask: ["alpha", "luminance", "match"] }],
            "mask-origin": [{ "mask-origin": ["border", "padding", "content", "fill", "stroke", "view"] }],
            "mask-position": [{ mask: et() }],
            "mask-repeat": [{ mask: ea() }],
            "mask-size": [{ mask: en() }],
            "mask-type": [{ "mask-type": ["alpha", "luminance"] }],
            "mask-image": [{ mask: ["none", B, T] }],
            filter: [{ filter: ["", "none", B, T] }],
            blur: [{ blur: ep() }],
            brightness: [{ brightness: [v, B, T] }],
            contrast: [{ contrast: [v, B, T] }],
            "drop-shadow": [{ "drop-shadow": ["", "none", b, F, q] }],
            "drop-shadow-color": [{ "drop-shadow": eo() }],
            grayscale: [{ grayscale: ["", v, B, T] }],
            "hue-rotate": [{ "hue-rotate": [v, B, T] }],
            invert: [{ invert: ["", v, B, T] }],
            saturate: [{ saturate: [v, B, T] }],
            sepia: [{ sepia: ["", v, B, T] }],
            "backdrop-filter": [{ "backdrop-filter": ["", "none", B, T] }],
            "backdrop-blur": [{ "backdrop-blur": ep() }],
            "backdrop-brightness": [{ "backdrop-brightness": [v, B, T] }],
            "backdrop-contrast": [{ "backdrop-contrast": [v, B, T] }],
            "backdrop-grayscale": [{ "backdrop-grayscale": ["", v, B, T] }],
            "backdrop-hue-rotate": [{ "backdrop-hue-rotate": [v, B, T] }],
            "backdrop-invert": [{ "backdrop-invert": ["", v, B, T] }],
            "backdrop-opacity": [{ "backdrop-opacity": [v, B, T] }],
            "backdrop-saturate": [{ "backdrop-saturate": [v, B, T] }],
            "backdrop-sepia": [{ "backdrop-sepia": ["", v, B, T] }],
            "border-collapse": [{ border: ["collapse", "separate"] }],
            "border-spacing": [{ "border-spacing": H() }],
            "border-spacing-x": [{ "border-spacing-x": H() }],
            "border-spacing-y": [{ "border-spacing-y": H() }],
            "table-layout": [{ table: ["auto", "fixed"] }],
            caption: [{ caption: ["top", "bottom"] }],
            transition: [
              { transition: ["", "all", "colors", "opacity", "shadow", "transform", "none", B, T] },
            ],
            "transition-behavior": [{ transition: ["normal", "discrete"] }],
            duration: [{ duration: [v, "initial", B, T] }],
            ease: [{ ease: ["linear", "initial", k, B, T] }],
            delay: [{ delay: [v, B, T] }],
            animate: [{ animate: ["none", x, B, T] }],
            backface: [{ backface: ["hidden", "visible"] }],
            perspective: [{ perspective: [g, B, T] }],
            "perspective-origin": [{ "perspective-origin": P() }],
            rotate: [{ rotate: eu() }],
            "rotate-x": [{ "rotate-x": eu() }],
            "rotate-y": [{ "rotate-y": eu() }],
            "rotate-z": [{ "rotate-z": eu() }],
            scale: [{ scale: eb() }],
            "scale-x": [{ "scale-x": eb() }],
            "scale-y": [{ "scale-y": eb() }],
            "scale-z": [{ "scale-z": eb() }],
            "scale-3d": ["scale-3d"],
            skew: [{ skew: ef() }],
            "skew-x": [{ "skew-x": ef() }],
            "skew-y": [{ "skew-y": ef() }],
            transform: [{ transform: [B, T, "", "none", "gpu", "cpu"] }],
            "transform-origin": [{ origin: P() }],
            "transform-style": [{ transform: ["3d", "flat"] }],
            translate: [{ translate: eg() }],
            "translate-x": [{ "translate-x": eg() }],
            "translate-y": [{ "translate-y": eg() }],
            "translate-z": [{ "translate-z": eg() }],
            "translate-none": ["translate-none"],
            accent: [{ accent: eo() }],
            appearance: [{ appearance: ["none", "auto"] }],
            "caret-color": [{ caret: eo() }],
            "color-scheme": [
              { scheme: ["normal", "dark", "light", "light-dark", "only-dark", "only-light"] },
            ],
            cursor: [
              {
                cursor: [
                  "auto",
                  "default",
                  "pointer",
                  "wait",
                  "text",
                  "move",
                  "help",
                  "not-allowed",
                  "none",
                  "context-menu",
                  "progress",
                  "cell",
                  "crosshair",
                  "vertical-text",
                  "alias",
                  "copy",
                  "no-drop",
                  "grab",
                  "grabbing",
                  "all-scroll",
                  "col-resize",
                  "row-resize",
                  "n-resize",
                  "e-resize",
                  "s-resize",
                  "w-resize",
                  "ne-resize",
                  "nw-resize",
                  "se-resize",
                  "sw-resize",
                  "ew-resize",
                  "ns-resize",
                  "nesw-resize",
                  "nwse-resize",
                  "zoom-in",
                  "zoom-out",
                  B,
                  T,
                ],
              },
            ],
            "field-sizing": [{ "field-sizing": ["fixed", "content"] }],
            "pointer-events": [{ "pointer-events": ["auto", "none"] }],
            resize: [{ resize: ["none", "", "y", "x"] }],
            "scroll-behavior": [{ scroll: ["auto", "smooth"] }],
            "scroll-m": [{ "scroll-m": H() }],
            "scroll-mx": [{ "scroll-mx": H() }],
            "scroll-my": [{ "scroll-my": H() }],
            "scroll-ms": [{ "scroll-ms": H() }],
            "scroll-me": [{ "scroll-me": H() }],
            "scroll-mt": [{ "scroll-mt": H() }],
            "scroll-mr": [{ "scroll-mr": H() }],
            "scroll-mb": [{ "scroll-mb": H() }],
            "scroll-ml": [{ "scroll-ml": H() }],
            "scroll-p": [{ "scroll-p": H() }],
            "scroll-px": [{ "scroll-px": H() }],
            "scroll-py": [{ "scroll-py": H() }],
            "scroll-ps": [{ "scroll-ps": H() }],
            "scroll-pe": [{ "scroll-pe": H() }],
            "scroll-pt": [{ "scroll-pt": H() }],
            "scroll-pr": [{ "scroll-pr": H() }],
            "scroll-pb": [{ "scroll-pb": H() }],
            "scroll-pl": [{ "scroll-pl": H() }],
            "snap-align": [{ snap: ["start", "end", "center", "align-none"] }],
            "snap-stop": [{ snap: ["normal", "always"] }],
            "snap-type": [{ snap: ["none", "x", "y", "both"] }],
            "snap-strictness": [{ snap: ["mandatory", "proximity"] }],
            touch: [{ touch: ["auto", "none", "manipulation"] }],
            "touch-x": [{ "touch-pan": ["x", "left", "right"] }],
            "touch-y": [{ "touch-pan": ["y", "up", "down"] }],
            "touch-pz": ["touch-pinch-zoom"],
            select: [{ select: ["none", "text", "all", "auto"] }],
            "will-change": [{ "will-change": ["auto", "scroll", "contents", "transform", B, T] }],
            fill: [{ fill: ["none", ...eo()] }],
            "stroke-w": [{ stroke: [v, K, E, O] }],
            stroke: [{ stroke: ["none", ...eo()] }],
            "forced-color-adjust": [{ "forced-color-adjust": ["auto", "none"] }],
          },
          conflictingClassGroups: {
            overflow: ["overflow-x", "overflow-y"],
            overscroll: ["overscroll-x", "overscroll-y"],
            inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
            "inset-x": ["right", "left"],
            "inset-y": ["top", "bottom"],
            flex: ["basis", "grow", "shrink"],
            gap: ["gap-x", "gap-y"],
            p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
            px: ["pr", "pl"],
            py: ["pt", "pb"],
            m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
            mx: ["mr", "ml"],
            my: ["mt", "mb"],
            size: ["w", "h"],
            "font-size": ["leading"],
            "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
            "fvn-ordinal": ["fvn-normal"],
            "fvn-slashed-zero": ["fvn-normal"],
            "fvn-figure": ["fvn-normal"],
            "fvn-spacing": ["fvn-normal"],
            "fvn-fraction": ["fvn-normal"],
            "line-clamp": ["display", "overflow"],
            rounded: [
              "rounded-s",
              "rounded-e",
              "rounded-t",
              "rounded-r",
              "rounded-b",
              "rounded-l",
              "rounded-ss",
              "rounded-se",
              "rounded-ee",
              "rounded-es",
              "rounded-tl",
              "rounded-tr",
              "rounded-br",
              "rounded-bl",
            ],
            "rounded-s": ["rounded-ss", "rounded-es"],
            "rounded-e": ["rounded-se", "rounded-ee"],
            "rounded-t": ["rounded-tl", "rounded-tr"],
            "rounded-r": ["rounded-tr", "rounded-br"],
            "rounded-b": ["rounded-br", "rounded-bl"],
            "rounded-l": ["rounded-tl", "rounded-bl"],
            "border-spacing": ["border-spacing-x", "border-spacing-y"],
            "border-w": [
              "border-w-x",
              "border-w-y",
              "border-w-s",
              "border-w-e",
              "border-w-t",
              "border-w-r",
              "border-w-b",
              "border-w-l",
            ],
            "border-w-x": ["border-w-r", "border-w-l"],
            "border-w-y": ["border-w-t", "border-w-b"],
            "border-color": [
              "border-color-x",
              "border-color-y",
              "border-color-s",
              "border-color-e",
              "border-color-t",
              "border-color-r",
              "border-color-b",
              "border-color-l",
            ],
            "border-color-x": ["border-color-r", "border-color-l"],
            "border-color-y": ["border-color-t", "border-color-b"],
            translate: ["translate-x", "translate-y", "translate-none"],
            "translate-none": ["translate", "translate-x", "translate-y", "translate-z"],
            "scroll-m": [
              "scroll-mx",
              "scroll-my",
              "scroll-ms",
              "scroll-me",
              "scroll-mt",
              "scroll-mr",
              "scroll-mb",
              "scroll-ml",
            ],
            "scroll-mx": ["scroll-mr", "scroll-ml"],
            "scroll-my": ["scroll-mt", "scroll-mb"],
            "scroll-p": [
              "scroll-px",
              "scroll-py",
              "scroll-ps",
              "scroll-pe",
              "scroll-pt",
              "scroll-pr",
              "scroll-pb",
              "scroll-pl",
            ],
            "scroll-px": ["scroll-pr", "scroll-pl"],
            "scroll-py": ["scroll-pt", "scroll-pb"],
            touch: ["touch-x", "touch-y", "touch-pz"],
            "touch-x": ["touch"],
            "touch-y": ["touch"],
            "touch-pz": ["touch"],
          },
          conflictingClassGroupModifiers: { "font-size": ["leading"] },
          orderSensitiveModifiers: [
            "*",
            "**",
            "after",
            "backdrop",
            "before",
            "details-content",
            "file",
            "first-letter",
            "first-line",
            "marker",
            "placeholder",
            "selection",
          ],
        };
      },
      eo = (e, r, o) => {
        void 0 !== o && (e[r] = o);
      },
      et = (e, r) => {
        if (r) for (let o in r) eo(e, o, r[o]);
      },
      ea = (e, r) => {
        if (r) for (let o in r) en(e, r, o);
      },
      en = (e, r, o) => {
        let t = r[o];
        void 0 !== t && (e[o] = e[o] ? e[o].concat(t) : t);
      },
      es = m(er);
    e.s(
      [
        "extendTailwindMerge",
        0,
        function (e) {
          for (var r = arguments.length, o = Array(r > 1 ? r - 1 : 0), t = 1; t < r; t++)
            o[t - 1] = arguments[t];
          return "function" == typeof e
            ? m(er, e, ...o)
            : m(
                () =>
                  ((e, r) => {
                    let {
                      cacheSize: o,
                      prefix: t,
                      experimentalParseClassName: a,
                      extend: n = {},
                      override: s = {},
                    } = r;
                    return (
                      eo(e, "cacheSize", o),
                      eo(e, "prefix", t),
                      eo(e, "experimentalParseClassName", a),
                      et(e.theme, s.theme),
                      et(e.classGroups, s.classGroups),
                      et(e.conflictingClassGroups, s.conflictingClassGroups),
                      et(e.conflictingClassGroupModifiers, s.conflictingClassGroupModifiers),
                      eo(e, "orderSensitiveModifiers", s.orderSensitiveModifiers),
                      ea(e.theme, n.theme),
                      ea(e.classGroups, n.classGroups),
                      ea(e.conflictingClassGroups, n.conflictingClassGroups),
                      ea(e.conflictingClassGroupModifiers, n.conflictingClassGroupModifiers),
                      en(e, n, "orderSensitiveModifiers"),
                      e
                    );
                  })(er(), e),
                ...o,
              );
        },
        "twMerge",
        0,
        es,
      ],
      919056,
    );
  },
]);
