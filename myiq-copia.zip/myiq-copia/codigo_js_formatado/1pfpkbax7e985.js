(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  557050,
  (e) => {
    e.v((a) => Promise.all(["static/chunks/1q2-_sktf0gwd.js"].map((a) => e.l(a))).then(() => a(864526)));
  },
  575898,
  (e) => {
    e.v((a) => Promise.all(["static/chunks/21jplqh00zxui.js"].map((a) => e.l(a))).then(() => a(952837)));
  },
  436306,
  (e) => {
    "use strict";
    var a = e.i(843476),
      s = e.i(520837),
      t = e.i(876898),
      l = e.i(901775),
      i = e.i(592021),
      n = e.i(770703);
    let r = (0, n.default)(() => e.A(557050), { loadableGenerated: { modules: [864526] } }),
      d = (0, n.default)(() => e.A(575898), { loadableGenerated: { modules: [952837] } });
    e.s(
      [
        "default",
        0,
        (e) => {
          let { review: n, isClickable: o, whiteCards: c } = e,
            m = !!o && !!n?.reviewUrl;
          return (0, a.jsxs)(s.Card, {
            as: m ? "a" : void 0,
            ...(m ? { href: n?.reviewUrl ?? void 0, target: "_blank", rel: "noopener noreferrer" } : {}),
            isPressable: m,
            disableRipple: !0,
            className: `h-full min-h-[200px] w-full gap-3 overflow-hidden rounded-2xl px-6 py-6 !antialiased ${c ? "border border-[#E6E7EB] bg-white" : "bg-[#F5F6F8]"} ${m ? "cursor-pointer transition-shadow" : ""}`,
            shadow: "none",
            children: [
              (0, a.jsxs)(i.CardHeader, {
                className: "flex items-center justify-between gap-2 p-0",
                children: [(0, a.jsx)(d, { rating: n?.rating ?? 5 }), (0, a.jsx)(r, {})],
              }),
              (0, a.jsxs)(t.CardBody, {
                className: "gap-2 p-0 !antialiased",
                children: [
                  n?.title
                    ? (0, a.jsx)("p", {
                        className: "text-md text-start font-semibold leading-snug text-[#191919]",
                        children: n.title,
                      })
                    : null,
                  (0, a.jsx)("p", {
                    className: "text-start text-sm leading-[1.55] text-grey-custom",
                    children: n?.review,
                  }),
                ],
              }),
              (0, a.jsxs)(l.CardFooter, {
                className: "flex items-center gap-1.5 rounded-b-none p-0 text-sm",
                children: [
                  n?.name
                    ? (0, a.jsx)("span", { className: "font-semibold text-[#191919]", children: n.name })
                    : null,
                  n?.name && n?.displayLocation
                    ? (0, a.jsx)("span", { className: "text-grey-light", children: "·" })
                    : null,
                  n?.displayLocation
                    ? (0, a.jsx)("span", { className: "text-grey-light", children: n.displayLocation })
                    : null,
                ],
              }),
            ],
          });
        },
      ],
      436306,
    );
  },
  188600,
  function (e) {
    e.n(e.i(436306));
  },
]);
