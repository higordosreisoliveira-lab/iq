(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  677711,
  676346,
  827701,
  (t) => {
    "use strict";
    var e = t.i(271645),
      r = { color: void 0, size: void 0, className: void 0, style: void 0, attr: void 0 },
      n = e.default.createContext && e.default.createContext(r),
      o = ["attr", "size", "title"];
    function l() {
      return (l = Object.assign.bind()).apply(this, arguments);
    }
    function c(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(t);
        (e &&
          (n = n.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, n));
      }
      return r;
    }
    function i(t) {
      for (var e = 1; e < arguments.length; e++) {
        var r = null != arguments[e] ? arguments[e] : {};
        e % 2
          ? c(Object(r), !0).forEach(function (e) {
              var n, o, l;
              ((n = t),
                (o = e),
                (l = r[e]),
                (o = (function (t) {
                  var e = (function (t, e) {
                    if ("object" != typeof t || !t) return t;
                    var r = t[Symbol.toPrimitive];
                    if (void 0 !== r) {
                      var n = r.call(t, e || "default");
                      if ("object" != typeof n) return n;
                      throw TypeError("@@toPrimitive must return a primitive value.");
                    }
                    return ("string" === e ? String : Number)(t);
                  })(t, "string");
                  return "symbol" == typeof e ? e : e + "";
                })(o)) in n
                  ? Object.defineProperty(n, o, { value: l, enumerable: !0, configurable: !0, writable: !0 })
                  : (n[o] = l));
            })
          : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
            : c(Object(r)).forEach(function (e) {
                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(r, e));
              });
      }
      return t;
    }
    function a(t) {
      var c = (r) => {
        var n,
          { attr: c, size: a, title: u } = t,
          s = (function (t, e) {
            if (null == t) return {};
            var r,
              n,
              o = (function (t, e) {
                if (null == t) return {};
                var r = {};
                for (var n in t)
                  if (Object.prototype.hasOwnProperty.call(t, n)) {
                    if (e.indexOf(n) >= 0) continue;
                    r[n] = t[n];
                  }
                return r;
              })(t, e);
            if (Object.getOwnPropertySymbols) {
              var l = Object.getOwnPropertySymbols(t);
              for (n = 0; n < l.length; n++)
                ((r = l[n]),
                  !(e.indexOf(r) >= 0) && Object.prototype.propertyIsEnumerable.call(t, r) && (o[r] = t[r]));
            }
            return o;
          })(t, o),
          f = a || r.size || "1em";
        return (
          r.className && (n = r.className),
          t.className && (n = (n ? n + " " : "") + t.className),
          e.default.createElement(
            "svg",
            l({ stroke: "currentColor", fill: "currentColor", strokeWidth: "0" }, r.attr, c, s, {
              className: n,
              style: i(i({ color: t.color || r.color }, r.style), t.style),
              height: f,
              width: f,
              xmlns: "http://www.w3.org/2000/svg",
            }),
            u && e.default.createElement("title", null, u),
            t.children,
          )
        );
      };
      return void 0 !== n ? e.default.createElement(n.Consumer, null, (t) => c(t)) : c(r);
    }
    t.s(
      [
        "FcGoogle",
        0,
        function (t) {
          var r;
          return ((r = {
            tag: "svg",
            attr: {
              version: "1.1",
              x: "0px",
              y: "0px",
              viewBox: "0 0 48 48",
              enableBackground: "new 0 0 48 48",
            },
            child: [
              {
                tag: "path",
                attr: {
                  fill: "#FFC107",
                  d: "M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12\r\n	c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24\r\n	c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z",
                },
                child: [],
              },
              {
                tag: "path",
                attr: {
                  fill: "#FF3D00",
                  d: "M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657\r\n	C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z",
                },
                child: [],
              },
              {
                tag: "path",
                attr: {
                  fill: "#4CAF50",
                  d: "M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36\r\n	c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z",
                },
                child: [],
              },
              {
                tag: "path",
                attr: {
                  fill: "#1976D2",
                  d: "M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571\r\n	c0.001-0.001,0.002-0.001,0.003-0.002l6.19,5.238C36.971,39.205,44,34,44,24C44,22.659,43.862,21.35,43.611,20.083z",
                },
                child: [],
              },
            ],
          }),
          (t) =>
            e.default.createElement(
              a,
              l({ attr: i({}, r.attr) }, t),
              (function t(r) {
                return (
                  r && r.map((r, n) => e.default.createElement(r.tag, i({ key: n }, r.attr), t(r.child)))
                );
              })(r.child),
            ))(t);
        },
      ],
      677711,
    );
    var u = t.i(106502);
    t.s(["IconMicrosoftLogo", () => u.default], 676346);
    var s = t.i(707945);
    t.s(["IconYandexLogo", () => s.default], 827701);
  },
]);
