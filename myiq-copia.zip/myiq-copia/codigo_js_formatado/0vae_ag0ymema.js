(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  882983,
  (e) => {
    "use strict";
    var t = e.i(265840),
      l = e.i(271645),
      s = e.i(273830),
      r = e.i(620253),
      i = e.i(75540),
      a = e.i(843476),
      o = (0, s.forwardRef)((e, s) => {
        let { as: o, children: n, className: c, ...d } = e,
          { slots: x, classNames: p, bodyId: h, setBodyMounted: u } = (0, t.useModalContext)(),
          f = (0, r.useDOMRef)(s);
        return (
          (0, l.useEffect)(() => (u(!0), () => u(!1)), [u]),
          (0, a.jsx)(o || "div", {
            ref: f,
            className: x.body({ class: (0, i.clsx)(null == p ? void 0 : p.body, c) }),
            id: h,
            ...d,
            children: n,
          })
        );
      });
    ((o.displayName = "HeroUI.ModalBody"), e.s(["ModalBody", 0, o], 882983));
  },
  599869,
  (e) => {
    "use strict";
    var t = e.i(770703),
      l = e.i(896085);
    let s = (0, t.default)(() => e.A(874975), { loadableGenerated: { modules: [358261] } });
    (e.s(["PaywallExitModalComponent", 0, s], 958165),
      e.i(958165),
      e.s(
        ["PAYWALL_EXIT_SHOWN_KEY", () => l.PAYWALL_EXIT_SHOWN_KEY, "PaywallExitModalComponent", 0, s],
        599869,
      ));
  },
  827627,
  function (e) {
    e.n(e.i(599869));
  },
  896085,
  (e) => {
    "use strict";
    var t = e.i(843476);
    let l = (0, e.i(475254).default)("move-right", [
      ["path", { d: "M18 8L22 12L18 16", key: "1r0oui" }],
      ["path", { d: "M2 12H22", key: "1m8cig" }],
    ]);
    var s = e.i(882983),
      r = e.i(742214),
      i = e.i(622963),
      a = e.i(86596);
    e.i(568267);
    var o = e.i(154692);
    e.i(80460);
    var n = e.i(998198);
    e.s(
      [
        "PAYWALL_EXIT_SHOWN_KEY",
        0,
        "paywall_exit_shown",
        "default",
        0,
        () => {
          let e = (0, i.useModalStore)((e) => e.modalProps),
            c = (0, i.useModalStore)((e) => e.handleChangeModalStore),
            d = (0, a.useUserStore)((e) => e.user);
          if (!e) return null;
          let {
              experiments: x,
              isMarketingSource: p,
              variant: h = "myiq",
              friendEncodedData: u,
              demoPriceDefault: f,
              demoPricePrev: m,
            } = e,
            y = (0, n.getCalculatePriceForView)(m, d),
            j =
              x?.abMyiqPromoPrice === "promo_price" && p
                ? (0, n.getCalculatePriceForView)(f, d)
                : d?.paymentInfo?.paynextAmountToPay || (0, n.getCalculatePriceForView)(f, d),
            b = (0, n.getSale)(m, f, !0);
          return (0, t.jsx)(r.ModalContent, {
            children: (0, t.jsx)(s.ModalBody, {
              className: "p-0",
              children: (0, t.jsxs)("div", {
                className: "relative px-6 pb-6 pt-4",
                children: [
                  (0, t.jsxs)("div", {
                    className: "relative mb-2 flex h-[130px] items-end justify-center",
                    children: [
                      (0, t.jsxs)("div", {
                        className:
                          "absolute right-5 top-1 rotate-[4deg] rounded-[14px] bg-blue-50 px-[14px] py-2 text-[13px] font-bold text-[#0A1B5E]",
                        children: [
                          "Wait!",
                          (0, t.jsx)("span", {
                            className:
                              "absolute -bottom-[6px] left-4 h-0 w-0 border-l-[6px] border-r-[6px] border-t-[8px] border-l-transparent border-r-transparent border-t-blue-50",
                          }),
                        ],
                      }),
                      (0, t.jsxs)("svg", {
                        viewBox: "0 0 140 130",
                        width: "140",
                        height: "130",
                        "aria-hidden": "true",
                        children: [
                          (0, t.jsx)("ellipse", {
                            cx: "70",
                            cy: "124",
                            rx: "38",
                            ry: "4",
                            fill: "#0A1B5E",
                            opacity: "0.1",
                          }),
                          (0, t.jsx)("path", {
                            d: "M40 50c-12 0-20 10-20 22s8 22 20 22c4 0 8-1 11-3v-38c-3-2-7-3-11-3z",
                            fill: "#C7BAFF",
                          }),
                          (0, t.jsx)("path", {
                            d: "M100 50c12 0 20 10 20 22s-8 22-20 22c-4 0-8-1-11-3v-38c3-2 7-3 11-3z",
                            fill: "#C7BAFF",
                          }),
                          (0, t.jsx)("ellipse", { cx: "70", cy: "60", rx: "35", ry: "22", fill: "#A78BFA" }),
                          (0, t.jsx)("ellipse", { cx: "70", cy: "64", rx: "38", ry: "24", fill: "#5C3DFF" }),
                          (0, t.jsx)("path", {
                            d: "M50 56q6-6 14 0q6-6 14 0q6-6 14 0",
                            stroke: "#4A2EE6",
                            strokeWidth: "2.5",
                            fill: "none",
                            strokeLinecap: "round",
                          }),
                          (0, t.jsx)("path", {
                            d: "M48 70q6-6 14 0q6-6 14 0q6-6 14 0",
                            stroke: "#4A2EE6",
                            strokeWidth: "2.5",
                            fill: "none",
                            strokeLinecap: "round",
                          }),
                          (0, t.jsx)("path", {
                            d: "M52 84q6-5 14 0q6-5 14 0",
                            stroke: "#4A2EE6",
                            strokeWidth: "2.5",
                            fill: "none",
                            strokeLinecap: "round",
                          }),
                          (0, t.jsx)("circle", { cx: "58", cy: "72", r: "6", fill: "#fff" }),
                          (0, t.jsx)("circle", { cx: "82", cy: "72", r: "6", fill: "#fff" }),
                          (0, t.jsx)("circle", { cx: "59", cy: "73", r: "3", fill: "#0A1B5E" }),
                          (0, t.jsx)("circle", { cx: "83", cy: "73", r: "3", fill: "#0A1B5E" }),
                          (0, t.jsx)("circle", { cx: "60", cy: "72", r: "1", fill: "#fff" }),
                          (0, t.jsx)("circle", { cx: "84", cy: "72", r: "1", fill: "#fff" }),
                          (0, t.jsx)("path", {
                            d: "M62 86q8 6 16 0",
                            stroke: "#0A1B5E",
                            strokeWidth: "2.5",
                            fill: "none",
                            strokeLinecap: "round",
                          }),
                          (0, t.jsx)("circle", { cx: "118", cy: "56", r: "7", fill: "#C7BAFF" }),
                          (0, t.jsx)("path", {
                            d: "M100 70q10-6 18-14",
                            stroke: "#C7BAFF",
                            strokeWidth: "9",
                            strokeLinecap: "round",
                            fill: "none",
                          }),
                          (0, t.jsxs)("g", {
                            fill: "#FFD43B",
                            children: [
                              (0, t.jsx)("path", { d: "M14 30l1.5 4 4 1.5-4 1.5-1.5 4-1.5-4-4-1.5 4-1.5z" }),
                              (0, t.jsx)("path", { d: "M126 100l1 3 3 1-3 1-1 3-1-3-3-1 3-1z" }),
                            ],
                          }),
                        ],
                      }),
                    ],
                  }),
                  (0, t.jsxs)("div", {
                    className: "mb-4 text-center",
                    children: [
                      (0, t.jsx)("h2", {
                        className:
                          "mb-2 text-[22px] font-extrabold leading-tight tracking-[-0.4px] text-gray-900",
                        children: "Don't go yet!",
                      }),
                      (0, t.jsxs)("p", {
                        className: "text-sm text-default-600",
                        children: [
                          "I unlocked a special ",
                          (0, t.jsxs)("strong", {
                            className: "text-primary",
                            children: ["-", b, "% discount"],
                          }),
                          " just for you. It's only good for the next few minutes.",
                        ],
                      }),
                    ],
                  }),
                  (0, t.jsxs)("div", {
                    className:
                      "mb-4 flex items-center justify-center gap-3 rounded-xl border border-blue-100 bg-blue-50 px-3 py-2.5",
                    children: [
                      (0, t.jsx)("span", {
                        className: "text-base text-grey-light line-through",
                        children: y,
                      }),
                      (0, t.jsx)(l, { className: "text-primary", size: 20 }),
                      (0, t.jsx)("span", {
                        className: "text-[22px] font-semibold text-gray-900",
                        children: j,
                      }),
                    ],
                  }),
                  (0, t.jsxs)(o.ButtonComponent, {
                    onClick: () => {
                      c({
                        modalComponent: "checkout-payment",
                        isModalVisible: !0,
                        modalProps: {
                          experiments: x,
                          isMarketingSource: p,
                          variant: h,
                          friendEncodedData: u,
                          demoPriceDefault: f,
                          demoPricePrev: m,
                        },
                      });
                    },
                    fullWidth: !0,
                    className: "mb-2 !h-auto py-[14px]",
                    children: ["Yes, I want ", b, " off!"],
                  }),
                  (0, t.jsx)(o.ButtonComponent, {
                    onClick: () => {
                      c({ isModalVisible: !1, modalComponent: null });
                    },
                    variant: "default",
                    fullWidth: !0,
                    className:
                      "border-none !bg-transparent py-2.5 text-[13px] text-grey-light transition-colors hover:text-gray-900",
                    children: "No thanks",
                  }),
                ],
              }),
            }),
          });
        },
      ],
      896085,
    );
  },
  874975,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/1wwhonstjpw_a.js"].map((t) => e.l(t))).then(() => t(358261)));
  },
]);
