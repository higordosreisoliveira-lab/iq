(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  584735,
  871363,
  559745,
  856564,
  143674,
  (e) => {
    "use strict";
    var r,
      a = e.i(843476);
    function t(e) {
      let { isSelected: r, disableAnimation: t, ...n } = e;
      return (0, a.jsx)("svg", {
        "aria-hidden": "true",
        fill: "none",
        role: "presentation",
        stroke: "currentColor",
        strokeDasharray: 22,
        strokeDashoffset: r ? 44 : 66,
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 2,
        style: !t && r ? { transition: "stroke-dashoffset 250ms linear 0.2s" } : {},
        viewBox: "0 0 17 18",
        ...n,
        children: (0, a.jsx)("polyline", { points: "1 9 7 14 15 4" }),
      });
    }
    function n(e) {
      let { isSelected: r, disableAnimation: t, ...n } = e;
      return (0, a.jsx)("svg", {
        stroke: "currentColor",
        strokeWidth: 3,
        viewBox: "0 0 24 24",
        ...n,
        children: (0, a.jsx)("line", { x1: "21", x2: "3", y1: "12", y2: "12" }),
      });
    }
    function i(e) {
      let { isIndeterminate: r, ...i } = e;
      return (0, a.jsx)(r ? n : t, { ...i });
    }
    var [o, l] = (0, e.i(526823).createContext)({ name: "CheckboxGroupContext", strict: !1 });
    e.s(["CheckboxGroupProvider", 0, o, "useCheckboxGroupContext", 0, l], 871363);
    var s = e.i(595494),
      d = e.i(271645),
      u = e.i(335190);
    function c() {
      var e;
      let r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
        { isReadOnly: a } = r,
        [t, n] = (0, u.useControlledState)(r.isSelected, r.defaultSelected || !1, r.onChange),
        [i] = (0, d.useState)(t);
      return {
        isSelected: t,
        defaultSelected: null != (e = r.defaultSelected) ? e : i,
        setSelected: function (e) {
          a || n(e);
        },
        toggle: function () {
          a || n(!t);
        },
      };
    }
    var f = e.i(984898),
      v = e.i(779754),
      p = (0, f.tv)({
        slots: {
          base: "group relative max-w-fit inline-flex items-center justify-start cursor-pointer tap-highlight-transparent p-2 -m-2 select-none",
          wrapper: [
            "relative",
            "inline-flex",
            "items-center",
            "justify-center",
            "shrink-0",
            "overflow-hidden",
            "before:content-['']",
            "before:absolute",
            "before:inset-0",
            "before:border-solid",
            "before:border-2",
            "before:box-border",
            "before:border-default",
            "after:content-['']",
            "after:absolute",
            "after:inset-0",
            "after:scale-50",
            "after:opacity-0",
            "after:origin-center",
            "group-data-[selected=true]:after:scale-100",
            "group-data-[selected=true]:after:opacity-100",
            "group-data-[hover=true]:before:bg-default-100",
            ...v.groupDataFocusVisibleClasses,
          ],
          hiddenInput: v.hiddenInputClasses,
          icon: "z-10 w-4 h-3 opacity-0 group-data-[selected=true]:opacity-100 pointer-events-none",
          label: "relative text-foreground select-none",
        },
        variants: {
          color: {
            default: { wrapper: "after:bg-default after:text-default-foreground text-default-foreground" },
            primary: { wrapper: "after:bg-primary after:text-primary-foreground text-primary-foreground" },
            secondary: {
              wrapper: "after:bg-secondary after:text-secondary-foreground text-secondary-foreground",
            },
            success: { wrapper: "after:bg-success after:text-success-foreground text-success-foreground" },
            warning: { wrapper: "after:bg-warning after:text-warning-foreground text-warning-foreground" },
            danger: { wrapper: "after:bg-danger after:text-danger-foreground text-danger-foreground" },
          },
          size: {
            sm: {
              wrapper: [
                "w-4 h-4 me-2",
                "rounded-[calc(var(--heroui-radius-medium)*0.5)]",
                "before:rounded-[calc(var(--heroui-radius-medium)*0.5)]",
                "after:rounded-[calc(var(--heroui-radius-medium)*0.5)]",
              ],
              label: "text-small",
              icon: "w-3 h-2",
            },
            md: {
              wrapper: [
                "w-5 h-5 me-2",
                "rounded-[calc(var(--heroui-radius-medium)*0.6)]",
                "before:rounded-[calc(var(--heroui-radius-medium)*0.6)]",
                "after:rounded-[calc(var(--heroui-radius-medium)*0.6)]",
              ],
              label: "text-medium",
              icon: "w-4 h-3",
            },
            lg: {
              wrapper: [
                "w-6 h-6 me-2",
                "rounded-[calc(var(--heroui-radius-medium)*0.7)]",
                "before:rounded-[calc(var(--heroui-radius-medium)*0.7)]",
                "after:rounded-[calc(var(--heroui-radius-medium)*0.7)]",
              ],
              label: "text-large",
              icon: "w-5 h-4",
            },
          },
          radius: {
            none: { wrapper: "rounded-none before:rounded-none after:rounded-none" },
            sm: {
              wrapper: [
                "rounded-[calc(var(--heroui-radius-medium)*0.5)]",
                "before:rounded-[calc(var(--heroui-radius-medium)*0.5)]",
                "after:rounded-[calc(var(--heroui-radius-medium)*0.5)]",
              ],
            },
            md: {
              wrapper: [
                "rounded-[calc(var(--heroui-radius-medium)*0.6)]",
                "before:rounded-[calc(var(--heroui-radius-medium)*0.6)]",
                "after:rounded-[calc(var(--heroui-radius-medium)*0.6)]",
              ],
            },
            lg: {
              wrapper: [
                "rounded-[calc(var(--heroui-radius-medium)*0.7)]",
                "before:rounded-[calc(var(--heroui-radius-medium)*0.7)]",
                "after:rounded-[calc(var(--heroui-radius-medium)*0.7)]",
              ],
            },
            full: { wrapper: "rounded-full before:rounded-full after:rounded-full" },
          },
          lineThrough: {
            true: {
              label: [
                "inline-flex",
                "items-center",
                "justify-center",
                "before:content-['']",
                "before:absolute",
                "before:bg-foreground",
                "before:w-0",
                "before:h-0.5",
                "group-data-[selected=true]:opacity-60",
                "group-data-[selected=true]:before:w-full",
              ],
            },
          },
          isDisabled: { true: { base: "opacity-disabled pointer-events-none" } },
          isInvalid: { true: { wrapper: "before:border-danger", label: "text-danger" } },
          disableAnimation: {
            true: { wrapper: "transition-none", icon: "transition-none", label: "transition-none" },
            false: {
              wrapper: [
                "before:transition-colors",
                "group-data-[pressed=true]:scale-95",
                "transition-transform",
                "after:transition-transform-opacity",
                "after:!ease-linear",
                "after:!duration-200",
                "motion-reduce:transition-none",
              ],
              icon: "transition-opacity motion-reduce:transition-none",
              label: "transition-colors-opacity before:transition-width motion-reduce:transition-none",
            },
          },
        },
        defaultVariants: { color: "primary", size: "md", isDisabled: !1, lineThrough: !1 },
      }),
      h = (0, f.tv)({
        slots: {
          base: "relative flex flex-col gap-2",
          label: "relative text-medium text-foreground-500",
          wrapper: "flex flex-col flex-wrap gap-2 data-[orientation=horizontal]:flex-row",
          description: "text-small text-foreground-400",
          errorMessage: "text-small text-danger",
        },
        variants: {
          isRequired: { true: { label: "after:content-['*'] after:text-danger after:ml-0.5" } },
          isInvalid: { true: { description: "text-danger" } },
          disableAnimation: {
            true: {},
            false: { description: "transition-colors !duration-150 motion-reduce:transition-none" },
          },
        },
        defaultVariants: { isInvalid: !1, isRequired: !1 },
      });
    e.s(["checkbox", 0, p, "checkboxGroup", 0, h], 559745);
    var b = e.i(355483),
      m = e.i(371330),
      g = e.i(429427),
      y = e.i(75540);
    ("u" > typeof document && d.default.useLayoutEffect,
      d.default.useInsertionEffect,
      e.i(454453),
      "u" > typeof window && window.document && window.document.createElement);
    let w = new Map();
    "u" > typeof FinalizationRegistry &&
      new FinalizationRegistry((e) => {
        w.delete(e);
      });
    var x = e.i(207670);
    function C() {
      for (var e = arguments.length, r = Array(e), a = 0; a < e; a++) r[a] = arguments[a];
      let t = { ...r[0] };
      for (let e = 1; e < r.length; e++) {
        let a = r[e];
        for (let e in a) {
          let r = t[e],
            n = a[e];
          "function" == typeof r &&
          "function" == typeof n &&
          "o" === e[0] &&
          "n" === e[1] &&
          e.charCodeAt(2) >= 65 &&
          90 >= e.charCodeAt(2)
            ? (t[e] = (function () {
                for (var e = arguments.length, r = Array(e), a = 0; a < e; a++) r[a] = arguments[a];
                return function () {
                  for (var e = arguments.length, a = Array(e), t = 0; t < e; t++) a[t] = arguments[t];
                  for (let e of r) "function" == typeof e && e(...a);
                };
              })(r, n))
            : ("className" === e || "UNSAFE_className" === e) && "string" == typeof r && "string" == typeof n
              ? (t[e] = (0, x.default)(r, n))
              : "id" === e && r && n
                ? (t.id = (function (e, r) {
                    if (e === r) return e;
                    let a = w.get(e);
                    if (a) return (a.forEach((e) => (e.current = r)), r);
                    let t = w.get(r);
                    return t ? (t.forEach((r) => (r.current = e)), e) : r;
                  })(r, n))
                : (t[e] = void 0 !== n ? n : r);
        }
      }
      return t;
    }
    e.s(["mergeProps", 0, C], 856564);
    var P = e.i(475695),
      S = e.i(148774),
      k = e.i(343027);
    let R = "u" > typeof document ? d.default.useLayoutEffect : () => {},
      A = null != (r = d.default.useInsertionEffect) ? r : R;
    "u" > typeof window && window.document && window.document.createElement;
    let E = new Map();
    function D() {
      for (var e = arguments.length, r = Array(e), a = 0; a < e; a++) r[a] = arguments[a];
      let t = { ...r[0] };
      for (let e = 1; e < r.length; e++) {
        let a = r[e];
        for (let e in a) {
          let r = t[e],
            n = a[e];
          "function" == typeof r &&
          "function" == typeof n &&
          "o" === e[0] &&
          "n" === e[1] &&
          e.charCodeAt(2) >= 65 &&
          90 >= e.charCodeAt(2)
            ? (t[e] = (function () {
                for (var e = arguments.length, r = Array(e), a = 0; a < e; a++) r[a] = arguments[a];
                return function () {
                  for (var e = arguments.length, a = Array(e), t = 0; t < e; t++) a[t] = arguments[t];
                  for (let e of r) "function" == typeof e && e(...a);
                };
              })(r, n))
            : ("className" === e || "UNSAFE_className" === e) && "string" == typeof r && "string" == typeof n
              ? (t[e] = (0, x.default)(r, n))
              : "id" === e && r && n
                ? (t.id = (function (e, r) {
                    if (e === r) return e;
                    let a = E.get(e);
                    if (a) return (a.forEach((e) => (e.current = r)), r);
                    let t = E.get(r);
                    return t ? (t.forEach((r) => (r.current = e)), e) : r;
                  })(r, n))
                : (t[e] = void 0 !== n ? n : r);
        }
      }
      return t;
    }
    "u" > typeof FinalizationRegistry &&
      new FinalizationRegistry((e) => {
        E.delete(e);
      });
    let I = new Set(["id"]),
      V = new Set(["aria-label", "aria-labelledby", "aria-describedby", "aria-details"]),
      O = new Set(["href", "hrefLang", "target", "rel", "download", "ping", "referrerPolicy"]),
      T = new Set(["dir", "lang", "hidden", "inert", "translate"]),
      M = new Set([
        "onClick",
        "onAuxClick",
        "onContextMenu",
        "onDoubleClick",
        "onMouseDown",
        "onMouseEnter",
        "onMouseLeave",
        "onMouseMove",
        "onMouseOut",
        "onMouseOver",
        "onMouseUp",
        "onTouchCancel",
        "onTouchEnd",
        "onTouchMove",
        "onTouchStart",
        "onPointerDown",
        "onPointerMove",
        "onPointerUp",
        "onPointerCancel",
        "onPointerEnter",
        "onPointerLeave",
        "onPointerOver",
        "onPointerOut",
        "onGotPointerCapture",
        "onLostPointerCapture",
        "onScroll",
        "onWheel",
        "onAnimationStart",
        "onAnimationEnd",
        "onAnimationIteration",
        "onTransitionCancel",
        "onTransitionEnd",
        "onTransitionRun",
        "onTransitionStart",
      ]),
      L = /^(data-.*)$/;
    var j = e.i(849962);
    function F(e, r, a) {
      let t = (0, P.useFormValidationState)({ ...e, value: r.isSelected }),
        { isInvalid: n, validationErrors: i, validationDetails: o } = t.displayValidation,
        {
          labelProps: l,
          inputProps: s,
          isSelected: u,
          isPressed: c,
          isDisabled: f,
          isReadOnly: v,
        } = (function (e, r, a) {
          var t, n, i;
          let o,
            l,
            {
              isDisabled: s = !1,
              isReadOnly: u = !1,
              value: c,
              name: f,
              form: v,
              children: p,
              "aria-label": h,
              "aria-labelledby": b,
              validationState: m = "valid",
              isInvalid: g,
              onPressStart: y,
              onPressEnd: w,
              onPressChange: x,
              onPress: C,
              onPressUp: P,
              onClick: S,
            } = e,
            { pressProps: R, isPressed: E } = (0, k.usePress)({
              onPressStart: y,
              onPressEnd: w,
              onPressChange: x,
              onPress: C,
              onPressUp: P,
              onClick: S,
              isDisabled: s,
            }),
            { pressProps: F, isPressed: N } = (0, k.usePress)({
              onPressStart: y,
              onPressEnd: w,
              onPressChange: x,
              onPressUp: P,
              onClick: S,
              onPress(e) {
                var t;
                (null == C || C(e), r.toggle(), null == (t = a.current) || t.focus());
              },
              isDisabled: s || u,
            }),
            { focusableProps: U } = (0, j.useFocusable)(e, a),
            B = D(R, U),
            z = (function (e) {
              let r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                { labelable: a, isLink: t, global: n, events: i = n, propNames: o } = r,
                l = {};
              for (let r in e)
                Object.prototype.hasOwnProperty.call(e, r) &&
                  (I.has(r) ||
                    (a && V.has(r)) ||
                    (t && O.has(r)) ||
                    (n && T.has(r)) ||
                    (i && M.has(r)) ||
                    (r.endsWith("Capture") && M.has(r.slice(0, -7))) ||
                    (null == o ? void 0 : o.has(r)) ||
                    L.test(r)) &&
                  (l[r] = e[r]);
              return l;
            })(e, { labelable: !0 });
          return (
            (t = r.defaultSelected),
            (n = r.setSelected),
            (i = () => {
              n && n(t);
            }),
            (o = (0, d.useRef)(null)),
            A(() => {
              o.current = i;
            }, [i]),
            (l = (0, d.useCallback)(function () {
              for (var e = arguments.length, r = Array(e), a = 0; a < e; a++) r[a] = arguments[a];
              let t = o.current;
              return null == t ? void 0 : t(...r);
            }, [])),
            (0, d.useEffect)(() => {
              var e;
              let r = null == a || null == (e = a.current) ? void 0 : e.form;
              return (
                null == r || r.addEventListener("reset", l),
                () => {
                  null == r || r.removeEventListener("reset", l);
                }
              );
            }, [a, l]),
            {
              labelProps: D(F, { onClick: (e) => e.preventDefault() }),
              inputProps: D(z, {
                "aria-invalid": g || "invalid" === m || void 0,
                "aria-errormessage": e["aria-errormessage"],
                "aria-controls": e["aria-controls"],
                "aria-readonly": u || void 0,
                onChange: (e) => {
                  (e.stopPropagation(), r.setSelected(e.target.checked));
                },
                disabled: s,
                ...(null == c ? {} : { value: c }),
                name: f,
                form: v,
                type: "checkbox",
                ...B,
              }),
              isSelected: r.isSelected,
              isPressed: E || N,
              isDisabled: s,
              isReadOnly: u,
              isInvalid: g || "invalid" === m,
            }
          );
        })({ ...e, isInvalid: n }, r, a);
      (0, S.useFormValidation)(e, t, a);
      let { isIndeterminate: p, isRequired: h, validationBehavior: b = "aria" } = e;
      (0, d.useEffect)(() => {
        a.current && (a.current.indeterminate = !!p);
      });
      let { pressProps: m } = (0, k.usePress)({
        isDisabled: f || v,
        onPress() {
          let { [P.privateValidationStateProp]: r } = e,
            { commitValidation: a } = r || t;
          a();
        },
      });
      return {
        labelProps: C(
          l,
          m,
          (0, d.useMemo)(() => ({ onMouseDown: (e) => e.preventDefault() }), []),
        ),
        inputProps: {
          ...s,
          checked: u,
          "aria-required": (h && "aria" === b) || void 0,
          required: h && "native" === b,
        },
        isSelected: u,
        isPressed: c,
        isDisabled: f,
        isReadOnly: v,
        isInvalid: n,
        validationErrors: i,
        validationDetails: o,
      };
    }
    let N = new WeakMap();
    e.s(["checkboxGroupData", 0, N], 143674);
    var U = e.i(655483),
      B = e.i(460849),
      z = e.i(415944),
      G = e.i(713934),
      q = (0, e.i(273830).forwardRef)((e, r) => {
        let {
            Component: t,
            children: n,
            icon: o = (0, a.jsx)(i, {}),
            getBaseProps: u,
            getWrapperProps: f,
            getInputProps: v,
            getIconProps: h,
            getLabelProps: w,
          } = (function () {
            var e, r, a, t, n, i, o, u;
            let f = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
              v = (0, s.useProviderContext)(),
              h = l(),
              { validationBehavior: w } = (0, G.useSlottedContext)(z.FormContext) || {},
              x = !!h,
              {
                as: C,
                ref: S,
                value: k = "",
                children: R,
                icon: A,
                name: E,
                isRequired: D,
                isReadOnly: I = !1,
                autoFocus: V = !1,
                isSelected: O,
                size: T = null != (e = null == h ? void 0 : h.size) ? e : "md",
                color: M = null != (r = null == h ? void 0 : h.color) ? r : "primary",
                radius: L = null == h ? void 0 : h.radius,
                lineThrough: j = null != (a = null == h ? void 0 : h.lineThrough) && a,
                isDisabled: q = null != (t = null == h ? void 0 : h.isDisabled) && t,
                disableAnimation: _ = null !=
                  (i =
                    null != (n = null == h ? void 0 : h.disableAnimation)
                      ? n
                      : null == v
                        ? void 0
                        : v.disableAnimation) && i,
                validationState: W,
                isInvalid: H = W ? "invalid" === W : null != (o = null == h ? void 0 : h.isInvalid) && o,
                isIndeterminate: $ = !1,
                validationBehavior: K = x
                  ? h.validationBehavior
                  : null != (u = null != w ? w : null == v ? void 0 : v.validationBehavior)
                    ? u
                    : "native",
                defaultSelected: J,
                classNames: Q,
                className: X,
                onValueChange: Y,
                validate: Z,
                ...ee
              } = f;
            h &&
              y.__DEV__ &&
              (O &&
                (0, y.warn)(
                  "The Checkbox.Group is being used, `isSelected` will be ignored. Use the `value` of the Checkbox.Group instead.",
                  "Checkbox",
                ),
              J &&
                (0, y.warn)(
                  "The Checkbox.Group is being used, `defaultSelected` will be ignored. Use the `defaultValue` of the Checkbox.Group instead.",
                  "Checkbox",
                ));
            let er = (0, d.useRef)(null),
              ea = (0, d.useRef)(null),
              et = f.onChange;
            x &&
              (et = (0, y.chain)(() => {
                h.groupState.resetValidation();
              }, et));
            let en = (0, d.useId)(),
              ei = (0, d.useMemo)(
                () => ({
                  name: E,
                  value: k,
                  children: R,
                  autoFocus: V,
                  defaultSelected: J,
                  isIndeterminate: $,
                  isRequired: D,
                  isInvalid: H,
                  isSelected: O,
                  isDisabled: q,
                  isReadOnly: I,
                  "aria-label": (0, y.safeAriaLabel)(ee["aria-label"], R),
                  "aria-labelledby": ee["aria-labelledby"] || en,
                  onChange: Y,
                }),
                [E, k, R, V, J, $, D, H, O, q, I, ee["aria-label"], ee["aria-labelledby"], en, Y],
              ),
              eo = c(ei),
              el = { isInvalid: H, isRequired: D, validate: Z, validationState: W, validationBehavior: K },
              {
                inputProps: es,
                isSelected: ed,
                isDisabled: eu,
                isReadOnly: ec,
                isPressed: ef,
                isInvalid: ev,
              } = x
                ? (function (e, r, a) {
                    var t, n;
                    let i = c({
                        isReadOnly: e.isReadOnly || r.isReadOnly,
                        isSelected: r.isSelected(e.value),
                        defaultSelected: r.defaultValue.includes(e.value),
                        onChange(a) {
                          (a ? r.addValue(e.value) : r.removeValue(e.value), e.onChange && e.onChange(a));
                        },
                      }),
                      {
                        name: o,
                        form: l,
                        descriptionId: s,
                        errorMessageId: u,
                        validationBehavior: f,
                      } = N.get(r);
                    f = null != (t = e.validationBehavior) ? t : f;
                    let { realtimeValidation: v } = (0, P.useFormValidationState)({
                        ...e,
                        value: i.isSelected,
                        name: void 0,
                        validationBehavior: "aria",
                      }),
                      p = (0, d.useRef)(P.DEFAULT_VALIDATION_RESULT),
                      h = () => {
                        r.setInvalid(e.value, v.isInvalid ? v : p.current);
                      };
                    (0, d.useEffect)(h);
                    let b = r.realtimeValidation.isInvalid ? r.realtimeValidation : v,
                      m = "native" === f ? r.displayValidation : b,
                      g = F(
                        {
                          ...e,
                          isReadOnly: e.isReadOnly || r.isReadOnly,
                          isDisabled: e.isDisabled || r.isDisabled,
                          name: e.name || o,
                          form: e.form || l,
                          isRequired: null != (n = e.isRequired) ? n : r.isRequired,
                          validationBehavior: f,
                          [P.privateValidationStateProp]: {
                            realtimeValidation: b,
                            displayValidation: m,
                            resetValidation: r.resetValidation,
                            commitValidation: r.commitValidation,
                            updateValidation(e) {
                              ((p.current = e), h());
                            },
                          },
                        },
                        i,
                        a,
                      );
                    return {
                      ...g,
                      inputProps: {
                        ...g.inputProps,
                        "aria-describedby":
                          [e["aria-describedby"], r.isInvalid ? u : null, s].filter(Boolean).join(" ") ||
                          void 0,
                      },
                    };
                  })({ ...ei, ...el }, h.groupState, ea)
                : F({ ...ei, ...el }, eo, ea),
              ep = "invalid" === W || H || ev,
              eh = !(eu || ec) && ef,
              { hoverProps: eb, isHovered: em } = (0, m.useHover)({ isDisabled: es.disabled }),
              {
                focusProps: eg,
                isFocused: ey,
                isFocusVisible: ew,
              } = (0, g.useFocusRing)({ autoFocus: es.autoFocus }),
              ex = (0, d.useMemo)(
                () =>
                  p({
                    color: M,
                    size: T,
                    radius: L,
                    isInvalid: ep,
                    lineThrough: j,
                    isDisabled: eu,
                    disableAnimation: _,
                  }),
                [M, T, L, ep, j, eu, _],
              );
            (0, U.useSafeLayoutEffect)(() => {
              if (!ea.current) return;
              let e = !!ea.current.checked;
              eo.setSelected(e);
            }, [ea.current]);
            let eC = (0, b.useCallbackRef)(et),
              eP = (0, d.useCallback)(
                (e) => {
                  ec || eu ? e.preventDefault() : null == eC || eC(e);
                },
                [ec, eu, eC],
              ),
              eS = (0, y.clsx)(null == Q ? void 0 : Q.base, X),
              ek = (0, d.useCallback)(
                () => ({
                  ref: er,
                  className: ex.base({ class: eS }),
                  "data-disabled": (0, y.dataAttr)(eu),
                  "data-selected": (0, y.dataAttr)(ed || $),
                  "data-invalid": (0, y.dataAttr)(ep),
                  "data-hover": (0, y.dataAttr)(em),
                  "data-focus": (0, y.dataAttr)(ey),
                  "data-pressed": (0, y.dataAttr)(eh),
                  "data-readonly": (0, y.dataAttr)(es.readOnly),
                  "data-focus-visible": (0, y.dataAttr)(ew),
                  "data-indeterminate": (0, y.dataAttr)($),
                  ...(0, y.mergeProps)(eb, ee),
                }),
                [ex, eS, eu, ed, $, ep, em, ey, eh, es.readOnly, ew, eb, ee],
              ),
              eR = (0, d.useCallback)(
                function () {
                  let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                  return {
                    ...e,
                    "aria-hidden": !0,
                    className: (0, y.clsx)(
                      ex.wrapper({
                        class: (0, y.clsx)(null == Q ? void 0 : Q.wrapper, null == e ? void 0 : e.className),
                      }),
                    ),
                  };
                },
                [ex, null == Q ? void 0 : Q.wrapper],
              ),
              eA = (0, d.useCallback)(
                () => ({
                  ref: (0, B.mergeRefs)(ea, S),
                  ...(0, y.mergeProps)(es, eg),
                  className: ex.hiddenInput({ class: null == Q ? void 0 : Q.hiddenInput }),
                  onChange: (0, y.chain)(es.onChange, eP),
                }),
                [es, eg, eP, null == Q ? void 0 : Q.hiddenInput],
              ),
              eE = (0, d.useCallback)(
                () => ({ id: en, className: ex.label({ class: null == Q ? void 0 : Q.label }) }),
                [ex, null == Q ? void 0 : Q.label, eu, ed, ep],
              ),
              eD = (0, d.useCallback)(
                () => ({
                  isSelected: ed,
                  isIndeterminate: $,
                  disableAnimation: _,
                  className: ex.icon({ class: null == Q ? void 0 : Q.icon }),
                }),
                [ex, null == Q ? void 0 : Q.icon, ed, $, _],
              );
            return {
              Component: C || "label",
              icon: A,
              children: R,
              isSelected: ed,
              isDisabled: eu,
              isInvalid: ep,
              isFocused: ey,
              isHovered: em,
              isFocusVisible: ew,
              getBaseProps: ek,
              getWrapperProps: eR,
              getInputProps: eA,
              getLabelProps: eE,
              getIconProps: eD,
            };
          })({ ...e, ref: r }),
          x = "function" == typeof o ? o(h()) : (0, d.cloneElement)(o, h());
        return (0, a.jsxs)(t, {
          ...u(),
          children: [
            (0, a.jsx)("input", { ...v() }),
            (0, a.jsx)("span", { ...f(), children: x }),
            n && (0, a.jsx)("span", { ...w(), children: n }),
          ],
        });
      });
    ((q.displayName = "HeroUI.Checkbox"), e.s(["Checkbox", 0, q], 584735));
  },
  714060,
  (e) => {
    "use strict";
    var r = e.i(919477),
      a = (0, e.i(984898).tv)({
        base: "shrink-0 bg-divider border-none",
        variants: { orientation: { horizontal: "w-full h-divider", vertical: "h-full w-divider" } },
        defaultVariants: { orientation: "horizontal" },
      }),
      t = e.i(271645),
      n = e.i(273830),
      i = e.i(843476),
      o = (0, n.forwardRef)((e, n) => {
        let { Component: o, getDividerProps: l } = (function (e) {
          var n;
          let i,
            o,
            { as: l, className: s, orientation: d, ...u } = e,
            c = l || "hr";
          "hr" === c && "vertical" === d && (c = "div");
          let { separatorProps: f } =
              ((n = { elementType: "string" == typeof c ? c : "hr", orientation: d }),
              (o = (0, r.filterDOMProps)(n, { enabled: "string" == typeof n.elementType })),
              ("vertical" === n.orientation && (i = "vertical"), "hr" !== n.elementType)
                ? { separatorProps: { ...o, role: "separator", "aria-orientation": i } }
                : { separatorProps: o }),
            v = (0, t.useMemo)(() => a({ orientation: d, className: s }), [d, s]);
          return {
            Component: c,
            getDividerProps: (0, t.useCallback)(
              function () {
                let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return { className: v, role: "separator", "data-orientation": d, ...f, ...u, ...e };
              },
              [v, d, f, u],
            ),
          };
        })({ ...e });
        return (0, i.jsx)(o, { ref: n, ...l() });
      });
    ((o.displayName = "HeroUI.Divider"), e.s(["Divider", 0, o], 714060));
  },
  460849,
  (e) => {
    "use strict";
    var r = e.i(75540);
    e.s([
      "mergeRefs",
      0,
      function () {
        for (var e = arguments.length, a = Array(e), t = 0; t < e; t++) a[t] = arguments[t];
        return (e) => {
          a.forEach((a) =>
            (function (e, a) {
              if (null != e) {
                if ((0, r.isFunction)(e)) return void e(a);
                try {
                  e.current = a;
                } catch {
                  throw Error(`Cannot assign value '${a}' to ref '${e}'`);
                }
              }
            })(a, e),
          );
        };
      },
    ]);
  },
  355483,
  (e) => {
    "use strict";
    var r = e.i(271645),
      a = e.i(655483);
    e.s([
      "useCallbackRef",
      0,
      function (e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [],
          n = (0, r.useRef)(e);
        return (
          (0, a.useSafeLayoutEffect)(() => {
            n.current = e;
          }),
          (0, r.useCallback)(function () {
            for (var e, r = arguments.length, a = Array(r), t = 0; t < r; t++) a[t] = arguments[t];
            return null == (e = n.current) ? void 0 : e.call(n, ...a);
          }, t)
        );
      },
    ]);
  },
  655483,
  (e) => {
    "use strict";
    var r = e.i(271645),
      a = (null == globalThis ? void 0 : globalThis.document) ? r.useLayoutEffect : r.useEffect;
    e.s(["useSafeLayoutEffect", 0, a]);
  },
]);
