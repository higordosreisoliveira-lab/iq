(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  415944,
  (e) => {
    "use strict";
    var t = e.i(713934),
      a = e.i(475695),
      n = e.i(271645),
      r = (0, e.i(984898).tv)({ base: "flex flex-col gap-2 items-start" }),
      i = e.i(843476),
      l = (0, n.createContext)(null),
      s = (0, n.forwardRef)(function (e, s) {
        [e, s] = (0, t.useContextProps)(e, s, l);
        let { validationErrors: o, validationBehavior: c = "native", children: d, className: u, ...m } = e,
          p = (0, n.useMemo)(() => r({ className: u }), [u]);
        return (0, i.jsx)("form", {
          noValidate: "native" !== c,
          ...m,
          ref: s,
          className: p,
          children: (0, i.jsx)(l.Provider, {
            value: { ...e, validationBehavior: c },
            children: (0, i.jsx)(a.FormValidationContext.Provider, {
              value: null != o ? o : {},
              children: d,
            }),
          }),
        });
      });
    e.s(["Form", 0, s, "FormContext", 0, l], 415944);
  },
  713934,
  (e) => {
    "use strict";
    var t = e.i(271645),
      a = e.i(75540),
      n = Symbol("default");
    function r(e, a) {
      let r = (0, t.useContext)(e);
      if (null === a) return null;
      if (r && "object" == typeof r && "slots" in r && r.slots) {
        let e = new Intl.ListFormat().format(Object.keys(r.slots).map((e) => `"${e}"`));
        if (!a && !r.slots[n]) throw Error(`A slot prop is required. Valid slot names are ${e}.`);
        let t = a || n;
        if (!r.slots[t]) throw Error(`Invalid slot "${a}". Valid slot names are ${e}.`);
        return r.slots[t];
      }
      return r;
    }
    e.s([
      "useContextProps",
      0,
      function (e, n, i) {
        var l;
        let s,
          o,
          c,
          { ref: d, ...u } = r(i, e.slot) || {},
          m =
            ((l = (0, t.useMemo)(() => (0, a.mergeRefs)(n, d), [n, d])),
            (s = (0, t.useRef)(null)),
            (o = (0, t.useRef)(void 0)),
            (c = (0, t.useCallback)(
              (e) => {
                if ("function" == typeof l) {
                  let t = l(e);
                  return () => {
                    "function" == typeof t ? t() : l(null);
                  };
                }
                if (l)
                  return (
                    (l.current = e),
                    () => {
                      l.current = null;
                    }
                  );
              },
              [l],
            )),
            (0, t.useMemo)(
              () => ({
                get current() {
                  return s.current;
                },
                set current(value) {
                  ((s.current = value),
                    o.current && (o.current(), (o.current = void 0)),
                    null != value && (o.current = c(value)));
                },
              }),
              [c],
            )),
          p = (0, a.mergeProps)(u, e);
        return (
          "style" in u &&
            u.style &&
            "style" in e &&
            e.style &&
            ("function" == typeof u.style || "function" == typeof e.style
              ? (p.style = (t) => {
                  let a = "function" == typeof u.style ? u.style(t) : u.style,
                    n = { ...t.defaultStyle, ...a },
                    r = "function" == typeof e.style ? e.style({ ...t, defaultStyle: n }) : e.style;
                  return { ...n, ...r };
                })
              : (p.style = { ...u.style, ...e.style })),
          [p, m]
        );
      },
      "useSlottedContext",
      0,
      r,
    ]);
  },
  475695,
  (e) => {
    "use strict";
    var t = e.i(271645);
    let a = {
        badInput: !1,
        customError: !1,
        patternMismatch: !1,
        rangeOverflow: !1,
        rangeUnderflow: !1,
        stepMismatch: !1,
        tooLong: !1,
        tooShort: !1,
        typeMismatch: !1,
        valueMissing: !1,
        valid: !0,
      },
      n = { ...a, customError: !0, valid: !1 },
      r = { isInvalid: !1, validationDetails: a, validationErrors: [] },
      i = (0, t.createContext)({}),
      l = "__formValidationState" + Date.now();
    function s(e) {
      return e ? (Array.isArray(e) ? e : [e]) : [];
    }
    function o(e) {
      return e.length ? { isInvalid: !0, validationErrors: e, validationDetails: n } : null;
    }
    function c(e, t) {
      return (
        e === t ||
        (!!e &&
          !!t &&
          e.isInvalid === t.isInvalid &&
          e.validationErrors.length === t.validationErrors.length &&
          e.validationErrors.every((e, a) => e === t.validationErrors[a]) &&
          Object.entries(e.validationDetails).every((e) => {
            let [a, n] = e;
            return t.validationDetails[a] === n;
          }))
      );
    }
    e.s([
      "DEFAULT_VALIDATION_RESULT",
      0,
      r,
      "FormValidationContext",
      0,
      i,
      "mergeValidation",
      0,
      function () {
        for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
        let r = new Set(),
          i = !1,
          l = { ...a };
        for (let e of t) {
          for (let t of e.validationErrors) r.add(t);
          for (let t in (i || (i = e.isInvalid), l)) l[t] || (l[t] = e.validationDetails[t]);
        }
        return ((l.valid = !i), { isInvalid: i, validationErrors: [...r], validationDetails: l });
      },
      "privateValidationStateProp",
      0,
      l,
      "useFormValidationState",
      0,
      function (e) {
        if (e[l]) {
          let {
            realtimeValidation: t,
            displayValidation: a,
            updateValidation: n,
            resetValidation: r,
            commitValidation: i,
          } = e[l];
          return {
            realtimeValidation: t,
            displayValidation: a,
            updateValidation: n,
            resetValidation: r,
            commitValidation: i,
          };
        }
        return (function (e) {
          let {
            isInvalid: a,
            validationState: l,
            name: d,
            value: u,
            builtinValidation: m,
            validate: p,
            validationBehavior: h = "aria",
          } = e;
          l && (a || (a = "invalid" === l));
          let v = void 0 !== a ? { isInvalid: a, validationErrors: [], validationDetails: n } : null,
            g = (0, t.useMemo)(
              () =>
                p && null != u
                  ? o(
                      (function (e, t) {
                        if ("function" == typeof e) {
                          let a = e(t);
                          if (a && "boolean" != typeof a) return s(a);
                        }
                        return [];
                      })(p, u),
                    )
                  : null,
              [p, u],
            );
          (null == m ? void 0 : m.validationDetails.valid) && (m = void 0);
          let f = (0, t.useContext)(i),
            E = (0, t.useMemo)(
              () => (d ? (Array.isArray(d) ? d.flatMap((e) => s(f[e])) : s(f[d])) : []),
              [f, d],
            ),
            [x, _] = (0, t.useState)(f),
            [C, w] = (0, t.useState)(!1);
          f !== x && (_(f), w(!1));
          let b = (0, t.useMemo)(() => o(C ? [] : E), [C, E]),
            y = (0, t.useRef)(r),
            [L, S] = (0, t.useState)(r),
            I = (0, t.useRef)(r),
            [A, N] = (0, t.useState)(!1);
          return (
            (0, t.useEffect)(() => {
              if (!A) return;
              N(!1);
              let e = g || m || y.current;
              c(e, I.current) || ((I.current = e), S(e));
            }),
            {
              realtimeValidation: v || b || g || m || r,
              displayValidation: "native" === h ? v || b || L : v || b || g || m || L,
              updateValidation(e) {
                "aria" !== h || c(L, e) ? (y.current = e) : S(e);
              },
              resetValidation() {
                (c(r, I.current) || ((I.current = r), S(r)), "native" === h && N(!1), w(!0));
              },
              commitValidation() {
                ("native" === h && N(!0), w(!0));
              },
            }
          );
        })(e);
      },
    ]);
  },
  749826,
  (e) => {
    "use strict";
    e.s([
      "CANCELLATION_AUTH",
      0,
      {
        steps: {
          step1: {
            translationKeys: {
              title: "cancellation_auth_step1_title",
              description: "cancellation_auth_step1_description",
            },
          },
          step2: {
            translationKeys: {
              title: "cancellation_auth_step2_title",
              description: "cancellation_auth_step2_description",
            },
          },
          step3: { isCheaperOffer: !0 },
        },
      },
    ]);
  },
  522717,
  144077,
  (e) => {
    "use strict";
    var t = e.i(271645);
    (e.s(
      [
        "useEmailFormConfirmationService",
        0,
        () => {
          let [e, a] = (0, t.useState)(null);
          return {
            parsedToken: e,
            parseToken: (0, t.useCallback)((e) => {
              try {
                if (!e || "string" != typeof e || 0 === e.trim().length) throw Error("Invalid token format");
                let t = e.trim().split(":");
                if (2 !== t.length) throw Error("Invalid token structure");
                let [n, r] = t;
                if (!n || !r) throw Error("Missing token components");
                let i = parseInt(r, 10);
                if (isNaN(i)) throw Error("Invalid timestamp");
                let l = Date.now() - i,
                  s = {
                    hashedToken: e.trim(),
                    hashedCode: n,
                    timestamp: r,
                    isValid: !0,
                    isExpired: l > 36e5,
                  };
                return (a(s), s);
              } catch {
                return (a(null), null);
              }
            }, []),
          };
        },
      ],
      144077,
    ),
      e.s([], 522717));
  },
  279274,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(948148),
      n = e.i(271645),
      r = e.i(749826),
      i = e.i(523173),
      l = e.i(86596);
    e.i(853754);
    var s = e.i(319970);
    e.i(924482);
    var o = e.i(20511);
    e.i(756503);
    var c = e.i(542516);
    e.i(470366);
    var d = e.i(504001);
    e.i(569311);
    var u = e.i(896855),
      m = e.i(861745),
      p = e.i(455263),
      h = e.i(653145),
      v = e.i(327445);
    e.i(522717);
    var g = e.i(144077),
      f = e.i(532153),
      E = e.i(494491),
      x = e.i(382963);
    e.i(976743);
    var _ = e.i(713008);
    e.i(821077);
    var C = e.i(881233);
    e.i(854089);
    var w = e.i(375653),
      b = e.i(495495),
      y = e.i(134404),
      L = e.i(157273);
    e.i(877045);
    var S = e.i(28639),
      I = e.i(322062),
      A = e.i(256889);
    e.i(791371);
    var N = e.i(642448);
    e.i(497799);
    var j = e.i(110910);
    e.i(451916);
    var k = e.i(250737),
      O = e.i(341980),
      T = e.i(60423),
      M = e.i(38691),
      F = e.i(360067),
      D = e.i(202042);
    let R = (e) => {
      let r,
        { updateStep: s, user: o, refreshToken: R, title: B, description: U } = e,
        V = (0, n.useRef)(null),
        z = (0, a.useTranslations)(),
        P = (0, m.useLocale)(),
        K = (0, D.useRouter)(),
        { searchParams: H, changeQuery: W } = (0, b.useQuerySearchParams)(),
        [q, G] = (0, n.useState)(!!R),
        [$, Q] = (0, n.useState)(!1),
        [X, Y] = (0, n.useState)(""),
        [J, Z] = (0, n.useState)(""),
        [ee, et] = (0, n.useState)(null),
        [ea, en] = (0, n.useState)(!1),
        [er, ei] = (0, n.useState)(0),
        [el, es] = (0, n.useState)(!1),
        [eo, ec] = (0, n.useState)(!1),
        { trigger: ed } = (0, E.useSendOtpCodeQuery)(),
        { trigger: eu } = (0, x.useUpdateUserInDatabaseMutation)(),
        { handleChangeUserStore: em } = (0, l.useUserStore)(),
        ep = (0, I.useUserSupportContextStore)((e) => e.handleChangeUserSupportContext),
        eh = (0, l.useUserStore)((e) => e.handleClearUserStore),
        { parseToken: ev } = (0, g.useEmailFormConfirmationService)(),
        {
          handleSubmit: eg,
          control: ef,
          formState: eE,
          getValues: ex,
          watch: e_,
          reset: eC,
        } = (0, h.useForm)({ defaultValues: { email: "", code: "" } }),
        ew = () => {
          eA();
        },
        eb = (e) =>
          e?.error
            ? { error_code: e?.error || "", detailed_message: e?.detailedMessage || "", status: "error" }
            : { status: "success" },
        ey = (e) =>
          e
            ? "true" === e || "sign_in_page_email_error" === e
              ? z("sign_in_page_email_error")
              : "sign_in_page_email_error_attempts" === e
                ? z("sign_in_page_email_error_attempts")
                : e
            : "",
        eL = async () => {
          el ||
            ed({ email: ex("email")?.toLowerCase() || "", locale: P }).then((e) => {
              (e.success &&
                (u.mixpanelClient.reset(),
                T.accessLocalStorage.setItem(
                  L.StorageKeys.CANCELLATION_USER_ID,
                  e.data?.internalUserId || e.data?.user_id || "",
                ),
                u.mixpanelClient.identify(e.data?.internalUserId || e.data?.user_id || ""),
                ew()),
                eb({ error: e?.error }),
                (0, d.trackClientEvents)({
                  event: i.EAnalyticEvents.CANCEL_FLOW_RESEND_CODE_CLICKED,
                  params: eb({ error: e?.error }),
                  user: o,
                }));
            });
        },
        eS = async () => {
          if ((Y(""), !ee)) {
            let e = await (0, M.executeInvisibleCaptcha)(V.current);
            e && et(e);
          }
          await eg(eI)();
        },
        eI = async (e) => {
          (G(!0), Y(""));
          let t = e?.email?.toLowerCase() || "";
          if (!$) {
            let e = await ed({ email: t, locale: P });
            (e.error && Y(ey(e.error)),
              e.success &&
                (e.data?.internalUserId &&
                  (u.mixpanelClient.reset(),
                  T.accessLocalStorage.setItem(L.StorageKeys.CANCELLATION_USER_ID, e.data.internalUserId),
                  u.mixpanelClient.identify(e.data.internalUserId)),
                ew(),
                s(2),
                eh(),
                Q(!0),
                e.data?.internalUserId &&
                  e.data?.user_id &&
                  ep({
                    email: t,
                    userId: e.data?.internalUserId || null,
                    subscriptionId: e.data?.user_id || null,
                  })),
              (0, d.trackClientEvents)({
                event: i.EAnalyticEvents.CANCEL_FLOW_EMAIL_CONTINUE_CLICKED,
                params: { email: t, ...eb({ error: e?.error, detailedMessage: e?.detailedMessage }) },
                user: o,
              }),
              e.success &&
                (0, d.trackClientEvents)({
                  event: i.EAnalyticEvents.CANCEL_FLOW_EMAIL_VERIFICATION_PAGE_VIEWED,
                  user: o,
                }),
              G(!1));
            return;
          }
          if ($) {
            Y("");
            let a = await (0, f.establishCancellationSessionFetcher)({ email: t, confirm_code: e?.code });
            (a.error && Y(ey(a.error)),
              (0, d.trackClientEvents)({
                event: i.EAnalyticEvents.CANCEL_FLOW_VERIFICATION_SUBMIT_CLICKED,
                params: {
                  entered_code: e?.code || "",
                  ...eb({ error: a?.error, detailedMessage: a?.detailedMessage }),
                },
                user: o,
              }),
              a.success &&
                (em({
                  user: {
                    email: t,
                    billingSubscriptionData: void 0,
                    paynextSubscription: void 0,
                    nextBillingDate: void 0,
                  },
                }),
                (0, S.grantCancellationAccess)(a.data?.sessionToken),
                ec(!0),
                requestAnimationFrame(() => {
                  (K.replace(y.EClientRoutes.CANCELLATION), K.refresh());
                })),
              G(!1));
            return;
          }
        },
        eA = () => {
          (ei(60), es(!0));
        };
      return (
        (0, n.useEffect)(() => {
          let e = null;
          return (
            el &&
              er > 0 &&
              (e = setInterval(() => {
                ei((e) => (e <= 1 ? (es(!1), 0) : e - 1));
              }, 1e3)),
            () => {
              e && clearInterval(e);
            }
          );
        }, [el, er]),
        (0, n.useLayoutEffect)(() => {
          R &&
            (async () => {
              G(!0);
              let e = await (0, f.establishCancellationSessionFetcher)({ otp_token: R });
              if (e.success) {
                let t = e.data?.email || "";
                t &&
                  ((0, S.grantCancellationAccess)(e.data?.sessionToken),
                  em({
                    user: {
                      email: t,
                      billingSubscriptionData: void 0,
                      paynextSubscription: void 0,
                      nextBillingDate: void 0,
                    },
                  }),
                  K.replace(y.EClientRoutes.CANCELLATION));
              } else
                ((0, d.trackClientEvents)({
                  event: i.EAnalyticEvents.CANCEL_FLOW_VERIFICATION_SUBMIT_CLICKED,
                  params: {
                    entered_token: R || "",
                    ...eb({ error: e?.error, detailedMessage: e?.detailedMessage }),
                  },
                  user: o,
                }),
                  G(!1));
            })();
        }, [R, ev, eu, K, o?.isBillingOnly]),
        (0, n.useLayoutEffect)(() => {
          o?.access_to_cancellation &&
            (ec(!0),
            requestAnimationFrame(() => {
              (K.replace(y.EClientRoutes.CANCELLATION), K.refresh());
            }));
        }, [o?.access_to_cancellation, K]),
        (0, n.useEffect)(() => {
          ("billing_only" === H.get("auth") && (ec(!0), K.push(y.EClientRoutes.CANCELLATION)),
            "not_found" === H.get("auth") && Z(z("error_not_found_email")));
        }, [H]),
        (0, t.jsxs)(t.Fragment, {
          children: [
            ea &&
              (0, t.jsx)("div", {
                "aria-hidden": !0,
                className: "absolute -left-[9999px] -top-[9999px]",
                children: (0, t.jsx)(p.default, {
                  ref: V,
                  sitekey: c.envClient.NEXT_PUBLIC_RE_CAPTCHA_INVISIBLE_KEY ?? "",
                  size: "invisible",
                  badge: "bottomright",
                  onChange: (e) => {
                    et(e);
                  },
                }),
              }),
            (0, t.jsxs)("div", {
              className: "flex flex-col gap-8",
              children: [
                (0, t.jsxs)("div", {
                  className: "flex flex-col gap-6",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex flex-col gap-2 text-center",
                      children: [
                        (0, t.jsx)("h1", { className: "text-hp-h3-lg text-black-custom", children: B }),
                        $
                          ? (0, t.jsx)(j.AuthCodeSentToComponent, {
                              email: ex("email"),
                              onChange: () => {
                                (Q(!1), s(1), eC({ email: "" }));
                              },
                            })
                          : (0, t.jsx)("p", { className: "text-hp-body-sm text-grey-deep", children: U }),
                      ],
                    }),
                    (0, t.jsxs)(v.Form, {
                      validationBehavior: "aria",
                      onSubmit: eg(eI),
                      className: "grid w-full gap-4",
                      children: [
                        $
                          ? (0, t.jsx)(
                              h.Controller,
                              {
                                control: ef,
                                name: "code",
                                render: (e) => {
                                  let {
                                    field: { value: a, onChange: n },
                                  } = e;
                                  return (0, t.jsxs)("div", {
                                    children: [
                                      (0, t.jsxs)("div", {
                                        className: "relative",
                                        children: [
                                          (0, t.jsx)("input", {
                                            id: "code",
                                            name: "code",
                                            "data-cy": "code_input",
                                            inputMode: "numeric",
                                            minLength: 6,
                                            maxLength: 6,
                                            placeholder: " ",
                                            value: a,
                                            "aria-invalid": !!X,
                                            "aria-describedby": X ? "code-error" : void 0,
                                            onChange: (e) => {
                                              (n(e.target.value.trim()), Y(""));
                                            },
                                            className: (0, A.cn)(
                                              O.FIELD_INPUT_BASE,
                                              X ? O.FIELD_INPUT_ERROR : O.FIELD_INPUT_REST,
                                            ),
                                          }),
                                          (0, t.jsx)("label", {
                                            htmlFor: "code",
                                            className: (0, A.cn)(
                                              O.FIELD_LABEL_BASE,
                                              O.FIELD_LABEL_REST,
                                              O.FIELD_LABEL_FLOAT,
                                            ),
                                            children: z("otp_confirmation_code_label"),
                                          }),
                                        ],
                                      }),
                                      X &&
                                        (0, t.jsx)("p", {
                                          id: "code-error",
                                          className: "mt-2 text-center text-hp-body-sm text-danger-custom",
                                          children: X,
                                        }),
                                    ],
                                  });
                                },
                                rules: { required: (0, F.getRequiredMessage)(z), minLength: 6, maxLength: 6 },
                              },
                              "code",
                            )
                          : (0, t.jsx)(
                              h.Controller,
                              {
                                control: ef,
                                name: "email",
                                render: (e) => {
                                  let {
                                    field: { value: a, onChange: n },
                                    fieldState: { error: r },
                                  } = e;
                                  return (0, t.jsxs)("div", {
                                    children: [
                                      (0, t.jsxs)("div", {
                                        className: "relative",
                                        children: [
                                          (0, t.jsx)("input", {
                                            id: "email",
                                            name: "email",
                                            "data-cy": "email_input",
                                            inputMode: "email",
                                            dir: "ltr",
                                            autoComplete: "email",
                                            autoCapitalize: "none",
                                            spellCheck: !1,
                                            placeholder: " ",
                                            value: a,
                                            "aria-invalid": !!r,
                                            "aria-describedby": r ? "email-error" : void 0,
                                            onChange: (e) => {
                                              ("not_found" === H.get("auth") && (W("auth", ""), Z("")),
                                                n(e.target.value.trim()),
                                                Y(""));
                                            },
                                            onFocus: () => en(!0),
                                            className: (0, A.cn)(
                                              O.FIELD_INPUT_BASE,
                                              r ? O.FIELD_INPUT_ERROR : O.FIELD_INPUT_REST,
                                            ),
                                          }),
                                          (0, t.jsx)("label", {
                                            htmlFor: "email",
                                            className: (0, A.cn)(
                                              O.FIELD_LABEL_BASE,
                                              O.FIELD_LABEL_REST,
                                              O.FIELD_LABEL_FLOAT,
                                            ),
                                            children: z("sign_in_page_email_input_title"),
                                          }),
                                        ],
                                      }),
                                      r?.message &&
                                        (0, t.jsx)("p", {
                                          id: "email-error",
                                          className: "mt-2 text-center text-hp-body-sm text-danger-custom",
                                          children: r.message,
                                        }),
                                    ],
                                  });
                                },
                                rules: {
                                  pattern: { value: F.emailPattern.value, message: z("error_email_format") },
                                },
                              },
                              "email",
                            ),
                        (0, t.jsxs)(N.DemoButton, {
                          type: "button",
                          className: "w-full",
                          size: "lg",
                          disabled: !eE.isValid || q || !e_("email"),
                          onClick: eS,
                          children: [
                            q &&
                              (0, t.jsx)("span", {
                                "aria-hidden": !0,
                                className:
                                  "size-4 shrink-0 animate-spin rounded-full border-2 border-white/40 border-t-white motion-reduce:animate-none",
                              }),
                            z("btn_continue"),
                          ],
                        }),
                        X &&
                          !$ &&
                          (0, t.jsx)("p", {
                            className: "text-center text-hp-body-sm text-danger-custom",
                            children: X,
                          }),
                        $ &&
                          (el
                            ? (0, t.jsx)("p", {
                                "aria-live": "polite",
                                className: "text-center text-hp-body-sm tabular-nums text-grey-light",
                                children: z("otp_confirmation_request_new_code_in", {
                                  time:
                                    ((r = Math.floor(er / 60)),
                                    `${r}:${(er % 60).toString().padStart(2, "0")}`),
                                }),
                              })
                            : (0, t.jsxs)("div", {
                                "aria-live": "polite",
                                className: "flex flex-col items-center gap-1",
                                children: [
                                  (0, t.jsx)("p", {
                                    className: "text-center text-hp-body-sm text-grey-light",
                                    children: z("otp_confirmation_check_spam_tip"),
                                  }),
                                  (0, t.jsx)("button", {
                                    type: "button",
                                    disabled: q,
                                    onClick: eL,
                                    className:
                                      "text-hp-body-sm font-medium text-blue-custom underline-offset-2 disabled:cursor-not-allowed disabled:opacity-50 [@media(hover:hover)]:hover:underline",
                                    children: z("otp_confirmation_request_new_code"),
                                  }),
                                ],
                              })),
                      ],
                    }),
                  ],
                }),
                !$ &&
                  (0, t.jsxs)(t.Fragment, {
                    children: [
                      (0, t.jsx)(w.SocialSignInSection, {
                        className: "",
                        isCancellationAuth: !0,
                        isRedesign: !0,
                        disabled: q,
                      }),
                      J &&
                        (0, t.jsx)("p", {
                          className: "text-center text-hp-body-sm text-danger-custom",
                          children: J,
                        }),
                      (0, t.jsx)(k.AuthSupportNoteComponent, {}),
                    ],
                  }),
              ],
            }),
            (eo || (!!R && q)) &&
              (0, t.jsxs)("div", {
                className: "fixed left-0 top-0 z-50 h-dvh w-dvw",
                children: [(0, t.jsx)(C.PreloaderComponent, {}), (0, t.jsx)(_.GradientBgComponent, {})],
              }),
          ],
        })
      );
    };
    e.s(
      [
        "default",
        0,
        (e) => {
          let { refreshToken: m } = e,
            p = (0, l.useUserStore)((e) => e.user),
            h = (0, a.useTranslations)(),
            [v, g] = (0, n.useState)(1);
          return (
            "production" === c.envClient.NEXT_PUBLIC_APP_ENV && u.mixpanelClient.startSessionRecording(),
            (0, n.useEffect)(() => {
              (0, d.trackClientEvents)({
                event: i.EAnalyticEvents.CANCEL_FLOW_ENTER_EMAIL_PAGE_VIEWED,
                user: p,
              });
            }, []),
            (0, t.jsxs)(t.Fragment, {
              children: [
                (0, t.jsx)(o.DemoStaticHeaderComponent, {}),
                (0, t.jsx)("main", {
                  className: "flex flex-1 flex-col px-4 py-8 md:py-10",
                  children: (0, t.jsx)("div", {
                    className:
                      "mx-auto w-full max-w-[448px] md:rounded-3xl md:border md:border-slate-200 md:bg-white md:px-5 md:py-8 md:shadow-rd-card",
                    children: (0, t.jsx)(R, {
                      currentStep: v,
                      updateStep: g,
                      refreshToken: m,
                      title: h(r.CANCELLATION_AUTH.steps.step1.translationKeys.title),
                      description: h(r.CANCELLATION_AUTH.steps.step1.translationKeys.description),
                    }),
                  }),
                }),
                (0, t.jsx)(s.DemoFooterComponent, {}),
              ],
            })
          );
        },
      ],
      279274,
    );
  },
  934337,
  194693,
  597521,
  171946,
  703085,
  492669,
  70224,
  19309,
  106502,
  327293,
  230268,
  779450,
  492810,
  216933,
  513833,
  178281,
  358551,
  339998,
  12326,
  482527,
  707945,
  (e) => {
    "use strict";
    var t,
      a,
      n,
      r,
      i,
      l,
      s,
      o,
      c,
      d,
      u,
      m,
      p,
      h,
      v,
      g,
      f,
      E,
      x,
      _,
      C,
      w,
      b,
      y,
      L,
      S,
      I,
      A,
      N,
      j,
      k,
      O,
      T,
      M = e.i(271645);
    function F() {
      return (F = Object.assign.bind()).apply(null, arguments);
    }
    function D() {
      return (D = Object.assign.bind()).apply(null, arguments);
    }
    function R() {
      return (R = Object.assign.bind()).apply(null, arguments);
    }
    function B() {
      return (B = Object.assign.bind()).apply(null, arguments);
    }
    function U() {
      return (U = Object.assign.bind()).apply(null, arguments);
    }
    function V() {
      return (V = Object.assign.bind()).apply(null, arguments);
    }
    function z() {
      return (z = Object.assign.bind()).apply(null, arguments);
    }
    function P() {
      return (P = Object.assign.bind()).apply(null, arguments);
    }
    function K() {
      return (K = Object.assign.bind()).apply(null, arguments);
    }
    function H() {
      return (H = Object.assign.bind()).apply(null, arguments);
    }
    function W() {
      return (W = Object.assign.bind()).apply(null, arguments);
    }
    function q() {
      return (q = Object.assign.bind()).apply(null, arguments);
    }
    function G() {
      return (G = Object.assign.bind()).apply(null, arguments);
    }
    function $() {
      return ($ = Object.assign.bind()).apply(null, arguments);
    }
    function Q() {
      return (Q = Object.assign.bind()).apply(null, arguments);
    }
    function X() {
      return (X = Object.assign.bind()).apply(null, arguments);
    }
    function Y() {
      return (Y = Object.assign.bind()).apply(null, arguments);
    }
    function J() {
      return (J = Object.assign.bind()).apply(null, arguments);
    }
    function Z() {
      return (Z = Object.assign.bind()).apply(null, arguments);
    }
    function ee() {
      return (ee = Object.assign.bind()).apply(null, arguments);
    }
    (e.s(
      [
        "default",
        0,
        (e) =>
          M.createElement(
            "svg",
            F({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 15 14" }, e),
            t ||
              (t = M.createElement("path", {
                fill: "#fff",
                d: "m5.938 1.094.687-.688c.313-.281.781-.281 1.063 0L13.78 6.47c.281.312.281.781 0 1.062l-6.094 6.094c-.28.281-.75.281-1.062 0l-.688-.688a.814.814 0 0 1 0-1.093L9.72 8.25H.75A.72.72 0 0 1 0 7.5v-1a.74.74 0 0 1 .75-.75h8.969L5.938 2.187c-.282-.312-.313-.78 0-1.093",
              })),
          ),
      ],
      194693,
    ),
      e.s(
        [
          "default",
          0,
          (e) =>
            M.createElement(
              "svg",
              D({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 8 12" }, e),
              a ||
                (a = M.createElement("path", {
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 1.667,
                  d: "m1.5 11 5-5-5-5",
                })),
            ),
        ],
        597521,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            M.createElement(
              "svg",
              R({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 25 24" }, e),
              n ||
                (n = M.createElement("path", {
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M5.5 12h14m-7-7 7 7-7 7",
                })),
            ),
        ],
        171946,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            M.createElement(
              "svg",
              B({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 48 48" }, e),
              r ||
                (r = M.createElement("path", {
                  fill: "#CFD8DC",
                  d: "M5 38V14h38v24c0 2.2-1.8 4-4 4H9c-2.2 0-4-1.8-4-4",
                })),
              i ||
                (i = M.createElement("path", {
                  fill: "#F44336",
                  d: "M43 10v6H5v-6c0-2.2 1.8-4 4-4h30c2.2 0 4 1.8 4 4",
                })),
              l ||
                (l = M.createElement(
                  "g",
                  { fill: "#B71C1C" },
                  M.createElement("circle", { cx: 33, cy: 10, r: 3 }),
                  M.createElement("circle", { cx: 15, cy: 10, r: 3 }),
                )),
              s ||
                (s = M.createElement("path", {
                  fill: "#B0BEC5",
                  d: "M33 3c-1.1 0-2 .9-2 2v5c0 1.1.9 2 2 2s2-.9 2-2V5c0-1.1-.9-2-2-2M15 3c-1.1 0-2 .9-2 2v5c0 1.1.9 2 2 2s2-.9 2-2V5c0-1.1-.9-2-2-2",
                })),
              o ||
                (o = M.createElement("path", {
                  fill: "#90A4AE",
                  d: "M13 20h4v4h-4zm6 0h4v4h-4zm6 0h4v4h-4zm6 0h4v4h-4zm-18 6h4v4h-4zm6 0h4v4h-4zm6 0h4v4h-4zm6 0h4v4h-4zm-18 6h4v4h-4zm6 0h4v4h-4zm6 0h4v4h-4zm6 0h4v4h-4z",
                })),
            ),
        ],
        703085,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            M.createElement(
              "svg",
              U({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 18 13" }, e),
              c ||
                (c = M.createElement("path", {
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2.333,
                  d: "m1.31 6.8 4.95 4.95 9.899-9.9",
                })),
            ),
        ],
        492669,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            M.createElement(
              "svg",
              V(
                {
                  xmlns: "http://www.w3.org/2000/svg",
                  fill: "none",
                  stroke: "currentColor",
                  strokeWidth: 1.5,
                  "aria-hidden": "true",
                  className:
                    "checkmark-thin_svg__text-blue-600 checkmark-thin_svg__min-h-6 checkmark-thin_svg__min-w-6 checkmark-thin_svg__max-h-6 checkmark-thin_svg__max-w-6",
                  "data-slot": "icon",
                  viewBox: "0 0 24 24",
                },
                e,
              ),
              d ||
                (d = M.createElement("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  d: "m4.5 12.75 6 6 9-13.5",
                })),
            ),
        ],
        70224,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            M.createElement(
              "svg",
              z({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24" }, e),
              u ||
                (u = M.createElement("path", {
                  fill: "currentColor",
                  fillRule: "evenodd",
                  d: "M3.172 5.172C2 6.343 2 8.229 2 12s0 5.657 1.172 6.828S6.229 20 10 20h4c3.771 0 5.657 0 6.828-1.172S22 15.771 22 12s0-5.657-1.172-6.828S17.771 4 14 4h-4C6.229 4 4.343 4 3.172 5.172M18.576 7.52a.75.75 0 0 1-.096 1.056l-2.196 1.83c-.887.74-1.605 1.338-2.24 1.746-.66.425-1.303.693-2.044.693s-1.384-.269-2.045-.693c-.634-.408-1.352-1.007-2.239-1.745L5.52 8.577a.75.75 0 0 1 .96-1.153l2.16 1.799c.933.777 1.58 1.315 2.128 1.667.529.34.888.455 1.233.455s.704-.114 1.233-.455c.547-.352 1.195-.89 2.128-1.667l2.159-1.8a.75.75 0 0 1 1.056.097",
                  clipRule: "evenodd",
                })),
            ),
        ],
        19309,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            M.createElement(
              "svg",
              P(
                {
                  xmlns: "http://www.w3.org/2000/svg",
                  width: "1em",
                  height: "1em",
                  fill: "none",
                  "aria-hidden": "true",
                  style: { fontSize: 20, lineHeight: 20, float: "left" },
                  viewBox: "0 0 24 24",
                },
                e,
              ),
              m || (m = M.createElement("path", { fill: "#f25022", d: "M0 0h10.931v10.931H0z" })),
              p || (p = M.createElement("path", { fill: "#7fba00", d: "M12.069 0H23v10.931H12.069z" })),
              h || (h = M.createElement("path", { fill: "#00a4ef", d: "M0 12.069h10.931V23H0z" })),
              v || (v = M.createElement("path", { fill: "#ffb900", d: "M12.069 12.069H23V23H12.069z" })),
            ),
        ],
        106502,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            M.createElement(
              "svg",
              K({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24" }, e),
              g ||
                (g = M.createElement("path", {
                  fill: "currentColor",
                  d: "m11.4 18.161 7.396-7.396a10.3 10.3 0 0 1-3.326-2.234 10.3 10.3 0 0 1-2.235-3.327L5.839 12.6c-.577.577-.866.866-1.114 1.184a6.6 6.6 0 0 0-.749 1.211c-.173.364-.302.752-.56 1.526l-1.362 4.083a1.06 1.06 0 0 0 1.342 1.342l4.083-1.362c.775-.258 1.162-.387 1.526-.56q.647-.308 1.211-.749c.318-.248.607-.537 1.184-1.114m9.448-9.448a3.932 3.932 0 0 0-5.561-5.561l-.887.887.038.111a8.75 8.75 0 0 0 2.092 3.32 8.75 8.75 0 0 0 3.431 2.13z",
                })),
            ),
        ],
        327293,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            M.createElement(
              "svg",
              H({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24" }, e),
              f ||
                (f = M.createElement("path", {
                  fill: "none",
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M5 12h14m-7-7v14",
                })),
            ),
        ],
        230268,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            M.createElement(
              "svg",
              W({ xmlns: "http://www.w3.org/2000/svg", fill: "currentColor", viewBox: "0 0 20 20" }, e),
              E ||
                (E = M.createElement("path", {
                  fillRule: "evenodd",
                  d: "M10 15.27 16.18 18l-1.64-7.03L19 7.24l-7.19-.61L10 0 8.19 6.63 1 7.24l4.46 3.73L3.82 18z",
                  clipRule: "evenodd",
                })),
            ),
        ],
        779450,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            M.createElement(
              "svg",
              q({ xmlns: "http://www.w3.org/2000/svg", "aria-hidden": "true", viewBox: "0 0 24 24" }, e),
              x ||
                (x = M.createElement("path", {
                  fill: "currentColor",
                  d: "M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z",
                })),
            ),
        ],
        492810,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            M.createElement(
              "svg",
              G({ xmlns: "http://www.w3.org/2000/svg", fill: "#0d766e", viewBox: "0 0 24 24" }, e),
              _ ||
                (_ = M.createElement("path", {
                  d: "M19.965 8.521Q20 8.26 20 8c0-2.379-2.143-4.288-4.521-3.965C14.786 2.802 13.466 2 12 2s-2.786.802-3.479 2.035C6.138 3.712 4 5.621 4 8q0 .26.035.521C2.802 9.215 2 10.535 2 12s.802 2.785 2.035 3.479A4 4 0 0 0 4 16c0 2.379 2.138 4.283 4.521 3.965C9.214 21.198 10.534 22 12 22s2.786-.802 3.479-2.035C17.857 20.283 20 18.379 20 16q0-.26-.035-.521C21.198 14.785 22 13.465 22 12s-.802-2.785-2.035-3.479m-9.01 7.895-3.667-3.714 1.424-1.404 2.257 2.286 4.327-4.294 1.408 1.42z",
                })),
            ),
        ],
        216933,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            M.createElement(
              "svg",
              $({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 32 32" }, e),
              C ||
                (C = M.createElement("path", {
                  fill: "#0758B4",
                  d: "M14.333 22.056a.5.5 0 0 0-.506-.142 2.147 2.147 0 0 1-2.569-1.219 3.1 3.1 0 0 0-2.678-1.92 2 2 0 0 1-.657-.151.5.5 0 0 0-.66.283l-3.775 9.926a.5.5 0 0 0 .636.647l3.936-1.415 2.001 3.674A.5.5 0 0 0 10.5 32l.034-.001a.5.5 0 0 0 .433-.322l3.465-9.104a.5.5 0 0 0-.099-.517m14.179 6.776-3.775-9.925a.5.5 0 0 0-.66-.283 2 2 0 0 1-.662.152 3.13 3.13 0 0 0-1.608.58c-.476.335-.845.8-1.064 1.339a2.115 2.115 0 0 1-2.566 1.221.5.5 0 0 0-.609.657l3.465 9.105a.5.5 0 0 0 .433.321L21.5 32a.5.5 0 0 0 .439-.261l2-3.674 3.937 1.415a.5.5 0 0 0 .636-.648",
                })),
              w ||
                (w = M.createElement("path", {
                  fill: "#4294FF",
                  d: "M26.989 9.136a2.07 2.07 0 0 1-.689-2.095 3.04 3.04 0 0 0-.49-2.538 3.12 3.12 0 0 0-2.323-1.279 2.13 2.13 0 0 1-1.818-1.298 3.1 3.1 0 0 0-1.913-1.77 3.14 3.14 0 0 0-2.63.313 2.16 2.16 0 0 1-2.253 0 3.145 3.145 0 0 0-3.78.36c-.33.307-.59.68-.761 1.097a2.13 2.13 0 0 1-1.823 1.299 3.12 3.12 0 0 0-2.32 1.278 3.04 3.04 0 0 0-.487 2.543 2.07 2.07 0 0 1-.696 2.095 3.05 3.05 0 0 0 .006 4.723 2.07 2.07 0 0 1 .688 2.095 3.04 3.04 0 0 0 .49 2.538 3.12 3.12 0 0 0 2.324 1.279 2.13 2.13 0 0 1 1.818 1.298 3.1 3.1 0 0 0 1.912 1.77 3.14 3.14 0 0 0 2.63-.313 2.16 2.16 0 0 1 2.252 0 3.146 3.146 0 0 0 3.781-.36c.33-.307.59-.68.762-1.097a2.13 2.13 0 0 1 1.822-1.299 3.12 3.12 0 0 0 2.32-1.278 3.04 3.04 0 0 0 .488-2.543 2.07 2.07 0 0 1 .695-2.094 3.05 3.05 0 0 0-.006-4.724",
                })),
              b ||
                (b = M.createElement("path", {
                  fill: "#FDFEFF",
                  d: "M16 19a7.5 7.5 0 1 0 0-15 7.5 7.5 0 0 0 0 15",
                })),
              y ||
                (y = M.createElement("path", {
                  fill: "#0758B4",
                  d: "M20.38 10.182a.5.5 0 0 0-.403-.34l-2.439-.355-1.09-2.208a.52.52 0 0 0-.896 0l-1.09 2.209-2.438.354a.5.5 0 0 0-.278.853l1.765 1.72-.416 2.427a.5.5 0 0 0 .724.527L16 14.223l2.18 1.146a.5.5 0 0 0 .726-.527l-.417-2.428 1.765-1.72a.5.5 0 0 0 .127-.512z",
                })),
            ),
        ],
        513833,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            M.createElement(
              "svg",
              Q(
                {
                  xmlns: "http://www.w3.org/2000/svg",
                  fill: "none",
                  stroke: "currentColor",
                  viewBox: "0 0 24 24",
                },
                e,
              ),
              L ||
                (L = M.createElement("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "m9 5 7 7-7 7",
                })),
            ),
        ],
        178281,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            M.createElement(
              "svg",
              X({ xmlns: "http://www.w3.org/2000/svg", width: 80, height: 78, fill: "none" }, e),
              S ||
                (S = M.createElement("path", {
                  fill: "currentColor",
                  fillRule: "evenodd",
                  d: "M52.865 48.96c-14.623 0-26.433-11.858-26.433-26.433 0 14.575-11.857 26.432-26.432 26.432 14.575 0 26.432 11.81 26.432 26.386 0-14.575 11.81-26.386 26.433-26.386M80 62.597c-8.014 0-14.482-6.514-14.482-14.481 0 7.967-6.514 14.481-14.481 14.481 7.967 0 14.481 6.468 14.481 14.482A14.46 14.46 0 0 1 80 62.597m-8.342-44.054c-9.748 0-17.622-7.873-17.622-17.621 0 9.748-7.873 17.621-17.621 17.621 9.748 0 17.621 7.874 17.621 17.622 0-9.748 7.874-17.622 17.622-17.622",
                  clipRule: "evenodd",
                })),
            ),
        ],
        358551,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            M.createElement(
              "svg",
              Y({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24" }, e),
              I ||
                (I = M.createElement("path", {
                  fill: "currentColor",
                  d: "M9 3V1h6v2zm2 11h2V8h-2zm1 8q-1.85 0-3.488-.712T5.65 19.35t-1.937-2.863T3 13t.713-3.488T5.65 6.65t2.863-1.937T12 4q1.55 0 2.975.5t2.675 1.45l1.4-1.4 1.4 1.4-1.4 1.4Q20 8.6 20.5 10.025T21 13q0 1.85-.713 3.488T18.35 19.35q-1.225 1.225-2.863 1.938T12 22m0-2q2.9 0 4.95-2.05T19 13t-2.05-4.95T12 6 7.05 8.05 5 13t2.05 4.95T12 20m0-7",
                })),
            ),
        ],
        339998,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            M.createElement(
              "svg",
              J({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24" }, e),
              A ||
                (A = M.createElement("path", {
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M3 11h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zm0 0a9 9 0 1 1 18 0m0 0v5a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2z",
                })),
              N ||
                (N = M.createElement("path", {
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M21 16v2a4 4 0 0 1-4 4h-5",
                })),
            ),
        ],
        12326,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            M.createElement(
              "svg",
              Z({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24" }, e),
              j || (j = M.createElement("circle", { cx: 12, cy: 6, r: 4, fill: "currentColor" })),
              k ||
                (k = M.createElement("path", {
                  fill: "currentColor",
                  d: "M20 17.5c0 2.485 0 4.5-8 4.5s-8-2.015-8-4.5S7.582 13 12 13s8 2.015 8 4.5",
                })),
            ),
        ],
        482527,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            M.createElement(
              "svg",
              ee({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 44 44" }, e),
              O || (O = M.createElement("path", { fill: "#FC3F1D", d: "M0 0h44v44H0z" })),
              T ||
                (T = M.createElement("path", {
                  fill: "#fff",
                  d: "M22.952 24.29c1.339 2.933 1.785 3.953 1.785 7.477v4.67h-4.783v-7.875L10.931 8.938h4.99zM28.85 8.938 23 22.233h4.862l5.866-13.295z",
                })),
            ),
        ],
        707945,
      ),
      e.s([], 934337));
  },
  854089,
  375653,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(217255),
      n = e.i(861745),
      r = e.i(948148),
      i = e.i(271645),
      l = e.i(677711),
      s = e.i(335889),
      o = e.i(112041);
    e.i(934337);
    var c = e.i(676346),
      d = e.i(827701),
      u = e.i(523173),
      m = e.i(866897),
      p = e.i(134404),
      h = e.i(924254);
    e.i(470366);
    var v = e.i(504001);
    e.i(999126);
    var g = e.i(548248);
    let f =
        "active flex h-12 w-full items-center justify-center gap-2 rounded-full border border-slate-200 bg-white text-hp-body-sm text-grey-deep transition-colors duration-150 disabled:cursor-not-allowed disabled:opacity-50 [@media(hover:hover)]:hover:bg-black-custom/[0.04]",
      E = (0, t.jsx)("span", {
        "aria-hidden": !0,
        className:
          "size-5 shrink-0 animate-spin rounded-full border-2 border-slate-200 border-t-green-custom motion-reduce:animate-none",
      });
    (e.s([], 854089),
      e.s(
        [
          "SocialSignInSection",
          0,
          (e) => {
            let { disabled: x, className: _, isCancellationAuth: C, isRedesign: w = !1 } = e,
              b = w
                ? f
                : "active flex h-12 w-full items-center justify-center gap-1.5 rounded-[5px] border bg-white text-dark-custom disabled:border-gray-300 disabled:opacity-[0.5] [@media(hover:hover)]:hover:bg-gray-50",
              y = w
                ? f
                : "active flex h-12 w-full items-center justify-center gap-2 rounded-[5px] border bg-white text-gray-700",
              L = w ? "size-5" : "min-h-5 min-w-5",
              S = w
                ? E
                : (0, t.jsx)(o.Spinner, {
                    size: "sm",
                    classNames: { circle1: "border-b-green-custom", circle2: "border-b-green-custom" },
                  }),
              I = (0, r.useTranslations)(),
              A = (0, n.useLocale)(),
              [N, j] = (0, i.useState)(null);
            (0, i.useEffect)(() => {
              let e = () => {
                "visible" === document.visibilityState && j(null);
              };
              return (
                document.addEventListener("visibilitychange", e),
                window.addEventListener("pageshow", e),
                () => {
                  (document.removeEventListener("visibilitychange", e),
                    window.removeEventListener("pageshow", e));
                }
              );
            }, []);
            let k = async (e, t) => {
                if (!e) return;
                (j(e),
                  (0, v.trackClientEvents)({ event: t }),
                  h.accessCookie.removeItem(m.ECookieArg.SOCIAL_SIGNUP_INTENT));
                let n = await (0, a.signIn)(e, {
                  redirect: !1,
                  callbackUrl: C ? p.EClientRoutes.CANCELLATION : p.EClientRoutes.SIGN_IN,
                });
                n?.error && ((0, g.debugUtil)({ text: "handleSocialSignIn error", value: n }), j(null));
              },
              O = null !== N;
            return (0, t.jsxs)(t.Fragment, {
              children: [
                (0, t.jsxs)("div", {
                  className: `relative flex justify-center ${_}`,
                  children: [
                    (0, t.jsx)("div", {
                      className: `absolute top-1/2 h-px w-full ${w ? "bg-slate-200" : "bg-gray-300"}`,
                    }),
                    (0, t.jsx)("span", {
                      className: w
                        ? "relative bg-white px-2 text-hp-body-sm text-grey-light"
                        : "relative bg-white px-2 text-sm text-gray-600",
                      children: I("sign_in_page_or_continue_with"),
                    }),
                  ],
                }),
                (0, t.jsxs)("div", {
                  className: "flex flex-col gap-2",
                  children: [
                    (0, t.jsxs)(s.Button, {
                      className: b,
                      disableRipple: !0,
                      onPress: () => k("google", u.EAnalyticEvents.GOOGLE_LOGIN_CLICKED),
                      isDisabled: x || O,
                      isLoading: "google" === N,
                      spinnerPlacement: "start",
                      spinner: S,
                      children: [
                        (0, t.jsx)(l.FcGoogle, {
                          className: w ? L : `min-h-6 min-w-6 ${x ? "text-gray-300" : ""}`,
                        }),
                        (0, t.jsx)("span", { children: I("sign_in_with_google") }),
                      ],
                    }),
                    "ru" !== A &&
                      (0, t.jsxs)(s.Button, {
                        disableAnimation: !0,
                        className: y,
                        onPress: () => k("azure-ad", u.EAnalyticEvents.MICROSOFT_LOGIN_CLICKED),
                        isDisabled: x || O,
                        isLoading: "azure-ad" === N,
                        spinner: S,
                        children: [
                          (0, t.jsx)(c.IconMicrosoftLogo, { className: L }),
                          (0, t.jsx)("span", { children: I("sign_in_with_microsoft") }),
                        ],
                      }),
                    "ru" === A &&
                      (0, t.jsxs)(s.Button, {
                        disableAnimation: !0,
                        className: y,
                        onPress: () => k("yandex", u.EAnalyticEvents.YANDEX_LOGIN_CLICKED),
                        isDisabled: x || O,
                        isLoading: "yandex" === N,
                        spinner: S,
                        children: [
                          (0, t.jsx)(d.IconYandexLogo, { className: `${L} rounded-full` }),
                          (0, t.jsx)("span", { children: I("sign_in_with_yandex") }),
                        ],
                      }),
                  ],
                }),
              ],
            });
          },
        ],
        375653,
      ));
  },
  495495,
  (e) => {
    "use strict";
    var t = e.i(618566),
      a = e.i(202042);
    e.s([
      "useQuerySearchParams",
      0,
      () => {
        let { push: e } = (0, a.useRouter)(),
          n = (0, a.usePathname)(),
          r = (0, t.useSearchParams)(),
          i = new URLSearchParams(window.location.hash.slice(1)),
          l = String(new URLSearchParams(r));
        return {
          push: e,
          searchParams: r,
          allQueriesParams: l,
          changeQuery: (t, a) => {
            let i;
            e(
              n +
                "?" +
                ((i = new URLSearchParams(r)).delete("page"), a ? i.set(t, a) : i.delete(t), i.toString()),
            );
          },
          hashParams: i,
        };
      },
    ]);
  },
  877045,
  28639,
  (e) => {
    "use strict";
    var t = e.i(117595),
      a = e.i(866897),
      n = e.i(157273),
      r = e.i(190899);
    let i = () => {
        r.accessSessionStorageUtil.removeItem(n.StorageKeys.CANCELLATION_STORAGE_SESSION);
      },
      l = () => {
        let e = r.accessSessionStorageUtil.getItem(n.StorageKeys.CANCELLATION_STORAGE_SESSION);
        if (!e) return null;
        let t = ((e) => {
          try {
            return JSON.parse(e);
          } catch {
            return null;
          }
        })(e);
        return t?.token && t.expiresAt > Date.now() ? t.token : (i(), null);
      };
    (e.s(
      [
        "getCancellationSessionHeaders",
        0,
        () => {
          let e = l();
          return e ? { "X-Cancellation-Session": e } : {};
        },
        "getCancellationStorageSession",
        0,
        l,
        "grantCancellationAccess",
        0,
        (e) => {
          if (
            (t.default.set(a.ECookieArg.ACCESS_TO_CANCELLATION, "true", { expires: 1 / 24 }),
            (navigator.cookieEnabled && "true" === t.default.get(a.ECookieArg.ACCESS_TO_CANCELLATION)) || !e)
          )
            return;
          let i = { token: e, expiresAt: Date.now() + 33e5 };
          r.accessSessionStorageUtil.setItem(n.StorageKeys.CANCELLATION_STORAGE_SESSION, JSON.stringify(i));
        },
        "revokeCancellationAccess",
        0,
        () => {
          (t.default.remove(a.ECookieArg.ACCESS_TO_CANCELLATION), i());
        },
      ],
      28639,
    ),
      e.s([], 877045));
  },
]);
