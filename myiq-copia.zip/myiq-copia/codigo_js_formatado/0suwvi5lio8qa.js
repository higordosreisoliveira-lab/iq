(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  424689,
  (e) => {
    "use strict";
    var t = e.i(843476),
      s = e.i(657688),
      i = e.i(948148),
      r = e.i(663615),
      o = e.i(866897),
      l = e.i(157273),
      c = e.i(924254),
      a = e.i(190899),
      n = e.i(493598),
      d = e.i(480164);
    e.s([
      "default",
      0,
      (e) => {
        let { onContinue: m } = e,
          x = (0, i.useTranslations)(),
          u = d.CHOOSE_YOUR_HERO_CELEBRITIES,
          f = (0, n.getIsGoogleTraffic)(),
          h = l.StorageKeys.SELECTED_HERO_ID;
        return (0, t.jsx)("div", {
          className: "select-none pb-5 lg:pb-10",
          children: (0, t.jsxs)("div", {
            className: "mx-auto flex w-full max-w-sm flex-col items-center gap-3 sm:max-w-xl",
            children: [
              (0, t.jsx)("div", {
                className:
                  "-mt-4 flex flex-col items-center justify-center gap-2 pb-6 max-lg:pt-6 max-sm:min-h-[110px]",
                children: (0, t.jsx)("h2", {
                  className:
                    "flex items-center justify-center text-center text-[24px] font-semibold leading-tight text-dark-custom",
                  children: x("choose_your_hero_title"),
                }),
              }),
              (0, t.jsx)("div", {
                className: "grid w-full max-w-md grid-cols-3 gap-3",
                children: u.map((e) =>
                  (0, t.jsxs)(
                    "button",
                    {
                      type: "button",
                      className: (0, r.cn)(
                        "flex min-h-[120px] w-full flex-col items-center gap-3 rounded-xl border border-transparent bg-correct-bg p-3 transition-colors duration-150 active:scale-[0.97] active:bg-correct-border",
                        f ? "justify-center" : "justify-start",
                      ),
                      "data-nr": "choose-your-hero-btn",
                      onClick: () => {
                        var t;
                        return (
                          (t = e.id),
                          void (a.accessSessionStorageUtil.setItem(h, t),
                          c.accessCookie.setItem(o.ECookieArg.SELECTED_HERO_ID, t, { session: !0 }),
                          m?.())
                        );
                      },
                      children: [
                        (0, t.jsx)("div", {
                          className: "relative h-16 w-16 shrink-0 overflow-hidden rounded-full",
                          children: (0, t.jsx)(s.default, {
                            src: d.CHOOSE_YOUR_HERO_IMAGE_MAP[e.id],
                            alt: f ? "" : x(`choose_your_hero_${e.id}`),
                            fill: !0,
                            className: "object-cover object-top",
                            sizes: "70px",
                            unoptimized: !0,
                            priority: !0,
                          }),
                        }),
                        !f &&
                          (0, t.jsx)("span", {
                            className:
                              "flex min-h-[2.5rem] flex-col items-center justify-center whitespace-pre-line text-center text-sm font-medium text-default-700",
                            children: x(`choose_your_hero_${e.id}`),
                          }),
                      ],
                    },
                    e.id,
                  ),
                ),
              }),
            ],
          }),
        });
      },
    ]);
  },
  215302,
  function (e) {
    e.n(e.i(424689));
  },
]);
