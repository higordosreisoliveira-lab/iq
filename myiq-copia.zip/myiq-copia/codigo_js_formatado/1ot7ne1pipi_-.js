(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  327445,
  (e) => {
    "use strict";
    var t = e.i(415944),
      r = e.i(595494),
      n = e.i(271645),
      a = e.i(843476),
      i = (0, n.forwardRef)(function (e, n) {
        var i, o;
        let s = (0, r.useProviderContext)(),
          c =
            null != (o = null != (i = e.validationBehavior) ? i : null == s ? void 0 : s.validationBehavior)
              ? o
              : "native";
        return (0, a.jsx)(t.Form, { ...e, ref: n, validationBehavior: c });
      });
    e.s(["Form", 0, i]);
  },
  900212,
  (e) => {
    "use strict";
    var t = e.i(834738),
      r = e.i(619110),
      n = e.i(271645),
      a = e.i(273830),
      i = e.i(843476),
      o = (0, a.forwardRef)((e, a) => {
        let {
            Component: o,
            label: s,
            description: c,
            isClearable: l,
            startContent: u,
            endContent: d,
            labelPlacement: p,
            hasHelper: f,
            isOutsideLeft: m,
            isOutsideTop: h,
            shouldLabelBeOutside: y,
            errorMessage: g,
            isInvalid: v,
            getBaseProps: b,
            getLabelProps: x,
            getInputProps: _,
            getInnerWrapperProps: C,
            getInputWrapperProps: E,
            getMainWrapperProps: S,
            getHelperWrapperProps: w,
            getDescriptionProps: N,
            getErrorMessageProps: R,
            getClearButtonProps: L,
          } = (0, t.useInput)({ ...e, ref: a }),
          j = s ? (0, i.jsx)("label", { ...x(), children: s }) : null,
          I = (0, n.useMemo)(
            () =>
              l ? (0, i.jsx)("button", { ...L(), children: d || (0, i.jsx)(r.CloseFilledIcon, {}) }) : d,
            [l, L],
          ),
          O = (0, n.useMemo)(() => {
            let e = v && g,
              t = e || c;
            return f && t
              ? (0, i.jsx)("div", {
                  ...w(),
                  children: e
                    ? (0, i.jsx)("div", { ...R(), children: g })
                    : (0, i.jsx)("div", { ...N(), children: c }),
                })
              : null;
          }, [f, v, g, c, w, R, N]),
          M = (0, n.useMemo)(
            () => (0, i.jsxs)("div", { ...C(), children: [u, (0, i.jsx)("input", { ..._() }), I] }),
            [u, I, _, C],
          ),
          P = (0, n.useMemo)(
            () =>
              y
                ? (0, i.jsxs)("div", {
                    ...S(),
                    children: [(0, i.jsxs)("div", { ...E(), children: [m || h ? null : j, M] }), O],
                  })
                : (0, i.jsxs)(i.Fragment, {
                    children: [(0, i.jsxs)("div", { ...E(), children: [j, M] }), O],
                  }),
            [p, O, y, j, M, g, c, S, E, R, N],
          );
        return (0, i.jsxs)(o, { ...b(), children: [m || h ? j : null, P] });
      });
    ((o.displayName = "HeroUI.Input"), e.s(["Input", 0, o], 900212));
  },
  882983,
  (e) => {
    "use strict";
    var t = e.i(265840),
      r = e.i(271645),
      n = e.i(273830),
      a = e.i(620253),
      i = e.i(75540),
      o = e.i(843476),
      s = (0, n.forwardRef)((e, n) => {
        let { as: s, children: c, className: l, ...u } = e,
          { slots: d, classNames: p, bodyId: f, setBodyMounted: m } = (0, t.useModalContext)(),
          h = (0, a.useDOMRef)(n);
        return (
          (0, r.useEffect)(() => (m(!0), () => m(!1)), [m]),
          (0, o.jsx)(s || "div", {
            ref: h,
            className: d.body({ class: (0, i.clsx)(null == p ? void 0 : p.body, l) }),
            id: f,
            ...u,
            children: c,
          })
        );
      });
    ((s.displayName = "HeroUI.ModalBody"), e.s(["ModalBody", 0, s], 882983));
  },
  398437,
  (e, t, r) => {
    "use strict";
    var n = e.r(179684),
      a = {
        childContextTypes: !0,
        contextType: !0,
        contextTypes: !0,
        defaultProps: !0,
        displayName: !0,
        getDefaultProps: !0,
        getDerivedStateFromError: !0,
        getDerivedStateFromProps: !0,
        mixins: !0,
        propTypes: !0,
        type: !0,
      },
      i = { name: !0, length: !0, prototype: !0, caller: !0, callee: !0, arguments: !0, arity: !0 },
      o = { $$typeof: !0, compare: !0, defaultProps: !0, displayName: !0, propTypes: !0, type: !0 },
      s = {};
    function c(e) {
      return n.isMemo(e) ? o : s[e.$$typeof] || a;
    }
    ((s[n.ForwardRef] = { $$typeof: !0, render: !0, defaultProps: !0, displayName: !0, propTypes: !0 }),
      (s[n.Memo] = o));
    var l = Object.defineProperty,
      u = Object.getOwnPropertyNames,
      d = Object.getOwnPropertySymbols,
      p = Object.getOwnPropertyDescriptor,
      f = Object.getPrototypeOf,
      m = Object.prototype;
    t.exports = function e(t, r, n) {
      if ("string" != typeof r) {
        if (m) {
          var a = f(r);
          a && a !== m && e(t, a, n);
        }
        var o = u(r);
        d && (o = o.concat(d(r)));
        for (var s = c(t), h = c(r), y = 0; y < o.length; ++y) {
          var g = o[y];
          if (!i[g] && !(n && n[g]) && !(h && h[g]) && !(s && s[g])) {
            var v = p(r, g);
            try {
              l(t, g, v);
            } catch (e) {}
          }
        }
      }
      return t;
    };
  },
  455263,
  (e) => {
    "use strict";
    var t,
      r,
      n = e.i(271645),
      a = e.i(745009),
      i = [
        "sitekey",
        "onChange",
        "theme",
        "type",
        "tabindex",
        "onExpired",
        "onErrored",
        "size",
        "stoken",
        "grecaptcha",
        "badge",
        "hl",
        "isolated",
      ];
    function o() {
      return (o = Object.assign.bind()).apply(this, arguments);
    }
    function s(e) {
      if (void 0 === e) throw ReferenceError("this hasn't been initialised - super() hasn't been called");
      return e;
    }
    function c(e, t) {
      return (c = Object.setPrototypeOf
        ? Object.setPrototypeOf.bind()
        : function (e, t) {
            return ((e.__proto__ = t), e);
          })(e, t);
    }
    var l = (function (e) {
      function t() {
        var t;
        return (
          ((t = e.call(this) || this).handleExpired = t.handleExpired.bind(s(t))),
          (t.handleErrored = t.handleErrored.bind(s(t))),
          (t.handleChange = t.handleChange.bind(s(t))),
          (t.handleRecaptchaRef = t.handleRecaptchaRef.bind(s(t))),
          t
        );
      }
      ((t.prototype = Object.create(e.prototype)), (t.prototype.constructor = t), c(t, e));
      var r = t.prototype;
      return (
        (r.getCaptchaFunction = function (e) {
          return this.props.grecaptcha
            ? this.props.grecaptcha.enterprise
              ? this.props.grecaptcha.enterprise[e]
              : this.props.grecaptcha[e]
            : null;
        }),
        (r.getValue = function () {
          var e = this.getCaptchaFunction("getResponse");
          return e && void 0 !== this._widgetId ? e(this._widgetId) : null;
        }),
        (r.getWidgetId = function () {
          return this.props.grecaptcha && void 0 !== this._widgetId ? this._widgetId : null;
        }),
        (r.execute = function () {
          var e = this.getCaptchaFunction("execute");
          if (e && void 0 !== this._widgetId) return e(this._widgetId);
          this._executeRequested = !0;
        }),
        (r.executeAsync = function () {
          var e = this;
          return new Promise(function (t, r) {
            ((e.executionResolve = t), (e.executionReject = r), e.execute());
          });
        }),
        (r.reset = function () {
          var e = this.getCaptchaFunction("reset");
          e && void 0 !== this._widgetId && e(this._widgetId);
        }),
        (r.forceReset = function () {
          var e = this.getCaptchaFunction("reset");
          e && e();
        }),
        (r.handleExpired = function () {
          this.props.onExpired ? this.props.onExpired() : this.handleChange(null);
        }),
        (r.handleErrored = function () {
          (this.props.onErrored && this.props.onErrored(),
            this.executionReject &&
              (this.executionReject(), delete this.executionResolve, delete this.executionReject));
        }),
        (r.handleChange = function (e) {
          (this.props.onChange && this.props.onChange(e),
            this.executionResolve &&
              (this.executionResolve(e), delete this.executionReject, delete this.executionResolve));
        }),
        (r.explicitRender = function () {
          var e = this.getCaptchaFunction("render");
          if (e && void 0 === this._widgetId) {
            var t = document.createElement("div");
            ((this._widgetId = e(t, {
              sitekey: this.props.sitekey,
              callback: this.handleChange,
              theme: this.props.theme,
              type: this.props.type,
              tabindex: this.props.tabindex,
              "expired-callback": this.handleExpired,
              "error-callback": this.handleErrored,
              size: this.props.size,
              stoken: this.props.stoken,
              hl: this.props.hl,
              badge: this.props.badge,
              isolated: this.props.isolated,
            })),
              this.captcha.appendChild(t));
          }
          this._executeRequested &&
            this.props.grecaptcha &&
            void 0 !== this._widgetId &&
            ((this._executeRequested = !1), this.execute());
        }),
        (r.componentDidMount = function () {
          this.explicitRender();
        }),
        (r.componentDidUpdate = function () {
          this.explicitRender();
        }),
        (r.handleRecaptchaRef = function (e) {
          this.captcha = e;
        }),
        (r.render = function () {
          var e = this.props,
            t =
              (e.sitekey,
              e.onChange,
              e.theme,
              e.type,
              e.tabindex,
              e.onExpired,
              e.onErrored,
              e.size,
              e.stoken,
              e.grecaptcha,
              e.badge,
              e.hl,
              e.isolated,
              (function (e, t) {
                if (null == e) return {};
                var r,
                  n,
                  a = {},
                  i = Object.keys(e);
                for (n = 0; n < i.length; n++) ((r = i[n]), t.indexOf(r) >= 0 || (a[r] = e[r]));
                return a;
              })(e, i));
          return n.createElement("div", o({}, t, { ref: this.handleRecaptchaRef }));
        }),
        t
      );
    })(n.Component);
    ((l.displayName = "ReCAPTCHA"),
      (l.propTypes = {
        sitekey: a.default.string.isRequired,
        onChange: a.default.func,
        grecaptcha: a.default.object,
        theme: a.default.oneOf(["dark", "light"]),
        type: a.default.oneOf(["image", "audio"]),
        tabindex: a.default.number,
        onExpired: a.default.func,
        onErrored: a.default.func,
        size: a.default.oneOf(["compact", "normal", "invisible"]),
        stoken: a.default.string,
        hl: a.default.string,
        badge: a.default.oneOf(["bottomright", "bottomleft", "inline"]),
        isolated: a.default.bool,
      }),
      (l.defaultProps = {
        onChange: function () {},
        theme: "light",
        type: "image",
        tabindex: 0,
        size: "normal",
        badge: "bottomright",
      }));
    var u = e.i(398437);
    function d() {
      return (d =
        Object.assign ||
        function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = arguments[t];
            for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
          }
          return e;
        }).apply(this, arguments);
    }
    var p = {},
      f = 0,
      m = "onloadcallback";
    function h() {
      return ("u" > typeof window && window.recaptchaOptions) || {};
    }
    let y = ((t = function () {
      var e = h(),
        t = e.useRecaptchaNet ? "recaptcha.net" : "www.google.com";
      return e.enterprise
        ? "https://" + t + "/recaptcha/enterprise.js?onload=" + m + "&render=explicit"
        : "https://" + t + "/recaptcha/api.js?onload=" + m + "&render=explicit";
    }),
    (r = r =
      { callbackName: m, globalName: "grecaptcha", attributes: h().nonce ? { nonce: h().nonce } : {} }),
    function (e) {
      var i = e.displayName || e.name || "Component",
        o = (function (a) {
          function i(e, t) {
            var r;
            return (((r = a.call(this, e, t) || this).state = {}), (r.__scriptURL = ""), r);
          }
          ((i.prototype = Object.create(a.prototype)), (i.prototype.constructor = i), (i.__proto__ = a));
          var o = i.prototype;
          return (
            (o.asyncScriptLoaderGetScriptLoaderID = function () {
              return (
                this.__scriptLoaderID || (this.__scriptLoaderID = "async-script-loader-" + f++),
                this.__scriptLoaderID
              );
            }),
            (o.setupScriptURL = function () {
              return ((this.__scriptURL = "function" == typeof t ? t() : t), this.__scriptURL);
            }),
            (o.asyncScriptLoaderHandleLoad = function (e) {
              var t = this;
              this.setState(e, function () {
                return t.props.asyncScriptOnLoad && t.props.asyncScriptOnLoad(t.state);
              });
            }),
            (o.asyncScriptLoaderTriggerOnScriptLoaded = function () {
              var e = p[this.__scriptURL];
              if (!e || !e.loaded) throw Error("Script is not loaded.");
              for (var t in e.observers) e.observers[t](e);
              delete window[r.callbackName];
            }),
            (o.componentDidMount = function () {
              var e = this,
                t = this.setupScriptURL(),
                n = this.asyncScriptLoaderGetScriptLoaderID(),
                a = r,
                i = a.globalName,
                o = a.callbackName,
                s = a.scriptId;
              if ((i && void 0 !== window[i] && (p[t] = { loaded: !0, observers: {} }), p[t])) {
                var c = p[t];
                return c && (c.loaded || c.errored)
                  ? void this.asyncScriptLoaderHandleLoad(c)
                  : void (c.observers[n] = function (t) {
                      return e.asyncScriptLoaderHandleLoad(t);
                    });
              }
              var l = {};
              ((l[n] = function (t) {
                return e.asyncScriptLoaderHandleLoad(t);
              }),
                (p[t] = { loaded: !1, observers: l }));
              var u = document.createElement("script");
              for (var d in ((u.src = t), (u.async = !0), r.attributes)) u.setAttribute(d, r.attributes[d]);
              s && (u.id = s);
              var f = function (e) {
                if (p[t]) {
                  var r = p[t].observers;
                  for (var n in r) e(r[n]) && delete r[n];
                }
              };
              (o &&
                "u" > typeof window &&
                (window[o] = function () {
                  return e.asyncScriptLoaderTriggerOnScriptLoaded();
                }),
                (u.onload = function () {
                  var e = p[t];
                  e &&
                    ((e.loaded = !0),
                    f(function (t) {
                      return !o && (t(e), !0);
                    }));
                }),
                (u.onerror = function () {
                  var e = p[t];
                  e &&
                    ((e.errored = !0),
                    f(function (t) {
                      return (t(e), !0);
                    }));
                }),
                document.body.appendChild(u));
            }),
            (o.componentWillUnmount = function () {
              var e = this.__scriptURL;
              if (!0 === r.removeOnUnmount)
                for (var t = document.getElementsByTagName("script"), n = 0; n < t.length; n += 1)
                  t[n].src.indexOf(e) > -1 && t[n].parentNode && t[n].parentNode.removeChild(t[n]);
              var a = p[e];
              a &&
                (delete a.observers[this.asyncScriptLoaderGetScriptLoaderID()],
                !0 === r.removeOnUnmount && delete p[e]);
            }),
            (o.render = function () {
              var t = r.globalName,
                a = this.props,
                i = (a.asyncScriptOnLoad, a.forwardedRef),
                o = (function (e, t) {
                  if (null == e) return {};
                  var r,
                    n,
                    a = {},
                    i = Object.keys(e);
                  for (n = 0; n < i.length; n++) t.indexOf((r = i[n])) >= 0 || (a[r] = e[r]);
                  return a;
                })(a, ["asyncScriptOnLoad", "forwardedRef"]);
              return (
                t && "u" > typeof window && (o[t] = void 0 !== window[t] ? window[t] : void 0),
                (o.ref = i),
                (0, n.createElement)(e, o)
              );
            }),
            i
          );
        })(n.Component),
        s = (0, n.forwardRef)(function (e, t) {
          return (0, n.createElement)(o, d({}, e, { forwardedRef: t }));
        });
      return (
        (s.displayName = "AsyncScriptLoader(" + i + ")"),
        (s.propTypes = { asyncScriptOnLoad: a.default.func }),
        (0, u.default)(s, e)
      );
    })(l);
    e.s(["default", 0, y], 455263);
  },
  232189,
  (e, t, r) => {
    "use strict";
    t.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
  },
  865156,
  (e, t, r) => {
    "use strict";
    var n = e.r(232189);
    function a() {}
    function i() {}
    ((i.resetWarningCache = a),
      (t.exports = function () {
        function e(e, t, r, a, i, o) {
          if (o !== n) {
            var s = Error(
              "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types",
            );
            throw ((s.name = "Invariant Violation"), s);
          }
        }
        function t() {
          return e;
        }
        e.isRequired = e;
        var r = {
          array: e,
          bigint: e,
          bool: e,
          func: e,
          number: e,
          object: e,
          string: e,
          symbol: e,
          any: e,
          arrayOf: t,
          element: e,
          elementType: e,
          instanceOf: t,
          node: e,
          objectOf: t,
          oneOf: t,
          oneOfType: t,
          shape: t,
          exact: t,
          checkPropTypes: i,
          resetWarningCache: a,
        };
        return ((r.PropTypes = r), r);
      }));
  },
  745009,
  (e, t, r) => {
    (e.i(247167), (t.exports = e.r(865156)()));
  },
  552210,
  (e, t, r) => {
    "use strict";
    var n = "function" == typeof Symbol && Symbol.for,
      a = n ? Symbol.for("react.element") : 60103,
      i = n ? Symbol.for("react.portal") : 60106,
      o = n ? Symbol.for("react.fragment") : 60107,
      s = n ? Symbol.for("react.strict_mode") : 60108,
      c = n ? Symbol.for("react.profiler") : 60114,
      l = n ? Symbol.for("react.provider") : 60109,
      u = n ? Symbol.for("react.context") : 60110,
      d = n ? Symbol.for("react.async_mode") : 60111,
      p = n ? Symbol.for("react.concurrent_mode") : 60111,
      f = n ? Symbol.for("react.forward_ref") : 60112,
      m = n ? Symbol.for("react.suspense") : 60113,
      h = n ? Symbol.for("react.suspense_list") : 60120,
      y = n ? Symbol.for("react.memo") : 60115,
      g = n ? Symbol.for("react.lazy") : 60116,
      v = n ? Symbol.for("react.block") : 60121,
      b = n ? Symbol.for("react.fundamental") : 60117,
      x = n ? Symbol.for("react.responder") : 60118,
      _ = n ? Symbol.for("react.scope") : 60119;
    function C(e) {
      if ("object" == typeof e && null !== e) {
        var t = e.$$typeof;
        switch (t) {
          case a:
            switch ((e = e.type)) {
              case d:
              case p:
              case o:
              case c:
              case s:
              case m:
                return e;
              default:
                switch ((e = e && e.$$typeof)) {
                  case u:
                  case f:
                  case g:
                  case y:
                  case l:
                    return e;
                  default:
                    return t;
                }
            }
          case i:
            return t;
        }
      }
    }
    function E(e) {
      return C(e) === p;
    }
    ((r.AsyncMode = d),
      (r.ConcurrentMode = p),
      (r.ContextConsumer = u),
      (r.ContextProvider = l),
      (r.Element = a),
      (r.ForwardRef = f),
      (r.Fragment = o),
      (r.Lazy = g),
      (r.Memo = y),
      (r.Portal = i),
      (r.Profiler = c),
      (r.StrictMode = s),
      (r.Suspense = m),
      (r.isAsyncMode = function (e) {
        return E(e) || C(e) === d;
      }),
      (r.isConcurrentMode = E),
      (r.isContextConsumer = function (e) {
        return C(e) === u;
      }),
      (r.isContextProvider = function (e) {
        return C(e) === l;
      }),
      (r.isElement = function (e) {
        return "object" == typeof e && null !== e && e.$$typeof === a;
      }),
      (r.isForwardRef = function (e) {
        return C(e) === f;
      }),
      (r.isFragment = function (e) {
        return C(e) === o;
      }),
      (r.isLazy = function (e) {
        return C(e) === g;
      }),
      (r.isMemo = function (e) {
        return C(e) === y;
      }),
      (r.isPortal = function (e) {
        return C(e) === i;
      }),
      (r.isProfiler = function (e) {
        return C(e) === c;
      }),
      (r.isStrictMode = function (e) {
        return C(e) === s;
      }),
      (r.isSuspense = function (e) {
        return C(e) === m;
      }),
      (r.isValidElementType = function (e) {
        return (
          "string" == typeof e ||
          "function" == typeof e ||
          e === o ||
          e === p ||
          e === c ||
          e === s ||
          e === m ||
          e === h ||
          ("object" == typeof e &&
            null !== e &&
            (e.$$typeof === g ||
              e.$$typeof === y ||
              e.$$typeof === l ||
              e.$$typeof === u ||
              e.$$typeof === f ||
              e.$$typeof === b ||
              e.$$typeof === x ||
              e.$$typeof === _ ||
              e.$$typeof === v))
        );
      }),
      (r.typeOf = C));
  },
  179684,
  (e, t, r) => {
    "use strict";
    (e.i(247167), (t.exports = e.r(552210)));
  },
  507003,
  764931,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(900212),
      n = e.i(663615),
      a = e.i(360067);
    (e.s([], 507003),
      e.s(
        [
          "InputComponent",
          0,
          (e) => {
            let {
              name: i,
              label: o,
              value: s = "",
              onChange: c,
              errorMessage: l,
              isDisabled: u = !1,
              maxLength: d,
              validate: p,
              inputMode: f = "text",
              required: m = !1,
              placeholder: h = "",
              isInvalid: y = !1,
              ref: g,
              onFocus: v = () => {},
              onBlur: b = () => {},
              autoComplete: x,
              dataCy: _,
              dir: C,
              inputWrapperClassName: E,
              labelClassName: S,
            } = e;
            return (0, t.jsxs)("div", {
              className: "flex w-full flex-col gap-1",
              children: [
                o && (0, t.jsx)("span", { className: (0, n.cn)("text-xs", S), children: o }),
                (0, t.jsx)(r.Input, {
                  name: i,
                  value: s,
                  onChange: (e) => {
                    c((0, a.sanitizeNameInput)(e.target.value.trimStart()));
                  },
                  inputMode: f,
                  required: m,
                  isDisabled: u,
                  autoCapitalize: "none",
                  maxLength: d,
                  autoComplete: x,
                  dir: C,
                  ref: g,
                  "data-cy": _,
                  size: "lg",
                  radius: "md",
                  onFocus: v,
                  onBlur: b,
                  labelPlacement: "outside",
                  placeholder: h,
                  isInvalid: y,
                  variant: "bordered",
                  className: "data-focus:border data-focus:border-primary mx-auto w-full",
                  classNames: {
                    errorMessage: "text-left",
                    input: "text-medium min-h-[56px] focus:outline-none focus:ring-0",
                    inputWrapper: (0, n.cn)("border border-default-300 focus-within:!border-primary-200", E),
                  },
                  errorMessage: l,
                  validate: (e) => !p || p(e),
                }),
              ],
            });
          },
        ],
        764931,
      ));
  },
  56339,
  (e) => {
    "use strict";
    e.i(944301);
    var t = e.i(820652),
      r = e.i(933837);
    e.s([
      "EnterNameCertificateFormComponent",
      () => t.default,
      "EnterNameCertificateModalComponent",
      () => r.default,
    ]);
  },
  739939,
  function (e) {
    e.n(e.i(56339));
  },
  944301,
  820652,
  933837,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(948148),
      n = e.i(271645),
      a = e.i(455263),
      i = e.i(653145),
      o = e.i(663615),
      s = e.i(327445);
    e.i(507003);
    var c = e.i(764931),
      l = e.i(134404);
    e.i(568267);
    var u = e.i(154692),
      d = e.i(38691),
      p = e.i(210209),
      f = e.i(382963),
      m = e.i(523173),
      h = e.i(622963),
      y = e.i(86596),
      g = e.i(360067);
    e.i(756503);
    var v = e.i(542516);
    e.i(470366);
    var b = e.i(504001),
      x = e.i(202042);
    e.i(682770);
    var _ = e.i(934952);
    let C = (e) => {
      let {
          user: C,
          isClosable: E = !0,
          handleDownloadCertificate: S,
          onNameSaved: w,
          onNameSubmitted: N,
          submitText: R,
          isAuthenticated: L = !0,
          isOverlay: j = !1,
          isRedesign: I = !1,
          onSubmitName: O,
          helperText: M,
        } = e,
        P = (0, r.useTranslations)(),
        T = (0, x.usePathname)() === l.EClientRoutes.CERTIFICATE,
        $ = (0, n.useRef)(null),
        { data: A } = (0, f.useGetProfileQuery)(C?.email || "");
      ((0, n.useEffect)(() => {
        (0, b.trackClientEvents)({ event: m.EAnalyticEvents.NAME_VIEWED, user: C });
      }, []),
        (0, n.useEffect)(() => {
          if (!T) return;
          let e = document.createElement("style");
          return (
            (e.textContent = ".grecaptcha-badge { visibility: hidden !important; }"),
            document.head.appendChild(e),
            () => {
              document.head.removeChild(e);
            }
          );
        }, [T]));
      let k = A?.data?.user_info ? A?.data?.user_info : C,
        { trigger: F, isPending: z } = (0, f.useUpdateUserInDatabaseMutation)(),
        { handleChangeUserStore: D } = (0, y.useUserStore)(),
        U = C?.username || k?.username || (0, p.getSuggestedCertificateName)(k || C),
        B = (0, g.sanitizeNameInput)(U),
        {
          handleSubmit: H,
          control: q,
          formState: V,
          setValue: W,
        } = (0, i.useForm)({ mode: "onChange", defaultValues: { username: B } }),
        G = (0, n.useRef)(null);
      (0, n.useEffect)(() => {
        let e = G.current;
        if (!e) return;
        let t = () => {
          W("username", (0, g.sanitizeNameInput)(e.value.trimStart()), {
            shouldValidate: !0,
            shouldDirty: !0,
          });
        };
        return (
          e.addEventListener("input", t),
          e.addEventListener("change", t),
          () => {
            (e.removeEventListener("input", t), e.removeEventListener("change", t));
          }
        );
      }, [W]);
      let Z = (0, h.useModalStore)((e) => e.handleChangeModalStore),
        K = () => {
          Z({ isModalVisible: !1, modalComponent: null });
        },
        X = async (e) => {
          let t = (0, g.sanitizeNameInput)(e.username);
          N?.(t);
          try {
            if ((T && (await (0, d.executeInvisibleCaptcha)($.current)), O)) {
              if (!(await O(t))) return;
              (E && K(), await w?.());
              return;
            }
            let e = {};
            (t !== k?.username && (e.username = t),
              L && (await F({ email: C?.email || "", userInfo: e })),
              D({ user: { email: C?.email || "", username: t } }),
              (0, b.trackClientEvents)({
                event: m.EAnalyticEvents.PAGE_CLICKED,
                user: C,
                params: { page_name: "NameSubmitted" },
              }),
              E && "enter-name-certificate" === h.useModalStore.getState().modalComponent && K(),
              S && (await S()),
              w && (await w()));
          } catch (e) {
            (0, _.customToast)(e?.message || "Something went wrong", "error");
          }
        };
      return (0, t.jsxs)(s.Form, {
        validationBehavior: "aria",
        className: (0, o.cn)("flex w-full flex-col", I ? "gap-5" : "gap-4"),
        onSubmit: H(X),
        children: [
          T &&
            (0, t.jsx)(a.default, {
              ref: $,
              sitekey: v.envClient.NEXT_PUBLIC_RE_CAPTCHA_INVISIBLE_KEY ?? "",
              size: "invisible",
              badge: "bottomright",
            }),
          (0, t.jsx)(
            i.Controller,
            {
              control: q,
              name: "username",
              render: (e) => {
                let {
                  field: { value: r, onChange: n },
                  fieldState: { error: a },
                } = e;
                return (0, t.jsx)(c.InputComponent, {
                  ref: G,
                  name: "username",
                  placeholder: P("profile_page_name_modal_input"),
                  value: r,
                  onChange: n,
                  errorMessage: a?.message,
                  isDisabled: V.isSubmitting || z,
                  maxLength: g.NAME_MAX_LENGTH,
                  inputWrapperClassName: j ? "bg-white" : void 0,
                  required: !0,
                  validate: (e) => (0, g.validateName)(e, P),
                });
              },
              rules: {
                pattern: (0, g.maxLengthPattern)(g.NAME_MAX_LENGTH, P) && g.namePattern,
                required: (0, g.getRequiredMessage)(P),
              },
            },
            "username",
          ),
          !!M && (0, t.jsx)("p", { className: "-mt-2 text-sm text-gray-500", children: M }),
          (0, t.jsxs)("div", {
            className: (0, o.cn)("flex w-full flex-col", I ? "gap-3" : "gap-2.5", !I && !j && "mt-4"),
            children: [
              (0, t.jsx)(u.ButtonComponent, {
                size: "sm",
                type: "submit",
                isDisabled: !V.isValid || (!B && !V.isDirty) || V.isSubmitting,
                text:
                  R ??
                  (S
                    ? P("certificate_card_enter_name_modal_download_certificate")
                    : P("certificate_card_enter_name_modal_reveal_certificate")),
                isLoading: V.isSubmitting || z,
              }),
              E &&
                (0, t.jsx)(u.ButtonComponent, {
                  onClick: K,
                  variant: "default",
                  size: "sm",
                  className: "block md:hidden",
                  isDisabled: V.isSubmitting || z,
                  children: P("btn_cancel"),
                }),
            ],
          }),
        ],
      });
    };
    (e.s(["default", 0, C], 820652), e.i(317197));
    var E = e.i(231529);
    (e.s(
      [
        "default",
        0,
        (e) => {
          let {
              user: a,
              isClosable: i = !0,
              handleDownloadCertificate: o,
              onNameSaved: s,
              onNameSubmitted: c,
              subtitle: l,
              submitText: u,
              isAuthenticated: d,
              isRedesign: p,
              onSubmitName: f,
              helperText: h,
            } = e,
            y = (0, r.useTranslations)();
          return (
            (0, n.useEffect)(() => {
              (0, b.trackClientEvents)({ event: m.EAnalyticEvents.NAME_VIEWED, user: a });
            }, []),
            (0, t.jsx)(E.ModalBodyComponent, {
              title: y("certificate_card_enter_name_modal_title"),
              subtitle: l || y("certificate_card_enter_name_modal_subtitle"),
              bodyClassName: p ? "gap-4" : void 0,
              children: (0, t.jsx)(C, {
                isClosable: i,
                user: a,
                handleDownloadCertificate: o,
                onNameSaved: s,
                onNameSubmitted: c,
                submitText: u,
                isAuthenticated: d,
                isRedesign: p,
                onSubmitName: f,
                helperText: h,
              }),
            })
          );
        },
      ],
      933837,
    ),
      e.s([], 944301));
  },
  317197,
  231529,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(882983),
      n = e.i(742214),
      a = e.i(663615);
    e.i(680460);
    var i = e.i(885944);
    (e.s([], 317197),
      e.s(
        [
          "ModalBodyComponent",
          0,
          (e) => {
            let {
              children: o,
              title: s,
              subtitle: c,
              className: l = "",
              bodyClassName: u,
              titleClassName: d,
            } = e;
            return (0, t.jsx)(n.ModalContent, {
              className: l,
              children: (0, t.jsxs)(r.ModalBody, {
                className: (0, a.cn)(
                  "flex h-full w-full flex-col gap-5 p-5 antialiased md:p-6 [@media(max-height:580px)]:gap-3 [@media(max-height:580px)]:p-4",
                  u,
                ),
                children: [
                  (s || c) &&
                    (0, t.jsx)(i.ModalHeaderComponent, { title: s, subtitle: c, titleClassName: d }),
                  o,
                ],
              }),
            });
          },
        ],
        231529,
      ));
  },
  38691,
  (e) => {
    "use strict";
    let t = async function (e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 5e3;
      if (!e) return null;
      try {
        return (
          e.reset(),
          await Promise.race([e.executeAsync(), new Promise((e) => setTimeout(() => e(null), t))])
        );
      } catch {
        return null;
      }
    };
    e.s(["executeInvisibleCaptcha", 0, t]);
  },
  210209,
  (e) => {
    "use strict";
    var t = e.i(360067);
    e.s([
      "getPayerNameFromCheckoutResult",
      0,
      (e) => {
        let t = ((e) => {
          let [t = "", ...r] = e
            .replace(/^[-_\s]+/, "")
            .trim()
            .split(/\s+/);
          return { firstName: t, lastName: r.join(" ") };
        })(e?.customer?.full_name || "");
        if (t.firstName) return t;
        let r = e?.payment_method?.details?.payer_info;
        return { firstName: (r?.first_name || "").trim(), lastName: (r?.last_name || "").trim() };
      },
      "getSuggestedCertificateName",
      0,
      (e) =>
        ((e) => {
          let r,
            n,
            a = (0, t.sanitizeNameInput)(e || "")
              .replace(/[^\p{L}\p{M}\s'-]/gu, "")
              .replace(/\s+/g, " ")
              .replace(/^[-\s]+/, "")
              .slice(0, 35)
              .trim();
          return a.length < 2
            ? ""
            : ((r = a === a.toLocaleUpperCase()),
              (n = a === a.toLocaleLowerCase()),
              r || n
                ? a.toLocaleLowerCase().replace(/(^|[\s'-])(\p{L})/gu, (e, t, r) => t + r.toLocaleUpperCase())
                : a);
        })([e?.firstName, e?.lastName].filter(Boolean).join(" ")),
    ]);
  },
  360067,
  (e) => {
    "use strict";
    let t = { value: /^[\p{L}\p{M}\s'][\p{L}\p{M}\s'-]*$/u, message: "error_name_format" },
      r = (e) => e.replace(/[\u200E\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g, "");
    e.s([
      "NAME_MAX_LENGTH",
      0,
      35,
      "emailPattern",
      0,
      {
        value:
          /^(?=.{1,311}$)([a-zA-Z0-9_](?:[a-zA-Z0-9_.+-]*(?:\.[a-zA-Z0-9_.+-]+)*[a-zA-Z0-9_])?@[a-zA-Z0-9]+(?:[.-][a-zA-Z0-9]+)*\.[a-zA-Z]{2,})$/,
        message: "error_email_format",
      },
      "getRequiredMessage",
      0,
      (e) => e("error_required_field"),
      "maxLengthPattern",
      0,
      (e, t) => ({ value: RegExp(`^.{2,${e}}$`), message: t("error_max_characters", { count: `${e}` }) }),
      "minLength2Pattern",
      0,
      { value: /^.{2,}$/, message: "error_min_2_characters" },
      "namePattern",
      0,
      t,
      "sanitizeNameInput",
      0,
      r,
      "validateName",
      0,
      (e, n) => {
        let a = r(e);
        return a && a.trim().length > 0 && !t.value.test(a)
          ? n("error_name_format")
          : a.length > 35
            ? n("error_max_characters", { count: "35" })
            : null;
      },
    ]);
  },
]);
