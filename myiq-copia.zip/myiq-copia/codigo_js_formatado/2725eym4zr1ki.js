(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  605500,
  (e, t, i) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(i, "__esModule", { value: !0 }),
      Object.defineProperty(i, "Image", {
        enumerable: !0,
        get: function () {
          return x;
        },
      }));
    let a = e.r(555682),
      r = e.r(190809),
      n = e.r(843476),
      s = r._(e.r(271645)),
      l = a._(e.r(174080)),
      o = a._(e.r(325633)),
      c = e.r(908927),
      h = e.r(987690),
      d = e.r(918556),
      m = e.r(65856),
      u = a._(e.r(1948)),
      A = e.r(818581),
      v = {
        deviceSizes: [640, 1080, 1920],
        imageSizes: [16, 64, 128],
        qualities: [75],
        path: "/_next/image",
        loader: "default",
        dangerouslyAllowSVG: !1,
        unoptimized: !0,
      };
    function p(e, t, i, a, r, n, s) {
      let l = e?.src;
      e &&
        e["data-loaded-src"] !== l &&
        ((e["data-loaded-src"] = l),
        ("decode" in e ? e.decode() : Promise.resolve())
          .catch(() => {})
          .then(() => {
            if (e.parentElement && e.isConnected) {
              if (("empty" !== t && r(!0), i?.current)) {
                let t = new Event("load");
                Object.defineProperty(t, "target", { writable: !1, value: e });
                let a = !1,
                  r = !1;
                i.current({
                  ...t,
                  nativeEvent: t,
                  currentTarget: e,
                  target: e,
                  isDefaultPrevented: () => a,
                  isPropagationStopped: () => r,
                  persist: () => {},
                  preventDefault: () => {
                    ((a = !0), t.preventDefault());
                  },
                  stopPropagation: () => {
                    ((r = !0), t.stopPropagation());
                  },
                });
              }
              a?.current && a.current(e);
            }
          }));
    }
    function g(e) {
      return s.use ? { fetchPriority: e } : { fetchpriority: e };
    }
    "u" < typeof window && (globalThis.__NEXT_IMAGE_IMPORTED = !0);
    let f = "u" < typeof window ? s.useEffect : s.useLayoutEffect,
      _ = (0, s.forwardRef)((e, t) => {
        let {
            src: i,
            srcSet: a,
            sizes: r,
            height: l,
            width: o,
            decoding: c,
            className: h,
            style: d,
            fetchPriority: m,
            placeholder: u,
            loading: v,
            unoptimized: _,
            fill: b,
            onLoadRef: x,
            onLoadingCompleteRef: y,
            setBlurComplete: w,
            setShowAltText: z,
            sizesInput: M,
            onLoad: j,
            onError: E,
            ...k
          } = e,
          N = (0, s.useRef)(!1),
          C = (0, s.useRef)(null);
        f(() => {
          let { current: e } = N,
            { current: t } = C;
          e || null === t || (E && (t.src = t.src), t.complete && p(t, u, x, y, w, _, M), (N.current = !0));
        }, [i, u, x, y, E, _, M]);
        let q = (0, A.useMergedRef)(t, C);
        return (0, n.jsx)("img", {
          ...k,
          ...g(m),
          loading: v,
          width: o,
          height: l,
          decoding: c,
          "data-nimg": b ? "fill" : "1",
          className: h,
          style: d,
          sizes: r,
          srcSet: a,
          src: i,
          ref: q,
          onLoad: (e) => {
            p(e.currentTarget, u, x, y, w, _, M);
          },
          onError: (e) => {
            (z(!0), "empty" !== u && w(!0), E && E(e));
          },
        });
      });
    function b(e) {
      let { isAppRouter: t, imgAttributes: i } = e,
        a = {
          as: "image",
          imageSrcSet: i.srcSet,
          imageSizes: i.sizes,
          crossOrigin: i.crossOrigin,
          referrerPolicy: i.referrerPolicy,
          ...g(i.fetchPriority),
        };
      return t && l.default.preload
        ? (l.default.preload(i.src, a), null)
        : (0, n.jsx)(o.default, {
            children: (0, n.jsx)(
              "link",
              { rel: "preload", href: i.srcSet ? void 0 : i.src, ...a },
              "__nimg-" + i.src + i.srcSet + i.sizes,
            ),
          });
    }
    let x = (0, s.forwardRef)((e, t) => {
      let i = (0, s.useContext)(m.RouterContext),
        a = (0, s.useContext)(d.ImageConfigContext),
        r = (0, s.useMemo)(() => {
          let e = v || a || h.imageConfigDefault,
            t = [...e.deviceSizes, ...e.imageSizes].sort((e, t) => e - t),
            i = e.deviceSizes.sort((e, t) => e - t),
            r = e.qualities?.sort((e, t) => e - t);
          return {
            ...e,
            allSizes: t,
            deviceSizes: i,
            qualities: r,
            localPatterns: "u" < typeof window ? a?.localPatterns : e.localPatterns,
          };
        }, [a]),
        { onLoad: l, onLoadingComplete: o } = e,
        A = (0, s.useRef)(l);
      (0, s.useEffect)(() => {
        A.current = l;
      }, [l]);
      let p = (0, s.useRef)(o);
      (0, s.useEffect)(() => {
        p.current = o;
      }, [o]);
      let [g, f] = (0, s.useState)(!1),
        [x, y] = (0, s.useState)(!1),
        { props: w, meta: z } = (0, c.getImgProps)(e, {
          defaultLoader: u.default,
          imgConf: r,
          blurComplete: g,
          showAltText: x,
        });
      return (0, n.jsxs)(n.Fragment, {
        children: [
          (0, n.jsx)(_, {
            ...w,
            unoptimized: z.unoptimized,
            placeholder: z.placeholder,
            fill: z.fill,
            onLoadRef: A,
            onLoadingCompleteRef: p,
            setBlurComplete: f,
            setShowAltText: y,
            sizesInput: e.sizes,
            ref: t,
          }),
          z.preload ? (0, n.jsx)(b, { isAppRouter: !i, imgAttributes: w }) : null,
        ],
      });
    });
    ("function" == typeof i.default || ("object" == typeof i.default && null !== i.default)) &&
      void 0 === i.default.__esModule &&
      (Object.defineProperty(i.default, "__esModule", { value: !0 }),
      Object.assign(i.default, i),
      (t.exports = i.default));
  },
  670965,
  (e, t, i) => {
    "use strict";
    function a(e, t) {
      let i = e || 75;
      return t?.qualities?.length
        ? t.qualities.reduce((e, t) => (Math.abs(t - i) < Math.abs(e - i) ? t : e), t.qualities[0])
        : i;
    }
    (Object.defineProperty(i, "__esModule", { value: !0 }),
      Object.defineProperty(i, "findClosestQuality", {
        enumerable: !0,
        get: function () {
          return a;
        },
      }));
  },
  908927,
  (e, t, i) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(i, "__esModule", { value: !0 }),
      Object.defineProperty(i, "getImgProps", {
        enumerable: !0,
        get: function () {
          return c;
        },
      }));
    let a = e.r(543369),
      r = e.r(488143),
      n = e.r(987690),
      s = ["-moz-initial", "fill", "none", "scale-down", void 0];
    function l(e) {
      return void 0 !== e.default;
    }
    function o(e) {
      return void 0 === e
        ? e
        : "number" == typeof e
          ? Number.isFinite(e)
            ? e
            : NaN
          : "string" == typeof e && /^[0-9]+$/.test(e)
            ? parseInt(e, 10)
            : NaN;
    }
    function c(e, t) {
      var i;
      let c,
        h,
        d,
        {
          src: m,
          sizes: u,
          unoptimized: A = !1,
          priority: v = !1,
          preload: p = !1,
          loading: g,
          className: f,
          quality: _,
          width: b,
          height: x,
          fill: y = !1,
          style: w,
          overrideSrc: z,
          onLoad: M,
          onLoadingComplete: j,
          placeholder: E = "empty",
          blurDataURL: k,
          fetchPriority: N,
          decoding: C = "async",
          layout: q,
          objectFit: I,
          objectPosition: S,
          lazyBoundary: R,
          lazyRoot: L,
          ...B
        } = e,
        { imgConf: P, showAltText: D, blurComplete: O, defaultLoader: T } = t,
        F = P || n.imageConfigDefault;
      if ("allSizes" in F) c = F;
      else {
        let e = [...F.deviceSizes, ...F.imageSizes].sort((e, t) => e - t),
          t = F.deviceSizes.sort((e, t) => e - t),
          i = F.qualities?.sort((e, t) => e - t);
        c = { ...F, allSizes: e, deviceSizes: t, qualities: i };
      }
      if (void 0 === T)
        throw Object.defineProperty(
          Error(
            "images.loaderFile detected but the file is missing default export.\nRead more: https://nextjs.org/docs/messages/invalid-images-config",
          ),
          "__NEXT_ERROR_CODE",
          { value: "E163", enumerable: !1, configurable: !0 },
        );
      let U = B.loader || T;
      (delete B.loader, delete B.srcSet);
      let W = "__next_img_default" in U;
      if (W) {
        if ("custom" === c.loader)
          throw Object.defineProperty(
            Error(`Image with src "${m}" is missing "loader" prop.
Read more: https://nextjs.org/docs/messages/next-image-missing-loader`),
            "__NEXT_ERROR_CODE",
            { value: "E252", enumerable: !1, configurable: !0 },
          );
      } else {
        let e = U;
        U = (t) => {
          let { config: i, ...a } = t;
          return e(a);
        };
      }
      if (q) {
        "fill" === q && (y = !0);
        let e = {
          intrinsic: { maxWidth: "100%", height: "auto" },
          responsive: { width: "100%", height: "auto" },
        }[q];
        e && (w = { ...w, ...e });
        let t = { responsive: "100vw", fill: "100vw" }[q];
        t && !u && (u = t);
      }
      let Q = "",
        V = o(b),
        K = o(x);
      if ((i = m) && "object" == typeof i && (l(i) || void 0 !== i.src)) {
        let e = l(m) ? m.default : m;
        if (!e.src)
          throw Object.defineProperty(
            Error(
              `An object should only be passed to the image component src parameter if it comes from a static image import. It must include src. Received ${JSON.stringify(e)}`,
            ),
            "__NEXT_ERROR_CODE",
            { value: "E460", enumerable: !1, configurable: !0 },
          );
        if (!e.height || !e.width)
          throw Object.defineProperty(
            Error(
              `An object should only be passed to the image component src parameter if it comes from a static image import. It must include height and width. Received ${JSON.stringify(e)}`,
            ),
            "__NEXT_ERROR_CODE",
            { value: "E48", enumerable: !1, configurable: !0 },
          );
        if (((h = e.blurWidth), (d = e.blurHeight), (k = k || e.blurDataURL), (Q = e.src), !y))
          if (V || K) {
            if (V && !K) {
              let t = V / e.width;
              K = Math.round(e.height * t);
            } else if (!V && K) {
              let t = K / e.height;
              V = Math.round(e.width * t);
            }
          } else ((V = e.width), (K = e.height));
      }
      let H = !v && !p && ("lazy" === g || void 0 === g);
      ((!(m = "string" == typeof m ? m : Q) || m.startsWith("data:") || m.startsWith("blob:")) &&
        ((A = !0), (H = !1)),
        c.unoptimized && (A = !0),
        W && !c.dangerouslyAllowSVG && m.split("?", 1)[0].endsWith(".svg") && (A = !0));
      let G = o(_),
        $ = Object.assign(
          y
            ? {
                position: "absolute",
                height: "100%",
                width: "100%",
                left: 0,
                top: 0,
                right: 0,
                bottom: 0,
                objectFit: I,
                objectPosition: S,
              }
            : {},
          D ? {} : { color: "transparent" },
          w,
        ),
        X =
          O || "empty" === E
            ? null
            : "blur" === E
              ? `url("data:image/svg+xml;charset=utf-8,${(0, r.getImageBlurSvg)({ widthInt: V, heightInt: K, blurWidth: h, blurHeight: d, blurDataURL: k || "", objectFit: $.objectFit })}")`
              : `url("${E}")`,
        Y = s.includes($.objectFit) ? ("fill" === $.objectFit ? "100% 100%" : "cover") : $.objectFit,
        J = X
          ? {
              backgroundSize: Y,
              backgroundPosition: $.objectPosition || "50% 50%",
              backgroundRepeat: "no-repeat",
              backgroundImage: X,
            }
          : {},
        Z = (function (e) {
          let { config: t, src: i, unoptimized: r, width: n, quality: s, sizes: l, loader: o } = e;
          if (r) {
            if (i.startsWith("/") && !i.startsWith("//")) {
              let e = (0, a.getDeploymentId)();
              if (i.includes("/_next/static/immutable") && !(0, a.getAssetToken)()) e = void 0;
              else if (e) {
                let t = i.indexOf("?");
                if (-1 !== t) {
                  let a = new URLSearchParams(i.slice(t + 1));
                  a.get("dpl") || (a.append("dpl", e), (i = i.slice(0, t) + "?" + a.toString()));
                } else i += `?dpl=${e}`;
              }
            }
            return { src: i, srcSet: void 0, sizes: void 0 };
          }
          let { widths: c, kind: h } = (function (e, t, i) {
              let { deviceSizes: a, allSizes: r } = e;
              if (i) {
                let e = /(^|\s)(1?\d?\d)vw/g,
                  t = [];
                for (let a; (a = e.exec(i));) t.push(parseInt(a[2]));
                if (t.length) {
                  let e = 0.01 * Math.min(...t);
                  return { widths: r.filter((t) => t >= a[0] * e), kind: "w" };
                }
                return { widths: r, kind: "w" };
              }
              return "number" != typeof t
                ? { widths: a, kind: "w" }
                : {
                    widths: [...new Set([t, 2 * t].map((e) => r.find((t) => t >= e) || r[r.length - 1]))],
                    kind: "x",
                  };
            })(t, n, l),
            d = c.length - 1;
          return {
            sizes: l || "w" !== h ? l : "100vw",
            srcSet: c
              .map((e, a) => `${o({ config: t, src: i, quality: s, width: e })} ${"w" === h ? e : a + 1}${h}`)
              .join(", "),
            src: o({ config: t, src: i, quality: s, width: c[d] }),
          };
        })({ config: c, src: m, unoptimized: A, width: V, quality: G, sizes: u, loader: U }),
        ee = H ? "lazy" : g;
      return {
        props: {
          ...B,
          loading: ee,
          fetchPriority: N,
          width: V,
          height: K,
          decoding: C,
          className: f,
          style: { ...$, ...J },
          sizes: Z.sizes,
          srcSet: Z.srcSet,
          src: z || Z.src,
        },
        meta: { unoptimized: A, preload: p || v, placeholder: E, fill: y },
      };
    }
  },
  325633,
  (e, t, i) => {
    "use strict";
    (e.i(247167), Object.defineProperty(i, "__esModule", { value: !0 }));
    var a = {
      default: function () {
        return v;
      },
      defaultHead: function () {
        return d;
      },
    };
    for (var r in a) Object.defineProperty(i, r, { enumerable: !0, get: a[r] });
    let n = e.r(555682),
      s = e.r(190809),
      l = e.r(843476),
      o = s._(e.r(271645)),
      c = n._(e.r(898879)),
      h = e.r(742732);
    function d() {
      return [
        (0, l.jsx)("meta", { charSet: "utf-8" }, "charset"),
        (0, l.jsx)("meta", { name: "viewport", content: "width=device-width" }, "viewport"),
      ];
    }
    function m(e, t) {
      return "string" == typeof t || "number" == typeof t
        ? e
        : t.type === o.default.Fragment
          ? e.concat(
              o.default.Children.toArray(t.props.children).reduce(
                (e, t) => ("string" == typeof t || "number" == typeof t ? e : e.concat(t)),
                [],
              ),
            )
          : e.concat(t);
    }
    let u = ["name", "httpEquiv", "charSet", "itemProp"];
    function A(e) {
      let t, i, a, r;
      return e
        .reduce(m, [])
        .reverse()
        .concat(d().reverse())
        .filter(
          ((t = new Set()),
          (i = new Set()),
          (a = new Set()),
          (r = {}),
          (e) => {
            let n = !0,
              s = !1;
            if (e.key && "number" != typeof e.key && e.key.indexOf("$") > 0) {
              s = !0;
              let i = e.key.slice(e.key.indexOf("$") + 1);
              t.has(i) ? (n = !1) : t.add(i);
            }
            switch (e.type) {
              case "title":
              case "base":
                i.has(e.type) ? (n = !1) : i.add(e.type);
                break;
              case "meta":
                for (let t = 0, i = u.length; t < i; t++) {
                  let i = u[t];
                  if (e.props.hasOwnProperty(i))
                    if ("charSet" === i) a.has(i) ? (n = !1) : a.add(i);
                    else {
                      let t = e.props[i],
                        a = r[i] || new Set();
                      ("name" !== i || !s) && a.has(t) ? (n = !1) : (a.add(t), (r[i] = a));
                    }
                }
            }
            return n;
          }),
        )
        .reverse()
        .map((e, t) => {
          let i = e.key || t;
          return o.default.cloneElement(e, { key: i });
        });
    }
    let v = function (e) {
      let { children: t } = e,
        i = (0, o.useContext)(h.HeadManagerContext);
      return (0, l.jsx)(c.default, { reduceComponentsToState: A, headManager: i, children: t });
    };
    ("function" == typeof i.default || ("object" == typeof i.default && null !== i.default)) &&
      void 0 === i.default.__esModule &&
      (Object.defineProperty(i.default, "__esModule", { value: !0 }),
      Object.assign(i.default, i),
      (t.exports = i.default));
  },
  488143,
  (e, t, i) => {
    "use strict";
    function a(e) {
      let { widthInt: t, heightInt: i, blurWidth: a, blurHeight: r, blurDataURL: n, objectFit: s } = e,
        l = a ? 40 * a : t,
        o = r ? 40 * r : i,
        c = l && o ? `viewBox='0 0 ${l} ${o}'` : "";
      return `%3Csvg xmlns='http://www.w3.org/2000/svg' ${c}%3E%3Cfilter id='b' color-interpolation-filters='sRGB'%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3CfeColorMatrix values='1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 100 -1' result='s'/%3E%3CfeFlood x='0' y='0' width='100%25' height='100%25'/%3E%3CfeComposite operator='out' in='s'/%3E%3CfeComposite in2='SourceGraphic'/%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3C/filter%3E%3Cimage width='100%25' height='100%25' x='0' y='0' preserveAspectRatio='${c ? "none" : "contain" === s ? "xMidYMid" : "cover" === s ? "xMidYMid slice" : "none"}' style='filter: url(%23b);' href='${n}'/%3E%3C/svg%3E`;
    }
    (Object.defineProperty(i, "__esModule", { value: !0 }),
      Object.defineProperty(i, "getImageBlurSvg", {
        enumerable: !0,
        get: function () {
          return a;
        },
      }));
  },
  918556,
  (e, t, i) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(i, "__esModule", { value: !0 }),
      Object.defineProperty(i, "ImageConfigContext", {
        enumerable: !0,
        get: function () {
          return n;
        },
      }));
    let a = e.r(555682)._(e.r(271645)),
      r = e.r(987690),
      n = a.default.createContext(r.imageConfigDefault);
  },
  987690,
  (e, t, i) => {
    "use strict";
    Object.defineProperty(i, "__esModule", { value: !0 });
    var a = {
      VALID_LOADERS: function () {
        return n;
      },
      imageConfigDefault: function () {
        return s;
      },
    };
    for (var r in a) Object.defineProperty(i, r, { enumerable: !0, get: a[r] });
    let n = ["default", "imgix", "cloudinary", "akamai", "custom"],
      s = {
        deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
        imageSizes: [32, 48, 64, 96, 128, 256, 384],
        path: "/_next/image",
        loader: "default",
        loaderFile: "",
        domains: [],
        disableStaticImages: !1,
        minimumCacheTTL: 14400,
        formats: ["image/webp"],
        maximumDiskCacheSize: void 0,
        maximumRedirects: 3,
        maximumResponseBody: 5e7,
        dangerouslyAllowLocalIP: !1,
        dangerouslyAllowSVG: !1,
        contentSecurityPolicy: "script-src 'none'; frame-src 'none'; sandbox;",
        contentDispositionType: "attachment",
        localPatterns: void 0,
        remotePatterns: [],
        qualities: [75],
        unoptimized: !1,
        customCacheHandler: !1,
      };
  },
  794909,
  (e, t, i) => {
    "use strict";
    (e.i(247167), Object.defineProperty(i, "__esModule", { value: !0 }));
    var a = {
      default: function () {
        return h;
      },
      getImageProps: function () {
        return c;
      },
    };
    for (var r in a) Object.defineProperty(i, r, { enumerable: !0, get: a[r] });
    let n = e.r(555682),
      s = e.r(908927),
      l = e.r(605500),
      o = n._(e.r(1948));
    function c(e) {
      let { props: t } = (0, s.getImgProps)(e, {
        defaultLoader: o.default,
        imgConf: {
          deviceSizes: [640, 1080, 1920],
          imageSizes: [16, 64, 128],
          qualities: [75],
          path: "/_next/image",
          loader: "default",
          dangerouslyAllowSVG: !1,
          unoptimized: !0,
        },
      });
      for (let [e, i] of Object.entries(t)) void 0 === i && delete t[e];
      return { props: t };
    }
    let h = l.Image;
  },
  657688,
  (e, t, i) => {
    t.exports = e.r(794909);
  },
  1948,
  (e, t, i) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(i, "__esModule", { value: !0 }),
      Object.defineProperty(i, "default", {
        enumerable: !0,
        get: function () {
          return s;
        },
      }));
    let a = e.r(670965),
      r = e.r(543369);
    function n(e) {
      let { config: t, src: i, width: n, quality: s } = e,
        l = (0, r.getDeploymentId)();
      if (i.startsWith("/") && !i.startsWith("//"))
        if (i.includes("/_next/static/immutable") && !(0, r.getAssetToken)()) l = void 0;
        else {
          let e = i.indexOf("?");
          if (-1 !== e) {
            let t = new URLSearchParams(i.slice(e + 1)),
              a = t.get("dpl");
            if (a) {
              ((l = a), t.delete("dpl"));
              let r = t.toString();
              i = i.slice(0, e) + (r ? "?" + r : "");
            }
          }
        }
      if (
        i.startsWith("/") &&
        i.includes("?") &&
        t.localPatterns?.length === 1 &&
        "**" === t.localPatterns[0].pathname &&
        "" === t.localPatterns[0].search
      )
        throw Object.defineProperty(
          Error(`Image with src "${i}" is using a query string which is not configured in images.localPatterns.
Read more: https://nextjs.org/docs/messages/next-image-unconfigured-localpatterns`),
          "__NEXT_ERROR_CODE",
          { value: "E871", enumerable: !1, configurable: !0 },
        );
      let o = (0, a.findClosestQuality)(s, t);
      return `${t.path}?url=${encodeURIComponent(i)}&w=${n}&q=${o}${i.startsWith("/") && l ? `&dpl=${l}` : ""}`;
    }
    n.__next_img_default = !0;
    let s = n;
  },
  65856,
  (e, t, i) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(i, "__esModule", { value: !0 }),
      Object.defineProperty(i, "RouterContext", {
        enumerable: !0,
        get: function () {
          return a;
        },
      }));
    let a = e.r(555682)._(e.r(271645)).default.createContext(null);
  },
  898879,
  (e, t, i) => {
    "use strict";
    (Object.defineProperty(i, "__esModule", { value: !0 }),
      Object.defineProperty(i, "default", {
        enumerable: !0,
        get: function () {
          return l;
        },
      }));
    let a = e.r(271645),
      r = "u" < typeof window,
      n = r ? () => {} : a.useLayoutEffect,
      s = r ? () => {} : a.useEffect;
    function l(e) {
      let { headManager: t, reduceComponentsToState: i } = e;
      function l() {
        if (t && t.mountedInstances) {
          let e = a.Children.toArray(Array.from(t.mountedInstances).filter(Boolean));
          t.updateHead(i(e));
        }
      }
      return (
        r && (t?.mountedInstances?.add(e.children), l()),
        n(
          () => (
            t?.mountedInstances?.add(e.children),
            () => {
              t?.mountedInstances?.delete(e.children);
            }
          ),
        ),
        n(
          () => (
            t && (t._pendingUpdate = l),
            () => {
              t && (t._pendingUpdate = l);
            }
          ),
        ),
        s(
          () => (
            t && t._pendingUpdate && (t._pendingUpdate(), (t._pendingUpdate = null)),
            () => {
              t && t._pendingUpdate && (t._pendingUpdate(), (t._pendingUpdate = null));
            }
          ),
        ),
        null
      );
    }
  },
  387435,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(948148),
      a = e.i(271645);
    e.i(333163);
    var r = e.i(216839),
      n = e.i(657688);
    e.i(83029);
    var s = e.i(40959);
    let l = "ab_myiq_home_redesign_certificate_signature_title",
      o = () => {
        let e = (0, i.useTranslations)();
        return (0, t.jsxs)("div", {
          className: "flex flex-col px-1 py-2 text-left md:px-4 md:py-3",
          children: [
            (0, t.jsxs)("div", {
              className: "flex items-start justify-between gap-4",
              children: [
                (0, t.jsx)(s.IconLogoDark, {
                  "aria-hidden": !0,
                  viewBox: "0 0 108 31",
                  className: "mt-1 h-6 w-auto md:h-7",
                }),
                (0, t.jsx)("svg", {
                  role: "img",
                  "aria-label": e("ab_myiq_home_redesign_certificate_qr_label"),
                  viewBox: "0 0 25 25",
                  shapeRendering: "crispEdges",
                  className:
                    "size-14 rounded-md border border-slate-200 p-1.5 text-black-custom md:size-16 md:rounded-lg",
                  children: (0, t.jsx)("path", {
                    d: "M0 0h1v1h-1zM1 0h1v1h-1zM2 0h1v1h-1zM3 0h1v1h-1zM4 0h1v1h-1zM5 0h1v1h-1zM6 0h1v1h-1zM10 0h1v1h-1zM11 0h1v1h-1zM14 0h1v1h-1zM18 0h1v1h-1zM19 0h1v1h-1zM20 0h1v1h-1zM21 0h1v1h-1zM22 0h1v1h-1zM23 0h1v1h-1zM24 0h1v1h-1zM0 1h1v1h-1zM6 1h1v1h-1zM8 1h1v1h-1zM13 1h1v1h-1zM18 1h1v1h-1zM24 1h1v1h-1zM0 2h1v1h-1zM2 2h1v1h-1zM3 2h1v1h-1zM4 2h1v1h-1zM6 2h1v1h-1zM10 2h1v1h-1zM12 2h1v1h-1zM15 2h1v1h-1zM18 2h1v1h-1zM20 2h1v1h-1zM21 2h1v1h-1zM22 2h1v1h-1zM24 2h1v1h-1zM0 3h1v1h-1zM2 3h1v1h-1zM3 3h1v1h-1zM4 3h1v1h-1zM6 3h1v1h-1zM9 3h1v1h-1zM11 3h1v1h-1zM12 3h1v1h-1zM13 3h1v1h-1zM18 3h1v1h-1zM20 3h1v1h-1zM21 3h1v1h-1zM22 3h1v1h-1zM24 3h1v1h-1zM0 4h1v1h-1zM2 4h1v1h-1zM3 4h1v1h-1zM4 4h1v1h-1zM6 4h1v1h-1zM8 4h1v1h-1zM10 4h1v1h-1zM12 4h1v1h-1zM13 4h1v1h-1zM16 4h1v1h-1zM18 4h1v1h-1zM20 4h1v1h-1zM21 4h1v1h-1zM22 4h1v1h-1zM24 4h1v1h-1zM0 5h1v1h-1zM6 5h1v1h-1zM10 5h1v1h-1zM11 5h1v1h-1zM14 5h1v1h-1zM15 5h1v1h-1zM16 5h1v1h-1zM18 5h1v1h-1zM24 5h1v1h-1zM0 6h1v1h-1zM1 6h1v1h-1zM2 6h1v1h-1zM3 6h1v1h-1zM4 6h1v1h-1zM5 6h1v1h-1zM6 6h1v1h-1zM8 6h1v1h-1zM10 6h1v1h-1zM12 6h1v1h-1zM14 6h1v1h-1zM16 6h1v1h-1zM18 6h1v1h-1zM19 6h1v1h-1zM20 6h1v1h-1zM21 6h1v1h-1zM22 6h1v1h-1zM23 6h1v1h-1zM24 6h1v1h-1zM10 7h1v1h-1zM11 7h1v1h-1zM12 7h1v1h-1zM15 7h1v1h-1zM16 7h1v1h-1zM0 8h1v1h-1zM2 8h1v1h-1zM4 8h1v1h-1zM6 8h1v1h-1zM11 8h1v1h-1zM12 8h1v1h-1zM15 8h1v1h-1zM16 8h1v1h-1zM20 8h1v1h-1zM23 8h1v1h-1zM1 9h1v1h-1zM2 9h1v1h-1zM3 9h1v1h-1zM5 9h1v1h-1zM7 9h1v1h-1zM10 9h1v1h-1zM11 9h1v1h-1zM13 9h1v1h-1zM16 9h1v1h-1zM18 9h1v1h-1zM24 9h1v1h-1zM1 10h1v1h-1zM3 10h1v1h-1zM4 10h1v1h-1zM6 10h1v1h-1zM7 10h1v1h-1zM10 10h1v1h-1zM11 10h1v1h-1zM12 10h1v1h-1zM14 10h1v1h-1zM19 10h1v1h-1zM20 10h1v1h-1zM22 10h1v1h-1zM23 10h1v1h-1zM24 10h1v1h-1zM0 11h1v1h-1zM2 11h1v1h-1zM3 11h1v1h-1zM7 11h1v1h-1zM8 11h1v1h-1zM10 11h1v1h-1zM12 11h1v1h-1zM13 11h1v1h-1zM14 11h1v1h-1zM16 11h1v1h-1zM20 11h1v1h-1zM23 11h1v1h-1zM0 12h1v1h-1zM1 12h1v1h-1zM4 12h1v1h-1zM5 12h1v1h-1zM6 12h1v1h-1zM7 12h1v1h-1zM8 12h1v1h-1zM9 12h1v1h-1zM14 12h1v1h-1zM15 12h1v1h-1zM16 12h1v1h-1zM17 12h1v1h-1zM18 12h1v1h-1zM21 12h1v1h-1zM23 12h1v1h-1zM24 12h1v1h-1zM1 13h1v1h-1zM3 13h1v1h-1zM4 13h1v1h-1zM7 13h1v1h-1zM10 13h1v1h-1zM11 13h1v1h-1zM14 13h1v1h-1zM16 13h1v1h-1zM17 13h1v1h-1zM18 13h1v1h-1zM21 13h1v1h-1zM24 13h1v1h-1zM0 14h1v1h-1zM2 14h1v1h-1zM5 14h1v1h-1zM6 14h1v1h-1zM10 14h1v1h-1zM13 14h1v1h-1zM19 14h1v1h-1zM22 14h1v1h-1zM23 14h1v1h-1zM24 14h1v1h-1zM1 15h1v1h-1zM3 15h1v1h-1zM4 15h1v1h-1zM5 15h1v1h-1zM7 15h1v1h-1zM11 15h1v1h-1zM20 15h1v1h-1zM23 15h1v1h-1zM0 16h1v1h-1zM2 16h1v1h-1zM3 16h1v1h-1zM4 16h1v1h-1zM5 16h1v1h-1zM6 16h1v1h-1zM7 16h1v1h-1zM10 16h1v1h-1zM12 16h1v1h-1zM16 16h1v1h-1zM17 16h1v1h-1zM18 16h1v1h-1zM19 16h1v1h-1zM20 16h1v1h-1zM21 16h1v1h-1zM8 17h1v1h-1zM9 17h1v1h-1zM10 17h1v1h-1zM11 17h1v1h-1zM12 17h1v1h-1zM13 17h1v1h-1zM15 17h1v1h-1zM16 17h1v1h-1zM20 17h1v1h-1zM21 17h1v1h-1zM23 17h1v1h-1zM24 17h1v1h-1zM0 18h1v1h-1zM1 18h1v1h-1zM2 18h1v1h-1zM3 18h1v1h-1zM4 18h1v1h-1zM5 18h1v1h-1zM6 18h1v1h-1zM9 18h1v1h-1zM10 18h1v1h-1zM11 18h1v1h-1zM12 18h1v1h-1zM14 18h1v1h-1zM15 18h1v1h-1zM16 18h1v1h-1zM18 18h1v1h-1zM20 18h1v1h-1zM21 18h1v1h-1zM23 18h1v1h-1zM24 18h1v1h-1zM0 19h1v1h-1zM6 19h1v1h-1zM9 19h1v1h-1zM10 19h1v1h-1zM12 19h1v1h-1zM13 19h1v1h-1zM14 19h1v1h-1zM16 19h1v1h-1zM20 19h1v1h-1zM21 19h1v1h-1zM23 19h1v1h-1zM0 20h1v1h-1zM2 20h1v1h-1zM3 20h1v1h-1zM4 20h1v1h-1zM6 20h1v1h-1zM8 20h1v1h-1zM9 20h1v1h-1zM10 20h1v1h-1zM11 20h1v1h-1zM14 20h1v1h-1zM16 20h1v1h-1zM17 20h1v1h-1zM18 20h1v1h-1zM19 20h1v1h-1zM20 20h1v1h-1zM21 20h1v1h-1zM24 20h1v1h-1zM0 21h1v1h-1zM2 21h1v1h-1zM3 21h1v1h-1zM4 21h1v1h-1zM6 21h1v1h-1zM9 21h1v1h-1zM11 21h1v1h-1zM14 21h1v1h-1zM15 21h1v1h-1zM16 21h1v1h-1zM19 21h1v1h-1zM20 21h1v1h-1zM21 21h1v1h-1zM22 21h1v1h-1zM0 22h1v1h-1zM2 22h1v1h-1zM3 22h1v1h-1zM4 22h1v1h-1zM6 22h1v1h-1zM8 22h1v1h-1zM9 22h1v1h-1zM10 22h1v1h-1zM13 22h1v1h-1zM15 22h1v1h-1zM17 22h1v1h-1zM20 22h1v1h-1zM24 22h1v1h-1zM0 23h1v1h-1zM6 23h1v1h-1zM9 23h1v1h-1zM10 23h1v1h-1zM11 23h1v1h-1zM15 23h1v1h-1zM16 23h1v1h-1zM17 23h1v1h-1zM20 23h1v1h-1zM21 23h1v1h-1zM23 23h1v1h-1zM0 24h1v1h-1zM1 24h1v1h-1zM2 24h1v1h-1zM3 24h1v1h-1zM4 24h1v1h-1zM5 24h1v1h-1zM6 24h1v1h-1zM8 24h1v1h-1zM12 24h1v1h-1zM16 24h1v1h-1zM17 24h1v1h-1zM18 24h1v1h-1zM19 24h1v1h-1zM23 24h1v1h-1zM24 24h1v1h-1z",
                    fill: "currentColor",
                  }),
                }),
              ],
            }),
            (0, t.jsxs)("div", {
              className: "mt-6 flex flex-col items-center text-center md:mt-8",
              children: [
                (0, t.jsx)("span", {
                  className: "text-hp-caption text-grey-custom md:text-hp-body-sm",
                  children: e("ab_myiq_home_redesign_certificate_kicker"),
                }),
                (0, t.jsx)("span", {
                  className:
                    "mt-1.5 font-serif text-[1.25rem] uppercase leading-none tracking-[0.18em] text-grey-custom md:text-[1.5rem]",
                  children: e("ab_myiq_home_redesign_certificate_doc_title"),
                }),
                (0, t.jsx)("span", {
                  className: "mt-7 text-hp-body-sm text-grey-custom md:mt-8",
                  children: e("ab_myiq_home_redesign_certificate_awarded_to"),
                }),
                (0, t.jsx)("span", {
                  className:
                    "mt-1.5 text-balance font-serif text-[2.125rem] leading-[1.1] tracking-normal text-black-custom md:text-[2.75rem]",
                  children: e("ab_myiq_home_redesign_certificate_name_placeholder"),
                }),
                (0, t.jsxs)("p", {
                  className: "mt-4 max-w-sm text-pretty text-hp-body-sm text-grey-custom",
                  children: [
                    e("ab_myiq_home_redesign_certificate_statement_before"),
                    " ",
                    e("ab_myiq_home_redesign_certificate_statement_product"),
                    " ",
                    e("ab_myiq_home_redesign_certificate_statement_after"),
                  ],
                }),
                (0, t.jsxs)("div", {
                  className: "mt-6 flex w-full items-center gap-5 md:mt-7 md:gap-6",
                  children: [
                    (0, t.jsx)("span", { "aria-hidden": !0, className: "h-px flex-1 bg-slate-200" }),
                    (0, t.jsx)("span", {
                      className: "text-hp-stat tabular-nums leading-none text-[#1D4ED8] lg:text-hp-stat-lg",
                      children: "120",
                    }),
                    (0, t.jsx)("span", { "aria-hidden": !0, className: "h-px flex-1 bg-slate-200" }),
                  ],
                }),
                (0, t.jsx)("span", {
                  className: "mt-4 text-hp-body-sm font-medium tabular-nums text-black-custom",
                  children: e("ab_myiq_home_redesign_certificate_date_value"),
                }),
              ],
            }),
            (0, t.jsxs)("div", {
              className:
                "mt-10 flex flex-col items-center gap-6 text-center md:mt-12 md:flex-row md:items-end md:justify-between md:gap-8 md:text-left",
              children: [
                (0, t.jsxs)("p", {
                  className: "whitespace-nowrap text-hp-body-sm text-grey-custom",
                  children: [
                    e("ab_myiq_home_redesign_certificate_id_label"),
                    " ",
                    (0, t.jsx)("span", {
                      className: "font-medium tabular-nums text-black-custom",
                      children: "728 415",
                    }),
                  ],
                }),
                (0, t.jsxs)("div", {
                  className: "flex w-44 shrink-0 flex-col items-center md:w-48",
                  children: [
                    (0, t.jsx)("span", {
                      className:
                        "flex h-10 w-full items-end justify-center overflow-hidden border-b border-slate-300 px-2 md:h-11",
                      children: (0, t.jsx)(n.default, {
                        src: "/images/certificate/sign-1.png",
                        alt: e(l),
                        width: 200,
                        height: 80,
                        className: "h-8 w-auto translate-y-[3px] object-contain md:h-9",
                      }),
                    }),
                    (0, t.jsx)("span", {
                      className: "mt-1.5 whitespace-nowrap text-hp-caption leading-[1.15] text-grey-custom",
                      children: e(l),
                    }),
                  ],
                }),
              ],
            }),
          ],
        });
      };
    e.s(
      [
        "default",
        0,
        () => {
          let e = (0, i.useTranslations)(),
            [n, s] = (0, a.useState)(!1),
            l = (0, a.useRef)(null),
            c = (0, a.useCallback)(() => {
              (s(!1), l.current?.focus());
            }, []);
          return (
            (0, a.useEffect)(() => {
              if (!n) return;
              let e = (e) => {
                  "Escape" === e.key && c();
                },
                t = document.body.style.overflow;
              return (
                (document.body.style.overflow = "hidden"),
                window.addEventListener("keydown", e),
                () => {
                  ((document.body.style.overflow = t), window.removeEventListener("keydown", e));
                }
              );
            }, [n, c]),
            (0, t.jsxs)(t.Fragment, {
              children: [
                (0, t.jsx)("button", {
                  ref: l,
                  type: "button",
                  "aria-label": e("ab_myiq_home_redesign_certificate_preview_label"),
                  "aria-haspopup": "dialog",
                  "aria-expanded": n,
                  onClick: () => s(!0),
                  className:
                    "relative block w-full cursor-zoom-in rounded-2xl bg-white p-5 text-left shadow-[0_18px_40px_-20px_rgba(11,12,39,0.18)] ring-1 ring-black/[0.04] transition-shadow duration-200 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-custom md:p-6 [@media(hover:hover)]:hover:shadow-[0_22px_48px_-20px_rgba(11,12,39,0.24)]",
                  children: (0, t.jsx)(o, {}),
                }),
                n &&
                  (0, t.jsx)("div", {
                    role: "dialog",
                    "aria-modal": "true",
                    "aria-label": e("ab_myiq_home_redesign_certificate_dialog_label"),
                    className:
                      "fixed inset-0 z-50 flex animate-[hero-fade_180ms_ease-out_both] justify-center overflow-y-auto bg-black-custom/80 px-4 pb-4 pt-14 backdrop-blur-md motion-reduce:animate-none md:px-8 md:pb-8",
                    onClick: c,
                    children: (0, t.jsxs)("div", {
                      className:
                        "relative my-auto w-full max-w-3xl [@media(min-width:768px)_and_(min-height:900px)]:[zoom:1.15]",
                      onClick: (e) => e.stopPropagation(),
                      children: [
                        (0, t.jsx)("button", {
                          type: "button",
                          "aria-label": e("ab_myiq_home_redesign_certificate_close_label"),
                          onClick: c,
                          autoFocus: !0,
                          className:
                            "absolute -top-12 right-0 flex size-9 items-center justify-center rounded-full bg-white/15 text-white transition-colors duration-150 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white [@media(hover:hover)]:hover:bg-white/25",
                          children: (0, t.jsx)(r.IconClose, { className: "size-4" }),
                        }),
                        (0, t.jsx)("div", {
                          className:
                            "animate-[hero-rise_260ms_ease-out_both] rounded-2xl bg-white p-3 shadow-[0_40px_100px_-24px_rgba(11,12,39,0.55)] motion-reduce:animate-none md:p-5",
                          children: (0, t.jsx)("div", {
                            className: "rounded border border-black-custom/40 px-4 py-6 md:px-10 md:py-9",
                            children: (0, t.jsx)(o, {}),
                          }),
                        }),
                      ],
                    }),
                  }),
              ],
            })
          );
        },
      ],
      387435,
    );
  },
  346668,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(657688),
      a = e.i(948148),
      r = e.i(271645);
    let n = {
        src: e.i(441449).default,
        width: 449,
        height: 704,
        blurWidth: 5,
        blurHeight: 8,
        blurDataURL:
          "data:image/webp;base64,UklGRgYBAABXRUJQVlA4TPoAAAAvBMABEM1VICICHgiACQMAAIC9GNaAmOPCIQAAAACAAwAAAAAAAAAAAAAAAAAAAOAGBEEC9zNBFwAAgAciAQAAAABw/g0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9kAkAAAAAADOvwEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAHghACgMAAMD5X/omJgBIMGIIENgwAIAAAAAAAAQAAgAEACAeAAAAAAAGAQAeRAAJKMbnL1pjIAAO7ouaiBEA6mXdJYhjiAgnTUi4bmTm+/8t0OAKPBt+Ly2AWGv7getPHVr+HnaYD2uG55wc",
      },
      s = {
        src: e.i(286642).default,
        width: 449,
        height: 704,
        blurWidth: 5,
        blurHeight: 8,
        blurDataURL:
          "data:image/webp;base64,UklGRggBAABXRUJQVlA4TPwAAAAvBMABEM1VICICHgiACQMAAIC1JXeOIAcCBoATBwAASAAAAAAAcAAAAAAAAAAIAIADgEMXgqAQAwAAgAciAQAAAABw/g0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9kAkAAAAAADOvwEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAHghACgMAAMD5XzN7YM+IAAAGAQBQAAQwRgAACAEAAQAAAAAAADAAAIAAAAAeRgqfgLFwIme+Qgfg8YHGPI4NQEPe/7+3AmnOkzLLIVm+btya9HtfsMm7O3RfVRhaau5YpE0FEKXoFYolD7hz8AY=",
      },
      l = {
        src: e.i(688356).default,
        width: 449,
        height: 704,
        blurWidth: 5,
        blurHeight: 8,
        blurDataURL:
          "data:image/webp;base64,UklGRgoBAABXRUJQVlA4TP0AAAAvBMABEM1VICICHgiADQIAAIAV7tsZ5N8J5TAA4AAAAsABAAAAAAAAAAAAAAAAAAAAAAAPRKB+YAAAADyQTQAAAACA898DAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgDwQCQAAAACA828AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAsAcCkMIAAABw/tegkA2CCNoIeQAAAwAABQAAIAIKAAAAAAAgAgAAAABgAAQAMECVAEPMQbxpgwGAcS1VQxGsHDtqQRDv4BTsNcVFaqVSmXNbngleeE7Y8B/CAvQK/0oQ3S8fz0enJ/R5sz547f8+AA==",
      };
    var o = e.i(768329),
      c = e.i(11059),
      h = e.i(714029);
    let d = [
      {
        id: "lincoln",
        name: "ab_myiq_home_redesign_figures_row1_name",
        iq: "123",
        image: n,
        portrait: o.ImgAbrahamLincoln123,
      },
      {
        id: "napoleon",
        name: "ab_myiq_home_redesign_figures_row2_name",
        iq: "118",
        image: l,
        portrait: h.ImgNapoleonBonaparte118,
      },
      {
        id: "washington",
        name: "ab_myiq_home_redesign_figures_row3_name",
        iq: "113",
        image: s,
        portrait: c.ImgGeorgeWashington113,
      },
    ];
    e.s(
      [
        "default",
        0,
        () => {
          let e = (0, a.useTranslations)(),
            [n, s] = (0, r.useState)(0),
            [l, o] = (0, r.useState)(!1),
            [c, h] = (0, r.useState)(!1);
          return (
            (0, r.useEffect)(() => {
              if (l || c || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
              let e = window.setInterval(() => {
                s((e) => (e + 1) % d.length);
              }, 4e3);
              return () => window.clearInterval(e);
            }, [l, c]),
            (0, t.jsxs)("div", {
              className: "contents",
              onMouseEnter: () => o(!0),
              onMouseLeave: () => o(!1),
              children: [
                (0, t.jsx)("div", {
                  className: "relative z-10 px-8 pt-8 md:hidden",
                  children: (0, t.jsxs)("div", {
                    className: "relative aspect-square overflow-hidden",
                    children: [
                      d.map((e, a) =>
                        (0, t.jsx)(
                          i.default,
                          {
                            src: e.portrait,
                            alt: "",
                            "aria-hidden": !0,
                            fill: !0,
                            sizes: "80vw",
                            className:
                              a === n
                                ? "select-none object-cover object-top opacity-100 transition-opacity duration-700 motion-reduce:transition-none"
                                : "select-none object-cover object-top opacity-0 transition-opacity duration-700 motion-reduce:transition-none",
                          },
                          e.id,
                        ),
                      ),
                      (0, t.jsx)("span", {
                        "aria-hidden": !0,
                        className:
                          "pointer-events-none absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-black-custom via-black-custom/85 to-transparent",
                      }),
                    ],
                  }),
                }),
                (0, t.jsx)("div", {
                  className:
                    "relative z-10 hidden items-end justify-center overflow-hidden px-8 pt-10 md:flex",
                  children: d.map((e, a) =>
                    (0, t.jsx)(
                      i.default,
                      {
                        src: e.image,
                        alt: "",
                        "aria-hidden": !0,
                        className:
                          a === n
                            ? "h-56 w-auto select-none object-contain object-bottom opacity-100 transition-opacity duration-700 motion-reduce:transition-none md:h-80 lg:h-[22rem]"
                            : "absolute bottom-0 h-56 w-auto select-none object-contain object-bottom opacity-0 transition-opacity duration-700 motion-reduce:transition-none md:h-80 lg:h-[22rem]",
                      },
                      e.id,
                    ),
                  ),
                }),
                (0, t.jsxs)("div", {
                  className:
                    "relative z-10 flex flex-col gap-8 p-6 md:p-10 lg:flex-row lg:items-start lg:gap-10 lg:self-center lg:p-12",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex flex-col gap-4 lg:flex-1",
                      children: [
                        (0, t.jsx)("span", {
                          className: "text-hp-eyebrow uppercase text-white/60",
                          children: e("ab_myiq_home_redesign_figures_eyebrow"),
                        }),
                        (0, t.jsx)("h3", {
                          className: "text-balance text-hp-h3 text-white lg:text-hp-h3-lg",
                          children: e("ab_myiq_home_redesign_figures_title"),
                        }),
                        (0, t.jsx)("p", {
                          className: "max-w-md text-pretty text-hp-body-sm text-white/80",
                          children: e("ab_myiq_home_redesign_figures_lede"),
                        }),
                      ],
                    }),
                    (0, t.jsxs)("div", {
                      className:
                        "flex flex-col gap-3 lg:w-64 lg:shrink-0 lg:border-l lg:border-white/10 lg:pl-8",
                      children: [
                        (0, t.jsx)("ul", {
                          className: "flex flex-col gap-2.5",
                          children: d.map((i, a) =>
                            (0, t.jsx)(
                              "li",
                              {
                                className: "border-t border-white/10 pt-2.5 first:border-t-0 first:pt-0",
                                children: (0, t.jsxs)("button", {
                                  type: "button",
                                  "aria-pressed": a === n,
                                  onClick: () => {
                                    (s(a), h(!0));
                                  },
                                  className:
                                    "group flex w-full items-center justify-between gap-3 text-left focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-white",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className:
                                        a === n
                                          ? "text-hp-body-sm font-medium text-white transition-colors duration-500 motion-reduce:transition-none"
                                          : "text-hp-body-sm text-white/50 transition-colors duration-500 motion-reduce:transition-none [@media(hover:hover)]:group-hover:text-white/80",
                                      children: e(i.name),
                                    }),
                                    (0, t.jsx)("span", {
                                      className:
                                        a === n
                                          ? "text-hp-body-sm font-medium tabular-nums text-white transition-colors duration-500 motion-reduce:transition-none"
                                          : "text-hp-body-sm tabular-nums text-white/50 transition-colors duration-500 motion-reduce:transition-none [@media(hover:hover)]:group-hover:text-white/80",
                                      children: i.iq,
                                    }),
                                  ],
                                }),
                              },
                              i.id,
                            ),
                          ),
                        }),
                        (0, t.jsx)("p", {
                          className: "text-pretty text-hp-caption text-white/50",
                          children: e("ab_myiq_home_redesign_figures_note"),
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            })
          );
        },
      ],
      346668,
    );
  },
  436992,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(948148);
    e.i(273998);
    var a = e.i(38256),
      r = e.i(523615),
      n = e.i(105278);
    e.i(872721);
    var s = e.i(652050);
    e.i(872756);
    var l = e.i(987132);
    e.i(83029);
    var o = e.i(40959);
    e.i(203068);
    var c = e.i(532262),
      h = e.i(202042);
    let d = [
        {
          titleKey: "ab_myiq_home_redesign_footer_col_product_title",
          links: [
            {
              labelKey: "ab_myiq_home_redesign_footer_link_how_it_works",
              href: "/#how-it-works",
              trackingName: "How it works",
            },
            {
              labelKey: "ab_myiq_home_redesign_footer_link_courses",
              href: "/#courses",
              trackingName: "Courses",
            },
            { labelKey: "nav_reviews", href: "/#reviews", trackingName: "Reviews" },
            { labelKey: "nav_pricing", href: "/#pricing", trackingName: "Pricing" },
            { labelKey: "ab_myiq_home_redesign_footer_link_faq", href: "/#faq", trackingName: "FAQ" },
          ],
        },
        {
          titleKey: "ab_myiq_home_redesign_footer_col_support_title",
          links: [
            { labelKey: "nav_help", href: "/help", trackingName: "Help" },
            {
              labelKey: "ab_myiq_home_redesign_footer_link_how_to_cancel",
              href: "/cancellation/auth",
              trackingName: "How to cancel",
              event: "how-to-cancel",
            },
            {
              labelKey: "ab_myiq_home_redesign_footer_link_contact",
              href: e.i(134404).EClientRoutes.CONTACT_SUPPORT,
              trackingName: "Contact",
              event: "contact-support",
            },
          ],
        },
        {
          titleKey: "nav_title_legal",
          links: [
            { labelKey: "nav_privacy_policy", href: "/privacy", trackingName: "Privacy Policy" },
            {
              labelKey: "ab_myiq_home_redesign_footer_link_terms",
              href: "/terms",
              trackingName: "Terms of Service",
            },
            { labelKey: "nav_cookie_policy", href: "/cookie", trackingName: "Cookie Policy" },
            { labelKey: "nav_refund", href: "/terms#refund-policy", trackingName: "Refund Policy" },
          ],
        },
      ],
      m = ["ab_myiq_home_redesign_footer_legal_copyright", "ab_myiq_home_redesign_footer_legal_disclaimer"],
      u = [
        { id: "instagram", label: "Instagram", href: "https://www.instagram.com/myiq_com" },
        { id: "facebook", label: "Facebook", href: "https://www.facebook.com/MyIQapp" },
        { id: "reddit", label: "Reddit", href: "https://www.reddit.com/r/MyIQ_Official/" },
      ],
      A = {
        instagram: (0, t.jsx)(r.InstagramIcon, {
          "aria-hidden": !0,
          viewBox: "0 0 28 29",
          className: "size-4",
        }),
        facebook: (0, t.jsx)(a.FacebookIcon, {
          "aria-hidden": !0,
          viewBox: "0 0 28 29",
          className: "size-4",
        }),
        reddit: (0, t.jsx)(n.RedditIcon, { "aria-hidden": !0, viewBox: "0 0 16 16", className: "size-4" }),
      },
      v = () =>
        (0, t.jsxs)("svg", {
          "aria-hidden": !0,
          viewBox: "0 0 16 16",
          fill: "none",
          focusable: "false",
          className: "size-4 shrink-0",
          children: [
            (0, t.jsx)("circle", {
              cx: "8",
              cy: "8",
              r: "6.25",
              stroke: "currentColor",
              strokeWidth: "1.25",
            }),
            (0, t.jsx)("path", {
              d: "M1.75 8h12.5M8 1.75c1.8 1.7 2.75 3.9 2.75 6.25S9.8 12.55 8 14.25M8 1.75c-1.8 1.7-2.75 3.9-2.75 6.25s.95 4.55 2.75 6.25",
              stroke: "currentColor",
              strokeWidth: "1.25",
            }),
          ],
        });
    e.s(
      [
        "default",
        0,
        (e) => {
          let { translatedByKey: a, preserveSearchParams: r } = e,
            n = (0, i.useTranslations)(),
            p = (e) => a?.[e] ?? n(e),
            {
              trackFooterLink: g,
              trackHowToCancel: f,
              trackContactSupport: _,
            } = (0, s.useDemoHomeTracking)();
          return (0, t.jsx)("footer", {
            id: "footer",
            className: "w-full border-t border-slate-200 bg-white pb-12 pt-8 sm:pt-16 lg:pb-16 lg:pt-24",
            children: (0, t.jsx)(l.DemoContainer, {
              children: (0, t.jsxs)("div", {
                className: "flex flex-col gap-12",
                children: [
                  (0, t.jsx)("h2", {
                    className: "sr-only",
                    children: p("ab_myiq_home_redesign_footer_heading"),
                  }),
                  (0, t.jsxs)("div", {
                    className: "grid grid-cols-2 gap-10 md:grid-cols-[1.5fr_1fr_1fr_1fr] lg:gap-12",
                    children: [
                      (0, t.jsxs)("div", {
                        className: "col-span-2 flex flex-col gap-4 md:col-span-1",
                        children: [
                          (0, t.jsxs)(h.Link, {
                            href: "/#demo-top",
                            className: "flex items-center gap-2",
                            children: [
                              (0, t.jsx)(o.IconLogoDark, {
                                "aria-hidden": !0,
                                viewBox: "0 0 108 31",
                                className: "h-7 w-auto",
                              }),
                              (0, t.jsx)("span", { className: "sr-only", children: "MyIQ" }),
                            ],
                          }),
                          (0, t.jsx)("ul", {
                            className: "mt-1 flex items-center gap-3",
                            children: u.map((e) =>
                              (0, t.jsx)(
                                "li",
                                {
                                  children: (0, t.jsx)("a", {
                                    href: e.href,
                                    target: "_blank",
                                    rel: "noreferrer",
                                    "aria-label": e.label,
                                    className:
                                      "flex size-9 items-center justify-center rounded-full border border-slate-200 text-grey-deep transition-colors duration-150 [@media(hover:hover)]:hover:border-slate-300 [@media(hover:hover)]:hover:text-black-custom",
                                    children: A[e.id],
                                  }),
                                },
                                e.id,
                              ),
                            ),
                          }),
                        ],
                      }),
                      d.map((e) =>
                        (0, t.jsxs)(
                          "div",
                          {
                            children: [
                              (0, t.jsx)("h3", {
                                className: "text-hp-eyebrow uppercase text-grey-light",
                                children: p(e.titleKey),
                              }),
                              (0, t.jsx)("ul", {
                                className: "mt-4 flex flex-col gap-3",
                                children: e.links.map((e) =>
                                  (0, t.jsx)(
                                    "li",
                                    {
                                      children: (0, t.jsx)("a", {
                                        href: e.href,
                                        onClick: () =>
                                          "how-to-cancel" === e.event
                                            ? f()
                                            : "contact-support" === e.event
                                              ? _()
                                              : void g(e.trackingName),
                                        className:
                                          "text-hp-body-sm text-grey-deep transition-colors duration-150 [@media(hover:hover)]:hover:text-black-custom",
                                        children: p(e.labelKey),
                                      }),
                                    },
                                    e.labelKey,
                                  ),
                                ),
                              }),
                            ],
                          },
                          e.titleKey,
                        ),
                      ),
                    ],
                  }),
                  (0, t.jsxs)("div", {
                    className:
                      "flex flex-col gap-6 border-t border-slate-200 pt-8 md:flex-row md:items-start md:justify-between md:gap-10",
                    children: [
                      (0, t.jsx)("div", {
                        className: "flex flex-col gap-3",
                        children: m.map((e) =>
                          (0, t.jsx)(
                            "p",
                            {
                              className: "max-w-3xl text-pretty text-hp-caption text-grey-light",
                              children: p(e),
                            },
                            e,
                          ),
                        ),
                      }),
                      (0, t.jsx)(c.LangComponent, {
                        placement: "top",
                        className:
                          "h-9 !min-w-0 shrink-0 gap-2 self-start rounded-full border border-slate-200 bg-transparent px-4 text-hp-body-sm text-grey-deep data-[hover=true]:border-slate-300 data-[hover=true]:bg-transparent",
                        arrowClassName: "size-4 !text-grey-light",
                        triggerIcon: (0, t.jsx)(v, {}),
                        shouldBlockScroll: !1,
                        preserveSearchParams: r,
                      }),
                    ],
                  }),
                ],
              }),
            }),
          });
        },
      ],
      436992,
    );
  },
  128506,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(948148),
      a = e.i(271645),
      r = e.i(256889);
    e.i(872721);
    var n = e.i(652050);
    e.i(791371);
    var s = e.i(642448);
    e.i(872756);
    var l = e.i(987132);
    e.i(331955);
    var o = e.i(957397),
      c = e.i(911271);
    e.i(83029);
    var h = e.i(40959);
    let d = [
        { href: "#how-it-works", label: "ab_myiq_home_redesign_header_nav1_label" },
        { href: "#reviews", label: "nav_reviews" },
        { href: "#pricing", label: "nav_pricing" },
      ],
      m = "/sign-in",
      u = "ab_myiq_home_redesign_header_sign_in_label",
      A = "demo-mobile-nav",
      v =
        "whitespace-nowrap text-hp-body-sm text-grey-deep transition-colors duration-150 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom [@media(hover:hover)]:hover:text-black-custom",
      p = "a[href], button:not([disabled])",
      g =
        "transition-[opacity,transform] duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] motion-reduce:transition-none",
      f = "translate-y-0 opacity-100",
      _ = "translate-y-2 opacity-0 [transition-delay:0ms]",
      b = ["[transition-delay:40ms]", "[transition-delay:80ms]", "[transition-delay:120ms]"],
      x =
        "absolute left-1 top-[11.25px] h-[1.5px] w-4 rounded-full bg-current transition-[transform,opacity] duration-200 ease-[cubic-bezier(0.4,0,0.2,1)] motion-reduce:transition-none";
    e.s(
      [
        "default",
        0,
        (e) => {
          let { abMyiqNewHomepageCtaCopy: y } = e,
            w = (0, i.useTranslations)(),
            z = (0, c.getHomepageCtaLabelKey)("ab_myiq_home_redesign_header_sheet_cta_label", y),
            [M, j] = (0, a.useState)(!1),
            [E, k] = (0, a.useState)(!1),
            { trackLogin: N } = (0, n.useDemoHomeTracking)(),
            C = (0, a.useRef)(null),
            q = (0, a.useRef)(null),
            I = (0, a.useRef)(null);
          (0, a.useEffect)(() => {
            let e = () => {
                j(window.scrollY > 8);
              },
              t = requestAnimationFrame(e);
            return (
              window.addEventListener("scroll", e, { passive: !0 }),
              () => {
                (cancelAnimationFrame(t), window.removeEventListener("scroll", e));
              }
            );
          }, []);
          let S = (0, a.useCallback)(() => {
            (k(!1), I.current?.focus({ preventScroll: !0 }));
          }, []);
          return (
            (0, a.useEffect)(() => {
              if (!E) return;
              let e = (e) => {
                  if ("Escape" === e.key) return void S();
                  if ("Tab" !== e.key || !C.current || !q.current) return;
                  let t = [...C.current.querySelectorAll(p), ...q.current.querySelectorAll(p)].filter(
                      (e) => null !== e.offsetParent,
                    ),
                    i = t[0],
                    a = t[t.length - 1];
                  i &&
                    a &&
                    (e.shiftKey && document.activeElement === i
                      ? (e.preventDefault(), a.focus())
                      : e.shiftKey || document.activeElement !== a || (e.preventDefault(), i.focus()));
                },
                t = window.matchMedia("(min-width: 1024px)"),
                i = (e) => {
                  e.matches && k(!1);
                },
                a = document.body.style.overflow;
              return (
                (document.body.style.overflow = "hidden"),
                window.addEventListener("keydown", e),
                t.addEventListener("change", i),
                () => {
                  ((document.body.style.overflow = a),
                    window.removeEventListener("keydown", e),
                    t.removeEventListener("change", i));
                }
              );
            }, [E, S]),
            (0, t.jsxs)(t.Fragment, {
              children: [
                (0, t.jsx)("header", {
                  ref: C,
                  id: "demo-top",
                  className: (0, r.cn)(
                    "sticky top-0 z-50 w-full border-b bg-white transition-colors duration-150",
                    E && "touch-none border-transparent",
                    !E && (M ? "border-slate-200" : "border-transparent"),
                  ),
                  children: (0, t.jsx)(l.DemoContainer, {
                    children: (0, t.jsxs)("div", {
                      className: "flex h-16 items-center justify-between gap-4",
                      children: [
                        (0, t.jsxs)("a", {
                          href: "#demo-top",
                          onClick: (e) => {
                            (e.preventDefault(), E && S(), window.scrollTo({ top: 0, behavior: "smooth" }));
                          },
                          className:
                            "flex items-center gap-2 rounded-lg focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom",
                          children: [
                            (0, t.jsx)(h.IconLogoDark, {
                              "aria-hidden": !0,
                              viewBox: "0 0 108 31",
                              className: "h-7 w-auto",
                            }),
                            (0, t.jsx)("span", {
                              className: "sr-only",
                              children: w("ab_myiq_home_redesign_header_brand_label"),
                            }),
                          ],
                        }),
                        (0, t.jsx)("nav", {
                          "aria-label": w("ab_myiq_home_redesign_header_nav_aria_label"),
                          className: "hidden items-center gap-8 lg:flex",
                          children: d.map((e) =>
                            (0, t.jsx)("a", { href: e.href, className: v, children: w(e.label) }, e.href),
                          ),
                        }),
                        (0, t.jsxs)("div", {
                          className: "flex items-center gap-3",
                          children: [
                            (0, t.jsx)("a", {
                              href: m,
                              onClick: N,
                              className: (0, r.cn)(v, "max-lg:hidden"),
                              children: w(u),
                            }),
                            (0, t.jsx)(o.DemoStartCta, {
                              size: "sm",
                              variant: "primary",
                              className: "max-lg:hidden",
                              children: w("btn_start_test"),
                            }),
                            (0, t.jsx)("button", {
                              ref: I,
                              type: "button",
                              "aria-expanded": E,
                              "aria-controls": A,
                              "aria-label": E
                                ? w("ab_myiq_home_redesign_header_close_menu_aria_label")
                                : w("ab_myiq_home_redesign_header_open_menu_aria_label"),
                              onClick: () => (E ? S() : k(!0)),
                              className:
                                "flex size-10 items-center justify-center rounded-full text-grey-deep transition-colors duration-150 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom lg:hidden [@media(hover:hover)]:hover:bg-black-custom/[0.04] [@media(hover:hover)]:hover:text-black-custom",
                              children: (0, t.jsxs)("span", {
                                "aria-hidden": !0,
                                className: "relative block size-6",
                                children: [
                                  (0, t.jsx)("span", {
                                    className: (0, r.cn)(x, E ? "rotate-45" : "-translate-y-[5px]"),
                                  }),
                                  (0, t.jsx)("span", {
                                    className: (0, r.cn)(
                                      x,
                                      E ? "scale-x-0 opacity-0" : "scale-x-100 opacity-100",
                                    ),
                                  }),
                                  (0, t.jsx)("span", {
                                    className: (0, r.cn)(x, E ? "-rotate-45" : "translate-y-[5px]"),
                                  }),
                                ],
                              }),
                            }),
                          ],
                        }),
                      ],
                    }),
                  }),
                }),
                (0, t.jsxs)("div", {
                  id: A,
                  ref: q,
                  inert: !E,
                  "aria-hidden": !E,
                  className: (0, r.cn)(
                    "fixed inset-0 z-[45] flex touch-none flex-col bg-white pt-16 transition-[opacity,visibility] duration-200 ease-[cubic-bezier(0.4,0,0.2,1)] motion-reduce:transition-none lg:hidden",
                    E ? "visible opacity-100" : "invisible opacity-0",
                  ),
                  children: [
                    (0, t.jsx)("nav", {
                      "aria-label": w("ab_myiq_home_redesign_header_mobile_nav_aria_label"),
                      className: "min-h-0 flex-1 touch-pan-y overflow-y-auto overscroll-contain",
                      children: (0, t.jsx)(l.DemoContainer, {
                        children: (0, t.jsx)("ul", {
                          className: "pt-2",
                          children: d.map((e, i) =>
                            (0, t.jsx)(
                              "li",
                              {
                                className: (0, r.cn)(
                                  "border-b border-slate-100",
                                  g,
                                  E ? (0, r.cn)(f, b[i]) : _,
                                ),
                                children: (0, t.jsx)("a", {
                                  href: e.href,
                                  onClick: S,
                                  className:
                                    "flex items-center rounded-lg py-4 text-hp-h2 text-black-custom transition-colors duration-150 active:text-grey-light focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom [@media(hover:hover)]:hover:text-grey-light",
                                  children: w(e.label),
                                }),
                              },
                              e.href,
                            ),
                          ),
                        }),
                      }),
                    }),
                    (0, t.jsx)("div", {
                      className: (0, r.cn)("shrink-0", g, E ? (0, r.cn)(f, "[transition-delay:160ms]") : _),
                      children: (0, t.jsxs)(l.DemoContainer, {
                        className: "flex flex-col gap-2 pb-[calc(1.5rem+env(safe-area-inset-bottom))] pt-4",
                        children: [
                          (0, t.jsx)(s.DemoButton, {
                            size: "md",
                            variant: "ghost",
                            href: m,
                            onClick: () => {
                              (N(), S());
                            },
                            className: "w-full",
                            children: w(u),
                          }),
                          (0, t.jsx)(o.DemoStartCta, {
                            size: "lg",
                            variant: "primary",
                            className: "w-full",
                            children: w(z),
                          }),
                        ],
                      }),
                    }),
                  ],
                }),
              ],
            })
          );
        },
      ],
      128506,
    );
  },
  440952,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(948148),
      a = e.i(271645),
      r = e.i(256889),
      n = e.i(276935);
    e.i(331955);
    var s = e.i(957397),
      l = e.i(911271);
    let o = ["pricing", "start", "footer"];
    e.s(
      [
        "default",
        0,
        (e) => {
          let { isStartSection: c, abNewMyiqStartPageGenderStickyCta: h, abMyiqNewHomepageCtaCopy: d } = e,
            m = (0, i.useTranslations)(),
            u = (0, l.getHomepageCtaLabelKey)("ab_myiq_home_redesign_mobile_cta_label", d),
            [A, v] = (0, a.useState)(!1),
            [p, g] = (0, a.useState)(() => new Set()),
            f = c ? "start-section-cta" : "hero";
          (0, a.useEffect)(() => {
            let e = document.getElementById(f),
              t = o.map((e) => document.getElementById(e)).filter((e) => null !== e);
            if (!e) return;
            let i = new IntersectionObserver(
                (e) => {
                  let [t] = e;
                  return v(!t.isIntersecting && t.boundingClientRect.top < 0);
                },
                { threshold: 0 },
              ),
              a = new IntersectionObserver((e) => {
                g((t) => {
                  let i = new Set(t);
                  for (let t of e) t.isIntersecting ? i.add(t.target.id) : i.delete(t.target.id);
                  return i;
                });
              });
            return (
              i.observe(e),
              t.forEach((e) => a.observe(e)),
              () => {
                (i.disconnect(), a.disconnect());
              }
            );
          }, [f]);
          let _ = A && 0 === p.size;
          return (0, t.jsxs)("div", {
            "data-demo-mobile-cta": !0,
            inert: !_,
            "aria-hidden": !_,
            className: (0, r.cn)(
              "fixed inset-x-0 bottom-0 z-40 bg-white px-4 pb-[calc(1.5rem+env(safe-area-inset-bottom))] transition-[transform,opacity] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] motion-reduce:transition-none lg:hidden",
              !_ && "pointer-events-none translate-y-full opacity-0",
            ),
            children: [
              (0, t.jsx)("span", {
                "aria-hidden": !0,
                className:
                  "pointer-events-none absolute inset-x-0 bottom-full h-6 bg-gradient-to-t from-white to-transparent",
              }),
              c || "v1_gendered_sticky_cta" === h
                ? (0, t.jsx)(n.default, {
                    className: "flex flex-col gap-2 pt-1",
                    promptClassName: "text-center text-hp-caption text-grey-deep",
                    buttonClassName: "shadow-[0_12px_32px_-10px_rgba(11,12,39,0.35)]",
                  })
                : (0, t.jsx)(s.DemoStartCta, {
                    size: "lg",
                    variant: "primary",
                    className: "w-full shadow-[0_12px_32px_-10px_rgba(11,12,39,0.35)]",
                    children: m(u),
                  }),
            ],
          });
        },
      ],
      440952,
    );
  },
  441932,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(948148),
      a = e.i(86596),
      r = e.i(725397);
    let n = [
        {
          id: "today",
          label: "ab_myiq_home_redesign_pricing_today_label",
          unit: "ab_myiq_home_redesign_pricing_today_unit",
        },
        {
          id: "then",
          label: "ab_myiq_home_redesign_pricing_then_label",
          unit: "ab_myiq_home_redesign_pricing_then_unit",
        },
      ],
      s = "help@myiq.com";
    e.i(331955);
    var l = e.i(957397),
      o = e.i(911271);
    e.i(80460);
    var c = e.i(998198);
    e.s(
      [
        "default",
        0,
        (e) => {
          let { abMyiqNewHomepageCtaCopy: h } = e,
            d = (0, i.useTranslations)(),
            m = (0, a.useUserStore)((e) => e.user) || null,
            { priceForView: u } = (0, c.getPaymentPlanPrice)({ paymentPlan: "DEMO_PRICE", user: m }),
            { priceForView: A } = (0, c.getPaymentPlanPrice)({ paymentPlan: "MONTH_PRICE", user: m }),
            v = (0, c.getCalculatePriceForView)(u, m),
            p = (0, c.getCalculatePriceForView)(A, m),
            g = { today: v, then: p },
            f = (0, r.isUs)(m?.currency?.countryCode),
            _ = (0, o.getHomepageCtaLabelKey)("ab_myiq_home_redesign_pricing_cta_label", h);
          return (0, t.jsxs)(t.Fragment, {
            children: [
              (0, t.jsx)("div", {
                className: "grid grid-cols-2 gap-3",
                children: n.map((e) =>
                  (0, t.jsxs)(
                    "div",
                    {
                      className:
                        "flex min-w-0 flex-col gap-1 rounded-xl bg-light-blue p-3 [container-type:inline-size] xs-sm:p-4 md:p-5",
                      children: [
                        (0, t.jsx)("span", {
                          className: "text-hp-body-sm font-medium text-black-custom",
                          children: d(e.label),
                        }),
                        (0, t.jsx)("span", {
                          className:
                            "text-[clamp(0.875rem,17cqw,2rem)] xs-sm:text-[clamp(1.1rem,17cqw,2rem)] font-semibold leading-tight tracking-tight tabular-nums text-black-custom",
                          children: g[e.id],
                        }),
                        (0, t.jsx)("span", {
                          className: "text-hp-caption text-grey-deep",
                          children: d(e.unit),
                        }),
                      ],
                    },
                    e.id,
                  ),
                ),
              }),
              (0, t.jsxs)("div", {
                className: "flex flex-col gap-3",
                children: [
                  (0, t.jsx)(l.DemoStartCta, {
                    size: "lg",
                    variant: "primary",
                    className: "w-full",
                    children: d(_),
                  }),
                  (0, t.jsxs)("p", {
                    className: "text-pretty text-center text-hp-caption text-grey-deep",
                    children: [
                      d("ab_myiq_home_redesign_pricing_disclosure_before_email", {
                        trialCost: v,
                        fullCost: p,
                      }),
                      (0, t.jsx)("a", {
                        href: `mailto:${s}`,
                        className:
                          "text-blue-custom underline decoration-1 underline-offset-4 transition-colors duration-150",
                        children: s,
                      }),
                      f ? `. ${d("price_excludes_tax")}` : ".",
                    ],
                  }),
                ],
              }),
            ],
          });
        },
      ],
      441932,
    );
  },
  538318,
  (e) => {
    "use strict";
    e.s([
      "REVIEWS",
      0,
      [
        {
          id: "mirekiq",
          rating: 5,
          title: "ab_myiq_home_redesign_reviews_review1_title",
          body: "ab_myiq_home_redesign_reviews_review1_body",
          name: "Mirekiq",
          country: "ab_myiq_home_redesign_reviews_review1_country",
        },
        {
          id: "mbdaking",
          rating: 4,
          title: "ab_myiq_home_redesign_reviews_review2_title",
          body: "ab_myiq_home_redesign_reviews_review2_body",
          name: "Mbdaking",
          country: "ab_myiq_home_redesign_reviews_review2_country",
        },
        {
          id: "eb",
          rating: 5,
          title: "ab_myiq_home_redesign_reviews_review3_title",
          body: "ab_myiq_home_redesign_reviews_review3_body",
          name: "E.B.",
          country: "ab_myiq_home_redesign_reviews_review3_country",
        },
        {
          id: "col-done",
          rating: 4,
          title: "ab_myiq_home_redesign_reviews_review4_title",
          body: "ab_myiq_home_redesign_reviews_review4_body",
          name: "Col Done",
          country: "ab_myiq_home_redesign_reviews_review4_country",
        },
        {
          id: "d-horton",
          rating: 5,
          title: "ab_myiq_home_redesign_reviews_review5_title",
          body: "ab_myiq_home_redesign_reviews_review5_body",
          name: "D Horton",
          country: "ab_myiq_home_redesign_reviews_review5_country",
        },
        {
          id: "king-piper",
          rating: 3,
          title: "ab_myiq_home_redesign_reviews_review6_title",
          body: "ab_myiq_home_redesign_reviews_review6_body",
          name: "King Piper",
          country: "ab_myiq_home_redesign_reviews_review6_country",
        },
        {
          id: "stella",
          rating: 5,
          title: "ab_myiq_home_redesign_reviews_review7_title",
          body: "ab_myiq_home_redesign_reviews_review7_body",
          name: "Stella",
          country: "ab_myiq_home_redesign_reviews_review7_country",
        },
        {
          id: "cathy",
          rating: 4,
          title: "ab_myiq_home_redesign_reviews_review8_title",
          body: "ab_myiq_home_redesign_reviews_review8_body",
          name: "Cathy",
          country: "ab_myiq_home_redesign_reviews_review8_country",
        },
        {
          id: "gordon-stark",
          rating: 3,
          title: "ab_myiq_home_redesign_reviews_review9_title",
          body: "ab_myiq_home_redesign_reviews_review9_body",
          name: "Gordon Stark",
          country: "ab_myiq_home_redesign_reviews_review9_country",
        },
      ],
      "REVIEWS_BADGE",
      0,
      "ab_myiq_home_redesign_reviews_badge",
      "REVIEWS_FOOTER_COUNT",
      0,
      "ab_myiq_home_redesign_reviews_footer_count",
      "REVIEWS_FOOTER_MIDDLE",
      0,
      "ab_myiq_home_redesign_reviews_footer_middle",
      "REVIEWS_FOOTER_NOTE",
      0,
      "ab_myiq_home_redesign_reviews_footer_note",
      "REVIEWS_FOOTER_PREFIX",
      0,
      "ab_myiq_home_redesign_reviews_footer_prefix",
      "REVIEWS_FOOTER_SCORE",
      0,
      "4.1",
      "REVIEWS_LEDE",
      0,
      "ab_myiq_home_redesign_reviews_lede",
      "REVIEWS_NEXT_LABEL",
      0,
      "ab_myiq_home_redesign_reviews_next_label",
      "REVIEWS_PREV_LABEL",
      0,
      "ab_myiq_home_redesign_reviews_prev_label",
      "REVIEWS_TITLE",
      0,
      "ab_myiq_home_redesign_reviews_title",
      "REVIEWS_TRUSTPILOT_LABEL",
      0,
      "Trustpilot",
    ]);
  },
  371576,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(948148),
      a = e.i(271645),
      r = e.i(256889);
    e.i(365694);
    var n = e.i(283023);
    e.i(333163);
    var s = e.i(216839);
    e.i(600987);
    var l = e.i(752714),
      o = e.i(538318);
    let c =
      "absolute top-1/2 z-10 hidden size-10 -translate-y-1/2 items-center justify-center rounded-full bg-white text-black-custom shadow-rd-card ring-1 ring-black/[0.04] transition-opacity duration-200 lg:flex";
    e.s([
      "default",
      0,
      (e) => {
        let { translatedByKey: h } = e,
          d = (0, i.useTranslations)(),
          m = (e) => h?.[e] ?? d(e),
          u = (0, a.useRef)(null),
          [A, v] = (0, a.useState)(!0),
          [p, g] = (0, a.useState)(!1),
          f = (0, a.useCallback)(() => {
            let e = u.current;
            e && (v(e.scrollLeft <= 4), g(e.scrollLeft >= e.scrollWidth - e.clientWidth - 4));
          }, []);
        (0, a.useEffect)(() => {
          let e = u.current;
          if (!e) return;
          let t = requestAnimationFrame(f);
          return (
            e.addEventListener("scroll", f, { passive: !0 }),
            window.addEventListener("resize", f),
            () => {
              (cancelAnimationFrame(t),
                e.removeEventListener("scroll", f),
                window.removeEventListener("resize", f));
            }
          );
        }, [f]);
        let _ = (e) => {
          let t = u.current;
          if (!t) return;
          let i = t.firstElementChild,
            a = Number.parseFloat(getComputedStyle(t).columnGap) || 0,
            r = i ? i.offsetWidth + a : t.clientWidth,
            n = window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth";
          t.scrollBy({ left: e * r, behavior: n });
        };
        return (0, t.jsxs)("div", {
          className: "relative lg:px-14 2xl:px-0",
          children: [
            (0, t.jsx)("ul", {
              ref: u,
              className:
                "flex snap-x snap-mandatory gap-4 overflow-x-auto pb-1 [scrollbar-width:none] lg:gap-6 [&::-webkit-scrollbar]:hidden",
              children: o.REVIEWS.map((e) =>
                (0, t.jsx)(
                  "li",
                  {
                    className:
                      "w-[94%] shrink-0 snap-start xs-m:w-[85%] sm:w-[55%] md:w-[calc((100%-16px)/2)] lg:w-[calc((100%-48px)/3)]",
                    children: (0, t.jsx)(n.DemoCard, {
                      variant: "content",
                      children: (0, t.jsxs)("div", {
                        className: "grid h-full grid-rows-[auto_1fr_auto] gap-5",
                        children: [
                          (0, t.jsxs)("div", {
                            className: "flex items-center justify-between gap-3",
                            children: [
                              (0, t.jsx)(l.DemoStarsComponent, {
                                value: e.rating,
                                idSuffix: e.id,
                                className: "aspect-[27/5] h-5",
                              }),
                              (0, t.jsxs)("span", {
                                className:
                                  "inline-flex h-6 shrink-0 items-center gap-1 rounded-full bg-slate-100 px-2.5 text-hp-caption font-medium text-grey-deep",
                                children: [
                                  (0, t.jsx)(s.IconCheck, { className: "size-3 [stroke-width:2.5]" }),
                                  m(o.REVIEWS_BADGE),
                                ],
                              }),
                            ],
                          }),
                          (0, t.jsxs)("div", {
                            className: "flex flex-col gap-2",
                            children: [
                              (0, t.jsx)("h3", {
                                className: "text-balance text-hp-h4 text-black-custom",
                                children: m(e.title),
                              }),
                              (0, t.jsx)("p", {
                                className: "text-pretty text-hp-body-sm text-grey-deep",
                                children: m(e.body),
                              }),
                            ],
                          }),
                          (0, t.jsxs)("p", {
                            className: "text-hp-body-sm text-grey-deep",
                            children: [
                              (0, t.jsx)("span", {
                                className: "font-medium text-black-custom",
                                children: e.name,
                              }),
                              " · ",
                              m(e.country),
                            ],
                          }),
                        ],
                      }),
                    }),
                  },
                  e.id,
                ),
              ),
            }),
            (0, t.jsx)("button", {
              type: "button",
              "aria-label": m(o.REVIEWS_PREV_LABEL),
              onClick: () => _(-1),
              className: (0, r.cn)(
                c,
                "lg:left-2 2xl:-left-11",
                A ? "pointer-events-none opacity-0" : "opacity-100",
              ),
              children: (0, t.jsx)(s.IconChevronDown, { className: "size-4 rotate-90" }),
            }),
            (0, t.jsx)("button", {
              type: "button",
              "aria-label": m(o.REVIEWS_NEXT_LABEL),
              onClick: () => _(1),
              className: (0, r.cn)(
                c,
                "lg:right-2 2xl:-right-11",
                p ? "pointer-events-none opacity-0" : "opacity-100",
              ),
              children: (0, t.jsx)(s.IconChevronDown, { className: "size-4 -rotate-90" }),
            }),
          ],
        });
      },
    ]);
  },
  256889,
  (e) => {
    "use strict";
    e.s([
      "cn",
      0,
      function () {
        for (var e = arguments.length, t = Array(e), i = 0; i < e; i++) t[i] = arguments[i];
        return t.filter(Boolean).join(" ");
      },
    ]);
  },
  6437,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(271645),
      a = e.i(256889);
    e.s([
      "default",
      0,
      (e) => {
        let { items: r, split: n = !1, className: s, defaultOpenId: l = r[0]?.id ?? null } = e,
          o = n ? [r.slice(0, Math.ceil(r.length / 2)), r.slice(Math.ceil(r.length / 2))] : [r],
          [c, h] = (0, i.useState)(l);
        return (0, t.jsxs)(t.Fragment, {
          children: [
            (0, t.jsx)("div", {
              "data-demo-accordion": !0,
              className: (0, a.cn)(n && "grid grid-cols-1 items-start lg:grid-cols-2 lg:gap-x-16", s),
              children: o.map((e, i) =>
                (0, t.jsx)(
                  "div",
                  {
                    className: (0, a.cn)(
                      "divide-y divide-slate-100 border-y border-slate-100",
                      n && 1 === i && "border-t-0 lg:border-t",
                    ),
                    children: e.map((e) => {
                      let i = c === e.id;
                      return (0, t.jsxs)(
                        "div",
                        {
                          children: [
                            (0, t.jsx)("h3", {
                              children: (0, t.jsxs)("button", {
                                type: "button",
                                id: `${e.id}-trigger`,
                                "aria-expanded": i,
                                "aria-controls": `${e.id}-panel`,
                                onClick: () => h(i ? null : e.id),
                                className:
                                  "flex w-full items-center justify-between gap-4 rounded-lg py-4 text-start text-hp-lede text-black-custom focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom",
                                children: [
                                  e.question,
                                  (0, t.jsxs)("span", {
                                    "aria-hidden": !0,
                                    className: "relative size-4 shrink-0 text-black-custom",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className:
                                          "absolute left-0 top-1/2 h-[1.5px] w-full -translate-y-1/2 rounded-full bg-current",
                                      }),
                                      (0, t.jsx)("span", {
                                        className: (0, a.cn)(
                                          "absolute left-1/2 top-0 h-full w-[1.5px] -translate-x-1/2 rounded-full bg-current transition-transform duration-200 motion-reduce:transition-none",
                                          i && "scale-y-0",
                                        ),
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            }),
                            (0, t.jsx)("div", {
                              id: `${e.id}-panel`,
                              role: "region",
                              "aria-labelledby": `${e.id}-trigger`,
                              className: (0, a.cn)(
                                "grid transition-[grid-template-rows] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] motion-reduce:transition-none",
                                i ? "grid-rows-[1fr]" : "grid-rows-[0fr]",
                              ),
                              children: (0, t.jsx)("div", {
                                className: "overflow-hidden",
                                children: (0, t.jsx)("p", {
                                  className: "text-pretty pb-6 text-hp-body text-grey-deep",
                                  children: e.answer,
                                }),
                              }),
                            }),
                          ],
                        },
                        e.id,
                      );
                    }),
                  },
                  e[0]?.id ?? i,
                ),
              ),
            }),
            (0, t.jsxs)("noscript", {
              children: [
                (0, t.jsx)("style", { children: "[data-demo-accordion]{display:none}" }),
                (0, t.jsx)("dl", {
                  className: (0, a.cn)("divide-y divide-slate-100 border-y border-slate-100", s),
                  children: r.map((e) =>
                    (0, t.jsxs)(
                      "div",
                      {
                        className: "py-4",
                        children: [
                          (0, t.jsx)("dt", {
                            className: "text-hp-lede text-black-custom",
                            children: e.question,
                          }),
                          (0, t.jsx)("dd", {
                            className: "mt-3 text-pretty text-hp-body text-grey-deep",
                            children: e.answer,
                          }),
                        ],
                      },
                      e.id,
                    ),
                  ),
                }),
              ],
            }),
          ],
        });
      },
    ]);
  },
  872721,
  652050,
  (e) => {
    "use strict";
    var t = e.i(271645),
      i = e.i(866897),
      a = e.i(157273),
      r = e.i(86596),
      n = e.i(924254),
      s = e.i(60423),
      l = e.i(523173),
      o = e.i(134404);
    e.i(470366);
    var c = e.i(504001),
      h = e.i(202042);
    (e.s(
      [
        "useDemoHomeTracking",
        0,
        () => {
          let e = (0, h.useRouter)(),
            d = (0, r.useUserStore)((e) => e.user),
            m = (0, r.useUserStore)((e) => e.handleChangeUserStore),
            u = (0, t.useCallback)(
              (e) => {
                (0, c.trackClientEvents)({
                  event: l.EAnalyticEvents.PAGE_CLICKED,
                  params: e,
                  sessionId: d?.id,
                  user: d,
                });
              },
              [d],
            ),
            A = (0, t.useCallback)(
              (t) => {
                (u({
                  page_name: "startCertifiedTestButtonClicked",
                  page_title: "Start",
                  ...(t && { gender: t }),
                }),
                  (0, c.trackClientEvents)({
                    event: l.EAnalyticEvents.FUNNEL_START_VIEW,
                    sessionId: d?.id,
                    user: d,
                  }),
                  (0, c.setPeopleAnalytic)({ funnel: "myiq", ...(t && { gender: t }) }),
                  s.accessLocalStorage.removeItem(a.StorageKeys.LOVE_LANGUAGE_QUIZ_ANSWERS),
                  s.accessLocalStorage.removeItem(a.StorageKeys.PERSONALITY_QUIZ_ANSWERS),
                  s.accessLocalStorage.removeItem(a.StorageKeys.QUIZ_ANSWERS),
                  n.accessCookie.removeItem(i.ECookieArg.LEGACY_FUNNEL),
                  m({
                    user: {
                      nextBillingDate: void 0,
                      billingSubscriptionData: void 0,
                      paynextSubscription: void 0,
                      paymentInfo: void 0,
                      isPaynextSubscribed: void 0,
                      ...(t && { gender: t }),
                    },
                  }),
                  e.push(o.EClientRoutes.QUIZ));
              },
              [u, d, m, e],
            ),
            v = (0, t.useCallback)(() => u({ page_name: "loginButtonClicked" }), [u]),
            p = (0, t.useCallback)((e) => u({ page_name: `${e}LinkClicked` }), [u]);
          return {
            startFunnel: A,
            trackLogin: v,
            trackFooterLink: p,
            trackHowToCancel: (0, t.useCallback)(() => {
              (0, c.trackClientEvents)({
                event: l.EAnalyticEvents.CANCEL_FLOW_HOW_TO_CANCEL_BUTTON_CLICKED,
                sessionId: d?.id,
              });
            }, [d]),
            trackContactSupport: (0, t.useCallback)(() => {
              (0, c.trackClientEvents)({
                event: l.EAnalyticEvents.CANCEL_FLOW_CONTACT_SUPPORT_BUTTON_CLICKED,
                sessionId: d?.id,
              });
            }, [d]),
          };
        },
      ],
      652050,
    ),
      e.s([], 872721));
  },
  791371,
  642448,
  (e) => {
    "use strict";
    var t = e.i(843476);
    e.i(340609);
    var i = e.i(90147),
      a = e.i(256889);
    let r = { sm: "h-9 px-3 text-hp-body-sm", md: "h-11 px-5 text-hp-body-sm", lg: "h-12 px-6 text-hp-body" },
      n = {
        primary:
          "bg-green-custom text-white border-transparent [@media(hover:hover)]:hover:bg-[#0B635C] active:bg-[#094F4A]",
        secondary:
          "bg-white text-green-custom border-green-custom [@media(hover:hover)]:hover:bg-green-custom/[0.06] active:bg-green-custom/[0.10]",
        ghost:
          "bg-transparent text-grey-deep border-transparent [@media(hover:hover)]:hover:bg-black-custom/[0.04] [@media(hover:hover)]:hover:text-black-custom active:bg-black-custom/[0.06]",
        danger:
          "bg-danger-custom text-white border-transparent [@media(hover:hover)]:hover:bg-danger-custom/90 active:bg-danger-custom/80",
      },
      s = (0, t.jsx)(i.Spinner, { size: "sm", color: "current", "aria-hidden": "true" });
    (e.s([], 791371),
      e.s(
        [
          "DemoButton",
          0,
          (e) => {
            let {
                size: i = "md",
                variant: l = "primary",
                href: o,
                type: c,
                disabled: h,
                isLoading: d,
                dataNr: m,
                className: u,
                onClick: A,
                children: v,
              } = e,
              p = (0, a.cn)(
                "inline-flex items-center justify-center gap-2 shrink-0 select-none rounded-full border border-transparent font-medium whitespace-nowrap transition-colors duration-150 ease-[cubic-bezier(0.4,0,0.2,1)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom disabled:cursor-not-allowed disabled:opacity-50 [&_svg]:size-4 [&_svg]:shrink-0",
                r[i],
                n[l],
                u,
              );
            return o
              ? (0, t.jsx)("a", { href: o, className: p, onClick: A, "data-nr": m, children: v })
              : (0, t.jsxs)("button", {
                  type: c ?? "button",
                  disabled: h,
                  className: p,
                  onClick: A,
                  "data-nr": m,
                  "data-loading": d || void 0,
                  children: [d && s, v],
                });
          },
        ],
        642448,
      ));
  },
  365694,
  283023,
  600987,
  752714,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(256889);
    let a = {
      content: "flex h-full flex-col rounded-2xl border border-slate-200 bg-white p-5 lg:p-6",
      chip: "flex items-start gap-3 rounded-xl border border-slate-200 bg-white p-4",
      panel: "rounded-3xl bg-light-blue p-6 lg:p-10",
      vignette:
        "relative px-5 pb-5 lg:rounded-3xl lg:border lg:border-slate-200 lg:bg-white lg:p-6 lg:shadow-rd-card",
    };
    (e.s([], 365694),
      e.s(
        [
          "DemoCard",
          0,
          (e) => {
            let { variant: r = "content", interactive: n = !1, as: s = "div", className: l, children: o } = e;
            return (0, t.jsx)(s, {
              className: (0, i.cn)(
                a[r],
                n && "transition-colors duration-150 [@media(hover:hover)]:hover:border-slate-300",
                l,
              ),
              children: o,
            });
          },
        ],
        283023,
      ));
    let r = [0, 1, 2, 3, 4],
      n = r
        .map(
          (e) =>
            `M${10 + 22 * e} 3.5l1.55 4.77h4.95l-4.03 2.93 1.55 4.77-4.02-2.93-4.02 2.93 1.55-4.77-4.03-2.93h4.95z`,
        )
        .join(""),
      s = "#00b67a";
    (e.s([], 600987),
      e.s(
        [
          "DemoStarsComponent",
          0,
          (e) => {
            let { value: i, idSuffix: a, className: l } = e,
              o = `demo-stars-${a}`,
              c = Math.floor(i),
              h = Math.round((i % 1) * 2e3) / 100,
              d = 22 * c;
            return (0, t.jsxs)("svg", {
              viewBox: "0 0 108 20",
              preserveAspectRatio: "xMinYMid meet",
              role: "img",
              "aria-label": `Rated ${i} out of 5`,
              className: l,
              children: [
                r.map((e) =>
                  (0, t.jsx)(
                    "rect",
                    { x: 22 * e, width: "20", height: "20", rx: "2", fill: e < c ? s : "#DCDCE6" },
                    e,
                  ),
                ),
                h > 0 &&
                  c < r.length &&
                  (0, t.jsxs)(t.Fragment, {
                    children: [
                      (0, t.jsx)("clipPath", {
                        id: o,
                        children: (0, t.jsx)("rect", { x: d, width: h, height: "20" }),
                      }),
                      (0, t.jsx)("rect", {
                        x: d,
                        width: "20",
                        height: "20",
                        rx: "2",
                        fill: s,
                        clipPath: `url(#${o})`,
                      }),
                    ],
                  }),
                (0, t.jsx)("path", { d: n, fill: "#FFFFFF" }),
              ],
            });
          },
        ],
        752714,
      ));
  },
  929072,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(271645),
      a = e.i(256889);
    let r = "flex shrink-0 gap-4 md:grid",
      n = (e, t, i, a) => {
        let r = Number.parseFloat(getComputedStyle(i).columnGap) || 0,
          n = a.offsetWidth + r;
        if (!n) return () => {};
        let s = 36e3 / n,
          l = i.animate([{ transform: "translateX(0px)" }, { transform: `translateX(-${n}px)` }], {
            duration: 36e3,
            iterations: 1 / 0,
            easing: "linear",
          }),
          o = !0,
          c = !1,
          h = !1,
          d = 0,
          m = 0,
          u = 0,
          A = 0,
          v = 0,
          p = 0,
          g = 0,
          f = 0,
          _ = null,
          b = (e) => ((e % 36e3) + 36e3) % 36e3,
          x = () => Number(l.currentTime ?? 0),
          y = () => {
            !o || c || h || "visible" !== document.visibilityState ? l.pause() : l.play();
          },
          w = () => {
            ((h = !0),
              window.clearTimeout(d),
              (d = window.setTimeout(() => {
                ((h = !1), y());
              }, 3e3)));
          },
          z = (e) => {
            l.currentTime = b(x() + e * s);
          },
          M = () => {
            ((u = 0), null !== _ && ((l.currentTime = b(v - (_ - A) * s)), (_ = null)));
          },
          j = (e) => {
            ("mouse" !== e.pointerType || 0 === e.button) &&
              (cancelAnimationFrame(m),
              cancelAnimationFrame(u),
              (u = 0),
              (_ = null),
              (c = !0),
              l.pause(),
              (A = e.clientX),
              (p = e.clientX),
              (g = performance.now()),
              (v = x()),
              (f = 0),
              t.setPointerCapture(e.pointerId));
          },
          E = (e) => {
            if (!c) return;
            let t = performance.now(),
              i = t - g;
            (i > 0 && (f = (e.clientX - p) / i),
              (p = e.clientX),
              (g = t),
              (_ = e.clientX),
              u || (u = requestAnimationFrame(M)));
          },
          k = (e) => {
            if (!c) return;
            ((c = !1), t.hasPointerCapture(e.pointerId) && t.releasePointerCapture(e.pointerId));
            let i = f,
              a = () => {
                0.02 > Math.abs(i) ? w() : (z(-(16 * i)), (i *= 0.94), (m = requestAnimationFrame(a)));
              };
            m = requestAnimationFrame(a);
          },
          N = (e) => {
            Math.abs(e.deltaX) <= Math.abs(e.deltaY) || (e.preventDefault(), l.pause(), z(e.deltaX), w());
          },
          C =
            "IntersectionObserver" in window
              ? new IntersectionObserver(
                  (e) => {
                    let [t] = e;
                    ((o = t.isIntersecting), y());
                  },
                  { threshold: 0.4 },
                )
              : null;
        return (
          C?.observe(e),
          document.addEventListener("visibilitychange", y),
          t.addEventListener("pointerdown", j),
          t.addEventListener("pointermove", E),
          t.addEventListener("pointerup", k),
          t.addEventListener("pointercancel", k),
          t.addEventListener("wheel", N, { passive: !1 }),
          y(),
          () => {
            (cancelAnimationFrame(m),
              cancelAnimationFrame(u),
              window.clearTimeout(d),
              C?.disconnect(),
              document.removeEventListener("visibilitychange", y),
              t.removeEventListener("pointerdown", j),
              t.removeEventListener("pointermove", E),
              t.removeEventListener("pointerup", k),
              t.removeEventListener("pointercancel", k),
              t.removeEventListener("wheel", N),
              l.cancel());
          }
        );
      };
    e.s(
      [
        "default",
        0,
        (e) => {
          let { as: s = "ul", label: l, className: o, children: c } = e,
            h = (0, i.useRef)(null),
            d = (0, i.useRef)(null),
            m = (0, i.useRef)(null),
            u = (0, i.useRef)(null);
          return (
            (0, i.useEffect)(() => {
              let e = h.current,
                t = d.current,
                i = m.current,
                a = u.current;
              if (!e || !t || !i || !a) return;
              let r = n(e, t, i, a),
                s = window.innerWidth,
                l = 0,
                o = () => {
                  window.innerWidth !== s &&
                    (window.clearTimeout(l),
                    (l = window.setTimeout(() => {
                      ((s = window.innerWidth), r(), (r = n(e, t, i, a)));
                    }, 150)));
                };
              return (
                window.addEventListener("resize", o),
                () => {
                  (window.clearTimeout(l), window.removeEventListener("resize", o), r());
                }
              );
            }, []),
            (0, t.jsx)("div", {
              ref: h,
              role: "region",
              "aria-roledescription": "carousel",
              "aria-label": l,
              className: "md:contents",
              children: (0, t.jsxs)("div", {
                ref: d,
                className:
                  "relative cursor-grab touch-pan-y select-none overflow-hidden active:cursor-grabbing md:contents",
                children: [
                  (0, t.jsx)("span", {
                    "aria-hidden": !0,
                    className:
                      "pointer-events-none absolute inset-y-0 left-0 z-10 w-5 bg-gradient-to-r from-white to-transparent md:hidden",
                  }),
                  (0, t.jsxs)("div", {
                    ref: m,
                    className:
                      "flex w-max gap-4 will-change-transform md:block md:w-auto md:will-change-auto",
                    children: [
                      (0, t.jsx)(s, { ref: u, className: (0, a.cn)(r, o), children: c }),
                      (0, t.jsx)(s, { "aria-hidden": !0, className: (0, a.cn)(r, "md:hidden"), children: c }),
                    ],
                  }),
                  (0, t.jsx)("span", {
                    "aria-hidden": !0,
                    className:
                      "pointer-events-none absolute inset-y-0 right-0 z-10 w-5 bg-gradient-to-l from-white to-transparent md:hidden",
                  }),
                ],
              }),
            })
          );
        },
      ],
      929072,
    );
  },
  872756,
  987132,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(256889);
    (e.s([], 872756),
      e.s(
        [
          "DemoContainer",
          0,
          (e) => {
            let { className: a, children: r } = e;
            return (0, t.jsx)("div", {
              className: (0, i.cn)("mx-auto w-full max-w-7xl px-4 md:px-6 lg:px-8", a),
              children: r,
            });
          },
        ],
        987132,
      ));
  },
  276935,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(948148);
    let a = [
      { id: "male", label: "profile_page_gender_m" },
      { id: "female", label: "profile_page_gender_f" },
    ];
    var r = e.i(256889);
    e.i(331955);
    var n = e.i(957397);
    e.s(
      [
        "default",
        0,
        (e) => {
          let { className: s, promptClassName: l, pairClassName: o, buttonClassName: c } = e,
            h = (0, i.useTranslations)();
          return (0, t.jsxs)("div", {
            className: s,
            children: [
              (0, t.jsx)("p", { className: l, children: h("ab_myiq_home_redesign_hero_gender_prompt") }),
              (0, t.jsx)("div", {
                className: o ?? "grid grid-cols-2 gap-3",
                children: a.map((e) =>
                  (0, t.jsx)(
                    n.DemoStartCta,
                    {
                      size: "lg",
                      variant: "primary",
                      gender: e.id,
                      className: (0, r.cn)("w-full", c),
                      children: h(e.label),
                    },
                    e.id,
                  ),
                ),
              }),
            ],
          });
        },
      ],
      276935,
    );
  },
  333163,
  216839,
  (e) => {
    "use strict";
    var t = e.i(843476);
    let i = {
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 1.5,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      "aria-hidden": !0,
    };
    (e.s(
      [
        "IconCheck",
        0,
        (e) => {
          let { className: a } = e;
          return (0, t.jsx)("svg", {
            ...i,
            className: a,
            children: (0, t.jsx)("path", { d: "M20 6 9 17l-5-5" }),
          });
        },
        "IconChevronDown",
        0,
        (e) => {
          let { className: a } = e;
          return (0, t.jsx)("svg", {
            ...i,
            className: a,
            children: (0, t.jsx)("path", { d: "m6 9 6 6 6-6" }),
          });
        },
        "IconClose",
        0,
        (e) => {
          let { className: a } = e;
          return (0, t.jsxs)("svg", {
            ...i,
            className: a,
            children: [(0, t.jsx)("path", { d: "m6 6 12 12" }), (0, t.jsx)("path", { d: "m18 6-12 12" })],
          });
        },
      ],
      216839,
    ),
      e.s([], 333163));
  },
  524579,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(861745),
      a = e.i(19576),
      r = e.i(256889);
    let n = "flex items-center whitespace-nowrap text-hp-body font-medium";
    e.s([
      "default",
      0,
      (e) => {
        let { items: s, className: l } = e,
          o = (0, i.useLocale)(),
          c = "rtl" === (0, a.getLocaleDirection)(o);
        return (0, t.jsx)("div", {
          className: (0, r.cn)(
            "group relative w-full overflow-hidden [--duration:48s] [--gap:64px]",
            "[mask-image:linear-gradient(to_right,transparent,black_96px,black_calc(100%-96px),transparent)]",
            l,
          ),
          children: (0, t.jsxs)("div", {
            className: (0, r.cn)(
              "flex w-max gap-16 group-focus-within:[animation-play-state:paused] group-hover:[animation-play-state:paused]",
              c ? "animate-scrolling-banner-rtl" : "animate-scrolling-banner",
            ),
            children: [
              s.map((e) => (0, t.jsx)("span", { className: n, children: e.node }, e.key)),
              s.map((e) =>
                (0, t.jsx)(
                  "span",
                  { "aria-hidden": "true", className: n, children: e.node },
                  `${e.key}-duplicate`,
                ),
              ),
            ],
          }),
        });
      },
    ]);
  },
  812857,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(134404);
    e.i(872721);
    var a = e.i(652050);
    e.i(791371);
    var r = e.i(642448);
    e.s([
      "default",
      0,
      (e) => {
        let { size: n = "lg", variant: s = "primary", gender: l, className: o, children: c } = e,
          { startFunnel: h } = (0, a.useDemoHomeTracking)();
        return (0, t.jsx)(r.DemoButton, {
          size: n,
          variant: s,
          href: i.EClientRoutes.QUIZ,
          onClick: (e) => {
            e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || 0 !== e.button || (e.preventDefault(), h(l));
          },
          className: o,
          children: c,
        });
      },
    ]);
  },
  331955,
  957397,
  (e) => {
    "use strict";
    var t = e.i(812857);
    (e.s([], 331955), e.s(["DemoStartCta", () => t.default], 957397));
  },
  911271,
  (e) => {
    "use strict";
    e.s(
      [
        "getHomepageCtaLabelKey",
        0,
        (e, t) =>
          "v1_get_iq_score" === t
            ? "ab_myiq_checkout_redesign_closing_cta"
            : "v2_find_out_iq" === t
              ? "ab_myiq_new_homepage_cta_copy_v2_label"
              : "v3_continue_cta" === t
                ? "btn_continue"
                : e,
      ],
      911271,
    );
  },
  83029,
  494967,
  676258,
  229742,
  40959,
  (e) => {
    "use strict";
    var t,
      i,
      a,
      r,
      n,
      s,
      l,
      o,
      c,
      h,
      d,
      m,
      u,
      A,
      v,
      p,
      g,
      f,
      _,
      b,
      x,
      y,
      w,
      z,
      M,
      j,
      E,
      k,
      N,
      C,
      q = e.i(271645);
    function I() {
      return (I = Object.assign.bind()).apply(null, arguments);
    }
    function S() {
      return (S = Object.assign.bind()).apply(null, arguments);
    }
    function R() {
      return (R = Object.assign.bind()).apply(null, arguments);
    }
    function L() {
      return (L = Object.assign.bind()).apply(null, arguments);
    }
    (e.s(
      [
        "default",
        0,
        (e) =>
          q.createElement(
            "svg",
            I({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 357 379" }, e),
            q.createElement(
              "g",
              { clipPath: "url(#a-1_svg__a)" },
              t ||
                (t = q.createElement("path", {
                  fill: "#FE0D0B",
                  d: "M304.015 127.868c-35.775-17.449-85.258-6.795-121.034-24.244l9.519-19.516c35.776 17.449 85.259 6.794 121.034 24.243z",
                })),
              i ||
                (i = q.createElement("path", {
                  fill: "#F80",
                  d: "M294.5 147.387c-35.776-17.449-85.259-6.794-121.035-24.243l9.519-19.517c35.776 17.449 85.259 6.794 121.035 24.243z",
                })),
              a ||
                (a = q.createElement("path", {
                  fill: "#FFD800",
                  d: "M284.98 166.903c-35.775-17.449-85.258-6.794-121.034-24.243l9.519-19.517c35.775 17.449 85.258 6.794 121.034 24.243z",
                })),
              r ||
                (r = q.createElement("path", {
                  fill: "#49B109",
                  d: "M275.461 186.418c-35.776-17.449-85.259-6.794-121.035-24.243l9.519-19.516c35.776 17.449 85.259 6.794 121.035 24.243z",
                })),
              n ||
                (n = q.createElement("path", {
                  fill: "#046EDE",
                  d: "M265.941 205.934c-35.776-17.449-85.259-6.794-121.034-24.243l9.519-19.517c35.775 17.449 85.258 6.794 121.034 24.243z",
                })),
              s ||
                (s = q.createElement("path", {
                  fill: "#800BBA",
                  d: "M256.422 225.453c-29.836-14.551-69.205-9.557-102.206-17.618-10.73-2.621-14.903-14.673-10.061-24.601l.751-1.54c35.776 17.449 85.259 6.794 121.035 24.243z",
                })),
              q.createElement(
                "mask",
                {
                  id: "a-1_svg__b",
                  width: 124,
                  height: 45,
                  x: 142,
                  y: 181,
                  maskUnits: "userSpaceOnUse",
                  style: { maskType: "alpha" },
                },
                l ||
                  (l = q.createElement("path", {
                    fill: "#800BBA",
                    d: "M256.426 225.453c-29.836-14.551-69.205-9.557-102.206-17.618-10.73-2.621-14.904-14.673-10.061-24.601l.751-1.54c35.776 17.449 85.259 6.794 121.035 24.243z",
                  })),
              ),
              o ||
                (o = q.createElement(
                  "g",
                  { mask: "url(#a-1_svg__b)" },
                  q.createElement("path", { fill: "#000", d: "m169.022 194.905-33.64 6.303 17.47-35.817z" }),
                )),
              c ||
                (c = q.createElement("path", {
                  fill: "#FE0D0B",
                  d: "M216.617 97.317c-35.776-17.45-85.259-6.794-121.034-24.243l.751-1.541c4.842-9.928 16.866-13.972 27.596-11.351 26.431 6.456 56.946 4.538 83.377 10.994 10.73 2.62 14.904 14.672 10.061 24.6z",
                })),
              h ||
                (h = q.createElement("path", {
                  fill: "#F80",
                  d: "M207.101 116.836c-35.775-17.449-85.258-6.794-121.034-24.243l9.519-19.516c35.776 17.449 85.259 6.794 121.034 24.243z",
                })),
              d ||
                (d = q.createElement("path", {
                  fill: "#FFD800",
                  d: "M197.582 136.352c-35.776-17.449-85.259-6.794-121.035-24.243l9.52-19.517c35.775 17.449 85.258 6.794 121.034 24.243z",
                })),
              m ||
                (m = q.createElement("path", {
                  fill: "#49B109",
                  d: "M188.062 155.868c-35.775-17.449-85.258-6.795-121.034-24.244l9.519-19.516c35.775 17.449 85.258 6.794 121.034 24.243z",
                })),
              u ||
                (u = q.createElement("path", {
                  fill: "#046EDE",
                  d: "M178.543 175.383c-35.776-17.449-85.259-6.794-121.035-24.243l9.52-19.517c35.775 17.449 85.258 6.795 121.034 24.244z",
                })),
              A ||
                (A = q.createElement("path", {
                  fill: "#800BBA",
                  d: "M169.023 194.903c-29.835-14.552-69.204-9.558-102.205-17.619-10.73-2.621-14.904-14.672-10.062-24.6l.752-1.541c35.775 17.449 85.258 6.794 121.034 24.243z",
                })),
              v ||
                (v = q.createElement("path", {
                  stroke: "#000",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 3.572,
                  d: "M223.704 328.086c-8.002 1.949-20.172 3.458-36.226 1.326-8.067-1.001-8.865-2.371-13.581-2.224s-19.994 14.935-19.994 14.935",
                })),
              p ||
                (p = q.createElement("path", {
                  stroke: "#000",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 14.29,
                  d: "M318.055 99.074 215.367 309.616M215.668 308.996l-20.335 41.693",
                })),
              g ||
                (g = q.createElement("path", {
                  fill: "#fff",
                  d: "m235.282 310.191-21.79-10.628a7.523 7.523 0 0 0-10.059 3.464 7.52 7.52 0 0 0 3.463 10.058l21.791 10.628a7.523 7.523 0 0 0 6.595-13.522",
                })),
              f ||
                (f = q.createElement("path", {
                  fill: "#fff",
                  stroke: "#000",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 3.572,
                  d: "m268 258.16-15.522-7.571c-4.984-2.431-10.996-.361-13.426 4.623h0c-2.431 4.984-.362 10.995 4.623 13.426l15.522 7.571c4.984 2.431 10.995.361 13.426-4.623s.361-10.995-4.623-13.426",
                })),
              _ ||
                (_ = q.createElement("path", {
                  fill: "#fff",
                  stroke: "#000",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 3.572,
                  d: "m261.472 277.317-24.533-11.966c-4.985-2.431-10.996-.361-13.426 4.623h0c-2.431 4.984-.362 10.995 4.622 13.426l24.534 11.966c4.984 2.43 10.995.361 13.426-4.623s.361-10.996-4.623-13.426",
                })),
              b ||
                (b = q.createElement("path", {
                  fill: "#fff",
                  stroke: "#000",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 3.572,
                  d: "m247.792 292.985-22.853-11.146c-4.985-2.431-10.996-.361-13.426 4.623h0c-2.431 4.984-.362 10.995 4.622 13.426l22.854 11.146c4.984 2.431 10.995.362 13.426-4.623 2.431-4.984.361-10.995-4.623-13.426",
                })),
              x ||
                (x = q.createElement("path", {
                  stroke: "#000",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 3.572,
                  d: "m221.497 321.143-14.203-6.927a8.375 8.375 0 0 1-3.856-11.2 8.375 8.375 0 0 1 11.199-3.856l20.286 9.894a8.375 8.375 0 0 1 3.856 11.199 8.34 8.34 0 0 1-3.793 3.826",
                })),
              y ||
                (y = q.createElement("path", {
                  stroke: "#000",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 3.572,
                  d: "M234.986 324.077s-3.836 2.195-11.28 4.008",
                })),
              w ||
                (w = q.createElement("path", {
                  fill: "#fff",
                  d: "M125.97 283.169c8.435-5.023 19.86-11.589 27.995-16.543 8.615-7.071 29.417-26.98 42.559-34.951 1.41-.848 2.834-1.564 4.355-2.031 4.119-1.15 7.875-.824 12.602-.498 6.189.539 12.944 1.62 19.077 2.892a120 120 0 0 1 7.129 1.686c3.02.795 6.303 1.977 8.04 4.1 6.249 7.192 5.736 21.119 5.775 30.389-.03 3.04.05 6.988-.057 9.546-.038.444-.105.742-.312 1.072-.421.6-1.103.985-1.755 1.328-1.735.956-4.406 1.214-6.536.522-7.328-2.08-12.136-12.831-13.571-19.763-.426-1.855-.406-3.02-.973-3.905-.491-.562-1.315-.288-2.003-.219a43 43 0 0 1-5.814.625c-1.39.069-2.595.098-3.45.273-1.422.255-1.88 1.115-2.326 2.345-4.457 13.467-14.528 26.734-33.859 30.394",
                })),
              z ||
                (z = q.createElement("path", {
                  stroke: "#000",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 3.572,
                  d: "M125.97 283.169c8.435-5.023 19.86-11.589 27.995-16.543 8.615-7.071 29.417-26.98 42.559-34.951 1.41-.848 2.834-1.564 4.355-2.031 4.119-1.15 7.875-.824 12.602-.498 6.189.539 12.944 1.62 19.078 2.892a120 120 0 0 1 7.128 1.686c3.02.795 6.303 1.977 8.04 4.1 6.249 7.192 5.736 21.119 5.775 30.389-.03 3.04.05 6.988-.057 9.546-.038.444-.105.742-.312 1.072-.421.6-1.103.985-1.755 1.328-1.735.956-4.406 1.214-6.536.522-7.328-2.08-12.136-12.831-13.571-19.763-.426-1.855-.406-3.02-.973-3.905-.491-.562-1.315-.288-2.003-.219a43 43 0 0 1-5.814.625c-1.39.069-2.595.098-3.45.273-1.422.255-1.88 1.115-2.326 2.345-4.457 13.467-14.528 26.734-33.859 30.394",
                })),
            ),
            M ||
              (M = q.createElement(
                "defs",
                null,
                q.createElement(
                  "clipPath",
                  { id: "a-1_svg__a" },
                  q.createElement("path", {
                    fill: "#fff",
                    d: "m131.223 0 225.114 109.795-131.223 269.046L.001 269.046z",
                  }),
                ),
              )),
          ),
      ],
      494967,
    ),
      e.s(
        [
          "default",
          0,
          (e) =>
            q.createElement(
              "svg",
              R({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 34 31" }, e),
              k ||
                (k = q.createElement("path", {
                  fill: "#E63942",
                  d: "m20.978 7.584 1.524 1.51a1.897 1.897 0 0 1-.001 2.696 1.935 1.935 0 0 1-2.722-.001l-1.666-1.651L14.11 6.17a6.24 6.24 0 0 0-4.274-1.496A6.23 6.23 0 0 0 5.67 6.466a6.1 6.1 0 0 0-1.814 4.124 6.1 6.1 0 0 0 1.507 4.234l10.506 10.42.316.314a.513.513 0 0 0 .726 0l10.822-10.734a6.1 6.1 0 0 0 1.507-4.233 6.1 6.1 0 0 0-1.812-4.124 6.23 6.23 0 0 0-5.176-1.747L19.14 1.639c1.31-.548 2.734-.82 4.18-.78a10.1 10.1 0 0 1 6.827 2.903 9.9 9.9 0 0 1 2.946 6.755 9.9 9.9 0 0 1-2.546 6.91l-.012.013-13.2 13.092a1.1 1.1 0 0 1-.787.323 1.12 1.12 0 0 1-.788-.323L2.548 17.428a9.9 9.9 0 0 1-2.544-6.907 9.9 9.9 0 0 1 2.94-6.75A10.1 10.1 0 0 1 9.767.86a10.1 10.1 0 0 1 6.777 2.36l.005-.005 4.42 4.376z",
                })),
            ),
        ],
        676258,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            q.createElement(
              "svg",
              L({ xmlns: "http://www.w3.org/2000/svg", width: 105, height: 30, fill: "none" }, e),
              N ||
                (N = q.createElement("path", {
                  fill: "#fff",
                  fillRule: "evenodd",
                  d: "m14.29 22.788-.082-.048zm-8.865-12.77-.373-.148a.7.7 0 0 1-.338.41l-.286.148a4.04 4.04 0 0 0-1.62 1.517 4.25 4.25 0 0 0 .068 4.469l.301.476.002.003c.4.619 1.006 1.07 1.707 1.264a2.9 2.9 0 0 0 2.098-.215l.004-.002a.65.65 0 0 1 .513-.04c.17.056.314.183.399.354.084.173.1.374.041.56a.7.7 0 0 1-.344.417l-.376.197.22.364a3.3 3.3 0 0 0 1.082 1.101l.01.007a3.2 3.2 0 0 0 2.471.323l.008-.002 6.186-1.85h.001a.65.65 0 0 1 .51.058c.157.09.277.241.33.426a.77.77 0 0 1-.063.555.7.7 0 0 1-.405.344l-1.54.461-.702.211.557.477c.358.306.688.563.991.8v.001c.957.749 1.659 1.297 2.19 2.528l.003.009.005.009a1 1 0 0 0 .929.567 1 1 0 0 0 .729-.314 1.06 1.06 0 0 0 .298-.743v-1.698a.76.76 0 0 1 .151-.45.7.7 0 0 1 .372-.254h.002l3.928-1.012c.398-.093.749-.326.993-.656s.367-.734.35-1.145a1.8 1.8 0 0 0-.5-1.237l-.005-.004-.634-.641-.207-.21-.261.136-.255.132a.66.66 0 0 1-.664-.025.7.7 0 0 1-.254-.286v-.001a.73.73 0 0 1 .091-.792.7.7 0 0 1 .208-.167h.001l.433-.224.008-.004.008-.005a3.83 3.83 0 0 0 1.412-1.427 4 4 0 0 0 .519-1.962c0-.42-.08-.835-.235-1.223a3.2 3.2 0 0 0-.67-1.04h-.001l-.328-.339-.002-.001a.8.8 0 0 1-.17-.283l-.07-.22a5.5 5.5 0 0 0-1.784-2.606 5.24 5.24 0 0 0-2.893-1.146l-.14-.01-.115.078a2.62 2.62 0 0 0-1.054 1.499 2.7 2.7 0 0 0 .168 1.837l.003.006a.73.73 0 0 1-.092.792.7.7 0 0 1-.204.165.65.65 0 0 1-.664-.025.7.7 0 0 1-.254-.285 4.2 4.2 0 0 1-.384-2.288 4.15 4.15 0 0 1 .884-2.134l.311-.388-.445-.22a4.85 4.85 0 0 0-3.834-.211l-.485.177.294.425q.203.293.357.616l.001.002.188.388v.002a.75.75 0 0 1-.092.805.656.656 0 0 1-.954.078.7.7 0 0 1-.166-.218l-.184-.396a3.02 3.02 0 0 0-1.334-1.434 2.9 2.9 0 0 0-1.92-.284h-.002A7.1 7.1 0 0 0 7.11 6.66a7.43 7.43 0 0 0-2.058 3.21zm21.38 6.333-.22.25.206.262.375.478.013.017.015.015c.382.392.66.88.807 1.42.146.539.155 1.108.025 1.652a3.26 3.26 0 0 1-.763 1.446 3.1 3.1 0 0 1-1.336.86l-3.104.802-.3.078v1.13c0 .665-.255 1.3-.706 1.768a2.35 2.35 0 0 1-1.69.725h-.005c-.454.005-.9-.126-1.285-.38a2.4 2.4 0 0 1-.882-1.05c-.775-1.796-2.034-2.538-3.47-3.386q-.322-.189-.654-.39l-.152-.093-.17.05-2.002.597h-.001c-.43.125-.876.184-1.323.178h-.01a4.4 4.4 0 0 1-2.339-.657l-.006-.004a4.53 4.53 0 0 1-1.88-2.193l-.101-.246-.266-.003a4.2 4.2 0 0 1-1.99-.532 4.36 4.36 0 0 1-1.529-1.434l-.002-.003-.316-.476a5.7 5.7 0 0 1-.835-2.16 5.8 5.8 0 0 1 .09-2.33 5.65 5.65 0 0 1 1.002-2.084 5.4 5.4 0 0 1 1.732-1.476l.131-.07.053-.14a8.9 8.9 0 0 1 2.499-3.566 8.44 8.44 0 0 1 3.836-1.881 4.3 4.3 0 0 1 2.636.355l.192.092.184-.108a6.2 6.2 0 0 1 3.363-.86 6.24 6.24 0 0 1 3.302 1.084l.431.298.094.064.114.006a6.54 6.54 0 0 1 3.704 1.388 6.9 6.9 0 0 1 2.309 3.318l.028.088.064.067.145.149a4.76 4.76 0 0 1 1.33 3.29 5.38 5.38 0 0 1-1.342 3.595",
                  clipRule: "evenodd",
                })),
              C ||
                (C = q.createElement("path", {
                  fill: "#fff",
                  d: "m36.63 24 2.182-13.09h2.447l-.358 2.13h.161a4.37 4.37 0 0 1 1.62-1.688q1.031-.613 2.335-.613 1.296 0 2.088.613.802.614 1.048 1.688h.137a4.56 4.56 0 0 1 1.764-1.68q1.134-.621 2.548-.621 1.764 0 2.71 1.125.955 1.116.58 3.358L54.426 24H51.87l1.432-8.54q.213-1.338-.409-1.926-.622-.597-1.628-.597-1.245 0-2.062.768-.819.758-1.006 1.951L46.79 24h-2.532l1.458-8.702q.17-1.074-.392-1.713-.555-.648-1.62-.648-.723 0-1.406.384a3.6 3.6 0 0 0-1.15 1.057 3.7 3.7 0 0 0-.622 1.551L39.179 24zm21.544 4.91q-.58 0-1.031-.095a3 3 0 0 1-.674-.187l.972-2.088q.674.187 1.202.145.537-.043 1.005-.444.47-.4.955-1.26l.477-.862-2.565-13.21h2.625l1.62 10.185h.136l5.011-10.185h2.838l-7.85 14.821q-.554 1.057-1.26 1.756a4.7 4.7 0 0 1-1.569 1.065 4.9 4.9 0 0 1-1.892.358M77.641 5.09V24h-3.998V5.09zm10.427 12.336h3.397l1.709 2.198 1.68 1.957 3.167 3.97h-3.73l-2.18-2.677-1.117-1.588zm10.239-2.88q0 3.093-1.173 5.262-1.163 2.17-3.176 3.315-2.003 1.136-4.505 1.136-2.52 0-4.525-1.145-2.002-1.146-3.166-3.315t-1.164-5.253q0-3.094 1.163-5.263t3.167-3.306q2.004-1.145 4.525-1.145 2.502 0 4.505 1.145 2.013 1.136 3.176 3.306 1.173 2.169 1.173 5.263m-4.053 0q0-2.004-.6-3.38-.59-1.376-1.672-2.086-1.08-.711-2.53-.711t-2.53.71-1.68 2.087q-.59 1.376-.59 3.38t.59 3.379q.6 1.375 1.68 2.086t2.53.711 2.53-.71q1.08-.712 1.672-2.087.6-1.376.6-3.38",
                })),
            ),
        ],
        229742,
      ),
      e.s([], 83029),
      e.s(
        [
          "IconLogoDark",
          0,
          (e) =>
            q.createElement(
              "svg",
              S({ xmlns: "http://www.w3.org/2000/svg", width: 108, height: 31, fill: "none" }, e),
              j ||
                (j = q.createElement("path", {
                  fill: "#2C3345",
                  fillRule: "evenodd",
                  d: "m14.29 23.288-.082-.048zm-8.865-12.77-.373-.148a.7.7 0 0 1-.338.41l-.286.148a4.04 4.04 0 0 0-1.62 1.517 4.25 4.25 0 0 0 .068 4.469l.301.476.002.003a3 3 0 0 0 1.707 1.263 2.9 2.9 0 0 0 2.098-.214l.004-.002a.65.65 0 0 1 .513-.041c.17.057.314.183.399.355.084.173.1.374.041.559a.7.7 0 0 1-.344.418l-.376.197.22.364a3.3 3.3 0 0 0 1.082 1.101l.01.007a3.2 3.2 0 0 0 2.471.323l.008-.002 6.186-1.85h.001a.65.65 0 0 1 .51.058.7.7 0 0 1 .33.426.77.77 0 0 1-.063.555.7.7 0 0 1-.405.344l-1.54.461-.702.21.557.477c.358.306.688.564.991.802.957.749 1.659 1.297 2.19 2.528l.003.009.005.008a1 1 0 0 0 .929.568 1.02 1.02 0 0 0 .729-.315 1.06 1.06 0 0 0 .298-.742v-1.698a.76.76 0 0 1 .151-.45.7.7 0 0 1 .372-.254h.002l3.928-1.012c.398-.093.749-.326.993-.656s.367-.734.35-1.145a1.8 1.8 0 0 0-.5-1.237l-.005-.004-.634-.641-.207-.21-.261.136-.255.132a.66.66 0 0 1-.664-.026.732.732 0 0 1-.163-1.078.7.7 0 0 1 .208-.167h.001l.433-.224.008-.005.008-.004a3.83 3.83 0 0 0 1.412-1.427 4 4 0 0 0 .519-1.962c0-.42-.08-.835-.235-1.223a3.2 3.2 0 0 0-.67-1.04h-.001l-.328-.339-.002-.002a.8.8 0 0 1-.17-.282l-.07-.22a5.5 5.5 0 0 0-1.784-2.606 5.24 5.24 0 0 0-2.893-1.146l-.14-.01-.115.078a2.62 2.62 0 0 0-1.054 1.499 2.7 2.7 0 0 0 .168 1.837l.003.006a.73.73 0 0 1-.092.792.7.7 0 0 1-.204.165.66.66 0 0 1-.664-.025.7.7 0 0 1-.254-.285 4.2 4.2 0 0 1-.384-2.288 4.15 4.15 0 0 1 .884-2.134l.311-.388-.445-.221a4.85 4.85 0 0 0-3.834-.211l-.485.178.294.425q.203.292.357.616l.001.002.188.387v.003a.75.75 0 0 1-.092.805.656.656 0 0 1-.954.078.7.7 0 0 1-.166-.218l-.184-.396a3.02 3.02 0 0 0-1.334-1.434 2.9 2.9 0 0 0-1.92-.284h-.002A7.1 7.1 0 0 0 7.11 7.16a7.43 7.43 0 0 0-2.058 3.21zm21.38 6.333-.22.25.206.262.375.478.013.017.015.015c.382.392.66.88.807 1.42.146.539.155 1.108.025 1.652a3.26 3.26 0 0 1-.763 1.446 3.1 3.1 0 0 1-1.336.86l-3.104.802-.3.078v1.13c0 .665-.255 1.3-.706 1.768a2.35 2.35 0 0 1-1.69.725h-.005c-.454.005-.9-.126-1.285-.38a2.4 2.4 0 0 1-.882-1.05c-.775-1.796-2.034-2.538-3.47-3.386q-.322-.189-.654-.39l-.152-.093-.17.05-2.002.597h-.001c-.43.125-.876.184-1.323.178h-.01a4.4 4.4 0 0 1-2.339-.657l-.006-.004a4.53 4.53 0 0 1-1.88-2.193l-.101-.246-.266-.003a4.2 4.2 0 0 1-1.99-.532 4.36 4.36 0 0 1-1.529-1.434l-.002-.003-.316-.476a5.7 5.7 0 0 1-.835-2.16 5.8 5.8 0 0 1 .09-2.33 5.65 5.65 0 0 1 1.002-2.084 5.4 5.4 0 0 1 1.732-1.476l.131-.07.053-.14a8.9 8.9 0 0 1 2.499-3.566 8.44 8.44 0 0 1 3.836-1.882 4.3 4.3 0 0 1 2.636.356l.192.092.184-.108a6.2 6.2 0 0 1 3.363-.86 6.24 6.24 0 0 1 3.302 1.084l.431.298.094.064.114.006a6.54 6.54 0 0 1 3.704 1.388 6.9 6.9 0 0 1 2.309 3.318l.028.088.064.067.145.149a4.76 4.76 0 0 1 1.33 3.289 5.38 5.38 0 0 1-1.342 3.596",
                  clipRule: "evenodd",
                })),
              E ||
                (E = q.createElement("path", {
                  fill: "#2C3345",
                  d: "m36.63 24.5 2.182-13.09h2.447l-.358 2.13h.161a4.37 4.37 0 0 1 1.62-1.688q1.031-.613 2.335-.613 1.296 0 2.088.613.802.614 1.048 1.688h.137a4.56 4.56 0 0 1 1.764-1.68q1.134-.621 2.548-.621 1.764 0 2.71 1.125.955 1.116.58 3.358L54.426 24.5H51.87l1.432-8.54q.213-1.338-.409-1.926-.622-.597-1.628-.597-1.245 0-2.062.768-.819.758-1.006 1.951L46.79 24.5h-2.532l1.458-8.702q.17-1.074-.392-1.713-.555-.648-1.62-.648-.723 0-1.406.384a3.6 3.6 0 0 0-1.15 1.057 3.7 3.7 0 0 0-.622 1.551L39.179 24.5zm21.544 4.91q-.58 0-1.031-.095a3 3 0 0 1-.674-.187l.972-2.088q.674.187 1.202.145.537-.043 1.005-.444.47-.4.955-1.26l.477-.862-2.565-13.21h2.625l1.62 10.185h.136l5.011-10.185h2.838l-7.85 14.821q-.554 1.057-1.26 1.756a4.7 4.7 0 0 1-1.569 1.065 4.9 4.9 0 0 1-1.892.358M77.641 5.59V24.5h-3.998V5.59zm10.427 12.336h3.397l1.709 2.198 1.68 1.957 3.167 3.97h-3.73l-2.18-2.677-1.117-1.588zm10.239-2.88q0 3.093-1.173 5.262-1.163 2.17-3.176 3.315-2.003 1.136-4.505 1.136-2.52 0-4.525-1.145-2.002-1.146-3.166-3.315t-1.164-5.253q0-3.094 1.163-5.263t3.167-3.306q2.004-1.145 4.525-1.145 2.502 0 4.505 1.145 2.013 1.136 3.176 3.306 1.173 2.169 1.173 5.263m-4.053 0q0-2.004-.6-3.38-.59-1.376-1.672-2.086-1.08-.711-2.53-.711t-2.53.71-1.68 2.087q-.59 1.376-.59 3.38t.59 3.379q.6 1.375 1.68 2.086t2.53.711 2.53-.71q1.08-.712 1.672-2.087.6-1.376.6-3.38",
                })),
            ),
        ],
        40959,
      ));
  },
  273998,
  38256,
  523615,
  105278,
  (e) => {
    "use strict";
    var t,
      i,
      a,
      r,
      n = e.i(271645);
    function s() {
      return (s = Object.assign.bind()).apply(null, arguments);
    }
    function l() {
      return (l = Object.assign.bind()).apply(null, arguments);
    }
    function o() {
      return (o = Object.assign.bind()).apply(null, arguments);
    }
    (e.s([], 273998),
      e.s(
        [
          "FacebookIcon",
          0,
          (e) =>
            n.createElement(
              "svg",
              s({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 28 29" }, e),
              t ||
                (t = n.createElement("path", {
                  fill: "currentColor",
                  d: "M14 .67c-7.732 0-14 6.268-14 14 0 6.566 4.52 12.075 10.618 13.588v-9.31H7.731V14.67h2.887v-1.843c0-4.765 2.156-6.974 6.835-6.974.887 0 2.417.174 3.043.348v3.878c-.33-.035-.904-.052-1.617-.052-2.296 0-3.183.87-3.183 3.13v1.513h4.573l-.786 4.278h-3.787v9.619C22.628 27.73 28 21.827 28 14.67c0-7.732-6.268-14-14-14",
                })),
            ),
        ],
        38256,
      ),
      e.s(
        [
          "InstagramIcon",
          0,
          (e) =>
            n.createElement(
              "svg",
              l({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 28 29" }, e),
              i ||
                (i = n.createElement("path", {
                  fill: "currentColor",
                  d: "M8.202.768c-1.49.07-2.507.308-3.396.657-.92.359-1.7.84-2.477 1.619a6.9 6.9 0 0 0-1.61 2.48c-.345.892-.578 1.91-.644 3.4s-.08 1.97-.073 5.772c.007 3.8.024 4.278.096 5.772.07 1.489.308 2.506.657 3.396.359.92.84 1.7 1.619 2.477a6.9 6.9 0 0 0 2.483 1.61c.89.344 1.909.579 3.399.644s1.97.08 5.77.073c3.802-.007 4.28-.024 5.774-.095s2.505-.31 3.395-.657c.92-.36 1.7-.84 2.477-1.62a6.85 6.85 0 0 0 1.609-2.483c.345-.89.579-1.91.644-3.398.065-1.494.08-1.971.073-5.773s-.024-4.278-.095-5.771-.308-2.507-.657-3.397a6.9 6.9 0 0 0-1.62-2.477 6.8 6.8 0 0 0-2.482-1.61c-.891-.344-1.91-.58-3.4-.643S17.775.663 13.974.67 9.695.694 8.202.766m.164 25.309c-1.365-.06-2.106-.286-2.6-.476a4.4 4.4 0 0 1-1.612-1.044 4.3 4.3 0 0 1-1.05-1.608c-.192-.494-.423-1.234-.487-2.6-.07-1.474-.084-1.917-.092-5.655s.006-4.18.07-5.656c.059-1.364.287-2.106.477-2.6a4.34 4.34 0 0 1 1.044-1.612 4.3 4.3 0 0 1 1.608-1.05c.493-.193 1.234-.422 2.598-.487 1.476-.07 1.919-.084 5.656-.092s4.18.006 5.658.07c1.364.06 2.106.286 2.599.477.654.252 1.12.555 1.612 1.044s.795.954 1.05 1.609c.194.492.423 1.232.487 2.597.07 1.476.086 1.919.093 5.656s-.006 4.18-.071 5.656c-.06 1.365-.286 2.106-.476 2.6a4.34 4.34 0 0 1-1.045 1.613 4.3 4.3 0 0 1-1.608 1.05c-.493.192-1.234.422-2.597.487-1.476.069-1.92.084-5.657.092s-4.181-.007-5.657-.071M19.779 7.187a1.68 1.68 0 1 0 3.36-.006 1.68 1.68 0 0 0-3.36.006M6.812 14.683a7.19 7.19 0 0 0 14.378-.028 7.19 7.19 0 0 0-14.378.028m2.523-.005a4.667 4.667 0 1 1 9.334-.022 4.667 4.667 0 0 1-9.334.024",
                })),
            ),
        ],
        523615,
      ),
      e.s(
        [
          "RedditIcon",
          0,
          (e) =>
            n.createElement(
              "svg",
              o(
                {
                  xmlns: "http://www.w3.org/2000/svg",
                  fill: "currentColor",
                  className: "RedditIcon_svg__bi RedditIcon_svg__bi-reddit",
                  viewBox: "0 0 16 16",
                },
                e,
              ),
              a ||
                (a = n.createElement("path", {
                  d: "M6.167 8a.83.83 0 0 0-.83.83c0 .459.372.84.83.831a.831.831 0 0 0 0-1.661m1.843 3.647c.315 0 1.403-.038 1.976-.611a.23.23 0 0 0 0-.306.213.213 0 0 0-.306 0c-.353.363-1.126.487-1.67.487-.545 0-1.308-.124-1.671-.487a.213.213 0 0 0-.306 0 .213.213 0 0 0 0 .306c.564.563 1.652.61 1.977.61zm.992-2.807c0 .458.373.83.831.83s.83-.381.83-.83a.831.831 0 0 0-1.66 0z",
                })),
              r ||
                (r = n.createElement("path", {
                  d: "M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.828-1.165c-.315 0-.602.124-.812.325-.801-.573-1.9-.945-3.121-.993l.534-2.501 1.738.372a.83.83 0 1 0 .83-.869.83.83 0 0 0-.744.468l-1.938-.41a.2.2 0 0 0-.153.028.2.2 0 0 0-.086.134l-.592 2.788c-1.24.038-2.358.41-3.17.992-.21-.2-.496-.324-.81-.324a1.163 1.163 0 0 0-.478 2.224q-.03.17-.029.353c0 1.795 2.091 3.256 4.669 3.256s4.668-1.451 4.668-3.256c0-.114-.01-.238-.029-.353.401-.181.688-.592.688-1.069 0-.65-.525-1.165-1.165-1.165",
                })),
            ),
        ],
        105278,
      ));
  },
  441449,
  (e) => {
    e.q("/_next/static/media/figure-abraham-lincoln-123.3aqb5ngb5wg3d.webp");
  },
  286642,
  (e) => {
    e.q("/_next/static/media/figure-george-washington-113.1ttq84d3nfwf2.webp");
  },
  688356,
  (e) => {
    e.q("/_next/static/media/figure-napoleon-bonaparte-118.1ud1iddxe0wem.webp");
  },
  239072,
  (e) => {
    e.q("/_next/static/media/abraham-lincoln-123.2y-7u8-gw0tex.webp");
  },
  768329,
  11059,
  714029,
  (e) => {
    "use strict";
    let t = {
      src: e.i(239072).default,
      width: 868,
      height: 1e3,
      blurWidth: 7,
      blurHeight: 8,
      blurDataURL:
        "data:image/webp;base64,UklGRhoBAABXRUJQVlA4TA0BAAAvBsABEM1VICICHghADgIAAID7b2VBERKQBQlkEAAAAAAAAAAEAAAAAAAAAAAAMADAAEAAIQOjebYBAAAPRAIAAAAA4PwbAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOyBSAAAAAAAnH8DAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgD0QgBQGAACA87+PsdSISQQgBqwBAAAwiAAgMAAAAMCgAQAAMAAAACAAAAIAADLAzEpAABo7bvtSfhpAuUg3t/kAUAc+lZFrACgE81T3T6A3CABAC/HgOmveyCsnw1ummYPmHihOdewK27PK/Atyogtas9CbydIGO7Ch+G/aDwA=",
    };
    e.s(["ImgAbrahamLincoln123", 0, t], 768329);
    let i = {
      src: e.i(131586).default,
      width: 868,
      height: 1e3,
      blurWidth: 7,
      blurHeight: 8,
      blurDataURL:
        "data:image/webp;base64,UklGRh4BAABXRUJQVlA4TBEBAAAvBsABEM1VICICHghADgIAAIBbfq3GECKAAAAAAwiAAAAAABAAAAAAAAAAAAAAAARgsI0ZAApFzPsAAAAPZBMAAAAA4PwXAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHQPRAIAAAAA4PwbAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOyBgOAgAAAAnP/9gmGRaQBKBAsYRlACAAIAAAoABAAAkAEAIAAAAAAQAJAAAAAaIAkE4DCeKfAWHsC/sR5cO6fFAqRD9dNGyugaaIAw//nvTE6yHAeQEb+uo7VR3c2TDKOimLwtLHXELKU9296JihQTUsVl3kArDAxMf8NjvtD0aRoA",
    };
    e.s(["ImgGeorgeWashington113", 0, i], 11059);
    let a = {
      src: e.i(395007).default,
      width: 868,
      height: 1e3,
      blurWidth: 7,
      blurHeight: 8,
      blurDataURL:
        "data:image/webp;base64,UklGRhwBAABXRUJQVlA4TBABAAAvBsABEM1VICICHghADgIAAID7Z/Yli5bMkDAAAAADMhAAAAAAAAAAAAAAAAAAAABAAAAAFEQoDbYAAAAPZBMAAAAA4Pz3AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAPRAIAAAAA4PwbAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOyBoOUgAAAAnP/7BxwqIFUQEEAjGDAgAQAUABYAAAAAAAAAJAAAAAAIAABAAIgAlECAhs4w39wvD6AS8uQtVyATAtTC3+VL+EwB+HXcMexIkkYCYYxFjnXtbeFqSnNaosZ9r4qSw4cK41SbUEHt0VzhDI/eZZaeHlXnA5/hY218DQ==",
    };
    e.s(["ImgNapoleonBonaparte118", 0, a], 714029);
  },
  131586,
  (e) => {
    e.q("/_next/static/media/george-washington-113.1ls1f78tt15i-.webp");
  },
  395007,
  (e) => {
    e.q("/_next/static/media/napoleon-bonaparte-118.2nkw9l9gq-j18.webp");
  },
  532262,
  (e) => {
    "use strict";
    var t = e.i(797982);
    e.s(["LangComponent", () => t.default]);
  },
  340609,
  90147,
  (e) => {
    "use strict";
    var t = e.i(23877);
    (e.s([], 340609), e.s(["Spinner", () => t.default], 90147));
  },
  23877,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(112041);
    e.s(["default", 0, (e) => (0, t.jsx)(i.Spinner, { ...e })]);
  },
]);
