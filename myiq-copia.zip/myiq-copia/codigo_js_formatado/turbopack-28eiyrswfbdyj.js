((globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  {
    otherChunks: [
      "static/chunks/0yassmujnu4nx.js",
      "static/chunks/2-urkx3cuhmdn.js",
      "static/chunks/3o_-_q1zmsv9a.js",
      "static/chunks/0f7g7kv52nzpl.js",
      "static/chunks/2d5lvc0d6o_u7.js",
    ],
    runtimeModuleIds: [494553],
  },
]),
  (() => {
    let e;
    if (!Array.isArray(globalThis.TURBOPACK)) return;
    var t,
      r = "/_next/",
      n = (function () {
        if (null != self.TURBOPACK_ASSET_SUFFIX) return self.TURBOPACK_ASSET_SUFFIX;
        let e = document?.currentScript?.getAttribute?.("src") ?? "",
          t = e.indexOf("?");
        return t >= 0 ? e.slice(t) : "";
      })(),
      o =
        (((t = o || {})[(t.Runtime = 0)] = "Runtime"),
        (t[(t.Parent = 1)] = "Parent"),
        (t[(t.Update = 2)] = "Update"),
        t);
    let l = new WeakMap();
    function i(e, t) {
      ((this.m = e), (this.e = t));
    }
    let u = i.prototype,
      s = Object.prototype.hasOwnProperty,
      c = "u" > typeof Symbol && Symbol.toStringTag;
    function a(e, t, r) {
      s.call(e, t) || Object.defineProperty(e, t, r);
    }
    function f(e, t) {
      let r = e[t];
      return (r || ((r = p(t)), (e[t] = r)), r);
    }
    function p(e) {
      return { exports: {}, error: void 0, id: e, namespaceObject: void 0 };
    }
    function h(e, t, r) {
      (a(e, "__esModule", { value: !0 }), c && a(e, c, { value: "Module" }));
      let n = 0;
      for (; n < t.length;) {
        let r = t[n++],
          o = t[n++];
        if ("number" == typeof o)
          if (0 === o) a(e, r, { value: t[n++], enumerable: !0, writable: !1 });
          else throw Error(`unexpected tag: ${o}`);
        else
          "function" == typeof t[n]
            ? a(e, r, { get: o, set: t[n++], enumerable: !0 })
            : a(e, r, { get: o, enumerable: !0 });
      }
      r || Object.seal(e);
    }
    function d(e, t) {
      (null != t ? f(this.c, t) : this.m).exports = e;
    }
    ((u.s = function (e, t, r) {
      let n, o;
      (null != t ? (o = (n = f(this.c, t)).exports) : ((n = this.m), (o = this.e)),
        (n.namespaceObject = o),
        h(o, e, r));
    }),
      (u.j = function (e, t) {
        let r, n;
        null != t ? (n = (r = f(this.c, t)).exports) : ((r = this.m), (n = this.e));
        let o = (function (e, t) {
          let r = l.get(e);
          if (!r) {
            l.set(e, (r = []));
            let n = (e) => {
              if ("default" !== e) {
                for (let t of r) if (s.call(t, e)) return t;
              }
            };
            e.exports = e.namespaceObject = new Proxy(t, {
              get(e, t) {
                if (s.call(e, t) || "default" === t || "__esModule" === t) return Reflect.get(e, t);
                let r = n(t);
                return r && Reflect.get(r, t);
              },
              set: () => !1,
              defineProperty: () => !1,
              deleteProperty: () => !1,
              has: (e, t) =>
                !!Reflect.has(e, t) || ("default" !== t && "__esModule" !== t && void 0 !== n(t)),
              ownKeys(e) {
                let t = Reflect.ownKeys(e);
                for (let e of r)
                  for (let r of Reflect.ownKeys(e)) "default" === r || t.includes(r) || t.push(r);
                return t;
              },
              getOwnPropertyDescriptor(e, t) {
                let r = Reflect.getOwnPropertyDescriptor(e, t);
                if (r || "default" === t || "__esModule" === t) return r;
                let o = n(t);
                if (o) return { enumerable: !0, configurable: !0, get: () => Reflect.get(o, t) };
              },
            });
          }
          return r;
        })(r, n);
        "object" == typeof e && null !== e && o.push(e);
      }),
      (u.v = d),
      (u.n = function (e, t) {
        let r;
        (r = null != t ? f(this.c, t) : this.m).exports = r.namespaceObject = e;
      }));
    let m = Object.getPrototypeOf ? (e) => Object.getPrototypeOf(e) : (e) => e.__proto__,
      y = [null, m({}), m([]), m(m)];
    function g(e, t, r) {
      let n = [],
        o = -1;
      for (let t = e; ("object" == typeof t || "function" == typeof t) && !y.includes(t); t = m(t))
        for (let r of Object.getOwnPropertyNames(t))
          (n.push(
            r,
            (function (e, t) {
              return () => e[t];
            })(e, r),
          ),
            -1 === o && "default" === r && (o = n.length - 1));
      return ((r && o >= 0) || (o >= 0 ? n.splice(o, 1, 0, e) : n.push("default", 0, e)), h(t, n), t);
    }
    function b(e) {
      let t = K(e, this.m);
      if (t.namespaceObject) return t.namespaceObject;
      let r = t.exports;
      return (t.namespaceObject = g(
        r,
        "function" == typeof r
          ? function () {
              for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
              return r.apply(this, t);
            }
          : Object.create(null),
        r && r.__esModule,
      ));
    }
    function O(e) {
      let t = e.indexOf("#");
      -1 !== t && (e = e.substring(0, t));
      let r = e.indexOf("?");
      return (-1 !== r && (e = e.substring(0, r)), e);
    }
    ((u.i = b),
      (u.A = function (e) {
        return this.r(e)(b.bind(this));
      }),
      (u.t =
        "function" == typeof require
          ? require
          : function () {
              throw Error("Unexpected use of runtime require");
            }),
      (u.r = function (e) {
        return K(e, this.m).exports;
      }),
      (u.f = function (e) {
        function t(t) {
          if (((t = O(t)), s.call(e, t))) return e[t].module();
          let r = Error(`Cannot find module '${t}'`);
          throw ((r.code = "MODULE_NOT_FOUND"), r);
        }
        return (
          (t.keys = () => Object.keys(e)),
          (t.resolve = (t) => {
            if (((t = O(t)), s.call(e, t))) return e[t].id();
            let r = Error(`Cannot find module '${t}'`);
            throw ((r.code = "MODULE_NOT_FOUND"), r);
          }),
          (t.import = async (e) => await t(e)),
          t
        );
      }));
    let w = function (e) {
      let t = new URL(e, "x:/"),
        r = {};
      for (let e in t) r[e] = t[e];
      for (let t in ((r.href = e),
      (r.pathname = e.replace(/[?#].*/, "")),
      (r.origin = r.protocol = ""),
      (r.toString = r.toJSON =
        function () {
          for (var t = arguments.length, r = Array(t), n = 0; n < t; n++) r[n] = arguments[n];
          return e;
        }),
      r))
        Object.defineProperty(this, t, { enumerable: !0, configurable: !0, value: r[t] });
    };
    function k(e, t) {
      throw Error(`Invariant: ${t(e)}`);
    }
    ((w.prototype = URL.prototype),
      (u.U = w),
      (u.z = function (e) {
        throw Error("dynamic usage of require is not supported");
      }),
      (u.g = globalThis));
    let v = i.prototype,
      R = new Map();
    u.M = R;
    let U = new Map(),
      j = new Map(),
      _ = new Map();
    async function $(e, t, r) {
      let n;
      if ("string" == typeof r)
        return (function (e, t, r) {
          return A(e, t, r);
        })(e, t, E(r));
      let o = r.included || [],
        l = o.map((e) => !!R.has(e) || U.get(e));
      if (l.length > 0 && l.every((e) => e)) return void (await Promise.all(l));
      for (let l of ((n = A(e, t, E(r.path))), o)) U.has(l) || U.set(l, n);
      await n;
    }
    v.l = function (e) {
      return $(o.Parent, this.m.id, e);
    };
    let P = Promise.resolve(void 0),
      C = new WeakMap();
    function A(t, r, n) {
      let l = e.loadChunkCached(t, n),
        i = C.get(l);
      if (void 0 === i) {
        let e = C.set.bind(C, l, P);
        ((i = l.then(e).catch((e) => {
          let l;
          switch (t) {
            case o.Runtime:
              l = `as a runtime dependency of chunk ${r}`;
              break;
            case o.Parent:
              l = `from module ${r}`;
              break;
            case o.Update:
              l = "from an HMR update";
              break;
            default:
              k(t, (e) => `Unknown source type: ${e}`);
          }
          let i = Error(`Failed to load chunk ${n} ${l}${e ? `: ${e}` : ""}`, e ? { cause: e } : void 0);
          throw ((i.name = "ChunkLoadError"), i);
        })),
          C.set(l, i));
      }
      return i;
    }
    v.L = function (e) {
      var t, r;
      return ((t = o.Parent), (r = this.m.id), A(t, r, e));
    };
    ((v.R = function (e) {
      let t = this.r(e);
      return t?.default ?? t;
    }),
      (v.P = function (e) {
        return `/ROOT/${e ?? ""}`;
      }),
      (v.F = function (e) {
        return e ? `file:///ROOT/${e.split("/").map(encodeURIComponent).join("/")}` : "file:///ROOT/";
      }),
      (v.q = function (e, t) {
        d.call(this, `${e}${n}`, t);
      }));
    let T = /[^A-Za-z0-9\-_.!~*'()/]/;
    function E(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : r,
        o = T.test(e) ? e.split("/").map(encodeURIComponent).join("/") : e;
      return `${t}${o}${n}`;
    }
    function x(e, t) {
      let r,
        n = e.indexOf("?");
      if (-1 !== n) r = n;
      else {
        let t = e.indexOf("#");
        r = -1 !== t ? t : e.length;
      }
      return r >= t.length && e.startsWith(t, r - t.length);
    }
    ((v.b = r), (v.X = n), (v.h = E));
    function M(e) {
      return x(e, ".css");
    }
    let S = {};
    u.c = S;
    let K = (e, t) => {
      let r = S[e];
      if (r) {
        if (r.error) throw r.error;
        return r;
      }
      return N(e, o.Parent, t.id);
    };
    function N(e, t, r) {
      let n = R.get(e);
      if ("function" != typeof n)
        throw Error(
          (function (e, t, r) {
            let n;
            switch (t) {
              case 0:
                n = `as a runtime entry of chunk ${r}`;
                break;
              case 1:
                n = `because it was required from module ${r}`;
                break;
              case 2:
                n = "because of an HMR update";
                break;
              default:
                k(t, (e) => `Unknown source type: ${e}`);
            }
            return `Module ${e} was instantiated ${n}, but the module factory is not available.`;
          })(e, t, r),
        );
      let o = p(e),
        l = o.exports;
      S[e] = o;
      let u = new i(o, l);
      try {
        n(u, o, l);
      } catch (e) {
        throw ((o.error = e), e);
      }
      return (o.namespaceObject && o.exports !== o.namespaceObject && g(o.exports, o.namespaceObject), o);
    }
    function L(t) {
      let r;
      if (!Array.isArray(t)) return e.registerChunk(void 0, t);
      let n = (function (e) {
        if ("string" == typeof e) return e;
        if (e) return { src: e.getAttribute("src") };
        if ("u" > typeof TURBOPACK_NEXT_CHUNK_URLS) return { src: TURBOPACK_NEXT_CHUNK_URLS.pop() };
        throw Error("chunk path empty but not in a worker");
      })(t[0]);
      return (
        2 === t.length
          ? (r = t[1])
          : ((r = void 0),
            !(function (e, t) {
              let r = 1;
              for (; r < e.length;) {
                let n,
                  o = r + 1;
                for (; o < e.length && "function" != typeof e[o];) o++;
                if (o === e.length) throw Error("malformed chunk format, expected a factory function");
                let l = e[o];
                for (let l = r; l < o; l++) {
                  let r = e[l],
                    o = t.get(r);
                  if (o) {
                    n = o;
                    break;
                  }
                }
                let i = n ?? l,
                  u = !1;
                for (let n = r; n < o; n++) {
                  let r = e[n];
                  t.has(r) ||
                    (u ||
                      (i === l && Object.defineProperty(l, "name", { value: "module evaluation" }), (u = !0)),
                    t.set(r, i));
                }
                r = o + 1;
              }
            })(t, R)),
        e.registerChunk(n, r)
      );
    }
    let B = new Map();
    function I(e) {
      let t = B.get(e);
      if (!t) {
        let r, n;
        ((t = {
          resolved: !1,
          loadingStarted: !1,
          retryAttempts: 0,
          promise: new Promise((e, t) => {
            ((r = e), (n = t));
          }),
          resolve: () => {
            ((t.resolved = !0), r());
          },
          reject: n,
        }),
          B.set(e, t));
      }
      return t;
    }
    function q(e, t, r, n, o) {
      !(null == n || (n instanceof DOMException && "NetworkError" === n.name)) ||
      r.retryAttempts >= 1 ||
      B.get(t) !== r
        ? (B.get(t) === r && B.delete(t), r.reject(n))
        : (r.retryAttempts++,
          setTimeout(
            () => {
              r.resolved || B.get(t) !== r || (o ? o() : ((r.loadingStarted = !1), F(e, t)));
            },
            200 + Math.floor(401 * Math.random()),
          ));
    }
    function F(e, t) {
      let r = I(t);
      if (r.loadingStarted) return r.promise;
      if (e === o.Runtime) return ((r.loadingStarted = !0), M(t) && r.resolve(), r.promise);
      if ("function" == typeof importScripts)
        if (M(t));
        else if (x(t, ".js")) {
          self.TURBOPACK_NEXT_CHUNK_URLS.push(t);
          try {
            importScripts(t);
          } catch (n) {
            q(e, t, r, n);
          }
        } else throw Error(`can't infer type of chunk from URL ${t} in worker`);
      else {
        let n = decodeURI(t);
        if (M(t))
          if (
            document.querySelectorAll(
              `link[rel=stylesheet][href="${t}"],link[rel=stylesheet][href^="${t}?"],link[rel=stylesheet][href="${n}"],link[rel=stylesheet][href^="${n}?"]`,
            ).length > 0
          )
            r.resolve();
          else {
            let n = () => {
              let o = document.createElement("link");
              return (
                (o.rel = "stylesheet"),
                (o.crossOrigin = null),
                (o.href = t),
                (o.onerror = () => {
                  let l = document.createComment("");
                  (o.replaceWith(l), q(e, t, r, void 0, () => l.replaceWith(n())));
                }),
                (o.onload = () => {
                  r.resolve();
                }),
                o
              );
            };
            document.head.appendChild(n());
          }
        else if (x(t, ".js")) {
          let o = document.querySelectorAll(
            `script[src="${t}"],script[src^="${t}?"],script[src="${n}"],script[src^="${n}?"]`,
          );
          if (o.length > 0)
            for (let n of Array.from(o))
              n.addEventListener(
                "error",
                () => {
                  (n.remove(), q(e, t, r));
                },
                { once: !0 },
              );
          else {
            let n = document.createElement("script");
            ((n.crossOrigin = null),
              (n.src = t),
              (n.onerror = () => {
                (n.remove(), q(e, t, r));
              }),
              document.head.appendChild(n));
          }
        } else throw Error(`can't infer type of chunk from URL ${t}`);
      }
      return ((r.loadingStarted = !0), r.promise);
    }
    e = {
      async registerChunk(e, t) {
        let n;
        if (
          (null != e &&
            ((n = (function (e) {
              if ("string" == typeof e) return e;
              let t = decodeURIComponent(e.src.replace(/[?#].*$/, ""));
              return t.startsWith(r) ? t.slice(r.length) : t;
            })(e)),
            I("string" == typeof e ? E(e) : e.src).resolve()),
          null != t)
        ) {
          for (let e of t.otherChunks) I(E("string" == typeof e ? e : e.path));
          if (
            (await Promise.all(
              t.otherChunks.map((e) => {
                var t;
                return ((t = n), $(o.Runtime, t, e));
              }),
            ),
            t.runtimeModuleIds.length > 0)
          )
            for (let e of t.runtimeModuleIds)
              !(function (e, t) {
                let r = S[t];
                if (r) {
                  if (r.error) throw r.error;
                  return;
                }
                N(t, o.Runtime, e);
              })(n, e);
        }
      },
      loadChunkCached: (e, t) => F(e, t),
    };
    var D = globalThis.TURBOPACK;
    ((globalThis.TURBOPACK = { push: L }), D.forEach(L));
  })());
