(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  882983,
  (e) => {
    "use strict";
    var t = e.i(265840),
      r = e.i(271645),
      o = e.i(273830),
      n = e.i(620253),
      a = e.i(75540),
      i = e.i(843476),
      s = (0, o.forwardRef)((e, o) => {
        let { as: s, children: l, className: c, ...d } = e,
          { slots: u, classNames: p, bodyId: m, setBodyMounted: f } = (0, t.useModalContext)(),
          y = (0, n.useDOMRef)(o);
        return (
          (0, r.useEffect)(() => (f(!0), () => f(!1)), [f]),
          (0, i.jsx)(s || "div", {
            ref: y,
            className: u.body({ class: (0, a.clsx)(null == p ? void 0 : p.body, c) }),
            id: m,
            ...d,
            children: l,
          })
        );
      });
    ((s.displayName = "HeroUI.ModalBody"), e.s(["ModalBody", 0, s], 882983));
  },
  641711,
  (e, t, r) => {
    "use strict";
    function o(e) {
      return (o =
        "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
          ? function (e) {
              return typeof e;
            }
          : function (e) {
              return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype
                ? "symbol"
                : typeof e;
            })(e);
    }
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n,
      a = "basil",
      i = "https://js.stripe.com",
      s = "".concat(i, "/").concat(a, "/stripe.js"),
      l = /^https:\/\/js\.stripe\.com\/v3\/?(\?.*)?$/,
      c = /^https:\/\/js\.stripe\.com\/(v3|[a-z]+)\/stripe\.js(\?.*)?$/,
      d =
        "loadStripe.setLoadParameters was called but an existing Stripe.js script already exists in the document; existing script parameters will be used",
      u = function () {
        for (var e = document.querySelectorAll('script[src^="'.concat(i, '"]')), t = 0; t < e.length; t++) {
          var r,
            o = e[t];
          if (((r = o.src), l.test(r) || c.test(r))) return o;
        }
        return null;
      },
      p = function (e) {
        var t = e && !e.advancedFraudSignals ? "?advancedFraudSignals=false" : "",
          r = document.createElement("script");
        r.src = "".concat(s).concat(t);
        var o = document.head || document.body;
        if (!o) throw Error("Expected document.body not to be null. Stripe.js requires a <body> element.");
        return (o.appendChild(r), r);
      },
      m = function (e, t) {
        e && e._registerWrapper && e._registerWrapper({ name: "stripe-js", version: "7.9.0", startTime: t });
      },
      f = null,
      y = null,
      h = null,
      v = function (e, t, r) {
        if (null === e) return null;
        var o,
          n = t[0].match(/^pk_test/),
          i = 3 === (o = e.version) ? "v3" : o;
        n &&
          i !== a &&
          console.warn(
            "Stripe.js@"
              .concat(i, " was loaded on the page, but @stripe/stripe-js@")
              .concat("7.9.0", " expected Stripe.js@")
              .concat(
                a,
                ". This may result in unexpected behavior. For more information, see https://docs.stripe.com/sdks/stripejs-versioning",
              ),
          );
        var s = e.apply(void 0, t);
        return (m(s, r), s);
      },
      S = function (e) {
        var t =
          "invalid load parameters; expected object of shape\n\n    {advancedFraudSignals: boolean}\n\nbut received\n\n    ".concat(
            JSON.stringify(e),
            "\n",
          );
        if (null === e || "object" !== o(e)) throw Error(t);
        if (1 === Object.keys(e).length && "boolean" == typeof e.advancedFraudSignals) return e;
        throw Error(t);
      },
      b = !1,
      g = function () {
        for (var e, t = arguments.length, r = Array(t), o = 0; o < t; o++) r[o] = arguments[o];
        b = !0;
        var a = Date.now();
        return ((e = n),
        null !== f
          ? f
          : (f = new Promise(function (t, r) {
              if ("u" < typeof window || "u" < typeof document) return void t(null);
              if ((window.Stripe && e && console.warn(d), window.Stripe)) return void t(window.Stripe);
              try {
                var o,
                  n = u();
                (n && e
                  ? console.warn(d)
                  : n
                    ? n &&
                      null !== h &&
                      null !== y &&
                      (n.removeEventListener("load", h),
                      n.removeEventListener("error", y),
                      null == (o = n.parentNode) || o.removeChild(n),
                      (n = p(e)))
                    : (n = p(e)),
                  (h = function () {
                    window.Stripe ? t(window.Stripe) : r(Error("Stripe.js not available"));
                  }),
                  (y = function (e) {
                    r(Error("Failed to load Stripe.js", { cause: e }));
                  }),
                  n.addEventListener("load", h),
                  n.addEventListener("error", y));
              } catch (e) {
                r(e);
                return;
              }
            })).catch(function (e) {
              return ((f = null), Promise.reject(e));
            })).then(function (e) {
          return v(e, r, a);
        });
      };
    ((g.setLoadParameters = function (e) {
      if (!(
        b &&
        n &&
        Object.keys(S(e)).reduce(function (t, r) {
          var o;
          return t && e[r] === (null == (o = n) ? void 0 : o[r]);
        }, !0)
      )) {
        if (b) throw Error("You cannot change load parameters after calling loadStripe");
        n = S(e);
      }
    }),
      (r.loadStripe = g));
  },
  709275,
  (e, t, r) => {
    t.exports = e.r(641711);
  },
  905572,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(861745),
      o = e.i(948148),
      n = e.i(271645),
      a = e.i(523173),
      i = e.i(622963);
    e.i(470366);
    var s = e.i(504001);
    e.i(491877);
    var l = e.i(758535);
    e.i(317197);
    var c = e.i(231529);
    (e.s([], 228865),
      e.i(228865),
      e.s(
        [
          "CardUpdaterModalComponent",
          0,
          (e) => {
            let { handleCheckoutSuccess: d, user: u, paymentPlan: p, isPrintedCertificateUpsell: m } = e,
              f = (0, o.useTranslations)(),
              y = (0, r.useLocale)(),
              h = (0, i.useModalStore)((e) => e.handleChangeModalStore);
            (0, n.useEffect)(() => {
              (0, s.trackClientEvents)({ event: a.EAnalyticEvents.PAYMENT_INFO_UPDATER_VIEWED, user: u });
            }, []);
            let v = m ? "Payment Unsuccessful" : f("card_updater_modal_title"),
              S = m
                ? "We couldn't process your payment. Please update your card details to complete your order."
                : f("card_updater_modal_description");
            return (0, t.jsx)(c.ModalBodyComponent, {
              title: v,
              subtitle: S,
              children: (0, t.jsx)(
                l.CheckoutFormComponent,
                {
                  handleCheckoutSuccess: (e) => {
                    (d(e),
                      (0, s.trackClientEvents)({ event: a.EAnalyticEvents.PAYMENT_INFO_UPDATED, user: u }),
                      h({ isModalVisible: !1 }));
                  },
                  locale: y,
                  user: u,
                },
                p,
              ),
            });
          },
        ],
        905572,
      ));
  },
  657997,
  function (e) {
    e.n(e.i(905572));
  },
  317197,
  231529,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(882983),
      o = e.i(742214),
      n = e.i(663615);
    e.i(680460);
    var a = e.i(885944);
    (e.s([], 317197),
      e.s(
        [
          "ModalBodyComponent",
          0,
          (e) => {
            let {
              children: i,
              title: s,
              subtitle: l,
              className: c = "",
              bodyClassName: d,
              titleClassName: u,
            } = e;
            return (0, t.jsx)(o.ModalContent, {
              className: c,
              children: (0, t.jsxs)(r.ModalBody, {
                className: (0, n.cn)(
                  "flex h-full w-full flex-col gap-5 p-5 antialiased md:p-6 [@media(max-height:580px)]:gap-3 [@media(max-height:580px)]:p-4",
                  d,
                ),
                children: [
                  (s || l) &&
                    (0, t.jsx)(a.ModalHeaderComponent, { title: s, subtitle: l, titleClassName: u }),
                  i,
                ],
              }),
            });
          },
        ],
        231529,
      ));
  },
  190899,
  (e) => {
    "use strict";
    e.s([
      "accessSessionStorageUtil",
      0,
      {
        getItem: (e) => {
          try {
            return sessionStorage.getItem(e);
          } catch {
            return null;
          }
        },
        setItem: (e, t) => {
          try {
            sessionStorage.setItem(e, t);
          } catch {
            return;
          }
        },
        removeItem: (e) => {
          try {
            sessionStorage.removeItem(e);
          } catch {
            return;
          }
        },
      },
    ]);
  },
  963075,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/3nf4bje-8x16b.js"].map((t) => e.l(t))).then(() => t(149278)));
  },
  491877,
  758535,
  (e) => {
    "use strict";
    let t = (0, e.i(770703).default)(() => e.A(963075), {
      loadableGenerated: { modules: [149278] },
      ssr: !1,
    });
    (e.s(["CheckoutFormComponent", 0, t], 758535), e.i(56395), e.s([], 491877));
  },
  56395,
  178668,
  (e) => {
    "use strict";
    let t,
      r = "u" > typeof crypto && crypto.randomUUID && crypto.randomUUID.bind(crypto),
      o = new Uint8Array(16),
      n = [];
    for (let e = 0; e < 256; ++e) n.push((e + 256).toString(16).slice(1));
    let a = function (e, a, i) {
      if (r && !a && !e) return r();
      let s =
        (e = e || {}).random ??
        e.rng?.() ??
        (function () {
          if (!t) {
            if ("u" < typeof crypto || !crypto.getRandomValues)
              throw Error(
                "crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported",
              );
            t = crypto.getRandomValues.bind(crypto);
          }
          return t(o);
        })();
      if (s.length < 16) throw Error("Random bytes length must be >= 16");
      if (((s[6] = (15 & s[6]) | 64), (s[8] = (63 & s[8]) | 128), a)) {
        if ((i = i || 0) < 0 || i + 16 > a.length)
          throw RangeError(`UUID byte range ${i}:${i + 15} is out of buffer bounds`);
        for (let e = 0; e < 16; ++e) a[i + e] = s[e];
        return a;
      }
      return (function (e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return (
          n[e[t + 0]] +
          n[e[t + 1]] +
          n[e[t + 2]] +
          n[e[t + 3]] +
          "-" +
          n[e[t + 4]] +
          n[e[t + 5]] +
          "-" +
          n[e[t + 6]] +
          n[e[t + 7]] +
          "-" +
          n[e[t + 8]] +
          n[e[t + 9]] +
          "-" +
          n[e[t + 10]] +
          n[e[t + 11]] +
          n[e[t + 12]] +
          n[e[t + 13]] +
          n[e[t + 14]] +
          n[e[t + 15]]
        ).toLowerCase();
      })(s);
    };
    var i = e.i(709275),
      s = e.i(190899);
    e.i(756503);
    var l = e.i(542516);
    e.i(999126);
    var c = e.i(548248);
    let d = async (e) => {
        try {
          await u();
          let t = [];
          for (let r of e) {
            let e = await (0, i.loadStripe)(r.key),
              o = await e?.createRadarSession();
            o?.radarSession?.id &&
              (t.push({ stripeRadarSessionId: o?.radarSession?.id, name: r.name }),
              s.accessSessionStorageUtil.setItem(r.name, o.radarSession.id));
          }
          let r = Object.assign({}, ...t.map((e) => ({ [e.name]: e.stripeRadarSessionId }))),
            o = p();
          return (
            (0, c.debugUtil)({ text: "createSessionsForClient", value: { ...r, ...o } }),
            { ...r, ...o }
          );
        } catch (t) {
          let e = t?.response?.body?.error?.message || t?.message || "Something went wrong";
          throw ((0, c.debugUtil)({ text: "createSessionsForClient error", value: t }), Error(e));
        }
      },
      u = async () => {
        try {
          return new Promise((e, t) => {
            if (window.Stripe) e();
            else {
              let r = "stripe-js-script",
                o = document.getElementById(r);
              if (o)
                (o.addEventListener("load", () => {
                  window.Stripe ? e() : t(Error("Stripe.js failed to load."));
                }),
                  o.addEventListener("error", () => {
                    t(Error("Stripe.js failed to load."));
                  }));
              else {
                let o = document.createElement("script");
                ((o.id = r),
                  (o.src = "https://js.stripe.com/v3/"),
                  (o.async = !0),
                  (o.onload = () => {
                    window.Stripe ? e() : t(Error("Stripe.js failed to load."));
                  }),
                  (o.onerror = () => t(Error("Stripe.js failed to load."))),
                  document.head.appendChild(o));
              }
            }
          });
        } catch (e) {
          (0, c.debugUtil)({ text: "loadStripeClient error", value: e });
          return;
        }
      },
      p = () => {
        let e = a(),
          t = document.createElement("script");
        ((t.id = "paypal-script"),
          (t.src = `https://c.paypal.com/da/r/fb.js?f=${e}&s=${l.envClient.NEXT_PUBLIC_PAY_PAL_MERCHANT_ID}_checkout-page&sandbox=false`),
          document.body.appendChild(t));
        let r = document.createElement("script");
        ((r.id = "paypal-fraudnet-script"),
          (r.src = "https://c.paypal.com/da/r/fb.js"),
          document.body.appendChild(r));
        let o = { paypal_session_id: e, paypal_client_metadata_id: e };
        return (
          Object.entries(o).forEach((e) => {
            let [t, r] = e;
            s.accessSessionStorageUtil.setItem(t, r);
          }),
          o
        );
      };
    (e.s(["createSessionsForClient", 0, d], 178668), e.s([], 56395));
  },
]);
