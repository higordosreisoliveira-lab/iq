(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  60020,
  (e) => {
    "use strict";
    var t = e.i(843476),
      l = e.i(948148),
      s = e.i(271645);
    e.i(733344);
    var a = e.i(208507),
      i = e.i(833012);
    e.i(346392);
    var r = e.i(296301);
    e.i(122612);
    var n = e.i(225352),
      o = e.i(117447),
      c = e.i(725397),
      d = e.i(915113),
      m = e.i(657688),
      u = e.i(493598);
    let x = {
        default:
          "relative flex w-full flex-col overflow-hidden rounded-2xl bg-white shadow-rd-card ring-1 ring-black/[0.04]",
        you: "relative flex w-full flex-col overflow-hidden rounded-2xl bg-blue-highlight",
      },
      h = ["h-[10.5rem] md:h-[12.5rem]", "h-[12rem] md:h-[14.25rem]", "h-[13.5rem] md:h-[16rem]"],
      _ = {
        default: "pt-3 text-center text-hp-h3 tabular-nums text-black-custom",
        you: "pt-3 text-center text-hp-h3 tabular-nums text-white",
      },
      p = {
        default: "relative mt-auto w-full overflow-hidden",
        you: "relative mt-auto w-full overflow-hidden px-[11%]",
      },
      b = ["h-[7.56rem] md:h-[9rem]", "h-[7.68rem] md:h-[9.12rem]", "h-[9.72rem] md:h-[11.52rem]"],
      g = "flex flex-col gap-1",
      f = "text-hp-h3 tabular-nums text-black-custom lg:text-hp-h3-lg",
      y = "text-hp-caption text-grey-deep md:text-hp-body-sm",
      j = [
        {
          id: "left",
          kind: "default",
          iq: "113",
          src: "/images/coco-chanelV21.webp",
          altKey: "ab_myiq_checkout_redesign_hero_card_default_alt",
        },
        {
          id: "you",
          kind: "you",
          iq: "???",
          src: "/images/youIq1.webp",
          nameKey: "ab_myiq_home_redesign_report_marker_label",
          altKey: "ab_myiq_checkout_redesign_hero_card_you_alt",
        },
        {
          id: "right",
          kind: "default",
          iq: "160",
          src: "/images/sj.webp",
          altKey: "updated_report_examples_section_steve_jobs",
        },
      ],
      w = {
        option_1: "choose_your_hero_option_1",
        option_2: "choose_your_hero_option_2",
        option_3: "choose_your_hero_option_3",
        option_4: "choose_your_hero_option_4",
        option_5: "choose_your_hero_option_5",
        option_6: "choose_your_hero_option_6",
      },
      k = [
        { id: "avg", value: "107", labelKey: "ab_myiq_checkout_redesign_hero_stat_avg_label" },
        { id: "taken", value: "7,869", labelKey: "ab_myiq_checkout_redesign_hero_stat_tests_label" },
      ],
      v = {
        option_1: { src: "/images/sj.webp", alt: "Steve Jobs" },
        option_2: { src: "/images/ae.webp", alt: "Albert Einstein" },
        option_3: { src: "/images/ep.webp", alt: "Elvis Presley" },
        option_4: { src: "/images/wh.webp", alt: "Whitney Houston" },
        option_5: { src: "/images/ah.webp", alt: "Audrey Hepburn" },
        option_6: { src: "/images/mm.webp", alt: "Marilyn Monroe" },
      },
      N = (e) => {
        let { heroId: s, onCardClick: a } = e,
          i = (0, l.useTranslations)(),
          r = (0, u.getIsGoogleTraffic)(),
          n = null === s ? null : (v[s] ?? null),
          o = null === s ? null : (w[s] ?? null);
        return (0, t.jsx)("div", {
          className: "mx-auto flex w-full max-w-md flex-col gap-7 lg:mx-0 lg:max-w-none lg:gap-8",
          children: (0, t.jsxs)("div", {
            className: "flex flex-col lg:rounded-3xl lg:bg-light-blue lg:px-7 lg:pb-5 lg:pt-9",
            children: [
              (0, t.jsx)("div", {
                className: "flex flex-col gap-4",
                children: (0, t.jsx)("div", {
                  className: "flex items-end justify-center gap-3.5 md:gap-5",
                  children: j.map((e, l) => {
                    let s = "default" === e.kind && "right" === e.id && null !== n,
                      c = s ? n.src : e.src,
                      d = s && null !== o ? o : e.altKey,
                      u = "you" !== e.kind,
                      g = r && u ? "" : i(d).replace("\n", " "),
                      f = (0, t.jsxs)(t.Fragment, {
                        children: [
                          (0, t.jsx)("span", {
                            className:
                              "you" === e.kind
                                ? "w-full text-center font-semibold uppercase text-hp-eyebrow text-blue-custom"
                                : "w-full text-center uppercase text-hp-eyebrow text-grey-deep",
                            children:
                              "you" === e.kind ? i(e.nameKey) : `${i("reviews_page_latest_IQ")} ${e.iq}`,
                          }),
                          (0, t.jsxs)("span", {
                            className: `${x[e.kind]} ${h[l]}`,
                            children: [
                              (0, t.jsx)("span", {
                                className: _[e.kind],
                                children: "you" === e.kind ? e.iq : "",
                              }),
                              (0, t.jsx)("span", {
                                className: `${p[e.kind]} ${b[l]}`,
                                children: (0, t.jsx)(m.default, {
                                  src: c,
                                  alt: g,
                                  fill: !0,
                                  sizes: "(min-width: 768px) 152px, 116px",
                                  priority: !0,
                                  fetchPriority: "high",
                                  className: "object-contain object-bottom",
                                }),
                              }),
                            ],
                          }),
                        ],
                      });
                    return void 0 === a
                      ? (0, t.jsx)(
                          "div",
                          { className: "flex w-[7.25rem] flex-col gap-2 md:w-[9.5rem]", children: f },
                          e.id,
                        )
                      : (0, t.jsx)(
                          "button",
                          {
                            type: "button",
                            className:
                              "flex w-[7.25rem] cursor-pointer flex-col gap-2 rounded-2xl transition-transform duration-150 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-highlight active:scale-[0.98] motion-reduce:transition-none md:w-[9.5rem]",
                            onClick: a,
                            children: f,
                          },
                          e.id,
                        );
                  }),
                }),
              }),
              (0, t.jsxs)("dl", {
                className: "mt-6 hidden grid-cols-3 gap-4 border-t border-slate-200 pt-5 text-center lg:grid",
                children: [
                  k.map((e) =>
                    (0, t.jsxs)(
                      "div",
                      {
                        className: g,
                        children: [
                          (0, t.jsx)("dd", { className: f, children: e.value }),
                          (0, t.jsx)("dt", { className: y, children: i(e.labelKey) }),
                        ],
                      },
                      e.id,
                    ),
                  ),
                  (0, t.jsxs)("div", {
                    className: g,
                    children: [
                      (0, t.jsx)("dd", { className: f, children: "4.1 / 5" }),
                      (0, t.jsxs)("dt", {
                        className: y,
                        children: [
                          (0, t.jsx)("svg", {
                            "aria-hidden": !0,
                            viewBox: "0 0 24 24",
                            fill: "#00b67a",
                            className: "inline size-3.5 shrink-0 align-[-2px]",
                            children: (0, t.jsx)("path", {
                              d: "M12 2.5l2.6 6.2 6.7.5-5.1 4.4 1.6 6.6-5.8-3.6-5.8 3.6 1.6-6.6-5.1-4.4 6.7-.5z",
                            }),
                          }),
                          " ",
                          "137,117",
                          " ",
                          i("ab_myiq_checkout_redesign_hero_rating_tail"),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
        });
      };
    var q = e.i(256889);
    e.i(791371);
    var E = e.i(642448);
    let C = "demo-checkout-hero-cta",
      I = "demo-checkout-closing-cta",
      P = ["demo-checkout-payment", I, "footer"];
    var S = e.i(20362);
    let R = (e) => {
      let { paymentAnchorId: a } = e,
        i = (0, l.useTranslations)(),
        [r, n] = (0, s.useState)(!1),
        [o, c] = (0, s.useState)(() => new Set());
      (0, s.useEffect)(() => {
        let e = document.getElementById(C);
        if (!e) return;
        let t = new IntersectionObserver(
            (e) => {
              let [t] = e;
              return n(!t.isIntersecting);
            },
            { threshold: 0 },
          ),
          l = new IntersectionObserver((e) => {
            c((t) => {
              let l = new Set(t);
              for (let t of e) t.isIntersecting ? l.add(t.target.id) : l.delete(t.target.id);
              return l;
            });
          });
        t.observe(e);
        let s = new Set(),
          a = () => {
            for (let e of P) {
              if (s.has(e)) continue;
              let t = document.getElementById(e);
              null !== t && (l.observe(t), s.add(e));
            }
            return s.size === P.length;
          },
          i = null;
        return (
          a() ||
            (i = new MutationObserver(() => {
              a() && i?.disconnect();
            })).observe(document.body, { childList: !0, subtree: !0 }),
          () => {
            (t.disconnect(), l.disconnect(), i?.disconnect());
          }
        );
      }, []);
      let d = (0, s.useCallback)(() => {
          let e = document.getElementById(a);
          if (null === e) return;
          let t = window.matchMedia(S.MEDIA_REDUCED_MOTION).matches ? "auto" : "smooth";
          (e.scrollIntoView({ behavior: t, block: "start" }), e.focus({ preventScroll: !0 }));
        }, [a]),
        m = r && 0 === o.size;
      return (0, t.jsxs)("div", {
        "data-checkout-mobile-cta": !0,
        inert: !m,
        "aria-hidden": !m,
        className: (0, q.cn)(
          "fixed inset-x-0 bottom-0 z-40 bg-white px-4 pb-[calc(1.5rem+env(safe-area-inset-bottom))] transition-[transform,opacity] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] motion-reduce:transition-none lg:hidden",
          !m && "pointer-events-none translate-y-full opacity-0",
        ),
        children: [
          (0, t.jsx)("span", {
            "aria-hidden": !0,
            className:
              "pointer-events-none absolute inset-x-0 bottom-full h-6 bg-gradient-to-t from-white to-transparent",
          }),
          (0, t.jsx)(E.DemoButton, {
            size: "lg",
            variant: "primary",
            className: "w-full shadow-[0_12px_32px_-10px_rgba(11,12,39,0.35)]",
            onClick: d,
            children: i("ab_myiq_checkout_redesign_hero_cta"),
          }),
        ],
      });
    };
    var T = e.i(117595),
      M = e.i(866897),
      D = e.i(263970);
    let F = 2 / 24,
      A = (e) => {
        let a,
          i,
          r,
          n,
          o,
          c,
          d,
          m,
          { trialCost: u, paymentAnchorId: x, desktopPaymentAnchorId: h, isTimerRenewable: _ = !1 } = e,
          p = (0, l.useTranslations)(),
          { clock: b, isExpired: g } =
            ((a = (0, D.useGlobalStore)((e) => e.checkoutTimerMins)),
            (i = (0, D.useGlobalStore)((e) => e.checkoutTimerSeconds)),
            (r = (0, D.useGlobalStore)((e) => e.checkoutTimerExpired)),
            (n = (0, D.useGlobalStore)((e) => e.checkoutTimerReady)),
            (o = (0, D.useGlobalStore)((e) => e.updateCheckoutTimer)),
            (c = (0, D.useGlobalStore)((e) => e.initCheckoutTimer)),
            (d = (0, D.useGlobalStore)((e) => e.expireCheckoutTimer)),
            (m = () => {
              (T.default.set(M.ECookieArg.CHECKOUT_TIMER_START, Date.now().toString(), { expires: F }),
                c(600));
            }),
            (0, s.useLayoutEffect)(() => {
              let e = T.default.get(M.ECookieArg.CHECKOUT_TIMER_START);
              if (e) {
                let t = 600 - Math.floor((Date.now() - parseInt(e)) / 1e3);
                if (t <= 0) return void (_ ? m() : d());
                c(t);
              } else m();
              let t = setInterval(o, 1e3);
              return () => clearInterval(t);
            }, [d, c, o, _]),
            (0, s.useEffect)(() => {
              0 !== a || 0 !== i || r || (_ ? m() : d());
            }, [r, a, i, d, _]),
            { clock: n ? `${a}:${String(i).padStart(2, "0")}` : "", isExpired: r && !_ }),
          f = (0, s.useCallback)(() => {
            let e = void 0 !== h && window.matchMedia(S.MEDIA_DESKTOP_UP).matches,
              t = document.getElementById(e ? h : x);
            if (null === t) return;
            let l = window.matchMedia(S.MEDIA_REDUCED_MOTION).matches ? "auto" : "smooth";
            (t.scrollIntoView({ behavior: l, block: "start" }), t.focus({ preventScroll: !0 }));
          }, [x, h]),
          y = p("ab_myiq_checkout_redesign_offer_bar_price_template", { total: u ?? "—" });
        return (0, t.jsx)("div", {
          "data-offer-bar": !0,
          className: "sticky top-10 z-40 w-full border-y border-slate-200 bg-white",
          children: (0, t.jsxs)("button", {
            type: "button",
            className:
              "mx-auto flex h-auto w-full max-w-7xl flex-wrap items-center justify-center gap-x-1.5 gap-y-1 px-4 py-2 focus-visible:outline focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-blue-custom xs-m:h-11 xs-m:gap-y-0 xs-m:py-0 md:px-6 lg:px-8",
            onClick: f,
            children: [
              (0, t.jsx)("span", {
                className: "text-hp-body-sm font-semibold text-black-custom",
                children: y,
              }),
              !g &&
                (0, t.jsxs)("span", {
                  className: "text-hp-body-sm text-grey-light",
                  children: [
                    p("ab_myiq_checkout_redesign_offer_bar_ends_in"),
                    " ",
                    (0, t.jsx)("span", {
                      className:
                        "inline-block min-w-[5ch] rounded-md bg-blue-custom px-1.5 py-0.5 text-center font-semibold tabular-nums text-blue-custom",
                      children: b,
                    }),
                  ],
                }),
            ],
          }),
        });
      };
    var O = e.i(861745);
    e.i(333163);
    var L = e.i(216839),
      V = e.i(19576);
    let U = [
        "ab_myiq_checkout_redesign_report_bullet1",
        "ab_myiq_checkout_redesign_report_bullet2",
        "ab_myiq_checkout_redesign_report_bullet3",
      ],
      K = [
        { id: "better", labelKey: "ab_myiq_home_redesign_report_stat1_label", lockedValue: "91%" },
        { id: "score", labelKey: "ab_myiq_home_redesign_report_stat2_label", lockedValue: "120" },
        { id: "above", labelKey: "report_redesign_v2_metric_above_average", lockedValue: "+20" },
      ];
    e.i(900206);
    var z = e.i(669509);
    let B = (e) => {
      let { paymentAnchorId: a, desktopPaymentAnchorId: i, answersCount: r = 40 } = e,
        n = (0, l.useTranslations)(),
        o = (0, O.useLocale)(),
        c = "rtl" === (0, V.getLocaleDirection)(o),
        d = (0, s.useCallback)(() => {
          let e = void 0 !== i && window.matchMedia(S.MEDIA_DESKTOP_UP).matches,
            t = document.getElementById(e ? i : a);
          if (null === t) return;
          let l = window.matchMedia(S.MEDIA_REDUCED_MOTION).matches ? "auto" : "smooth";
          (t.scrollIntoView({ behavior: l, block: "start" }), t.focus({ preventScroll: !0 }));
        }, [a, i]);
      return (0, t.jsxs)("div", {
        className: "grid grid-cols-1 items-center gap-10 lg:grid-cols-[1fr_1.15fr] lg:gap-16",
        children: [
          (0, t.jsxs)("div", {
            className: "flex flex-col gap-4",
            children: [
              (0, t.jsx)("h2", {
                className: (0, q.cn)(
                  "mx-auto max-w-[26ch] text-balance text-center text-hp-h2 text-black-custom lg:mx-0 lg:text-hp-h2-lg",
                  c ? "lg:text-right" : "lg:text-left",
                ),
                children: n("ab_myiq_checkout_redesign_report_title"),
              }),
              (0, t.jsx)("p", {
                className: (0, q.cn)(
                  "mx-auto max-w-xl text-pretty text-center text-hp-lede text-grey-deep lg:mx-0",
                  c ? "lg:text-right" : "lg:text-left",
                ),
                children: n("ab_myiq_checkout_redesign_report_lede"),
              }),
              (0, t.jsx)("ul", {
                className: "mt-2 flex flex-col gap-3 self-center lg:self-start",
                children: U.map((e) =>
                  (0, t.jsxs)(
                    "li",
                    {
                      className: "flex items-start gap-3",
                      children: [
                        (0, t.jsx)(L.IconCheck, { className: "mt-0.5 size-5 shrink-0 text-blue-custom" }),
                        (0, t.jsx)("span", {
                          className: "text-pretty text-hp-body text-grey-deep",
                          children: n(e, { count: String(r) }),
                        }),
                      ],
                    },
                    e,
                  ),
                ),
              }),
            ],
          }),
          (0, t.jsxs)("div", {
            className:
              "relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#F0FAF8] via-[#EFF6FC] to-[#E4EFFD] p-5 md:p-8 lg:p-10",
            children: [
              (0, t.jsx)("span", {
                "aria-hidden": !0,
                className:
                  "pointer-events-none absolute -right-20 -top-24 size-72 rounded-full bg-[#CDEDE7] opacity-70 blur-3xl",
              }),
              (0, t.jsx)("span", {
                "aria-hidden": !0,
                className:
                  "pointer-events-none absolute -bottom-28 -left-24 size-72 rounded-full bg-[#D7E9FF] opacity-90 blur-3xl",
              }),
              (0, t.jsxs)("div", {
                className: "relative rounded-2xl bg-white p-5 shadow-rd-card ring-1 ring-black/[0.04] md:p-6",
                children: [
                  (0, t.jsx)("p", {
                    className: "text-hp-caption font-medium text-grey-deep",
                    children: n("ab_myiq_home_redesign_report_card_label"),
                  }),
                  (0, t.jsxs)("svg", {
                    "aria-hidden": !0,
                    viewBox: "0 0 480 180",
                    className: "mt-3 h-auto w-full",
                    children: [
                      (0, t.jsx)("path", {
                        d: "M0 170 C 120 168, 170 40, 240 40 C 310 40, 360 168, 480 170 L 480 180 L 0 180 Z",
                        fill: "#E8F2FD",
                      }),
                      (0, t.jsx)("path", {
                        d: "M0 170 C 120 168, 170 40, 240 40 C 310 40, 360 168, 480 170",
                        fill: "none",
                        stroke: "#006FEE",
                        strokeWidth: "1.5",
                      }),
                      (0, t.jsx)("line", {
                        x1: "346",
                        y1: "60",
                        x2: "346",
                        y2: "170",
                        stroke: "#006FEE",
                        strokeWidth: "1",
                        strokeDasharray: "3 4",
                      }),
                      (0, t.jsx)("rect", {
                        x: "322",
                        y: "38",
                        width: "48",
                        height: "22",
                        rx: "11",
                        fill: "#006FEE",
                      }),
                      (0, t.jsx)("text", {
                        x: "346",
                        y: "53",
                        textAnchor: "middle",
                        fontSize: "11",
                        fontWeight: "600",
                        fill: "#FFFFFF",
                        children: n("ab_myiq_home_redesign_report_marker_label"),
                      }),
                    ],
                  }),
                  (0, t.jsx)("dl", {
                    className: "mt-4 grid grid-cols-1 gap-3 iphone-pro-max:grid-cols-3",
                    children: K.map((e) =>
                      (0, t.jsxs)(
                        "div",
                        {
                          className:
                            "flex flex-row items-center gap-3 rounded-xl bg-light-blue p-3 iphone-pro-max:flex-col iphone-pro-max:items-start iphone-pro-max:gap-1",
                          children: [
                            (0, t.jsx)("dt", {
                              className: "min-w-0 flex-1 text-start text-hp-caption text-grey-deep",
                              children: n(e.labelKey),
                            }),
                            (0, t.jsx)("dd", {
                              "aria-hidden": !0,
                              className:
                                "shrink-0 select-none text-end text-hp-h3 tabular-nums text-blue-custom blur-[6px]",
                              children: e.lockedValue,
                            }),
                          ],
                        },
                        e.id,
                      ),
                    ),
                  }),
                  (0, t.jsxs)("button", {
                    type: "button",
                    className:
                      "mt-4 flex w-full items-center justify-center gap-2 border-t border-slate-100 pt-3.5 text-hp-caption font-semibold text-green-custom transition-colors duration-150 after:absolute after:inset-0 after:content-[''] hover:text-[#0B635C] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom",
                    onClick: d,
                    children: [
                      (0, t.jsx)(z.IconLock, { className: "size-3.5 shrink-0" }),
                      n("ab_myiq_checkout_redesign_report_lock_line"),
                    ],
                  }),
                ],
              }),
            ],
          }),
        ],
      });
    };
    e.i(743893);
    var W = e.i(852016),
      G = e.i(331890),
      $ = e.i(613488),
      H = e.i(171770),
      Q = e.i(458350),
      X = e.i(386847),
      J = e.i(129466);
    let Z = (e) => [e.currentCountry.code, ...e.neighboringCountries.map((e) => e.code)],
      Y = (e) => {
        let { onClick: a, realUsers: i } = e,
          r = (0, l.useTranslations)(),
          n = ((e) => {
            let [t, l] = (0, s.useState)(null),
              { generateUsers: a } = (0, Q.useGeneratedUser)(),
              i = (0, s.useRef)(a),
              r = (0, X.getClientCountry)()?.toUpperCase(),
              n = (0, s.useMemo)(() => {
                let e = (0, J.getCountryDataFromLocalStorage)();
                return e?.currentCountry?.code?.toUpperCase() === r ? e : null;
              }, [r]),
              { data: o } = (0, G.useGetCountryDataQuery)(r, !n),
              c = n ?? o?.data;
            return (
              (0, s.useEffect)(() => {
                let t;
                if (!c) return;
                let s =
                  ((t = new Set(Z(c).map((e) => e.toUpperCase()))),
                  (e ?? []).filter((e) => t.has(e.country.toUpperCase())));
                (0, H.preloadFlags)([...s.map((e) => e.country), ...Z(c)]);
                let a = () => (0, $.pickRealUser)(s) ?? i.current(1, c)[0] ?? null;
                l(a());
                let r = window.setInterval(() => {
                  l(a());
                }, 4e3);
                return () => {
                  window.clearInterval(r);
                };
              }, [c, e]),
              t
            );
          })(i),
          o = (0, t.jsxs)(t.Fragment, {
            children: [
              (0, t.jsxs)("span", {
                className: "relative flex size-2 shrink-0",
                children: [
                  (0, t.jsx)("span", {
                    className:
                      "absolute inset-0 animate-ping rounded-full bg-[#00b67a] opacity-40 [animation-duration:2s] motion-reduce:animate-none",
                  }),
                  (0, t.jsx)("span", { className: "relative m-px flex-1 rounded-full bg-[#00b67a]" }),
                ],
              }),
              null !== n &&
                (0, t.jsxs)(
                  "span",
                  {
                    className:
                      "flex min-w-0 animate-[fadeSlideIn_300ms_ease-out_both] items-center gap-2 xs-sm:gap-2.5 motion-reduce:animate-none",
                    children: [
                      (0, t.jsxs)("span", {
                        className: "truncate text-hp-caption text-grey-deep md:text-hp-body-sm",
                        children: [
                          (0, t.jsx)("span", {
                            className: "font-semibold text-black-custom",
                            children: n.name,
                          }),
                          " ",
                          r(
                            "female" === n.sex
                              ? "checkout_page_just_bought_female"
                              : "checkout_page_just_bought_male",
                          ),
                        ],
                      }),
                      "" !== n.country &&
                        (0, t.jsx)(W.Flag, {
                          alt: n.country,
                          className: "h-[15px] w-5 shrink-0 rounded-[3px] object-cover",
                          code: n.country,
                        }),
                      (0, t.jsxs)("span", {
                        className:
                          "text-hp-caption font-semibold tabular-nums text-blue-custom md:text-hp-body-sm",
                        children: [r("reviews_page_latest_IQ"), " ", n.count],
                      }),
                    ],
                  },
                  n.id,
                ),
            ],
          });
        return (0, t.jsx)("div", {
          "aria-hidden": !0,
          className: "sticky top-0 z-50 w-full border-b border-slate-200 bg-light-blue",
          children:
            void 0 === a
              ? (0, t.jsx)("div", {
                  className:
                    "mx-auto flex h-10 max-w-7xl items-center justify-center gap-2 px-3 xs-sm:gap-3 xs-sm:px-4 md:px-6 lg:px-8",
                  children: o,
                })
              : (0, t.jsx)("button", {
                  type: "button",
                  tabIndex: -1,
                  className:
                    "mx-auto flex h-10 w-full max-w-7xl cursor-pointer items-center justify-center gap-2 px-3 xs-sm:gap-3 xs-sm:px-4 md:px-6 lg:px-8",
                  onClick: a,
                  children: o,
                }),
        });
      };
    e.i(771699);
    var ee = e.i(381907);
    e.i(361313);
    var et = e.i(140830);
    let el = {
        link: (e) =>
          (0, t.jsx)("a", {
            href: "https://myiq.com/cancellation",
            className:
              "text-blue-custom underline decoration-1 underline-offset-4 transition-colors duration-150",
            children: e,
          }),
      },
      es = [
        {
          id: "demo-faq-includes",
          question: "ab_myiq_home_redesign_faq_q1_question",
          answer: "ab_myiq_home_redesign_faq_q1_answer",
        },
        {
          id: "demo-faq-cancel",
          question: "main_page_faq_question_3",
          answer: "ab_myiq_home_redesign_faq_q2_answer",
          hasLink: !0,
        },
        {
          id: "demo-faq-private",
          question: "ab_myiq_home_redesign_faq_q3_question",
          answer: "ab_myiq_home_redesign_faq_q3_answer",
        },
        {
          id: "demo-faq-good-score",
          question: "ab_myiq_home_redesign_faq_q4_question",
          answer: "ab_myiq_home_redesign_faq_q4_answer",
        },
        {
          id: "demo-faq-increase",
          question: "ab_myiq_home_redesign_faq_q5_question",
          answer: "ab_myiq_home_redesign_faq_q5_answer",
        },
        {
          id: "demo-faq-results",
          question: "ab_myiq_home_redesign_faq_q6_question",
          answer: "ab_myiq_home_redesign_faq_q6_answer",
        },
        {
          id: "demo-faq-age",
          question: "ab_myiq_home_redesign_faq_q7_question",
          answer: "ab_myiq_home_redesign_faq_q7_answer",
        },
        {
          id: "demo-faq-inherit",
          question: "ab_myiq_home_redesign_faq_q8_question",
          answer: "ab_myiq_home_redesign_faq_q8_answer",
        },
      ];
    var ea = e.i(6437);
    e.i(872756);
    var ei = e.i(987132);
    let er = {
        major: "py-8 lg:py-24",
        "chapter-open": "pb-8 pt-8 lg:pt-24 lg:pb-12",
        continuation: "pb-8 pt-8 lg:pt-12 lg:pb-24",
        hero: "pb-0 pt-8 lg:pb-16 lg:pt-28",
      },
      en = { "light-blue": "bg-light-blue", "blue-pale": "bg-blue-pale" },
      eo = {
        h2: "text-balance text-hp-h2 text-black-custom lg:text-hp-h2-lg",
        h3: "text-balance text-hp-h3 text-black-custom lg:text-hp-h3-lg",
      },
      ec = (e) => {
        let {
          id: l,
          tier: s = "major",
          band: a,
          title: i,
          titleSize: r = "h2",
          titleHidden: n = !1,
          lede: o,
          align: c = "center",
          className: d,
          children: m,
        } = e;
        return (0, t.jsxs)("section", {
          id: l,
          className: (0, q.cn)("relative w-full scroll-mt-20", er[s], d),
          children: [
            a &&
              (0, t.jsx)("span", {
                "aria-hidden": !0,
                className: (0, q.cn)("absolute inset-y-0 left-1/2 -z-10 w-screen -translate-x-1/2", en[a]),
              }),
            (0, t.jsxs)(ei.DemoContainer, {
              children: [
                i && n && (0, t.jsx)("h2", { className: "sr-only", children: i }),
                i && !n
                  ? (0, t.jsxs)("div", {
                      className: "flex flex-col gap-10 lg:gap-12",
                      children: [
                        (0, t.jsxs)("div", {
                          className: (0, q.cn)(
                            "flex max-w-4xl flex-col gap-4",
                            "center" === c && "mx-auto items-center text-center",
                          ),
                          children: [
                            (0, t.jsx)("h2", { className: eo[r], children: i }),
                            o &&
                              (0, t.jsx)("p", {
                                className: "max-w-2xl text-pretty text-hp-lede text-grey-deep",
                                children: o,
                              }),
                          ],
                        }),
                        m,
                      ],
                    })
                  : m,
              ],
            }),
          ],
        });
      },
      ed = (e) => {
        let s = (0, l.useTranslations)(),
          a = e.t ?? s,
          i = es.map((e) => ({
            id: e.id,
            question: a(e.question),
            answer: e.hasLink ? a.rich(e.answer, el) : a(e.answer),
          }));
        return (0, t.jsx)(ec, {
          id: "faq",
          children: (0, t.jsxs)("div", {
            className: "flex flex-col gap-10 lg:gap-12",
            children: [
              (0, t.jsx)("h2", {
                className: "text-balance text-center text-hp-h2 text-black-custom lg:text-hp-h2-lg",
                children: a("ab_myiq_home_redesign_faq_title"),
              }),
              (0, t.jsx)(ea.default, { items: i, split: !0 }),
            ],
          }),
        });
      };
    e.i(853754);
    var em = e.i(319970),
      eu = e.i(538318),
      ex = e.i(371576);
    let eh = (e) => {
      let { hasLede: s = !0 } = e,
        a = (0, l.useTranslations)(),
        i = e.t ?? a,
        r = Object.fromEntries(
          [
            eu.REVIEWS_BADGE,
            eu.REVIEWS_PREV_LABEL,
            eu.REVIEWS_NEXT_LABEL,
            ...eu.REVIEWS.flatMap((e) => [e.title, e.body, e.country]),
          ].map((e) => [e, i(e)]),
        );
      return (0, t.jsx)(ec, {
        id: "reviews",
        tier: "major",
        align: "center",
        title: i(eu.REVIEWS_TITLE),
        lede: s ? i(eu.REVIEWS_LEDE) : void 0,
        children: (0, t.jsxs)("div", {
          className: "flex flex-col gap-8",
          children: [
            (0, t.jsx)(ex.default, { translatedByKey: r }),
            (0, t.jsxs)("div", {
              className: "flex flex-col items-center gap-3",
              children: [
                (0, t.jsxs)("p", {
                  className: "text-center text-hp-body-sm text-grey-deep",
                  children: [
                    i(eu.REVIEWS_FOOTER_PREFIX),
                    " ",
                    (0, t.jsx)("span", {
                      className: "font-semibold tabular-nums text-black-custom",
                      children: eu.REVIEWS_FOOTER_SCORE,
                    }),
                    " ",
                    i(eu.REVIEWS_FOOTER_MIDDLE),
                    " ",
                    (0, t.jsx)("span", {
                      className: "font-semibold tabular-nums text-black-custom",
                      children: i(eu.REVIEWS_FOOTER_COUNT),
                    }),
                    ". ",
                    i(eu.REVIEWS_FOOTER_NOTE),
                  ],
                }),
                (0, t.jsxs)("span", {
                  className: "flex items-center gap-1.5",
                  children: [
                    (0, t.jsx)("svg", {
                      "aria-hidden": !0,
                      className: "size-4",
                      viewBox: "0 0 24 24",
                      fill: "#00b67a",
                      focusable: "false",
                      children: (0, t.jsx)("path", {
                        d: "M12 1.6l2.7 6.4 6.9.5-5.3 4.5 1.7 6.7L12 16.5 6 19.7l1.7-6.7L2.4 8.5l6.9-.5L12 1.6z",
                      }),
                    }),
                    (0, t.jsx)("span", {
                      className: "text-hp-body-sm font-semibold text-black-custom",
                      children: eu.REVIEWS_TRUSTPILOT_LABEL,
                    }),
                  ],
                }),
              ],
            }),
          ],
        }),
      });
    };
    e.i(635099);
    var e_ = e.i(901287);
    e.i(118046);
    var ep = e.i(112015);
    let eb = "demo-checkout-coupon",
      eg = "demo-checkout-bullet-disclosure",
      ef = "ab_myiq_checkout_redesign_closing_title";
    var ey = e.i(926654);
    e.i(185595);
    var ej = e.i(266278),
      ew = e.i(891133);
    e.i(80460);
    var ek = e.i(998198);
    let ev = "mt-0.5 size-4 shrink-0 text-black-custom",
      eN = "min-w-0 text-hp-body-sm text-grey-deep",
      eq = [
        "ab_myiq_checkout_redesign_offer_bullet1",
        "ab_myiq_checkout_redesign_offer_bullet2",
        "ab_myiq_checkout_redesign_offer_bullet3",
      ],
      eE = [
        { id: "certificate", labelKey: "ab_myiq_checkout_redesign_summary_row_certificate", isPriceRow: !0 },
        { id: "report", labelKey: "ab_myiq_checkout_redesign_summary_row_report", isPriceRow: !1 },
        { id: "ranking", labelKey: "ab_myiq_checkout_redesign_summary_row_ranking", isPriceRow: !1 },
        { id: "training", labelKey: "ab_myiq_checkout_redesign_summary_row_training", isPriceRow: !1 },
        { id: "courses", labelKey: "ab_myiq_checkout_redesign_summary_row_courses", isPriceRow: !1 },
      ],
      eC = {
        certificate: z.IconAward,
        report: z.IconReport,
        ranking: z.IconGlobe,
        training: z.IconBrain,
        courses: z.IconCourses,
      },
      eI = (e) => {
        let s = (0, l.useTranslations)(),
          {
            variant: a,
            user: i,
            isMarketingSource: r,
            friendEncodedData: o,
            experiments: d,
            isPlanPickerFunnel: m,
            selectedPlan: u,
            onPlanChange: x,
            country: h,
            isUsRegularFunnel: _,
          } = e,
          {
            abMyiqPromoPrice: p,
            abMyiqAb100Vs199: b,
            abMyiqRevolutMonzoBlock: g,
            abMyiqProductFeedbackWidget: f,
            abMyiqPrintCertificateUpsell: y,
            ftMyiqReviewPlatformSplit: j,
            abMyiqBrazilMastercardOnly: w,
            abMyiqPostPaymentProcessingModal: k,
          } = d,
          v = (0, ew.useIsUsA1Campaign)(),
          { isUserRestoring: N } = (0, n.useCheckoutUserRestore)(),
          q = (0, c.isUs)(i?.currency?.countryCode || h),
          E = q && !_,
          C = ("promo_price" === p && r) || void 0,
          { priceForView: I } = (0, ek.getPaymentPlanPrice)({
            paymentPlan: C
              ? "DEMO_PRICE_SPECIAL"
              : "v1_trial_1_99" === b || v
                ? "DEMO_PRICE_1_99"
                : "DEMO_PRICE",
            user: i,
          }),
          { priceForView: P } = (0, ek.getPaymentPlanPrice)({ paymentPlan: "DEMO_PRICE_PREV", user: i }),
          { priceForView: S } = (0, ek.getPaymentPlanPrice)({ paymentPlan: "MONTH_PRICE", user: i }),
          R = (e) => (i ? (0, ek.getCalculatePriceForView)(e, i) : "—"),
          T = i?.paymentInfo?.paynextAmountToPay || R(I),
          M = i?.paymentInfo?.paynextAmountMonth || R(S),
          D = R(P),
          F = (0, c.getBillingCycleDays)(i?.currency?.countryCode || h),
          A = (0, c.isUk)(i?.currency?.countryCode || h, (0, X.getClientCity)()),
          O = !r || A,
          V = s.rich("ab_myiq_checkout_redesign_disclosure", {
            trialCost: T,
            fullCost: M,
            days: F.toString(),
            strong: (e) =>
              O
                ? (0, t.jsx)("span", { className: "font-semibold", children: e })
                : (0, t.jsx)(t.Fragment, { children: e }),
          });
        return (0, t.jsxs)("div", {
          className: "mx-auto flex w-full max-w-md flex-col gap-5 lg:mx-0 lg:max-w-none",
          children: [
            !m &&
              (0, t.jsxs)(t.Fragment, {
                children: [
                  (0, t.jsx)("h2", {
                    className: "order-0 text-balance text-center text-hp-h2 text-black-custom lg:hidden",
                    children: s("ab_myiq_checkout_redesign_offer_bullets_title"),
                  }),
                  (0, t.jsxs)("ul", {
                    className: "order-0 flex flex-col gap-2.5 pt-2 lg:hidden",
                    children: [
                      eq
                        .slice(1)
                        .map((e) =>
                          (0, t.jsxs)(
                            "li",
                            {
                              className: "flex items-start gap-3",
                              children: [
                                (0, t.jsx)(L.IconCheck, { "aria-hidden": !0, className: ev }),
                                (0, t.jsx)("span", { className: eN, children: s(e) }),
                              ],
                            },
                            e,
                          ),
                        ),
                      !q &&
                        (0, t.jsxs)("li", {
                          id: eg,
                          tabIndex: -1,
                          className: "flex scroll-mt-24 items-start gap-3 focus:outline-none",
                          children: [
                            (0, t.jsx)(L.IconCheck, { "aria-hidden": !0, className: ev }),
                            N
                              ? (0, t.jsx)(ey.Skeleton, { className: "h-10 min-w-0 flex-1 rounded-md" })
                              : (0, t.jsx)("span", { className: eN, children: V }),
                          ],
                        }),
                    ],
                  }),
                ],
              }),
            (0, t.jsxs)("div", {
              className: "order-2 lg:order-1",
              children: [
                (0, t.jsx)("p", {
                  className: "uppercase text-hp-eyebrow text-grey-light",
                  children: s("ab_myiq_checkout_redesign_summary_label"),
                }),
                (0, t.jsx)("dl", {
                  className: "mt-2 flex flex-col",
                  children: eE.map((e) => {
                    let l = eC[e.id] ?? z.IconAward,
                      a = e.isPriceRow && N;
                    return (0, t.jsxs)(
                      "div",
                      {
                        className:
                          "courses" === e.id
                            ? "flex items-center gap-3 py-2 lg:hidden"
                            : "flex items-center gap-3 py-2",
                        children: [
                          (0, t.jsx)(l, { className: "size-4 shrink-0 text-grey-custom" }),
                          (0, t.jsx)("dt", {
                            className: "min-w-0 flex-1 text-hp-body-sm text-grey-deep",
                            children: s(e.labelKey),
                          }),
                          a
                            ? (0, t.jsx)(ey.Skeleton, { as: "dd", className: "h-4 w-12 shrink-0 rounded-md" })
                            : (0, t.jsx)("dd", {
                                className: e.isPriceRow
                                  ? "shrink-0 text-right font-semibold tabular-nums text-hp-body-sm text-black-custom"
                                  : "shrink-0 text-right text-hp-body-sm text-blue-custom",
                                children: e.isPriceRow
                                  ? T
                                  : s("ab_myiq_checkout_redesign_summary_row_included"),
                              }),
                        ],
                      },
                      e.id,
                    );
                  }),
                }),
              ],
            }),
            !E &&
              (0, t.jsxs)("div", {
                id: eb,
                tabIndex: -1,
                className:
                  "order-1 flex scroll-mt-24 items-center justify-between gap-4 rounded-xl bg-blue-custom px-4 py-3 focus:outline-none lg:order-2",
                children: [
                  (0, t.jsxs)("span", {
                    className: "flex min-w-0 items-center gap-3",
                    children: [
                      (0, t.jsx)(z.IconTag, { className: "size-5 shrink-0 text-blue-custom" }),
                      (0, t.jsxs)("span", {
                        className: "flex min-w-0 flex-col",
                        children: [
                          (0, t.jsx)("span", {
                            className: "truncate text-hp-body-sm font-semibold text-black-custom",
                            children: s("ab_myiq_checkout_redesign_promo_line"),
                          }),
                          (0, t.jsx)("span", {
                            className: "truncate text-hp-caption text-grey-light",
                            children: s("ab_myiq_checkout_redesign_promo_save_line"),
                          }),
                        ],
                      }),
                    ],
                  }),
                  (0, t.jsx)("span", {
                    className:
                      "shrink-0 rounded-full bg-blue-highlight px-3 py-1 text-hp-caption font-semibold tabular-nums text-white",
                    children: s("ab_myiq_checkout_redesign_promo_pill"),
                  }),
                ],
              }),
            (0, t.jsxs)("div", {
              id: E ? eb : void 0,
              tabIndex: E ? -1 : void 0,
              className: E
                ? "order-3 flex scroll-mt-4 flex-col rounded-2xl border-[1.5px] border-blue-custom bg-white p-5 focus:outline-none md:p-6 lg:border lg:border-slate-200"
                : "order-3 flex flex-col rounded-2xl border-[1.5px] border-blue-custom bg-white p-5 md:p-6 lg:border lg:border-slate-200",
              children: [
                !m &&
                  (0, t.jsxs)("div", {
                    id: E ? eg : void 0,
                    tabIndex: E ? -1 : void 0,
                    className: E
                      ? "flex scroll-mt-9 items-baseline justify-between gap-4 focus:outline-none md:scroll-mt-10"
                      : "flex items-baseline justify-between gap-4",
                    children: [
                      (0, t.jsx)("span", {
                        className: "text-hp-body font-semibold text-black-custom",
                        children: s("ab_myiq_checkout_redesign_due_today_label"),
                      }),
                      N
                        ? (0, t.jsx)(ey.Skeleton, { className: "h-7 w-24 rounded-lg" })
                        : (0, t.jsxs)("span", {
                            className: "flex items-baseline gap-2",
                            children: [
                              !E &&
                                (0, t.jsx)("s", {
                                  className: "text-hp-body-sm tabular-nums text-grey-light line-through",
                                  children: D,
                                }),
                              (0, t.jsx)("span", {
                                className: q
                                  ? "text-hp-body font-semibold tabular-nums text-black-custom"
                                  : "font-semibold tabular-nums text-hp-h3 text-black-custom lg:text-hp-h3-lg",
                                children: T,
                              }),
                            ],
                          }),
                    ],
                  }),
                (0, t.jsx)("div", {
                  id: "checkout-due-today-section",
                  children: (0, t.jsx)(ej.CheckoutFormSectionComponent, {
                    abMyiqProductFeedbackWidget: f,
                    variant: a,
                    user: i,
                    isMarketingSource: r,
                    friendEncodedData: o,
                    abMyiqPromoPrice: p,
                    abMyiqAb100Vs199: b,
                    abMyiqRevolutMonzoBlock: g,
                    abMyiqPrintCertificateUpsell: y,
                    ftMyiqReviewPlatformSplit: j,
                    abMyiqBrazilMastercardOnly: w,
                    isPlanPickerFunnel: m,
                    selectedPlan: u,
                    onPlanChange: x,
                    abMyiqPostPaymentProcessingModal: k,
                    isConsentGateHidden: !q,
                  }),
                }),
              ],
            }),
            !q &&
              (N
                ? (0, t.jsx)(ey.Skeleton, { className: "order-4 hidden h-10 w-full rounded-md lg:block" })
                : (0, t.jsx)("p", {
                    className:
                      "order-4 hidden text-pretty text-center text-hp-body-sm text-grey-light lg:block",
                    children: V,
                  })),
          ],
        });
      },
      eP = "myiq";
    e.s(
      [
        "default",
        0,
        (e) => {
          let {
              userToken: m,
              marketingParams: u,
              friendEncodedData: x,
              experiments: h,
              isPlanPickerFunnel: _,
              selectedHeroId: p,
              country: b,
              bannerUsers: g,
              isUsRegularFunnel: f,
            } = e,
            y = (0, l.useTranslations)();
          (0, o.useModalVh)();
          let { user: j } = (0, a.useCheckout)({
              variant: eP,
              userToken: m,
              marketingParams: u,
              experiments: h,
            }),
            { isUserRestoring: w } = (0, n.useCheckoutUserRestore)(),
            k = (0, d.getIsMarketingSource)(),
            v = "promo_price" === h.abMyiqPromoPrice && !!k,
            q = (0, c.isUs)(j?.currency?.countryCode || b),
            P = q && !f,
            T = q && f ? eb : eg,
            [M, D] = (0, s.useState)(ep.DEFAULT_PLAN_PICKER_PLAN),
            [F, O] = (0, s.useState)(!1);
          (0, s.useEffect)(() => {
            let e = () => O(!0);
            if ("requestIdleCallback" in window) {
              let t = requestIdleCallback(e, { timeout: 200 });
              return () => cancelIdleCallback(t);
            }
            let t = setTimeout(e, 200);
            return () => clearTimeout(t);
          }, []);
          let L = (0, s.useCallback)(() => {
              let e = window.matchMedia(S.MEDIA_DESKTOP_UP).matches,
                t = document.getElementById(e ? eb : T);
              null !== t &&
                (t.scrollIntoView({ behavior: "smooth", block: "start" }), t.focus({ preventScroll: !0 }));
            }, []),
            V = w ? null : (j?.paymentInfo?.paynextAmountToPay ?? null),
            U = `${y("ab_myiq_checkout_redesign_hero_title_line1")} ${y("ab_myiq_checkout_redesign_hero_title_line2")}`;
          return (0, t.jsxs)("div", {
            className: "isolate flex min-h-[calc(100*var(--vh,1vh))] flex-col bg-white antialiased",
            children: [
              !P && (0, t.jsx)(Y, { onClick: L, realUsers: g }),
              (0, t.jsx)(et.FunnelHeaderComponent, {
                isCounterVisible: !1,
                counterCurrent: 0,
                railCurrent: 0,
                isRailVisible: !1,
                isTimerVisible: !1,
                clock: S.FUNNEL_CLOCK_PLACEHOLDER,
                isClockLive: !1,
                email: w ? null : (j?.email ?? null),
                isSticky: !1,
                brandHref: null,
              }),
              !P &&
                (0, t.jsx)(A, {
                  trialCost: V,
                  paymentAnchorId: T,
                  desktopPaymentAnchorId: eb,
                  isTimerRenewable: v,
                }),
              (0, t.jsxs)("main", {
                className: "flex flex-1 flex-col",
                children: [
                  (0, t.jsx)(r.PaywallConfettiComponent, {
                    funnel: eP,
                    children: (0, t.jsx)("section", {
                      "aria-label": U,
                      className: "relative w-full",
                      children: (0, t.jsxs)(ei.DemoContainer, {
                        className: "pb-12 pt-6 lg:pb-16 lg:pt-8",
                        children: [
                          (0, t.jsx)("h1", {
                            className:
                              "hidden text-balance text-center text-black-custom lg:mb-10 lg:block lg:text-hp-h2-lg",
                            children: U,
                          }),
                          (0, t.jsxs)("div", {
                            className:
                              "w-full lg:grid lg:grid-cols-[minmax(0,1.05fr)_minmax(0,1fr)] lg:items-start lg:gap-16",
                            children: [
                              (0, t.jsxs)("div", {
                                className: "relative pb-8 lg:col-start-1 lg:row-start-1 lg:pb-0",
                                children: [
                                  (0, t.jsx)("span", {
                                    "aria-hidden": !0,
                                    className:
                                      "absolute -top-6 bottom-0 left-1/2 -z-10 w-screen -translate-x-1/2 bg-slate-100 lg:hidden",
                                  }),
                                  P
                                    ? (0, t.jsx)(i.IqCertificateComponent, {
                                        isFluid: !0,
                                        onClick: L,
                                        className:
                                          "mt-0 lg:origin-top lg:-translate-x-[1.5%] lg:scale-[0.85]",
                                      })
                                    : (0, t.jsx)(N, { heroId: p ?? null, onCardClick: L }),
                                  (0, t.jsx)("h1", {
                                    className:
                                      "mt-8 text-balance text-center text-hp-h2 text-black-custom lg:hidden",
                                    children: U,
                                  }),
                                  (0, t.jsx)("div", {
                                    id: C,
                                    className: "mx-auto mt-6 w-full max-w-md lg:hidden",
                                    children: (0, t.jsx)(E.DemoButton, {
                                      size: "lg",
                                      variant: "primary",
                                      className: "w-full",
                                      onClick: L,
                                      children: y("ab_myiq_checkout_redesign_hero_cta"),
                                    }),
                                  }),
                                ],
                              }),
                              (0, t.jsx)("div", {
                                id: "demo-checkout-payment",
                                tabIndex: -1,
                                className:
                                  "mt-12 scroll-mt-16 focus:outline-none lg:col-start-2 lg:row-start-1 lg:mt-0",
                                children: (0, t.jsx)(eI, {
                                  variant: eP,
                                  user: j,
                                  isMarketingSource: k,
                                  friendEncodedData: x,
                                  experiments: h,
                                  isPlanPickerFunnel: _,
                                  selectedPlan: M,
                                  onPlanChange: D,
                                  country: b,
                                  isUsRegularFunnel: f,
                                }),
                              }),
                            ],
                          }),
                        ],
                      }),
                    }),
                  }),
                  F &&
                    (0, t.jsxs)(t.Fragment, {
                      children: [
                        (0, t.jsx)("section", {
                          "aria-label": y(ee.REVIEWS_FEATURED_LABEL_TEXT),
                          className: "relative hidden w-full lg:block",
                          children: (0, t.jsx)(ei.DemoContainer, {
                            className: "pb-14 lg:pb-16",
                            children: (0, t.jsxs)("div", {
                              className: "flex flex-col gap-4",
                              children: [
                                (0, t.jsx)("p", {
                                  className: "text-center text-hp-eyebrow uppercase text-grey-light",
                                  children: y(ee.REVIEWS_FEATURED_LABEL_TEXT),
                                }),
                                (0, t.jsx)(e_.DemoMarquee, {
                                  items: ee.REVIEWS_MARQUEE_LOGOS,
                                  className:
                                    "w-full text-grey-light opacity-70 grayscale [&_svg]:h-5 [&_svg]:w-auto",
                                }),
                              ],
                            }),
                          }),
                        }),
                        (0, t.jsxs)("div", {
                          className: "relative w-full",
                          children: [
                            (0, t.jsx)("span", {
                              "aria-hidden": !0,
                              className:
                                "absolute inset-y-0 left-1/2 -z-10 w-screen -translate-x-1/2 bg-light-blue",
                            }),
                            (0, t.jsx)(eh, { hasLede: !1 }),
                          ],
                        }),
                        (0, t.jsx)("section", {
                          "aria-label": y("ab_myiq_checkout_redesign_report_title"),
                          className: "relative w-full",
                          children: (0, t.jsx)(ei.DemoContainer, {
                            className: "pb-8 pt-16 lg:pb-12 lg:pt-24",
                            children: (0, t.jsx)(B, {
                              paymentAnchorId: T,
                              desktopPaymentAnchorId: eb,
                              answersCount: P ? 60 : void 0,
                            }),
                          }),
                        }),
                        (0, t.jsx)(ed, {}),
                        (0, t.jsx)("section", {
                          "aria-label": y(ef),
                          className: "relative w-full",
                          children: (0, t.jsx)(ei.DemoContainer, {
                            className: "pb-16 lg:pb-24",
                            children: (0, t.jsxs)("div", {
                              className:
                                "flex flex-col items-start gap-8 rounded-3xl bg-light-blue px-6 py-12 md:px-10 md:py-14 lg:flex-row lg:items-center lg:justify-between lg:gap-12 lg:px-16 lg:py-20",
                              children: [
                                (0, t.jsxs)("div", {
                                  className: "flex flex-col gap-3",
                                  children: [
                                    (0, t.jsx)("h2", {
                                      className:
                                        "max-w-[24ch] text-balance text-hp-display text-black-custom lg:text-hp-display-lg",
                                      children: y(ef),
                                    }),
                                    (0, t.jsx)("p", {
                                      className: "text-pretty text-hp-lede text-grey-deep",
                                      children: y("ab_myiq_checkout_redesign_closing_lede"),
                                    }),
                                  ],
                                }),
                                (0, t.jsx)("div", {
                                  id: I,
                                  className: "w-full shrink-0 md:w-auto",
                                  children: (0, t.jsx)(E.DemoButton, {
                                    size: "lg",
                                    variant: "primary",
                                    className: "w-full md:w-auto",
                                    onClick: L,
                                    children: y("ab_myiq_checkout_redesign_closing_cta"),
                                  }),
                                }),
                              ],
                            }),
                          }),
                        }),
                      ],
                    }),
                ],
              }),
              (0, t.jsx)(em.DemoFooterComponent, {}),
              (0, t.jsx)(R, { paymentAnchorId: T }),
            ],
          });
        },
      ],
      60020,
    );
  },
  949635,
  function (e) {
    e.n(e.i(60020));
  },
]);
