(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  882983,
  (e) => {
    "use strict";
    var t = e.i(265840),
      a = e.i(271645),
      i = e.i(273830),
      n = e.i(620253),
      l = e.i(75540),
      o = e.i(843476),
      r = (0, i.forwardRef)((e, i) => {
        let { as: r, children: s, className: d, ..._ } = e,
          { slots: c, classNames: m, bodyId: u, setBodyMounted: p } = (0, t.useModalContext)(),
          f = (0, n.useDOMRef)(i);
        return (
          (0, a.useEffect)(() => (p(!0), () => p(!1)), [p]),
          (0, o.jsx)(r || "div", {
            ref: f,
            className: c.body({ class: (0, l.clsx)(null == m ? void 0 : m.body, d) }),
            id: u,
            ..._,
            children: s,
          })
        );
      });
    ((r.displayName = "HeroUI.ModalBody"), e.s(["ModalBody", 0, r], 882983));
  },
  436643,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(948148),
      i = e.i(271645);
    e.i(317197);
    var n = e.i(231529),
      l = e.i(523173),
      o = e.i(622963);
    e.i(568267);
    var r = e.i(154692);
    e.i(470366);
    var s = e.i(504001);
    (e.s([], 783868),
      e.i(783868),
      e.s(
        [
          "FastTrackConfirmModalComponent",
          0,
          (e) => {
            let { user: d, price: _, onConfirm: c, onClose: m } = e,
              u = (0, a.useTranslations)(),
              p = (0, o.useModalStore)((e) => e.handleChangeModalStore),
              [f, y] = (0, i.useState)(!1);
            (0, i.useEffect)(() => {
              (0, s.trackClientEvents)({
                event: l.EAnalyticEvents.REPORT_GENERATION_FAST_TRACK_MODAL_VIEWED,
                user: d,
                params: { funnel: d?.funnel, page_name: "DetailedReport" },
              });
            }, []);
            let C = async () => {
              ((0, s.trackClientEvents)({
                event: l.EAnalyticEvents.PRIORITY_REPORT_CONFIRM_CLICKED,
                user: d,
                params: {
                  funnel: d?.funnel,
                  page_name: "DetailedReport",
                  button_name: u("ab_myiq_report_delayed_generation_confirm_btn_charge", { price: _ }),
                },
              }),
                y(!0));
              try {
                await c();
              } finally {
                y(!1);
              }
            };
            return (0, t.jsxs)(n.ModalBodyComponent, {
              title: u("ab_myiq_report_delayed_generation_confirm_title"),
              subtitle: u("ab_myiq_report_delayed_generation_confirm_subtitle", { price: _ }),
              children: [
                (0, t.jsxs)("div", {
                  className: "flex flex-col gap-2.5",
                  children: [
                    (0, t.jsx)(r.ButtonComponent, {
                      size: "sm",
                      fullWidth: !0,
                      onClick: C,
                      isLoading: f,
                      children: u("ab_myiq_report_delayed_generation_confirm_btn_charge", { price: _ }),
                    }),
                    (0, t.jsx)(r.ButtonComponent, {
                      variant: "default",
                      size: "sm",
                      onClick: () => {
                        ((0, s.trackClientEvents)({
                          event: l.EAnalyticEvents.PRIORITY_REPORT_CANCEL_CLICKED,
                          user: d,
                          params: {
                            funnel: d?.funnel,
                            page_name: "DetailedReport",
                            button_name: u("ab_myiq_report_delayed_generation_confirm_btn_cancel"),
                          },
                        }),
                          m?.(),
                          p({ isModalVisible: !1, modalComponent: null }));
                      },
                      isDisabled: f,
                      children: u("ab_myiq_report_delayed_generation_confirm_btn_cancel"),
                    }),
                  ],
                }),
                (0, t.jsxs)("div", {
                  className:
                    "mt-2 gap-0.5 break-keep text-center text-xs italic leading-tight text-default-600",
                  children: [
                    (0, t.jsx)("div", { className: "inline", children: "*" }),
                    u("ab_myiq_report_delayed_generation_confirm_disclaimer", { price: _ }),
                  ],
                }),
              ],
            });
          },
        ],
        436643,
      ));
  },
  250096,
  function (e) {
    e.n(e.i(436643));
  },
  317197,
  231529,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(882983),
      i = e.i(742214),
      n = e.i(663615);
    e.i(680460);
    var l = e.i(885944);
    (e.s([], 317197),
      e.s(
        [
          "ModalBodyComponent",
          0,
          (e) => {
            let {
              children: o,
              title: r,
              subtitle: s,
              className: d = "",
              bodyClassName: _,
              titleClassName: c,
            } = e;
            return (0, t.jsx)(i.ModalContent, {
              className: d,
              children: (0, t.jsxs)(a.ModalBody, {
                className: (0, n.cn)(
                  "flex h-full w-full flex-col gap-5 p-5 antialiased md:p-6 [@media(max-height:580px)]:gap-3 [@media(max-height:580px)]:p-4",
                  _,
                ),
                children: [
                  (r || s) &&
                    (0, t.jsx)(l.ModalHeaderComponent, { title: r, subtitle: s, titleClassName: c }),
                  o,
                ],
              }),
            });
          },
        ],
        231529,
      ));
  },
]);
