(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  661852,
  (e) => {
    "use strict";
    e.s([
      "ANALYZING_COMPLETE_ANNOUNCEMENT",
      0,
      "Analysis complete.",
      "FUNNEL_BRAND_LABEL",
      0,
      "myIQ — back to home",
      "FUNNEL_CLOCK_LABEL",
      0,
      "Elapsed time",
      "FUNNEL_PROGRESS_LABEL",
      0,
      "Test progress",
      "MEASURE_STATE_TEXT",
      0,
      { pending: " — waiting", active: " — in progress", done: " — scored" },
      "QUIZ_FIGURE_ALT",
      0,
      "",
      "QUIZ_SEQUENCE_LABEL",
      0,
      "Number sequence to memorize",
      "formatMeasureAnnouncement",
      0,
      (e) => `${e} scored.`,
      "formatOptionLabel",
      0,
      (e) => `Option ${e}`,
      "formatProgressValueText",
      0,
      (e, t) => `Question ${e} of ${t}`,
      "formatQuestionAnnouncement",
      0,
      (e) => `${e}.`,
      "splitCountdownTemplate",
      0,
      (e) => {
        let [t = "", r = ""] = e.split("{seconds}");
        return { before: t, after: r };
      },
    ]);
  },
  406953,
  413769,
  (e) => {
    "use strict";
    (e.s(
      [
        "HEADER_BRAND",
        0,
        "flex items-center gap-2 rounded-lg focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom",
        "HEADER_CLOCK_CHIP",
        0,
        "inline-flex h-6 shrink-0 items-center gap-1 rounded-full border border-slate-200 bg-light-blue px-2.5 text-hp-caption tabular-nums text-grey-deep",
        "HEADER_COUNTER",
        0,
        "text-hp-caption tabular-nums text-grey-light",
        "HEADER_COUNTER_VALUE",
        0,
        "text-grey-deep",
        "HEADER_DIVIDER",
        0,
        "h-4 w-px shrink-0 bg-slate-100",
        "HEADER_EMAIL_AVATAR",
        0,
        "flex size-6 shrink-0 items-center justify-center rounded-full bg-slate-100 text-[0.625rem]/[1] font-semibold uppercase text-grey-deep",
        "HEADER_EMAIL_CHIP",
        0,
        "inline-flex h-8 min-w-0 shrink items-center gap-2 rounded-full border border-slate-200 bg-white pl-1 pr-3 text-hp-caption text-grey-deep",
        "HEADER_EMAIL_TEXT",
        0,
        "max-w-[9rem] truncate md:max-w-[16rem]",
        "HEADER_LOGO_VIEW_BOX",
        0,
        "0 0 108 31",
        "HEADER_RAIL_FILL",
        0,
        "block h-0.5 w-full origin-left bg-blue-highlight transition-transform duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] motion-reduce:transition-none",
        "HEADER_RAIL_TRACK",
        0,
        "absolute inset-x-0 bottom-0 h-0.5 bg-blue-custom",
        "HEADER_SHELL",
        0,
        "sticky top-0 z-50 w-full shrink-0 border-b bg-white transition-colors duration-150",
        "HEADER_SHELL_STATIC",
        0,
        "w-full shrink-0 border-b border-transparent bg-white",
      ],
      406953,
    ),
      e.s(["QUIZ_FLOW_TOTAL_COUNTED", 0, 40], 413769));
  },
  361313,
  140830,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(948148),
      s = e.i(256889);
    e.i(872756);
    var i = e.i(987132);
    e.i(379551);
    var a = e.i(90614);
    e.i(83029);
    var n = e.i(40959),
      l = e.i(406953),
      o = e.i(413769),
      c = e.i(20362),
      u = e.i(661852);
    e.i(900206);
    var d = e.i(669509);
    (e.s([], 361313),
      e.s(
        [
          "FunnelHeaderComponent",
          0,
          (e) => {
            let {
                isCounterVisible: m,
                counterCurrent: x,
                counterTotal: h = o.QUIZ_FLOW_TOTAL_COUNTED,
                railCurrent: p,
                railTotal: b = o.QUIZ_FLOW_TOTAL_COUNTED,
                isTimerVisible: f,
                clock: E,
                isClockLive: g,
                isRailVisible: v = !0,
                email: _ = null,
                isSticky: A = !0,
                brandHref: N = c.ROUTE_HOME,
              } = e,
              j = (0, r.useTranslations)(),
              L = (0, a.useHeaderScroll)(),
              y = Math.min(100, Math.max(0, (p / b) * 100)),
              R = A && L && !v;
            return (0, t.jsxs)("header", {
              className: (0, s.cn)(
                A ? l.HEADER_SHELL : l.HEADER_SHELL_STATIC,
                A && (R ? "border-slate-200" : "border-transparent"),
              ),
              children: [
                (0, t.jsx)(i.DemoContainer, {
                  children: (0, t.jsxs)("div", {
                    className: "flex h-16 items-center justify-between gap-4",
                    children: [
                      null === N
                        ? (0, t.jsxs)("span", {
                            className: l.HEADER_BRAND,
                            children: [
                              (0, t.jsx)(n.IconLogoDark, {
                                "aria-hidden": !0,
                                viewBox: l.HEADER_LOGO_VIEW_BOX,
                                className: "h-7 w-auto",
                              }),
                              (0, t.jsx)("span", { className: "sr-only", children: u.FUNNEL_BRAND_LABEL }),
                            ],
                          })
                        : (0, t.jsxs)("a", {
                            href: N,
                            className: l.HEADER_BRAND,
                            children: [
                              (0, t.jsx)(n.IconLogoDark, {
                                "aria-hidden": !0,
                                viewBox: l.HEADER_LOGO_VIEW_BOX,
                                className: "h-7 w-auto",
                              }),
                              (0, t.jsx)("span", { className: "sr-only", children: u.FUNNEL_BRAND_LABEL }),
                            ],
                          }),
                      (0, t.jsxs)("div", {
                        className: "flex min-w-0 shrink items-center gap-3",
                        children: [
                          null !== _ &&
                            (0, t.jsxs)("span", {
                              "data-email": !0,
                              className: l.HEADER_EMAIL_CHIP,
                              children: [
                                (0, t.jsx)("span", {
                                  "aria-hidden": !0,
                                  className: l.HEADER_EMAIL_AVATAR,
                                  children: _.slice(0, 2),
                                }),
                                (0, t.jsx)("span", { className: l.HEADER_EMAIL_TEXT, children: _ }),
                              ],
                            }),
                          m &&
                            (0, t.jsxs)("p", {
                              "data-counter": !0,
                              className: l.HEADER_COUNTER,
                              children: [
                                (0, t.jsx)("span", { className: l.HEADER_COUNTER_VALUE, children: x }),
                                ` ${j("text_of")} `,
                                h,
                              ],
                            }),
                          m && f && (0, t.jsx)("span", { "aria-hidden": !0, className: l.HEADER_DIVIDER }),
                          f &&
                            (0, t.jsxs)("span", {
                              "data-timer": !0,
                              "aria-hidden": g,
                              "aria-label": g ? void 0 : u.FUNNEL_CLOCK_LABEL,
                              className: l.HEADER_CLOCK_CHIP,
                              children: [(0, t.jsx)(d.IconClock, { className: "size-3.5" }), E],
                            }),
                        ],
                      }),
                    ],
                  }),
                }),
                v &&
                  (0, t.jsx)("div", {
                    role: "progressbar",
                    "aria-label": u.FUNNEL_PROGRESS_LABEL,
                    "aria-valuemin": 0,
                    "aria-valuemax": b,
                    "aria-valuenow": p,
                    "aria-valuetext": (0, u.formatProgressValueText)(p, b),
                    className: l.HEADER_RAIL_TRACK,
                    children: (0, t.jsx)("span", {
                      className: l.HEADER_RAIL_FILL,
                      style: { transform: `scaleX(${y / 100})` },
                    }),
                  }),
              ],
            });
          },
        ],
        140830,
      ));
  },
  900206,
  669509,
  (e) => {
    "use strict";
    var t = e.i(843476);
    let r = {
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 1.5,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      "aria-hidden": !0,
    };
    (e.s(
      [
        "IconAward",
        0,
        (e) => {
          let { className: s } = e;
          return (0, t.jsxs)("svg", {
            ...r,
            className: s,
            children: [
              (0, t.jsx)("circle", { cx: "12", cy: "9", r: "5" }),
              (0, t.jsx)("path", { d: "m8.5 13.5-1.5 7 5-2.5 5 2.5-1.5-7" }),
            ],
          });
        },
        "IconBrain",
        0,
        (e) => {
          let { className: s } = e;
          return (0, t.jsxs)("svg", {
            ...r,
            className: s,
            children: [
              (0, t.jsx)("path", {
                d: "M12 4.5a3 3 0 0 0-5.8 1A3.2 3.2 0 0 0 4 8.7a3.4 3.4 0 0 0 .6 5.4A3.2 3.2 0 0 0 9 19.5c1.3 0 2.4-.7 3-1.8",
              }),
              (0, t.jsx)("path", {
                d: "M12 4.5a3 3 0 0 1 5.8 1A3.2 3.2 0 0 1 20 8.7a3.4 3.4 0 0 1-.6 5.4A3.2 3.2 0 0 1 15 19.5c-1.3 0-2.4-.7-3-1.8",
              }),
              (0, t.jsx)("path", { d: "M12 4.5v13.2" }),
            ],
          });
        },
        "IconClock",
        0,
        (e) => {
          let { className: s } = e;
          return (0, t.jsxs)("svg", {
            ...r,
            className: s,
            children: [
              (0, t.jsx)("circle", { cx: "12", cy: "12", r: "9" }),
              (0, t.jsx)("path", { d: "M12 7.5v5l3 2" }),
            ],
          });
        },
        "IconCourses",
        0,
        (e) => {
          let { className: s } = e;
          return (0, t.jsxs)("svg", {
            ...r,
            className: s,
            children: [
              (0, t.jsx)("path", { d: "M12 4 2 9l10 5 10-5z" }),
              (0, t.jsx)("path", { d: "M5 10.7V16c0 1.7 3.1 3 7 3s7-1.3 7-3v-5.3" }),
            ],
          });
        },
        "IconGlobe",
        0,
        (e) => {
          let { className: s } = e;
          return (0, t.jsxs)("svg", {
            ...r,
            className: s,
            children: [
              (0, t.jsx)("circle", { cx: "12", cy: "12", r: "9" }),
              (0, t.jsx)("path", { d: "M3 12h18" }),
              (0, t.jsx)("path", { d: "M12 3a15 15 0 0 1 0 18" }),
              (0, t.jsx)("path", { d: "M12 3a15 15 0 0 0 0 18" }),
            ],
          });
        },
        "IconLock",
        0,
        (e) => {
          let { className: s } = e;
          return (0, t.jsxs)("svg", {
            ...r,
            className: s,
            children: [
              (0, t.jsx)("rect", { x: "4.75", y: "10.5", width: "14.5", height: "9.75", rx: "2" }),
              (0, t.jsx)("path", { d: "M8.25 10.5V7.75a3.75 3.75 0 0 1 7.5 0v2.75" }),
            ],
          });
        },
        "IconReport",
        0,
        (e) => {
          let { className: s } = e;
          return (0, t.jsxs)("svg", {
            ...r,
            className: s,
            children: [
              (0, t.jsx)("path", { d: "M14 2H7a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7z" }),
              (0, t.jsx)("path", { d: "M14 2v5h5" }),
              (0, t.jsx)("path", { d: "M9 13h6" }),
              (0, t.jsx)("path", { d: "M9 17h6" }),
            ],
          });
        },
        "IconStar",
        0,
        (e) => {
          let { className: r } = e;
          return (0, t.jsx)("svg", {
            viewBox: "0 0 24 24",
            fill: "currentColor",
            "aria-hidden": !0,
            className: r,
            children: (0, t.jsx)("path", {
              d: "M12 3.5l2.6 5.27 5.82.85-4.21 4.1.99 5.78L12 16.77l-5.2 2.73.99-5.78-4.21-4.1 5.82-.85z",
            }),
          });
        },
        "IconTag",
        0,
        (e) => {
          let { className: s } = e;
          return (0, t.jsxs)("svg", {
            ...r,
            className: s,
            children: [
              (0, t.jsx)("path", {
                d: "M12.6 2.9 21 11.4a2 2 0 0 1 0 2.8l-6.8 6.8a2 2 0 0 1-2.8 0L2.9 12.6A2 2 0 0 1 2.3 11l.3-5.6a2 2 0 0 1 1.9-1.9L10 3.2a2 2 0 0 1 1.5.5Z",
              }),
              (0, t.jsx)("circle", { cx: "8", cy: "8", r: "1.25" }),
            ],
          });
        },
      ],
      669509,
    ),
      e.s([], 900206));
  },
  279866,
  899948,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(271645),
      s = e.i(20362),
      i = e.i(256889),
      a = e.i(661852);
    let n = (e) => {
        let {
            kind: s,
            imageVariant: n = "fragment",
            index: l,
            letter: o,
            label: c,
            src: u,
            showBadge: d = !0,
            align: m = "start",
            density: x = "default",
            restClassName: h,
            isSelected: p,
            tabIndex: b,
            innerRef: f,
            onSelect: E,
          } = e,
          [g, v] = (0, r.useState)(!1),
          _ = (0, r.useRef)(null),
          A = (0, r.useCallback)(() => {
            v(!0);
          }, []);
        (0, r.useEffect)(() => {
          if ("image" !== s) return;
          let e = window.setTimeout(() => {
            let e = _.current;
            null !== e && e.complete && 0 === e.naturalWidth && v(!0);
          }, 0);
          return () => {
            window.clearTimeout(e);
          };
        }, [s, u]);
        let N = (0, r.useCallback)(() => {
          E(l, !0);
        }, [l, E]);
        if ("image" === s) {
          let e = "portrait" === n;
          return (0, t.jsxs)("button", {
            type: "button",
            role: "radio",
            "aria-checked": p,
            "aria-label": c ?? (0, a.formatOptionLabel)(o),
            tabIndex: b,
            ref: f,
            "data-option-index": l,
            className: (0, i.cn)(
              e
                ? "group relative flex flex-col items-center justify-center gap-2.5 rounded-2xl border px-3 py-4 transition-[background-color,border-color,transform] duration-150 active:scale-[0.97] ease-[cubic-bezier(0.4,0,0.2,1)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom motion-reduce:transition-none md:py-5"
                : "group relative flex h-20 max-xs-sm:h-16 items-center justify-center rounded-2xl border p-1.5 transition-[background-color,border-color,transform] duration-150 active:scale-[0.97] ease-[cubic-bezier(0.4,0,0.2,1)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom motion-reduce:transition-none md:h-28 lg:h-24",
              p
                ? "border-green-custom bg-correct-bg"
                : e
                  ? "border-slate-200 bg-white [@media(hover:hover)]:hover:border-slate-300"
                  : "border-transparent bg-light-blue [@media(hover:hover)]:hover:border-slate-200 [@media(hover:hover)]:hover:bg-white active:!border-blue-100 active:!bg-blue-100",
            ),
            onClick: N,
            children: [
              (0, t.jsx)("span", {
                "aria-hidden": !0,
                className: p
                  ? "absolute left-1.5 top-1.5 flex size-5 items-center justify-center rounded-full bg-green-custom text-hp-caption font-medium tabular-nums text-white"
                  : "hidden",
                children: o,
              }),
              g || void 0 === u
                ? (0, t.jsx)("span", {
                    "aria-hidden": !0,
                    className: "text-hp-h4 text-grey-light",
                    children: o,
                  })
                : (0, t.jsx)("img", {
                    ref: _,
                    src: u,
                    alt: "",
                    "aria-hidden": !0,
                    draggable: !1,
                    decoding: "sync",
                    className: e
                      ? "h-16 w-auto object-contain md:h-[4.5rem]"
                      : "h-12 max-xs-sm:h-9 w-auto max-w-[85%] object-contain md:h-14 lg:h-16",
                    onError: A,
                  }),
              e &&
                void 0 !== c &&
                (0, t.jsx)("span", {
                  className: "text-balance text-center text-hp-body-sm font-medium text-black-custom",
                  children: c,
                }),
            ],
          });
        }
        return (0, t.jsxs)("button", {
          type: "button",
          role: "radio",
          "aria-checked": p,
          tabIndex: b,
          ref: f,
          "data-option-index": l,
          className: (0, i.cn)(
            "compact" === x
              ? "flex min-h-12 max-xs-sm:min-h-10 w-full items-center gap-3 rounded-2xl border px-4 max-xs-sm:px-3 py-3 max-xs-sm:py-2 text-left transition-[background-color,border-color,color,transform] duration-150 active:scale-[0.97] ease-[cubic-bezier(0.4,0,0.2,1)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom motion-reduce:transition-none md:px-5"
              : "flex min-h-14 max-xs-sm:min-h-12 w-full items-center gap-3 rounded-2xl border px-4 max-xs-sm:px-3 py-3 max-xs-sm:py-2 text-left transition-[background-color,border-color,color,transform] duration-150 active:scale-[0.97] ease-[cubic-bezier(0.4,0,0.2,1)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom motion-reduce:transition-none md:px-5",
            p
              ? "border-green-custom bg-correct-bg"
              : (h ??
                  "border-slate-300 bg-white [@media(hover:hover)]:hover:border-slate-400 [@media(hover:hover)]:hover:bg-light-blue"),
          ),
          onClick: N,
          children: [
            d &&
              (0, t.jsx)("span", {
                "aria-hidden": !0,
                className: (0, i.cn)(
                  "flex size-6 shrink-0 items-center justify-center rounded-full text-hp-caption font-medium tabular-nums",
                  p ? "bg-green-custom text-white" : "bg-slate-100 text-grey-deep",
                ),
                children: o,
              }),
            (0, t.jsx)("span", {
              "data-option-label": !0,
              className: d
                ? p
                  ? "min-w-0 flex-1 text-pretty text-hp-body tabular-nums text-black-custom"
                  : "min-w-0 flex-1 text-pretty text-hp-body tabular-nums text-grey-deep"
                : "center" === m
                  ? p
                    ? "min-w-0 flex-1 text-pretty text-center text-hp-body tabular-nums text-black-custom"
                    : "min-w-0 flex-1 text-pretty text-center text-hp-body tabular-nums text-grey-deep"
                  : p
                    ? "min-w-0 flex-1 text-pretty text-hp-body tabular-nums text-black-custom"
                    : "min-w-0 flex-1 text-pretty text-hp-body tabular-nums text-grey-deep",
              children: c,
            }),
          ],
        });
      },
      l = { A: 0, B: 1, C: 2, D: 3, E: 4, F: 5, 1: 0, 2: 1, 3: 2, 4: 3, 5: 4, 6: 5 };
    (e.s([], 279866),
      e.s(
        [
          "FunnelOptionGroupComponent",
          0,
          (e) => {
            let {
                kind: i,
                labelledBy: a,
                flow: o = "row",
                columns: c,
                rows: u = 1,
                layoutClassName: d,
                options: m,
                imageLabels: x,
                imageVariant: h,
                restClassNames: p,
                showBadge: b,
                align: f,
                density: E,
                selected: g,
                shouldFocusOnMount: v = !1,
                onSelect: _,
              } = e,
              [A, N] = (0, r.useState)(() => g ?? 0),
              j = (0, r.useRef)([]),
              L = (0, r.useCallback)((e) => {
                j.current[e]?.focus({ preventScroll: !0 });
              }, []);
            (0, r.useEffect)(() => {
              if (!v) return;
              let e = window.setTimeout(() => {
                j.current[0]?.focus({ preventScroll: !0 });
              }, 0);
              return () => {
                window.clearTimeout(e);
              };
            }, [v]);
            let y = (0, r.useCallback)(
                (e, t) => {
                  let r = m.length,
                    s = ((e % r) + r) % r;
                  (N(s), L(s), _(s, t));
                },
                [m.length, L, _],
              ),
              R = (0, r.useCallback)(
                (e) => {
                  let t = m.length,
                    r = "column" === o ? u : 1,
                    s = "column" === o ? 1 : c,
                    i = e.target.closest("[data-option-index]")?.getAttribute("data-option-index"),
                    a = null == i ? A : Number(i);
                  if ("ArrowRight" === e.key) {
                    (e.preventDefault(), y(a + r, !1));
                    return;
                  }
                  if ("ArrowLeft" === e.key) {
                    (e.preventDefault(), y(a - r, !1));
                    return;
                  }
                  if ("ArrowDown" === e.key) {
                    (e.preventDefault(), y(a + s, !1));
                    return;
                  }
                  if ("ArrowUp" === e.key) {
                    (e.preventDefault(), y(a - s, !1));
                    return;
                  }
                  if ("Home" === e.key) {
                    (e.preventDefault(), y(0, !1));
                    return;
                  }
                  if ("End" === e.key) {
                    (e.preventDefault(), y(t - 1, !1));
                    return;
                  }
                  if (e.repeat) return;
                  if ("Enter" === e.key || " " === e.key) {
                    (e.preventDefault(), y(a, !0));
                    return;
                  }
                  let n = l[e.key.toUpperCase()];
                  void 0 !== n && n < t && (e.preventDefault(), y(n, !0));
                },
                [m.length, o, u, c, A, y],
              ),
              D = g ?? A;
            return (0, t.jsx)("div", {
              role: "radiogroup",
              "aria-labelledby": a,
              "aria-required": "true",
              className: d,
              onKeyDown: R,
              children: m.map((e, r) =>
                (0, t.jsx)(
                  n,
                  {
                    restClassName: p?.[r],
                    kind: i,
                    imageVariant: h,
                    index: r,
                    letter: s.OPTION_KEYS[r],
                    label: "text" === i ? e : x?.[r],
                    src: "image" === i ? e : void 0,
                    showBadge: b,
                    align: f,
                    density: E,
                    isSelected: g === r,
                    tabIndex: D === r ? 0 : -1,
                    innerRef: (e) => {
                      j.current[r] = e;
                    },
                    onSelect: _,
                  },
                  `${r}-${e}`,
                ),
              ),
            });
          },
        ],
        899948,
      ));
  },
  507192,
  889572,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(271645);
    e.i(872756);
    var s = e.i(987132);
    (e.s([], 507192),
      e.s(
        [
          "FunnelStageComponent",
          0,
          (e) => {
            let { isLeaving: i = !1, scrollResetKey: a, children: n } = e,
              l = (0, r.useRef)(null);
            return (
              (0, r.useEffect)(() => {
                void 0 !== a && l.current?.scrollTo({ top: 0 });
              }, [a]),
              (0, t.jsx)("div", {
                ref: l,
                "data-leaving": i,
                className:
                  "flex min-h-0 flex-1 flex-col overflow-y-auto overscroll-contain transition-opacity duration-200 ease-[cubic-bezier(0.4,0,0.2,1)] data-[leaving=true]:opacity-0 motion-reduce:transition-none",
                children: (0, t.jsx)(s.DemoContainer, {
                  className: "mb-auto md:my-auto",
                  children: (0, t.jsx)("div", {
                    className: "w-full py-6 max-xs-sm:py-4 md:py-10",
                    children: n,
                  }),
                }),
              })
            );
          },
        ],
        889572,
      ));
  },
  922342,
  162278,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(369595);
    (e.s([], 922342),
      e.s(
        [
          "FunnelTokensComponent",
          0,
          (e) => {
            let { tokens: s, values: i, highlightClassName: a = "text-blue-custom" } = e;
            return (0, t.jsx)(t.Fragment, {
              children: s.map((e, s) => {
                if ("text" === e.kind)
                  return (0, t.jsx)("span", { children: (0, r.keepTrailingEmojiInline)(e.text) }, s);
                if ("highlight" === e.kind) return (0, t.jsx)("span", { className: a, children: e.text }, s);
                if ("flag" === e.kind)
                  return (0, t.jsx)(
                    "img",
                    {
                      src: e.src,
                      alt: e.alt,
                      width: e.width,
                      height: e.height,
                      className: "mb-1 inline-block h-5 w-[30px] rounded object-cover align-middle",
                    },
                    s,
                  );
                let n = `${i?.[e.value] ?? ""}${e.suffix ?? ""}`;
                return (0, t.jsx)("span", { className: e.isHighlighted ? a : void 0, children: n }, s);
              }),
            });
          },
        ],
        162278,
      ));
  },
  20362,
  (e) => {
    "use strict";
    e.s([
      "FUNNEL_CLOCK_PLACEHOLDER",
      0,
      "—",
      "FUNNEL_SEQUENCE_TICK_MS",
      0,
      1e3,
      "MEDIA_DESKTOP_UP",
      0,
      "(min-width: 1024px)",
      "MEDIA_REDUCED_MOTION",
      0,
      "(prefers-reduced-motion: reduce)",
      "OPTION_IMAGE_ROWS",
      0,
      3,
      "OPTION_KEYS",
      0,
      ["A", "B", "C", "D", "E", "F"],
      "ROUTE_HOME",
      0,
      "/demo-home",
    ]);
  },
  369595,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(271645);
    let s = /\s+(\p{Extended_Pictographic})️?$/u;
    e.s([
      "keepTrailingEmojiInline",
      0,
      (e) => {
        let i = function (e) {
          let i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
          if ("string" != typeof e) return e;
          let a = e.match(s);
          return a && void 0 !== a.index
            ? (0, t.jsxs)(
                r.Fragment,
                {
                  children: [
                    e.slice(0, a.index),
                    " ",
                    (0, t.jsx)("span", { className: "font-emoji", children: `${a[1]}️` }),
                  ],
                },
                `trailing-emoji-${i}`,
              )
            : e;
        };
        return Array.isArray(e) ? e.map(i) : i(e);
      },
    ]);
  },
]);
