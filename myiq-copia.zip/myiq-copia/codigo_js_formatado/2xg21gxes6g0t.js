(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  346238,
  (e) => {
    "use strict";
    var t = e.i(843476),
      s = e.i(730699),
      m = e.i(663615);
    e.s([
      "default",
      0,
      (e) => {
        let {
          appliedText: a,
          saveText: n,
          salePercent: r,
          isRtl: x,
          isAppliedTextLighter: i,
          idSuffix: l = "",
          isHairline: o,
        } = e;
        return (0, t.jsxs)("div", {
          id: `checkout-coupon-disclaimer${l}`,
          className: (0, m.cn)(
            "mb-5 mt-2 flex items-center justify-between gap-2 rounded-large border border-primary/20 bg-gradient-to-r from-blue-50 to-[#e0eaff] px-3 py-3",
            o && "max-sm:mb-2 max-sm:rounded-2xl max-sm:border-[#E8F2FD] max-sm:bg-none max-sm:px-4",
          ),
          children: [
            (0, t.jsxs)("div", {
              className: "flex items-center",
              children: [
                (0, t.jsx)(s.Gift, {
                  className: (0, m.cn)("inline h-6 w-6 shrink-0 text-primary", x ? "ml-3" : "mr-3"),
                }),
                (0, t.jsxs)("div", {
                  children: [
                    (0, t.jsx)("p", {
                      className: (0, m.cn)(
                        "text-start text-sm text-[#121620]",
                        i ? "font-medium" : "font-semibold",
                        o && "max-sm:font-medium max-sm:text-[#0D0D0D]",
                      ),
                      children: a,
                    }),
                    (0, t.jsx)("p", {
                      className: (0, m.cn)(
                        "text-start text-xs font-normal text-default-600",
                        o && "max-sm:text-[#5D5D5D]",
                      ),
                      children: n,
                    }),
                  ],
                }),
              ],
            }),
            (0, t.jsxs)("span", {
              className: (0, m.cn)(
                "inline-flex shrink-0 items-center gap-1.5 rounded-full bg-primary px-3 py-1 text-xs font-bold text-white shadow-sm",
                o &&
                  "max-sm:bg-transparent max-sm:px-0 max-sm:text-sm max-sm:font-semibold max-sm:tabular-nums max-sm:text-primary max-sm:shadow-none",
              ),
              children: ["−", r, "%"],
            }),
          ],
        });
      },
    ]);
  },
  202969,
  function (e) {
    e.n(e.i(346238));
  },
]);
