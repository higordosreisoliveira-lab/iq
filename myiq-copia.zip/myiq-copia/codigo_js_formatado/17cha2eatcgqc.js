(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  882983,
  (e) => {
    "use strict";
    var t = e.i(265840),
      a = e.i(271645),
      i = e.i(273830),
      s = e.i(620253),
      r = e.i(75540),
      l = e.i(843476),
      n = (0, i.forwardRef)((e, i) => {
        let { as: n, children: o, className: c, ...d } = e,
          { slots: m, classNames: u, bodyId: x, setBodyMounted: p } = (0, t.useModalContext)(),
          y = (0, s.useDOMRef)(i);
        return (
          (0, a.useEffect)(() => (p(!0), () => p(!1)), [p]),
          (0, l.jsx)(n || "div", {
            ref: y,
            className: m.body({ class: (0, r.clsx)(null == u ? void 0 : u.body, c) }),
            id: x,
            ...d,
            children: o,
          })
        );
      });
    ((n.displayName = "HeroUI.ModalBody"), e.s(["ModalBody", 0, n], 882983));
  },
  852306,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/2sniuzg0xcb_4.js"].map((t) => e.l(t))).then(() => t(373432)));
  },
  615993,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/1otd5qog52e4u.js"].map((t) => e.l(t))).then(() => t(380091)));
  },
  800320,
  (e) => {
    "use strict";
    var t = e.i(843476);
    let a = (0, e.i(475254).default)("tag", [
      [
        "path",
        {
          d: "M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z",
          key: "vktsd0",
        },
      ],
      ["circle", { cx: "7.5", cy: "7.5", r: ".5", fill: "currentColor", key: "kqv944" }],
    ]);
    var i = e.i(948148),
      s = e.i(271645),
      r = e.i(882983),
      l = e.i(742214),
      n = e.i(926654);
    e.i(185595);
    var o = e.i(266278),
      c = e.i(891133),
      d = e.i(263970),
      m = e.i(622963),
      u = e.i(86596),
      x = e.i(386847),
      p = e.i(725397);
    e.i(80460);
    var y = e.i(998198),
      h = e.i(202042);
    let f = (e) => (e < 10 ? `0${e}` : `${e}`);
    e.s(
      [
        "default",
        0,
        () => {
          let e = (0, m.useModalStore)((e) => e.modalProps),
            b = (0, m.useModalStore)((e) => e.handleChangeModalStore),
            g = (0, u.useUserStore)((e) => e.user),
            j = (0, i.useTranslations)(),
            P = (0, c.useIsUsA1Campaign)(),
            _ = (0, d.useGlobalStore)((e) => e.checkoutTimerMins),
            M = (0, d.useGlobalStore)((e) => e.checkoutTimerSeconds),
            k = (0, d.useGlobalStore)((e) => e.checkoutTimerExpired),
            v = (0, d.useGlobalStore)((e) => e.isPaymentFormExpanded),
            N = (0, h.usePathname)(),
            C = (0, s.useRef)(N),
            q = (0, s.useRef)(null);
          if (
            ((0, s.useEffect)(() => {
              N !== C.current && b({ isModalVisible: !1 });
            }, [N]),
            (0, s.useEffect)(() => {
              if (!v) return;
              let e = q.current;
              e && requestAnimationFrame(() => e.scrollIntoView({ behavior: "smooth", block: "start" }));
            }, [v]),
            !e)
          )
            return null;
          let { experiments: w, isMarketingSource: S, variant: E = "myiq", friendEncodedData: F } = e,
            { priceForView: R } = (0, y.getPaymentPlanPrice)({
              paymentPlan: w?.abMyiqAb100Vs199 === "v1_trial_1_99" || P ? "DEMO_PRICE_1_99" : "DEMO_PRICE",
              user: g,
            }),
            { priceForView: A } = (0, y.getPaymentPlanPrice)({ paymentPlan: "DEMO_PRICE_PREV", user: g }),
            I = !g?.paymentInfo?.paynextAmountToPay,
            T = w?.abMyiqPromoPrice === "promo_price" && S,
            V = k && !T && "personality" !== E,
            B = g?.currency?.countryCode === "US",
            O = (0, p.isUk)(g?.currency?.countryCode, (0, x.getClientCity)()),
            U = `${f(_)}:${f(M)}`,
            z = (0, y.getCalculatePriceForView)(A, g),
            D = parseFloat(g?.paymentInfo?.paynextAmountToPay?.replace(/[^0-9.]/g, "") ?? "0") || R,
            G = g?.paymentInfo?.paynextAmountToPay || (0, y.getCalculatePriceForView)(R, g),
            $ = parseInt((0, y.getSale)(A, R, !0), 10) || 0,
            H = (0, y.getCalculatePriceForView)(A - D, g);
          return (0, t.jsx)(l.ModalContent, {
            className: "!m-0 flex flex-col overflow-hidden rounded-2xl bg-white",
            children: (0, t.jsxs)(r.ModalBody, {
              className: "flex flex-col gap-2.5 px-5 pb-5 pt-3 sm:px-6",
              children: [
                (0, t.jsx)("div", { ref: q, "aria-hidden": !0, className: "-mt-3 h-1 shrink-0" }),
                (0, t.jsx)("h2", {
                  className:
                    "flex min-h-8 items-center justify-center px-8 text-center text-[18px] font-semibold leading-tight tracking-tight text-gray-900",
                  children: j("checkout_modal_payment_title"),
                }),
                !V &&
                  (0, t.jsxs)("div", {
                    className:
                      "flex items-center justify-between rounded-large border border-primary/20 bg-primary/[0.08] px-3.5 py-3",
                    children: [
                      (0, t.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                          (0, t.jsx)(a, { className: "mr-2.5 inline h-5 w-5 text-primary" }),
                          (0, t.jsx)("p", {
                            className: "text-[13px] font-medium text-[#121620]",
                            children: j("checkout_v2_discount_expires_in"),
                          }),
                        ],
                      }),
                      (0, t.jsx)("span", {
                        className: "text-[13px] font-bold tabular-nums text-primary",
                        children: U,
                      }),
                    ],
                  }),
                I
                  ? (0, t.jsx)(n.Skeleton, { className: "h-[110px] w-full rounded-large" })
                  : (0, t.jsxs)("div", {
                      className: "flex flex-col gap-2 rounded-large bg-default-100 p-3",
                      children: [
                        !V &&
                          (0, t.jsxs)("div", {
                            className: "flex items-center justify-between gap-3",
                            children: [
                              (0, t.jsx)("span", {
                                className: "text-[13px] font-bold text-gray-900",
                                children: j("checkout_modal_payment_product_name"),
                              }),
                              (0, t.jsx)("span", {
                                className: "text-[13px] text-[#747475] line-through",
                                children: z,
                              }),
                            ],
                          }),
                        !V &&
                          $ > 0 &&
                          (0, t.jsxs)(t.Fragment, {
                            children: [
                              (0, t.jsxs)("div", {
                                className: "flex items-center justify-between gap-3",
                                children: [
                                  (0, t.jsx)("span", {
                                    className: "flex items-center gap-1.5 text-[13px] text-default-600",
                                    children: j.rich("checkout_modal_payment_promo_applied", {
                                      sale: String($),
                                      code: (e) =>
                                        (0, t.jsx)("span", {
                                          className:
                                            "inline-flex items-center rounded bg-primary/10 px-1.5 py-px font-mono text-[10px] font-bold tracking-wider text-primary",
                                          children: e,
                                        }),
                                    }),
                                  }),
                                  (0, t.jsxs)("span", {
                                    className: "text-[13px] font-semibold text-primary",
                                    children: ["−", H],
                                  }),
                                ],
                              }),
                              (0, t.jsx)("div", { className: "h-px bg-gray-200" }),
                            ],
                          }),
                        (0, t.jsxs)("div", {
                          className: "flex items-center justify-between gap-3",
                          children: [
                            (0, t.jsxs)("span", {
                              className: "text-[13px] font-bold text-gray-900",
                              children: [
                                j(B || O ? "checkout_page_total_due" : "checkout_page_due_today"),
                                ":",
                              ],
                            }),
                            (0, t.jsx)("span", {
                              className: "text-[15px] font-bold text-black",
                              children: G,
                            }),
                          ],
                        }),
                      ],
                    }),
                (0, t.jsx)("div", {
                  className: "[&>*]:!mt-0",
                  children: (0, t.jsx)(o.CheckoutFormSectionComponent, {
                    variant: E,
                    user: g,
                    isMarketingSource: S,
                    friendEncodedData: F,
                    abMyiqPromoPrice: w?.abMyiqPromoPrice,
                    abMyiqAb100Vs199: w?.abMyiqAb100Vs199,
                    abMyiqRevolutMonzoBlock: w?.abMyiqRevolutMonzoBlock,
                    abMyiqBrazilMastercardOnly: w?.abMyiqBrazilMastercardOnly,
                    abMyiqProductFeedbackWidget: w?.abMyiqProductFeedbackWidget,
                    containerId: "checkout-modal-container",
                  }),
                }),
              ],
            }),
          });
        },
      ],
      800320,
    );
  },
  506184,
  function (e) {
    e.n(e.i(800320));
  },
  963075,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/3-0_kq2g74b8i.js"].map((t) => e.l(t))).then(() => t(149278)));
  },
]);
