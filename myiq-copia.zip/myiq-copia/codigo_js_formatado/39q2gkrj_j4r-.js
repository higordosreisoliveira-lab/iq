(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  882983,
  (e) => {
    "use strict";
    var t = e.i(265840),
      i = e.i(271645),
      s = e.i(273830),
      l = e.i(620253),
      a = e.i(75540),
      r = e.i(843476),
      d = (0, s.forwardRef)((e, s) => {
        let { as: d, children: _, className: n, ...o } = e,
          { slots: c, classNames: p, bodyId: m, setBodyMounted: u } = (0, t.useModalContext)(),
          x = (0, l.useDOMRef)(s);
        return (
          (0, i.useEffect)(() => (u(!0), () => u(!1)), [u]),
          (0, r.jsx)(d || "div", {
            ref: x,
            className: c.body({ class: (0, a.clsx)(null == p ? void 0 : p.body, n) }),
            id: m,
            ...o,
            children: _,
          })
        );
      });
    ((d.displayName = "HeroUI.ModalBody"), e.s(["ModalBody", 0, d], 882983));
  },
  949411,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("clock", [
      ["path", { d: "M12 6v6l4 2", key: "mmk7yg" }],
      ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
    ]);
    e.s(["default", 0, t]);
  },
  531447,
  (e) => {
    "use strict";
    var t = e.i(949411);
    e.s(["ClockIcon", () => t.default]);
  },
  935832,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("gift", [
      ["rect", { x: "3", y: "8", width: "18", height: "4", rx: "1", key: "bkv52" }],
      ["path", { d: "M12 8v13", key: "1c76mn" }],
      ["path", { d: "M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7", key: "6wjy6b" }],
      [
        "path",
        { d: "M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5", key: "1ihvrl" },
      ],
    ]);
    e.s(["default", 0, t]);
  },
  914299,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("heart", [
      [
        "path",
        {
          d: "M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5",
          key: "mvr1a0",
        },
      ],
    ]);
    e.s(["default", 0, t]);
  },
  293625,
  (e) => {
    "use strict";
    var t = e.i(914299);
    e.s(["HeartIcon", () => t.default]);
  },
  661263,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("split", [
      ["path", { d: "M16 3h5v5", key: "1806ms" }],
      ["path", { d: "M8 3H3v5", key: "15dfkv" }],
      ["path", { d: "M12 22v-8.3a4 4 0 0 0-1.172-2.872L3 3", key: "1qrqzj" }],
      ["path", { d: "m15 9 6-6", key: "ko1vev" }],
    ]);
    e.s(["Split", 0, t], 661263);
  },
  540600,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(948148),
      s = e.i(271645);
    e.i(317197);
    var l = e.i(231529),
      a = e.i(265832),
      r = e.i(622963);
    e.i(568267);
    var d = e.i(154692);
    let _ = () => {
      let e = (0, i.useTranslations)(),
        s = (0, r.useModalStore)((e) => e.handleChangeModalStore);
      return (0, t.jsx)(d.ButtonComponent, {
        onClick: () => {
          s({ isModalVisible: !1, modalComponent: null });
        },
        fullWidth: !0,
        size: "sm",
        children: e("btn_got_it"),
      });
    };
    var n = e.i(935832),
      n = n,
      o = e.i(531447),
      c = e.i(293625),
      p = e.i(661263);
    let m = (e) => {
        let { powerUp: i, timeUp: s, cutOff: l, size: a = "medium" } = e,
          r = "small" === a ? "h-3 w-3" : "h-5 w-5",
          d = "small" === a ? "min-w-9 text-xs" : "text-sm";
        return "small" === a
          ? (0, t.jsxs)(t.Fragment, {
              children: [
                (0, t.jsxs)("span", {
                  className: `text-muted-foreground flex items-center justify-end gap-1 ${d}`,
                  children: [
                    "+",
                    i,
                    " ",
                    (0, t.jsx)(c.HeartIcon, { className: `${r} fill-rose-600 text-rose-600` }),
                  ],
                }),
                s
                  ? (0, t.jsxs)("span", {
                      className: `text-muted-foreground flex items-center justify-end gap-1 ${d}`,
                      children: ["+", s, " ", (0, t.jsx)(o.ClockIcon, { className: `${r} text-blue-600` })],
                    })
                  : (0, t.jsxs)("span", {
                      className: `text-muted-foreground hidden items-center justify-end gap-1 ${d}`,
                      children: ["+", s, " ", (0, t.jsx)(o.ClockIcon, { className: `${r} text-blue-600` })],
                    }),
                l
                  ? (0, t.jsxs)("span", {
                      className: `text-muted-foreground flex items-center justify-end gap-1 ${d}`,
                      children: ["+", l, " ", (0, t.jsx)(p.Split, { className: `${r} text-amber-500` })],
                    })
                  : (0, t.jsxs)("span", {
                      className: `text-muted-foreground hidden items-center justify-end gap-1 ${d}`,
                      children: ["+", l, " ", (0, t.jsx)(p.Split, { className: `${r} text-amber-500` })],
                    }),
              ],
            })
          : (0, t.jsxs)(t.Fragment, {
              children: [
                i && i > 0
                  ? (0, t.jsxs)("span", {
                      className: `flex items-center justify-center gap-1 rounded-lg py-1.5 ${d}`,
                      children: [
                        (0, t.jsx)(c.HeartIcon, { className: `${r} fill-rose-600 text-rose-600` }),
                        (0, t.jsxs)("span", { children: ["+", i] }),
                      ],
                    })
                  : null,
                s && s > 0
                  ? (0, t.jsxs)("span", {
                      className: `flex items-center justify-center gap-1 rounded-lg py-1.5 ${d}`,
                      children: [
                        (0, t.jsx)(o.ClockIcon, { className: `${r} text-blue-600` }),
                        (0, t.jsxs)("span", { children: ["+", s] }),
                      ],
                    })
                  : null,
                l && l > 0
                  ? (0, t.jsxs)("span", {
                      className: `flex items-center justify-center gap-1 rounded-lg py-1.5 ${d}`,
                      children: [
                        (0, t.jsx)(p.Split, { className: `${r} text-amber-500` }),
                        (0, t.jsxs)("span", { children: ["+", l] }),
                      ],
                    })
                  : null,
              ],
            });
      },
      u = (e) => {
        let { nextRewardXP: s, displayXP: l, remainingXP: a, gridColsClass: r } = e,
          d = (0, i.useTranslations)();
        return s
          ? (0, t.jsxs)("div", {
              className: "mb-5 rounded-xl border bg-slate-50 p-2 sm:p-4",
              children: [
                (0, t.jsxs)("div", {
                  className: "mb-3 flex items-center gap-3",
                  children: [
                    (0, t.jsx)(n.default, { className: "h-6 w-6 text-blue-500" }),
                    (0, t.jsxs)("div", {
                      className: "flex-1",
                      children: [
                        (0, t.jsx)("p", {
                          className: "text-sm font-semibold",
                          children: d("trivia_xp_bonus_modal_next_reward"),
                        }),
                        (0, t.jsx)("p", {
                          className: "text-muted-foreground text-xs",
                          children: d("trivia_xp_bonus_modal_xp_remaining", { count: String(a) }),
                        }),
                      ],
                    }),
                    (0, t.jsx)("span", {
                      className: "font-bold text-blue-600",
                      children: d("trivia_xp_bonus_modal_xp_amount", { amount: String(s?.xp || 0) }),
                    }),
                  ],
                }),
                (0, t.jsx)("div", {
                  className: "mb-4 flex items-center gap-3",
                  children: (0, t.jsx)("div", {
                    className: "relative h-1.5 flex-1 overflow-hidden rounded-full bg-gray-200",
                    children: (0, t.jsx)("div", {
                      className: "absolute bottom-0 top-0 bg-primary transition-all duration-500 ease-out",
                      style: { width: `${(l / s.xp) * 100}%` },
                    }),
                  }),
                }),
                (0, t.jsx)("div", {
                  className: `mt-3 grid ${r} gap-2`,
                  children: (0, t.jsx)(m, {
                    powerUp: s.powerUp,
                    timeUp: s.timeUp,
                    cutOff: s.cutOff,
                    size: "medium",
                  }),
                }),
              ],
            })
          : null;
      };
    var x = e.i(663615);
    let f = (e) => {
      let { displayXP: s } = e,
        l = (0, i.useTranslations)();
      return (0, t.jsx)("div", {
        className:
          "mb-5 h-[25vh] max-h-[25vh] overflow-y-auto pr-1 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-gray-400 [&::-webkit-scrollbar-track]:rounded-full [&::-webkit-scrollbar-track]:bg-gray-200 [&::-webkit-scrollbar]:[width:6px] [@media(max-height:600px)]:h-[20vh]",
        children: a.XP_BOOST_CONFIG.map((e) => {
          let i = s >= e.xp;
          return (0, t.jsxs)(
            "div",
            {
              className: (0, x.cn)(
                "grid grid-cols-[25%_30%_1fr] items-center justify-between border-b border-b-gray-200 p-2 xs-base:grid-cols-[20%_30%_1fr] xs-base:px-3 md:grid-cols-[30%_30%_1fr]",
                i ? "bg-blue-50 opacity-40" : "",
              ),
              children: [
                (0, t.jsx)("div", {
                  className: "text-[12px] text-gray-900",
                  children: l("level_up_modal_level", { number: String(e.id) }),
                }),
                (0, t.jsx)("div", {
                  className: "flex items-center justify-center",
                  children: (0, t.jsx)("span", {
                    className: "text-[12px]",
                    children: l("trivia_xp_bonus_modal_xp_amount", { amount: String(e.xp) }),
                  }),
                }),
                (0, t.jsx)("div", {
                  className: "flex justify-end gap-2",
                  children: (0, t.jsx)(m, {
                    powerUp: e.powerUp,
                    timeUp: e.timeUp,
                    cutOff: e.cutOff,
                    size: "small",
                  }),
                }),
              ],
            },
            e.xp,
          );
        }),
      });
    };
    e.s(
      [
        "default",
        0,
        (e) => {
          let { displayXP: r } = e,
            d = (0, i.useTranslations)(),
            n = a.XP_BOOST_CONFIG.find((e) => e.xp > r),
            o = n ? n.xp - r : 0,
            c = (0, s.useMemo)(() => {
              if (!n) return 0;
              let e = 0;
              return (
                n.powerUp && n.powerUp > 0 && e++,
                n.timeUp && n.timeUp > 0 && e++,
                n.cutOff && n.cutOff > 0 && e++,
                e
              );
            }, [n]);
          return (0, t.jsx)(l.ModalBodyComponent, {
            title: d("trivia_xp_bonus_modal_title"),
            subtitle: d("trivia_xp_bonus_modal_description"),
            children: (0, t.jsxs)("div", {
              children: [
                (0, t.jsx)(u, {
                  nextRewardXP: n || null,
                  displayXP: r,
                  remainingXP: o,
                  gridColsClass: 1 === c ? "grid-cols-1" : 2 === c ? "grid-cols-2" : "grid-cols-3",
                }),
                (0, t.jsx)(f, { displayXP: r }),
                (0, t.jsx)(_, {}),
              ],
            }),
          });
        },
      ],
      540600,
    );
  },
  617740,
  function (e) {
    e.n(e.i(540600));
  },
  317197,
  231529,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(882983),
      s = e.i(742214),
      l = e.i(663615);
    e.i(680460);
    var a = e.i(885944);
    (e.s([], 317197),
      e.s(
        [
          "ModalBodyComponent",
          0,
          (e) => {
            let {
              children: r,
              title: d,
              subtitle: _,
              className: n = "",
              bodyClassName: o,
              titleClassName: c,
            } = e;
            return (0, t.jsx)(s.ModalContent, {
              className: n,
              children: (0, t.jsxs)(i.ModalBody, {
                className: (0, l.cn)(
                  "flex h-full w-full flex-col gap-5 p-5 antialiased md:p-6 [@media(max-height:580px)]:gap-3 [@media(max-height:580px)]:p-4",
                  o,
                ),
                children: [
                  (d || _) &&
                    (0, t.jsx)(a.ModalHeaderComponent, { title: d, subtitle: _, titleClassName: c }),
                  r,
                ],
              }),
            });
          },
        ],
        231529,
      ));
  },
  265832,
  (e) => {
    "use strict";
    e.s([
      "ANIMATION_CONFIG",
      0,
      { COIN_ANIMATION_DURATION: 1200, MIN_INTERVAL_DURATION: 16, NOTIFICATION_DELAY: 1200 },
      "AVERAGE_TIME_FOR_SKILL_BOOST",
      0,
      8e3,
      "DAILY_FULL_COMPLETION_KEYS",
      0,
      [
        "trivia_daily_full_0",
        "trivia_daily_full_1",
        "trivia_daily_full_2",
        "trivia_daily_full_3",
        "trivia_daily_full_4",
        "trivia_daily_full_5",
        "trivia_daily_full_6",
        "trivia_daily_full_7",
      ],
      "DAILY_NOT_FULL_COMPLETION_KEYS",
      0,
      [
        "trivia_daily_more_0",
        "trivia_daily_more_1",
        "trivia_daily_more_2",
        "trivia_daily_more_3",
        "trivia_daily_more_4",
        "trivia_daily_more_5",
        "trivia_daily_more_6",
        "trivia_daily_more_7",
      ],
      "DAILY_PROGRESS_SETS",
      0,
      5,
      "HEARTS_CONFIG",
      0,
      {
        INITIAL_HEARTS: 3,
        PURCHASED_HEARTS: 5,
        HEARTS_LOSS_PER_WRONG_ANSWER: 1,
        HEARTS_ANIMATION_DELAY: 700,
        HEARTS_ANIMATION_DURATION: 600,
      },
      "LEVEL_COMPLETED_BONUS",
      0,
      10,
      "MOVE_TO_TEST_COMPLETION_DELAY",
      0,
      400,
      "PLAY_COIN_REWARD_SOUND_AFTER_DELAY",
      0,
      500,
      "POWER_UPS_CONFIG",
      0,
      { INITIAL_FIFTY_FIFTY_USES: 3, INITIAL_EXTRA_TIME_USES: 3, EXTRA_TIME_SECONDS: 30, REFILL_TIME: 18e5 },
      "SKILL_BOOST_SCORE",
      0,
      0.3,
      "STREAK_BONUS_XP",
      0,
      { STREAK_3: 10, STREAK_5: 20, STREAK_10: 50 },
      "STREAK_MILESTONES",
      0,
      { STREAK_3: 3, STREAK_5: 5, STREAK_10: 10 },
      "TIMER_DURATION",
      0,
      20,
      "TIME_UNTIL_NEXT_TEST",
      0,
      18e5,
      "TRIVIA_COMPLETE_SCREEN_SUBTITLE_KEYS",
      0,
      [
        "trivia_complete_subtitle_0",
        "trivia_complete_subtitle_1",
        "trivia_complete_subtitle_2",
        "trivia_complete_subtitle_3",
        "trivia_complete_subtitle_4",
        "trivia_complete_subtitle_5",
        "trivia_complete_subtitle_6",
        "trivia_complete_subtitle_7",
      ],
      "XP_BOOST_CONFIG",
      0,
      [
        { id: 1, xp: 90, powerUp: 2, timeUp: 0, cutOff: 0 },
        { id: 2, xp: 200, powerUp: 3, timeUp: 1, cutOff: 0 },
        { id: 3, xp: 450, powerUp: 4, timeUp: 1, cutOff: 1 },
        { id: 4, xp: 800, powerUp: 5, timeUp: 2, cutOff: 1 },
        { id: 5, xp: 1400, powerUp: 7, timeUp: 3, cutOff: 2 },
        { id: 6, xp: 2200, powerUp: 10, timeUp: 4, cutOff: 3 },
        { id: 7, xp: 3200, powerUp: 12, timeUp: 5, cutOff: 4 },
        { id: 8, xp: 4500, powerUp: 15, timeUp: 6, cutOff: 5 },
        { id: 9, xp: 6500, powerUp: 18, timeUp: 8, cutOff: 6 },
        { id: 10, xp: 9e3, powerUp: 22, timeUp: 10, cutOff: 8 },
        { id: 11, xp: 13e3, powerUp: 27, timeUp: 12, cutOff: 10 },
        { id: 12, xp: 18e3, powerUp: 35, timeUp: 15, cutOff: 12 },
      ],
      "XP_PER_CORRECT_ANSWER",
      0,
      10,
    ]);
  },
]);
