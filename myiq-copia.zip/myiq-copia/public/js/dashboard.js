// Member Area & Results Dashboard Controller for myIQ
document.addEventListener("DOMContentLoaded", () => {
  const isDashboard = document.getElementById("dashboard-view");
  if (!isDashboard) return;

  // Retrieve score and domains from localStorage or default
  let result = {
    score: 128,
    percentile: 96.8,
    correctCount: 34,
    totalQuestions: 40,
    domains: {
      fluid: 131,
      visual: 125,
      memory: 129,
      pattern: 133,
      logic: 126
    },
    completedAt: new Date().toISOString()
  };

  const savedResult = localStorage.getItem("myiq_test_result");
  if (savedResult) {
    try {
      result = JSON.parse(savedResult);
    } catch (e) {}
  }

  // Update Score Elements
  const mainScoreEl = document.getElementById("report-main-score");
  const percentileEl = document.getElementById("report-percentile");
  const accuracyEl = document.getElementById("report-accuracy");
  const classificationEl = document.getElementById("report-classification");

  if (mainScoreEl) mainScoreEl.textContent = result.score;
  if (percentileEl) percentileEl.textContent = `${result.percentile}%`;
  if (accuracyEl) accuracyEl.textContent = `${result.correctCount}/${result.totalQuestions}`;

  let classification = "Superior Intelligence";
  if (result.score >= 130) classification = "Very Superior / Gifted";
  else if (result.score >= 120) classification = "Superior Intelligence";
  else if (result.score >= 110) classification = "High Average Intelligence";
  else if (result.score >= 90) classification = "Average Intelligence";

  if (classificationEl) classificationEl.textContent = classification;

  // Update Domain Sliders & Values
  const domainMapping = [
    { id: "fluid", key: "fluid" },
    { id: "visual", key: "visual" },
    { id: "memory", key: "memory" },
    { id: "pattern", key: "pattern" },
    { id: "logic", key: "logic" }
  ];

  domainMapping.forEach(d => {
    const scoreVal = result.domains[d.key] || result.score;
    const valEl = document.getElementById(`val-${d.id}`);
    const barEl = document.getElementById(`bar-${d.id}`);
    if (valEl) valEl.textContent = scoreVal;
    if (barEl) {
      const pct = Math.min(100, Math.max(20, Math.round(((scoreVal - 70) / 80) * 100)));
      barEl.style.width = `${pct}%`;
    }
  });

  // Certificate customization
  const certNameInput = document.getElementById("cert-name-input");
  const certNameDisplay = document.getElementById("cert-display-name");
  const certScoreDisplay = document.getElementById("cert-display-score");
  const certDateDisplay = document.getElementById("cert-display-date");
  const certCodeDisplay = document.getElementById("cert-display-code");

  if (certScoreDisplay) certScoreDisplay.textContent = result.score;
  if (certDateDisplay) certDateDisplay.textContent = new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });
  if (certCodeDisplay) certCodeDisplay.textContent = `IQ-${Math.floor(100000 + Math.random() * 900000)}`;

  if (certNameInput && certNameDisplay) {
    certNameInput.addEventListener("input", (e) => {
      certNameDisplay.textContent = e.target.value.trim() || "John Doe";
    });
  }

  // Print / Save Certificate button
  const printBtn = document.getElementById("btn-print-certificate");
  if (printBtn) {
    printBtn.addEventListener("click", () => {
      window.print();
    });
  }

  // Mini Brain Training Game (Memory Matrix)
  initMiniBrainGame();
});

function initMiniBrainGame() {
  const gameGrid = document.getElementById("brain-game-grid");
  const startBtn = document.getElementById("start-brain-game");
  const scoreDisplay = document.getElementById("brain-game-score");
  if (!gameGrid || !startBtn) return;

  let score = 0;
  let highlightedCells = [];
  let userClickedCells = [];
  let isDisplayPhase = false;

  function generateRound() {
    highlightedCells = [];
    userClickedCells = [];
    isDisplayPhase = true;
    
    // Choose 3 random cells out of 9
    while (highlightedCells.length < 3) {
      const r = Math.floor(Math.random() * 9);
      if (!highlightedCells.includes(r)) highlightedCells.push(r);
    }

    renderGameCells(true);

    setTimeout(() => {
      isDisplayPhase = false;
      renderGameCells(false);
    }, 1200);
  }

  function renderGameCells(showHighlight) {
    gameGrid.innerHTML = '';
    for (let i = 0; i < 9; i++) {
      const cell = document.createElement("div");
      const isTarget = highlightedCells.includes(i);
      const isClicked = userClickedCells.includes(i);

      cell.className = `aspect-square rounded-xl flex items-center justify-center font-bold text-xl cursor-pointer transition-all ${
        showHighlight && isTarget 
          ? 'bg-blue-custom shadow-lg scale-95' 
          : isClicked && isTarget
            ? 'bg-green-custom text-white'
            : isClicked && !isTarget
              ? 'bg-red-500 text-white'
              : 'bg-slate-100 hover:bg-slate-200'
      }`;

      cell.addEventListener("click", () => {
        if (isDisplayPhase || userClickedCells.includes(i)) return;
        userClickedCells.push(i);
        if (isTarget) {
          cell.classList.remove("bg-slate-100");
          cell.classList.add("bg-green-custom", "text-white");
          if (userClickedCells.filter(c => highlightedCells.includes(c)).length === highlightedCells.length) {
            score += 10;
            if (scoreDisplay) scoreDisplay.textContent = `Score: ${score}`;
            setTimeout(generateRound, 600);
          }
        } else {
          cell.classList.remove("bg-slate-100");
          cell.classList.add("bg-red-500", "text-white");
          alert("Missed! Try next round!");
          setTimeout(generateRound, 800);
        }
      });

      gameGrid.appendChild(cell);
    }
  }

  startBtn.addEventListener("click", () => {
    score = 0;
    if (scoreDisplay) scoreDisplay.textContent = `Score: ${score}`;
    startBtn.textContent = "Restart Drill";
    generateRound();
  });
}
