(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  660678,
  (e) => {
    "use strict";
    var t = e.i(271645),
      s = e.i(372775),
      n = e.i(912598);
    e.s([
      "HydrationBoundary",
      0,
      (e) => {
        let { children: r, options: a = {}, state: i, queryClient: l } = e,
          o = (0, n.useQueryClient)(l),
          c = t.useRef(a);
        c.current = a;
        let u = t.useMemo(() => {
          if (i) {
            if ("object" != typeof i) return;
            let e = o.getQueryCache(),
              t = i.queries || [],
              n = [],
              r = [];
            for (let s of t) {
              let t = e.get(s.queryHash);
              t
                ? (s.state.dataUpdatedAt > t.state.dataUpdatedAt ||
                    (s.promise &&
                      "pending" !== t.state.status &&
                      "fetching" !== t.state.fetchStatus &&
                      void 0 !== s.dehydratedAt &&
                      s.dehydratedAt > t.state.dataUpdatedAt)) &&
                  r.push(s)
                : n.push(s);
            }
            if ((n.length > 0 && (0, s.hydrate)(o, { queries: n }, c.current), r.length > 0)) return r;
          }
        }, [o, i]);
        return (
          t.useEffect(() => {
            u && (0, s.hydrate)(o, { queries: u }, c.current);
          }, [o, u]),
          r
        );
      },
    ]);
  },
  861152,
  (e) => {
    "use strict";
    let t = [
        "bg-[#d0e8d8] data-[pressed=true]:!bg-[#a0c6a8]",
        "bg-[#FDF5D8] data-[pressed=true]:!bg-[#F6EBC2]",
        "bg-[#f5d6d6] data-[pressed=true]:!bg-[#e0bcbc]",
      ],
      s = [
        "bg-[#d0e8d8] data-[pressed=true]:!bg-[#a0c6a8]",
        "bg-correct-bg data-[pressed=true]:!bg-correct-border",
        "bg-[#FDF5D8] data-[pressed=true]:!bg-[#F6EBC2]",
        "bg-[#f8e6e6] data-[pressed=true]:!bg-[#e4c8c8]",
        "bg-[#f5d6d6] data-[pressed=true]:!bg-[#e0bcbc]",
      ];
    e.s([
      "getButtonClasses",
      0,
      (e) => {
        let { answerIdx: n, answersLength: r } = e;
        return (3 === r ? t : s)[n] ?? "";
      },
      "isAdditionalQuestion",
      0,
      (e, t, s) => "personality" === t && e >= (s || 93) - 3,
    ]);
  },
  841977,
  (e) => {
    "use strict";
    e.s([
      "BONUS_POINTS",
      0,
      { under_ten: 5, under_seven: 7, under_five: 10 },
      "CORRECT_ANSWER_MIN_COUNT",
      0,
      15,
      "EASY_QUESTION_POINTS",
      0,
      0.87,
      "FIVE_MINUTES",
      0,
      300,
      "FOUR_MINUTES",
      0,
      240,
      "HARD_QUESTION_POINTS",
      0,
      1.12,
      "MINIMAL_IQ_SCORE",
      0,
      105,
      "MINUTE_SECONDS",
      0,
      60,
      "SEVEN_MINUTES",
      0,
      420,
      "TEN_MINUTES",
      0,
      600,
      "WARNING_THRESHOLD",
      0,
      10,
    ]);
  },
  706152,
  907139,
  415858,
  446454,
  (e) => {
    "use strict";
    var t = e.i(843476),
      s = e.i(663615);
    e.i(165037);
    var n = e.i(856095);
    (e.s([], 706152),
      e.s(
        [
          "ProgressComponent",
          0,
          (e) => {
            let { currentQuestionId: r, questionLength: a, className: i, isInsidePagination: l } = e,
              o = (0, n.getProgressPercentage)(r, a);
            return (0, t.jsx)("div", {
              className: (0, s.cn)(
                "h-1 w-full overflow-hidden bg-[#e9e9ea]",
                l ? "relative !top-0 -mt-[5px]" : "fixed left-0 top-[61px] z-50",
                "top-[61px]",
                i,
              ),
              children: (0, t.jsx)("div", {
                className:
                  "h-1 w-full origin-left bg-teal-700 transition-transform duration-300 ease-out rtl:origin-right",
                style: { transform: `scaleX(${o / 100})`, willChange: "transform" },
              }),
            });
          },
        ],
        907139,
      ));
    var r = e.i(271645);
    e.i(7028);
    var a = e.i(468749),
      i = e.i(948148),
      l = e.i(335889),
      o = e.i(520837);
    e.i(381069);
    var c = e.i(468387),
      u = e.i(356037),
      m = e.i(803786);
    e.i(568267);
    var d = e.i(154692);
    let x = (e) => {
      let {
          question: a,
          showResultButton: x,
          handleFinishQuiz: p,
          handleSelectOption: g,
          selectedOption: h,
          isLoading: f,
          className: _,
          isAdditionalTest: w,
          buttonResultsText: b,
          useRetakeQuestions: N,
          abMyiqQuizChaosBlockQ1122: v,
          abMyiqQuizHintAssistCount: E,
          abMyiqQuizFewerOptions: S,
        } = e,
        y = "v3_increased_image_size" === S,
        A = (0, i.useTranslations)();
      (0, r.useEffect)(() => {
        x && (0, n.scrollToBottom)();
      }, [x]);
      let j = (0, r.useMemo)(
          () => (a?.icons?.options ?? []).map((e) => Object.keys(e).find((e) => 1 === e.length)),
          [a?.icons?.options],
        ),
        {
          isHintControlVisible: I,
          hintsLeft: z,
          poolSize: q,
          eliminatedOptions: O,
          handleActivateHint: C,
        } = (0, m.useHintAssist)({
          variant: E,
          isEligible: !!a?.correctAnswer,
          questionId: a?.id ?? 0,
          hasSelectedOption: !!h,
          isSequenceHidden: !0,
          options: j,
          correctOption: a?.correctAnswer,
        });
      return (0, t.jsxs)("div", {
        className: (0, s.cn)("grid lg:grid-cols-2 lg:gap-11 lg:px-5", _),
        children: [
          (0, t.jsx)(o.Card, {
            "data-cy": "question_image",
            className: (0, s.cn)(
              "relative mx-auto w-full max-w-[343px] lg:max-w-[464px]",
              a?.icons?.layout === "stack"
                ? "aspect-auto"
                : "aspect-[49/37] max-xs-sm:aspect-[3/2] max-xs-sm:max-h-[160px]",
              "[&_img]:h-full [&_img]:w-full [&_img]:object-contain [&_svg]:h-full [&_svg]:w-full [&_svg]:object-fill",
              y && "max-w-[464px]",
            ),
            children: a?.icons?.question,
          }),
          (0, t.jsxs)("div", {
            className: (0, s.cn)("flex basis-full flex-col gap-1 px-0 pt-0 text-center lg:basis-6/12"),
            children: [
              (0, t.jsx)("p", {
                className:
                  "dark:text-foreground-700 lg:text-md mb-2 mt-4 select-none px-5 text-center max-xs-sm:mb-1 max-xs-sm:mt-2 lg:mt-0",
                children: A(
                  "v3_disperse_taskline" === v
                    ? "quiz_page_ab_myiq_chaos_block_task_heading"
                    : "quiz_choose_answer",
                ),
              }),
              (0, t.jsx)("div", {
                className: (0, s.cn)(
                  "grid gap-3 px-1 max-xs-sm:gap-2 sm:px-5 lg:px-0",
                  a?.icons?.layout === "stack"
                    ? "grid-flow-row grid-cols-1"
                    : a?.icons?.options?.length === 4
                      ? "grid-flow-col grid-rows-2 lg:grid-rows-2"
                      : "grow grid-flow-col grid-rows-3 lg:grid-rows-3",
                ),
                children: a?.icons?.options?.map((e) => {
                  let n = Object.keys(e).find((e) => 1 === e.length),
                    r = O.includes(n),
                    i = a?.icons?.layout === "stack";
                  return (0, t.jsx)(
                    l.Button,
                    {
                      name: "answer_btn",
                      disableRipple: !0,
                      isDisabled: r,
                      "data-nr": "answer_btn",
                      onPress: () => g(n),
                      "aria-label": `question-${n}`,
                      className: (0, s.cn)(
                        i
                          ? "h-[58px] w-full justify-start text-wrap rounded-xl bg-correct-bg p-6 text-start text-base font-medium text-dark-custom max-xs-sm:h-[48px] max-xs-sm:p-4 max-xs-sm:text-sm"
                          : (0, s.cn)(
                              "min-w-unit-16 relative flex min-h-[4rem] w-full items-center justify-center overflow-visible rounded-large",
                              "border border-transparent",
                              "max-xs-sm:min-h-[3.25rem]",
                              "lg:h-[97px]",
                              N
                                ? "[&_img]:h-full [&_img]:w-full [&_img]:object-fill [&_svg]:h-full [&_svg]:w-full [&_svg]:object-fill"
                                : "[&_img]:h-[40px] [&_img]:w-[56px] [&_img]:max-w-none max-xs-sm:[&_img]:h-[32px] max-xs-sm:[&_img]:w-[44px] [&_svg]:h-[40px] [&_svg]:w-[56px] [&_svg]:max-w-none max-xs-sm:[&_svg]:h-[32px] max-xs-sm:[&_svg]:w-[44px]",
                              y &&
                                !N &&
                                "min-h-[5rem] max-xs-sm:min-h-[3.25rem] md:h-[7rem] lg:h-[6rem] [&_img]:h-[48px] [&_img]:w-auto max-xs-sm:[&_img]:h-[32px] md:[&_img]:h-[56px] lg:[&_img]:h-[64px] [&_svg]:h-[48px] [&_svg]:w-auto max-xs-sm:[&_svg]:h-[32px] md:[&_svg]:h-[56px] lg:[&_svg]:h-[64px]",
                              "bg-gray-50",
                              "text-sm",
                            ),
                        "transition-all data-[pressed=true]:bg-blue-100",
                        h === n ? "bg-blue-100 !border-blue-100" : "",
                        r && "pointer-events-none select-none opacity-50 blur-[2px] grayscale",
                      ),
                      children: (0, c.getOptionNode)(e, n),
                    },
                    `${a?.id}-${n}-answer`,
                  );
                }),
              }),
              I && (0, t.jsx)(u.HintAssistCounterComponent, { hintsLeft: z, poolSize: q, onActivate: C }),
              x &&
                (0, t.jsxs)("div", {
                  "data-cy": "get_result_section",
                  className: "mt-6 px-1 max-xs-sm:mt-3 sm:px-5 lg:px-1",
                  children: [
                    (0, t.jsx)(d.ButtonComponent, {
                      dataNR: "get-my-results-btn",
                      text: w ? b : A("quiz_get_my_results"),
                      size: "sm",
                      className: (0, s.cn)(
                        "get_result_btn mx-auto w-full max-w-md select-none lg:max-w-none [&_svg]:max-h-[80px] [&_svg]:max-w-[100px]",
                      ),
                      onClick: p,
                      opt: { isLoading: f },
                    }),
                    (0, t.jsx)("p", {
                      className:
                        "max-w-[600px] select-none whitespace-pre-wrap pt-2 text-center text-sm text-neutral-700",
                      children: A("quiz_do_you_want_to_confirm"),
                    }),
                  ],
                }),
            ],
          }),
        ],
      });
    };
    (e.s([], 415858),
      e.s(
        [
          "RenderCurrentStep",
          0,
          (e) => {
            let {
                activeQuestion: s,
                currentQuestionId: i,
                isShowMotivation: l,
                isMutatingQuizStarted: o,
                showResultButton: c,
                handleSelectOption: u,
                handleFinishQuiz: m,
                selectedOption: d,
                isLoading: p,
                isAdditionalTest: g,
                isProfile: h,
                buttonResultsText: f,
                useRetakeQuestions: _,
                abMyiqQuizChaosBlockQ1122: w,
                abMyiqQuizHintAssistCount: b,
                abMyiqQuizFewerOptions: N,
              } = e,
              v = s && "icons" in s;
            return ((0, r.useEffect)(() => {
              d || (0, n.scrollToTop)();
            }, [i, d]),
            v)
              ? (0, t.jsx)(
                  x,
                  {
                    className: l ? "!hidden" : "",
                    isLoading: p,
                    question: s,
                    showResultButton: c && !o,
                    handleFinishQuiz: m,
                    handleSelectOption: u,
                    selectedOption: d,
                    isAdditionalTest: g,
                    buttonResultsText: f,
                    useRetakeQuestions: _,
                    abMyiqQuizChaosBlockQ1122: w,
                    abMyiqQuizHintAssistCount: b,
                    abMyiqQuizFewerOptions: N,
                  },
                  i,
                )
              : (0, t.jsx)(
                  a.AdditionalQuestionsComponent,
                  {
                    question: s,
                    handleAnswerClick: (e) => u(e),
                    showResultButton: c,
                    handleFinishQuiz: m,
                    isLoading: p,
                    selectedOption: d,
                    isAdditionalTest: g,
                    isProfile: h,
                    abMyiqQuizHintAssistCount: b,
                  },
                  i,
                );
          },
        ],
        446454,
      ));
  },
  7028,
  803786,
  64802,
  356037,
  76670,
  468749,
  (e) => {
    "use strict";
    var t,
      s,
      n,
      r,
      a,
      i,
      l = e.i(843476),
      o = e.i(207670),
      c = e.i(948148),
      u = e.i(271645),
      m = e.i(520837),
      d = e.i(335889);
    e.i(381069);
    var x = e.i(268041),
      p = e.i(770703),
      g = e.i(768834),
      h = e.i(579473);
    e.i(756503);
    var f = e.i(542516);
    let _ = { poolSize: 0, usedCount: 0, eliminatedByQuestionId: {} },
      w = (0, g.create)()(
        (0, h.devtools)(
          (e) => ({
            ..._,
            syncPoolSize: (t) => e((e) => (e.poolSize === t ? e : { ..._, poolSize: t })),
            consumeHint: (t, s) =>
              e((e) =>
                e.eliminatedByQuestionId[t] || e.usedCount >= e.poolSize
                  ? e
                  : {
                      ...e,
                      usedCount: e.usedCount + 1,
                      eliminatedByQuestionId: { ...e.eliminatedByQuestionId, [t]: s },
                    },
              ),
            resetHintAssist: () => e({ ..._ }),
          }),
          { enabled: "production" !== f.envClient.NEXT_PUBLIC_NODE_ENV },
        ),
      ),
      b = (e) => {
        let {
            variant: t,
            isEligible: s,
            questionId: n,
            hasSelectedOption: r,
            isSequenceHidden: a,
            options: i,
            correctOption: l,
          } = e,
          { usedCount: o, eliminatedByQuestionId: c, syncPoolSize: m, consumeHint: d } = w(),
          x = "v1_3_hints" === t ? 3 : "v2_5_hints" === t ? 5 : 7 * ("v3_7_hints" === t);
        (0, u.useEffect)(() => {
          m(x);
        }, [x, m]);
        let p = Math.max(x - o, 0),
          g = c[n];
        return {
          isHintControlVisible: s && a && !r && !g && p > 0 && void 0 !== l,
          hintsLeft: p,
          poolSize: x,
          eliminatedOptions: g ?? [],
          handleActivateHint: () => {
            if (!g && !(p <= 0) && void 0 !== l) {
              let e;
              d(
                n,
                ((e, t) => {
                  let s = [...e],
                    n = [];
                  for (; n.length < t && s.length;) {
                    let e = Math.floor(Math.random() * s.length);
                    n.push(...s.splice(e, 1));
                  }
                  return n;
                })((e = i.filter((e) => e !== l)), e.length <= 2 ? 1 : 2),
              );
            }
          },
        };
      };
    e.s(["useHintAssist", 0, b], 803786);
    let N = () => () => {},
      v = () => !0;
    e.s(
      [
        "useIsHintAssistMobileViewport",
        0,
        () => {
          let e = (0, u.useRef)(void 0),
            t = (0, u.useCallback)(
              () => (
                void 0 === e.current && (e.current = document.documentElement.clientWidth < 768),
                e.current
              ),
              [],
            );
          return (0, u.useSyncExternalStore)(N, t, v);
        },
      ],
      64802,
    );
    let E = (0, p.default)(() => e.A(825853), { loadableGenerated: { modules: [360625] }, ssr: !1 });
    e.s(["HintAssistCounterComponent", 0, E], 356037);
    var S = e.i(663615);
    let y = (e) => {
      let { shapes: t, columns: s, correctIndex: n, onSolved: r, className: a } = e,
        i = s >= 4 ? 44 : 64,
        [o, c] = (0, u.useState)(!1),
        [m, d] = (0, u.useState)(!1);
      return (
        (0, u.useEffect)(() => {
          if (!o) return;
          let e = setTimeout(r, 600);
          return () => clearTimeout(e);
        }, [o, r]),
        (0, l.jsx)("div", {
          className: (0, S.cn)("mx-auto grid gap-3", a),
          style: { gridTemplateColumns: `repeat(${s}, ${i}px)` },
          "data-nr": "odd-one-out-grid",
          children: t.map((e, t) => {
            let s = o && t === n;
            return (0, l.jsx)(
              "button",
              {
                type: "button",
                disabled: m,
                "aria-label": `odd-one-out-cell-${t}`,
                "data-nr": t === n ? "additional-questions-answer-btn" : "odd-one-out-cell",
                onClick: () =>
                  ((e) => {
                    if (!m) {
                      if ((d(!0), e === n)) return void c(!0);
                      r();
                    }
                  })(t),
                style: { height: i, width: i },
                className: (0, S.cn)(
                  "transition-colors duration-300 ease-in-out",
                  "circle" === e ? "rounded-full" : "rounded-lg",
                  s ? "bg-green-custom" : "bg-gray-300",
                ),
              },
              t,
            );
          }),
        })
      );
    };
    e.i(165037);
    var A = e.i(856095);
    e.i(392277);
    var j = e.i(861152);
    e.i(934337);
    var I = e.i(599545);
    e.i(568267);
    var z = e.i(154692);
    let q = (e) => {
      let { title: t } = e,
        s = (0, c.useTranslations)()("ab_myiq_quiz_chat_analyst_name"),
        n = [...s][0] ?? "";
      return (0, l.jsxs)("div", {
        className: "mx-auto mb-4 w-full max-w-[600px]",
        children: [
          (0, l.jsxs)("div", {
            className: "mb-2 flex items-center gap-2.5",
            children: [
              (0, l.jsx)("span", {
                className:
                  "flex h-[22px] w-[22px] flex-none items-center justify-center rounded-lg bg-blue-custom text-[11px] font-bold leading-none text-blue-custom",
                children: n,
              }),
              (0, l.jsxs)("span", {
                className: "flex items-center gap-1.5",
                children: [
                  (0, l.jsx)("span", {
                    className: "text-[12px] font-semibold leading-none text-dark-custom",
                    children: s,
                  }),
                  (0, l.jsxs)("span", {
                    className: "relative flex h-1.5 w-1.5 flex-none",
                    "aria-hidden": "true",
                    children: [
                      (0, l.jsx)("span", {
                        className:
                          "absolute inset-0 rounded-full bg-green-custom/50 motion-safe:animate-chat-presence-ping",
                      }),
                      (0, l.jsx)("span", {
                        className: "relative inline-flex h-1.5 w-1.5 rounded-full bg-green-custom",
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          (0, l.jsx)("h2", {
            className:
              "inline-block rounded-2xl rounded-tl-[6px] bg-zinc-100 px-[18px] py-[13px] text-[16px] font-semibold leading-snug text-dark-custom [[dir=rtl]_&]:rounded-tl-2xl [[dir=rtl]_&]:rounded-tr-[4px]",
            "data-nr": "chat-question-title",
            children: t,
          }),
        ],
      });
    };
    var O = e.i(643449);
    let C = (e) => {
        let { questionId: t, secondsLeft: s, durationSeconds: n } = e,
          r = (0, c.useTranslations)(),
          a = (0, u.useRef)(null);
        return (
          (0, u.useEffect)(() => {
            let e,
              t = a.current;
            if (!t) return;
            let s = 1e3 * n,
              r = performance.now(),
              i = (n) => {
                let a = Math.min((n - r) / s, 1);
                ((t.style.width = `${(1 - a) * 100}%`), a < 1 && (e = requestAnimationFrame(i)));
              };
            return ((e = requestAnimationFrame(i)), () => cancelAnimationFrame(e));
          }, [t, n]),
          (0, l.jsx)("p", {
            className: "text-sm text-default-600",
            children: r.rich("quiz_page_ab_myiq_memorization_disappears_in_seconds", {
              seconds: String(s),
              strong: (e) =>
                (0, l.jsx)("strong", {
                  className: "font-semibold tabular-nums text-default-600",
                  children: e,
                }),
            }),
          })
        );
      },
      T = (e) => {
        let {
            sequence: t,
            questionId: s,
            onComplete: n,
            durationSeconds: r = O.DEFAULT_DISPLAY_DURATION_SECONDS,
            precueTitle: a,
          } = e,
          i = (0, c.useTranslations)(),
          o = a ?? i("quiz_page_ab_myiq_memorization_intro_title"),
          [m, d] = (0, u.useState)(r);
        return (
          (0, u.useEffect)(() => {
            d(r);
            let e = setInterval(() => {
                d((e) => Math.max(0, e - 1));
              }, 1e3),
              t = setTimeout(() => {
                n();
              }, 1e3 * r);
            return () => {
              (clearInterval(e), clearTimeout(t));
            };
          }, [s, n, r]),
          (0, l.jsxs)("div", {
            className: "mx-auto flex w-full flex-col items-center gap-3",
            children: [
              (0, l.jsxs)("div", {
                className: "flex w-full max-w-[600px] flex-col gap-3",
                children: [
                  (0, l.jsx)("div", {
                    className:
                      "-mt-4 flex flex-col items-center justify-center gap-2 pb-6 max-sm:min-h-[110px]",
                    children: (0, l.jsx)("h2", {
                      className:
                        "flex items-center justify-center text-center text-[24px] font-semibold leading-tight text-dark-custom max-lg:pt-6",
                      children: o,
                    }),
                  }),
                  (0, l.jsx)("div", {
                    className:
                      "flex h-[100px] w-full items-center justify-center rounded-2xl border border-gray-200 bg-white px-4",
                    "data-nr": "memorization-sequence-display",
                    children: (0, l.jsx)("span", {
                      className: "inline-block",
                      children: (0, l.jsx)("span", {
                        className:
                          "select-none text-[40px] font-semibold tabular-nums tracking-[0.35em] text-dark-custom",
                        children: t,
                      }),
                    }),
                  }),
                ],
              }),
              (0, l.jsx)("div", {
                className: "flex flex-col items-center gap-1.5",
                children: (0, l.jsx)(C, { questionId: s, secondsLeft: m, durationSeconds: r }),
              }),
            ],
          })
        );
      };
    function R() {
      return (R = Object.assign.bind()).apply(null, arguments);
    }
    function k() {
      return (k = Object.assign.bind()).apply(null, arguments);
    }
    function M() {
      return (M = Object.assign.bind()).apply(null, arguments);
    }
    function L() {
      return (L = Object.assign.bind()).apply(null, arguments);
    }
    function F() {
      return (F = Object.assign.bind()).apply(null, arguments);
    }
    function Q() {
      return (Q = Object.assign.bind()).apply(null, arguments);
    }
    let U = {
        circle: (e) =>
          u.createElement(
            "svg",
            R({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 200 200" }, e),
            t || (t = u.createElement("circle", { cx: 100, cy: 100, r: 98, stroke: "#000", strokeWidth: 4 })),
          ),
        triangle: (e) =>
          u.createElement(
            "svg",
            Q({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 200 200" }, e),
            i || (i = u.createElement("path", { stroke: "#000", strokeWidth: 4, d: "m100 4 96 194H4z" })),
          ),
        square: (e) =>
          u.createElement(
            "svg",
            L({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 200 200" }, e),
            r ||
              (r = u.createElement("rect", {
                width: 196,
                height: 196,
                x: 2,
                y: 2,
                stroke: "#000",
                strokeWidth: 4,
                rx: 23.119,
              })),
          ),
        diamond: (e) =>
          u.createElement(
            "svg",
            k({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 200 200" }, e),
            s ||
              (s = u.createElement("path", {
                stroke: "#000",
                strokeWidth: 4,
                d: "M197.172 100 100 197.172 2.828 100 100 2.828z",
              })),
          ),
        star: (e) =>
          u.createElement(
            "svg",
            F({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 -4.88 211 211" }, e),
            a ||
              (a = u.createElement("path", {
                stroke: "#000",
                strokeWidth: 4,
                d: "m128.065 77.012.45 1.382h75.622l-60.004 43.594-1.176.855.449 1.382 22.92 70.539-60.004-43.596-1.176-.854-1.175.854-60.005 43.595 22.92-70.538.449-1.382-1.176-.855L6.156 78.394h75.621l.45-1.382L105.146 6.47z",
              })),
          ),
        hexagon: (e) =>
          u.createElement(
            "svg",
            M({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 174 200" }, e),
            n ||
              (n = u.createElement("path", {
                stroke: "#000",
                strokeWidth: 4,
                d: "M171.205 51.154v97.691l-84.602 48.844L2 148.845v-97.69L86.603 2.31z",
              })),
          ),
      },
      B = (e) => {
        let { shape: t, className: s } = e,
          n = U[t];
        return n ? (0, l.jsx)(n, { className: s }) : null;
      },
      D = (e) => {
        let { shapes: t, questionId: s, onComplete: n, durationSeconds: r = 5 } = e,
          a = (0, c.useTranslations)(),
          [i, o] = (0, u.useState)(r);
        return (
          (0, u.useEffect)(() => {
            o(r);
            let e = setInterval(() => {
                o((e) => Math.max(0, e - 1));
              }, 1e3),
              t = setTimeout(() => {
                n();
              }, 1e3 * r);
            return () => {
              (clearInterval(e), clearTimeout(t));
            };
          }, [s, n, r]),
          (0, l.jsxs)("div", {
            className: "mx-auto flex w-full flex-col items-center gap-3",
            children: [
              (0, l.jsxs)("div", {
                className: "flex w-fit max-w-full flex-col gap-3",
                children: [
                  (0, l.jsx)("div", {
                    className:
                      "-mt-4 flex flex-col items-center justify-center gap-2 pb-6 max-sm:min-h-[110px]",
                    children: (0, l.jsx)("h2", {
                      className:
                        "flex items-center justify-center text-center text-[24px] font-semibold leading-tight text-dark-custom max-lg:pt-6",
                      children: a("quiz_page_ab_myiq_memorization_shapes_intro_title"),
                    }),
                  }),
                  (0, l.jsx)("div", {
                    className:
                      "flex min-h-[100px] w-full items-center justify-center gap-3 rounded-2xl border border-[#D9D9D9] bg-white px-4 xs-m:gap-4",
                    "data-nr": "memorization-shape-sequence-display",
                    children: t.map((e, s) =>
                      (0, l.jsx)(
                        B,
                        {
                          shape: e,
                          className: (0, S.cn)(
                            "h-14 w-14 flex-shrink-0",
                            4 === t.length && "h-[52px] w-[52px] xs-m:h-14 xs-m:w-14",
                            t.length > 4 && "h-10 w-10 xs-m:h-12 xs-m:w-12 xs-l:h-14 xs-l:w-14",
                          ),
                        },
                        s,
                      ),
                    ),
                  }),
                ],
              }),
              (0, l.jsx)("div", {
                className: "flex flex-col items-center gap-1.5",
                children: (0, l.jsxs)("p", {
                  className: "text-sm text-default-600",
                  children: [
                    a("quiz_page_ab_myiq_memorization_disappears_in"),
                    " ",
                    (0, l.jsx)("strong", {
                      className: "font-semibold tabular-nums text-default-600",
                      children: i,
                    }),
                    " ",
                    a("quiz_page_ab_myiq_memorization_seconds_label"),
                  ],
                }),
              }),
            ],
          })
        );
      };
    (e.s(
      [
        "default",
        0,
        (e) => {
          let { word: t, title: s, subtitle: n, isDigits: r } = e,
            a = (0, c.useTranslations)();
          return (0, l.jsxs)("div", {
            className: "mx-auto flex w-full flex-col items-center gap-3",
            children: [
              (0, l.jsxs)("div", {
                className: "flex w-full max-w-[600px] flex-col gap-3",
                children: [
                  (0, l.jsx)("div", {
                    className:
                      "-mt-4 flex flex-col items-center justify-center gap-2 pb-6 max-sm:min-h-[110px]",
                    children: (0, l.jsx)("h2", {
                      className:
                        "flex items-center justify-center text-center text-[24px] font-semibold leading-tight text-dark-custom max-lg:pt-6",
                      children: s ?? a("quiz_page_ab_myiq_word_recall_intro_title"),
                    }),
                  }),
                  (0, l.jsx)("div", {
                    className:
                      "flex h-[100px] w-full items-center justify-center rounded-2xl border border-gray-200 bg-white px-4",
                    "data-nr": "word-recall-intro-display",
                    children: (0, l.jsx)("span", {
                      className: "inline-block",
                      children: (0, l.jsx)("span", {
                        className: (0, S.cn)(
                          "select-none text-[40px] font-semibold text-dark-custom",
                          r && "tabular-nums tracking-[0.35em]",
                        ),
                        children: t,
                      }),
                    }),
                  }),
                ],
              }),
              (0, l.jsx)("div", {
                className: "flex flex-col items-center gap-1.5",
                children: (0, l.jsx)("p", {
                  className: "text-sm text-default-600",
                  children: n ?? a("quiz_page_ab_myiq_word_recall_intro_subtitle"),
                }),
              }),
            ],
          });
        },
      ],
      76670,
    ),
      e.s([], 7028),
      e.s(
        [
          "AdditionalQuestionsComponent",
          0,
          (e) => {
            let {
                question: t,
                handleAnswerClick: s,
                showResultButton: n,
                handleFinishQuiz: r,
                isLoading: a,
                selectedOption: i,
                abVariation: p,
                isAdditionalTest: g,
                isProfile: h,
                onEmail: f,
                answersNormalCase: _,
                answerDataNR: w = "additional-questions-answer-btn",
                abMyiqQuizHintAssistCount: N,
              } = e,
              v = (0, c.useTranslations)(),
              S = (0, A.getQuizButtonText)(v, h, g),
              O = !!t.stimulusImage,
              C = O && "stack" === t.stimulusLayout,
              R = O && "flush" === t.stimulusLayout,
              k = !!t.memorizationShapes?.length,
              M = !!t.memorizationSequence,
              L = k || M,
              F = !!t.oddOneOutShapes?.length,
              [Q, U] = (0, u.useState)(L);
            (0, u.useEffect)(() => {
              U(!!t.memorizationSequence || !!t.memorizationShapes?.length);
            }, [t.id]);
            let P = (0, u.useCallback)(() => {
              U(!1);
            }, []);
            (0, u.useEffect)(() => {
              n && window.innerWidth < 640 && (0, A.scrollToBottom)();
            }, [n]);
            let {
              isHintControlVisible: H,
              hintsLeft: W,
              poolSize: $,
              eliminatedOptions: G,
              handleActivateHint: K,
            } = b({
              variant: N,
              isEligible: !h && !!t.correctAnswer && !!t.answers?.length,
              questionId: t.id,
              hasSelectedOption: !!i,
              isSequenceHidden: !Q,
              options: t.answers?.map((e, t) => t) ?? [],
              correctOption: t.correctAnswer ? t.answers?.indexOf(t.correctAnswer) : void 0,
            });
            return L && Q
              ? k
                ? (0, l.jsx)(D, { shapes: t.memorizationShapes, questionId: t.id, onComplete: P })
                : (0, l.jsx)(T, {
                    sequence: t.memorizationSequence,
                    questionId: t.id,
                    onComplete: P,
                    precueTitle: t.memorizationPrecueTitle,
                  })
              : F
                ? (0, l.jsxs)("div", {
                    className: "mx-auto flex w-full flex-col",
                    children: [
                      (0, l.jsx)("div", {
                        className:
                          "mx-auto flex aspect-[49/37] w-full max-w-[343px] items-center justify-center rounded-2xl bg-white p-4 shadow-[0_2px_14px_rgba(0,0,0,0.09)] lg:max-w-[464px]",
                        children: (0, l.jsx)(y, {
                          shapes: t.oddOneOutShapes,
                          columns: t.oddOneOutColumns,
                          correctIndex: t.oddOneOutCorrectIndex,
                          onSolved: () => s(t.correctAnswer),
                        }),
                      }),
                      (0, l.jsx)("h2", {
                        className: "dark:text-foreground-700 mb-2 mt-4 select-none px-5 text-center lg:mt-0",
                        children: t.title,
                      }),
                    ],
                  })
                : (0, l.jsxs)("div", {
                    className: (0, o.default)(
                      "mx-auto flex w-full flex-col gap-3",
                      O && (C || R ? "!gap-0" : "gap-6 px-4"),
                    ),
                    children: [
                      t.isChatQuestion
                        ? (0, l.jsx)(q, { title: t.title })
                        : O
                          ? (0, l.jsxs)(l.Fragment, {
                              children: [
                                R
                                  ? (0, l.jsx)(m.Card, {
                                      className: "relative mx-auto w-full max-w-[343px] lg:max-w-[464px]",
                                      children: (0, l.jsx)("div", {
                                        className: "flex w-full justify-center bg-white px-6 py-4",
                                        children: t.stimulusImage,
                                      }),
                                    })
                                  : (0, l.jsx)("div", {
                                      className: (0, o.default)(
                                        "flex w-full justify-center rounded-2xl bg-white p-4 shadow-[0_2px_14px_rgba(0,0,0,0.09)]",
                                        C && "mx-auto max-w-[343px] lg:max-w-[464px]",
                                      ),
                                      children: t.stimulusImage,
                                    }),
                                (0, l.jsx)("h2", {
                                  className: (0, o.default)(
                                    "dark:text-foreground-700 mb-2 mt-4 select-none px-5 text-center lg:mt-0",
                                    C ? "lg:text-md" : "text-[17px] [text-wrap:pretty]",
                                  ),
                                  children: t.title,
                                }),
                              ],
                            })
                          : (0, l.jsx)("div", {
                              className: (0, o.default)(
                                "flex flex-col items-center justify-center gap-2 pb-6",
                                !f && "-mt-4 max-sm:min-h-[110px]",
                              ),
                              children: (0, l.jsx)("h2", {
                                className:
                                  "flex items-center justify-center text-center text-[24px] font-semibold leading-tight text-dark-custom max-lg:pt-6",
                                children: t.title,
                              }),
                            }),
                      (0, l.jsxs)("div", {
                        className: (0, o.default)(
                          "mx-auto flex w-full flex-col gap-3",
                          R ? "max-w-[343px] lg:max-w-[464px]" : "max-w-[600px]",
                          C && "mt-1 px-1 sm:px-5",
                        ),
                        children: [
                          t.answers.map((e, n) => {
                            let r = i === e,
                              a = (0, x.isDefaultColor)(t),
                              c = t.answersShapeIcons?.[n],
                              u = G.includes(n);
                            return (0, l.jsx)(
                              "div",
                              {
                                className: "mx-auto w-full max-w-[600px]",
                                children: (0, l.jsxs)(d.Button, {
                                  disableRipple: !0,
                                  isDisabled: u,
                                  className: (0, o.default)(
                                    !O || C || R
                                      ? (0, o.default)(
                                          a
                                            ? "bg-correct-bg text-start"
                                            : (0, j.getButtonClasses)({
                                                answerIdx: n,
                                                answersLength: t.answers.length,
                                              }),
                                          "h-[58px] justify-between justify-items-start p-6 text-base font-medium text-dark-custom",
                                          "rounded-xl",
                                        )
                                      : "min-h-[60px] items-center justify-start rounded-2xl bg-[rgb(234,244,240)] px-5 text-[17px] font-medium text-[rgb(38,50,72)]",
                                    "w-full text-wrap",
                                    _ || t.answersNormalCase ? "normal-case" : "capitalize",
                                    "transition-all duration-300 ease-in-out",
                                    p &&
                                      "bg-correct-bg data-[pressed=true]:!bg-zinc-100 sm:hover:bg-correct-border",
                                    u && "pointer-events-none select-none opacity-50 blur-[2px] grayscale",
                                  ),
                                  onPress: () => s(e),
                                  "data-nr": w,
                                  children: [
                                    (0, l.jsxs)("span", {
                                      className: (0, o.default)(
                                        "flex flex-1 items-center gap-2",
                                        t.answersCentered ? "justify-center text-center" : "text-start",
                                      ),
                                      children: [
                                        c && (0, l.jsx)(B, { shape: c, className: "h-5 w-5 flex-shrink-0" }),
                                        e,
                                      ],
                                    }),
                                    r && (0, l.jsx)(I.IconCheckmark, { className: "h-4 w-4" }),
                                  ],
                                }),
                              },
                              `${t.title}-${e}`,
                            );
                          }),
                          H && (0, l.jsx)(E, { hintsLeft: W, poolSize: $, onActivate: K }),
                        ],
                      }),
                      n &&
                        (0, l.jsxs)("div", {
                          "data-cy": "get_result_section",
                          className: "mx-auto mt-4 flex w-full max-w-[600px] flex-col justify-center px-0",
                          children: [
                            (0, l.jsx)(z.ButtonComponent, {
                              name: "get-my-results-btn",
                              dataNR: "get-my-results-btn",
                              text: S,
                              size: "md",
                              className: (0, o.default)("mx-auto w-full select-none"),
                              onClick: r,
                              opt: { isLoading: a },
                              fullWidth: !0,
                            }),
                            (0, l.jsx)("p", {
                              className:
                                "max-w-[600px] select-none pt-2 text-center text-sm text-neutral-700",
                              children: v("quiz_do_you_want_to_confirm"),
                            }),
                          ],
                        }),
                    ],
                  });
          },
        ],
        468749,
      ));
  },
  339386,
  643449,
  (e) => {
    "use strict";
    var t = e.i(157273),
      s = e.i(60423);
    (e.s(["DEFAULT_DISPLAY_DURATION_SECONDS", 0, 5], 643449),
      e.s(
        [
          "buildNonImageQuizAnswers",
          0,
          (e) => {
            let { allQuestions: t, additionalAnswers: s, questionTimes: n } = e,
              r = [...t].sort((e, t) => e.id - t.id),
              a = 0;
            return r.reduce((e, t) => {
              if ("icons" in t) return (a++, e);
              if (!("questionKey" in t && t.questionKey && t.correctAnswer)) return e;
              let r = s[t.id];
              if (void 0 === r) return e;
              let i = !!(t.memorizationSequence && t.memorizationAskedPosition);
              return (
                e.push({
                  questionKey: t.questionKey,
                  position: t.id,
                  precedingImageCount: a,
                  userAnswer: r,
                  correctAnswer: t.correctAnswer,
                  isCorrect: r === t.correctAnswer,
                  timeSpent: n?.[t.id] || 0,
                  ...(i
                    ? {
                        memorization: {
                          sequence: t.memorizationSequence,
                          askedPosition: t.memorizationAskedPosition,
                          shownSeconds: t.memorizationDurationSeconds ?? 5,
                        },
                      }
                    : {}),
                }),
                e
              );
            }, []);
          },
          "getNonImageQuizAnswersFromLocalStorage",
          0,
          () => {
            let e = s.accessLocalStorage.getItem(t.StorageKeys.MYIQ_NON_IMAGE_ANSWERS);
            if (!e) return null;
            try {
              let t = JSON.parse(e);
              return Array.isArray(t) ? t : null;
            } catch {
              return null;
            }
          },
          "saveNonImageQuizAnswersToLocalStorage",
          0,
          (e) => {
            0 !== e.length &&
              s.accessLocalStorage.setItem(t.StorageKeys.MYIQ_NON_IMAGE_ANSWERS, JSON.stringify(e));
          },
        ],
        339386,
      ));
  },
  245588,
  (e) => {
    "use strict";
    var t = e.i(157273),
      s = e.i(60423);
    e.s([
      "clearQuizAnswersFromLocalStorage",
      0,
      () => {
        s.accessLocalStorage.removeItem(t.StorageKeys.QUIZ_ANSWERS);
      },
      "getQuizAnswersFromLocalStorage",
      0,
      () => {
        let e = s.accessLocalStorage.getItem(t.StorageKeys.QUIZ_ANSWERS);
        return e ? JSON.parse(e) : null;
      },
    ]);
  },
  224033,
  895106,
  (e) => {
    "use strict";
    let t = (e) => {
      let { baseId: t, userAnswer: s, correctAnswer: n } = e;
      if (!t || t < 1 || t > 100) return null;
      let r = `abq${t}`,
        a = `aba${t}-${s}`,
        i = n ? `aba${t}-${n}` : a;
      return { questionImageId: r, userAnswerImageId: a, correctAnswerImageId: i };
    };
    e.s(["generateRetakeQuizAnswerImages", 0, t], 895106);
    var s = e.i(157273),
      n = e.i(60423),
      r = e.i(278718);
    e.i(245588);
    let a = (e, t) => {
      let s = t - e.reduce((e, t) => e + (t.timeSpent || 0), 0);
      return s > 0
        ? ((e, t) => {
            if (t <= 0 || 0 === e.length) return e;
            let s = e.map((e, t) => t);
            for (let e = s.length - 1; e > 0; e--) {
              let t = Math.floor(Math.random() * (e + 1));
              [s[e], s[t]] = [s[t], s[e]];
            }
            let n = [...e],
              r = t,
              a = 0;
            for (; r > 0 && a < s.length;) {
              let e = s[a],
                t = Math.min(Math.floor(3 * Math.random()) + 1, r);
              ((n[e] = { ...n[e], timeSpent: (n[e].timeSpent || 0) + t }), (r -= t), a++);
            }
            if (r > 0) {
              let e = Math.floor(r / n.length),
                t = r % n.length;
              n.forEach((s, r) => {
                n[r] = { ...s, timeSpent: (s.timeSpent || 0) + e + +(r < t) };
              });
            }
            return n;
          })(e, s)
        : e;
    };
    e.s(
      [
        "saveQuizAnswersToLocalStorage",
        0,
        (e) => {
          let { userAnswers: i, questionTimes: l, totalSpentTime: o, isProfile: c, isABQuiz: u } = e,
            m = i
              .filter((e) => void 0 !== e.userAnswer)
              .map((e) => {
                let s = { id: e.id, baseId: e.baseId, userAnswer: e.userAnswer, timeSpent: l?.[e.id] || 0 },
                  n = u
                    ? t({ baseId: e.baseId, userAnswer: e.userAnswer, correctAnswer: e.correctAnswer })
                    : (0, r.generateQuizAnswerImages)({
                        baseId: e.baseId,
                        userAnswer: e.userAnswer,
                        correctAnswer: e.correctAnswer,
                      }) || t({ baseId: e.baseId, userAnswer: e.userAnswer, correctAnswer: e.correctAnswer });
                return n
                  ? {
                      ...s,
                      questionImageId: n.questionImageId,
                      userAnswerImageId: n.userAnswerImageId,
                      correctAnswerImageId: n.correctAnswerImageId,
                    }
                  : s;
              }),
            d = void 0 !== o ? a(m, o) : m;
          if (c) return d;
          n.accessLocalStorage.setItem(s.StorageKeys.QUIZ_ANSWERS, JSON.stringify(d));
        },
        "synchronizeQuestionTimes",
        0,
        a,
      ],
      224033,
    );
  },
  236801,
  (e) => {
    "use strict";
    var t = e.i(954616),
      s = e.i(912598),
      n = e.i(134404),
      r = e.i(86596),
      a = e.i(431936),
      i = e.i(51742);
    let l = async (e, t) => {
      if (!e) return { success: !1, error: "Email is required", data: null };
      let s = ((e) => {
        switch (e) {
          case i.EFunnels.LOVE_LANGUAGE:
            return "love_quiz";
          case i.EFunnels.PERSONALITY:
            return "personality_quiz";
          case i.EFunnels.ADHD:
            return "adhd_quiz";
          case i.EFunnels.ATTACHMENT:
            return "attachment_quiz";
          case i.EFunnels.CAREERS:
            return "careers_quiz";
          case i.EFunnels.MYIQ:
            return "quiz";
          case i.EFunnels.DEPRESSION:
            return "depression_quiz";
          case i.EFunnels.TIME_MANAGEMENT:
            return "time_management_quiz";
          case i.EFunnels.BURNOUT:
            return "burnout_quiz";
          case i.EFunnels.EMOTIONAL:
            return "emotional_quiz";
          case i.EFunnels.WORK:
            return "work_quiz";
          case i.EFunnels.PSYCHOLOGICAL_ARCHETYPES:
            return "psychological_archetypes_quiz";
          case i.EFunnels.PROCRASTINATION:
            return "procrastination_quiz";
          case i.EFunnels.IMPOSTER_SYNDROME:
            return "imposter_syndrome_quiz";
          case i.EFunnels.ANXIETY:
            return "anxiety_quiz";
          case i.EFunnels.CONFIDENCE:
            return "confidence_quiz";
          case i.EFunnels.STRENGTHS:
            return "strengths_quiz";
          case i.EFunnels.AUTISM:
            return "autism_quiz";
          case i.EFunnels.ENNEAGRAM:
            return "enneagram_quiz";
          default:
            return "quiz";
        }
      })(t);
      return (0, a.patchUserFetcher)({ email: e, userInfo: { [s]: "started" } });
    };
    e.s(
      [
        "useQuizStarted",
        0,
        (e) => {
          let a = (0, s.useQueryClient)(),
            i = (0, r.useUserStore)((e) => e.handleChangeUserStore),
            o = (0, t.useMutation)({
              mutationFn: (t) => l(t, e),
              onSuccess(e, t) {
                t &&
                  e.data &&
                  (a.setQueryData([n.EApiRoutes.AUTH_USER, t], { success: !0, data: e.data }),
                  i({ user: { ...e.data.user_info } }));
              },
            });
          return { ...o, trigger: o.mutateAsync };
        },
      ],
      236801,
    );
  },
  984574,
  (e) => {
    "use strict";
    e.s([
      "generateCertificateId",
      0,
      () => `${Math.floor(6e5 * Math.random()) + 4e5}`.replace(/\B(?=(\d{3})+(?!\d))/g, " "),
    ]);
  },
  775367,
  (e) => {
    "use strict";
    let t = "4726",
      s = ["7421", t];
    e.s([
      "NUMBER_RECALL_ANALYZING_PROGRESS",
      0,
      80,
      "NUMBER_RECALL_ANSWERS",
      0,
      s,
      "NUMBER_RECALL_IMAGE_BLOCK_INDEX",
      0,
      17,
      "NUMBER_RECALL_NUMBER",
      0,
      t,
      "NUMBER_RECALL_QUESTION_POSITION",
      0,
      28,
    ]);
  },
  573348,
  (e) => {
    "use strict";
    e.s([
      "DEFAULT_GENERAL_SCORE",
      0,
      105,
      "DEFAULT_SECTION_SCORES",
      0,
      { visual: 85, abstract: 78, pattern: 82, spatial: 75, analytical: 80 },
    ]);
  },
]);
