(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  882983,
  (e) => {
    "use strict";
    var i = e.i(265840),
      t = e.i(271645),
      a = e.i(273830),
      s = e.i(620253),
      r = e.i(75540),
      o = e.i(843476),
      l = (0, a.forwardRef)((e, a) => {
        let { as: l, children: n, className: d, ...c } = e,
          { slots: m, classNames: p, bodyId: h, setBodyMounted: f } = (0, i.useModalContext)(),
          v = (0, s.useDOMRef)(a);
        return (
          (0, t.useEffect)(() => (f(!0), () => f(!1)), [f]),
          (0, o.jsx)(l || "div", {
            ref: v,
            className: m.body({ class: (0, r.clsx)(null == p ? void 0 : p.body, d) }),
            id: h,
            ...c,
            children: n,
          })
        );
      });
    ((l.displayName = "HeroUI.ModalBody"), e.s(["ModalBody", 0, l], 882983));
  },
  768214,
  (e) => {
    "use strict";
    let i = (0, e.i(475254).default)("mail", [
      ["path", { d: "m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7", key: "132q7q" }],
      ["rect", { x: "2", y: "4", width: "20", height: "16", rx: "2", key: "izxlao" }],
    ]);
    e.s(["default", 0, i]);
  },
  380251,
  618208,
  (e) => {
    "use strict";
    var i = e.i(843476),
      t = e.i(202042);
    let a = /^(https?:|mailto:|\/|#)/i,
      s = /^(https?:|mailto:)/i,
      r = {
        sm: "h-[var(--ds-primitive-dimension-size-36)] px-[var(--ds-primitive-dimension-spacing-16)] text-[length:var(--ds-primitive-typography-scale-body-sm-font-size)] leading-[var(--ds-primitive-typography-scale-body-sm-line-height)] tracking-[var(--ds-primitive-typography-scale-body-sm-letter-spacing)]",
        md: "h-[var(--ds-primitive-dimension-size-44)] px-[var(--ds-primitive-dimension-spacing-20)] text-[length:var(--ds-primitive-typography-scale-body-sm-font-size)] leading-[var(--ds-primitive-typography-scale-body-sm-line-height)] tracking-[var(--ds-primitive-typography-scale-body-sm-letter-spacing)]",
        lg: "h-[var(--ds-primitive-dimension-size-48)] px-[var(--ds-primitive-dimension-spacing-24)] text-[length:var(--ds-primitive-typography-scale-body-font-size)] leading-[var(--ds-primitive-typography-scale-body-line-height)] tracking-[var(--ds-primitive-typography-scale-body-letter-spacing)]",
        xl: "h-[var(--ds-primitive-dimension-size-52)] px-[var(--ds-primitive-dimension-spacing-24)] text-[length:var(--ds-primitive-typography-scale-body-font-size)] leading-[var(--ds-primitive-typography-scale-body-line-height)] tracking-[var(--ds-primitive-typography-scale-body-letter-spacing)]",
      },
      o = {
        primary:
          "border-transparent bg-[var(--ds-semantic-color-accent-base)] text-[var(--ds-semantic-color-text-on-accent)]",
        secondary:
          "border-[var(--ds-semantic-color-border-accent)] bg-[var(--ds-semantic-color-surface-page)] text-[var(--ds-semantic-color-accent-base)]",
        ghost: "border-transparent bg-transparent text-[var(--ds-semantic-color-text-muted)]",
      },
      l = {
        primary:
          "group-hover:opacity-[var(--ds-semantic-opacity-hover-on-fill)] group-active:opacity-[var(--ds-semantic-opacity-pressed-on-fill)]",
        secondary:
          "group-hover:opacity-[var(--ds-semantic-opacity-hover-on-surface)] group-active:opacity-[var(--ds-semantic-opacity-pressed-on-surface)]",
        ghost:
          "group-hover:opacity-[var(--ds-semantic-opacity-hover-on-surface)] group-active:opacity-[var(--ds-semantic-opacity-pressed-on-surface)]",
      },
      n = { false: "w-auto", true: "w-full", "until-md": "w-full md:w-auto" },
      d = (e) => (a.test(e) ? e : "#");
    (e.s([], 380251),
      e.s(
        [
          "ButtonComponent",
          0,
          (e) => {
            let {
                children: a,
                className: c,
                disabled: m = !1,
                fullWidth: p = !1,
                href: h,
                icon: f,
                onClick: v,
                size: x = "md",
                type: y = "button",
                variant: g = "primary",
              } = e,
              u = `group relative isolate inline-flex items-center justify-center gap-x-[var(--ds-primitive-dimension-spacing-8)] overflow-hidden rounded-[var(--ds-semantic-radius-pill)] border-[length:var(--ds-primitive-dimension-borderWidth-hairline)] border-solid font-medium no-underline transition-[color,background-color,border-color,text-decoration-color,fill,stroke] duration-[var(--ds-semantic-motion-instant)] motion-reduce:transition-none focus-visible:outline focus-visible:outline-[length:var(--ds-primitive-dimension-borderWidth-thick)] focus-visible:outline-offset-[var(--ds-primitive-dimension-size-half-2)] focus-visible:outline-[var(--ds-semantic-color-border-focus)] disabled:opacity-[0.5] disabled:cursor-not-allowed ${r[x]} ${o[g]} ${n[String(p)]} ${c ?? ""}`,
              b = (0, i.jsx)("span", {
                "aria-hidden": "true",
                className: `absolute inset-0 -z-10 bg-[var(--ds-semantic-color-state-layer-on-light)] opacity-0 transition-opacity duration-[var(--ds-semantic-motion-instant)] motion-reduce:transition-none ${l[g]}`,
              });
            return h && s.test(h)
              ? (0, i.jsxs)("a", {
                  className: u,
                  href: d(h),
                  onClick: v,
                  rel: "noopener noreferrer",
                  target: "_blank",
                  children: [b, a, f],
                })
              : h
                ? (0, i.jsxs)(t.Link, { className: u, href: d(h), onClick: v, children: [b, a, f] })
                : (0, i.jsxs)("button", {
                    className: u,
                    disabled: m,
                    onClick: v,
                    type: y,
                    children: [b, a, f],
                  });
          },
        ],
        618208,
      ));
  },
  247162,
  (e) => {
    "use strict";
    var i = e.i(843476),
      t = e.i(768214),
      t = t,
      a = e.i(948148);
    e.i(380251);
    var s = e.i(618208);
    e.i(317197);
    var r = e.i(231529),
      o = e.i(622963);
    let l = () =>
      (0, i.jsxs)("svg", {
        viewBox: "0 0 200 132",
        className: "h-auto w-[176px]",
        "aria-hidden": !0,
        children: [
          (0, i.jsx)("circle", { cx: "100", cy: "74", r: "58", fill: "#ffffff", fillOpacity: "0.7" }),
          (0, i.jsxs)("g", {
            className: "animate-hero-fade motion-reduce:animate-none [animation-delay:500ms]",
            children: [
              (0, i.jsx)("path", {
                d: "M38 30l1.6 4.4L44 36l-4.4 1.6L38 42l-1.6-4.4L32 36l4.4-1.6z",
                className: "fill-blue-custom/50",
              }),
              (0, i.jsx)("path", {
                d: "M168 24l1.2 3.3 3.3 1.2-3.3 1.2-1.2 3.3-1.2-3.3-3.3-1.2 3.3-1.2z",
                className: "fill-blue-custom/40",
              }),
              (0, i.jsx)("path", {
                d: "M30 94l1 2.8 2.8 1-2.8 1-1 2.8-1-2.8-2.8-1 2.8-1z",
                className: "fill-blue-custom/30",
              }),
            ],
          }),
          (0, i.jsx)("rect", { x: "44", y: "58", width: "112", height: "66", rx: "10", fill: "#D7E9FF" }),
          (0, i.jsx)("path", { d: "M44 66l56-36 56 36z", fill: "#C2DCFB" }),
          (0, i.jsxs)("g", {
            className: "animate-hero-rise motion-reduce:animate-none [animation-delay:120ms]",
            children: [
              (0, i.jsx)("rect", {
                x: "58",
                y: "20",
                width: "84",
                height: "74",
                rx: "6",
                fill: "#ffffff",
                stroke: "#E2E8F0",
              }),
              (0, i.jsx)("rect", {
                x: "68",
                y: "30",
                width: "24",
                height: "4",
                rx: "2",
                className: "fill-blue-custom",
              }),
              (0, i.jsx)("rect", { x: "68", y: "40", width: "54", height: "6", rx: "3", fill: "#0B0C27" }),
              (0, i.jsx)("rect", { x: "68", y: "51", width: "42", height: "3", rx: "1.5", fill: "#CBD5E1" }),
              (0, i.jsx)("rect", { x: "68", y: "57", width: "48", height: "3", rx: "1.5", fill: "#CBD5E1" }),
              (0, i.jsx)("rect", { x: "66", y: "66", width: "23", height: "12", rx: "3", fill: "#D7E9FF" }),
              (0, i.jsx)("text", {
                x: "77.5",
                y: "74.4",
                textAnchor: "middle",
                fontSize: "6.5",
                fontWeight: "700",
                fill: "#006FEE",
                children: "PDF",
              }),
              (0, i.jsx)("path", {
                d: "M121 72l-3 10 5-2.5 3 3.5 1-10zM131 72l3 10-5-2.5-3 3.5-1-10z",
                className: "fill-blue-custom/70",
              }),
              (0, i.jsx)("circle", { cx: "126", cy: "68", r: "8", className: "fill-blue-custom" }),
              (0, i.jsx)("circle", {
                cx: "126",
                cy: "68",
                r: "4.5",
                fill: "none",
                stroke: "#ffffff",
                strokeWidth: "1.2",
              }),
            ],
          }),
          (0, i.jsx)("path", {
            d: "M44 68l56 32 56-32v46a10 10 0 0 1-10 10H54a10 10 0 0 1-10-10z",
            className: "fill-blue-custom",
          }),
          (0, i.jsx)("path", {
            d: "M46 122l44-26M154 122l-44-26",
            stroke: "#ffffff",
            strokeOpacity: "0.22",
            strokeWidth: "1.5",
          }),
          (0, i.jsxs)("g", {
            className:
              "origin-center animate-profile-pop [animation-delay:520ms] [transform-box:fill-box] motion-reduce:animate-none",
            children: [
              (0, i.jsx)("circle", {
                cx: "154",
                cy: "62",
                r: "13",
                fill: "#0D766E",
                stroke: "#ffffff",
                strokeWidth: "3",
              }),
              (0, i.jsx)("path", {
                d: "M148.5 62.2l3.8 3.8 7.2-7.4",
                fill: "none",
                stroke: "#ffffff",
                strokeWidth: "2.6",
                strokeLinecap: "round",
                strokeLinejoin: "round",
              }),
            ],
          }),
        ],
      });
    (e.s([], 33958),
      e.i(33958),
      e.s(
        [
          "CertificateEmailSentModalComponent",
          0,
          (e) => {
            let { email: n, document: d = "certificate" } = e,
              c = (0, a.useTranslations)(),
              m = (0, o.useModalStore)((e) => e.handleChangeModalStore);
            return (0, i.jsxs)(r.ModalBodyComponent, {
              bodyClassName:
                "gap-0 p-0 md:p-0 [@media(max-height:580px)]:gap-0 [@media(max-height:580px)]:p-0",
              children: [
                (0, i.jsx)("div", {
                  className:
                    "flex justify-center bg-[image:var(--ds-semantic-gradient-panel)] px-6 pb-4 pt-10",
                  children: (0, i.jsx)(l, {}),
                }),
                (0, i.jsxs)("div", {
                  className: "flex flex-col p-6 text-center",
                  children: [
                    (0, i.jsx)("h2", {
                      className:
                        "text-[length:var(--ds-primitive-typography-scale-h3-font-size)] font-semibold leading-[var(--ds-primitive-typography-scale-h3-line-height)] tracking-[var(--ds-primitive-typography-scale-h3-letter-spacing)] text-[var(--ds-semantic-color-text-primary)]",
                      children: c("certificate_email_modal_title"),
                    }),
                    (0, i.jsx)("p", {
                      className:
                        "mt-2 text-[length:var(--ds-primitive-typography-scale-body-font-size)] leading-[var(--ds-primitive-typography-scale-body-line-height)] tracking-[var(--ds-primitive-typography-scale-body-letter-spacing)] text-[var(--ds-semantic-color-text-muted)]",
                      children: c(
                        "report" === d
                          ? "certificate_email_modal_subtitle_report"
                          : "certificate_email_modal_subtitle",
                      ),
                    }),
                    (0, i.jsxs)("span", {
                      className:
                        "mx-auto mt-4 inline-flex h-10 max-w-full animate-hero-fade items-center gap-2 rounded-[var(--ds-semantic-radius-pill)] border border-[var(--ds-semantic-color-border-default)] bg-[var(--ds-semantic-color-surface-raised)] px-4 [animation-delay:250ms] motion-reduce:animate-none",
                      children: [
                        (0, i.jsx)(t.default, {
                          size: 16,
                          className: "shrink-0 text-[var(--ds-semantic-color-accent-base)]",
                          "aria-hidden": !0,
                        }),
                        (0, i.jsx)("span", {
                          dir: "ltr",
                          className:
                            "truncate text-[length:var(--ds-primitive-typography-scale-body-sm-font-size)] font-semibold leading-[var(--ds-primitive-typography-scale-body-sm-line-height)] text-[var(--ds-semantic-color-text-primary)]",
                          children: n,
                        }),
                      ],
                    }),
                    (0, i.jsx)("p", {
                      className:
                        "mt-4 text-[length:var(--ds-primitive-typography-scale-note-font-size)] leading-[var(--ds-primitive-typography-scale-note-line-height)] text-[var(--ds-semantic-color-text-subtle)]",
                      children: c("certificate_email_modal_hint"),
                    }),
                    (0, i.jsx)(s.ButtonComponent, {
                      className: "mt-6",
                      fullWidth: !0,
                      onClick: () => {
                        m({ isModalVisible: !1, modalComponent: null });
                      },
                      size: "lg",
                      children: c("btn_got_it"),
                    }),
                  ],
                }),
              ],
            });
          },
        ],
        247162,
      ));
  },
  498487,
  function (e) {
    e.n(e.i(247162));
  },
  317197,
  231529,
  (e) => {
    "use strict";
    var i = e.i(843476),
      t = e.i(882983),
      a = e.i(742214),
      s = e.i(663615);
    e.i(680460);
    var r = e.i(885944);
    (e.s([], 317197),
      e.s(
        [
          "ModalBodyComponent",
          0,
          (e) => {
            let {
              children: o,
              title: l,
              subtitle: n,
              className: d = "",
              bodyClassName: c,
              titleClassName: m,
            } = e;
            return (0, i.jsx)(a.ModalContent, {
              className: d,
              children: (0, i.jsxs)(t.ModalBody, {
                className: (0, s.cn)(
                  "flex h-full w-full flex-col gap-5 p-5 antialiased md:p-6 [@media(max-height:580px)]:gap-3 [@media(max-height:580px)]:p-4",
                  c,
                ),
                children: [
                  (l || n) &&
                    (0, i.jsx)(r.ModalHeaderComponent, { title: l, subtitle: n, titleClassName: m }),
                  o,
                ],
              }),
            });
          },
        ],
        231529,
      ));
  },
]);
