(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  473503,
  (e) => {
    "use strict";
    let t, i, n;
    var a = e.i(843476);
    e.i(361313);
    var l = e.i(140830);
    e.i(507192);
    var r = e.i(889572);
    e.i(470618);
    var s = e.i(786116);
    let o = ["text_pattern_2_4_8_16", "text_missing_15"],
      d = { word: "memorize-word", number: "memorize-number", "second-word": "memorize-second-word" },
      m = "btn_continue",
      c = {
        1: {
          title: "quiz_page_quiz_get_motivation_title_1",
          body: "quiz_page_quiz_get_motivation_description_1",
        },
        2: {
          title: "quiz_page_quiz_get_motivation_title_2",
          body: "quiz_page_quiz_get_motivation_description_2",
        },
        3: {
          title: "quiz_page_quiz_get_motivation_title_3",
          body: "quiz_page_quiz_get_motivation_description_3",
        },
        4: {
          title: "quiz_page_quiz_get_motivation_title_4",
          body: "quiz_page_quiz_get_motivation_description_4",
        },
      },
      u = "primary";
    var x = e.i(271645);
    let h = "flex w-full items-center justify-center gap-2 md:gap-3",
      g = "flex aspect-square w-16 min-w-9 shrink items-center justify-center rounded-2xl bg-white md:w-20",
      p = "text-hp-display tabular-nums text-black-custom";
    var _ = e.i(20362),
      f = e.i(661852);
    let b = (e) => {
      let { screen: t, onComplete: i } = e,
        [n, l] = (0, x.useState)(t.countdownSeconds),
        [r, s] = (0, x.useState)(!1),
        o = (0, x.useRef)(null);
      ((0, x.useEffect)(() => {
        let e = window.setTimeout(() => {
          o.current?.focus({ preventScroll: !0 });
        }, 0);
        return () => {
          window.clearTimeout(e);
        };
      }, [t.id]),
        (0, x.useEffect)(() => {
          let e = window.setInterval(() => {
              l((e) => (e > 1 ? e - 1 : 1));
            }, _.FUNNEL_SEQUENCE_TICK_MS),
            n = window.setTimeout(() => {
              i();
            }, t.countdownSeconds * _.FUNNEL_SEQUENCE_TICK_MS),
            a = window.setTimeout(() => {
              s(!0);
            }, 50);
          return () => {
            (window.clearInterval(e), window.clearTimeout(n), window.clearTimeout(a));
          };
        }, [t.countdownSeconds, t.id, i]));
      let d = (0, f.splitCountdownTemplate)(t.countdownTemplate),
        m = t.sequence.split("");
      return (0, a.jsxs)("div", {
        className: "mx-auto flex w-full max-w-lg flex-col items-center text-center md:max-w-xl",
        children: [
          (0, a.jsx)("h1", {
            ref: o,
            tabIndex: -1,
            className: "text-balance text-hp-h2 text-black-custom lg:text-hp-h2-lg focus:outline-none",
            children: t.title,
          }),
          (0, a.jsxs)("div", {
            className: "mt-6 flex w-fit max-w-full flex-col md:mt-8",
            children: [
              (0, a.jsxs)("div", {
                className: "flex w-full flex-col rounded-2xl bg-slate-100/[0.88] p-4 md:p-5",
                children: [
                  (0, a.jsx)("p", {
                    "aria-label": f.QUIZ_SEQUENCE_LABEL,
                    className: h,
                    children: m.map((e, t) =>
                      (0, a.jsx)(
                        "span",
                        { className: g, children: (0, a.jsx)("span", { className: p, children: e }) },
                        t,
                      ),
                    ),
                  }),
                  (0, a.jsx)("span", {
                    "aria-hidden": !0,
                    className: "mt-4 h-0.5 w-full overflow-hidden rounded-full bg-slate-200 md:mt-5",
                    children: (0, a.jsx)("span", {
                      className:
                        "block h-full w-full origin-left rounded-full bg-slate-500 transition-transform ease-linear motion-reduce:hidden",
                      style: {
                        transform: r ? "scaleX(0)" : "scaleX(1)",
                        transitionDuration: `${t.countdownSeconds * _.FUNNEL_SEQUENCE_TICK_MS}ms`,
                      },
                    }),
                  }),
                ],
              }),
              (0, a.jsxs)("p", {
                "aria-live": "polite",
                "data-countdown": !0,
                className: "mt-3 text-hp-body-sm text-grey-light md:mt-4",
                children: [
                  d.before,
                  (0, a.jsx)("strong", {
                    className: "font-semibold tabular-nums text-grey-deep",
                    children: n,
                  }),
                  d.after,
                ],
              }),
            ],
          }),
        ],
      });
    };
    e.i(279866);
    var w = e.i(899948);
    let v = "funnel-prompt",
      y =
        "text-balance text-hp-h2 max-xs-sm:text-[1.25rem] max-xs-sm:leading-[1.5rem] tabular-nums text-black-custom lg:text-hp-h2-lg",
      k = (e) => {
        let { screen: t, selected: i, shouldFocusOnMount: n = !1, onSelect: l } = e,
          [r, s] = (0, x.useState)(2);
        return (
          (0, x.useEffect)(() => {
            let e = window.matchMedia("(min-width: 768px)"),
              t = () => {
                s(e.matches ? 3 : 2);
              };
            return (
              t(),
              e.addEventListener("change", t),
              () => {
                e.removeEventListener("change", t);
              }
            );
          }, []),
          (0, a.jsxs)("div", {
            className: "mx-auto flex w-full max-w-lg flex-col gap-5 text-center md:max-w-2xl md:gap-6",
            children: [
              (0, a.jsx)("h1", { id: v, className: y, children: t.title }),
              (0, a.jsx)(w.FunnelOptionGroupComponent, {
                kind: "image",
                imageVariant: "portrait",
                labelledBy: v,
                columns: r,
                layoutClassName: "grid grid-cols-2 gap-3 md:grid-cols-3 md:gap-4",
                options: t.options.map((e) => e.src),
                imageLabels: t.options.map((e) => e.name),
                selected: i,
                shouldFocusOnMount: n,
                onSelect: l,
              }),
            ],
          })
        );
      },
      j = (e) => {
        let { screen: t, selected: i, shouldFocusOnMount: n, onSelect: l } = e;
        return (0, a.jsxs)("div", {
          className:
            "mx-auto grid w-full max-w-lg grid-cols-1 gap-5 max-xs-sm:gap-3 md:max-w-xl md:gap-6 lg:max-w-none lg:grid-cols-[30rem_24rem] lg:grid-rows-[auto_auto] lg:items-center lg:justify-center lg:gap-x-16 lg:gap-y-6",
          children: [
            (0, a.jsx)("div", {
              className: "lg:col-start-1 lg:row-span-2 lg:row-start-1",
              children: (0, a.jsx)("div", {
                className: "overflow-hidden rounded-2xl border border-slate-200 bg-white",
                children: (0, a.jsx)("img", {
                  "data-figure": !0,
                  src: t.questionImage,
                  alt: f.QUIZ_FIGURE_ALT,
                  "aria-hidden": !0,
                  draggable: !1,
                  decoding: "sync",
                  width: 464,
                  height: 352,
                  className:
                    "mx-auto block h-auto max-h-[40dvh] max-xs-sm:max-h-[26dvh] w-full object-contain lg:max-h-none",
                }),
              }),
            }),
            (0, a.jsx)("div", {
              className: "text-center lg:col-start-2 lg:row-start-1 lg:self-end",
              children: (0, a.jsx)("h1", {
                id: v,
                className: "block text-balance text-hp-body-sm text-black-custom lg:text-hp-lede",
                children: t.prompt,
              }),
            }),
            (0, a.jsx)("div", {
              className: "lg:col-start-2 lg:row-start-2 lg:self-start",
              children: (0, a.jsx)(w.FunnelOptionGroupComponent, {
                kind: "image",
                labelledBy: v,
                flow: "column",
                columns: 2,
                rows: _.OPTION_IMAGE_ROWS,
                layoutClassName:
                  "grid grid-flow-col grid-cols-2 grid-rows-3 gap-3 max-xs-sm:gap-2 md:gap-4 lg:gap-3",
                options: t.options.map((e) => e.src),
                selected: i,
                shouldFocusOnMount: n,
                onSelect: l,
              }),
            }),
          ],
        });
      };
    var N = e.i(948148);
    e.i(791371);
    var C = e.i(642448);
    e.i(900206);
    var E = e.i(669509);
    let S = (e) => {
      let { screen: t, onContinue: i } = e,
        n = (0, N.useTranslations)(),
        l = (0, x.useRef)(null);
      (0, x.useEffect)(() => {
        let e = window.setTimeout(() => {
          l.current?.focus({ preventScroll: !0 });
        }, 0);
        return () => {
          window.clearTimeout(e);
        };
      }, [t.id]);
      let r = t.isTokenNumeric;
      return (0, a.jsxs)("div", {
        className: "mx-auto flex w-full max-w-lg flex-col items-center text-center md:max-w-xl lg:max-w-2xl",
        children: [
          (0, a.jsx)("h1", {
            ref: l,
            tabIndex: -1,
            className: "text-balance text-hp-h2 text-black-custom focus:outline-none lg:text-hp-h2-lg",
            children: t.title,
          }),
          (0, a.jsx)("p", {
            className: "mt-3 max-w-md text-pretty text-hp-lede text-grey-deep md:mt-4 md:max-w-lg",
            children: t.subtitle,
          }),
          (0, a.jsx)("div", {
            className: r
              ? "mt-6 flex w-full items-center justify-center rounded-3xl bg-slate-100/[0.88] p-4 md:mt-8 md:p-5"
              : "mt-6 flex w-full items-center justify-center rounded-3xl bg-slate-100/[0.88] px-6 py-10 md:mt-8 md:py-14",
            children: r
              ? (0, a.jsx)("p", {
                  "aria-label": t.token,
                  className: h,
                  children: t.token
                    .split("")
                    .map((e, t) =>
                      (0, a.jsx)(
                        "span",
                        {
                          "aria-hidden": !0,
                          className: g,
                          children: (0, a.jsx)("span", { className: p, children: e }),
                        },
                        t,
                      ),
                    ),
                })
              : (0, a.jsx)("p", {
                  className:
                    "text-balance text-[2.5rem] font-semibold leading-[2.75rem] text-black-custom xs-m:text-hp-display-lg md:text-hp-hero-lg",
                  children: t.token,
                }),
          }),
          (0, a.jsxs)("p", {
            className: "mt-3 flex items-center justify-center gap-2 md:mt-4",
            children: [
              (0, a.jsx)(E.IconClock, { className: "size-4 shrink-0 text-grey-deep" }),
              (0, a.jsx)("span", {
                className: "text-hp-body-sm text-grey-deep",
                children: n("ab_myiq_quiz_redesign_memorize_ready"),
              }),
            ],
          }),
          (0, a.jsx)(C.DemoButton, {
            size: "lg",
            variant: "primary",
            className: "mt-8 w-full md:mt-10 md:w-auto md:min-w-[16rem]",
            onClick: i,
            children: n("ab_myiq_quiz_redesign_memorize_cta"),
          }),
        ],
      });
    };
    e.i(743893);
    var q = e.i(852016),
      z = e.i(68641);
    let T = "mt-8 max-xs-sm:mt-4 flex w-full flex-col items-center md:mt-10",
      I = "block h-auto w-full",
      A = "text-[0.6em] leading-none",
      O = `${z.FUNNEL_CTA_STICKY} mt-10 max-xs-sm:mt-5 md:mt-12`,
      L = z.FUNNEL_CTA_STICKY_FADE,
      F = "#006FEE",
      R = "#FFFFFF",
      M = "M14 110 A96 96 0 0 1 206 110",
      U = "#E2E8F0",
      D = [-90, -18, 54, 126, 198],
      $ = [
        [56, 44, 50, 28, 40],
        [40, 56, 34, 48, 52],
        [50, 36, 56, 42, 30],
      ],
      Q = [64, 64, 64, 64, 64],
      B = [
        { x: 70, y: 98, width: 40, height: 34 },
        { x: 110, y: 82, width: 40, height: 50 },
        { x: 150, y: 108, width: 40, height: 24 },
      ],
      P = ["#F1F5F9", "#F8FAFC", "#F1F5F9"],
      W = "podium-glint-clip",
      H = (e) => {
        let { card: t } = e;
        return (0, a.jsx)("div", {
          className: T,
          children: (0, a.jsx)("div", {
            role: "img",
            "aria-label": t.vizLabel,
            className: "w-[170px] max-xs-sm:w-[115px] max-w-full md:w-[190px]",
            children: (0, a.jsxs)("svg", {
              "aria-hidden": !0,
              focusable: "false",
              viewBox: "68 24 124 124",
              className: "block h-auto w-full overflow-visible",
              children: [
                (0, a.jsx)("circle", {
                  cx: 130,
                  cy: 86,
                  r: 44,
                  fill: "#E8F2FD",
                  className:
                    "opacity-0 origin-center animate-bolt-flash [animation-delay:380ms] [transform-box:fill-box] motion-reduce:animate-none",
                }),
                (0, a.jsx)("circle", {
                  cx: 130,
                  cy: 86,
                  r: 40,
                  fill: "none",
                  stroke: U,
                  strokeWidth: 1.5,
                  className:
                    "origin-center animate-bolt-breathe [transform-box:fill-box] motion-reduce:animate-none",
                }),
                (0, a.jsx)("circle", {
                  cx: 130,
                  cy: 86,
                  r: 56,
                  fill: "none",
                  stroke: "#CBD5E1",
                  strokeWidth: 1.5,
                  strokeDasharray: "2 5",
                  className:
                    "origin-center animate-bolt-spin [transform-box:fill-box] motion-reduce:animate-none",
                }),
                (0, a.jsx)("polygon", {
                  points: "141,42 106,94 126,94 117,130 154,76 133,76",
                  fill: F,
                  stroke: F,
                  strokeWidth: 3,
                  strokeLinejoin: "round",
                  className:
                    "origin-center animate-bolt-strike [animation-delay:80ms] [transform-box:fill-box] motion-reduce:animate-none",
                }),
              ],
            }),
          }),
        });
      };
    var K = e.i(861745),
      G = e.i(19576),
      V = e.i(413769);
    let Y = (e) => Math.round(10 * e) / 10,
      Z = (e) => Math.round(100 * e) / 100,
      X = Z(96 * Math.PI),
      J = (e) =>
        e.map((e, t) => {
          let i;
          return {
            x: Y(130 + e * Math.cos(((i = D[t]) * Math.PI) / 180)),
            y: Y(84 + e * Math.sin((i * Math.PI) / 180)),
          };
        }),
      ee = (e) => e.map((e) => `${e.x},${e.y}`).join(" "),
      et = ee(J(Q)),
      ei = ee(J([32, 32, 32, 32, 32])),
      en = J(Q),
      ea = J($[0]),
      el = ee(ea),
      er =
        ((t = (() => {
          let e = [[...$[0]]];
          for (let t of [$[1], $[2], $[0]])
            for (let i = 0; i < D.length; i += 1) {
              let n = [...e[e.length - 1]];
              ((n[i] = t[i]), e.push(n));
            }
          return e;
        })()),
        (i = []),
        (n = 0),
        t.forEach((e, a) => {
          let l = a % D.length == 0 ? 1.2 : 0.35,
            r = J(e);
          (i.push({ time: n, points: r }, { time: n + l, points: r }), (n += l + 0.3 * (a < t.length - 1)));
        }),
        i),
      es = er[er.length - 1].time,
      eo = (e) => {
        if (e <= 0) return 0;
        if (e >= 1) return 1;
        let t = (e, t, i) => 3 * e * (1 - i) * (1 - i) * i + 3 * t * (1 - i) * i * i + i * i * i,
          i = 0,
          n = 1;
        for (let a = 0; a < 24; a += 1) {
          let a = (i + n) / 2;
          t(0.4, 0.2, a) < e ? (i = a) : (n = a);
        }
        return t(0, 1, (i + n) / 2);
      },
      ed = (e) => {
        let { card: t } = e,
          i = (0, K.useLocale)(),
          n = (0, G.getIsPercentSignFirst)(i);
        return (0, a.jsxs)("div", {
          className: T,
          children: [
            (0, a.jsxs)("div", {
              role: "img",
              "aria-label": t.vizLabel,
              className: "relative w-[220px] max-xs-sm:w-[145px] max-w-full md:w-[260px]",
              children: [
                (0, a.jsxs)("svg", {
                  "aria-hidden": !0,
                  focusable: "false",
                  viewBox: "0 0 220 122",
                  className: I,
                  children: [
                    (0, a.jsx)("path", {
                      d: M,
                      fill: "none",
                      stroke: U,
                      strokeWidth: 6,
                      strokeLinecap: "round",
                    }),
                    (0, a.jsx)("path", {
                      d: M,
                      fill: "none",
                      stroke: F,
                      strokeWidth: 6,
                      strokeLinecap: "round",
                      strokeDasharray: X,
                      strokeDashoffset: Z(X * (1 - t.percent / 100)),
                      className: "animate-gauge-sweep [animation-delay:80ms] motion-reduce:animate-none",
                    }),
                  ],
                }),
                (0, a.jsx)("div", {
                  "aria-hidden": !0,
                  className:
                    "absolute bottom-[5%] left-1/2 -translate-x-1/2 text-hp-stat tabular-nums text-blue-custom md:text-hp-stat-lg",
                  children: (0, a.jsxs)("span", {
                    className: "inline-flex items-baseline",
                    children: [
                      n && (0, a.jsx)("span", { className: A, children: "%" }),
                      (0, a.jsx)("span", {
                        className:
                          "inline-block h-[1.15em] -mb-[0.075em] overflow-hidden [-webkit-mask-image:linear-gradient(to_bottom,transparent_0,#000_16%,#000_84%,transparent_100%)] [mask-image:linear-gradient(to_bottom,transparent_0,#000_16%,#000_84%,transparent_100%)]",
                        children: (0, a.jsx)("span", {
                          className:
                            "block pt-[0.075em] animate-gauge-roll [animation-delay:80ms] motion-reduce:animate-none",
                          style: { transform: `translateY(-${t.percent}em)` },
                          children: Array.from({ length: t.percent + 1 }, (e, t) => t).map((e) =>
                            (0, a.jsx)(
                              "span",
                              { className: "block h-[1em] text-center leading-none", children: e },
                              e,
                            ),
                          ),
                        }),
                      }),
                      !n && (0, a.jsx)("span", { className: A, children: "%" }),
                    ],
                  }),
                }),
              ],
            }),
            (0, a.jsxs)("div", {
              "aria-hidden": !0,
              className:
                "mt-1 flex w-[220px] max-xs-sm:w-[145px] max-w-full justify-between px-2 text-hp-caption text-grey-light md:w-[260px]",
              children: [
                (0, a.jsx)("span", { children: t.axisLeft }),
                (0, a.jsx)("span", { children: t.axisRight }),
              ],
            }),
          ],
        });
      },
      em = (e) => {
        let { card: t } = e;
        return (0, a.jsx)("div", {
          className: T,
          children: (0, a.jsx)("div", {
            role: "img",
            "aria-label": t.vizLabel,
            className: "w-[190px] max-xs-sm:w-[130px] max-w-full md:w-[212px]",
            children: (0, a.jsxs)("svg", {
              "aria-hidden": !0,
              focusable: "false",
              viewBox: "66 34 128 102",
              className: I,
              children: [
                (0, a.jsxs)("g", {
                  className:
                    "origin-center animate-podium-hop [animation-delay:80ms] [transform-box:fill-box] motion-reduce:animate-none",
                  children: [
                    (0, a.jsx)("circle", { cx: 130, cy: 52, r: 6.6, fill: F }),
                    (0, a.jsx)("rect", { x: 119, y: 60.8, width: 22, height: 16.5, rx: 10, fill: F }),
                  ],
                }),
                B.map((e, t) =>
                  (0, a.jsx)(
                    "rect",
                    {
                      x: e.x,
                      y: e.y,
                      width: e.width,
                      height: e.height,
                      rx: 6,
                      fill: P[t],
                      stroke: U,
                      strokeWidth: 1.5,
                    },
                    e.x,
                  ),
                ),
                (0, a.jsx)("text", {
                  x: 130,
                  y: 111,
                  textAnchor: "middle",
                  fontSize: 13,
                  fontWeight: 600,
                  fill: "#94A3B8",
                  children: t.topLabel,
                }),
                (0, a.jsx)("clipPath", {
                  id: W,
                  children: B.map((e) =>
                    (0, a.jsx)("rect", { x: e.x, y: e.y, width: e.width, height: e.height }, e.x),
                  ),
                }),
                (0, a.jsx)("g", {
                  clipPath: `url(#${W})`,
                  children: (0, a.jsx)("rect", {
                    x: -30,
                    y: 70,
                    width: 26,
                    height: 80,
                    fill: R,
                    className:
                      "opacity-0 origin-center animate-podium-glint [transform-box:fill-box] motion-reduce:animate-none",
                  }),
                }),
              ],
            }),
          }),
        });
      },
      ec = (e) => {
        let t,
          { card: i } = e,
          n = (0, x.useRef)(null);
        return (
          (t = (() => {
            let [e, t] = (0, x.useState)(!0);
            return (
              (0, x.useEffect)(() => {
                let e = window.matchMedia("(prefers-reduced-motion: reduce)"),
                  i = () => {
                    t(!e.matches);
                  };
                return (
                  i(),
                  e.addEventListener("change", i),
                  () => {
                    e.removeEventListener("change", i);
                  }
                );
              }, []),
              e
            );
          })()),
          (0, x.useEffect)(() => {
            if (!t) return;
            let e = n.current;
            if (null === e) return;
            let i = e.querySelector("polygon"),
              a = Array.from(e.querySelectorAll("circle")),
              l = performance.now(),
              r = 0,
              s = (e) => {
                let t = ((e) => {
                  let t = ((e % es) + es) % es;
                  for (let e = 0; e < er.length - 1; e += 1) {
                    let i = er[e],
                      n = er[e + 1];
                    if (t > n.time) continue;
                    if (i.points === n.points || n.time === i.time) return i.points;
                    let a = eo((t - i.time) / (n.time - i.time));
                    return i.points.map((e, t) => ({
                      x: e.x + (n.points[t].x - e.x) * a,
                      y: e.y + (n.points[t].y - e.y) * a,
                    }));
                  }
                  return er[er.length - 1].points;
                })((e - l) / 1e3);
                (i?.setAttribute("points", ee(t)),
                  a.forEach((e, i) => {
                    (e.setAttribute("cx", `${t[i].x}`), e.setAttribute("cy", `${t[i].y}`));
                  }),
                  (r = window.requestAnimationFrame(s)));
              };
            return (
              (r = window.requestAnimationFrame(s)),
              () => {
                (window.cancelAnimationFrame(r),
                  i?.setAttribute("points", el),
                  a.forEach((e, t) => {
                    (e.setAttribute("cx", `${ea[t].x}`), e.setAttribute("cy", `${ea[t].y}`));
                  }));
              }
            );
          }, [t, n]),
          (0, a.jsx)("div", {
            className: T,
            children: (0, a.jsx)("div", {
              role: "img",
              "aria-label": i.vizLabel,
              className: "w-[207px] max-xs-sm:w-[135px] max-w-full md:w-[234px]",
              children: (0, a.jsxs)("svg", {
                "aria-hidden": !0,
                focusable: "false",
                viewBox: "63 14 134 128",
                className: I,
                children: [
                  (0, a.jsx)("polygon", { points: et, fill: "none", stroke: U, strokeWidth: 1 }),
                  (0, a.jsx)("polygon", { points: ei, fill: "none", stroke: U, strokeWidth: 1 }),
                  en.map((e) =>
                    (0, a.jsx)(
                      "line",
                      { x1: 130, y1: 84, x2: e.x, y2: e.y, stroke: U, strokeWidth: 1 },
                      `${e.x}-${e.y}`,
                    ),
                  ),
                  (0, a.jsxs)("g", {
                    ref: n,
                    className:
                      "origin-center animate-profile-pop [animation-delay:80ms] [transform-box:fill-box] motion-reduce:animate-none",
                    children: [
                      (0, a.jsx)("polygon", {
                        points: el,
                        fill: F,
                        fillOpacity: 0.12,
                        stroke: F,
                        strokeWidth: 1.5,
                        strokeLinejoin: "round",
                      }),
                      ea.map((e, t) => {
                        let i = 3 === t;
                        return (0, a.jsx)(
                          "circle",
                          {
                            cx: e.x,
                            cy: e.y,
                            r: i ? 3.5 : 3,
                            fill: i ? R : F,
                            stroke: i ? F : void 0,
                            strokeWidth: i ? 1.5 : void 0,
                          },
                          `${e.x}-${e.y}`,
                        );
                      }),
                    ],
                  }),
                ],
              }),
            }),
          })
        );
      };
    e.i(922342);
    var eu = e.i(162278);
    let ex = (e) => {
      let { screen: t, percent: i, countryCode: n, onContinue: l } = e,
        r = (0, N.useTranslations)(),
        s = (0, x.useRef)(null);
      (0, x.useEffect)(() => {
        let e = window.setTimeout(() => {
          s.current?.focus({ preventScroll: !0 });
        }, 0);
        return () => {
          window.clearTimeout(e);
        };
      }, [t.id]);
      let o = ((e, t, i, n) => {
        let a, l;
        return 1 === e && null !== t
          ? { readout: "bolt", vizLabel: n("ab_myiq_quiz_redesign_motivational_vizlabel_bolt") }
          : 2 === e && null !== t
            ? {
                readout: "podium",
                vizLabel: n("ab_myiq_quiz_redesign_motivational_vizlabel_podium"),
                topLabel: n("checkout_myiq_hero_top"),
              }
            : 3 === e
              ? { readout: "radar", vizLabel: n("ab_myiq_quiz_redesign_motivational_vizlabel_radar") }
              : {
                  readout: "gauge",
                  percent: (l = Math.round(
                    ((a = Math.max(0, Math.min(V.QUIZ_FLOW_TOTAL_COUNTED, i - 1))) /
                      V.QUIZ_FLOW_TOTAL_COUNTED) *
                      100,
                  )),
                  axisLeft: n("ab_myiq_quiz_redesign_motivational_axis_start"),
                  axisRight: n("ab_myiq_quiz_redesign_motivational_axis_finish"),
                  vizLabel: n("ab_myiq_quiz_redesign_motivational_vizlabel_gauge", {
                    percent: l,
                    answered: a,
                    total: V.QUIZ_FLOW_TOTAL_COUNTED,
                  }),
                };
      })(t.screenNumber, i, t.railCurrent, r);
      return (0, a.jsxs)("div", {
        className: "mx-auto flex w-full max-w-lg flex-col items-center text-center md:max-w-xl lg:max-w-2xl",
        children: [
          (0, a.jsxs)("h1", {
            ref: s,
            tabIndex: -1,
            className:
              "text-balance text-hp-h2 max-xs-sm:text-[1.25rem] max-xs-sm:leading-[1.5rem] tabular-nums text-black-custom focus:outline-none lg:text-hp-h2-lg",
            children: [
              (0, a.jsx)(eu.FunnelTokensComponent, {
                tokens: t.titleTokens,
                highlightClassName: "text-blue-custom",
              }),
              "country" === t.percentSource &&
                (0, a.jsx)(q.Flag, {
                  "aria-hidden": !0,
                  alt: "",
                  code: n,
                  className:
                    "mb-1 ml-2 inline-block h-5 w-[30px] lg:h-6 lg:w-9 rounded object-cover align-middle outline outline-1 -outline-offset-1 outline-black/[.12]",
                }),
            ],
          }),
          "gauge" === o.readout && (0, a.jsx)(ed, { card: o }),
          "bolt" === o.readout && (0, a.jsx)(H, { card: o }),
          "podium" === o.readout && (0, a.jsx)(em, { card: o }),
          "radar" === o.readout && (0, a.jsx)(ec, { card: o }),
          (0, a.jsx)("p", {
            className:
              "mt-6 max-xs-sm:mt-3 max-w-md text-pretty text-hp-lede max-xs-sm:text-[0.875rem] max-xs-sm:leading-[1.25rem] tabular-nums text-grey-deep md:mt-8 md:max-w-lg",
            children: t.body,
          }),
          (0, a.jsxs)("div", {
            className: O,
            children: [
              (0, a.jsx)("span", { "aria-hidden": !0, className: L }),
              (0, a.jsx)(C.DemoButton, {
                size: "lg",
                variant: "primary",
                className: "w-full md:w-auto md:min-w-[16rem]",
                onClick: l,
                children: t.cta,
              }),
            ],
          }),
        ],
      });
    };
    e.i(771699);
    var eh = e.i(571365),
      eh = eh;
    let eg = [
        "border-slate-300 bg-emerald-50 [@media(hover:hover)]:hover:border-slate-400 [@media(hover:hover)]:hover:bg-emerald-100/60",
        "border-slate-300 bg-emerald-50/60 [@media(hover:hover)]:hover:border-slate-400 [@media(hover:hover)]:hover:bg-emerald-50",
        "border-slate-300 bg-amber-50/70 [@media(hover:hover)]:hover:border-slate-400 [@media(hover:hover)]:hover:bg-amber-50",
        "border-slate-300 bg-rose-50/60 [@media(hover:hover)]:hover:border-slate-400 [@media(hover:hover)]:hover:bg-rose-50",
        "border-slate-300 bg-rose-50 [@media(hover:hover)]:hover:border-slate-400 [@media(hover:hover)]:hover:bg-rose-100/60",
      ],
      ep = (e) => {
        let {
            screen: t,
            selected: i,
            shouldFocusOnMount: n,
            onSelect: l,
            onSubmit: r,
            isSubmitDisabled: s = !1,
          } = e,
          o = (0, x.useRef)(null),
          d = "reveal-submit" === t.advance && null !== i;
        return (
          (0, x.useEffect)(() => {
            if (!d) return;
            let e = window.setTimeout(() => {
              o.current?.scrollIntoView({ block: "nearest", behavior: "smooth" });
            }, 0);
            return () => {
              window.clearTimeout(e);
            };
          }, [d]),
          (0, a.jsxs)("div", {
            className:
              "mx-auto flex w-full max-w-lg flex-col items-center gap-5 max-xs-sm:gap-3 text-center md:gap-6",
            children: [
              (0, a.jsx)("h1", { id: v, className: y, children: t.title }),
              (0, a.jsx)(w.FunnelOptionGroupComponent, {
                kind: "text",
                labelledBy: v,
                columns: 1,
                layoutClassName: "mx-auto flex w-full max-w-md flex-col gap-3 max-xs-sm:gap-2",
                options: t.options.map((e) => e.label),
                restClassNames: "likert" === t.variant ? eg : void 0,
                showBadge: "likert" !== t.variant,
                selected: i,
                shouldFocusOnMount: n,
                onSelect: l,
              }),
              "reveal-submit" === t.advance &&
                null !== t.submitCta &&
                (0, a.jsxs)("div", {
                  ref: o,
                  className: d
                    ? "mx-auto mt-3 flex w-full max-w-md flex-col items-center gap-3 md:mt-4"
                    : "invisible mx-auto mt-3 flex w-full max-w-md flex-col items-center gap-3 md:mt-4",
                  children: [
                    (0, a.jsx)(C.DemoButton, {
                      size: "lg",
                      variant: "primary",
                      disabled: s,
                      isLoading: s,
                      className: "w-full",
                      onClick: r,
                      children: t.submitCta,
                    }),
                    null !== t.submitNote &&
                      (0, a.jsx)("p", {
                        className: "text-pretty text-hp-body-sm text-grey-light",
                        children: t.submitNote,
                      }),
                  ],
                }),
            ],
          })
        );
      },
      e_ = (e) => {
        let {
          screen: t,
          selectedIndex: i,
          isSubmitDisabled: n,
          isAgeQuestion: l,
          motivationPercent: r,
          motivationCountryName: s,
          motivationCountryCode: o,
          onQuestionSelect: d,
          onAgeSelect: m,
          onHeroSelect: c,
          onSubmit: u,
          onSequenceComplete: x,
          onWordRecallIntroContinue: h,
          onSecondWordIntroContinue: g,
          onNumberRecallIntroContinue: p,
          onMotivationContinue: _,
          onTestimonialsContinue: f,
        } = e;
        return (0, a.jsxs)("div", {
          "data-screen": t.id,
          "data-kind": t.kind,
          children: [
            "image" === t.kind &&
              (0, a.jsx)(j, { screen: t, selected: i, shouldFocusOnMount: !1, onSelect: d }),
            "text" === t.kind &&
              (0, a.jsx)(ep, {
                screen: t,
                selected: i,
                shouldFocusOnMount: !1,
                onSelect: l ? m : d,
                onSubmit: u,
                isSubmitDisabled: n,
              }),
            "digit-sequence" === t.kind && (0, a.jsx)(b, { screen: t, onComplete: x }),
            "memorize" === t.kind &&
              (0, a.jsx)(S, { screen: t, onContinue: { word: h, "second-word": g, number: p }[t.variant] }),
            "motivational" === t.kind &&
              (0, a.jsx)(ex, { screen: t, percent: r, countryName: s, countryCode: o, onContinue: _ }),
            "reviews" === t.kind && (0, a.jsx)(eh.default, { screen: t, onContinue: f }),
            "hero" === t.kind &&
              (0, a.jsx)(k, { screen: t, selected: null, shouldFocusOnMount: !1, onSelect: c }),
          ],
        });
      };
    var ef = e.i(174080);
    e.i(381069);
    var eb = e.i(468387);
    e.i(118360);
    var ew = e.i(45180),
      ev = e.i(643449);
    e.i(165037);
    var ey = e.i(98636),
      ek = e.i(527154),
      ej = e.i(567697);
    e.i(367148);
    var eN = e.i(480164),
      eC = e.i(775367),
      eE = e.i(523173),
      eS = e.i(866897),
      eq = e.i(157273);
    e.i(910661);
    var ez = e.i(642871),
      eT = e.i(924254),
      eI = e.i(190899),
      eA = e.i(915113),
      eO = e.i(493598);
    e.i(470366);
    var eL = e.i(504001);
    let eF = (e) => {
        let t = e?.type,
          i = t?.src;
        return "string" == typeof i ? i : "";
      },
      eR = (e) => Object.keys(e).find((e) => 1 === e.length) ?? "A",
      eM = (e) => {
        let {
          order: t,
          id: i,
          position: n,
          baseId: a,
          total: l,
          railCurrent: r,
          isCounted: s,
          isTimerVisible: o,
        } = e;
        return {
          order: t,
          id: i,
          isCounted: s,
          position: n,
          baseId: a,
          counterText: s && null !== n ? `${n} of ${l}` : null,
          railCurrent: r,
          isTimerVisible: o,
        };
      },
      eU = (e) => {
        let {
          variant: t,
          token: i,
          isTokenNumeric: n,
          title: a,
          subtitle: l,
          cta: r,
          total: s,
          railCurrent: o,
        } = e;
        return {
          ...eM({
            order: o,
            id: d[t],
            position: null,
            baseId: null,
            total: s,
            railCurrent: o,
            isCounted: !1,
            isTimerVisible: !0,
          }),
          kind: "memorize",
          variant: t,
          title: a,
          token: i,
          isTokenNumeric: n,
          subtitle: l,
          cta: r,
          advance: "cta",
        };
      },
      eD = (e, t) => {
        let i = RegExp(`<${t}>([\\s\\S]*?)</${t}>`, "g"),
          n = [],
          a = 0,
          l = i.exec(e);
        for (; null !== l;)
          (l.index > a && n.push({ kind: "text", text: e.slice(a, l.index) }),
            n.push({ kind: "highlight", text: l[1] }),
            (a = l.index + l[0].length),
            (l = i.exec(e)));
        return (a < e.length && n.push({ kind: "text", text: e.slice(a) }), n);
      },
      e$ = (e, t) =>
        Object.entries(t).reduce((e, t) => {
          let [i, n] = t;
          return e.split(`{${i}}`).join(n);
        }, e);
    e.s(
      [
        "default",
        0,
        (e) => {
          let t,
            i,
            {
              screen: n,
              total: d,
              currentQuestionId: h,
              secondsPassed: g,
              isLoading: p,
              showAgeQuestion: _,
              motivationPercent: b,
              motivationCountryName: w,
              motivationCountryCode: v,
              announcement: y,
              selectedIndex: k,
              handleQuestionSelect: j,
              handleAgeOptionSelect: C,
              handleHeroSelect: E,
              handleSequenceComplete: S,
              handleWordRecallIntroContinue: q,
              handleSecondWordIntroComplete: z,
              handleNumberRecallIntroComplete: T,
              handleShowResultsClick: I,
              handleMotivationContinue: A,
              handleTestimonialsContinue: O,
            } = ((e) => {
              var t;
              let i,
                n,
                a,
                {
                  isProfile: l = !1,
                  userProfile: r,
                  experiments: s = {},
                  isBrainTrain: d,
                  useRetakeQuestions: h,
                  isUsUkTraffic: g,
                } = e,
                p = (0, N.useTranslations)(),
                {
                  currentQuestionId: _,
                  activeQuestion: b,
                  allQuestions: w,
                  showResultButton: v,
                  isShowMotivation: y,
                  isShowTestimonials: k,
                  showHeroAfterTestimonials: j,
                  handleHeroAfterTestimonialsContinue: C,
                  isLoading: E,
                  selectedOption: S,
                  userData: q,
                  showAgeQuestion: z,
                  handleAgeSelect: T,
                  showSecondWordIntro: I,
                  handleSecondWordIntroComplete: A,
                  showNumberRecallIntro: O,
                  handleNumberRecallIntroComplete: L,
                  handleSelectOption: F,
                  handleShowResultsClick: R,
                  handleTestimonialsContinue: M,
                  handleMotivationContinue: U,
                  isProfile: D,
                } = (0, ey.useQuizModuleService)({
                  userProfile: r,
                  isProfile: l,
                  experiments: s,
                  isBrainTrain: d,
                  useRetakeQuestions: h,
                  isUsUkTraffic: g,
                  isRedesignFunnel: !0,
                }),
                $ = (0, ez.useQuizStore)((e) => e.secondsPassed),
                [Q, B] = (0, x.useState)(() => (l || h ? "done" : "memorize")),
                [P, W] = (0, x.useState)(null),
                [H, K] = (0, x.useState)(null),
                [G, V] = (0, x.useState)(null),
                Y = q?.currency?.countryCode || "US",
                Z = (0, ej.getCountryData)("name", q) || Y,
                X = w.length,
                J = (0, ew.getMotivationQuestionIds)(X, d),
                [ee, et] = J;
              ((0, x.useEffect)(() => {
                y && V((0, ew.getOrGeneratePercentage)(_, ee, et, q));
              }, [y, _, ee, et, q]),
                (0, x.useEffect)(() => {
                  let e = (e) => {
                    v || e.preventDefault();
                  };
                  return (
                    window.addEventListener("beforeunload", e),
                    () => window.removeEventListener("beforeunload", e)
                  );
                }, [v]),
                (0, eA.getIsMarketingSource)() &&
                  (0, eN.getQuizHeroImages)().forEach((e) =>
                    (0, ef.preload)(e.src, { as: "image", fetchPriority: "low" }),
                  ),
                (0, ek.getQuizImageSrcs)(w).forEach((e) =>
                  (0, ef.preload)(e, { as: "image", fetchPriority: "low" }),
                ),
                (t = (0, ek.getQuizImageSrcs)(
                  -1 === (i = w.findIndex((e) => e.id === _)) ? [] : w.slice(i, i + 2 + 1),
                )),
                (n = (0, x.useRef)(new Map())),
                (a = t.join("|")),
                (0, x.useEffect)(() => {
                  t.forEach((e) => {
                    if (n.current.has(e)) return;
                    let t = new Image();
                    ((t.fetchPriority = "high"),
                      (t.src = e),
                      t.decode().catch(() => void 0),
                      n.current.set(e, t));
                  });
                }, [a]));
              let ei = (0, x.useCallback)((e) => String(p.raw(e) ?? ""), [p]),
                en = (0, x.useCallback)(() => {
                  ("with_analytics" === s.ftMemorizeContinueAnalyticsRedesign &&
                    (0, eL.trackClientEvents)({
                      event: eE.EAnalyticEvents.QUIZ_CONTINUE,
                      params: { question_number: _, screen_type: "memorize" },
                      user: q,
                    }),
                    B("done"));
                }, [s.ftMemorizeContinueAnalyticsRedesign, _, q]),
                ea = "memorize" === Q && !y && !(k || j),
                el = null != b && "icons" in b,
                er = el ? (b.icons?.options ?? []).map((e) => eR(e)) : [],
                es = el ? [] : (b?.answers ?? []),
                eo = !el && b?.memorizationSequence ? b.memorizationSequence : null,
                ed = null !== eo && P !== b?.id,
                em = D ? p("btn_see_report") : p("quiz_get_my_results"),
                ec = p("quiz_do_you_want_to_confirm"),
                eu = Math.min(_, X),
                ex = D && _ === X,
                eh = (0, x.useCallback)(
                  (e, t) => {
                    if (!t) return;
                    let i = el ? er[e] : es[e];
                    void 0 !== i && F(i);
                  },
                  [el, er, es, F],
                ),
                eg = (0, x.useCallback)(
                  (e, t) => {
                    t && (K(e), T(eb.US_UK_AGE_GROUPS_ORDER[e] ?? eb.US_UK_DEFAULT_AGE_GROUP));
                  },
                  [T],
                ),
                ep = (0, x.useCallback)(() => {
                  W(b?.id ?? null);
                }, [b?.id]),
                e_ = (0, x.useCallback)(
                  (e, t) => {
                    if (!t) return;
                    let i = eN.CHOOSE_YOUR_HERO_CELEBRITIES[e];
                    void 0 !== i &&
                      (eI.accessSessionStorageUtil.setItem(eq.StorageKeys.SELECTED_HERO_ID, i.id),
                      eT.accessCookie.setItem(eS.ECookieArg.SELECTED_HERO_ID, i.id, { session: !0 }),
                      C());
                  },
                  [C],
                ),
                eQ = (() => {
                  if (y) {
                    let e = ((e, t) => {
                        let [i, n, , a] = t;
                        return void 0 !== a && e === a ? 4 : e === i ? 1 : e === n ? 2 : 3;
                      })(_, J),
                      t = String(X - _ + 1),
                      i = c[e] ?? c[3],
                      n = e$(ei(i.title).replace(RegExp("<img>[\\s\\S]*?</img>", "g"), ""), {
                        percent: String(G ?? ""),
                        country: (0, ej.getCountryData)("name", q),
                        numberOfQuestionsLeft: t,
                      }),
                      a = e$(ei(i.body).replace(/<\/?[a-zA-Z][\w-]*>/g, ""), {
                        answeredPercent: String(Math.round(((_ - 1) / (X || 1)) * 100)),
                        numberOfQuestionsLeft: t,
                      });
                    return ((e) => {
                      let { screenNumber: t, titleTokens: i, body: n, cta: a, total: l, railCurrent: r } = e;
                      return {
                        ...eM({
                          order: r,
                          id: `motivational-${t}`,
                          position: null,
                          baseId: null,
                          total: l,
                          railCurrent: r,
                          isCounted: !1,
                          isTimerVisible: !1,
                        }),
                        kind: "motivational",
                        screenNumber: t,
                        illustration: "",
                        titleTokens: i,
                        body: n,
                        cta: a,
                        percentSource: 1 === t ? "speed" : 2 === t ? "country" : null,
                        advance: "cta",
                      };
                    })({
                      screenNumber: e,
                      titleTokens: eD(n, "span"),
                      body: a,
                      cta: p(m),
                      total: X,
                      railCurrent: eu,
                    });
                  }
                  if (j) {
                    let e;
                    return {
                      ...eM({
                        order:
                          (e = {
                            title: p("choose_your_hero_title"),
                            options: eN.CHOOSE_YOUR_HERO_CELEBRITIES.map((e) => ({
                              id: e.id,
                              name: (0, eO.getIsGoogleTraffic)() ? void 0 : p(`choose_your_hero_${e.id}`),
                              src: eN.CHOOSE_YOUR_HERO_IMAGE_MAP[e.id].src,
                            })),
                            total: X,
                          }).total + 3,
                        id: "choose-your-hero",
                        position: null,
                        baseId: null,
                        total: e.total,
                        railCurrent: e.total,
                        isCounted: !1,
                        isTimerVisible: !0,
                      }),
                      kind: "hero",
                      title: e.title,
                      options: e.options.map((e) => ({ id: e.id, name: e.name, src: e.src })),
                      advance: "auto",
                    };
                  }
                  if (k) {
                    let e;
                    return {
                      ...eM({
                        order:
                          (e = {
                            titleTokens: eD(ei("quiz_page_testimonials_title"), u),
                            reviewHeadline: p("quiz_page_testimonials_finding_my_iq_was"),
                            reviewBody: p("quiz_page_testimonials_been_many_many_years_since"),
                            reviewAuthor: p("quiz_page_testimonials_author_name"),
                            reviewAuthorSeparator: "·",
                            reviewAuthorRole: p("quiz_page_testimonials_verified_customer"),
                            testsTakenTokens: eD(ei("quiz_page_testimonials_tests_taken"), u),
                            trustedTokens: eD(ei("quiz_page_testimonials_trusted"), u),
                            featuredIn: p("logo_scroller_featured_in"),
                            cta: p(m),
                            total: X,
                          }).total + 2,
                        id: "reviews",
                        position: null,
                        baseId: null,
                        total: e.total,
                        railCurrent: e.total,
                        isCounted: !1,
                        isTimerVisible: !1,
                      }),
                      kind: "reviews",
                      titleTokens: e.titleTokens,
                      reviewHeadline: e.reviewHeadline,
                      reviewBody: e.reviewBody,
                      reviewAuthor: e.reviewAuthor,
                      reviewAuthorSeparator: e.reviewAuthorSeparator,
                      reviewAuthorRole: e.reviewAuthorRole,
                      testsTakenTokens: e.testsTakenTokens,
                      trustedTokens: e.trustedTokens,
                      featuredIn: e.featuredIn,
                      cta: e.cta,
                      advance: "cta",
                    };
                  }
                  if (ea)
                    return eU({
                      variant: "word",
                      token: p(eb.WORD_RECALL_INTRO_WORD),
                      isTokenNumeric: !1,
                      title: p("quiz_page_ab_myiq_word_recall_intro_title"),
                      subtitle: p("quiz_page_ab_myiq_word_recall_intro_subtitle"),
                      cta: p(m),
                      total: X,
                      railCurrent: eu,
                    });
                  if (I)
                    return eU({
                      variant: "second-word",
                      token: p(eb.WORD_RECALL_2ND_WORD),
                      isTokenNumeric: !1,
                      title: p("quiz_page_ab_myiq_word_recall_2nd_intro_title"),
                      subtitle: p("quiz_page_ab_myiq_word_recall_2nd_intro_subtitle"),
                      cta: p(m),
                      total: X,
                      railCurrent: eu,
                    });
                  if (O)
                    return eU({
                      variant: "number",
                      token: eC.NUMBER_RECALL_NUMBER,
                      isTokenNumeric: !0,
                      title: p("ab_myiq_number_recall_intro_title"),
                      subtitle: p("ab_myiq_number_recall_intro_subtitle"),
                      cta: p(m),
                      total: X,
                      railCurrent: eu,
                    });
                  if (z)
                    return ((e) => {
                      let { title: t, answers: i, total: n, railCurrent: a, submitCta: l, submitNote: r } = e;
                      return {
                        ...eM({
                          order: n + 1,
                          id: "age-question",
                          position: null,
                          baseId: 34,
                          total: n,
                          railCurrent: a,
                          isCounted: !1,
                          isTimerVisible: !0,
                        }),
                        kind: "text",
                        variant: "age",
                        title: t,
                        options: i.map((e, t) => ({ index: t, label: e })),
                        correctAnswer: null,
                        isNumeric: !1,
                        advance: "reveal-submit",
                        submitCta: l,
                        submitNote: r,
                      };
                    })({
                      title: p("what_is_your_age"),
                      answers: (0, eb.getUsUkAgeAnswers)(),
                      total: X,
                      railCurrent: X,
                      submitCta: em,
                      submitNote: ec,
                    });
                  if (null == b) return null;
                  if (ed && !el && null !== eo)
                    return ((e) => {
                      let {
                        question: t,
                        currentQuestionId: i,
                        total: n,
                        title: a,
                        countdownTemplate: l,
                        countdownSeconds: r,
                      } = e;
                      return {
                        ...eM({
                          order: i,
                          id: `sequence-${t.id}`,
                          position: i,
                          baseId: t.baseId ?? null,
                          total: n,
                          railCurrent: i,
                          isCounted: !0,
                          isTimerVisible: !0,
                        }),
                        kind: "digit-sequence",
                        title: a,
                        sequence: t.memorizationSequence ?? "",
                        countdownTemplate: l,
                        countdownSeconds: r,
                        recallScreenId: `question-${t.id}`,
                        advance: "timer",
                      };
                    })({
                      question: b,
                      currentQuestionId: _,
                      total: X,
                      title: p("quiz_page_ab_myiq_memorization_intro_title"),
                      countdownTemplate: ei("quiz_page_ab_myiq_memorization_disappears_in_seconds").replace(
                        /<\/?[a-zA-Z][\w-]*>/g,
                        "",
                      ),
                      countdownSeconds: b.memorizationDurationSeconds ?? ev.DEFAULT_DISPLAY_DURATION_SECONDS,
                    });
                  let e = {
                    currentQuestionId: _,
                    total: X,
                    imagePrompt:
                      "v3_disperse_taskline" === s.abMyiqQuizChaosBlockQ1122
                        ? p("quiz_page_ab_myiq_chaos_block_task_heading")
                        : p("quiz_choose_answer"),
                    submitCta: ex ? em : null,
                    submitNote: ex ? ec : null,
                  };
                  return el
                    ? ((e) => {
                        let { question: t, currentQuestionId: i, total: n, imagePrompt: a } = e,
                          l = (t.icons?.options ?? []).map((e) => {
                            let t = eR(e);
                            return { letter: t, src: eF(e[t]) };
                          });
                        return {
                          ...eM({
                            order: i,
                            id: `question-${t.id}`,
                            position: i,
                            baseId: t.baseId ?? null,
                            total: n,
                            railCurrent: i,
                            isCounted: !0,
                            isTimerVisible: !0,
                          }),
                          kind: "image",
                          prompt: a,
                          questionImage: eF(t.icons?.question),
                          options: l,
                          correctAnswer: t.correctAnswer,
                          advance: "auto",
                        };
                      })({ ...e, question: b })
                    : ((e) => {
                        let t,
                          { question: i, currentQuestionId: n, total: a, submitCta: l, submitNote: r } = e,
                          s = (i.answers ?? []).map((e, t) => ({ index: t, label: e }));
                        return {
                          ...eM({
                            order: n,
                            id: `question-${i.id}`,
                            position: n,
                            baseId: i.baseId ?? null,
                            total: a,
                            railCurrent: n,
                            isCounted: !0,
                            isTimerVisible: !0,
                          }),
                          kind: "text",
                          variant: i.memorizationSequence
                            ? "digit-recall"
                            : "recall_cognitive" === i.questionKey
                              ? "word-recall"
                              : 34 === i.baseId
                                ? "age"
                                : 35 === i.baseId
                                  ? "education"
                                  : !1 === i.isDefaultColor
                                    ? "likert"
                                    : i.questionKey && o.includes(i.questionKey)
                                      ? "number-pattern"
                                      : "riddle",
                          title: "string" == typeof (t = i.title) ? t : "",
                          options: s,
                          correctAnswer: i.correctAnswer ?? null,
                          isNumeric: (i.answers ?? []).every((e) => /^\d+$/.test(e)),
                          advance: null === l ? "auto" : "reveal-submit",
                          submitCta: l,
                          submitNote: r,
                        };
                      })({ ...e, question: b });
                })();
              return {
                screen: eQ,
                total: X,
                currentQuestionId: _,
                secondsPassed: $,
                isLoading: E,
                showAgeQuestion: z,
                motivationPercent: G,
                motivationCountryName: Z,
                motivationCountryCode: Y,
                announcement:
                  null === eQ || null === eQ.counterText
                    ? ""
                    : (0, f.formatQuestionAnnouncement)(eQ.counterText),
                selectedIndex: ((e) => {
                  let {
                    screen: t,
                    selectedAgeIndex: i,
                    selectedOption: n,
                    imageOptionLetters: a,
                    textAnswers: l,
                  } = e;
                  if (null === t) return null;
                  if ("text" === t.kind && "age" === t.variant) return i;
                  let r = "image" === t.kind ? a.indexOf(n) : "text" === t.kind ? l.indexOf(n) : -1;
                  return -1 === r ? null : r;
                })({
                  screen: eQ,
                  selectedAgeIndex: H,
                  selectedOption: S,
                  imageOptionLetters: er,
                  textAnswers: es,
                }),
                handleQuestionSelect: eh,
                handleAgeOptionSelect: eg,
                handleHeroSelect: e_,
                handleSequenceComplete: ep,
                handleWordRecallIntroContinue: en,
                handleSecondWordIntroComplete: A,
                handleNumberRecallIntroComplete: L,
                handleShowResultsClick: R,
                handleMotivationContinue: U,
                handleTestimonialsContinue: M,
              };
            })(e);
          return (0, a.jsxs)("div", {
            className: "flex h-dvh flex-col overflow-hidden bg-white antialiased",
            children: [
              (0, a.jsx)("div", {
                className: "hidden",
                "aria-hidden": !0,
                children: (0, a.jsx)(s.QuizTimerComponent, {}),
              }),
              (0, a.jsx)(l.FunnelHeaderComponent, {
                isCounterVisible: null !== n && null !== n.counterText,
                counterCurrent: n?.position ?? h,
                counterTotal: d,
                railCurrent: n?.railCurrent ?? h,
                railTotal: d,
                isTimerVisible: null !== n && n.isTimerVisible,
                clock:
                  ((i = Math.floor((t = Math.max(0, Math.floor(g))) / 60)),
                  `${String(i).padStart(2, "0")}:${String(t % 60).padStart(2, "0")}`),
                isClockLive: !0,
                brandHref: null,
              }),
              (0, a.jsxs)("main", {
                className: "flex min-h-0 flex-1 flex-col",
                children: [
                  (0, a.jsx)("p", {
                    "aria-live": "polite",
                    "aria-atomic": "true",
                    className: "sr-only",
                    children: y,
                  }),
                  (0, a.jsx)(r.FunnelStageComponent, {
                    scrollResetKey: n?.id,
                    children:
                      null !== n &&
                      (0, a.jsx)(
                        e_,
                        {
                          screen: n,
                          selectedIndex: k,
                          isSubmitDisabled: p,
                          isAgeQuestion: _,
                          motivationPercent: b,
                          motivationCountryName: w,
                          motivationCountryCode: v,
                          onQuestionSelect: j,
                          onAgeSelect: C,
                          onHeroSelect: E,
                          onSubmit: I,
                          onSequenceComplete: S,
                          onWordRecallIntroContinue: q,
                          onSecondWordIntroContinue: z,
                          onNumberRecallIntroContinue: T,
                          onMotivationContinue: A,
                          onTestimonialsContinue: O,
                        },
                        n.id,
                      ),
                  }),
                ],
              }),
            ],
          });
        },
      ],
      473503,
    );
  },
  527154,
  (e) => {
    "use strict";
    let t = (e) => {
      let t = e?.type,
        i = t?.src;
      return "string" == typeof i ? i : void 0;
    };
    e.s([
      "getQuizImageSrcs",
      0,
      (e) => {
        let i = new Set();
        return (
          e.forEach((e) => {
            let { icons: n, stimulusImage: a } = e,
              l = t(n?.question);
            l && i.add(l);
            let r = t(a);
            (r && i.add(r),
              n?.options?.forEach((e) => {
                Object.values(e).forEach((e) => {
                  let n = t(e);
                  n && i.add(n);
                });
              }));
          }),
          [...i]
        );
      },
    ]);
  },
  367148,
  (e) => {
    "use strict";
    let t = (0, e.i(770703).default)(() => e.A(722619), { loadableGenerated: { modules: [215302] } });
    e.s(["ChooseYourHeroComponent", 0, t]);
  },
]);
