(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  262389,
  (e) => {
    "use strict";
    var a = e.i(976218),
      t = e.i(273830),
      i = e.i(620253),
      r = e.i(75540),
      s = e.i(843476),
      l = (0, t.forwardRef)((e, t) => {
        var l;
        let { as: n, className: o, children: d, ...u } = e,
          p = (0, i.useDOMRef)(t),
          { slots: c, classNames: m } = (0, a.useCardContext)(),
          y = (0, r.clsx)(null == m ? void 0 : m.footer, o);
        return (0, s.jsx)(n || "div", {
          ref: p,
          className: null == (l = c.footer) ? void 0 : l.call(c, { class: y }),
          ...u,
          children: d,
        });
      });
    ((l.displayName = "HeroUI.CardFooter"), e.s(["card_footer_default", 0, l]));
  },
  901775,
  (e) => {
    "use strict";
    var a = e.i(262389);
    e.s(["CardFooter", () => a.card_footer_default]);
  },
  872225,
  (e) => {
    "use strict";
    var a = e.i(503259);
    e.s(
      [
        "Autoplay",
        0,
        function (e) {
          let t,
            i,
            r,
            s,
            l,
            n,
            o,
            d,
            u,
            p,
            { swiper: c, extendParams: m, on: y, emit: v, params: g } = e;
          ((c.autoplay = { running: !1, paused: !1, timeLeft: 0 }),
            m({
              autoplay: {
                enabled: !1,
                delay: 3e3,
                waitForTransition: !0,
                disableOnInteraction: !1,
                stopOnLastSlide: !1,
                reverseDirection: !1,
                pauseOnMouseEnter: !1,
              },
            }));
          let f = g && g.autoplay ? g.autoplay.delay : 3e3,
            h = g && g.autoplay ? g.autoplay.delay : 3e3,
            x = new Date().getTime();
          function w(e) {
            !c ||
              c.destroyed ||
              !c.wrapperEl ||
              e.target !== c.wrapperEl ||
              (c.wrapperEl.removeEventListener("transitionend", w),
              p || (e.detail && e.detail.bySwiperTouchMove) || I());
          }
          let b = () => {
              if (c.destroyed || !c.autoplay.running) return;
              c.autoplay.paused ? (s = !0) : s && ((h = r), (s = !1));
              let e = c.autoplay.paused ? r : x + h - new Date().getTime();
              ((c.autoplay.timeLeft = e),
                v("autoplayTimeLeft", e, e / f),
                (i = requestAnimationFrame(() => {
                  b();
                })));
            },
            j = (e) => {
              if (c.destroyed || !c.autoplay.running) return;
              (cancelAnimationFrame(i), b());
              let a = void 0 === e ? c.params.autoplay.delay : e;
              ((f = c.params.autoplay.delay), (h = c.params.autoplay.delay));
              let s = (() => {
                let e;
                if (
                  (e =
                    c.virtual && c.params.virtual.enabled
                      ? c.slides.find((e) => e.classList.contains("swiper-slide-active"))
                      : c.slides[c.activeIndex])
                )
                  return parseInt(e.getAttribute("data-swiper-autoplay"), 10);
              })();
              (!Number.isNaN(s) && s > 0 && void 0 === e && ((a = s), (f = s), (h = s)), (r = a));
              let l = c.params.speed,
                n = () => {
                  c &&
                    !c.destroyed &&
                    (c.params.autoplay.reverseDirection
                      ? !c.isBeginning || c.params.loop || c.params.rewind
                        ? (c.slidePrev(l, !0, !0), v("autoplay"))
                        : c.params.autoplay.stopOnLastSlide ||
                          (c.slideTo(c.slides.length - 1, l, !0, !0), v("autoplay"))
                      : !c.isEnd || c.params.loop || c.params.rewind
                        ? (c.slideNext(l, !0, !0), v("autoplay"))
                        : c.params.autoplay.stopOnLastSlide || (c.slideTo(0, l, !0, !0), v("autoplay")),
                    c.params.cssMode &&
                      ((x = new Date().getTime()),
                      requestAnimationFrame(() => {
                        j();
                      })));
                };
              return (
                a > 0
                  ? (clearTimeout(t),
                    (t = setTimeout(() => {
                      n();
                    }, a)))
                  : requestAnimationFrame(() => {
                      n();
                    }),
                a
              );
            },
            N = () => {
              ((x = new Date().getTime()), (c.autoplay.running = !0), j(), v("autoplayStart"));
            },
            S = () => {
              ((c.autoplay.running = !1), clearTimeout(t), cancelAnimationFrame(i), v("autoplayStop"));
            },
            T = (e, a) => {
              if (c.destroyed || !c.autoplay.running) return;
              (clearTimeout(t), e || (u = !0));
              let i = () => {
                (v("autoplayPause"),
                  c.params.autoplay.waitForTransition
                    ? c.wrapperEl.addEventListener("transitionend", w)
                    : I());
              };
              if (((c.autoplay.paused = !0), a)) {
                (d && (r = c.params.autoplay.delay), (d = !1), i());
                return;
              }
              ((r = (r || c.params.autoplay.delay) - (new Date().getTime() - x)),
                (c.isEnd && r < 0 && !c.params.loop) || (r < 0 && (r = 0), i()));
            },
            I = () => {
              (c.isEnd && r < 0 && !c.params.loop) ||
                c.destroyed ||
                !c.autoplay.running ||
                ((x = new Date().getTime()),
                u ? ((u = !1), j(r)) : j(),
                (c.autoplay.paused = !1),
                v("autoplayResume"));
            },
            O = () => {
              if (c.destroyed || !c.autoplay.running) return;
              let e = (0, a.g)();
              ("hidden" === e.visibilityState && ((u = !0), T(!0)), "visible" === e.visibilityState && I());
            },
            E = (e) => {
              "mouse" !== e.pointerType || ((u = !0), (p = !0), c.animating || c.autoplay.paused || T(!0));
            },
            L = (e) => {
              "mouse" === e.pointerType && ((p = !1), c.autoplay.paused && I());
            };
          (y("init", () => {
            c.params.autoplay.enabled &&
              (c.params.autoplay.pauseOnMouseEnter &&
                (c.el.addEventListener("pointerenter", E), c.el.addEventListener("pointerleave", L)),
              (0, a.g)().addEventListener("visibilitychange", O),
              N());
          }),
            y("destroy", () => {
              (c.el &&
                "string" != typeof c.el &&
                (c.el.removeEventListener("pointerenter", E), c.el.removeEventListener("pointerleave", L)),
                (0, a.g)().removeEventListener("visibilitychange", O),
                c.autoplay.running && S());
            }),
            y("_freeModeStaticRelease", () => {
              (n || u) && I();
            }),
            y("_freeModeNoMomentumRelease", () => {
              c.params.autoplay.disableOnInteraction ? S() : T(!0, !0);
            }),
            y("beforeTransitionStart", (e, a, t) => {
              !c.destroyed &&
                c.autoplay.running &&
                (t || !c.params.autoplay.disableOnInteraction ? T(!0, !0) : S());
            }),
            y("sliderFirstMove", () => {
              if (!c.destroyed && c.autoplay.running) {
                if (c.params.autoplay.disableOnInteraction) return void S();
                ((l = !0),
                  (n = !1),
                  (u = !1),
                  (o = setTimeout(() => {
                    ((u = !0), (n = !0), T(!0));
                  }, 200)));
              }
            }),
            y("touchEnd", () => {
              if (!c.destroyed && c.autoplay.running && l) {
                if ((clearTimeout(o), clearTimeout(t), c.params.autoplay.disableOnInteraction)) {
                  ((n = !1), (l = !1));
                  return;
                }
                (n && c.params.cssMode && I(), (n = !1), (l = !1));
              }
            }),
            y("slideChange", () => {
              !c.destroyed && c.autoplay.running && (d = !0);
            }),
            Object.assign(c.autoplay, { start: N, stop: S, pause: T, resume: I }));
        },
      ],
      872225,
    );
  },
  928092,
  (e) => {
    "use strict";
    var a = e.i(492810);
    e.s(["IconRatingStarBold", () => a.default]);
  },
  250124,
  (e) => {
    "use strict";
    var a = e.i(178281);
    e.s(["IconSimpleArrow", () => a.default]);
  },
  911167,
  (e) => {
    "use strict";
    var a = e.i(843476),
      t = e.i(861745),
      i = e.i(271645),
      r = e.i(872225),
      s = e.i(980401),
      l = e.i(335889),
      n = e.i(926654),
      o = e.i(266027),
      d = e.i(600304);
    e.i(934337);
    var u = e.i(250124),
      p = e.i(948148),
      c = e.i(520837),
      m = e.i(876898),
      y = e.i(901775),
      v = e.i(592021),
      g = e.i(216933),
      g = g;
    e.i(376990);
    var f = e.i(338531),
      h = e.i(19576);
    let x = (e) => {
      let { review: i } = e,
        r = (0, p.useTranslations)(),
        s = (0, t.useLocale)(),
        l = (0, h.getLocaleDirection)(s);
      return (0, a.jsxs)(c.Card, {
        className:
          "h-full min-h-[190px] w-full gap-3 overflow-auto border-1 border-slate-200 p-6 !antialiased",
        shadow: "none",
        children: [
          (0, a.jsxs)(v.CardHeader, {
            className: "flex flex-col items-start gap-1 p-0",
            dir: l,
            children: [
              (0, a.jsxs)("div", {
                className: "flex items-center justify-start gap-2",
                children: [
                  (0, a.jsx)("p", {
                    className: "text-[18px] font-semibold text-dark-custom",
                    children: i?.name,
                  }),
                  (0, a.jsx)(f.RatingStarsComponent, { rating: i?.rating ?? 5, iconSize: 16 }),
                ],
              }),
              (0, a.jsxs)("div", {
                className: "flex gap-1.5",
                children: [
                  (0, a.jsx)(g.default, { className: "h-[15px] w-[15px]" }),
                  (0, a.jsx)("p", { className: "text-[11px]", children: r("review_verified_customer") }),
                ],
              }),
            ],
          }),
          (0, a.jsx)(m.CardBody, {
            className: "p-0 text-sm text-dark-custom !antialiased",
            dir: l,
            children: (0, a.jsx)("p", { className: "line-clamp-2", children: i?.review }),
          }),
          (0, a.jsxs)(y.CardFooter, {
            className: "flex justify-end rounded-b-none p-0 text-[11px]",
            dir: l,
            children: [i?.city && `${i?.city}, `, i?.time],
          }),
        ],
      });
    };
    e.i(344419);
    var w = e.i(155740);
    (e.s([], 887686),
      e.i(887686),
      e.s(
        [
          "CarouselNewComponent",
          0,
          (e) => {
            let { tag: p } = e,
              c = (0, t.useLocale)(),
              { data: m } = (0, o.useQuery)((0, d.reviewsGeneralQueryOptions)(c, p)),
              [y, v] = (0, i.useState)(null),
              g = (0, w.useAutoplayInView)(y);
            return (0, a.jsxs)("div", {
              ref: g,
              className: "grid w-full grid-cols-[auto_1fr_auto] items-center",
              dir: "ltr",
              children: [
                (0, a.jsx)(l.Button, {
                  onPress: () => y?.slidePrev(),
                  "aria-label": "previous button",
                  className: "rotate-180 bg-transparent text-[#317873] [&_svg]:h-5 [&_svg]:w-5",
                  isIconOnly: !0,
                  size: "sm",
                  radius: "sm",
                  disableRipple: !0,
                  children: (0, a.jsx)(u.IconSimpleArrow, {}),
                }),
                (0, a.jsx)(s.Swiper, {
                  onSwiper: (e) => v(e),
                  direction: "horizontal",
                  modules: [r.Autoplay],
                  slidesPerView: "auto",
                  loop: m && m.length >= 3,
                  autoplay: { delay: 4e3, disableOnInteraction: !0 },
                  initialSlide: 1,
                  className: "!w-full",
                  speed: 1e3,
                  lazyPreloadPrevNext: 3,
                  edgeSwipeDetection: "prevent",
                  children:
                    m && y
                      ? m?.map((e, t) =>
                          (0, a.jsx)(
                            s.SwiperSlide,
                            {
                              className: "!h-auto p-2 md:!w-[50%] lg:!w-[33.3%]",
                              children: (0, a.jsx)(x, { review: e }),
                            },
                            `${t}-bonus-carousel`,
                          ),
                        )
                      : (0, a.jsx)("div", {
                          className:
                            "grid w-full grid-flow-col gap-2 [&>*:nth-child(1)]:block md:[&>*:nth-child(2)]:block lg:[&>*:nth-child(3)]:block [&>div]:hidden",
                          children: [void 0, void 0, void 0].map((e, t) =>
                            (0, a.jsx)(
                              n.Skeleton,
                              { className: "rounded-lg", children: (0, a.jsx)(x, { review: null }) },
                              t,
                            ),
                          ),
                        }),
                }),
                (0, a.jsx)(l.Button, {
                  onPress: () => y?.slideNext(),
                  "aria-label": "next button",
                  className: "bg-transparent text-[#317873] [&_svg]:h-5 [&_svg]:w-5",
                  isIconOnly: !0,
                  size: "sm",
                  radius: "sm",
                  disableRipple: !0,
                  children: (0, a.jsx)(u.IconSimpleArrow, {}),
                }),
              ],
            });
          },
        ],
        911167,
      ));
  },
  998909,
  function (e) {
    e.n(e.i(911167));
  },
  344419,
  155740,
  (e) => {
    "use strict";
    var a = e.i(271645);
    (e.s(
      [
        "useAutoplayInView",
        0,
        (e) => {
          let t = (0, a.useRef)(null),
            i = (0, a.useRef)(!1);
          return (
            (0, a.useEffect)(() => {
              let a = t.current,
                r = e?.autoplay;
              if (!a || !r || "u" < typeof IntersectionObserver) return;
              let s = new IntersectionObserver((e) => {
                let [a] = e;
                if (a.isIntersecting) {
                  if (!i.current) return;
                  ((i.current = !1), r.start());
                  return;
                }
                r.running && ((i.current = !0), r.stop());
              });
              return (s.observe(a), () => s.disconnect());
            }, [e]),
            t
          );
        },
      ],
      155740,
    ),
      e.s([], 344419));
  },
  376990,
  338531,
  (e) => {
    "use strict";
    var a = e.i(843476);
    e.i(934337);
    var t = e.i(779450),
      t = t,
      i = e.i(928092);
    (e.s([], 376990),
      e.s(
        [
          "RatingStarsComponent",
          0,
          (e) => {
            let { rating: r, iconSize: s, starsQuantity: l = 5, ownSize: n, iconType: o = "normal" } = e;
            return (0, a.jsx)("div", {
              className: "relative flex text-gray-300",
              children: Array(l)
                .fill("")
                ?.map((e, l) => {
                  let d;
                  return (0, a.jsxs)(
                    "div",
                    {
                      className: "relative",
                      style: { width: s + 2 * !n, height: s + 2 * !n },
                      children: [
                        "normal" === o
                          ? (0, a.jsx)(t.default, { width: s, height: s, className: "absolute" })
                          : (0, a.jsx)(i.IconRatingStarBold, { width: s, height: s, className: "absolute" }),
                        (0, a.jsx)("div", {
                          className: "absolute top-0 overflow-hidden text-[#f7b635]",
                          style: {
                            width:
                              l < (d = Math.floor(r))
                                ? "100%"
                                : l === d
                                  ? `${Math.round(100 * (r - d))}%`
                                  : "0%",
                          },
                          children:
                            "normal" === o
                              ? (0, a.jsx)(t.default, { width: s, height: s })
                              : (0, a.jsx)(i.IconRatingStarBold, { width: s, height: s }),
                        }),
                      ],
                    },
                    `start-qt-${l}`,
                  );
                }),
            });
          },
        ],
        338531,
      ));
  },
]);
