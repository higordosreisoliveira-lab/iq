(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  747329,
  119042,
  783670,
  366880,
  204821,
  191429,
  21353,
  27748,
  722337,
  (e) => {
    "use strict";
    var t,
      a,
      i,
      s,
      r,
      n,
      l,
      o,
      c,
      _,
      m,
      u,
      d,
      p,
      g,
      h,
      x,
      y,
      f = e.i(843476),
      b = e.i(520837),
      M = e.i(663615),
      v = e.i(449496),
      k = e.i(47252);
    e.i(934337);
    var w = e.i(599545);
    (e.s([], 747329),
      e.s(
        [
          "AdvantagesComponent",
          0,
          (e) => {
            let { advantagesList: t, funnel: a, isPaymentAboveFold: i } = e;
            return (0, f.jsx)("section", {
              className: `mx-auto grid items-center justify-items-center gap-5 bg-white ${"love_language" === a ? "relative max-sm:py-5 sm:gap-10 md:gap-10 lg:pb-10" : "sm:gap-10 md:gap-10"}`,
              children: (0, f.jsx)("div", {
                className: "z-10 grid w-full gap-5 md:grid-cols-2 md:gap-8",
                children: t.map((e) => {
                  let { title: t, children: s } = e;
                  return (0, f.jsxs)(
                    b.Card,
                    {
                      className: `mx-auto w-full max-w-2xl p-6 max-sm:px-3 lg:max-w-none ${"love_language" === a ? "text-love-grey" : "text-black"} ${((0, v.isMyiqVariant)(a) || "personality" === a) && "max-sm:border-none max-sm:shadow-none"} ${i ? "lg:border-none lg:shadow-none" : ""}`,
                      children: [
                        (0, f.jsx)("h6", {
                          className: `text-xl font-semibold leading-[1] max-md:text-center ${"love_language" === a ? "md:text-xl" : "md:text-1.5xl"}`,
                          children: t,
                        }),
                        (0, f.jsx)("ul", {
                          className: "mt-3.5 grid gap-3 md:mt-5",
                          children: s?.map((e) =>
                            (0, f.jsxs)(
                              "li",
                              {
                                className: `flex gap-2 text-sm ${"love_language" === a ? "" : "text-love-grey"}`,
                                children: [
                                  (0, f.jsx)(w.IconCheckmark, {
                                    className: (0, M.cn)(
                                      "h-6 w-6 shrink-0 rounded-[5px]",
                                      "love_language" === a
                                        ? "bg-[#f9efec] p-1.5 text-love-main"
                                        : "bg-[#ECF1F7] p-1.5 text-blue-600",
                                    ),
                                  }),
                                  (0, f.jsx)("span", {
                                    dangerouslySetInnerHTML: {
                                      __html: (0, k.sanitizeTranslationHtml)(e.title),
                                    },
                                  }),
                                ],
                              },
                              e.title,
                            ),
                          ),
                        }),
                      ],
                    },
                    `section-${t}`,
                  );
                }),
              }),
            });
          },
        ],
        119042,
      ));
    var P = e.i(948148);
    let A = (e, t) => {
      let a = t("checkout_page_faq_question_8"),
        i = t.raw("checkout_page_faq_answer_8"),
        s = t("checkout_page_faq_question_9"),
        r = t("checkout_page_faq_answer_9"),
        n = t("checkout_page_faq_question_7"),
        l = t("checkout_page_faq_answer_7");
      switch (e) {
        case "myiq":
          return [
            { question: s, answer: r },
            { question: n, answer: l },
            { question: a, answer: i },
          ];
        case "love_language":
          return [
            { question: t("checkout_page_faq_question_4"), answer: t("checkout_love_faq_answer_4_b") },
            { question: t("checkout_page_faq_question_7"), answer: t("checkout_page_faq_answer_7") },
            { question: a, answer: t.raw("checkout_personality_page_faq_answer_5") },
          ];
        case "personality":
        case "enneagram":
          return [
            {
              question: t("checkout_personality_page_faq_question_3"),
              answer: t("checkout_personality_page_faq_answer_3"),
            },
            {
              question: t("checkout_personality_page_faq_question_5"),
              answer: t.raw("checkout_personality_page_faq_answer_5"),
            },
          ];
        case "depression":
          return [
            {
              question: t("checkout_depression_faq_question_1"),
              answer: t("checkout_depression_faq_answer_1"),
            },
            {
              question: t("checkout_depression_faq_question_2"),
              answer: t("checkout_depression_faq_answer_2"),
            },
            {
              question: t("checkout_depression_faq_question_3"),
              answer: t("checkout_depression_faq_answer_3"),
            },
          ];
        case "autism":
          return [
            {
              question: t("checkout_autism_page_faq_question_1"),
              answer: t("checkout_autism_page_faq_answer_1"),
            },
            {
              question: t("checkout_autism_page_faq_question_2"),
              answer: t("checkout_autism_page_faq_answer_2"),
            },
            {
              question: t("checkout_autism_page_faq_question_3"),
              answer: t.raw("checkout_personality_page_faq_answer_5"),
            },
          ];
        default:
          return [];
      }
    };
    e.s(
      [
        "getBenefitSection",
        0,
        function (e, t) {
          let a = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
          switch (e) {
            case "myiq":
              return {
                title: t("how_you_will_benefit"),
                children: [
                  { title: t("benefits_section_1") },
                  { title: t("benefits_section_2") },
                  { title: t("benefits_section_3") },
                  {
                    title: t(a ? "build_lasting_cognitive_skills_with_daily_training" : "benefits_section_4"),
                  },
                ],
              };
            case "love_language":
              return {
                title: t("how_you_will_benefit"),
                children: [
                  { title: t("understand_how_you_show_affection") },
                  { title: t("improve_communication") },
                  { title: t("resolve_relationships_issues") },
                  { title: t("build_stronger_bonds") },
                  { title: t("boost_self_awareness") },
                ],
              };
            case "personality":
              return {
                title: t("lgbtq_what_your_report_includes"),
                children: [
                  { title: t("checkout_personality_page_benefits_title_1") },
                  { title: t("checkout_personality_page_benefits_title_2") },
                  { title: t("checkout_personality_page_benefits_title_3") },
                  { title: t("checkout_personality_page_benefits_title_4") },
                ],
              };
            case "depression":
              return {
                title: t("how_you_will_benefit"),
                children: [
                  { title: t("checkout_depression_benefit_1") },
                  { title: t("checkout_depression_benefit_2") },
                  { title: t("checkout_depression_benefit_3") },
                  { title: t("checkout_depression_benefit_4") },
                  { title: t("checkout_depression_benefit_5") },
                ],
              };
            case "autism":
              return {
                title: t("lgbtq_what_your_report_includes"),
                children: [
                  { title: t("checkout_autism_page_benefits_title_1") },
                  { title: t("checkout_autism_page_benefits_title_2") },
                  { title: t("checkout_autism_page_benefits_title_3") },
                  { title: t("checkout_autism_page_benefits_title_4") },
                ],
              };
            case "enneagram":
              return {
                title: t("lgbtq_what_your_report_includes"),
                children: [
                  { title: "Your exact Enneagram type out of 9 — with your wing" },
                  { title: "Your core strengths and blind spots, explained in plain language" },
                  { title: "How your type shows up in relationships and at work" },
                  { title: "Personalized growth areas to focus on first" },
                ],
              };
            default:
              return { title: t("how_you_will_benefit"), children: [] };
          }
        },
        "getCheckoutFAQ",
        0,
        A,
        "getLearnHowToSection",
        0,
        (e, t) => {
          switch (e) {
            case "myiq":
              return {
                title: t("learn_how_to"),
                children: [
                  { title: t("learn_how_to_section_1") },
                  { title: t("learn_how_to_section_2") },
                  { title: t("learn_how_to_section_3") },
                  { title: t("learn_how_to_section_4") },
                ],
              };
            case "love_language":
              return {
                title: t("learn_how_to"),
                children: [
                  { title: t("identify_your_love_style") },
                  { title: t("manage_love_blockers") },
                  { title: t("express_love") },
                  { title: t("develop_emotional_skills") },
                  { title: t("build_deeper_connections") },
                ],
              };
            case "personality":
              return {
                title: t("learn_how_to"),
                children: [
                  { title: t("checkout_personality_page_learn_how_title_1") },
                  { title: t("checkout_personality_page_learn_how_title_2") },
                  { title: t("checkout_personality_page_learn_how_title_3") },
                  { title: t("checkout_personality_page_learn_how_title_4") },
                ],
              };
            case "autism":
              return {
                title: t("learn_how_to"),
                children: [
                  { title: t("checkout_autism_page_learn_how_title_1") },
                  { title: t("checkout_autism_page_learn_how_title_2") },
                  { title: t("checkout_autism_page_learn_how_title_3") },
                  { title: t("checkout_autism_page_learn_how_title_4") },
                ],
              };
            case "depression":
              return {
                title: t("learn_how_to"),
                children: [
                  { title: t("checkout_depression_learn_1") },
                  { title: t("checkout_depression_learn_2") },
                  { title: t("checkout_depression_learn_3") },
                  { title: t("checkout_depression_learn_4") },
                ],
              };
            case "enneagram":
              return {
                title: t("learn_how_to"),
                children: [
                  { title: "Use your type’s strengths instead of fighting them" },
                  { title: "Spot the blind spots that hold you back" },
                  { title: "Communicate better with the people closest to you" },
                  { title: "Grow in the direction your type actually needs" },
                ],
              };
            default:
              return { title: t("learn_how_to"), children: [] };
          }
        },
      ],
      783670,
    );
    var j = e.i(579565),
      U = e.i(357196);
    let S = (e) => {
      let { qnaList: t, variant: a } = e,
        i = (0, P.useTranslations)();
      return (0, f.jsxs)("section", {
        className: "mx-auto grid w-full gap-5 text-left max-sm:gap-0 lg:grid-cols-[0.5fr_1fr] lg:gap-14",
        children: [
          (0, f.jsxs)("h2", {
            className: `md:leading-[49px]'} text-[28px] font-semibold leading-[33px] ${"love_language" === a ? "text-love-grey" : "text-[#2B2D42]"} max-lg:text-center md:mb-8 md:mt-5 md:text-[39px] lg:max-w-64`,
            children: [
              (0, f.jsx)("span", {
                className: "inline-block break-words md:hidden",
                children: i("reviews_page_faq_title_short"),
              }),
              (0, f.jsx)("span", {
                className: "hidden leading-[50px] md:inline-block",
                children: i("reviews_page_faq_title_full"),
              }),
            ],
          }),
          (0, f.jsx)(j.Accordion, {
            fullWidth: !0,
            keepContentMounted: !0,
            className: "max-md: !gap-0 !px-0 pt-4 max-sm:!pt-2",
            itemClasses: {
              base: "md:px-5 !shadow-none bg-transparent border-b-1 border-[#E5EBFA] !rounded-none",
              title: "font-semibold",
              trigger: "py-6",
              content: "pt-0 pb-6 text-sm md:text-base text-grey-custom",
              indicator: "text-lg text-[#2B2D42]",
            },
            items: t,
            selectionMode: "single",
            variant: "splitted",
            children: t?.map((e, t) =>
              (0, f.jsx)(
                U.AccordionItem,
                {
                  classNames: {
                    title: "font-medium text-[#2B2D42] md:text-lg sm:font-semibold}",
                    content: "text-grey-custom max-md:text-sm pt-0 pb-3 md:pb-6 rtl:text-right",
                    trigger: "py-3 md:py-[18px]",
                  },
                  className: "text-left",
                  title: e.question,
                  children: (0, f.jsx)("p", {
                    className: "[&_a]:text-primary [&_a]:underline",
                    dangerouslySetInnerHTML: { __html: (0, k.sanitizeTranslationHtml)(e.answer) },
                  }),
                },
                `faq-accordion-${t}`,
              ),
            ),
          }),
        ],
      });
    };
    (e.s([], 366880),
      e.s(
        [
          "FaqsSectionComponent",
          0,
          (e) => {
            let { variant: t, isPaymentSectionRepeated: a } = e,
              i = A(t, (0, P.useTranslations)());
            return (0, f.jsxs)("div", {
              className: (0, M.cn)(
                "relative w-full max-sm:pb-7 sm:pb-20 sm:pt-5 md:-mb-16",
                a ? "pb-10 pt-6" : "py-10",
              ),
              children: [
                (0, f.jsx)(S, { qnaList: i, variant: t }),
                "love_language" === t &&
                  (0, f.jsx)("span", {
                    className: "absolute left-[-50vw] top-0 z-[-1] order-4 h-full w-[200vw] bg-[#f9efec]",
                  }),
              ],
            });
          },
        ],
        204821,
      ));
    var q = e.i(271645),
      C = e.i(618566),
      E = e.i(157273),
      T = e.i(562942),
      I = e.i(190899),
      N = e.i(276394),
      R = e.i(876898),
      O = e.i(386847),
      V = e.i(725397);
    e.i(310443);
    var D = e.i(340557),
      L = e.i(204128),
      B = e.i(139989),
      F = e.i(695106),
      H = e.i(245847),
      G = e.i(400657);
    let z = [
        { icon: (0, f.jsx)(D.IconLogoBusinessWire, {}), link: "https://www.businesswire.com" },
        { icon: (0, f.jsx)(L.IconLogoDigitalTrends, {}), link: "https://www.digitaltrends.com" },
        { icon: (0, f.jsx)(B.IconLogoNewMsn, {}), link: "https://www.msn.com" },
        { icon: (0, f.jsx)(F.IconLogoNewsweek, {}), link: "https://www.newsweek.com" },
        { icon: (0, f.jsx)(H.IconLogoUSAToday, {}), link: "https://www.usatoday.com" },
        { icon: (0, f.jsx)(G.IconLogoYahooFinance, {}), link: "https://finance.yahoo.com" },
      ],
      Y = (e) => {
        let { trustItems: t, variant: a } = e;
        return (0, f.jsx)("ul", {
          className: "grid gap-2",
          children: t.map((e) =>
            (0, f.jsxs)(
              "li",
              {
                className: (0, M.cn)(
                  "flex items-start gap-2 [&_svg]:h-8 [&_svg]:w-8 [&_svg]:shrink-0",
                  "love_language" === a ? "[&_svg]:text-love-main" : "[&_svg]:text-primary-700",
                ),
                children: [
                  e.icon,
                  (0, f.jsxs)("div", {
                    children: [
                      (0, f.jsx)("h3", {
                        className: "text-start text-sm font-medium text-default-700",
                        children: e.title,
                      }),
                      (0, f.jsx)("p", {
                        className: (0, M.cn)("mt-1.5 text-start text-xs leading-tight text-default-600"),
                        children: e.subtitle,
                      }),
                    ],
                  }),
                ],
              },
              e.title,
            ),
          ),
        });
      },
      Q = (e) => {
        let {
            trustItems: t,
            user: a,
            variant: i,
            isApplovinParam: s,
            isPaymentAboveFold: r,
            rollbackUsRegion: n,
          } = e,
          l = (0, P.useTranslations)(),
          o = a?.currency?.countryCode,
          c = n ? (0, V.isUk)(o, (0, O.getClientCity)()) : (0, V.isUsUk)(o, (0, O.getClientCity)());
        return (0, f.jsx)(b.Card, {
          className: (0, M.cn)(
            "mx-auto h-fit w-full max-w-screen-sm bg-white p-6 subpixel-antialiased max-sm:px-3 lg:shrink-0 lg:flex-grow-0",
            ((0, v.isMyiqVariant)(i) || "personality" === i) && "max-sm:border-none max-sm:shadow-none",
            r && "lg:border-none lg:p-0 lg:px-6 lg:shadow-none",
          ),
          children: (0, f.jsxs)(R.CardBody, {
            className: "flex w-full flex-col items-start overflow-hidden p-0",
            children: [
              (0, f.jsxs)("div", {
                className: "grid gap-2",
                children: [
                  (0, f.jsx)("h2", {
                    className:
                      "mt-0 w-full text-left text-sm font-semibold uppercase tracking-tight text-gray-900 [&_span]:text-gray-900",
                    dangerouslySetInnerHTML: {
                      __html: (0, k.sanitizeTranslationHtml)(l.raw("checkout_page_why_trust")),
                    },
                  }),
                  (0, f.jsx)(Y, { trustItems: t, variant: i }),
                ],
              }),
              (0, f.jsxs)("div", {
                className: "mt-3 grid w-full gap-3",
                children: [
                  (0, f.jsx)("h4", {
                    className: "text-left text-sm font-semibold uppercase tracking-tight text-gray-900",
                    children: l("checkout_page_featured_in"),
                  }),
                  (0, f.jsx)("ul", {
                    className: "flex flex-wrap justify-center gap-4",
                    children: (s ? z.slice(2, 4) : z).map((e, t) =>
                      (0, f.jsx)(
                        "li",
                        {
                          className: "w-fit items-start text-[#a0a3a4] [&_svg]:h-5 [&_svg]:shrink-0",
                          children: e.icon,
                        },
                        `${t}-partner-logo`,
                      ),
                    ),
                  }),
                  c &&
                    (0, f.jsx)("p", {
                      className: "text-left text-sm font-normal leading-normal text-gray-600",
                      children: l("checkout_page_media_disclaimer"),
                    }),
                ],
              }),
            ],
          }),
        });
      },
      $ = (e) => (0, f.jsx)(Q, { ...e });
    var K = e.i(915113);
    function Z() {
      return (Z = Object.assign.bind()).apply(null, arguments);
    }
    let W = (e) =>
      q.createElement(
        "svg",
        Z({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 32 32" }, e),
        t ||
          (t = q.createElement(
            "g",
            {
              stroke: "#1662B6",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeMiterlimit: 10,
              strokeWidth: 1.875,
              clipPath: "url(#braining_svg__a)",
            },
            q.createElement("path", {
              d: "M16 27.25c6.213 0 11.25-5.037 11.25-11.25S22.213 4.75 16 4.75 4.75 9.787 4.75 16 9.787 27.25 16 27.25",
            }),
            q.createElement("path", {
              d: "M16 21.625a1.875 1.875 0 1 1-3.75 0 2.188 2.188 0 0 1-1.806-3.422 2.499 2.499 0 0 1 0-4.406 2.188 2.188 0 0 1 1.806-3.421 1.875 1.875 0 1 1 3.75-.001m0 11.25v-11.25m0 11.25a1.875 1.875 0 1 0 3.75 0 2.188 2.188 0 0 0 1.806-3.422 2.499 2.499 0 0 0 0-4.406 2.188 2.188 0 0 0-1.806-3.421 1.875 1.875 0 1 0-3.75-.001m12.563-4.437a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5m-25.125 0a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5m25.125 25.125a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5m-25.125 0a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5m20.517-7.108 2.84 2.84M5.205 5.205l2.84 2.84m-2.84 18.75 2.84-2.84m18.75-18.75-2.84 2.84",
            }),
          )),
        a ||
          (a = q.createElement(
            "defs",
            null,
            q.createElement(
              "clipPath",
              { id: "braining_svg__a" },
              q.createElement("path", { fill: "#fff", d: "M0 0h32v32H0z" }),
            ),
          )),
      );
    function J() {
      return (J = Object.assign.bind()).apply(null, arguments);
    }
    let X = (e) =>
      q.createElement(
        "svg",
        J({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 32 32" }, e),
        q.createElement(
          "mask",
          {
            id: "certificate_svg__a",
            width: 32,
            height: 32,
            x: 0,
            y: 0,
            maskUnits: "userSpaceOnUse",
            style: { maskType: "luminance" },
          },
          i || (i = q.createElement("path", { fill: "#fff", d: "M0 0h32v32H0z" })),
        ),
        s ||
          (s = q.createElement(
            "g",
            {
              stroke: "#1662B6",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeMiterlimit: 10,
              strokeWidth: 1.939,
              mask: "url(#certificate_svg__a)",
            },
            q.createElement("path", {
              d: "M17.157 24.593H8.508A5.51 5.51 0 0 1 3 19.085V8.509A5.51 5.51 0 0 1 8.508 3h14.984A5.51 5.51 0 0 1 29 8.509v1.983M8.508 13.466h7.933m-7.933 4.407h5.013",
            }),
            q.createElement("path", {
              d: "m24.893 13.867.245.368a1.02 1.02 0 0 0 1.052.437l.434-.088a1.02 1.02 0 0 1 1.203 1.203l-.088.434a1.02 1.02 0 0 0 .437 1.052l.368.245a1.022 1.022 0 0 1 0 1.701l-.368.245a1.02 1.02 0 0 0-.436 1.053l.087.433a1.02 1.02 0 0 1-1.203 1.203l-.433-.087a1.02 1.02 0 0 0-1.053.436l-.245.368a1.022 1.022 0 0 1-1.702 0l-.244-.368a1.02 1.02 0 0 0-1.053-.436l-.433.087a1.02 1.02 0 0 1-1.203-1.203l.087-.433a1.02 1.02 0 0 0-.436-1.053l-.368-.244a1.02 1.02 0 0 1 0-1.702l.368-.245a1.02 1.02 0 0 0 .436-1.052l-.087-.434a1.02 1.02 0 0 1 1.203-1.203l.433.088a1.02 1.02 0 0 0 1.053-.437l.244-.368a1.022 1.022 0 0 1 1.702 0M8.508 9.06h14.984m3.25 17.076v2.082a.78.78 0 0 1-1.316.569l-1.439-1.33-1.439 1.33a.78.78 0 0 1-1.315-.569v-2.082",
            }),
          )),
      );
    function ee() {
      return (ee = Object.assign.bind()).apply(null, arguments);
    }
    let et = (e) =>
      q.createElement(
        "svg",
        ee({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 28 28" }, e),
        r ||
          (r = q.createElement(
            "g",
            { clipPath: "url(#eye_svg__a)" },
            q.createElement("path", {
              fill: "currentColor",
              d: "M14 9.49A4.516 4.516 0 0 0 9.49 14 4.517 4.517 0 0 0 14 18.513a4.516 4.516 0 0 0 4.512-4.511A4.515 4.515 0 0 0 14 9.49m0 7.446a2.94 2.94 0 0 1-2.935-2.935 2.94 2.94 0 0 1 2.936-2.936 2.94 2.94 0 0 1 2.935 2.936 2.94 2.94 0 0 1-2.935 2.935",
            }),
            q.createElement("path", {
              fill: "#40425e",
              d: "M26.318 12.232c-2.262-2.336-6.868-6.256-12.319-6.256-5.45 0-10.057 3.92-12.318 6.256a2.53 2.53 0 0 0 0 3.536c2.262 2.335 6.87 6.255 12.318 6.255 5.449 0 10.057-3.919 12.318-6.255a2.53 2.53 0 0 0 0-3.536m-1.132 2.44c-1.68 1.736-6.137 5.776-11.187 5.776s-9.505-4.04-11.186-5.776a.96.96 0 0 1 0-1.345C4.493 11.591 8.95 7.551 14 7.551s9.506 4.04 11.186 5.776a.963.963 0 0 1 .001 1.345M14 3.774a.79.79 0 0 0 .788-.787v-.918a.787.787 0 1 0-1.575 0v.918a.79.79 0 0 0 .787.787m0 20.45a.787.787 0 0 0-.787.788v.918a.788.788 0 0 0 1.575 0v-.918a.79.79 0 0 0-.788-.787M7.811 4.858a.787.787 0 0 0 1.363-.788l-.458-.795a.787.787 0 0 0-1.363.787zm12.376 18.285a.787.787 0 0 0-1.363.788l.458.794a.788.788 0 0 0 1.364-.787zM19.112 5.144a.787.787 0 0 0 1.075-.288l.459-.794a.787.787 0 1 0-1.364-.788l-.458.794a.79.79 0 0 0 .288 1.076M8.887 22.854a.785.785 0 0 0-1.076.288l-.458.795a.788.788 0 1 0 1.363.787l.458-.794a.787.787 0 0 0-.287-1.076",
            }),
          )),
        n ||
          (n = q.createElement(
            "defs",
            null,
            q.createElement(
              "clipPath",
              { id: "eye_svg__a" },
              q.createElement("path", { fill: "currentColor", d: "M0 0h28v28H0z" }),
            ),
          )),
      );
    function ea() {
      return (ea = Object.assign.bind()).apply(null, arguments);
    }
    let ei = (e) =>
      q.createElement(
        "svg",
        ea({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 32 26" }, e),
        l ||
          (l = q.createElement("path", {
            fill: "currentColor",
            stroke: "currentColor",
            strokeWidth: 0.3,
            d: "M31.11 14.963c-.47-1.208-1.741-3.362-1.532-4.7.22-6.802-7.68-11.57-13.578-8.262C9.84-1.384 1.941 3.688 2.423 10.724c.06 2.522-4.08 5.955.555 6.715.304 1.673.353 4.166 2.652 4.162.105.056 3.442-.13 3.365.11l.49 1.987a1.78 1.78 0 0 0 1.729 1.354h9.572c.821 0 1.532-.556 1.729-1.355l.489-1.987c-.097-.235 3.303-.058 3.365-.11 2.308-.006 2.345-2.483 2.652-4.162l.985-.242c.958-.212 1.517-1.346 1.102-2.234zM17.322 4.942a7.77 7.77 0 0 1 2.099 5.285c.025 2.62-1.81 4.917-1.606 7.542-.012.15.033 4.232-.037 4.246-.16.827-.935 1.474-1.778 1.475-.843-.001-1.619-.648-1.777-1.475l-.008-.045c-.061.04-.016-4.1-.03-4.201.205-2.624-1.63-4.922-1.605-7.542-.012-2.53 1.313-5.01 3.42-6.411.481.323.926.702 1.322 1.125ZM11.214 23.49a.22.22 0 0 1-.213-.165c-.343-1.208-.423-3.33-2.145-3.285H5.63a.72.72 0 0 1-.707-.592c-.293-1.032-.127-3.25-1.522-3.513l-1.035-.255a.06.06 0 0 1-.043-.034.06.06 0 0 1-.001-.056l1.234-2.818c.359-.787.46-1.652.43-2.508-.16-5.292 5.616-9.25 10.47-7.248-2.286 1.833-3.596 4.767-3.426 7.698.04 2.447 1.737 4.61 1.593 7.055.107 1.308-.36 4.617.546 5.722h-1.955Zm18.463-7.845a.06.06 0 0 1-.043.035l-1.036.255c-1.396.264-1.227 2.485-1.52 3.512a.72.72 0 0 1-.708.592h-3.226c-1.732-.039-1.8 2.078-2.146 3.285a.22.22 0 0 1-.212.166h-1.955c.904-1.09.44-4.415.546-5.721-.13-2.608 1.741-4.898 1.606-7.542.015-2.773-1.283-5.479-3.44-7.212 4.855-2.001 10.63 1.956 10.472 7.248-.22 1.748 1.112 3.831 1.662 5.382Z",
          })),
      );
    function es() {
      return (es = Object.assign.bind()).apply(null, arguments);
    }
    let er = (e) =>
      q.createElement(
        "svg",
        es({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 32 32" }, e),
        o ||
          (o = q.createElement("path", {
            stroke: "#1662B6",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: 2,
            d: "M28.56 14.563a1.334 1.334 0 0 0-.025-2.451L17.107 6.907a2.67 2.67 0 0 0-2.214 0l-11.426 5.2a1.333 1.333 0 0 0 0 2.442l11.426 5.211a2.67 2.67 0 0 0 2.214 0zm.773-1.23v8",
          })),
        c ||
          (c = q.createElement("path", {
            stroke: "#1662B6",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: 2,
            d: "M8 16.667v4.666c0 1.061.843 2.079 2.343 2.829s3.535 1.171 5.657 1.171 4.157-.421 5.657-1.171S24 22.394 24 21.333v-4.666",
          })),
      );
    function en() {
      return (en = Object.assign.bind()).apply(null, arguments);
    }
    let el = (e) =>
      q.createElement(
        "svg",
        en({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 32 30" }, e),
        _ ||
          (_ = q.createElement("path", {
            fill: "currentColor",
            stroke: "currentColor",
            strokeWidth: 0.4,
            d: "M22.818 2.556C21.01 1.116 18.588.323 16 .323c-2.589 0-5.01.793-6.818 2.233-2.076 1.652-3.173 4.003-3.173 6.798 0 3.47 1.436 5.473 2.703 7.24 1.02 1.424 1.902 2.653 1.902 4.468v.384a1.64 1.64 0 0 0 1.638 1.638h7.496a1.64 1.64 0 0 0 1.638-1.638v-.384c0-1.815.881-3.044 1.902-4.468 1.267-1.767 2.702-3.77 2.702-7.24 0-2.795-1.097-5.146-3.172-6.798ZM16 13.226a1.28 1.28 0 0 1-1.279-1.279A1.28 1.28 0 0 1 16 10.668a1.28 1.28 0 0 1 1.279 1.28A1.28 1.28 0 0 1 16 13.225Zm6.018 2.458c-1.08 1.505-2.195 3.061-2.195 5.378v.384c0 .04-.035.075-.075.075h-2.967v-6.843a2.846 2.846 0 0 0 2.06-2.73A2.845 2.845 0 0 0 16 9.105a2.845 2.845 0 0 0-2.841 2.841c0 1.296.872 2.391 2.06 2.732v6.842h-2.967a.077.077 0 0 1-.075-.075v-.384c0-2.317-1.116-3.873-2.195-5.378-1.185-1.653-2.41-3.363-2.41-6.33 0-5.131 4.369-7.468 8.428-7.468s8.428 2.337 8.428 7.468c0 2.967-1.225 4.677-2.41 6.33Zm-1.646 9.38c0 .431-.35.781-.78.781h-7.183a.781.781 0 0 1 0-1.562h7.182a.78.78 0 0 1 .781.781Zm-1.69 2.762a.78.78 0 0 1-.782.78h-1.12v.29a.781.781 0 0 1-1.562 0v-.29H14.1a.781.781 0 0 1 0-1.562h3.8c.431 0 .781.35.781.782Zm7.774-23.313a.78.78 0 0 1 .286-1.067l1.47-.849a.781.781 0 0 1 .782 1.354l-1.47.848a.78.78 0 0 1-1.068-.286ZM3.323 10.668H1.625a.781.781 0 0 1 0-1.562h1.698a.781.781 0 0 1 0 1.562Zm2.22 4.593a.78.78 0 0 1-.285 1.067l-1.47.849a.781.781 0 1 1-.782-1.354l1.47-.848a.78.78 0 0 1 1.068.286Zm23.737 1.63a.78.78 0 0 1-1.068.286l-1.47-.85a.781.781 0 1 1 .781-1.352l1.47.848a.78.78 0 0 1 .287 1.068ZM5.544 4.513a.78.78 0 0 1-1.067.286l-1.47-.849a.781.781 0 1 1 .78-1.353l1.47.85a.78.78 0 0 1 .287 1.066Zm25.612 5.374c0 .431-.35.781-.781.781h-1.698a.781.781 0 1 1 0-1.562h1.698c.431 0 .781.35.781.78Z",
          })),
      );
    function eo() {
      return (eo = Object.assign.bind()).apply(null, arguments);
    }
    let ec = (e) =>
      q.createElement(
        "svg",
        eo({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 28 28" }, e),
        m ||
          (m = q.createElement(
            "g",
            { clipPath: "url(#lamp_svg__a)" },
            q.createElement(
              "g",
              { clipPath: "url(#lamp_svg__b)" },
              q.createElement("path", {
                fill: "currentColor",
                d: "M14 5.031a.656.656 0 0 1-.656-.656v-1.75a.656.656 0 1 1 1.312 0v1.75a.656.656 0 0 1-.656.656m-6.806 2.82a.65.65 0 0 1-.463-.193L5.49 6.421a.656.656 0 0 1 .928-.928l1.24 1.236a.656.656 0 0 1-.464 1.12zM5.25 14.656H3.5a.656.656 0 1 1 0-1.312h1.75a.656.656 0 1 1 0 1.312m15.556-6.805a.656.656 0 0 1-.464-1.12l1.237-1.239a.656.656 0 1 1 .928.928L21.27 7.659a.65.65 0 0 1-.463.192zm2.819 6.805h-1.75a.656.656 0 1 1 0-1.312h1.75a.656.656 0 1 1 0 1.312M14 18.156a.656.656 0 0 1-.656-.656v-1.75c0-.174.07-.34.192-.464l1.75-1.75a.657.657 0 1 1 .928.928l-1.558 1.557V17.5a.656.656 0 0 1-.656.656",
              }),
              q.createElement("path", {
                fill: "currentColor",
                d: "M14 16.407a.66.66 0 0 1-.463-.192l-1.75-1.75a.657.657 0 1 1 .927-.928l1.75 1.75a.656.656 0 0 1-.463 1.12",
              }),
              q.createElement("path", {
                fill: "#40425e",
                d: "M16.188 26.031h-4.375A1.534 1.534 0 0 1 10.28 24.5v-1.313a.656.656 0 0 1 .656-.656h6.126a.656.656 0 0 1 .656.656V24.5a1.533 1.533 0 0 1-1.532 1.531m-4.594-2.187v.656a.22.22 0 0 0 .219.219h4.374a.22.22 0 0 0 .22-.22v-.655zm5.906-2.625h-7a.656.656 0 0 1-.656-.657v-1.994a7.219 7.219 0 1 1 8.312 0v1.994a.656.656 0 0 1-.656.657m-6.344-1.313h5.688v-1.689a.66.66 0 0 1 .305-.554 5.905 5.905 0 1 0-6.298 0 .66.66 0 0 1 .305.555z",
              }),
              q.createElement("path", {
                fill: "#40425e",
                d: "M16.777 23.844h-5.554a2.256 2.256 0 0 1-2.254-2.254v-.228a1.457 1.457 0 0 1 1.455-1.456h7.152a1.457 1.457 0 0 1 1.455 1.455v.229a2.255 2.255 0 0 1-2.254 2.254m-6.352-2.625a.14.14 0 0 0-.102.041.14.14 0 0 0-.042.101v.229a.943.943 0 0 0 .942.941h5.554a.94.94 0 0 0 .942-.941v-.228a.14.14 0 0 0-.042-.101.14.14 0 0 0-.1-.042z",
              }),
            ),
          )),
        u ||
          (u = q.createElement(
            "defs",
            null,
            q.createElement(
              "clipPath",
              { id: "lamp_svg__a" },
              q.createElement("path", { fill: "currentColor", d: "M0 0h28v28H0z" }),
            ),
            q.createElement(
              "clipPath",
              { id: "lamp_svg__b" },
              q.createElement("path", { fill: "currentColor", d: "M0 0h28v28H0z" }),
            ),
          )),
      );
    function e_() {
      return (e_ = Object.assign.bind()).apply(null, arguments);
    }
    function em() {
      return (em = Object.assign.bind()).apply(null, arguments);
    }
    e.s(
      [
        "default",
        0,
        (e) =>
          q.createElement(
            "svg",
            e_({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 23 22" }, e),
            d ||
              (d = q.createElement("path", {
                fill: "currentColor",
                d: "M5.404 20.9q-.661 0-1.133-.462a1.5 1.5 0 0 1-.471-1.11V9.366q0-.648.471-1.11a1.56 1.56 0 0 1 1.133-.462h1.444V5.657q0-1.89 1.361-3.224Q9.57 1.1 11.502 1.1q1.93 0 3.29 1.333t1.36 3.224v2.137h1.444q.661 0 1.133.462.471.462.471 1.11v9.962q0 .65-.471 1.11a1.56 1.56 0 0 1-1.133.462zm6.099-4.714q.775 0 1.325-.531t.549-1.276q0-.732-.552-1.3-.552-.57-1.328-.57-.775 0-1.325.57-.549.569-.549 1.307 0 .74.552 1.27t1.328.53M8.452 7.794h6.096V5.657a2.85 2.85 0 0 0-.888-2.115q-.89-.87-2.158-.87-1.269 0-2.16.87a2.85 2.85 0 0 0-.89 2.115z",
              })),
          ),
      ],
      191429,
    );
    let eu = (e) =>
      q.createElement(
        "svg",
        em({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 28 30" }, e),
        p ||
          (p = q.createElement("path", {
            fill: "currentColor",
            d: "m17.236 19.688-1.49 1.293-.3-.412a.9.9 0 0 0-1.455 1.06l.877 1.203a.9.9 0 0 0 .728.37.9.9 0 0 0 .59-.22l2.23-1.936a.899.899 0 0 0-.52-1.597.9.9 0 0 0-.66.24",
          })),
        g ||
          (g = q.createElement("path", {
            fill: "currentColor",
            d: "M24.298.1H8.213a3.326 3.326 0 0 0-3.327 3.316v1.188h-1.18a3.32 3.32 0 0 0-3.32 3.318v18.66a3.32 3.32 0 0 0 3.318 3.317H19.79a3.32 3.32 0 0 0 3.32-3.318v-1.183h1.187a3.325 3.325 0 0 0 3.316-3.326V3.417A3.32 3.32 0 0 0 24.298.1M21.31 26.582a1.52 1.52 0 0 1-1.52 1.518H3.705a1.52 1.52 0 0 1-1.519-1.518V7.923a1.52 1.52 0 0 1 1.52-1.519H19.79a1.52 1.52 0 0 1 1.52 1.52zm4.504-4.509c0 .842-.68 1.526-1.516 1.526H23.11V7.923a3.32 3.32 0 0 0-3.319-3.318H6.686V3.417c0-.836.685-1.517 1.527-1.517h16.085c.836 0 1.516.68 1.516 1.517z",
          })),
        h ||
          (h = q.createElement("path", {
            fill: "currentColor",
            d: "M17.826 15.724H5.669a.9.9 0 0 0 0 1.8h12.157a.9.9 0 1 0 0-1.8m-6.274 4.711H5.669a.9.9 0 0 0 0 1.8h5.883a.9.9 0 1 0 0-1.8m-1.935-9.376h4.261a.9.9 0 1 0 0-1.8H9.617a.9.9 0 1 0 0 1.8",
          })),
      );
    function ed() {
      return (ed = Object.assign.bind()).apply(null, arguments);
    }
    let ep = (e) =>
      q.createElement(
        "svg",
        ed({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 28 28" }, e),
        x ||
          (x = q.createElement(
            "g",
            { clipPath: "url(#test_svg__a)" },
            q.createElement(
              "g",
              { clipPath: "url(#test_svg__b)" },
              q.createElement("path", {
                fill: "#40425e",
                d: "M18.977 26.444H4.876a3.35 3.35 0 0 1-2.333-.973 3.28 3.28 0 0 1-.973-2.333v-.84a.83.83 0 0 1 .817-.832H5.7V4.876a3.32 3.32 0 0 1 3.321-3.321h14.514a2.9 2.9 0 0 1 2.909 2.9v8.712a.83.83 0 0 1-.832.832h-3.314v9.123a3.32 3.32 0 0 1-3.321 3.322M7.365 21.466h9.123a.833.833 0 0 1 .832.832v.825a1.657 1.657 0 0 0 3.314 0V4.455c0-.43.096-.856.28-1.245H9.02a1.657 1.657 0 0 0-1.656 1.665zM3.21 23.122a1.67 1.67 0 0 0 1.665 1.665h11.231a3.3 3.3 0 0 1-.451-1.665zm19.087-10.78h2.489V4.456a1.245 1.245 0 0 0-2.489 0z",
              }),
              q.createElement("path", {
                fill: "currentColor",
                d: "M17.32 16.489h-6.642a.831.831 0 0 1 0-1.657h6.642a.832.832 0 0 1 0 1.657m0-4.146h-6.642a.833.833 0 0 1 0-1.664h6.642a.832.832 0 0 1 0 1.664m-1.664-4.977h-3.314a.832.832 0 1 1 0-1.665h3.314a.832.832 0 0 1 0 1.665",
              }),
            ),
          )),
        y ||
          (y = q.createElement(
            "defs",
            null,
            q.createElement(
              "clipPath",
              { id: "test_svg__a" },
              q.createElement("path", { fill: "currentColor", d: "M0 0h28v28H0z" }),
            ),
            q.createElement(
              "clipPath",
              { id: "test_svg__b" },
              q.createElement("path", { fill: "currentColor", d: "M0 0h28v28H0z" }),
            ),
          )),
      );
    e.s([], 21353);
    var eg = e.i(387652),
      eh = e.i(891133),
      ex = e.i(263970),
      ey = e.i(730699),
      ef = e.i(861745),
      eb = e.i(926654);
    e.i(122612);
    var eM = e.i(225352);
    e.i(80460);
    var ev = e.i(998198),
      ek = e.i(19576);
    let ew = { price: "max-md:text-[24px]", skeleton: "max-md:h-8" },
      eP = { price: "max-md:text-lg", skeleton: "max-md:h-6" },
      eA = (0, e.i(770703).default)(() => e.A(675467), { loadableGenerated: { modules: [202969] } }),
      ej = (e) => {
        let {
            user: t,
            alignCenter: a,
            className: i,
            textSizeClassName: s,
            skeletonClassName: r,
            isPromoPriceSpecial: n,
            isMarketingSource: l,
            isUnderTotalDue: o,
            abMyiqAb100Vs199: c,
            isBrainTrain: _,
          } = e,
          m = (0, P.useTranslations)(),
          u = (0, ef.useLocale)(),
          d = "rtl" === (0, ek.getLocaleDirection)(u),
          p = a ? "text-center" : d ? "text-right" : "text-left",
          g = (0, eh.useIsUsA1Campaign)(),
          { priceForView: h } = (0, ev.getPaymentPlanPrice)({
            paymentPlan: "v1_trial_1_99" === c || g ? "DEMO_PRICE_1_99" : "DEMO_PRICE",
            user: t,
          }),
          { priceForView: x } = (0, ev.getPaymentPlanPrice)({ paymentPlan: "MONTH_PRICE", user: t }),
          y = t?.currency?.countryCode === "US",
          b = (0, V.isUk)(t?.currency?.countryCode, (0, O.getClientCity)()),
          v = (0, V.getBillingCycleDays)(t?.currency?.countryCode),
          { isUserRestoring: k } = (0, eM.useCheckoutUserRestore)();
        if (k || !t?.paymentInfo?.paynextAmountToPay || !t?.paymentInfo?.paynextAmountMonth)
          return (0, f.jsx)(eb.Skeleton, { className: (0, M.cn)(r, "h-5 w-full rounded-lg") });
        let w = (e) =>
          y || (!o && (!l || b))
            ? (0, f.jsx)("span", { className: "font-medium text-dark-custom", children: e })
            : (0, f.jsx)("span", { children: e });
        if (n) {
          let e = t?.paymentInfo?.paynextAmountToPay || (0, ev.getCalculatePriceForView)(h, t);
          return (0, f.jsx)("p", {
            id: "afterwards",
            className: (0, M.cn)(
              p,
              i,
              "text-sm leading-6 text-gray-600 [&>span]:inline",
              !o && "md:text-[15px]",
              s,
            ),
            dir: d ? "rtl" : "ltr",
            children: m.rich("checkout_page_cost_calculation_promo_price", {
              trialCost: e,
              fullCost: e,
              strong: w,
            }),
          });
        }
        return (0, f.jsxs)("p", {
          id: "afterwards",
          className: (0, M.cn)(
            p,
            i,
            "text-sm leading-6 text-gray-600 [&>span]:inline",
            !o && "md:text-[15px]",
            s,
          ),
          dir: d ? "rtl" : "ltr",
          children: [
            m.rich(
              y || b
                ? "checkout_page_four_bullet_point_us"
                : _
                  ? "checkout_page_four_bullet_point_bt"
                  : "checkout_page_four_bullet_point_v2",
              {
                trialCost: t?.paymentInfo?.paynextAmountToPay || (0, ev.getCalculatePriceForView)(h, t),
                fullCost: t?.paymentInfo?.paynextAmountMonth || (0, ev.getCalculatePriceForView)(x, t),
                days: v.toString(),
                strong: w,
              },
            ),
            " ",
            y && (0, f.jsx)("span", { children: m("price_excludes_tax") }),
          ],
        });
      },
      eU = (e) => {
        let {
            demoPricePrev: t,
            demoPriceDefault: a,
            user: i,
            variant: s,
            isShownCouponDisclaimer: r = !0,
            isMarketingSource: n,
            abMyiqPromoPrice: l,
            abMyiqAb100Vs199: o,
            ftMyiqPaywall: c,
            bannerOnly: _ = !1,
            isUSorGBUser: m,
            rollbackUsRegion: u,
            idSuffix: d = "",
            isCouponHairline: p,
          } = e,
          g = (0, P.useTranslations)(),
          h = (0, ef.useLocale)(),
          x = (0, O.getClientCity)(),
          y = (0, V.isUk)(i?.currency?.countryCode, x),
          b = m ?? (0, V.isUsUk)(i?.currency?.countryCode, x),
          v = u ? (0, V.isUk)(i?.currency?.countryCode, x) : b,
          k = u ? (0, V.isGb)(i?.currency?.countryCode) : (0, V.isUsOrAnyUk)(i?.currency?.countryCode),
          w = !!n && !k,
          A = w && !u,
          j = (() => {
            if (w) return u ? eP : ew;
          })(),
          U = () => g("checkout_page_you_save", { sale: (0, ev.getSale)(t, a, !0) }),
          S = () => g("checkout_page_promo_applied", { sale: (0, ev.getSale)(t, a, !0) }),
          q = "rtl" === (0, ek.getLocaleDirection)(h),
          { isUserRestoring: C } = (0, eM.useCheckoutUserRestore)(),
          E = C || !i?.paymentInfo?.paynextAmountToPay,
          T = (0, ex.useGlobalStore)((e) => e.checkoutTimerExpired),
          I = "promo_price" === l && n,
          N = T && !I && "personality" !== s,
          R = r && !y && "love_language" !== s && !E,
          D = i?.paymentInfo?.paynextAmountToPay || (0, ev.getCalculatePriceForView)(a, i),
          L = (0, ev.getSale)(t, a, !0),
          B = R
            ? (0, f.jsx)(eA, {
                appliedText: S(),
                saveText: U(),
                salePercent: L,
                isRtl: q,
                isAppliedTextLighter: !1,
                idSuffix: d,
                isHairline: p,
              })
            : r &&
              (0, f.jsx)("div", {
                className: (0, M.cn)(
                  "mt-2 flex items-center justify-between rounded-large px-3 py-[14px]",
                  "love_language" === s ? "bg-[#fff4f38a]" : "bg-blue-pale",
                  p && "max-sm:border max-sm:border-primary/20 max-sm:bg-transparent",
                ),
                id: `checkout-coupon-disclaimer${d}`,
                children: (0, f.jsxs)("div", {
                  className: (0, M.cn)("flex items-center"),
                  children: [
                    (0, f.jsx)(ey.Gift, {
                      className: `inline h-6 w-6 ${"love_language" === s ? "text-love-main" : "text-primary"} ${q ? "ml-3" : "mr-3"}`,
                    }),
                    (0, f.jsxs)("div", {
                      children: [
                        "love_language" === s
                          ? (0, f.jsx)("p", {
                              className: "text-start text-sm font-medium text-[#121620]",
                              children: g("checkout_love_promo", {
                                name: "LOVESTYLE",
                                sale: (0, ev.getSale)(t, a, !0),
                              }),
                            })
                          : (0, f.jsx)("p", {
                              className: "text-start text-sm font-semibold text-[#121620]",
                              children: S(),
                            }),
                        (0, f.jsx)("p", {
                          className: "text-start text-sm font-normal text-default-600",
                          children: U(),
                        }),
                      ],
                    }),
                  ],
                }),
              });
        return (0, f.jsxs)(f.Fragment, {
          children: [
            !v && !N && B,
            !_ &&
              (0, f.jsxs)(f.Fragment, {
                children: [
                  (0, f.jsxs)("div", {
                    id: `total-due${d}`,
                    className: (0, M.cn)(
                      "mb-2 flex justify-between font-semibold",
                      "items-center border-b border-gray-200 pb-2",
                      r && !N && "mt-5",
                    ),
                    children: [
                      (0, f.jsxs)("span", {
                        className: (0, M.cn)(
                          "love_language" === s && "text-love-grey",
                          w && "max-md:text-lg",
                        ),
                        children: [
                          A &&
                            (0, f.jsx)("span", {
                              className: "md:hidden",
                              children: g("certificate_card_iq_test_subtitle"),
                            }),
                          (0, f.jsx)("span", {
                            className: (0, M.cn)(A && "max-md:hidden"),
                            children: `${g("checkout_page_due_today")}:`,
                          }),
                        ],
                      }),
                      E
                        ? (0, f.jsx)(eb.Skeleton, {
                            className: (0, M.cn)("h-7 w-20 rounded-lg", j?.skeleton),
                          })
                        : (0, f.jsxs)("div", {
                            children: [
                              !N &&
                                !v &&
                                (0, f.jsx)("span", {
                                  className: "pr-1 text-sm text-[#747475] line-through",
                                  children: (0, ev.getCalculatePriceForView)(t, i),
                                }),
                              (0, f.jsx)("span", {
                                className: (0, M.cn)(
                                  "font-bold",
                                  "love_language" === s ? "text-love-grey" : "text-black",
                                  j?.price,
                                  w && "max-md:leading-tight",
                                ),
                                children: D,
                              }),
                            ],
                          }),
                    ],
                  }),
                  "autism" === s &&
                    (0, f.jsx)("p", {
                      className: "mb-2 text-center text-xs text-gray-400",
                      children: g("start_autism_disclaimer"),
                    }),
                  "price_disclamer" === c &&
                    !(0, V.isUsOrAnyUk)(i?.currency?.countryCode) &&
                    (0, f.jsx)(ej, {
                      isMarketingSource: n,
                      user: i,
                      abMyiqAb100Vs199: o,
                      isUnderTotalDue: !0,
                    }),
                ],
              }),
          ],
        });
      };
    e.i(118046);
    var eS = e.i(174956);
    e.i(185595);
    var eq = e.i(266278),
      eC = e.i(842009),
      eE = e.i(455711);
    let eT = (0, e.i(475254).default)("file-text", [
      ["path", { d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z", key: "1rqfz7" }],
      ["path", { d: "M14 2v4a2 2 0 0 0 2 2h4", key: "tnqrlb" }],
      ["path", { d: "M10 9H8", key: "b1mrlr" }],
      ["path", { d: "M16 13H8", key: "t4e002" }],
      ["path", { d: "M16 17H8", key: "z1uh3a" }],
    ]);
    var eI = e.i(248256);
    let eN = (e) => {
        let { user: t, demoPriceDefault: a, summaryRedesign: i } = e,
          s = (0, P.useTranslations)(),
          { isUserRestoring: r } = (0, eM.useCheckoutUserRestore)(),
          n = r || !t?.paymentInfo?.paynextAmountToPay,
          l = t?.paymentInfo?.paynextAmountToPay || (0, ev.getCalculatePriceForView)(a, t),
          o = "v2_blue_band" === i || "v3_light_border" === i,
          c = [
            { icon: eC.Award, label: s("checkout_order_summary_iq_score_certificate"), isPrice: !0 },
            { icon: eT, label: s("checkout_order_summary_detailed_report"), isPrice: !1 },
            { icon: eI.Globe, label: s("checkout_order_summary_ranking"), isPrice: !1 },
            { icon: eE.Brain, label: s("checkout_order_summary_cognitive_training"), isPrice: !1 },
          ];
        return (0, f.jsxs)("div", {
          className: (0, M.cn)("mb-3 border-t border-gray-200 pt-3 sm:rounded-large sm:border sm:p-4", {
            "max-sm:mb-0 max-sm:rounded-t-2xl max-sm:border-2 max-sm:border-b-0 max-sm:border-primary max-sm:bg-white max-sm:px-4 max-sm:pb-1 max-sm:pt-4":
              "v1_extended" === i,
            "max-sm:mb-2 max-sm:rounded-2xl max-sm:px-4 max-sm:pb-4 max-sm:pt-4": o,
            "max-sm:border-t-0 max-sm:bg-gradient-to-r max-sm:from-blue-50 max-sm:to-[#e0eaff]":
              "v2_blue_band" === i,
            "max-sm:border max-sm:border-primary/30 max-sm:bg-white": "v3_light_border" === i,
          }),
          children: [
            (0, f.jsx)("p", {
              className: "mb-3 text-xs font-semibold uppercase tracking-wide text-grey-light",
              children: s("checkout_order_summary_title"),
            }),
            (0, f.jsx)("ul", {
              className: "grid gap-2.5",
              children: c.map((e, t) => {
                let { icon: a, label: i, isPrice: r } = e;
                return (0, f.jsxs)(
                  "li",
                  {
                    className: "flex items-center justify-between gap-3",
                    children: [
                      (0, f.jsxs)("div", {
                        className: "flex items-center gap-2",
                        children: [
                          (0, f.jsx)(a, { className: "h-[18px] w-[18px] shrink-0 text-primary" }),
                          (0, f.jsx)("span", {
                            className: (0, M.cn)(
                              "text-sm text-zinc-700 md:text-[15px]",
                              o && "max-sm:text-[#0D0D0D]",
                            ),
                            children: i,
                          }),
                        ],
                      }),
                      r
                        ? n
                          ? (0, f.jsx)(eb.Skeleton, { className: "h-5 w-14 rounded-md" })
                          : (0, f.jsx)("span", {
                              className: "text-sm font-bold text-black md:text-[15px]",
                              children: l,
                            })
                        : (0, f.jsx)("span", {
                            className: "text-sm font-semibold text-primary md:text-[15px]",
                            children: s("checkout_order_summary_included"),
                          }),
                    ],
                  },
                  t,
                );
              }),
            }),
          ],
        });
      },
      eR = (e) => {
        let { isProminent: t, isJoinedWithSummary: a, isTightWithSummary: i, children: s } = e;
        return t
          ? (0, f.jsx)("div", {
              className: (0, M.cn)(
                "mt-3 rounded-2xl bg-gradient-to-r from-primary via-[#5C92FF] to-primary p-[2px]",
                a && "max-sm:mt-0 max-sm:rounded-t-none max-sm:pt-0",
                i && "max-sm:mt-0",
              ),
              children: (0, f.jsx)("div", {
                className: (0, M.cn)(
                  "rounded-[14px] bg-white px-4 py-4 max-xs-sm:px-3 md:px-5 md:py-5",
                  a && "max-sm:rounded-t-none max-sm:pt-1.5",
                ),
                children: s,
              }),
            })
          : (0, f.jsx)(f.Fragment, { children: s });
      },
      eO = (e) => {
        let {
            user: t,
            isMarketingSource: a,
            variant: i,
            friendEncodedData: s,
            isBrainTrain: r,
            experiments: n,
            iqScore: l,
            currentHour: o,
            isPlanPickerFunnel: c,
            isUSorGBUser: _,
            rollbackUsRegion: m,
            onPaymentSectionInView: u,
            idSuffix: d = "",
            isSecondaryInstance: p,
            selectedPlan: g,
            onPlanChange: h,
            abMyiqPostPaymentProcessingModal: x,
          } = e,
          y = (0, q.useRef)(null),
          k = (0, eg.useInView)(y, { once: !0, amount: 0.5 }),
          P = (0, ex.useGlobalStore)((e) => e.isAutoScrolling);
        (0, q.useEffect)(() => {
          k && !P && u?.();
        }, [k, P, u]);
        let {
            abMyiqPromoPrice: A,
            abMyiqAb100Vs199: j,
            abMyiqRevolutMonzoBlock: U,
            abMyiqProductFeedbackWidget: S,
            abMyiqPrintCertificateUpsell: C,
            ftMyiqPaywall: E,
            ftMyiqReviewPlatformSplit: T,
            abMyiqBrazilMastercardOnly: I,
            abMyiqPaywallBenefitsOptimization: N,
            abMyiqPaywallBenefitsRedesign: D,
            abMyiqBenefitVersion: L,
            abMyiqPaywallSummaryRedesign: B,
          } = n,
          F = m ? (0, V.isGb)(t?.currency?.countryCode) : (0, V.isUsOrAnyUk)(t?.currency?.countryCode),
          H = !!a && !F,
          G = !!a && !F,
          z = G && "v1_bullet_icons" === N,
          Y = G && "v2_dash_icons" === N,
          Q = G && "v3_separators" === N,
          $ = "border-t border-[#eef2f7] pt-[11px] pb-[11px] first:border-t-0 first:pt-[2px] last:pb-[2px]",
          K = (L && a && !F ? "v1_updated_benefits" === L : H)
            ? "text-[12px] md:text-[15px]"
            : "text-sm md:text-[15px]",
          Z = H ? "h-5 w-5 p-[5px] md:h-6 md:w-6 md:p-1.5" : "h-6 w-6 p-1.5",
          W = _ ?? (0, V.isUsUk)(t?.currency?.countryCode, (0, O.getClientCity)()),
          J = "v1_design_1" === D && (0, v.isMyiqVariant)(i) && !r && !!a && !F,
          X = (0, eS.usePaymentDetailsList)({ variant: i, isBrainTrain: r, isBenefitsRedesign: J }),
          ee = ("promo_price" === A && a) || void 0,
          et = (0, eh.useIsUsA1Campaign)(),
          ea = !F && !!a,
          ei = "price_disclamer" === E && !(0, V.isUsOrAnyUk)(t?.currency?.countryCode),
          { priceForView: es } = (0, ev.getPaymentPlanPrice)({
            paymentPlan: ee
              ? "DEMO_PRICE_SPECIAL"
              : "v1_trial_1_99" === j || et
                ? "DEMO_PRICE_1_99"
                : "DEMO_PRICE",
            user: t,
          }),
          { priceForView: er } = (0, ev.getPaymentPlanPrice)({ paymentPlan: "DEMO_PRICE_PREV", user: t }),
          en = (0, v.isMyiqVariant)(i) && !c,
          el = en && ea && "default_summary" !== B ? B : void 0,
          eo = (0, f.jsx)(eU, {
            variant: i,
            demoPricePrev: er,
            demoPriceDefault: es,
            user: t,
            iqScore: l,
            currentHour: o,
            isMarketingSource: a,
            abMyiqPromoPrice: A,
            abMyiqAb100Vs199: j,
            ftMyiqPaywall: E,
            isUSorGBUser: W,
            rollbackUsRegion: m,
            bannerOnly: !0,
            idSuffix: d,
            isCouponHairline: "v2_blue_band" === el || "v3_light_border" === el,
          }),
          ec = (0, f.jsx)(eU, {
            variant: i,
            demoPricePrev: er,
            demoPriceDefault: es,
            user: t,
            iqScore: l,
            currentHour: o,
            isMarketingSource: a,
            abMyiqPromoPrice: A,
            abMyiqAb100Vs199: j,
            ftMyiqPaywall: E,
            isUSorGBUser: W,
            rollbackUsRegion: m,
            bannerOnly: !0,
            idSuffix: d,
          });
        return (0, f.jsx)(b.Card, {
          id: `payment-form${d}`,
          className: (0, M.cn)(
            "flex w-full min-w-0 max-w-full items-start justify-start overflow-visible lg:order-2 lg:p-3",
            ((0, v.isMyiqVariant)(i) || "personality" === i) && "max-sm:border-none max-sm:shadow-none",
          ),
          children: (0, f.jsxs)(R.CardBody, {
            className: (0, M.cn)("overflow-visible subpixel-antialiased"),
            children: [
              !c &&
                (0, f.jsxs)("ul", {
                  className: (0, M.cn)("mb-3 mt-1 grid gap-3", { "gap-0": Q, "max-md:gap-[18px]": J }),
                  children: [
                    X?.map((e, t) =>
                      (0, f.jsxs)(
                        "li",
                        {
                          className: (0, M.cn)("flex gap-2 text-love-grey", {
                            "items-start": !z && !Y,
                            "items-center": z || Y,
                            [$]: Q,
                            "max-md:gap-[14px] max-md:items-start": J,
                          }),
                          children: [
                            J &&
                              (0, f.jsx)("span", {
                                "aria-hidden": !0,
                                className:
                                  "flex h-9 w-9 shrink-0 items-center justify-center rounded-[10px] bg-blue-custom text-blue-custom md:hidden",
                                children: eS.BENEFITS_REDESIGN_ICONS[t],
                              }),
                            Q
                              ? null
                              : z
                                ? (0, f.jsx)("span", {
                                    "aria-hidden": !0,
                                    className: (0, M.cn)(
                                      "h-[5px] w-[5px] shrink-0 rounded-full bg-gray-600",
                                      { "max-md:hidden": J },
                                    ),
                                  })
                                : Y
                                  ? (0, f.jsx)("span", {
                                      "aria-hidden": !0,
                                      className: (0, M.cn)(
                                        "h-[2px] w-[6px] shrink-0 rounded-full bg-gray-600",
                                        { "max-md:hidden": J },
                                      ),
                                    })
                                  : (0, f.jsx)(w.IconCheckmark, {
                                      className: (0, M.cn)(
                                        "shrink-0 rounded-[5px] bg-[#ECF1F7] text-blue-600",
                                        Z,
                                        {
                                          "bg-[#f9efec] text-love-main": "love_language" === i,
                                          "-ml-1 !bg-transparent !px-0 !text-gray-600 lg:-ml-1.5":
                                            "love_language" !== i,
                                          "max-md:hidden": J,
                                        },
                                      ),
                                    }),
                            (0, f.jsx)("p", {
                              className: (0, M.cn)("leading-6 text-default-600", K, {
                                "max-md:pt-1.5 max-md:text-base max-md:leading-6 max-md:text-grey-custom": J,
                              }),
                              children: e.title,
                            }),
                          ],
                        },
                        t,
                      ),
                    ),
                    !ei &&
                      !W &&
                      (0, f.jsxs)("li", {
                        id: `last-bullet-point${d}`,
                        className: (0, M.cn)("flex items-start gap-2 text-love-grey", {
                          [$]: Q,
                          "max-md:mt-0.5 max-md:block max-md:px-2": J,
                        }),
                        children: [
                          Q
                            ? null
                            : z
                              ? (0, f.jsx)("span", {
                                  "aria-hidden": !0,
                                  className: (0, M.cn)(
                                    "mt-1.5 h-[5px] w-[5px] shrink-0 rounded-full bg-gray-600",
                                    { "max-md:hidden": J },
                                  ),
                                })
                              : Y
                                ? (0, f.jsx)("span", {
                                    "aria-hidden": !0,
                                    className: (0, M.cn)(
                                      "mt-1.5 h-[2px] w-[6px] shrink-0 rounded-full bg-gray-600",
                                      { "max-md:hidden": J },
                                    ),
                                  })
                                : (0, f.jsx)(w.IconCheckmark, {
                                    className: (0, M.cn)(
                                      "shrink-0 rounded-[5px] bg-[#ECF1F7] text-blue-600",
                                      Z,
                                      {
                                        "bg-[#f9efec] text-love-main": "love_language" === i,
                                        "-ml-1 !bg-transparent !px-0 !text-gray-600 lg:-ml-1.5":
                                          "love_language" !== i,
                                        "max-md:hidden": J,
                                      },
                                    ),
                                  }),
                          (0, f.jsx)(ej, {
                            isMarketingSource: a,
                            user: t,
                            isPromoPriceSpecial: ee,
                            abMyiqAb100Vs199: j,
                            isBrainTrain: r,
                            className: (0, M.cn)({ "max-md:text-center max-md:text-grey-light": J }),
                            textSizeClassName: (0, M.cn)(K, { "max-md:leading-[18px]": J }),
                          }),
                        ],
                      }),
                  ],
                }),
              c
                ? (0, f.jsx)("div", {
                    id: `checkout-due-today-section${d}`,
                    ref: y,
                    children: (0, f.jsx)(eq.CheckoutFormSectionComponent, {
                      abMyiqProductFeedbackWidget: S,
                      variant: i,
                      user: t,
                      isMarketingSource: a,
                      friendEncodedData: s,
                      abMyiqPromoPrice: A,
                      abMyiqAb100Vs199: j,
                      abMyiqRevolutMonzoBlock: U,
                      abMyiqPrintCertificateUpsell: C,
                      ftMyiqReviewPlatformSplit: T,
                      abMyiqBrazilMastercardOnly: I,
                      isPlanPickerFunnel: !0,
                      idSuffix: d,
                      containerId: p ? `checkout-container${d}` : void 0,
                      isSecondaryForm: p,
                      selectedPlan: g,
                      onPlanChange: h,
                      abMyiqPostPaymentProcessingModal: x,
                    }),
                  })
                : ea
                  ? (0, f.jsxs)(f.Fragment, {
                      children: [
                        eo,
                        en && (0, f.jsx)(eN, { user: t, demoPriceDefault: es, summaryRedesign: el }),
                        (0, f.jsxs)(eR, {
                          isProminent: ea,
                          isJoinedWithSummary: "v1_extended" === el,
                          children: [
                            (0, f.jsx)(eU, {
                              variant: i,
                              demoPricePrev: er,
                              demoPriceDefault: es,
                              user: t,
                              iqScore: l,
                              currentHour: o,
                              isMarketingSource: a,
                              abMyiqPromoPrice: A,
                              abMyiqAb100Vs199: j,
                              ftMyiqPaywall: E,
                              isUSorGBUser: W,
                              rollbackUsRegion: m,
                              isShownCouponDisclaimer: !1,
                              idSuffix: d,
                            }),
                            (0, f.jsx)("div", {
                              id: `checkout-due-today-section${d}`,
                              ref: y,
                              children: (0, f.jsx)(eq.CheckoutFormSectionComponent, {
                                abMyiqProductFeedbackWidget: S,
                                variant: i,
                                user: t,
                                isMarketingSource: a,
                                friendEncodedData: s,
                                abMyiqPromoPrice: A,
                                abMyiqAb100Vs199: j,
                                abMyiqRevolutMonzoBlock: U,
                                abMyiqPrintCertificateUpsell: C,
                                ftMyiqReviewPlatformSplit: T,
                                abMyiqBrazilMastercardOnly: I,
                                idSuffix: d,
                                containerId: p ? `checkout-container${d}` : void 0,
                                isSecondaryForm: p,
                                selectedPlan: g,
                                onPlanChange: h,
                                abMyiqPostPaymentProcessingModal: x,
                              }),
                            }),
                          ],
                        }),
                      ],
                    })
                  : (0, f.jsxs)(f.Fragment, {
                      children: [
                        en
                          ? (0, f.jsxs)(f.Fragment, {
                              children: [
                                ec,
                                (0, f.jsx)(eN, { user: t, demoPriceDefault: es }),
                                (0, f.jsx)(eU, {
                                  variant: i,
                                  demoPricePrev: er,
                                  demoPriceDefault: es,
                                  user: t,
                                  iqScore: l,
                                  currentHour: o,
                                  isMarketingSource: a,
                                  abMyiqPromoPrice: A,
                                  abMyiqAb100Vs199: j,
                                  ftMyiqPaywall: E,
                                  isUSorGBUser: W,
                                  rollbackUsRegion: m,
                                  isShownCouponDisclaimer: !1,
                                  idSuffix: d,
                                }),
                              ],
                            })
                          : (0, f.jsx)(eU, {
                              variant: i,
                              demoPricePrev: er,
                              demoPriceDefault: es,
                              user: t,
                              iqScore: l,
                              currentHour: o,
                              isMarketingSource: a,
                              abMyiqPromoPrice: A,
                              abMyiqAb100Vs199: j,
                              ftMyiqPaywall: E,
                              isUSorGBUser: W,
                              rollbackUsRegion: m,
                              idSuffix: d,
                            }),
                        (0, f.jsx)("div", {
                          id: `checkout-due-today-section${d}`,
                          ref: y,
                          children: (0, f.jsx)(eq.CheckoutFormSectionComponent, {
                            abMyiqProductFeedbackWidget: S,
                            variant: i,
                            user: t,
                            isMarketingSource: a,
                            friendEncodedData: s,
                            abMyiqPromoPrice: A,
                            abMyiqAb100Vs199: j,
                            abMyiqRevolutMonzoBlock: U,
                            abMyiqPrintCertificateUpsell: C,
                            ftMyiqReviewPlatformSplit: T,
                            abMyiqBrazilMastercardOnly: I,
                            idSuffix: d,
                            containerId: p ? `checkout-container${d}` : void 0,
                            isSecondaryForm: p,
                            selectedPlan: g,
                            onPlanChange: h,
                            abMyiqPostPaymentProcessingModal: x,
                          }),
                        }),
                      ],
                    }),
            ],
          }),
        });
      };
    (e.s([], 27748),
      e.s(
        [
          "PaymentComponent",
          0,
          (e) => {
            let t,
              {
                variant: a,
                user: i,
                friendEncodedData: s,
                iqScore: r,
                currentHour: n,
                sessionId: l,
                isBrainTrain: o,
                experiments: c,
                isPlanPickerFunnel: _,
                isUSorGBUser: m,
                rollbackUsRegion: u,
                reserveDesktopTopSpace: d,
                onPaymentSectionInView: p,
                idSuffix: g = "",
                isSecondaryInstance: h,
                selectedPlanPickerPlan: x,
                onPlanPickerPlanChange: y,
              } = e,
              { abMyiqDesktopPaymentAboveFold: b, abMyiqPostPaymentProcessingModal: v } = c,
              k = (0, P.useTranslations)(),
              w = (0, K.getIsMarketingSource)(),
              { isApplovinParam: A } =
                ((t = (0, C.useSearchParams)()),
                (0, q.useMemo)(() => {
                  let e = I.accessSessionStorageUtil.getItem(E.StorageKeys.GOOGLE_PARAM),
                    a = I.accessSessionStorageUtil.getItem(E.StorageKeys.TIKTOK_PARAM),
                    i = I.accessSessionStorageUtil.getItem(E.StorageKeys.MARKETING_SOURCE),
                    s = I.accessSessionStorageUtil.getItem(E.StorageKeys.MARKETING_ID),
                    r = I.accessSessionStorageUtil.getItem(E.StorageKeys.APPLOVIN_PARAM),
                    n =
                      t.get(T.UTM_PARAMS.MYIQ_PARAM_GOOGLE) ||
                      t.get(T.UTM_PARAMS.MYIQ_PARAM_GOOGLE.toUpperCase()),
                    l =
                      t.get(T.UTM_PARAMS.MYIQ_PARAM_TIKTOK) ||
                      t.get(T.UTM_PARAMS.MYIQ_PARAM_TIKTOK.toUpperCase()),
                    o =
                      t.get(T.UTM_PARAMS.MYIQ_PARAM_APPLOVIN) ||
                      t.get(T.UTM_PARAMS.MYIQ_PARAM_APPLOVIN.toUpperCase()),
                    c = "campaign" === t.get(T.UTM_PARAMS.MYIQ_UTM),
                    _ = t.get(T.UTM_PARAMS.MYIQ_PARAM) || t.get(T.UTM_PARAMS.MYIQ_PARAM.toUpperCase()),
                    m = t.get(T.UTM_PARAMS.MYIQ_UTM_REFERRAL_DOMAIN),
                    u = t.get(T.UTM_PARAMS.MYIQ_UTM_SOURCE),
                    d = t.get(T.UTM_PARAMS.MYIQ_UTM_MEDIUM),
                    p = t.get(T.UTM_PARAMS.MYIQ_UTM_CAMPAIGN),
                    g = t.get(T.UTM_PARAMS.MYIQ_UTM_CAMPAIGN_ID),
                    h = t.get(T.UTM_PARAMS.MYIQ_UTM_ADGROUP_ID) || t.get(T.UTM_PARAMS.MYIQ_UTM_ADSET_ID),
                    x = t.get(T.UTM_PARAMS.MYIQ_UTM_AD_ID),
                    y = t.get(T.UTM_PARAMS.INITIAL_CURRENT_URL),
                    f = t.get(T.UTM_PARAMS.MYIQ_UTM_USER_TOKEN),
                    b = t.get(T.UTM_PARAMS.MYIQ_UTM_GCLID),
                    M = t.get(T.UTM_PARAMS.MYIQ_UTM_FBCLID),
                    v = t.get(T.UTM_PARAMS.MYIQ_UTM_AD_NAME),
                    k = t.get(T.UTM_PARAMS.MYIQ_UTM_TERM),
                    w = t.get(T.UTM_PARAMS.MYIQ_UTM_TARGET_ID),
                    P = t.get(T.UTM_PARAMS.MYIQ_UTM_WBRAID),
                    A = t.get(T.UTM_PARAMS.MYIQ_UTM_SOURCE_ID),
                    j = N.cookieUtil.getFbcCookie(),
                    U =
                      t.get(T.UTM_PARAMS.MYIQ_PREVENT_PARAM_GOOGLE) ===
                        T.UTM_PARAMS.MYIQ_PREVENT_PARAM_GOOGLE_VALUE ||
                      t.get(T.UTM_PARAMS.MYIQ_PREVENT_PARAM_GOOGLE.toUpperCase()) ===
                        T.UTM_PARAMS.MYIQ_PREVENT_PARAM_GOOGLE_VALUE;
                  return {
                    isGoogleParam: e || (n ? "true" : ""),
                    isTikTokParam: a || (l ? "true" : ""),
                    isApplovinParam: r || (o ? "true" : ""),
                    isMarketingSource:
                      i || s || c || _ || n || l || m || u || d || p || g || h || x || y || f || j || A || U
                        ? "true"
                        : "",
                    urlGoogleParam: n,
                    urlTikTokParam: l,
                    urlApplovinParam: o,
                    urlCampaign: c,
                    urlParamPrev: _,
                    urlReferralDomain: m,
                    urlUtmSource: u,
                    urlUtmMedium: d,
                    urlUtmCampaign: p,
                    urlUtmCampaignId: g,
                    urlUtmAdgroupId: h,
                    urlUtmAdId: x,
                    urlInitialCurrentUrl: y,
                    urlUserToken: f,
                    urlGclid: b,
                    urlFbclid: M,
                    urlUtmAdName: v,
                    urlUtmTerm: k,
                    urlUtmTargetId: w,
                    urlWbraid: P,
                    urlFbc: j,
                    urlUtmSourceId: A,
                    urlGoogleLinkPreventParam: U,
                  };
                }, [t])),
              j = ((e) => {
                let { variant: t } = e,
                  a = (0, P.useTranslations)();
                switch (t) {
                  case "myiq":
                    return ((e) => {
                      let { t } = e;
                      return [
                        {
                          icon: (0, f.jsx)(er, {}),
                          title: t("checkout_page_trust_list_title_1"),
                          subtitle: t("checkout_page_trust_list_description_1"),
                        },
                        {
                          icon: (0, f.jsx)(X, { className: "mt-0.5" }),
                          title: t("checkout_page_trust_list_title_2"),
                          subtitle: t.rich("checkout_page_trust_list_description_2", {
                            span: (e) => (0, f.jsx)("span", { children: e }),
                          }),
                        },
                        {
                          icon: (0, f.jsx)(W, { className: "mt-1" }),
                          title: t("checkout_page_trust_list_title_3"),
                          subtitle: t("checkout_page_trust_list_description_3"),
                        },
                      ];
                    })({ t: a });
                  case "personality":
                    return [
                      {
                        icon: (0, f.jsx)(ei, {}),
                        title: a("checkout_personality_page_trust_list_title_1_b"),
                        subtitle: a("checkout_personality_page_trust_list_description_1_b"),
                      },
                      {
                        icon: (0, f.jsx)(eu, {}),
                        title: a("checkout_personality_page_trust_list_title_2_b"),
                        subtitle: a("checkout_personality_page_trust_list_description_2_b"),
                      },
                      {
                        icon: (0, f.jsx)(el, {}),
                        title: a("checkout_personality_page_trust_list_title_3_b"),
                        subtitle: a("checkout_personality_page_trust_list_description_3_b"),
                      },
                    ];
                  case "love_language":
                    return [
                      {
                        icon: (0, f.jsx)(et, {}),
                        title: a("validated_love_style_test"),
                        subtitle: a("validated_love_style_test_description"),
                      },
                      {
                        icon: (0, f.jsx)(ep, {}),
                        title: a("comprehensive_report"),
                        subtitle: a("comprehensive_report_description"),
                      },
                      {
                        icon: (0, f.jsx)(ec, {}),
                        title: a("science_based_love_style_test"),
                        subtitle: a("science_based_love_style_test_description"),
                      },
                    ];
                  case "depression":
                    return [
                      {
                        icon: (0, f.jsx)(ei, {}),
                        title: a("checkout_depression_trust_title_1"),
                        subtitle: a("checkout_depression_trust_description_1"),
                      },
                      {
                        icon: (0, f.jsx)(eu, {}),
                        title: a("checkout_depression_trust_title_2"),
                        subtitle: a("checkout_depression_trust_description_2"),
                      },
                      {
                        icon: (0, f.jsx)(el, {}),
                        title: a("checkout_depression_trust_title_3"),
                        subtitle: a("checkout_depression_trust_description_3"),
                      },
                    ];
                  case "autism":
                    return [
                      {
                        icon: (0, f.jsx)(ei, {}),
                        title: a("checkout_autism_page_trust_list_title_1"),
                        subtitle: a("checkout_autism_page_trust_list_description_1"),
                      },
                      {
                        icon: (0, f.jsx)(eu, {}),
                        title: a("checkout_autism_page_trust_list_title_2"),
                        subtitle: a("checkout_autism_page_trust_list_description_2"),
                      },
                      {
                        icon: (0, f.jsx)(el, {}),
                        title: a("checkout_autism_page_trust_list_title_3"),
                        subtitle: a("checkout_autism_page_trust_list_description_3"),
                      },
                    ];
                  case "enneagram":
                    return [
                      {
                        icon: (0, f.jsx)(ei, {}),
                        title: "Enneagram Test",
                        subtitle:
                          "Our test was developed to give you a clear, accurate picture of your personality type — in plain language, without jargon.",
                      },
                      {
                        icon: (0, f.jsx)(eu, {}),
                        title: "Comprehensive Report",
                        subtitle:
                          "A detailed personalized report mapping your type, strengths, weaknesses, and growth areas.",
                      },
                      {
                        icon: (0, f.jsx)(el, {}),
                        title: "Your Growth Toolkit",
                        subtitle:
                          "Your report is just the beginning — access brain training games, expert courses, and 15+ additional assessments.",
                      },
                    ];
                  default:
                    return [];
                }
              })({ variant: a }),
              U = (0, q.useRef)(null),
              S = (0, q.useRef)(null);
            return (0, f.jsx)("div", {
              id: `checkout-payment-section${g}`,
              children: (0, f.jsxs)("section", {
                className: (0, M.cn)(
                  "relative mx-auto grid max-w-[704px] gap-4 py-10 lg:max-w-none lg:gap-6",
                  d && "lg:!pt-[90px]",
                  h && "pb-0",
                ),
                children: [
                  (0, f.jsx)("h2", {
                    id: `ab-checkout-title${g}`,
                    className:
                      "px-2 text-center text-2.7xl font-semibold leading-none tracking-tight text-gray-900 iphone-pro-max:text-3xl md:text-4xl",
                    children: _
                      ? k("plan_picker_title")
                      : "personality" === a
                        ? k("checkout_personality_page_title")
                        : "depression" === a
                          ? k("checkout_depression_page_title")
                          : "autism" === a
                            ? k("checkout_autism_page_title")
                            : "enneagram" === a
                              ? "Get Your Enneagram Report"
                              : k(
                                  o
                                    ? "checkout_page_title_get_your_benefits"
                                    : "checkout_page_title_get_your_iq_certificate",
                                ),
                  }),
                  (0, f.jsxs)("div", {
                    id: `payment${g}`,
                    ref: U,
                    className: "grid gap-10 max-sm:gap-0 md:gap-11 lg:grid-cols-2",
                    children: [
                      (0, f.jsx)(eO, {
                        variant: a,
                        isMarketingSource: w,
                        user: i,
                        friendEncodedData: s,
                        lastBulletPointRef: S,
                        isBrainTrain: o,
                        experiments: c,
                        isPlanPickerFunnel: _,
                        iqScore: r,
                        currentHour: n,
                        isUSorGBUser: m,
                        rollbackUsRegion: u,
                        onPaymentSectionInView: h ? void 0 : p,
                        idSuffix: g,
                        isSecondaryInstance: h,
                        selectedPlan: x,
                        onPlanChange: y,
                        abMyiqPostPaymentProcessingModal: v,
                      }),
                      !h &&
                        (0, f.jsx)($, {
                          variant: a,
                          user: i,
                          isApplovinParam: A,
                          trustItems: j,
                          iqScore: r,
                          currentHour: n,
                          isPaymentAboveFold: "v1_payment_above_fold" === b,
                          sessionId: l,
                          rollbackUsRegion: u,
                        }),
                    ],
                  }),
                ],
              }),
            });
          },
        ],
        722337,
      ));
  },
]);
