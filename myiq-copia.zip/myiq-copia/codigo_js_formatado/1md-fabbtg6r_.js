(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  756503,
  542516,
  846911,
  (e) => {
    "use strict";
    var t,
      i = e.i(247167);
    let r = Object.freeze({ status: "aborted" });
    function n(e, t, i) {
      function r(i, r) {
        var n;
        for (let a in (Object.defineProperty(i, "_zod", { value: i._zod ?? {}, enumerable: !1 }),
        (n = i._zod).traits ?? (n.traits = new Set()),
        i._zod.traits.add(e),
        t(i, r),
        o.prototype))
          a in i || Object.defineProperty(i, a, { value: o.prototype[a].bind(i) });
        ((i._zod.constr = o), (i._zod.def = r));
      }
      let n = i?.Parent ?? Object;
      class a extends n {}
      function o(e) {
        var t;
        let n = i?.Parent ? new a() : this;
        for (let i of (r(n, e), (t = n._zod).deferred ?? (t.deferred = []), n._zod.deferred)) i();
        return n;
      }
      return (
        Object.defineProperty(a, "name", { value: e }),
        Object.defineProperty(o, "init", { value: r }),
        Object.defineProperty(o, Symbol.hasInstance, {
          value: (t) => (!!i?.Parent && t instanceof i.Parent) || t?._zod?.traits?.has(e),
        }),
        Object.defineProperty(o, "name", { value: e }),
        o
      );
    }
    let a = Symbol("zod_brand");
    class o extends Error {
      constructor() {
        super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
      }
    }
    class u extends Error {
      constructor(e) {
        (super(`Encountered unidirectional transform during encode: ${e}`), (this.name = "ZodEncodeError"));
      }
    }
    let s = {};
    function l(e) {
      return (e && Object.assign(s, e), s);
    }
    function d(e) {
      let t = Object.values(e).filter((e) => "number" == typeof e);
      return Object.entries(e)
        .filter((e) => {
          let [i, r] = e;
          return -1 === t.indexOf(+i);
        })
        .map((e) => {
          let [t, i] = e;
          return i;
        });
    }
    function c(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "|";
      return e.map((e) => P(e)).join(t);
    }
    function m(e, t) {
      return "bigint" == typeof t ? t.toString() : t;
    }
    function f(e) {
      return {
        get value() {
          {
            let t = e();
            return (Object.defineProperty(this, "value", { value: t }), t);
          }
        },
      };
    }
    function p(e) {
      return null == e;
    }
    function v(e) {
      let t = +!!e.startsWith("^"),
        i = e.endsWith("$") ? e.length - 1 : e.length;
      return e.slice(t, i);
    }
    function g(e, t) {
      let i = (e.toString().split(".")[1] || "").length,
        r = t.toString(),
        n = (r.split(".")[1] || "").length;
      if (0 === n && /\d?e-\d?/.test(r)) {
        let e = r.match(/\d?e-(\d?)/);
        e?.[1] && (n = Number.parseInt(e[1]));
      }
      let a = i > n ? i : n;
      return (
        (Number.parseInt(e.toFixed(a).replace(".", "")) % Number.parseInt(t.toFixed(a).replace(".", ""))) /
        10 ** a
      );
    }
    e.s(
      [
        "$ZodAsyncError",
        0,
        o,
        "$ZodEncodeError",
        0,
        u,
        "$brand",
        0,
        a,
        "$constructor",
        0,
        n,
        "NEVER",
        0,
        r,
        "config",
        0,
        l,
        "globalConfig",
        0,
        s,
      ],
      197753,
    );
    let _ = Symbol("evaluating");
    function h(e, t, i) {
      let r;
      Object.defineProperty(e, t, {
        get() {
          if (r !== _) return (void 0 === r && ((r = _), (r = i())), r);
        },
        set(i) {
          Object.defineProperty(e, t, { value: i });
        },
        configurable: !0,
      });
    }
    function $(e, t, i) {
      Object.defineProperty(e, t, { value: i, writable: !0, enumerable: !0, configurable: !0 });
    }
    function y() {
      for (var e = arguments.length, t = Array(e), i = 0; i < e; i++) t[i] = arguments[i];
      let r = {};
      for (let e of t) Object.assign(r, Object.getOwnPropertyDescriptors(e));
      return Object.defineProperties({}, r);
    }
    function b(e) {
      return JSON.stringify(e);
    }
    let I =
      "captureStackTrace" in Error
        ? Error.captureStackTrace
        : function () {
            for (var e = arguments.length, t = Array(e), i = 0; i < e; i++) t[i] = arguments[i];
          };
    function x(e) {
      return "object" == typeof e && null !== e && !Array.isArray(e);
    }
    let k = f(() => {
      if ("u" > typeof navigator && navigator?.userAgent?.includes("Cloudflare")) return !1;
      try {
        return (Function(""), !0);
      } catch (e) {
        return !1;
      }
    });
    function S(e) {
      if (!1 === x(e)) return !1;
      let t = e.constructor;
      if (void 0 === t) return !0;
      let i = t.prototype;
      return !1 !== x(i) && !1 !== Object.prototype.hasOwnProperty.call(i, "isPrototypeOf");
    }
    function w(e) {
      return S(e) ? { ...e } : Array.isArray(e) ? [...e] : e;
    }
    let U = new Set(["string", "number", "symbol"]),
      E = new Set(["string", "number", "bigint", "boolean", "symbol", "undefined"]);
    function N(e) {
      return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    }
    function z(e, t, i) {
      let r = new e._zod.constr(t ?? e._zod.def);
      return ((!t || i?.parent) && (r._zod.parent = e), r);
    }
    function O(e) {
      if (!e) return {};
      if ("string" == typeof e) return { error: () => e };
      if (e?.message !== void 0) {
        if (e?.error !== void 0) throw Error("Cannot specify both `message` and `error` params");
        e.error = e.message;
      }
      return (delete e.message, "string" == typeof e.error) ? { ...e, error: () => e.error } : e;
    }
    function P(e) {
      return "bigint" == typeof e ? e.toString() + "n" : "string" == typeof e ? `"${e}"` : `${e}`;
    }
    function Z(e) {
      return Object.keys(e).filter((t) => "optional" === e[t]._zod.optin && "optional" === e[t]._zod.optout);
    }
    let j = {
        safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
        int32: [-0x80000000, 0x7fffffff],
        uint32: [0, 0xffffffff],
        float32: [-34028234663852886e22, 34028234663852886e22],
        float64: [-Number.MAX_VALUE, Number.MAX_VALUE],
      },
      T = {
        int64: [BigInt("-9223372036854775808"), BigInt("9223372036854775807")],
        uint64: [BigInt(0), BigInt("18446744073709551615")],
      };
    function D(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
      if (!0 === e.aborted) return !0;
      for (let i = t; i < e.issues.length; i++) if (e.issues[i]?.continue !== !0) return !0;
      return !1;
    }
    function A(e, t) {
      return t.map((t) => (t.path ?? (t.path = []), t.path.unshift(e), t));
    }
    function C(e) {
      return "string" == typeof e ? e : e?.message;
    }
    function L(e, t, i) {
      let r = { ...e, path: e.path ?? [] };
      return (
        e.message ||
          (r.message =
            C(e.inst?._zod.def?.error?.(e)) ??
            C(t?.error?.(e)) ??
            C(i.customError?.(e)) ??
            C(i.localeError?.(e)) ??
            "Invalid input"),
        delete r.inst,
        delete r.continue,
        t?.reportInput || delete r.input,
        r
      );
    }
    function R(e) {
      return e instanceof Set ? "set" : e instanceof Map ? "map" : e instanceof File ? "file" : "unknown";
    }
    function B(e) {
      return Array.isArray(e) ? "array" : "string" == typeof e ? "string" : "unknown";
    }
    function X() {
      for (var e = arguments.length, t = Array(e), i = 0; i < e; i++) t[i] = arguments[i];
      let [r, n, a] = t;
      return "string" == typeof r ? { message: r, code: "custom", input: n, inst: a } : { ...r };
    }
    function F(e) {
      let t = atob(e),
        i = new Uint8Array(t.length);
      for (let e = 0; e < t.length; e++) i[e] = t.charCodeAt(e);
      return i;
    }
    function J(e) {
      let t = "";
      for (let i = 0; i < e.length; i++) t += String.fromCharCode(e[i]);
      return btoa(t);
    }
    e.s(
      [
        "BIGINT_FORMAT_RANGES",
        0,
        T,
        "Class",
        0,
        class {
          constructor(...e) {}
        },
        "NUMBER_FORMAT_RANGES",
        0,
        j,
        "aborted",
        0,
        D,
        "allowsEval",
        0,
        k,
        "assert",
        0,
        function (e) {},
        "assertEqual",
        0,
        function (e) {
          return e;
        },
        "assertIs",
        0,
        function (e) {},
        "assertNever",
        0,
        function (e) {
          throw Error();
        },
        "assertNotEqual",
        0,
        function (e) {
          return e;
        },
        "assignProp",
        0,
        $,
        "base64ToUint8Array",
        0,
        F,
        "base64urlToUint8Array",
        0,
        function (e) {
          let t = e.replace(/-/g, "+").replace(/_/g, "/"),
            i = "=".repeat((4 - (t.length % 4)) % 4);
          return F(t + i);
        },
        "cached",
        0,
        f,
        "captureStackTrace",
        0,
        I,
        "cleanEnum",
        0,
        function (e) {
          return Object.entries(e)
            .filter((e) => {
              let [t, i] = e;
              return Number.isNaN(Number.parseInt(t, 10));
            })
            .map((e) => e[1]);
        },
        "cleanRegex",
        0,
        v,
        "clone",
        0,
        z,
        "cloneDef",
        0,
        function (e) {
          return y(e._zod.def);
        },
        "createTransparentProxy",
        0,
        function (e) {
          let t;
          return new Proxy(
            {},
            {
              get: (i, r, n) => (t ?? (t = e()), Reflect.get(t, r, n)),
              set: (i, r, n, a) => (t ?? (t = e()), Reflect.set(t, r, n, a)),
              has: (i, r) => (t ?? (t = e()), Reflect.has(t, r)),
              deleteProperty: (i, r) => (t ?? (t = e()), Reflect.deleteProperty(t, r)),
              ownKeys: (i) => (t ?? (t = e()), Reflect.ownKeys(t)),
              getOwnPropertyDescriptor: (i, r) => (t ?? (t = e()), Reflect.getOwnPropertyDescriptor(t, r)),
              defineProperty: (i, r, n) => (t ?? (t = e()), Reflect.defineProperty(t, r, n)),
            },
          );
        },
        "defineLazy",
        0,
        h,
        "esc",
        0,
        b,
        "escapeRegex",
        0,
        N,
        "extend",
        0,
        function (e, t) {
          if (!S(t)) throw Error("Invalid input to extend: expected a plain object");
          let i = e._zod.def.checks;
          if (i && i.length > 0)
            throw Error(
              "Object schemas containing refinements cannot be extended. Use `.safeExtend()` instead.",
            );
          let r = y(e._zod.def, {
            get shape() {
              let i = { ...e._zod.def.shape, ...t };
              return ($(this, "shape", i), i);
            },
            checks: [],
          });
          return z(e, r);
        },
        "finalizeIssue",
        0,
        L,
        "floatSafeRemainder",
        0,
        g,
        "getElementAtPath",
        0,
        function (e, t) {
          return t ? t.reduce((e, t) => e?.[t], e) : e;
        },
        "getEnumValues",
        0,
        d,
        "getLengthableOrigin",
        0,
        B,
        "getParsedType",
        0,
        (e) => {
          let t = typeof e;
          switch (t) {
            case "undefined":
              return "undefined";
            case "string":
              return "string";
            case "number":
              return Number.isNaN(e) ? "nan" : "number";
            case "boolean":
              return "boolean";
            case "function":
              return "function";
            case "bigint":
              return "bigint";
            case "symbol":
              return "symbol";
            case "object":
              if (Array.isArray(e)) return "array";
              if (null === e) return "null";
              if (e.then && "function" == typeof e.then && e.catch && "function" == typeof e.catch)
                return "promise";
              if ("u" > typeof Map && e instanceof Map) return "map";
              if ("u" > typeof Set && e instanceof Set) return "set";
              if ("u" > typeof Date && e instanceof Date) return "date";
              if ("u" > typeof File && e instanceof File) return "file";
              return "object";
            default:
              throw Error(`Unknown data type: ${t}`);
          }
        },
        "getSizableOrigin",
        0,
        R,
        "hexToUint8Array",
        0,
        function (e) {
          let t = e.replace(/^0x/, "");
          if (t.length % 2 != 0) throw Error("Invalid hex string length");
          let i = new Uint8Array(t.length / 2);
          for (let e = 0; e < t.length; e += 2) i[e / 2] = Number.parseInt(t.slice(e, e + 2), 16);
          return i;
        },
        "isObject",
        0,
        x,
        "isPlainObject",
        0,
        S,
        "issue",
        0,
        X,
        "joinValues",
        0,
        c,
        "jsonStringifyReplacer",
        0,
        m,
        "merge",
        0,
        function (e, t) {
          let i = y(e._zod.def, {
            get shape() {
              let i = { ...e._zod.def.shape, ...t._zod.def.shape };
              return ($(this, "shape", i), i);
            },
            get catchall() {
              return t._zod.def.catchall;
            },
            checks: [],
          });
          return z(e, i);
        },
        "mergeDefs",
        0,
        y,
        "normalizeParams",
        0,
        O,
        "nullish",
        0,
        p,
        "numKeys",
        0,
        function (e) {
          let t = 0;
          for (let i in e) Object.prototype.hasOwnProperty.call(e, i) && t++;
          return t;
        },
        "objectClone",
        0,
        function (e) {
          return Object.create(Object.getPrototypeOf(e), Object.getOwnPropertyDescriptors(e));
        },
        "omit",
        0,
        function (e, t) {
          let i = e._zod.def,
            r = y(e._zod.def, {
              get shape() {
                let r = { ...e._zod.def.shape };
                for (let e in t) {
                  if (!(e in i.shape)) throw Error(`Unrecognized key: "${e}"`);
                  t[e] && delete r[e];
                }
                return ($(this, "shape", r), r);
              },
              checks: [],
            });
          return z(e, r);
        },
        "optionalKeys",
        0,
        Z,
        "partial",
        0,
        function (e, t, i) {
          let r = y(t._zod.def, {
            get shape() {
              let r = t._zod.def.shape,
                n = { ...r };
              if (i)
                for (let t in i) {
                  if (!(t in r)) throw Error(`Unrecognized key: "${t}"`);
                  i[t] && (n[t] = e ? new e({ type: "optional", innerType: r[t] }) : r[t]);
                }
              else for (let t in r) n[t] = e ? new e({ type: "optional", innerType: r[t] }) : r[t];
              return ($(this, "shape", n), n);
            },
            checks: [],
          });
          return z(t, r);
        },
        "pick",
        0,
        function (e, t) {
          let i = e._zod.def,
            r = y(e._zod.def, {
              get shape() {
                let e = {};
                for (let r in t) {
                  if (!(r in i.shape)) throw Error(`Unrecognized key: "${r}"`);
                  t[r] && (e[r] = i.shape[r]);
                }
                return ($(this, "shape", e), e);
              },
              checks: [],
            });
          return z(e, r);
        },
        "prefixIssues",
        0,
        A,
        "primitiveTypes",
        0,
        E,
        "promiseAllObject",
        0,
        function (e) {
          let t = Object.keys(e);
          return Promise.all(t.map((t) => e[t])).then((e) => {
            let i = {};
            for (let r = 0; r < t.length; r++) i[t[r]] = e[r];
            return i;
          });
        },
        "propertyKeyTypes",
        0,
        U,
        "randomString",
        0,
        function () {
          let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 10,
            t = "abcdefghijklmnopqrstuvwxyz",
            i = "";
          for (let r = 0; r < e; r++) i += t[Math.floor(Math.random() * t.length)];
          return i;
        },
        "required",
        0,
        function (e, t, i) {
          let r = y(t._zod.def, {
            get shape() {
              let r = t._zod.def.shape,
                n = { ...r };
              if (i)
                for (let t in i) {
                  if (!(t in n)) throw Error(`Unrecognized key: "${t}"`);
                  i[t] && (n[t] = new e({ type: "nonoptional", innerType: r[t] }));
                }
              else for (let t in r) n[t] = new e({ type: "nonoptional", innerType: r[t] });
              return ($(this, "shape", n), n);
            },
            checks: [],
          });
          return z(t, r);
        },
        "safeExtend",
        0,
        function (e, t) {
          if (!S(t)) throw Error("Invalid input to safeExtend: expected a plain object");
          let i = {
            ...e._zod.def,
            get shape() {
              let i = { ...e._zod.def.shape, ...t };
              return ($(this, "shape", i), i);
            },
            checks: e._zod.def.checks,
          };
          return z(e, i);
        },
        "shallowClone",
        0,
        w,
        "stringifyPrimitive",
        0,
        P,
        "uint8ArrayToBase64",
        0,
        J,
        "uint8ArrayToBase64url",
        0,
        function (e) {
          return J(e).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
        },
        "uint8ArrayToHex",
        0,
        function (e) {
          return Array.from(e)
            .map((e) => e.toString(16).padStart(2, "0"))
            .join("");
        },
        "unwrapMessage",
        0,
        C,
      ],
      922143,
    );
    let G = (e, t) => {
        ((e.name = "$ZodError"),
          Object.defineProperty(e, "_zod", { value: e._zod, enumerable: !1 }),
          Object.defineProperty(e, "issues", { value: t, enumerable: !1 }),
          (e.message = JSON.stringify(t, m, 2)),
          Object.defineProperty(e, "toString", { value: () => e.message, enumerable: !1 }));
      },
      M = n("$ZodError", G),
      K = n("$ZodError", G, { Parent: Error });
    function V(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : (e) => e.message,
        i = {},
        r = [];
      for (let n of e.issues)
        n.path.length > 0 ? ((i[n.path[0]] = i[n.path[0]] || []), i[n.path[0]].push(t(n))) : r.push(t(n));
      return { formErrors: r, fieldErrors: i };
    }
    function W(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : (e) => e.message,
        i = { _errors: [] },
        r = (e) => {
          for (let n of e.issues)
            if ("invalid_union" === n.code && n.errors.length) n.errors.map((e) => r({ issues: e }));
            else if ("invalid_key" === n.code) r({ issues: n.issues });
            else if ("invalid_element" === n.code) r({ issues: n.issues });
            else if (0 === n.path.length) i._errors.push(t(n));
            else {
              let e = i,
                r = 0;
              for (; r < n.path.length;) {
                let i = n.path[r];
                (r === n.path.length - 1
                  ? ((e[i] = e[i] || { _errors: [] }), e[i]._errors.push(t(n)))
                  : (e[i] = e[i] || { _errors: [] }),
                  (e = e[i]),
                  r++);
              }
            }
        };
      return (r(e), i);
    }
    function q(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : (e) => e.message,
        i = { errors: [] },
        r = function (e) {
          var n, a;
          let o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
          for (let u of e.issues)
            if ("invalid_union" === u.code && u.errors.length) u.errors.map((e) => r({ issues: e }, u.path));
            else if ("invalid_key" === u.code) r({ issues: u.issues }, u.path);
            else if ("invalid_element" === u.code) r({ issues: u.issues }, u.path);
            else {
              let e = [...o, ...u.path];
              if (0 === e.length) {
                i.errors.push(t(u));
                continue;
              }
              let r = i,
                s = 0;
              for (; s < e.length;) {
                let i = e[s],
                  o = s === e.length - 1;
                ("string" == typeof i
                  ? (r.properties ?? (r.properties = {}),
                    (n = r.properties)[i] ?? (n[i] = { errors: [] }),
                    (r = r.properties[i]))
                  : (r.items ?? (r.items = []),
                    (a = r.items)[i] ?? (a[i] = { errors: [] }),
                    (r = r.items[i])),
                  o && r.errors.push(t(u)),
                  s++);
              }
            }
        };
      return (r(e), i);
    }
    function Y(e) {
      let t = [];
      for (let i of e.map((e) => ("object" == typeof e ? e.key : e)))
        "number" == typeof i
          ? t.push(`[${i}]`)
          : "symbol" == typeof i
            ? t.push(`[${JSON.stringify(String(i))}]`)
            : /[^\w$]/.test(i)
              ? t.push(`[${JSON.stringify(i)}]`)
              : (t.length && t.push("."), t.push(i));
      return t.join("");
    }
    function H(e) {
      let t = [];
      for (let i of [...e.issues].sort((e, t) => (e.path ?? []).length - (t.path ?? []).length))
        (t.push(`✖ ${i.message}`), i.path?.length && t.push(`  → at ${Y(i.path)}`));
      return t.join("\n");
    }
    e.s(
      [
        "$ZodError",
        0,
        M,
        "$ZodRealError",
        0,
        K,
        "flattenError",
        0,
        V,
        "formatError",
        0,
        W,
        "prettifyError",
        0,
        H,
        "toDotPath",
        0,
        Y,
        "treeifyError",
        0,
        q,
      ],
      374969,
    );
    let Q = (e) => (t, i, r, n) => {
        let a = r ? Object.assign(r, { async: !1 }) : { async: !1 },
          u = t._zod.run({ value: i, issues: [] }, a);
        if (u instanceof Promise) throw new o();
        if (u.issues.length) {
          let t = new (n?.Err ?? e)(u.issues.map((e) => L(e, a, l())));
          throw (I(t, n?.callee), t);
        }
        return u.value;
      },
      ee = Q(K),
      et = (e) => async (t, i, r, n) => {
        let a = r ? Object.assign(r, { async: !0 }) : { async: !0 },
          o = t._zod.run({ value: i, issues: [] }, a);
        if ((o instanceof Promise && (o = await o), o.issues.length)) {
          let t = new (n?.Err ?? e)(o.issues.map((e) => L(e, a, l())));
          throw (I(t, n?.callee), t);
        }
        return o.value;
      },
      ei = et(K),
      er = (e) => (t, i, r) => {
        let n = r ? { ...r, async: !1 } : { async: !1 },
          a = t._zod.run({ value: i, issues: [] }, n);
        if (a instanceof Promise) throw new o();
        return a.issues.length
          ? { success: !1, error: new (e ?? M)(a.issues.map((e) => L(e, n, l()))) }
          : { success: !0, data: a.value };
      },
      en = er(K),
      ea = (e) => async (t, i, r) => {
        let n = r ? Object.assign(r, { async: !0 }) : { async: !0 },
          a = t._zod.run({ value: i, issues: [] }, n);
        return (
          a instanceof Promise && (a = await a),
          a.issues.length
            ? { success: !1, error: new e(a.issues.map((e) => L(e, n, l()))) }
            : { success: !0, data: a.value }
        );
      },
      eo = ea(K),
      eu = (e) => (t, i, r) => {
        let n = r ? Object.assign(r, { direction: "backward" }) : { direction: "backward" };
        return Q(e)(t, i, n);
      },
      es = eu(K),
      el = (e) => (t, i, r) => Q(e)(t, i, r),
      ed = el(K),
      ec = (e) => async (t, i, r) => {
        let n = r ? Object.assign(r, { direction: "backward" }) : { direction: "backward" };
        return et(e)(t, i, n);
      },
      em = ec(K),
      ef = (e) => async (t, i, r) => et(e)(t, i, r),
      ep = ef(K),
      ev = (e) => (t, i, r) => {
        let n = r ? Object.assign(r, { direction: "backward" }) : { direction: "backward" };
        return er(e)(t, i, n);
      },
      eg = ev(K),
      e_ = (e) => (t, i, r) => er(e)(t, i, r),
      eh = e_(K),
      e$ = (e) => async (t, i, r) => {
        let n = r ? Object.assign(r, { direction: "backward" }) : { direction: "backward" };
        return ea(e)(t, i, n);
      },
      ey = e$(K),
      eb = (e) => async (t, i, r) => ea(e)(t, i, r),
      eI = eb(K);
    e.s(
      [
        "_decode",
        0,
        el,
        "_decodeAsync",
        0,
        ef,
        "_encode",
        0,
        eu,
        "_encodeAsync",
        0,
        ec,
        "_parse",
        0,
        Q,
        "_parseAsync",
        0,
        et,
        "_safeDecode",
        0,
        e_,
        "_safeDecodeAsync",
        0,
        eb,
        "_safeEncode",
        0,
        ev,
        "_safeEncodeAsync",
        0,
        e$,
        "_safeParse",
        0,
        er,
        "_safeParseAsync",
        0,
        ea,
        "decode",
        0,
        ed,
        "decodeAsync",
        0,
        ep,
        "encode",
        0,
        es,
        "encodeAsync",
        0,
        em,
        "parse",
        0,
        ee,
        "parseAsync",
        0,
        ei,
        "safeDecode",
        0,
        eh,
        "safeDecodeAsync",
        0,
        eI,
        "safeEncode",
        0,
        eg,
        "safeEncodeAsync",
        0,
        ey,
        "safeParse",
        0,
        en,
        "safeParseAsync",
        0,
        eo,
      ],
      803108,
    );
    let ex = /^[cC][^\s-]{8,}$/,
      ek = /^[0-9a-z]+$/,
      eS = /^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/,
      ew = /^[0-9a-vA-V]{20}$/,
      eU = /^[A-Za-z0-9]{27}$/,
      eE = /^[a-zA-Z0-9_-]{21}$/,
      eN = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/,
      ez = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/,
      eO = (e) =>
        e
          ? RegExp(
              `^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`,
            )
          : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/,
      eP = eO(4),
      eZ = eO(6),
      ej = eO(7),
      eT = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/,
      eD = /^[^\s@"]{1,64}@[^\s@]{1,255}$/u;
    function eA() {
      return RegExp("^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$", "u");
    }
    let eC =
        /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/,
      eL =
        /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/,
      eR =
        /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/,
      eB =
        /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/,
      eX = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/,
      eF = /^[A-Za-z0-9_-]*$/,
      eJ =
        /^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/,
      eG = /^\+(?:[0-9]){6,14}[0-9]$/,
      eM =
        "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))",
      eK = RegExp(`^${eM}$`);
    function eV(e) {
      let t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
      return "number" == typeof e.precision
        ? -1 === e.precision
          ? `${t}`
          : 0 === e.precision
            ? `${t}:[0-5]\\d`
            : `${t}:[0-5]\\d\\.\\d{${e.precision}}`
        : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
    }
    function eW(e) {
      return RegExp(`^${eV(e)}$`);
    }
    function eq(e) {
      let t = eV({ precision: e.precision }),
        i = ["Z"];
      (e.local && i.push(""), e.offset && i.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)"));
      let r = `${t}(?:${i.join("|")})`;
      return RegExp(`^${eM}T(?:${r})$`);
    }
    let eY = (e) => {
        let t = e ? `[\\s\\S]{${e?.minimum ?? 0},${e?.maximum ?? ""}}` : "[\\s\\S]*";
        return RegExp(`^${t}$`);
      },
      eH = /^-?\d+n?$/,
      eQ = /^-?\d+$/,
      e0 = /^-?\d+(?:\.\d+)?/,
      e4 = /^(?:true|false)$/i,
      e6 = /^null$/i,
      e1 = /^undefined$/i,
      e2 = /^[^A-Z]*$/,
      e9 = /^[^a-z]*$/;
    function e3(e, t) {
      return RegExp(`^[A-Za-z0-9+/]{${e}}${t}$`);
    }
    function e5(e) {
      return RegExp(`^[A-Za-z0-9_-]{${e}}$`);
    }
    let e7 = e3(22, "=="),
      e8 = e5(22),
      te = e3(27, "="),
      tt = e5(27),
      ti = e3(43, "="),
      tr = e5(43),
      tn = e3(64, ""),
      ta = e5(64),
      to = e3(86, "=="),
      tu = e5(86);
    e.s(
      [
        "base64",
        0,
        eX,
        "base64url",
        0,
        eF,
        "bigint",
        0,
        eH,
        "boolean",
        0,
        e4,
        "browserEmail",
        0,
        /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/,
        "cidrv4",
        0,
        eR,
        "cidrv6",
        0,
        eB,
        "cuid",
        0,
        ex,
        "cuid2",
        0,
        ek,
        "date",
        0,
        eK,
        "datetime",
        0,
        eq,
        "domain",
        0,
        /^([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/,
        "duration",
        0,
        eN,
        "e164",
        0,
        eG,
        "email",
        0,
        eT,
        "emoji",
        0,
        eA,
        "extendedDuration",
        0,
        /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/,
        "guid",
        0,
        ez,
        "hex",
        0,
        /^[0-9a-fA-F]*$/,
        "hostname",
        0,
        eJ,
        "html5Email",
        0,
        /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/,
        "idnEmail",
        0,
        eD,
        "integer",
        0,
        eQ,
        "ipv4",
        0,
        eC,
        "ipv6",
        0,
        eL,
        "ksuid",
        0,
        eU,
        "lowercase",
        0,
        e2,
        "md5_base64",
        0,
        e7,
        "md5_base64url",
        0,
        e8,
        "md5_hex",
        0,
        /^[0-9a-fA-F]{32}$/,
        "nanoid",
        0,
        eE,
        "null",
        0,
        e6,
        "number",
        0,
        e0,
        "rfc5322Email",
        0,
        /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
        "sha1_base64",
        0,
        te,
        "sha1_base64url",
        0,
        tt,
        "sha1_hex",
        0,
        /^[0-9a-fA-F]{40}$/,
        "sha256_base64",
        0,
        ti,
        "sha256_base64url",
        0,
        tr,
        "sha256_hex",
        0,
        /^[0-9a-fA-F]{64}$/,
        "sha384_base64",
        0,
        tn,
        "sha384_base64url",
        0,
        ta,
        "sha384_hex",
        0,
        /^[0-9a-fA-F]{96}$/,
        "sha512_base64",
        0,
        to,
        "sha512_base64url",
        0,
        tu,
        "sha512_hex",
        0,
        /^[0-9a-fA-F]{128}$/,
        "string",
        0,
        eY,
        "time",
        0,
        eW,
        "ulid",
        0,
        eS,
        "undefined",
        0,
        e1,
        "unicodeEmail",
        0,
        eD,
        "uppercase",
        0,
        e9,
        "uuid",
        0,
        eO,
        "uuid4",
        0,
        eP,
        "uuid6",
        0,
        eZ,
        "uuid7",
        0,
        ej,
        "xid",
        0,
        ew,
      ],
      682358,
    );
    let ts = n("$ZodCheck", (e, t) => {
        var i;
        (e._zod ?? (e._zod = {}), (e._zod.def = t), (i = e._zod).onattach ?? (i.onattach = []));
      }),
      tl = { number: "number", bigint: "bigint", object: "date" },
      td = n("$ZodCheckLessThan", (e, t) => {
        ts.init(e, t);
        let i = tl[typeof t.value];
        (e._zod.onattach.push((e) => {
          let i = e._zod.bag,
            r = (t.inclusive ? i.maximum : i.exclusiveMaximum) ?? 1 / 0;
          t.value < r && (t.inclusive ? (i.maximum = t.value) : (i.exclusiveMaximum = t.value));
        }),
          (e._zod.check = (r) => {
            (t.inclusive ? r.value <= t.value : r.value < t.value) ||
              r.issues.push({
                origin: i,
                code: "too_big",
                maximum: t.value,
                input: r.value,
                inclusive: t.inclusive,
                inst: e,
                continue: !t.abort,
              });
          }));
      }),
      tc = n("$ZodCheckGreaterThan", (e, t) => {
        ts.init(e, t);
        let i = tl[typeof t.value];
        (e._zod.onattach.push((e) => {
          let i = e._zod.bag,
            r = (t.inclusive ? i.minimum : i.exclusiveMinimum) ?? -1 / 0;
          t.value > r && (t.inclusive ? (i.minimum = t.value) : (i.exclusiveMinimum = t.value));
        }),
          (e._zod.check = (r) => {
            (t.inclusive ? r.value >= t.value : r.value > t.value) ||
              r.issues.push({
                origin: i,
                code: "too_small",
                minimum: t.value,
                input: r.value,
                inclusive: t.inclusive,
                inst: e,
                continue: !t.abort,
              });
          }));
      }),
      tm = n("$ZodCheckMultipleOf", (e, t) => {
        (ts.init(e, t),
          e._zod.onattach.push((e) => {
            var i;
            (i = e._zod.bag).multipleOf ?? (i.multipleOf = t.value);
          }),
          (e._zod.check = (i) => {
            if (typeof i.value != typeof t.value)
              throw Error("Cannot mix number and bigint in multiple_of check.");
            ("bigint" == typeof i.value ? i.value % t.value === BigInt(0) : 0 === g(i.value, t.value)) ||
              i.issues.push({
                origin: typeof i.value,
                code: "not_multiple_of",
                divisor: t.value,
                input: i.value,
                inst: e,
                continue: !t.abort,
              });
          }));
      }),
      tf = n("$ZodCheckNumberFormat", (e, t) => {
        (ts.init(e, t), (t.format = t.format || "float64"));
        let i = t.format?.includes("int"),
          r = i ? "int" : "number",
          [n, a] = j[t.format];
        (e._zod.onattach.push((e) => {
          let r = e._zod.bag;
          ((r.format = t.format), (r.minimum = n), (r.maximum = a), i && (r.pattern = eQ));
        }),
          (e._zod.check = (o) => {
            let u = o.value;
            if (i) {
              if (!Number.isInteger(u))
                return void o.issues.push({
                  expected: r,
                  format: t.format,
                  code: "invalid_type",
                  continue: !1,
                  input: u,
                  inst: e,
                });
              if (!Number.isSafeInteger(u))
                return void (u > 0
                  ? o.issues.push({
                      input: u,
                      code: "too_big",
                      maximum: Number.MAX_SAFE_INTEGER,
                      note: "Integers must be within the safe integer range.",
                      inst: e,
                      origin: r,
                      continue: !t.abort,
                    })
                  : o.issues.push({
                      input: u,
                      code: "too_small",
                      minimum: Number.MIN_SAFE_INTEGER,
                      note: "Integers must be within the safe integer range.",
                      inst: e,
                      origin: r,
                      continue: !t.abort,
                    }));
            }
            (u < n &&
              o.issues.push({
                origin: "number",
                input: u,
                code: "too_small",
                minimum: n,
                inclusive: !0,
                inst: e,
                continue: !t.abort,
              }),
              u > a && o.issues.push({ origin: "number", input: u, code: "too_big", maximum: a, inst: e }));
          }));
      }),
      tp = n("$ZodCheckBigIntFormat", (e, t) => {
        ts.init(e, t);
        let [i, r] = T[t.format];
        (e._zod.onattach.push((e) => {
          let n = e._zod.bag;
          ((n.format = t.format), (n.minimum = i), (n.maximum = r));
        }),
          (e._zod.check = (n) => {
            let a = n.value;
            (a < i &&
              n.issues.push({
                origin: "bigint",
                input: a,
                code: "too_small",
                minimum: i,
                inclusive: !0,
                inst: e,
                continue: !t.abort,
              }),
              a > r && n.issues.push({ origin: "bigint", input: a, code: "too_big", maximum: r, inst: e }));
          }));
      }),
      tv = n("$ZodCheckMaxSize", (e, t) => {
        var i;
        (ts.init(e, t),
          (i = e._zod.def).when ??
            (i.when = (e) => {
              let t = e.value;
              return !p(t) && void 0 !== t.size;
            }),
          e._zod.onattach.push((e) => {
            let i = e._zod.bag.maximum ?? 1 / 0;
            t.maximum < i && (e._zod.bag.maximum = t.maximum);
          }),
          (e._zod.check = (i) => {
            let r = i.value;
            r.size <= t.maximum ||
              i.issues.push({
                origin: R(r),
                code: "too_big",
                maximum: t.maximum,
                inclusive: !0,
                input: r,
                inst: e,
                continue: !t.abort,
              });
          }));
      }),
      tg = n("$ZodCheckMinSize", (e, t) => {
        var i;
        (ts.init(e, t),
          (i = e._zod.def).when ??
            (i.when = (e) => {
              let t = e.value;
              return !p(t) && void 0 !== t.size;
            }),
          e._zod.onattach.push((e) => {
            let i = e._zod.bag.minimum ?? -1 / 0;
            t.minimum > i && (e._zod.bag.minimum = t.minimum);
          }),
          (e._zod.check = (i) => {
            let r = i.value;
            r.size >= t.minimum ||
              i.issues.push({
                origin: R(r),
                code: "too_small",
                minimum: t.minimum,
                inclusive: !0,
                input: r,
                inst: e,
                continue: !t.abort,
              });
          }));
      }),
      t_ = n("$ZodCheckSizeEquals", (e, t) => {
        var i;
        (ts.init(e, t),
          (i = e._zod.def).when ??
            (i.when = (e) => {
              let t = e.value;
              return !p(t) && void 0 !== t.size;
            }),
          e._zod.onattach.push((e) => {
            let i = e._zod.bag;
            ((i.minimum = t.size), (i.maximum = t.size), (i.size = t.size));
          }),
          (e._zod.check = (i) => {
            let r = i.value,
              n = r.size;
            if (n === t.size) return;
            let a = n > t.size;
            i.issues.push({
              origin: R(r),
              ...(a ? { code: "too_big", maximum: t.size } : { code: "too_small", minimum: t.size }),
              inclusive: !0,
              exact: !0,
              input: i.value,
              inst: e,
              continue: !t.abort,
            });
          }));
      }),
      th = n("$ZodCheckMaxLength", (e, t) => {
        var i;
        (ts.init(e, t),
          (i = e._zod.def).when ??
            (i.when = (e) => {
              let t = e.value;
              return !p(t) && void 0 !== t.length;
            }),
          e._zod.onattach.push((e) => {
            let i = e._zod.bag.maximum ?? 1 / 0;
            t.maximum < i && (e._zod.bag.maximum = t.maximum);
          }),
          (e._zod.check = (i) => {
            let r = i.value;
            if (r.length <= t.maximum) return;
            let n = B(r);
            i.issues.push({
              origin: n,
              code: "too_big",
              maximum: t.maximum,
              inclusive: !0,
              input: r,
              inst: e,
              continue: !t.abort,
            });
          }));
      }),
      t$ = n("$ZodCheckMinLength", (e, t) => {
        var i;
        (ts.init(e, t),
          (i = e._zod.def).when ??
            (i.when = (e) => {
              let t = e.value;
              return !p(t) && void 0 !== t.length;
            }),
          e._zod.onattach.push((e) => {
            let i = e._zod.bag.minimum ?? -1 / 0;
            t.minimum > i && (e._zod.bag.minimum = t.minimum);
          }),
          (e._zod.check = (i) => {
            let r = i.value;
            if (r.length >= t.minimum) return;
            let n = B(r);
            i.issues.push({
              origin: n,
              code: "too_small",
              minimum: t.minimum,
              inclusive: !0,
              input: r,
              inst: e,
              continue: !t.abort,
            });
          }));
      }),
      ty = n("$ZodCheckLengthEquals", (e, t) => {
        var i;
        (ts.init(e, t),
          (i = e._zod.def).when ??
            (i.when = (e) => {
              let t = e.value;
              return !p(t) && void 0 !== t.length;
            }),
          e._zod.onattach.push((e) => {
            let i = e._zod.bag;
            ((i.minimum = t.length), (i.maximum = t.length), (i.length = t.length));
          }),
          (e._zod.check = (i) => {
            let r = i.value,
              n = r.length;
            if (n === t.length) return;
            let a = B(r),
              o = n > t.length;
            i.issues.push({
              origin: a,
              ...(o ? { code: "too_big", maximum: t.length } : { code: "too_small", minimum: t.length }),
              inclusive: !0,
              exact: !0,
              input: i.value,
              inst: e,
              continue: !t.abort,
            });
          }));
      }),
      tb = n("$ZodCheckStringFormat", (e, t) => {
        var i, r;
        (ts.init(e, t),
          e._zod.onattach.push((e) => {
            let i = e._zod.bag;
            ((i.format = t.format),
              t.pattern && (i.patterns ?? (i.patterns = new Set()), i.patterns.add(t.pattern)));
          }),
          t.pattern
            ? ((i = e._zod).check ??
              (i.check = (i) => {
                ((t.pattern.lastIndex = 0),
                  t.pattern.test(i.value) ||
                    i.issues.push({
                      origin: "string",
                      code: "invalid_format",
                      format: t.format,
                      input: i.value,
                      ...(t.pattern ? { pattern: t.pattern.toString() } : {}),
                      inst: e,
                      continue: !t.abort,
                    }));
              }))
            : ((r = e._zod).check ?? (r.check = () => {})));
      }),
      tI = n("$ZodCheckRegex", (e, t) => {
        (tb.init(e, t),
          (e._zod.check = (i) => {
            ((t.pattern.lastIndex = 0),
              t.pattern.test(i.value) ||
                i.issues.push({
                  origin: "string",
                  code: "invalid_format",
                  format: "regex",
                  input: i.value,
                  pattern: t.pattern.toString(),
                  inst: e,
                  continue: !t.abort,
                }));
          }));
      }),
      tx = n("$ZodCheckLowerCase", (e, t) => {
        (t.pattern ?? (t.pattern = e2), tb.init(e, t));
      }),
      tk = n("$ZodCheckUpperCase", (e, t) => {
        (t.pattern ?? (t.pattern = e9), tb.init(e, t));
      }),
      tS = n("$ZodCheckIncludes", (e, t) => {
        ts.init(e, t);
        let i = N(t.includes),
          r = new RegExp("number" == typeof t.position ? `^.{${t.position}}${i}` : i);
        ((t.pattern = r),
          e._zod.onattach.push((e) => {
            let t = e._zod.bag;
            (t.patterns ?? (t.patterns = new Set()), t.patterns.add(r));
          }),
          (e._zod.check = (i) => {
            i.value.includes(t.includes, t.position) ||
              i.issues.push({
                origin: "string",
                code: "invalid_format",
                format: "includes",
                includes: t.includes,
                input: i.value,
                inst: e,
                continue: !t.abort,
              });
          }));
      }),
      tw = n("$ZodCheckStartsWith", (e, t) => {
        ts.init(e, t);
        let i = RegExp(`^${N(t.prefix)}.*`);
        (t.pattern ?? (t.pattern = i),
          e._zod.onattach.push((e) => {
            let t = e._zod.bag;
            (t.patterns ?? (t.patterns = new Set()), t.patterns.add(i));
          }),
          (e._zod.check = (i) => {
            i.value.startsWith(t.prefix) ||
              i.issues.push({
                origin: "string",
                code: "invalid_format",
                format: "starts_with",
                prefix: t.prefix,
                input: i.value,
                inst: e,
                continue: !t.abort,
              });
          }));
      }),
      tU = n("$ZodCheckEndsWith", (e, t) => {
        ts.init(e, t);
        let i = RegExp(`.*${N(t.suffix)}$`);
        (t.pattern ?? (t.pattern = i),
          e._zod.onattach.push((e) => {
            let t = e._zod.bag;
            (t.patterns ?? (t.patterns = new Set()), t.patterns.add(i));
          }),
          (e._zod.check = (i) => {
            i.value.endsWith(t.suffix) ||
              i.issues.push({
                origin: "string",
                code: "invalid_format",
                format: "ends_with",
                suffix: t.suffix,
                input: i.value,
                inst: e,
                continue: !t.abort,
              });
          }));
      });
    function tE(e, t, i) {
      e.issues.length && t.issues.push(...A(i, e.issues));
    }
    let tN = n("$ZodCheckProperty", (e, t) => {
        (ts.init(e, t),
          (e._zod.check = (e) => {
            let i = t.schema._zod.run({ value: e.value[t.property], issues: [] }, {});
            if (i instanceof Promise) return i.then((i) => tE(i, e, t.property));
            tE(i, e, t.property);
          }));
      }),
      tz = n("$ZodCheckMimeType", (e, t) => {
        ts.init(e, t);
        let i = new Set(t.mime);
        (e._zod.onattach.push((e) => {
          e._zod.bag.mime = t.mime;
        }),
          (e._zod.check = (r) => {
            i.has(r.value.type) ||
              r.issues.push({
                code: "invalid_value",
                values: t.mime,
                input: r.value.type,
                inst: e,
                continue: !t.abort,
              });
          }));
      }),
      tO = n("$ZodCheckOverwrite", (e, t) => {
        (ts.init(e, t),
          (e._zod.check = (e) => {
            e.value = t.tx(e.value);
          }));
      });
    e.s(
      [
        "$ZodCheck",
        0,
        ts,
        "$ZodCheckBigIntFormat",
        0,
        tp,
        "$ZodCheckEndsWith",
        0,
        tU,
        "$ZodCheckGreaterThan",
        0,
        tc,
        "$ZodCheckIncludes",
        0,
        tS,
        "$ZodCheckLengthEquals",
        0,
        ty,
        "$ZodCheckLessThan",
        0,
        td,
        "$ZodCheckLowerCase",
        0,
        tx,
        "$ZodCheckMaxLength",
        0,
        th,
        "$ZodCheckMaxSize",
        0,
        tv,
        "$ZodCheckMimeType",
        0,
        tz,
        "$ZodCheckMinLength",
        0,
        t$,
        "$ZodCheckMinSize",
        0,
        tg,
        "$ZodCheckMultipleOf",
        0,
        tm,
        "$ZodCheckNumberFormat",
        0,
        tf,
        "$ZodCheckOverwrite",
        0,
        tO,
        "$ZodCheckProperty",
        0,
        tN,
        "$ZodCheckRegex",
        0,
        tI,
        "$ZodCheckSizeEquals",
        0,
        t_,
        "$ZodCheckStartsWith",
        0,
        tw,
        "$ZodCheckStringFormat",
        0,
        tb,
        "$ZodCheckUpperCase",
        0,
        tk,
      ],
      355605,
    );
    class tP {
      constructor(e = []) {
        ((this.content = []), (this.indent = 0), this && (this.args = e));
      }
      indented(e) {
        ((this.indent += 1), e(this), (this.indent -= 1));
      }
      write(e) {
        if ("function" == typeof e) {
          (e(this, { execution: "sync" }), e(this, { execution: "async" }));
          return;
        }
        let t = e.split("\n").filter((e) => e),
          i = Math.min(...t.map((e) => e.length - e.trimStart().length));
        for (let e of t.map((e) => e.slice(i)).map((e) => " ".repeat(2 * this.indent) + e))
          this.content.push(e);
      }
      compile() {
        return Function(...this?.args, [...(this?.content ?? [""]).map((e) => `  ${e}`)].join("\n"));
      }
    }
    e.s(["Doc", 0, tP], 698530);
    let tZ = { major: 4, minor: 1, patch: 12 };
    e.s(["version", 0, tZ], 398477);
    let tj = n("$ZodType", (e, t) => {
        var i;
        (e ?? (e = {}), (e._zod.def = t), (e._zod.bag = e._zod.bag || {}), (e._zod.version = tZ));
        let r = [...(e._zod.def.checks ?? [])];
        for (let t of (e._zod.traits.has("$ZodCheck") && r.unshift(e), r))
          for (let i of t._zod.onattach) i(e);
        if (0 === r.length)
          ((i = e._zod).deferred ?? (i.deferred = []),
            e._zod.deferred?.push(() => {
              e._zod.run = e._zod.parse;
            }));
        else {
          let t = (e, t, i) => {
              let r,
                n = D(e);
              for (let a of t) {
                if (a._zod.def.when) {
                  if (!a._zod.def.when(e)) continue;
                } else if (n) continue;
                let t = e.issues.length,
                  u = a._zod.check(e);
                if (u instanceof Promise && i?.async === !1) throw new o();
                if (r || u instanceof Promise)
                  r = (r ?? Promise.resolve()).then(async () => {
                    (await u, e.issues.length !== t && (n || (n = D(e, t))));
                  });
                else {
                  if (e.issues.length === t) continue;
                  n || (n = D(e, t));
                }
              }
              return r ? r.then(() => e) : e;
            },
            i = (i, n, a) => {
              if (D(i)) return ((i.aborted = !0), i);
              let u = t(n, r, a);
              if (u instanceof Promise) {
                if (!1 === a.async) throw new o();
                return u.then((t) => e._zod.parse(t, a));
              }
              return e._zod.parse(u, a);
            };
          e._zod.run = (n, a) => {
            if (a.skipChecks) return e._zod.parse(n, a);
            if ("backward" === a.direction) {
              let t = e._zod.parse({ value: n.value, issues: [] }, { ...a, skipChecks: !0 });
              return t instanceof Promise ? t.then((e) => i(e, n, a)) : i(t, n, a);
            }
            let u = e._zod.parse(n, a);
            if (u instanceof Promise) {
              if (!1 === a.async) throw new o();
              return u.then((e) => t(e, r, a));
            }
            return t(u, r, a);
          };
        }
        e["~standard"] = {
          validate: (t) => {
            try {
              let i = en(e, t);
              return i.success ? { value: i.data } : { issues: i.error?.issues };
            } catch (i) {
              return eo(e, t).then((e) => (e.success ? { value: e.data } : { issues: e.error?.issues }));
            }
          },
          vendor: "zod",
          version: 1,
        };
      }),
      tT = n("$ZodString", (e, t) => {
        (tj.init(e, t),
          (e._zod.pattern = [...(e?._zod.bag?.patterns ?? [])].pop() ?? eY(e._zod.bag)),
          (e._zod.parse = (i, r) => {
            if (t.coerce)
              try {
                i.value = String(i.value);
              } catch (e) {}
            return (
              "string" == typeof i.value ||
                i.issues.push({ expected: "string", code: "invalid_type", input: i.value, inst: e }),
              i
            );
          }));
      }),
      tD = n("$ZodStringFormat", (e, t) => {
        (tb.init(e, t), tT.init(e, t));
      }),
      tA = n("$ZodGUID", (e, t) => {
        (t.pattern ?? (t.pattern = ez), tD.init(e, t));
      }),
      tC = n("$ZodUUID", (e, t) => {
        if (t.version) {
          let e = { v1: 1, v2: 2, v3: 3, v4: 4, v5: 5, v6: 6, v7: 7, v8: 8 }[t.version];
          if (void 0 === e) throw Error(`Invalid UUID version: "${t.version}"`);
          t.pattern ?? (t.pattern = eO(e));
        } else t.pattern ?? (t.pattern = eO());
        tD.init(e, t);
      }),
      tL = n("$ZodEmail", (e, t) => {
        (t.pattern ?? (t.pattern = eT), tD.init(e, t));
      }),
      tR = n("$ZodURL", (e, t) => {
        (tD.init(e, t),
          (e._zod.check = (i) => {
            try {
              let r = i.value.trim(),
                n = new URL(r);
              (t.hostname &&
                ((t.hostname.lastIndex = 0),
                t.hostname.test(n.hostname) ||
                  i.issues.push({
                    code: "invalid_format",
                    format: "url",
                    note: "Invalid hostname",
                    pattern: eJ.source,
                    input: i.value,
                    inst: e,
                    continue: !t.abort,
                  })),
                t.protocol &&
                  ((t.protocol.lastIndex = 0),
                  t.protocol.test(n.protocol.endsWith(":") ? n.protocol.slice(0, -1) : n.protocol) ||
                    i.issues.push({
                      code: "invalid_format",
                      format: "url",
                      note: "Invalid protocol",
                      pattern: t.protocol.source,
                      input: i.value,
                      inst: e,
                      continue: !t.abort,
                    })),
                t.normalize ? (i.value = n.href) : (i.value = r));
              return;
            } catch (r) {
              i.issues.push({
                code: "invalid_format",
                format: "url",
                input: i.value,
                inst: e,
                continue: !t.abort,
              });
            }
          }));
      }),
      tB = n("$ZodEmoji", (e, t) => {
        (t.pattern ?? (t.pattern = eA()), tD.init(e, t));
      }),
      tX = n("$ZodNanoID", (e, t) => {
        (t.pattern ?? (t.pattern = eE), tD.init(e, t));
      }),
      tF = n("$ZodCUID", (e, t) => {
        (t.pattern ?? (t.pattern = ex), tD.init(e, t));
      }),
      tJ = n("$ZodCUID2", (e, t) => {
        (t.pattern ?? (t.pattern = ek), tD.init(e, t));
      }),
      tG = n("$ZodULID", (e, t) => {
        (t.pattern ?? (t.pattern = eS), tD.init(e, t));
      }),
      tM = n("$ZodXID", (e, t) => {
        (t.pattern ?? (t.pattern = ew), tD.init(e, t));
      }),
      tK = n("$ZodKSUID", (e, t) => {
        (t.pattern ?? (t.pattern = eU), tD.init(e, t));
      }),
      tV = n("$ZodISODateTime", (e, t) => {
        (t.pattern ?? (t.pattern = eq(t)), tD.init(e, t));
      }),
      tW = n("$ZodISODate", (e, t) => {
        (t.pattern ?? (t.pattern = eK), tD.init(e, t));
      }),
      tq = n("$ZodISOTime", (e, t) => {
        (t.pattern ?? (t.pattern = eW(t)), tD.init(e, t));
      }),
      tY = n("$ZodISODuration", (e, t) => {
        (t.pattern ?? (t.pattern = eN), tD.init(e, t));
      }),
      tH = n("$ZodIPv4", (e, t) => {
        (t.pattern ?? (t.pattern = eC),
          tD.init(e, t),
          e._zod.onattach.push((e) => {
            e._zod.bag.format = "ipv4";
          }));
      }),
      tQ = n("$ZodIPv6", (e, t) => {
        (t.pattern ?? (t.pattern = eL),
          tD.init(e, t),
          e._zod.onattach.push((e) => {
            e._zod.bag.format = "ipv6";
          }),
          (e._zod.check = (i) => {
            try {
              new URL(`http://[${i.value}]`);
            } catch {
              i.issues.push({
                code: "invalid_format",
                format: "ipv6",
                input: i.value,
                inst: e,
                continue: !t.abort,
              });
            }
          }));
      }),
      t0 = n("$ZodCIDRv4", (e, t) => {
        (t.pattern ?? (t.pattern = eR), tD.init(e, t));
      }),
      t4 = n("$ZodCIDRv6", (e, t) => {
        (t.pattern ?? (t.pattern = eB),
          tD.init(e, t),
          (e._zod.check = (i) => {
            let r = i.value.split("/");
            try {
              if (2 !== r.length) throw Error();
              let [e, t] = r;
              if (!t) throw Error();
              let i = Number(t);
              if (`${i}` !== t || i < 0 || i > 128) throw Error();
              new URL(`http://[${e}]`);
            } catch {
              i.issues.push({
                code: "invalid_format",
                format: "cidrv6",
                input: i.value,
                inst: e,
                continue: !t.abort,
              });
            }
          }));
      });
    function t6(e) {
      if ("" === e) return !0;
      if (e.length % 4 != 0) return !1;
      try {
        return (atob(e), !0);
      } catch {
        return !1;
      }
    }
    let t1 = n("$ZodBase64", (e, t) => {
      (t.pattern ?? (t.pattern = eX),
        tD.init(e, t),
        e._zod.onattach.push((e) => {
          e._zod.bag.contentEncoding = "base64";
        }),
        (e._zod.check = (i) => {
          t6(i.value) ||
            i.issues.push({
              code: "invalid_format",
              format: "base64",
              input: i.value,
              inst: e,
              continue: !t.abort,
            });
        }));
    });
    function t2(e) {
      if (!eF.test(e)) return !1;
      let t = e.replace(/[-_]/g, (e) => ("-" === e ? "+" : "/"));
      return t6(t.padEnd(4 * Math.ceil(t.length / 4), "="));
    }
    let t9 = n("$ZodBase64URL", (e, t) => {
        (t.pattern ?? (t.pattern = eF),
          tD.init(e, t),
          e._zod.onattach.push((e) => {
            e._zod.bag.contentEncoding = "base64url";
          }),
          (e._zod.check = (i) => {
            t2(i.value) ||
              i.issues.push({
                code: "invalid_format",
                format: "base64url",
                input: i.value,
                inst: e,
                continue: !t.abort,
              });
          }));
      }),
      t3 = n("$ZodE164", (e, t) => {
        (t.pattern ?? (t.pattern = eG), tD.init(e, t));
      });
    function t5(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
      try {
        let i = e.split(".");
        if (3 !== i.length) return !1;
        let [r] = i;
        if (!r) return !1;
        let n = JSON.parse(atob(r));
        if (("typ" in n && n?.typ !== "JWT") || !n.alg || (t && (!("alg" in n) || n.alg !== t))) return !1;
        return !0;
      } catch {
        return !1;
      }
    }
    let t7 = n("$ZodJWT", (e, t) => {
        (tD.init(e, t),
          (e._zod.check = (i) => {
            t5(i.value, t.alg) ||
              i.issues.push({
                code: "invalid_format",
                format: "jwt",
                input: i.value,
                inst: e,
                continue: !t.abort,
              });
          }));
      }),
      t8 = n("$ZodCustomStringFormat", (e, t) => {
        (tD.init(e, t),
          (e._zod.check = (i) => {
            t.fn(i.value) ||
              i.issues.push({
                code: "invalid_format",
                format: t.format,
                input: i.value,
                inst: e,
                continue: !t.abort,
              });
          }));
      }),
      ie = n("$ZodNumber", (e, t) => {
        (tj.init(e, t),
          (e._zod.pattern = e._zod.bag.pattern ?? e0),
          (e._zod.parse = (i, r) => {
            if (t.coerce)
              try {
                i.value = Number(i.value);
              } catch (e) {}
            let n = i.value;
            if ("number" == typeof n && !Number.isNaN(n) && Number.isFinite(n)) return i;
            let a =
              "number" == typeof n
                ? Number.isNaN(n)
                  ? "NaN"
                  : Number.isFinite(n)
                    ? void 0
                    : "Infinity"
                : void 0;
            return (
              i.issues.push({
                expected: "number",
                code: "invalid_type",
                input: n,
                inst: e,
                ...(a ? { received: a } : {}),
              }),
              i
            );
          }));
      }),
      it = n("$ZodNumber", (e, t) => {
        (tf.init(e, t), ie.init(e, t));
      }),
      ii = n("$ZodBoolean", (e, t) => {
        (tj.init(e, t),
          (e._zod.pattern = e4),
          (e._zod.parse = (i, r) => {
            if (t.coerce)
              try {
                i.value = !!i.value;
              } catch (e) {}
            let n = i.value;
            return (
              "boolean" == typeof n ||
                i.issues.push({ expected: "boolean", code: "invalid_type", input: n, inst: e }),
              i
            );
          }));
      }),
      ir = n("$ZodBigInt", (e, t) => {
        (tj.init(e, t),
          (e._zod.pattern = eH),
          (e._zod.parse = (i, r) => {
            if (t.coerce)
              try {
                i.value = BigInt(i.value);
              } catch (e) {}
            return (
              "bigint" == typeof i.value ||
                i.issues.push({ expected: "bigint", code: "invalid_type", input: i.value, inst: e }),
              i
            );
          }));
      }),
      ia = n("$ZodBigInt", (e, t) => {
        (tp.init(e, t), ir.init(e, t));
      }),
      io = n("$ZodSymbol", (e, t) => {
        (tj.init(e, t),
          (e._zod.parse = (t, i) => {
            let r = t.value;
            return (
              "symbol" == typeof r ||
                t.issues.push({ expected: "symbol", code: "invalid_type", input: r, inst: e }),
              t
            );
          }));
      }),
      iu = n("$ZodUndefined", (e, t) => {
        (tj.init(e, t),
          (e._zod.pattern = e1),
          (e._zod.values = new Set([void 0])),
          (e._zod.optin = "optional"),
          (e._zod.optout = "optional"),
          (e._zod.parse = (t, i) => {
            let r = t.value;
            return (
              void 0 === r ||
                t.issues.push({ expected: "undefined", code: "invalid_type", input: r, inst: e }),
              t
            );
          }));
      }),
      is = n("$ZodNull", (e, t) => {
        (tj.init(e, t),
          (e._zod.pattern = e6),
          (e._zod.values = new Set([null])),
          (e._zod.parse = (t, i) => {
            let r = t.value;
            return (
              null === r || t.issues.push({ expected: "null", code: "invalid_type", input: r, inst: e }),
              t
            );
          }));
      }),
      il = n("$ZodAny", (e, t) => {
        (tj.init(e, t), (e._zod.parse = (e) => e));
      }),
      id = n("$ZodUnknown", (e, t) => {
        (tj.init(e, t), (e._zod.parse = (e) => e));
      }),
      ic = n("$ZodNever", (e, t) => {
        (tj.init(e, t),
          (e._zod.parse = (t, i) => (
            t.issues.push({ expected: "never", code: "invalid_type", input: t.value, inst: e }),
            t
          )));
      }),
      im = n("$ZodVoid", (e, t) => {
        (tj.init(e, t),
          (e._zod.parse = (t, i) => {
            let r = t.value;
            return (
              void 0 === r || t.issues.push({ expected: "void", code: "invalid_type", input: r, inst: e }),
              t
            );
          }));
      }),
      ip = n("$ZodDate", (e, t) => {
        (tj.init(e, t),
          (e._zod.parse = (i, r) => {
            if (t.coerce)
              try {
                i.value = new Date(i.value);
              } catch (e) {}
            let n = i.value,
              a = n instanceof Date;
            return (
              (a && !Number.isNaN(n.getTime())) ||
                i.issues.push({
                  expected: "date",
                  code: "invalid_type",
                  input: n,
                  ...(a ? { received: "Invalid Date" } : {}),
                  inst: e,
                }),
              i
            );
          }));
      });
    function iv(e, t, i) {
      (e.issues.length && t.issues.push(...A(i, e.issues)), (t.value[i] = e.value));
    }
    let ig = n("$ZodArray", (e, t) => {
      (tj.init(e, t),
        (e._zod.parse = (i, r) => {
          let n = i.value;
          if (!Array.isArray(n))
            return (i.issues.push({ expected: "array", code: "invalid_type", input: n, inst: e }), i);
          i.value = Array(n.length);
          let a = [];
          for (let e = 0; e < n.length; e++) {
            let o = n[e],
              u = t.element._zod.run({ value: o, issues: [] }, r);
            u instanceof Promise ? a.push(u.then((t) => iv(t, i, e))) : iv(u, i, e);
          }
          return a.length ? Promise.all(a).then(() => i) : i;
        }));
    });
    function i_(e, t, i, r) {
      (e.issues.length && t.issues.push(...A(i, e.issues)),
        void 0 === e.value ? i in r && (t.value[i] = void 0) : (t.value[i] = e.value));
    }
    function ih(e) {
      let t = Object.keys(e.shape);
      for (let i of t)
        if (!e.shape?.[i]?._zod?.traits?.has("$ZodType"))
          throw Error(`Invalid element at key "${i}": expected a Zod schema`);
      let i = Z(e.shape);
      return { ...e, keys: t, keySet: new Set(t), numKeys: t.length, optionalKeys: new Set(i) };
    }
    function i$(e, t, i, r, n, a) {
      let o = [],
        u = n.keySet,
        s = n.catchall._zod,
        l = s.def.type;
      for (let n of Object.keys(t)) {
        if (u.has(n)) continue;
        if ("never" === l) {
          o.push(n);
          continue;
        }
        let a = s.run({ value: t[n], issues: [] }, r);
        a instanceof Promise ? e.push(a.then((e) => i_(e, i, n, t))) : i_(a, i, n, t);
      }
      return (o.length && i.issues.push({ code: "unrecognized_keys", keys: o, input: t, inst: a }), e.length)
        ? Promise.all(e).then(() => i)
        : i;
    }
    let iy = n("$ZodObject", (e, t) => {
        let i;
        tj.init(e, t);
        let r = Object.getOwnPropertyDescriptor(t, "shape");
        if (!r?.get) {
          let e = t.shape;
          Object.defineProperty(t, "shape", {
            get: () => {
              let i = { ...e };
              return (Object.defineProperty(t, "shape", { value: i }), i);
            },
          });
        }
        let n = f(() => ih(t));
        h(e._zod, "propValues", () => {
          let e = t.shape,
            i = {};
          for (let t in e) {
            let r = e[t]._zod;
            if (r.values) for (let e of (i[t] ?? (i[t] = new Set()), r.values)) i[t].add(e);
          }
          return i;
        });
        let a = t.catchall;
        e._zod.parse = (t, r) => {
          i ?? (i = n.value);
          let o = t.value;
          if (!x(o))
            return (t.issues.push({ expected: "object", code: "invalid_type", input: o, inst: e }), t);
          t.value = {};
          let u = [],
            s = i.shape;
          for (let e of i.keys) {
            let i = s[e]._zod.run({ value: o[e], issues: [] }, r);
            i instanceof Promise ? u.push(i.then((i) => i_(i, t, e, o))) : i_(i, t, e, o);
          }
          return a ? i$(u, o, t, r, n.value, e) : u.length ? Promise.all(u).then(() => t) : t;
        };
      }),
      ib = n("$ZodObjectJIT", (e, t) => {
        let i, r;
        iy.init(e, t);
        let n = e._zod.parse,
          a = f(() => ih(t)),
          o = !s.jitless,
          u = o && k.value,
          l = t.catchall;
        e._zod.parse = (s, d) => {
          r ?? (r = a.value);
          let c = s.value;
          return x(c)
            ? o && u && d?.async === !1 && !0 !== d.jitless
              ? (i ||
                  (i = ((e) => {
                    let t = new tP(["shape", "payload", "ctx"]),
                      i = a.value,
                      r = (e) => {
                        let t = b(e);
                        return `shape[${t}]._zod.run({ value: input[${t}], issues: [] }, ctx)`;
                      };
                    t.write("const input = payload.value;");
                    let n = Object.create(null),
                      o = 0;
                    for (let e of i.keys) n[e] = `key_${o++}`;
                    for (let e of (t.write("const newResult = {};"), i.keys)) {
                      let i = n[e],
                        a = b(e);
                      (t.write(`const ${i} = ${r(e)};`),
                        t.write(`
        if (${i}.issues.length) {
          payload.issues = payload.issues.concat(${i}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${a}, ...iss.path] : [${a}]
          })));
        }
        
        
        if (${i}.value === undefined) {
          if (${a} in input) {
            newResult[${a}] = undefined;
          }
        } else {
          newResult[${a}] = ${i}.value;
        }
        
      `));
                    }
                    (t.write("payload.value = newResult;"), t.write("return payload;"));
                    let u = t.compile();
                    return (t, i) => u(e, t, i);
                  })(t.shape)),
                (s = i(s, d)),
                l)
                ? i$([], c, s, d, r, e)
                : s
              : n(s, d)
            : (s.issues.push({ expected: "object", code: "invalid_type", input: c, inst: e }), s);
        };
      });
    function iI(e, t, i, r) {
      for (let i of e) if (0 === i.issues.length) return ((t.value = i.value), t);
      let n = e.filter((e) => !D(e));
      return 1 === n.length
        ? ((t.value = n[0].value), n[0])
        : (t.issues.push({
            code: "invalid_union",
            input: t.value,
            inst: i,
            errors: e.map((e) => e.issues.map((e) => L(e, r, l()))),
          }),
          t);
    }
    let ix = n("$ZodUnion", (e, t) => {
        (tj.init(e, t),
          h(e._zod, "optin", () =>
            t.options.some((e) => "optional" === e._zod.optin) ? "optional" : void 0,
          ),
          h(e._zod, "optout", () =>
            t.options.some((e) => "optional" === e._zod.optout) ? "optional" : void 0,
          ),
          h(e._zod, "values", () => {
            if (t.options.every((e) => e._zod.values))
              return new Set(t.options.flatMap((e) => Array.from(e._zod.values)));
          }),
          h(e._zod, "pattern", () => {
            if (t.options.every((e) => e._zod.pattern)) {
              let e = t.options.map((e) => e._zod.pattern);
              return RegExp(`^(${e.map((e) => v(e.source)).join("|")})$`);
            }
          }));
        let i = 1 === t.options.length,
          r = t.options[0]._zod.run;
        e._zod.parse = (n, a) => {
          if (i) return r(n, a);
          let o = !1,
            u = [];
          for (let e of t.options) {
            let t = e._zod.run({ value: n.value, issues: [] }, a);
            if (t instanceof Promise) (u.push(t), (o = !0));
            else {
              if (0 === t.issues.length) return t;
              u.push(t);
            }
          }
          return o ? Promise.all(u).then((t) => iI(t, n, e, a)) : iI(u, n, e, a);
        };
      }),
      ik = n("$ZodDiscriminatedUnion", (e, t) => {
        ix.init(e, t);
        let i = e._zod.parse;
        h(e._zod, "propValues", () => {
          let e = {};
          for (let i of t.options) {
            let r = i._zod.propValues;
            if (!r || 0 === Object.keys(r).length)
              throw Error(`Invalid discriminated union option at index "${t.options.indexOf(i)}"`);
            for (let [t, i] of Object.entries(r)) for (let r of (e[t] || (e[t] = new Set()), i)) e[t].add(r);
          }
          return e;
        });
        let r = f(() => {
          let e = t.options,
            i = new Map();
          for (let r of e) {
            let e = r._zod.propValues?.[t.discriminator];
            if (!e || 0 === e.size)
              throw Error(`Invalid discriminated union option at index "${t.options.indexOf(r)}"`);
            for (let t of e) {
              if (i.has(t)) throw Error(`Duplicate discriminator value "${String(t)}"`);
              i.set(t, r);
            }
          }
          return i;
        });
        e._zod.parse = (n, a) => {
          let o = n.value;
          if (!x(o))
            return (n.issues.push({ code: "invalid_type", expected: "object", input: o, inst: e }), n);
          let u = r.value.get(o?.[t.discriminator]);
          return u
            ? u._zod.run(n, a)
            : t.unionFallback
              ? i(n, a)
              : (n.issues.push({
                  code: "invalid_union",
                  errors: [],
                  note: "No matching discriminator",
                  discriminator: t.discriminator,
                  input: o,
                  path: [t.discriminator],
                  inst: e,
                }),
                n);
        };
      }),
      iS = n("$ZodIntersection", (e, t) => {
        (tj.init(e, t),
          (e._zod.parse = (e, i) => {
            let r = e.value,
              n = t.left._zod.run({ value: r, issues: [] }, i),
              a = t.right._zod.run({ value: r, issues: [] }, i);
            return n instanceof Promise || a instanceof Promise
              ? Promise.all([n, a]).then((t) => {
                  let [i, r] = t;
                  return iw(e, i, r);
                })
              : iw(e, n, a);
          }));
      });
    function iw(e, t, i) {
      if (
        (t.issues.length && e.issues.push(...t.issues), i.issues.length && e.issues.push(...i.issues), D(e))
      )
        return e;
      let r = (function e(t, i) {
        if (t === i || (t instanceof Date && i instanceof Date && +t == +i)) return { valid: !0, data: t };
        if (S(t) && S(i)) {
          let r = Object.keys(i),
            n = Object.keys(t).filter((e) => -1 !== r.indexOf(e)),
            a = { ...t, ...i };
          for (let r of n) {
            let n = e(t[r], i[r]);
            if (!n.valid) return { valid: !1, mergeErrorPath: [r, ...n.mergeErrorPath] };
            a[r] = n.data;
          }
          return { valid: !0, data: a };
        }
        if (Array.isArray(t) && Array.isArray(i)) {
          if (t.length !== i.length) return { valid: !1, mergeErrorPath: [] };
          let r = [];
          for (let n = 0; n < t.length; n++) {
            let a = e(t[n], i[n]);
            if (!a.valid) return { valid: !1, mergeErrorPath: [n, ...a.mergeErrorPath] };
            r.push(a.data);
          }
          return { valid: !0, data: r };
        }
        return { valid: !1, mergeErrorPath: [] };
      })(t.value, i.value);
      if (!r.valid) throw Error(`Unmergable intersection. Error path: ${JSON.stringify(r.mergeErrorPath)}`);
      return ((e.value = r.data), e);
    }
    let iU = n("$ZodTuple", (e, t) => {
      tj.init(e, t);
      let i = t.items,
        r = i.length - [...i].reverse().findIndex((e) => "optional" !== e._zod.optin);
      e._zod.parse = (n, a) => {
        let o = n.value;
        if (!Array.isArray(o))
          return (n.issues.push({ input: o, inst: e, expected: "tuple", code: "invalid_type" }), n);
        n.value = [];
        let u = [];
        if (!t.rest) {
          let t = o.length > i.length,
            a = o.length < r - 1;
          if (t || a)
            return (
              n.issues.push({
                ...(t ? { code: "too_big", maximum: i.length } : { code: "too_small", minimum: i.length }),
                input: o,
                inst: e,
                origin: "array",
              }),
              n
            );
        }
        let s = -1;
        for (let e of i) {
          if (++s >= o.length && s >= r) continue;
          let t = e._zod.run({ value: o[s], issues: [] }, a);
          t instanceof Promise ? u.push(t.then((e) => iE(e, n, s))) : iE(t, n, s);
        }
        if (t.rest)
          for (let e of o.slice(i.length)) {
            s++;
            let i = t.rest._zod.run({ value: e, issues: [] }, a);
            i instanceof Promise ? u.push(i.then((e) => iE(e, n, s))) : iE(i, n, s);
          }
        return u.length ? Promise.all(u).then(() => n) : n;
      };
    });
    function iE(e, t, i) {
      (e.issues.length && t.issues.push(...A(i, e.issues)), (t.value[i] = e.value));
    }
    let iN = n("$ZodRecord", (e, t) => {
        (tj.init(e, t),
          (e._zod.parse = (i, r) => {
            let n = i.value;
            if (!S(n))
              return (i.issues.push({ expected: "record", code: "invalid_type", input: n, inst: e }), i);
            let a = [];
            if (t.keyType._zod.values) {
              let o,
                u = t.keyType._zod.values;
              for (let e of ((i.value = {}), u))
                if ("string" == typeof e || "number" == typeof e || "symbol" == typeof e) {
                  let o = t.valueType._zod.run({ value: n[e], issues: [] }, r);
                  o instanceof Promise
                    ? a.push(
                        o.then((t) => {
                          (t.issues.length && i.issues.push(...A(e, t.issues)), (i.value[e] = t.value));
                        }),
                      )
                    : (o.issues.length && i.issues.push(...A(e, o.issues)), (i.value[e] = o.value));
                }
              for (let e in n) u.has(e) || (o = o ?? []).push(e);
              o && o.length > 0 && i.issues.push({ code: "unrecognized_keys", input: n, inst: e, keys: o });
            } else
              for (let o of ((i.value = {}), Reflect.ownKeys(n))) {
                if ("__proto__" === o) continue;
                let u = t.keyType._zod.run({ value: o, issues: [] }, r);
                if (u instanceof Promise) throw Error("Async schemas not supported in object keys currently");
                if (u.issues.length) {
                  (i.issues.push({
                    code: "invalid_key",
                    origin: "record",
                    issues: u.issues.map((e) => L(e, r, l())),
                    input: o,
                    path: [o],
                    inst: e,
                  }),
                    (i.value[u.value] = u.value));
                  continue;
                }
                let s = t.valueType._zod.run({ value: n[o], issues: [] }, r);
                s instanceof Promise
                  ? a.push(
                      s.then((e) => {
                        (e.issues.length && i.issues.push(...A(o, e.issues)), (i.value[u.value] = e.value));
                      }),
                    )
                  : (s.issues.length && i.issues.push(...A(o, s.issues)), (i.value[u.value] = s.value));
              }
            return a.length ? Promise.all(a).then(() => i) : i;
          }));
      }),
      iz = n("$ZodMap", (e, t) => {
        (tj.init(e, t),
          (e._zod.parse = (i, r) => {
            let n = i.value;
            if (!(n instanceof Map))
              return (i.issues.push({ expected: "map", code: "invalid_type", input: n, inst: e }), i);
            let a = [];
            for (let [o, u] of ((i.value = new Map()), n)) {
              let s = t.keyType._zod.run({ value: o, issues: [] }, r),
                l = t.valueType._zod.run({ value: u, issues: [] }, r);
              s instanceof Promise || l instanceof Promise
                ? a.push(
                    Promise.all([s, l]).then((t) => {
                      let [a, u] = t;
                      iO(a, u, i, o, n, e, r);
                    }),
                  )
                : iO(s, l, i, o, n, e, r);
            }
            return a.length ? Promise.all(a).then(() => i) : i;
          }));
      });
    function iO(e, t, i, r, n, a, o) {
      (e.issues.length &&
        (U.has(typeof r)
          ? i.issues.push(...A(r, e.issues))
          : i.issues.push({
              code: "invalid_key",
              origin: "map",
              input: n,
              inst: a,
              issues: e.issues.map((e) => L(e, o, l())),
            })),
        t.issues.length &&
          (U.has(typeof r)
            ? i.issues.push(...A(r, t.issues))
            : i.issues.push({
                origin: "map",
                code: "invalid_element",
                input: n,
                inst: a,
                key: r,
                issues: t.issues.map((e) => L(e, o, l())),
              })),
        i.value.set(e.value, t.value));
    }
    let iP = n("$ZodSet", (e, t) => {
      (tj.init(e, t),
        (e._zod.parse = (i, r) => {
          let n = i.value;
          if (!(n instanceof Set))
            return (i.issues.push({ input: n, inst: e, expected: "set", code: "invalid_type" }), i);
          let a = [];
          for (let e of ((i.value = new Set()), n)) {
            let n = t.valueType._zod.run({ value: e, issues: [] }, r);
            n instanceof Promise ? a.push(n.then((e) => iZ(e, i))) : iZ(n, i);
          }
          return a.length ? Promise.all(a).then(() => i) : i;
        }));
    });
    function iZ(e, t) {
      (e.issues.length && t.issues.push(...e.issues), t.value.add(e.value));
    }
    let ij = n("$ZodEnum", (e, t) => {
        tj.init(e, t);
        let i = d(t.entries),
          r = new Set(i);
        ((e._zod.values = r),
          (e._zod.pattern = RegExp(
            `^(${i
              .filter((e) => U.has(typeof e))
              .map((e) => ("string" == typeof e ? N(e) : e.toString()))
              .join("|")})$`,
          )),
          (e._zod.parse = (t, n) => {
            let a = t.value;
            return (r.has(a) || t.issues.push({ code: "invalid_value", values: i, input: a, inst: e }), t);
          }));
      }),
      iT = n("$ZodLiteral", (e, t) => {
        if ((tj.init(e, t), 0 === t.values.length))
          throw Error("Cannot create literal schema with no valid values");
        ((e._zod.values = new Set(t.values)),
          (e._zod.pattern = RegExp(
            `^(${t.values.map((e) => ("string" == typeof e ? N(e) : e ? N(e.toString()) : String(e))).join("|")})$`,
          )),
          (e._zod.parse = (i, r) => {
            let n = i.value;
            return (
              e._zod.values.has(n) ||
                i.issues.push({ code: "invalid_value", values: t.values, input: n, inst: e }),
              i
            );
          }));
      }),
      iD = n("$ZodFile", (e, t) => {
        (tj.init(e, t),
          (e._zod.parse = (t, i) => {
            let r = t.value;
            return (
              r instanceof File ||
                t.issues.push({ expected: "file", code: "invalid_type", input: r, inst: e }),
              t
            );
          }));
      }),
      iA = n("$ZodTransform", (e, t) => {
        (tj.init(e, t),
          (e._zod.parse = (i, r) => {
            if ("backward" === r.direction) throw new u(e.constructor.name);
            let n = t.transform(i.value, i);
            if (r.async)
              return (n instanceof Promise ? n : Promise.resolve(n)).then((e) => ((i.value = e), i));
            if (n instanceof Promise) throw new o();
            return ((i.value = n), i);
          }));
      });
    function iC(e, t) {
      return e.issues.length && void 0 === t ? { issues: [], value: void 0 } : e;
    }
    let iL = n("$ZodOptional", (e, t) => {
        (tj.init(e, t),
          (e._zod.optin = "optional"),
          (e._zod.optout = "optional"),
          h(e._zod, "values", () =>
            t.innerType._zod.values ? new Set([...t.innerType._zod.values, void 0]) : void 0,
          ),
          h(e._zod, "pattern", () => {
            let e = t.innerType._zod.pattern;
            return e ? RegExp(`^(${v(e.source)})?$`) : void 0;
          }),
          (e._zod.parse = (e, i) => {
            if ("optional" === t.innerType._zod.optin) {
              let r = t.innerType._zod.run(e, i);
              return r instanceof Promise ? r.then((t) => iC(t, e.value)) : iC(r, e.value);
            }
            return void 0 === e.value ? e : t.innerType._zod.run(e, i);
          }));
      }),
      iR = n("$ZodNullable", (e, t) => {
        (tj.init(e, t),
          h(e._zod, "optin", () => t.innerType._zod.optin),
          h(e._zod, "optout", () => t.innerType._zod.optout),
          h(e._zod, "pattern", () => {
            let e = t.innerType._zod.pattern;
            return e ? RegExp(`^(${v(e.source)}|null)$`) : void 0;
          }),
          h(e._zod, "values", () =>
            t.innerType._zod.values ? new Set([...t.innerType._zod.values, null]) : void 0,
          ),
          (e._zod.parse = (e, i) => (null === e.value ? e : t.innerType._zod.run(e, i))));
      }),
      iB = n("$ZodDefault", (e, t) => {
        (tj.init(e, t),
          (e._zod.optin = "optional"),
          h(e._zod, "values", () => t.innerType._zod.values),
          (e._zod.parse = (e, i) => {
            if ("backward" === i.direction) return t.innerType._zod.run(e, i);
            if (void 0 === e.value) return ((e.value = t.defaultValue), e);
            let r = t.innerType._zod.run(e, i);
            return r instanceof Promise ? r.then((e) => iX(e, t)) : iX(r, t);
          }));
      });
    function iX(e, t) {
      return (void 0 === e.value && (e.value = t.defaultValue), e);
    }
    let iF = n("$ZodPrefault", (e, t) => {
        (tj.init(e, t),
          (e._zod.optin = "optional"),
          h(e._zod, "values", () => t.innerType._zod.values),
          (e._zod.parse = (e, i) => (
            "backward" === i.direction || (void 0 === e.value && (e.value = t.defaultValue)),
            t.innerType._zod.run(e, i)
          )));
      }),
      iJ = n("$ZodNonOptional", (e, t) => {
        (tj.init(e, t),
          h(e._zod, "values", () => {
            let e = t.innerType._zod.values;
            return e ? new Set([...e].filter((e) => void 0 !== e)) : void 0;
          }),
          (e._zod.parse = (i, r) => {
            let n = t.innerType._zod.run(i, r);
            return n instanceof Promise ? n.then((t) => iG(t, e)) : iG(n, e);
          }));
      });
    function iG(e, t) {
      return (
        e.issues.length ||
          void 0 !== e.value ||
          e.issues.push({ code: "invalid_type", expected: "nonoptional", input: e.value, inst: t }),
        e
      );
    }
    let iM = n("$ZodSuccess", (e, t) => {
        (tj.init(e, t),
          (e._zod.parse = (e, i) => {
            if ("backward" === i.direction) throw new u("ZodSuccess");
            let r = t.innerType._zod.run(e, i);
            return r instanceof Promise
              ? r.then((t) => ((e.value = 0 === t.issues.length), e))
              : ((e.value = 0 === r.issues.length), e);
          }));
      }),
      iK = n("$ZodCatch", (e, t) => {
        (tj.init(e, t),
          h(e._zod, "optin", () => t.innerType._zod.optin),
          h(e._zod, "optout", () => t.innerType._zod.optout),
          h(e._zod, "values", () => t.innerType._zod.values),
          (e._zod.parse = (e, i) => {
            if ("backward" === i.direction) return t.innerType._zod.run(e, i);
            let r = t.innerType._zod.run(e, i);
            return r instanceof Promise
              ? r.then(
                  (r) => (
                    (e.value = r.value),
                    r.issues.length &&
                      ((e.value = t.catchValue({
                        ...e,
                        error: { issues: r.issues.map((e) => L(e, i, l())) },
                        input: e.value,
                      })),
                      (e.issues = [])),
                    e
                  ),
                )
              : ((e.value = r.value),
                r.issues.length &&
                  ((e.value = t.catchValue({
                    ...e,
                    error: { issues: r.issues.map((e) => L(e, i, l())) },
                    input: e.value,
                  })),
                  (e.issues = [])),
                e);
          }));
      }),
      iV = n("$ZodNaN", (e, t) => {
        (tj.init(e, t),
          (e._zod.parse = (t, i) => (
            ("number" == typeof t.value && Number.isNaN(t.value)) ||
              t.issues.push({ input: t.value, inst: e, expected: "nan", code: "invalid_type" }),
            t
          )));
      }),
      iW = n("$ZodPipe", (e, t) => {
        (tj.init(e, t),
          h(e._zod, "values", () => t.in._zod.values),
          h(e._zod, "optin", () => t.in._zod.optin),
          h(e._zod, "optout", () => t.out._zod.optout),
          h(e._zod, "propValues", () => t.in._zod.propValues),
          (e._zod.parse = (e, i) => {
            if ("backward" === i.direction) {
              let r = t.out._zod.run(e, i);
              return r instanceof Promise ? r.then((e) => iq(e, t.in, i)) : iq(r, t.in, i);
            }
            let r = t.in._zod.run(e, i);
            return r instanceof Promise ? r.then((e) => iq(e, t.out, i)) : iq(r, t.out, i);
          }));
      });
    function iq(e, t, i) {
      return e.issues.length ? ((e.aborted = !0), e) : t._zod.run({ value: e.value, issues: e.issues }, i);
    }
    let iY = n("$ZodCodec", (e, t) => {
      (tj.init(e, t),
        h(e._zod, "values", () => t.in._zod.values),
        h(e._zod, "optin", () => t.in._zod.optin),
        h(e._zod, "optout", () => t.out._zod.optout),
        h(e._zod, "propValues", () => t.in._zod.propValues),
        (e._zod.parse = (e, i) => {
          if ("forward" === (i.direction || "forward")) {
            let r = t.in._zod.run(e, i);
            return r instanceof Promise ? r.then((e) => iH(e, t, i)) : iH(r, t, i);
          }
          {
            let r = t.out._zod.run(e, i);
            return r instanceof Promise ? r.then((e) => iH(e, t, i)) : iH(r, t, i);
          }
        }));
    });
    function iH(e, t, i) {
      if (e.issues.length) return ((e.aborted = !0), e);
      if ("forward" === (i.direction || "forward")) {
        let r = t.transform(e.value, e);
        return r instanceof Promise ? r.then((r) => iQ(e, r, t.out, i)) : iQ(e, r, t.out, i);
      }
      {
        let r = t.reverseTransform(e.value, e);
        return r instanceof Promise ? r.then((r) => iQ(e, r, t.in, i)) : iQ(e, r, t.in, i);
      }
    }
    function iQ(e, t, i, r) {
      return e.issues.length ? ((e.aborted = !0), e) : i._zod.run({ value: t, issues: e.issues }, r);
    }
    let i0 = n("$ZodReadonly", (e, t) => {
      (tj.init(e, t),
        h(e._zod, "propValues", () => t.innerType._zod.propValues),
        h(e._zod, "values", () => t.innerType._zod.values),
        h(e._zod, "optin", () => t.innerType._zod.optin),
        h(e._zod, "optout", () => t.innerType._zod.optout),
        (e._zod.parse = (e, i) => {
          if ("backward" === i.direction) return t.innerType._zod.run(e, i);
          let r = t.innerType._zod.run(e, i);
          return r instanceof Promise ? r.then(i4) : i4(r);
        }));
    });
    function i4(e) {
      return ((e.value = Object.freeze(e.value)), e);
    }
    let i6 = n("$ZodTemplateLiteral", (e, t) => {
        tj.init(e, t);
        let i = [];
        for (let e of t.parts)
          if ("object" == typeof e && null !== e) {
            if (!e._zod.pattern)
              throw Error(`Invalid template literal part, no pattern found: ${[...e._zod.traits].shift()}`);
            let t = e._zod.pattern instanceof RegExp ? e._zod.pattern.source : e._zod.pattern;
            if (!t) throw Error(`Invalid template literal part: ${e._zod.traits}`);
            let r = +!!t.startsWith("^"),
              n = t.endsWith("$") ? t.length - 1 : t.length;
            i.push(t.slice(r, n));
          } else if (null === e || E.has(typeof e)) i.push(N(`${e}`));
          else throw Error(`Invalid template literal part: ${e}`);
        ((e._zod.pattern = RegExp(`^${i.join("")}$`)),
          (e._zod.parse = (i, r) => (
            "string" != typeof i.value
              ? i.issues.push({ input: i.value, inst: e, expected: "template_literal", code: "invalid_type" })
              : ((e._zod.pattern.lastIndex = 0),
                e._zod.pattern.test(i.value) ||
                  i.issues.push({
                    input: i.value,
                    inst: e,
                    code: "invalid_format",
                    format: t.format ?? "template_literal",
                    pattern: e._zod.pattern.source,
                  })),
            i
          )));
      }),
      i1 = n(
        "$ZodFunction",
        (e, t) => (
          tj.init(e, t),
          (e._def = t),
          (e._zod.def = t),
          (e.implement = (t) => {
            if ("function" != typeof t) throw Error("implement() must be called with a function");
            return function () {
              for (var i = arguments.length, r = Array(i), n = 0; n < i; n++) r[n] = arguments[n];
              let a = Reflect.apply(t, this, e._def.input ? ee(e._def.input, r) : r);
              return e._def.output ? ee(e._def.output, a) : a;
            };
          }),
          (e.implementAsync = (t) => {
            if ("function" != typeof t) throw Error("implementAsync() must be called with a function");
            return async function () {
              for (var i = arguments.length, r = Array(i), n = 0; n < i; n++) r[n] = arguments[n];
              let a = e._def.input ? await ei(e._def.input, r) : r,
                o = await Reflect.apply(t, this, a);
              return e._def.output ? await ei(e._def.output, o) : o;
            };
          }),
          (e._zod.parse = (t, i) => (
            "function" != typeof t.value
              ? t.issues.push({ code: "invalid_type", expected: "function", input: t.value, inst: e })
              : e._def.output && "promise" === e._def.output._zod.def.type
                ? (t.value = e.implementAsync(t.value))
                : (t.value = e.implement(t.value)),
            t
          )),
          (e.input = function () {
            for (var t = arguments.length, i = Array(t), r = 0; r < t; r++) i[r] = arguments[r];
            let n = e.constructor;
            return new n(
              Array.isArray(i[0])
                ? {
                    type: "function",
                    input: new iU({ type: "tuple", items: i[0], rest: i[1] }),
                    output: e._def.output,
                  }
                : { type: "function", input: i[0], output: e._def.output },
            );
          }),
          (e.output = (t) => new e.constructor({ type: "function", input: e._def.input, output: t })),
          e
        ),
      ),
      i2 = n("$ZodPromise", (e, t) => {
        (tj.init(e, t),
          (e._zod.parse = (e, i) =>
            Promise.resolve(e.value).then((e) => t.innerType._zod.run({ value: e, issues: [] }, i))));
      }),
      i9 = n("$ZodLazy", (e, t) => {
        (tj.init(e, t),
          h(e._zod, "innerType", () => t.getter()),
          h(e._zod, "pattern", () => e._zod.innerType._zod.pattern),
          h(e._zod, "propValues", () => e._zod.innerType._zod.propValues),
          h(e._zod, "optin", () => e._zod.innerType._zod.optin ?? void 0),
          h(e._zod, "optout", () => e._zod.innerType._zod.optout ?? void 0),
          (e._zod.parse = (t, i) => e._zod.innerType._zod.run(t, i)));
      }),
      i3 = n("$ZodCustom", (e, t) => {
        (ts.init(e, t),
          tj.init(e, t),
          (e._zod.parse = (e, t) => e),
          (e._zod.check = (i) => {
            let r = i.value,
              n = t.fn(r);
            if (n instanceof Promise) return n.then((t) => i5(t, i, r, e));
            i5(n, i, r, e);
          }));
      });
    function i5(e, t, i, r) {
      if (!e) {
        let e = {
          code: "custom",
          input: i,
          inst: r,
          path: [...(r._zod.def.path ?? [])],
          continue: !r._zod.def.abort,
        };
        (r._zod.def.params && (e.params = r._zod.def.params), t.issues.push(X(e)));
      }
    }
    function i7(e, t, i, r) {
      let n = Math.abs(e),
        a = n % 10,
        o = n % 100;
      return o >= 11 && o <= 19 ? r : 1 === a ? t : a >= 2 && a <= 4 ? i : r;
    }
    function i8() {
      let e, t;
      return {
        localeError:
          ((e = {
            string: { unit: "characters", verb: "to have" },
            file: { unit: "bytes", verb: "to have" },
            array: { unit: "items", verb: "to have" },
            set: { unit: "items", verb: "to have" },
          }),
          (t = {
            regex: "input",
            email: "email address",
            url: "URL",
            emoji: "emoji",
            uuid: "UUID",
            uuidv4: "UUIDv4",
            uuidv6: "UUIDv6",
            nanoid: "nanoid",
            guid: "GUID",
            cuid: "cuid",
            cuid2: "cuid2",
            ulid: "ULID",
            xid: "XID",
            ksuid: "KSUID",
            datetime: "ISO datetime",
            date: "ISO date",
            time: "ISO time",
            duration: "ISO duration",
            ipv4: "IPv4 address",
            ipv6: "IPv6 address",
            cidrv4: "IPv4 range",
            cidrv6: "IPv6 range",
            base64: "base64-encoded string",
            base64url: "base64url-encoded string",
            json_string: "JSON string",
            e164: "E.164 number",
            jwt: "JWT",
            template_literal: "input",
          }),
          (i) => {
            switch (i.code) {
              case "invalid_type":
                return `Invalid input: expected ${i.expected}, received ${((e) => {
                  let t = typeof e;
                  switch (t) {
                    case "number":
                      return Number.isNaN(e) ? "NaN" : "number";
                    case "object":
                      if (Array.isArray(e)) return "array";
                      if (null === e) return "null";
                      if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                        return e.constructor.name;
                  }
                  return t;
                })(i.input)}`;
              case "invalid_value":
                if (1 === i.values.length) return `Invalid input: expected ${P(i.values[0])}`;
                return `Invalid option: expected one of ${c(i.values, "|")}`;
              case "too_big": {
                let t = i.inclusive ? "<=" : "<",
                  r = e[i.origin] ?? null;
                if (r)
                  return `Too big: expected ${i.origin ?? "value"} to have ${t}${i.maximum.toString()} ${r.unit ?? "elements"}`;
                return `Too big: expected ${i.origin ?? "value"} to be ${t}${i.maximum.toString()}`;
              }
              case "too_small": {
                let t = i.inclusive ? ">=" : ">",
                  r = e[i.origin] ?? null;
                if (r) return `Too small: expected ${i.origin} to have ${t}${i.minimum.toString()} ${r.unit}`;
                return `Too small: expected ${i.origin} to be ${t}${i.minimum.toString()}`;
              }
              case "invalid_format":
                if ("starts_with" === i.format) return `Invalid string: must start with "${i.prefix}"`;
                if ("ends_with" === i.format) return `Invalid string: must end with "${i.suffix}"`;
                if ("includes" === i.format) return `Invalid string: must include "${i.includes}"`;
                if ("regex" === i.format) return `Invalid string: must match pattern ${i.pattern}`;
                return `Invalid ${t[i.format] ?? i.format}`;
              case "not_multiple_of":
                return `Invalid number: must be a multiple of ${i.divisor}`;
              case "unrecognized_keys":
                return `Unrecognized key${i.keys.length > 1 ? "s" : ""}: ${c(i.keys, ", ")}`;
              case "invalid_key":
                return `Invalid key in ${i.origin}`;
              case "invalid_union":
              default:
                return "Invalid input";
              case "invalid_element":
                return `Invalid value in ${i.origin}`;
            }
          }),
      };
    }
    function re() {
      let e, t;
      return {
        localeError:
          ((e = {
            string: { unit: "តួអក្សរ", verb: "គួរមាន" },
            file: { unit: "បៃ", verb: "គួរមាន" },
            array: { unit: "ធាតុ", verb: "គួរមាន" },
            set: { unit: "ធាតុ", verb: "គួរមាន" },
          }),
          (t = {
            regex: "ទិន្នន័យបញ្ចូល",
            email: "អាសយដ្ឋានអ៊ីមែល",
            url: "URL",
            emoji: "សញ្ញាអារម្មណ៍",
            uuid: "UUID",
            uuidv4: "UUIDv4",
            uuidv6: "UUIDv6",
            nanoid: "nanoid",
            guid: "GUID",
            cuid: "cuid",
            cuid2: "cuid2",
            ulid: "ULID",
            xid: "XID",
            ksuid: "KSUID",
            datetime: "កាលបរិច្ឆេទ និងម៉ោង ISO",
            date: "កាលបរិច្ឆេទ ISO",
            time: "ម៉ោង ISO",
            duration: "រយៈពេល ISO",
            ipv4: "អាសយដ្ឋាន IPv4",
            ipv6: "អាសយដ្ឋាន IPv6",
            cidrv4: "ដែនអាសយដ្ឋាន IPv4",
            cidrv6: "ដែនអាសយដ្ឋាន IPv6",
            base64: "ខ្សែអក្សរអ៊ិកូដ base64",
            base64url: "ខ្សែអក្សរអ៊ិកូដ base64url",
            json_string: "ខ្សែអក្សរ JSON",
            e164: "លេខ E.164",
            jwt: "JWT",
            template_literal: "ទិន្នន័យបញ្ចូល",
          }),
          (i) => {
            switch (i.code) {
              case "invalid_type":
                return `ទិន្នន័យបញ្ចូលមិនត្រឹមត្រូវ៖ ត្រូវការ ${i.expected} ប៉ុន្តែទទួលបាន ${((e) => {
                  let t = typeof e;
                  switch (t) {
                    case "number":
                      return Number.isNaN(e) ? "មិនមែនជាលេខ (NaN)" : "លេខ";
                    case "object":
                      if (Array.isArray(e)) return "អារេ (Array)";
                      if (null === e) return "គ្មានតម្លៃ (null)";
                      if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                        return e.constructor.name;
                  }
                  return t;
                })(i.input)}`;
              case "invalid_value":
                if (1 === i.values.length) return `ទិន្នន័យបញ្ចូលមិនត្រឹមត្រូវ៖ ត្រូវការ ${P(i.values[0])}`;
                return `ជម្រើសមិនត្រឹមត្រូវ៖ ត្រូវជាមួយក្នុងចំណោម ${c(i.values, "|")}`;
              case "too_big": {
                let t = i.inclusive ? "<=" : "<",
                  r = e[i.origin] ?? null;
                if (r)
                  return `ធំពេក៖ ត្រូវការ ${i.origin ?? "តម្លៃ"} ${t} ${i.maximum.toString()} ${r.unit ?? "ធាតុ"}`;
                return `ធំពេក៖ ត្រូវការ ${i.origin ?? "តម្លៃ"} ${t} ${i.maximum.toString()}`;
              }
              case "too_small": {
                let t = i.inclusive ? ">=" : ">",
                  r = e[i.origin] ?? null;
                if (r) return `តូចពេក៖ ត្រូវការ ${i.origin} ${t} ${i.minimum.toString()} ${r.unit}`;
                return `តូចពេក៖ ត្រូវការ ${i.origin} ${t} ${i.minimum.toString()}`;
              }
              case "invalid_format":
                if ("starts_with" === i.format)
                  return `ខ្សែអក្សរមិនត្រឹមត្រូវ៖ ត្រូវចាប់ផ្តើមដោយ "${i.prefix}"`;
                if ("ends_with" === i.format) return `ខ្សែអក្សរមិនត្រឹមត្រូវ៖ ត្រូវបញ្ចប់ដោយ "${i.suffix}"`;
                if ("includes" === i.format) return `ខ្សែអក្សរមិនត្រឹមត្រូវ៖ ត្រូវមាន "${i.includes}"`;
                if ("regex" === i.format)
                  return `ខ្សែអក្សរមិនត្រឹមត្រូវ៖ ត្រូវតែផ្គូផ្គងនឹងទម្រង់ដែលបានកំណត់ ${i.pattern}`;
                return `មិនត្រឹមត្រូវ៖ ${t[i.format] ?? i.format}`;
              case "not_multiple_of":
                return `លេខមិនត្រឹមត្រូវ៖ ត្រូវតែជាពហុគុណនៃ ${i.divisor}`;
              case "unrecognized_keys":
                return `រកឃើញសោមិនស្គាល់៖ ${c(i.keys, ", ")}`;
              case "invalid_key":
                return `សោមិនត្រឹមត្រូវនៅក្នុង ${i.origin}`;
              case "invalid_union":
              default:
                return "ទិន្នន័យមិនត្រឹមត្រូវ";
              case "invalid_element":
                return `ទិន្នន័យមិនត្រឹមត្រូវនៅក្នុង ${i.origin}`;
            }
          }),
      };
    }
    e.s(
      [
        "$ZodAny",
        0,
        il,
        "$ZodArray",
        0,
        ig,
        "$ZodBase64",
        0,
        t1,
        "$ZodBase64URL",
        0,
        t9,
        "$ZodBigInt",
        0,
        ir,
        "$ZodBigIntFormat",
        0,
        ia,
        "$ZodBoolean",
        0,
        ii,
        "$ZodCIDRv4",
        0,
        t0,
        "$ZodCIDRv6",
        0,
        t4,
        "$ZodCUID",
        0,
        tF,
        "$ZodCUID2",
        0,
        tJ,
        "$ZodCatch",
        0,
        iK,
        "$ZodCodec",
        0,
        iY,
        "$ZodCustom",
        0,
        i3,
        "$ZodCustomStringFormat",
        0,
        t8,
        "$ZodDate",
        0,
        ip,
        "$ZodDefault",
        0,
        iB,
        "$ZodDiscriminatedUnion",
        0,
        ik,
        "$ZodE164",
        0,
        t3,
        "$ZodEmail",
        0,
        tL,
        "$ZodEmoji",
        0,
        tB,
        "$ZodEnum",
        0,
        ij,
        "$ZodFile",
        0,
        iD,
        "$ZodFunction",
        0,
        i1,
        "$ZodGUID",
        0,
        tA,
        "$ZodIPv4",
        0,
        tH,
        "$ZodIPv6",
        0,
        tQ,
        "$ZodISODate",
        0,
        tW,
        "$ZodISODateTime",
        0,
        tV,
        "$ZodISODuration",
        0,
        tY,
        "$ZodISOTime",
        0,
        tq,
        "$ZodIntersection",
        0,
        iS,
        "$ZodJWT",
        0,
        t7,
        "$ZodKSUID",
        0,
        tK,
        "$ZodLazy",
        0,
        i9,
        "$ZodLiteral",
        0,
        iT,
        "$ZodMap",
        0,
        iz,
        "$ZodNaN",
        0,
        iV,
        "$ZodNanoID",
        0,
        tX,
        "$ZodNever",
        0,
        ic,
        "$ZodNonOptional",
        0,
        iJ,
        "$ZodNull",
        0,
        is,
        "$ZodNullable",
        0,
        iR,
        "$ZodNumber",
        0,
        ie,
        "$ZodNumberFormat",
        0,
        it,
        "$ZodObject",
        0,
        iy,
        "$ZodObjectJIT",
        0,
        ib,
        "$ZodOptional",
        0,
        iL,
        "$ZodPipe",
        0,
        iW,
        "$ZodPrefault",
        0,
        iF,
        "$ZodPromise",
        0,
        i2,
        "$ZodReadonly",
        0,
        i0,
        "$ZodRecord",
        0,
        iN,
        "$ZodSet",
        0,
        iP,
        "$ZodString",
        0,
        tT,
        "$ZodStringFormat",
        0,
        tD,
        "$ZodSuccess",
        0,
        iM,
        "$ZodSymbol",
        0,
        io,
        "$ZodTemplateLiteral",
        0,
        i6,
        "$ZodTransform",
        0,
        iA,
        "$ZodTuple",
        0,
        iU,
        "$ZodType",
        0,
        tj,
        "$ZodULID",
        0,
        tG,
        "$ZodURL",
        0,
        tR,
        "$ZodUUID",
        0,
        tC,
        "$ZodUndefined",
        0,
        iu,
        "$ZodUnion",
        0,
        ix,
        "$ZodUnknown",
        0,
        id,
        "$ZodVoid",
        0,
        im,
        "$ZodXID",
        0,
        tM,
        "isValidBase64",
        0,
        t6,
        "isValidBase64URL",
        0,
        t2,
        "isValidJWT",
        0,
        t5,
      ],
      676094,
    );
    let rt = function (e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : void 0;
        switch (e) {
          case "number":
            return Number.isNaN(t) ? "NaN" : "skaičius";
          case "bigint":
            return "sveikasis skaičius";
          case "string":
            return "eilutė";
          case "boolean":
            return "loginė reikšmė";
          case "undefined":
          case "void":
            return "neapibrėžta reikšmė";
          case "function":
            return "funkcija";
          case "symbol":
            return "simbolis";
          case "object":
            if (void 0 === t) return "nežinomas objektas";
            if (null === t) return "nulinė reikšmė";
            if (Array.isArray(t)) return "masyvas";
            if (Object.getPrototypeOf(t) !== Object.prototype && t.constructor) return t.constructor.name;
            return "objektas";
          case "null":
            return "nulinė reikšmė";
        }
        return e;
      },
      ri = (e) => e.charAt(0).toUpperCase() + e.slice(1);
    function rr(e) {
      let t = Math.abs(e),
        i = t % 10,
        r = t % 100;
      return (r >= 11 && r <= 19) || 0 === i ? "many" : 1 === i ? "one" : "few";
    }
    function rn(e, t, i, r) {
      let n = Math.abs(e),
        a = n % 10,
        o = n % 100;
      return o >= 11 && o <= 19 ? r : 1 === a ? t : a >= 2 && a <= 4 ? i : r;
    }
    function ra() {
      let e, t;
      return {
        localeError:
          ((e = {
            string: { unit: "символів", verb: "матиме" },
            file: { unit: "байтів", verb: "матиме" },
            array: { unit: "елементів", verb: "матиме" },
            set: { unit: "елементів", verb: "матиме" },
          }),
          (t = {
            regex: "вхідні дані",
            email: "адреса електронної пошти",
            url: "URL",
            emoji: "емодзі",
            uuid: "UUID",
            uuidv4: "UUIDv4",
            uuidv6: "UUIDv6",
            nanoid: "nanoid",
            guid: "GUID",
            cuid: "cuid",
            cuid2: "cuid2",
            ulid: "ULID",
            xid: "XID",
            ksuid: "KSUID",
            datetime: "дата та час ISO",
            date: "дата ISO",
            time: "час ISO",
            duration: "тривалість ISO",
            ipv4: "адреса IPv4",
            ipv6: "адреса IPv6",
            cidrv4: "діапазон IPv4",
            cidrv6: "діапазон IPv6",
            base64: "рядок у кодуванні base64",
            base64url: "рядок у кодуванні base64url",
            json_string: "рядок JSON",
            e164: "номер E.164",
            jwt: "JWT",
            template_literal: "вхідні дані",
          }),
          (i) => {
            switch (i.code) {
              case "invalid_type":
                return `Неправильні вхідні дані: очікується ${i.expected}, отримано ${((e) => {
                  let t = typeof e;
                  switch (t) {
                    case "number":
                      return Number.isNaN(e) ? "NaN" : "число";
                    case "object":
                      if (Array.isArray(e)) return "масив";
                      if (null === e) return "null";
                      if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                        return e.constructor.name;
                  }
                  return t;
                })(i.input)}`;
              case "invalid_value":
                if (1 === i.values.length) return `Неправильні вхідні дані: очікується ${P(i.values[0])}`;
                return `Неправильна опція: очікується одне з ${c(i.values, "|")}`;
              case "too_big": {
                let t = i.inclusive ? "<=" : "<",
                  r = e[i.origin] ?? null;
                if (r)
                  return `Занадто велике: очікується, що ${i.origin ?? "значення"} ${r.verb} ${t}${i.maximum.toString()} ${r.unit ?? "елементів"}`;
                return `Занадто велике: очікується, що ${i.origin ?? "значення"} буде ${t}${i.maximum.toString()}`;
              }
              case "too_small": {
                let t = i.inclusive ? ">=" : ">",
                  r = e[i.origin] ?? null;
                if (r)
                  return `Занадто мале: очікується, що ${i.origin} ${r.verb} ${t}${i.minimum.toString()} ${r.unit}`;
                return `Занадто мале: очікується, що ${i.origin} буде ${t}${i.minimum.toString()}`;
              }
              case "invalid_format":
                if ("starts_with" === i.format)
                  return `Неправильний рядок: повинен починатися з "${i.prefix}"`;
                if ("ends_with" === i.format)
                  return `Неправильний рядок: повинен закінчуватися на "${i.suffix}"`;
                if ("includes" === i.format) return `Неправильний рядок: повинен містити "${i.includes}"`;
                if ("regex" === i.format)
                  return `Неправильний рядок: повинен відповідати шаблону ${i.pattern}`;
                return `Неправильний ${t[i.format] ?? i.format}`;
              case "not_multiple_of":
                return `Неправильне число: повинно бути кратним ${i.divisor}`;
              case "unrecognized_keys":
                return `Нерозпізнаний ключ${i.keys.length > 1 ? "і" : ""}: ${c(i.keys, ", ")}`;
              case "invalid_key":
                return `Неправильний ключ у ${i.origin}`;
              case "invalid_union":
              default:
                return "Неправильні вхідні дані";
              case "invalid_element":
                return `Неправильне значення у ${i.origin}`;
            }
          }),
      };
    }
    function ro(e, t) {
      return new e({ type: "string", ...O(t) });
    }
    function ru(e, t) {
      return new e({ type: "string", coerce: !0, ...O(t) });
    }
    function rs(e, t) {
      return new e({ type: "string", format: "email", check: "string_format", abort: !1, ...O(t) });
    }
    function rl(e, t) {
      return new e({ type: "string", format: "guid", check: "string_format", abort: !1, ...O(t) });
    }
    function rd(e, t) {
      return new e({ type: "string", format: "uuid", check: "string_format", abort: !1, ...O(t) });
    }
    function rc(e, t) {
      return new e({
        type: "string",
        format: "uuid",
        check: "string_format",
        abort: !1,
        version: "v4",
        ...O(t),
      });
    }
    function rm(e, t) {
      return new e({
        type: "string",
        format: "uuid",
        check: "string_format",
        abort: !1,
        version: "v6",
        ...O(t),
      });
    }
    function rf(e, t) {
      return new e({
        type: "string",
        format: "uuid",
        check: "string_format",
        abort: !1,
        version: "v7",
        ...O(t),
      });
    }
    function rp(e, t) {
      return new e({ type: "string", format: "url", check: "string_format", abort: !1, ...O(t) });
    }
    function rv(e, t) {
      return new e({ type: "string", format: "emoji", check: "string_format", abort: !1, ...O(t) });
    }
    function rg(e, t) {
      return new e({ type: "string", format: "nanoid", check: "string_format", abort: !1, ...O(t) });
    }
    function r_(e, t) {
      return new e({ type: "string", format: "cuid", check: "string_format", abort: !1, ...O(t) });
    }
    function rh(e, t) {
      return new e({ type: "string", format: "cuid2", check: "string_format", abort: !1, ...O(t) });
    }
    function r$(e, t) {
      return new e({ type: "string", format: "ulid", check: "string_format", abort: !1, ...O(t) });
    }
    function ry(e, t) {
      return new e({ type: "string", format: "xid", check: "string_format", abort: !1, ...O(t) });
    }
    function rb(e, t) {
      return new e({ type: "string", format: "ksuid", check: "string_format", abort: !1, ...O(t) });
    }
    function rI(e, t) {
      return new e({ type: "string", format: "ipv4", check: "string_format", abort: !1, ...O(t) });
    }
    function rx(e, t) {
      return new e({ type: "string", format: "ipv6", check: "string_format", abort: !1, ...O(t) });
    }
    function rk(e, t) {
      return new e({ type: "string", format: "cidrv4", check: "string_format", abort: !1, ...O(t) });
    }
    function rS(e, t) {
      return new e({ type: "string", format: "cidrv6", check: "string_format", abort: !1, ...O(t) });
    }
    function rw(e, t) {
      return new e({ type: "string", format: "base64", check: "string_format", abort: !1, ...O(t) });
    }
    function rU(e, t) {
      return new e({ type: "string", format: "base64url", check: "string_format", abort: !1, ...O(t) });
    }
    function rE(e, t) {
      return new e({ type: "string", format: "e164", check: "string_format", abort: !1, ...O(t) });
    }
    function rN(e, t) {
      return new e({ type: "string", format: "jwt", check: "string_format", abort: !1, ...O(t) });
    }
    e.s([], 543365);
    let rz = { Any: null, Minute: -1, Second: 0, Millisecond: 3, Microsecond: 6 };
    function rO(e, t) {
      return new e({
        type: "string",
        format: "datetime",
        check: "string_format",
        offset: !1,
        local: !1,
        precision: null,
        ...O(t),
      });
    }
    function rP(e, t) {
      return new e({ type: "string", format: "date", check: "string_format", ...O(t) });
    }
    function rZ(e, t) {
      return new e({ type: "string", format: "time", check: "string_format", precision: null, ...O(t) });
    }
    function rj(e, t) {
      return new e({ type: "string", format: "duration", check: "string_format", ...O(t) });
    }
    function rT(e, t) {
      return new e({ type: "number", checks: [], ...O(t) });
    }
    function rD(e, t) {
      return new e({ type: "number", coerce: !0, checks: [], ...O(t) });
    }
    function rA(e, t) {
      return new e({ type: "number", check: "number_format", abort: !1, format: "safeint", ...O(t) });
    }
    function rC(e, t) {
      return new e({ type: "number", check: "number_format", abort: !1, format: "float32", ...O(t) });
    }
    function rL(e, t) {
      return new e({ type: "number", check: "number_format", abort: !1, format: "float64", ...O(t) });
    }
    function rR(e, t) {
      return new e({ type: "number", check: "number_format", abort: !1, format: "int32", ...O(t) });
    }
    function rB(e, t) {
      return new e({ type: "number", check: "number_format", abort: !1, format: "uint32", ...O(t) });
    }
    function rX(e, t) {
      return new e({ type: "boolean", ...O(t) });
    }
    function rF(e, t) {
      return new e({ type: "boolean", coerce: !0, ...O(t) });
    }
    function rJ(e, t) {
      return new e({ type: "bigint", ...O(t) });
    }
    function rG(e, t) {
      return new e({ type: "bigint", coerce: !0, ...O(t) });
    }
    function rM(e, t) {
      return new e({ type: "bigint", check: "bigint_format", abort: !1, format: "int64", ...O(t) });
    }
    function rK(e, t) {
      return new e({ type: "bigint", check: "bigint_format", abort: !1, format: "uint64", ...O(t) });
    }
    function rV(e, t) {
      return new e({ type: "symbol", ...O(t) });
    }
    function rW(e, t) {
      return new e({ type: "undefined", ...O(t) });
    }
    function rq(e, t) {
      return new e({ type: "null", ...O(t) });
    }
    function rY(e) {
      return new e({ type: "any" });
    }
    function rH(e) {
      return new e({ type: "unknown" });
    }
    function rQ(e, t) {
      return new e({ type: "never", ...O(t) });
    }
    function r0(e, t) {
      return new e({ type: "void", ...O(t) });
    }
    function r4(e, t) {
      return new e({ type: "date", ...O(t) });
    }
    function r6(e, t) {
      return new e({ type: "date", coerce: !0, ...O(t) });
    }
    function r1(e, t) {
      return new e({ type: "nan", ...O(t) });
    }
    function r2(e, t) {
      return new td({ check: "less_than", ...O(t), value: e, inclusive: !1 });
    }
    function r9(e, t) {
      return new td({ check: "less_than", ...O(t), value: e, inclusive: !0 });
    }
    function r3(e, t) {
      return new tc({ check: "greater_than", ...O(t), value: e, inclusive: !1 });
    }
    function r5(e, t) {
      return new tc({ check: "greater_than", ...O(t), value: e, inclusive: !0 });
    }
    function r7(e) {
      return r3(0, e);
    }
    function r8(e) {
      return r2(0, e);
    }
    function ne(e) {
      return r9(0, e);
    }
    function nt(e) {
      return r5(0, e);
    }
    function ni(e, t) {
      return new tm({ check: "multiple_of", ...O(t), value: e });
    }
    function nr(e, t) {
      return new tv({ check: "max_size", ...O(t), maximum: e });
    }
    function nn(e, t) {
      return new tg({ check: "min_size", ...O(t), minimum: e });
    }
    function na(e, t) {
      return new t_({ check: "size_equals", ...O(t), size: e });
    }
    function no(e, t) {
      return new th({ check: "max_length", ...O(t), maximum: e });
    }
    function nu(e, t) {
      return new t$({ check: "min_length", ...O(t), minimum: e });
    }
    function ns(e, t) {
      return new ty({ check: "length_equals", ...O(t), length: e });
    }
    function nl(e, t) {
      return new tI({ check: "string_format", format: "regex", ...O(t), pattern: e });
    }
    function nd(e) {
      return new tx({ check: "string_format", format: "lowercase", ...O(e) });
    }
    function nc(e) {
      return new tk({ check: "string_format", format: "uppercase", ...O(e) });
    }
    function nm(e, t) {
      return new tS({ check: "string_format", format: "includes", ...O(t), includes: e });
    }
    function nf(e, t) {
      return new tw({ check: "string_format", format: "starts_with", ...O(t), prefix: e });
    }
    function np(e, t) {
      return new tU({ check: "string_format", format: "ends_with", ...O(t), suffix: e });
    }
    function nv(e, t, i) {
      return new tN({ check: "property", property: e, schema: t, ...O(i) });
    }
    function ng(e, t) {
      return new tz({ check: "mime_type", mime: e, ...O(t) });
    }
    function n_(e) {
      return new tO({ check: "overwrite", tx: e });
    }
    function nh(e) {
      return n_((t) => t.normalize(e));
    }
    function n$() {
      return n_((e) => e.trim());
    }
    function ny() {
      return n_((e) => e.toLowerCase());
    }
    function nb() {
      return n_((e) => e.toUpperCase());
    }
    function nI(e, t, i) {
      return new e({ type: "array", element: t, ...O(i) });
    }
    function nx(e, t, i) {
      return new e({ type: "union", options: t, ...O(i) });
    }
    function nk(e, t, i, r) {
      return new e({ type: "union", options: i, discriminator: t, ...O(r) });
    }
    function nS(e, t, i) {
      return new e({ type: "intersection", left: t, right: i });
    }
    function nw(e, t, i, r) {
      let n = i instanceof tj,
        a = n ? r : i;
      return new e({ type: "tuple", items: t, rest: n ? i : null, ...O(a) });
    }
    function nU(e, t, i, r) {
      return new e({ type: "record", keyType: t, valueType: i, ...O(r) });
    }
    function nE(e, t, i, r) {
      return new e({ type: "map", keyType: t, valueType: i, ...O(r) });
    }
    function nN(e, t, i) {
      return new e({ type: "set", valueType: t, ...O(i) });
    }
    function nz(e, t, i) {
      return new e({
        type: "enum",
        entries: Array.isArray(t) ? Object.fromEntries(t.map((e) => [e, e])) : t,
        ...O(i),
      });
    }
    function nO(e, t, i) {
      return new e({ type: "enum", entries: t, ...O(i) });
    }
    function nP(e, t, i) {
      return new e({ type: "literal", values: Array.isArray(t) ? t : [t], ...O(i) });
    }
    function nZ(e, t) {
      return new e({ type: "file", ...O(t) });
    }
    function nj(e, t) {
      return new e({ type: "transform", transform: t });
    }
    function nT(e, t) {
      return new e({ type: "optional", innerType: t });
    }
    function nD(e, t) {
      return new e({ type: "nullable", innerType: t });
    }
    function nA(e, t, i) {
      return new e({
        type: "default",
        innerType: t,
        get defaultValue() {
          return "function" == typeof i ? i() : w(i);
        },
      });
    }
    function nC(e, t, i) {
      return new e({ type: "nonoptional", innerType: t, ...O(i) });
    }
    function nL(e, t) {
      return new e({ type: "success", innerType: t });
    }
    function nR(e, t, i) {
      return new e({ type: "catch", innerType: t, catchValue: "function" == typeof i ? i : () => i });
    }
    function nB(e, t, i) {
      return new e({ type: "pipe", in: t, out: i });
    }
    function nX(e, t) {
      return new e({ type: "readonly", innerType: t });
    }
    function nF(e, t, i) {
      return new e({ type: "template_literal", parts: t, ...O(i) });
    }
    function nJ(e, t) {
      return new e({ type: "lazy", getter: t });
    }
    function nG(e, t) {
      return new e({ type: "promise", innerType: t });
    }
    function nM(e, t, i) {
      let r = O(i);
      return (r.abort ?? (r.abort = !0), new e({ type: "custom", check: "custom", fn: t, ...r }));
    }
    function nK(e, t, i) {
      return new e({ type: "custom", check: "custom", fn: t, ...O(i) });
    }
    function nV(e) {
      let t = nW(
        (i) => (
          (i.addIssue = (e) => {
            "string" == typeof e
              ? i.issues.push(X(e, i.value, t._zod.def))
              : (e.fatal && (e.continue = !1),
                e.code ?? (e.code = "custom"),
                e.input ?? (e.input = i.value),
                e.inst ?? (e.inst = t),
                e.continue ?? (e.continue = !t._zod.def.abort),
                i.issues.push(X(e)));
          }),
          e(i.value, i)
        ),
      );
      return t;
    }
    function nW(e, t) {
      let i = new ts({ check: "custom", ...O(t) });
      return ((i._zod.check = e), i);
    }
    function nq(e, t) {
      let i = O(t),
        r = i.truthy ?? ["true", "1", "yes", "on", "y", "enabled"],
        n = i.falsy ?? ["false", "0", "no", "off", "n", "disabled"];
      "sensitive" !== i.case &&
        ((r = r.map((e) => ("string" == typeof e ? e.toLowerCase() : e))),
        (n = n.map((e) => ("string" == typeof e ? e.toLowerCase() : e))));
      let a = new Set(r),
        o = new Set(n),
        u = e.Codec ?? iY,
        s = e.Boolean ?? ii,
        l = new u({
          type: "pipe",
          in: new (e.String ?? tT)({ type: "string", error: i.error }),
          out: new s({ type: "boolean", error: i.error }),
          transform: (e, t) => {
            let r = e;
            return (
              "sensitive" !== i.case && (r = r.toLowerCase()),
              !!a.has(r) ||
                (!o.has(r) &&
                  (t.issues.push({
                    code: "invalid_value",
                    expected: "stringbool",
                    values: [...a, ...o],
                    input: t.value,
                    inst: l,
                    continue: !1,
                  }),
                  {}))
            );
          },
          reverseTransform: (e, t) => (!0 === e ? r[0] || "true" : n[0] || "false"),
          error: i.error,
        });
      return l;
    }
    function nY(e, t, i) {
      let r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {},
        n = O(r),
        a = {
          ...O(r),
          check: "string_format",
          type: "string",
          format: t,
          fn: "function" == typeof i ? i : (e) => i.test(e),
          ...n,
        };
      return (i instanceof RegExp && (a.pattern = i), new e(a));
    }
    e.s(
      [
        "TimePrecision",
        0,
        rz,
        "_any",
        0,
        rY,
        "_array",
        0,
        nI,
        "_base64",
        0,
        rw,
        "_base64url",
        0,
        rU,
        "_bigint",
        0,
        rJ,
        "_boolean",
        0,
        rX,
        "_catch",
        0,
        nR,
        "_check",
        0,
        nW,
        "_cidrv4",
        0,
        rk,
        "_cidrv6",
        0,
        rS,
        "_coercedBigint",
        0,
        rG,
        "_coercedBoolean",
        0,
        rF,
        "_coercedDate",
        0,
        r6,
        "_coercedNumber",
        0,
        rD,
        "_coercedString",
        0,
        ru,
        "_cuid",
        0,
        r_,
        "_cuid2",
        0,
        rh,
        "_custom",
        0,
        nM,
        "_date",
        0,
        r4,
        "_default",
        0,
        nA,
        "_discriminatedUnion",
        0,
        nk,
        "_e164",
        0,
        rE,
        "_email",
        0,
        rs,
        "_emoji",
        0,
        rv,
        "_endsWith",
        0,
        np,
        "_enum",
        0,
        nz,
        "_file",
        0,
        nZ,
        "_float32",
        0,
        rC,
        "_float64",
        0,
        rL,
        "_gt",
        0,
        r3,
        "_gte",
        0,
        r5,
        "_guid",
        0,
        rl,
        "_includes",
        0,
        nm,
        "_int",
        0,
        rA,
        "_int32",
        0,
        rR,
        "_int64",
        0,
        rM,
        "_intersection",
        0,
        nS,
        "_ipv4",
        0,
        rI,
        "_ipv6",
        0,
        rx,
        "_isoDate",
        0,
        rP,
        "_isoDateTime",
        0,
        rO,
        "_isoDuration",
        0,
        rj,
        "_isoTime",
        0,
        rZ,
        "_jwt",
        0,
        rN,
        "_ksuid",
        0,
        rb,
        "_lazy",
        0,
        nJ,
        "_length",
        0,
        ns,
        "_literal",
        0,
        nP,
        "_lowercase",
        0,
        nd,
        "_lt",
        0,
        r2,
        "_lte",
        0,
        r9,
        "_map",
        0,
        nE,
        "_max",
        0,
        r9,
        "_maxLength",
        0,
        no,
        "_maxSize",
        0,
        nr,
        "_mime",
        0,
        ng,
        "_min",
        0,
        r5,
        "_minLength",
        0,
        nu,
        "_minSize",
        0,
        nn,
        "_multipleOf",
        0,
        ni,
        "_nan",
        0,
        r1,
        "_nanoid",
        0,
        rg,
        "_nativeEnum",
        0,
        nO,
        "_negative",
        0,
        r8,
        "_never",
        0,
        rQ,
        "_nonnegative",
        0,
        nt,
        "_nonoptional",
        0,
        nC,
        "_nonpositive",
        0,
        ne,
        "_normalize",
        0,
        nh,
        "_null",
        0,
        rq,
        "_nullable",
        0,
        nD,
        "_number",
        0,
        rT,
        "_optional",
        0,
        nT,
        "_overwrite",
        0,
        n_,
        "_pipe",
        0,
        nB,
        "_positive",
        0,
        r7,
        "_promise",
        0,
        nG,
        "_property",
        0,
        nv,
        "_readonly",
        0,
        nX,
        "_record",
        0,
        nU,
        "_refine",
        0,
        nK,
        "_regex",
        0,
        nl,
        "_set",
        0,
        nN,
        "_size",
        0,
        na,
        "_startsWith",
        0,
        nf,
        "_string",
        0,
        ro,
        "_stringFormat",
        0,
        nY,
        "_stringbool",
        0,
        nq,
        "_success",
        0,
        nL,
        "_superRefine",
        0,
        nV,
        "_symbol",
        0,
        rV,
        "_templateLiteral",
        0,
        nF,
        "_toLowerCase",
        0,
        ny,
        "_toUpperCase",
        0,
        nb,
        "_transform",
        0,
        nj,
        "_trim",
        0,
        n$,
        "_tuple",
        0,
        nw,
        "_uint32",
        0,
        rB,
        "_uint64",
        0,
        rK,
        "_ulid",
        0,
        r$,
        "_undefined",
        0,
        rW,
        "_union",
        0,
        nx,
        "_unknown",
        0,
        rH,
        "_uppercase",
        0,
        nc,
        "_url",
        0,
        rp,
        "_uuid",
        0,
        rd,
        "_uuidv4",
        0,
        rc,
        "_uuidv6",
        0,
        rm,
        "_uuidv7",
        0,
        rf,
        "_void",
        0,
        r0,
        "_xid",
        0,
        ry,
      ],
      650215,
    );
    let nH = Symbol("ZodOutput"),
      nQ = Symbol("ZodInput");
    class n0 {
      constructor() {
        ((this._map = new WeakMap()), (this._idmap = new Map()));
      }
      add(e) {
        for (var t = arguments.length, i = Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++)
          i[r - 1] = arguments[r];
        let n = i[0];
        if ((this._map.set(e, n), n && "object" == typeof n && "id" in n)) {
          if (this._idmap.has(n.id)) throw Error(`ID ${n.id} already exists in the registry`);
          this._idmap.set(n.id, e);
        }
        return this;
      }
      clear() {
        return ((this._map = new WeakMap()), (this._idmap = new Map()), this);
      }
      remove(e) {
        let t = this._map.get(e);
        return (
          t && "object" == typeof t && "id" in t && this._idmap.delete(t.id),
          this._map.delete(e),
          this
        );
      }
      get(e) {
        let t = e._zod.parent;
        if (t) {
          let i = { ...(this.get(t) ?? {}) };
          delete i.id;
          let r = { ...i, ...this._map.get(e) };
          return Object.keys(r).length ? r : void 0;
        }
        return this._map.get(e);
      }
      has(e) {
        return this._map.has(e);
      }
    }
    function n4() {
      return new n0();
    }
    let n6 = n4();
    e.s(
      ["$ZodRegistry", 0, n0, "$input", 0, nQ, "$output", 0, nH, "globalRegistry", 0, n6, "registry", 0, n4],
      525527,
    );
    class n1 {
      constructor(e) {
        ((this.counter = 0),
          (this.metadataRegistry = e?.metadata ?? n6),
          (this.target = e?.target ?? "draft-2020-12"),
          (this.unrepresentable = e?.unrepresentable ?? "throw"),
          (this.override = e?.override ?? (() => {})),
          (this.io = e?.io ?? "output"),
          (this.seen = new Map()));
      }
      process(e) {
        var t;
        let i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : { path: [], schemaPath: [] },
          r = e._zod.def,
          n = this.seen.get(e);
        if (n) return (n.count++, i.schemaPath.includes(e) && (n.cycle = i.path), n.schema);
        let a = { schema: {}, count: 1, cycle: void 0, path: i.path };
        this.seen.set(e, a);
        let o = e._zod.toJSONSchema?.();
        if (o) a.schema = o;
        else {
          let t = { ...i, schemaPath: [...i.schemaPath, e], path: i.path },
            n = e._zod.parent;
          if (n) ((a.ref = n), this.process(n, t), (this.seen.get(n).isParent = !0));
          else {
            let i = a.schema;
            switch (r.type) {
              case "string": {
                i.type = "string";
                let { minimum: t, maximum: r, format: n, patterns: o, contentEncoding: u } = e._zod.bag;
                if (
                  ("number" == typeof t && (i.minLength = t),
                  "number" == typeof r && (i.maxLength = r),
                  n &&
                    ((i.format =
                      {
                        guid: "uuid",
                        url: "uri",
                        datetime: "date-time",
                        json_string: "json-string",
                        regex: "",
                      }[n] ?? n),
                    "" === i.format && delete i.format),
                  u && (i.contentEncoding = u),
                  o && o.size > 0)
                ) {
                  let e = [...o];
                  1 === e.length
                    ? (i.pattern = e[0].source)
                    : e.length > 1 &&
                      (a.schema.allOf = [
                        ...e.map((e) => ({
                          ...("draft-7" === this.target ||
                          "draft-4" === this.target ||
                          "openapi-3.0" === this.target
                            ? { type: "string" }
                            : {}),
                          pattern: e.source,
                        })),
                      ]);
                }
                break;
              }
              case "number": {
                let {
                  minimum: t,
                  maximum: r,
                  format: n,
                  multipleOf: a,
                  exclusiveMaximum: o,
                  exclusiveMinimum: u,
                } = e._zod.bag;
                ("string" == typeof n && n.includes("int") ? (i.type = "integer") : (i.type = "number"),
                  "number" == typeof u &&
                    ("draft-4" === this.target || "openapi-3.0" === this.target
                      ? ((i.minimum = u), (i.exclusiveMinimum = !0))
                      : (i.exclusiveMinimum = u)),
                  "number" == typeof t &&
                    ((i.minimum = t),
                    "number" == typeof u &&
                      "draft-4" !== this.target &&
                      (u >= t ? delete i.minimum : delete i.exclusiveMinimum)),
                  "number" == typeof o &&
                    ("draft-4" === this.target || "openapi-3.0" === this.target
                      ? ((i.maximum = o), (i.exclusiveMaximum = !0))
                      : (i.exclusiveMaximum = o)),
                  "number" == typeof r &&
                    ((i.maximum = r),
                    "number" == typeof o &&
                      "draft-4" !== this.target &&
                      (o <= r ? delete i.maximum : delete i.exclusiveMaximum)),
                  "number" == typeof a && (i.multipleOf = a));
                break;
              }
              case "boolean":
              case "success":
                i.type = "boolean";
                break;
              case "bigint":
                if ("throw" === this.unrepresentable)
                  throw Error("BigInt cannot be represented in JSON Schema");
                break;
              case "symbol":
                if ("throw" === this.unrepresentable)
                  throw Error("Symbols cannot be represented in JSON Schema");
                break;
              case "null":
                "openapi-3.0" === this.target
                  ? ((i.type = "string"), (i.nullable = !0), (i.enum = [null]))
                  : (i.type = "null");
                break;
              case "any":
              case "unknown":
                break;
              case "undefined":
                if ("throw" === this.unrepresentable)
                  throw Error("Undefined cannot be represented in JSON Schema");
                break;
              case "void":
                if ("throw" === this.unrepresentable)
                  throw Error("Void cannot be represented in JSON Schema");
                break;
              case "never":
                i.not = {};
                break;
              case "date":
                if ("throw" === this.unrepresentable)
                  throw Error("Date cannot be represented in JSON Schema");
                break;
              case "array": {
                let { minimum: n, maximum: a } = e._zod.bag;
                ("number" == typeof n && (i.minItems = n),
                  "number" == typeof a && (i.maxItems = a),
                  (i.type = "array"),
                  (i.items = this.process(r.element, { ...t, path: [...t.path, "items"] })));
                break;
              }
              case "object": {
                ((i.type = "object"), (i.properties = {}));
                let e = r.shape;
                for (let r in e)
                  i.properties[r] = this.process(e[r], { ...t, path: [...t.path, "properties", r] });
                let n = new Set(
                  [...new Set(Object.keys(e))].filter((e) => {
                    let t = r.shape[e]._zod;
                    return "input" === this.io ? void 0 === t.optin : void 0 === t.optout;
                  }),
                );
                (n.size > 0 && (i.required = Array.from(n)),
                  r.catchall?._zod.def.type === "never"
                    ? (i.additionalProperties = !1)
                    : r.catchall
                      ? r.catchall &&
                        (i.additionalProperties = this.process(r.catchall, {
                          ...t,
                          path: [...t.path, "additionalProperties"],
                        }))
                      : "output" === this.io && (i.additionalProperties = !1));
                break;
              }
              case "union":
                i.anyOf = r.options.map((e, i) => this.process(e, { ...t, path: [...t.path, "anyOf", i] }));
                break;
              case "intersection": {
                let e = this.process(r.left, { ...t, path: [...t.path, "allOf", 0] }),
                  n = this.process(r.right, { ...t, path: [...t.path, "allOf", 1] }),
                  a = (e) => "allOf" in e && 1 === Object.keys(e).length;
                i.allOf = [...(a(e) ? e.allOf : [e]), ...(a(n) ? n.allOf : [n])];
                break;
              }
              case "tuple": {
                i.type = "array";
                let n = "draft-2020-12" === this.target ? "prefixItems" : "items",
                  a =
                    "draft-2020-12" === this.target || "openapi-3.0" === this.target
                      ? "items"
                      : "additionalItems",
                  o = r.items.map((e, i) => this.process(e, { ...t, path: [...t.path, n, i] })),
                  u = r.rest
                    ? this.process(r.rest, {
                        ...t,
                        path: [...t.path, a, ...("openapi-3.0" === this.target ? [r.items.length] : [])],
                      })
                    : null;
                "draft-2020-12" === this.target
                  ? ((i.prefixItems = o), u && (i.items = u))
                  : "openapi-3.0" === this.target
                    ? ((i.items = { anyOf: o }),
                      u && i.items.anyOf.push(u),
                      (i.minItems = o.length),
                      u || (i.maxItems = o.length))
                    : ((i.items = o), u && (i.additionalItems = u));
                let { minimum: s, maximum: l } = e._zod.bag;
                ("number" == typeof s && (i.minItems = s), "number" == typeof l && (i.maxItems = l));
                break;
              }
              case "record":
                ((i.type = "object"),
                  ("draft-7" === this.target || "draft-2020-12" === this.target) &&
                    (i.propertyNames = this.process(r.keyType, { ...t, path: [...t.path, "propertyNames"] })),
                  (i.additionalProperties = this.process(r.valueType, {
                    ...t,
                    path: [...t.path, "additionalProperties"],
                  })));
                break;
              case "map":
                if ("throw" === this.unrepresentable) throw Error("Map cannot be represented in JSON Schema");
                break;
              case "set":
                if ("throw" === this.unrepresentable) throw Error("Set cannot be represented in JSON Schema");
                break;
              case "enum": {
                let e = d(r.entries);
                (e.every((e) => "number" == typeof e) && (i.type = "number"),
                  e.every((e) => "string" == typeof e) && (i.type = "string"),
                  (i.enum = e));
                break;
              }
              case "literal": {
                let e = [];
                for (let t of r.values)
                  if (void 0 === t) {
                    if ("throw" === this.unrepresentable)
                      throw Error("Literal `undefined` cannot be represented in JSON Schema");
                  } else if ("bigint" == typeof t)
                    if ("throw" === this.unrepresentable)
                      throw Error("BigInt literals cannot be represented in JSON Schema");
                    else e.push(Number(t));
                  else e.push(t);
                if (0 === e.length);
                else if (1 === e.length) {
                  let t = e[0];
                  ((i.type = null === t ? "null" : typeof t),
                    "draft-4" === this.target || "openapi-3.0" === this.target
                      ? (i.enum = [t])
                      : (i.const = t));
                } else
                  (e.every((e) => "number" == typeof e) && (i.type = "number"),
                    e.every((e) => "string" == typeof e) && (i.type = "string"),
                    e.every((e) => "boolean" == typeof e) && (i.type = "string"),
                    e.every((e) => null === e) && (i.type = "null"),
                    (i.enum = e));
                break;
              }
              case "file": {
                let t = { type: "string", format: "binary", contentEncoding: "binary" },
                  { minimum: r, maximum: n, mime: a } = e._zod.bag;
                (void 0 !== r && (t.minLength = r),
                  void 0 !== n && (t.maxLength = n),
                  a
                    ? 1 === a.length
                      ? ((t.contentMediaType = a[0]), Object.assign(i, t))
                      : (i.anyOf = a.map((e) => ({ ...t, contentMediaType: e })))
                    : Object.assign(i, t));
                break;
              }
              case "transform":
                if ("throw" === this.unrepresentable)
                  throw Error("Transforms cannot be represented in JSON Schema");
                break;
              case "nullable": {
                let e = this.process(r.innerType, t);
                "openapi-3.0" === this.target
                  ? ((a.ref = r.innerType), (i.nullable = !0))
                  : (i.anyOf = [e, { type: "null" }]);
                break;
              }
              case "nonoptional":
              case "promise":
              case "optional":
                (this.process(r.innerType, t), (a.ref = r.innerType));
                break;
              case "default":
                (this.process(r.innerType, t),
                  (a.ref = r.innerType),
                  (i.default = JSON.parse(JSON.stringify(r.defaultValue))));
                break;
              case "prefault":
                (this.process(r.innerType, t),
                  (a.ref = r.innerType),
                  "input" === this.io && (i._prefault = JSON.parse(JSON.stringify(r.defaultValue))));
                break;
              case "catch": {
                let e;
                (this.process(r.innerType, t), (a.ref = r.innerType));
                try {
                  e = r.catchValue(void 0);
                } catch {
                  throw Error("Dynamic catch values are not supported in JSON Schema");
                }
                i.default = e;
                break;
              }
              case "nan":
                if ("throw" === this.unrepresentable) throw Error("NaN cannot be represented in JSON Schema");
                break;
              case "template_literal": {
                let t = e._zod.pattern;
                if (!t) throw Error("Pattern not found in template literal");
                ((i.type = "string"), (i.pattern = t.source));
                break;
              }
              case "pipe": {
                let e = "input" === this.io ? ("transform" === r.in._zod.def.type ? r.out : r.in) : r.out;
                (this.process(e, t), (a.ref = e));
                break;
              }
              case "readonly":
                (this.process(r.innerType, t), (a.ref = r.innerType), (i.readOnly = !0));
                break;
              case "lazy": {
                let i = e._zod.innerType;
                (this.process(i, t), (a.ref = i));
                break;
              }
              case "custom":
                if ("throw" === this.unrepresentable)
                  throw Error("Custom types cannot be represented in JSON Schema");
                break;
              case "function":
                if ("throw" === this.unrepresentable)
                  throw Error("Function types cannot be represented in JSON Schema");
            }
          }
        }
        let u = this.metadataRegistry.get(e);
        return (
          u && Object.assign(a.schema, u),
          "input" === this.io &&
            (function e(t, i) {
              let r = i ?? { seen: new Set() };
              if (r.seen.has(t)) return !1;
              r.seen.add(t);
              let n = t._zod.def;
              switch (n.type) {
                case "string":
                case "number":
                case "bigint":
                case "boolean":
                case "date":
                case "symbol":
                case "undefined":
                case "null":
                case "any":
                case "unknown":
                case "never":
                case "void":
                case "literal":
                case "enum":
                case "nan":
                case "file":
                case "template_literal":
                case "custom":
                case "success":
                case "catch":
                case "function":
                  return !1;
                case "array":
                  return e(n.element, r);
                case "object":
                  for (let t in n.shape) if (e(n.shape[t], r)) return !0;
                  return !1;
                case "union":
                  for (let t of n.options) if (e(t, r)) return !0;
                  return !1;
                case "intersection":
                  return e(n.left, r) || e(n.right, r);
                case "tuple":
                  for (let t of n.items) if (e(t, r)) return !0;
                  if (n.rest && e(n.rest, r)) return !0;
                  return !1;
                case "record":
                case "map":
                  return e(n.keyType, r) || e(n.valueType, r);
                case "set":
                  return e(n.valueType, r);
                case "promise":
                case "optional":
                case "nonoptional":
                case "nullable":
                case "readonly":
                case "default":
                case "prefault":
                  return e(n.innerType, r);
                case "lazy":
                  return e(n.getter(), r);
                case "transform":
                  return !0;
                case "pipe":
                  return e(n.in, r) || e(n.out, r);
              }
              throw Error(`Unknown schema type: ${n.type}`);
            })(e) &&
            (delete a.schema.examples, delete a.schema.default),
          "input" === this.io &&
            a.schema._prefault &&
            ((t = a.schema).default ?? (t.default = a.schema._prefault)),
          delete a.schema._prefault,
          this.seen.get(e).schema
        );
      }
      emit(e, t) {
        let i = {
            cycles: t?.cycles ?? "ref",
            reused: t?.reused ?? "inline",
            external: t?.external ?? void 0,
          },
          r = this.seen.get(e);
        if (!r) throw Error("Unprocessed schema. This is a bug in Zod.");
        let n = (e) => {
            let t = "draft-2020-12" === this.target ? "$defs" : "definitions";
            if (i.external) {
              let r = i.external.registry.get(e[0])?.id,
                n = i.external.uri ?? ((e) => e);
              if (r) return { ref: n(r) };
              let a = e[1].defId ?? e[1].schema.id ?? `schema${this.counter++}`;
              return ((e[1].defId = a), { defId: a, ref: `${n("__shared")}#/${t}/${a}` });
            }
            if (e[1] === r) return { ref: "#" };
            let n = `#/${t}/`,
              a = e[1].schema.id ?? `__schema${this.counter++}`;
            return { defId: a, ref: n + a };
          },
          a = (e) => {
            if (e[1].schema.$ref) return;
            let t = e[1],
              { ref: i, defId: r } = n(e);
            ((t.def = { ...t.schema }), r && (t.defId = r));
            let a = t.schema;
            for (let e in a) delete a[e];
            a.$ref = i;
          };
        if ("throw" === i.cycles)
          for (let e of this.seen.entries()) {
            let t = e[1];
            if (t.cycle)
              throw Error(`Cycle detected: #/${t.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
          }
        for (let t of this.seen.entries()) {
          let r = t[1];
          if (e === t[0]) {
            a(t);
            continue;
          }
          if (i.external) {
            let r = i.external.registry.get(t[0])?.id;
            if (e !== t[0] && r) {
              a(t);
              continue;
            }
          }
          if (this.metadataRegistry.get(t[0])?.id || r.cycle || (r.count > 1 && "ref" === i.reused)) {
            a(t);
            continue;
          }
        }
        let o = (e, t) => {
          let i = this.seen.get(e),
            r = i.def ?? i.schema,
            n = { ...r };
          if (null === i.ref) return;
          let a = i.ref;
          if (((i.ref = null), a)) {
            o(a, t);
            let e = this.seen.get(a).schema;
            e.$ref && ("draft-7" === t.target || "draft-4" === t.target || "openapi-3.0" === t.target)
              ? ((r.allOf = r.allOf ?? []), r.allOf.push(e))
              : (Object.assign(r, e), Object.assign(r, n));
          }
          i.isParent || this.override({ zodSchema: e, jsonSchema: r, path: i.path ?? [] });
        };
        for (let e of [...this.seen.entries()].reverse()) o(e[0], { target: this.target });
        let u = {};
        if (
          ("draft-2020-12" === this.target
            ? (u.$schema = "https://json-schema.org/draft/2020-12/schema")
            : "draft-7" === this.target
              ? (u.$schema = "http://json-schema.org/draft-07/schema#")
              : "draft-4" === this.target
                ? (u.$schema = "http://json-schema.org/draft-04/schema#")
                : "openapi-3.0" === this.target || console.warn(`Invalid target: ${this.target}`),
          i.external?.uri)
        ) {
          let t = i.external.registry.get(e)?.id;
          if (!t) throw Error("Schema is missing an `id` property");
          u.$id = i.external.uri(t);
        }
        Object.assign(u, r.def);
        let s = i.external?.defs ?? {};
        for (let e of this.seen.entries()) {
          let t = e[1];
          t.def && t.defId && (s[t.defId] = t.def);
        }
        i.external ||
          (Object.keys(s).length > 0 &&
            ("draft-2020-12" === this.target ? (u.$defs = s) : (u.definitions = s)));
        try {
          return JSON.parse(JSON.stringify(u));
        } catch (e) {
          throw Error("Error converting schema to JSON.");
        }
      }
    }
    function n2(e, t) {
      if (e instanceof n0) {
        let i = new n1(t),
          r = {};
        for (let t of e._idmap.entries()) {
          let [e, r] = t;
          i.process(r);
        }
        let n = {},
          a = { registry: e, uri: t?.uri, defs: r };
        for (let r of e._idmap.entries()) {
          let [e, o] = r;
          n[e] = i.emit(o, { ...t, external: a });
        }
        return (
          Object.keys(r).length > 0 &&
            (n.__shared = { ["draft-2020-12" === i.target ? "$defs" : "definitions"]: r }),
          { schemas: n }
        );
      }
      let i = new n1(t);
      return (i.process(e), i.emit(e, t));
    }
    (e.s(["JSONSchemaGenerator", 0, n1, "toJSONSchema", 0, n2], 34966),
      e.s([], 292135),
      e.s(
        [
          "ZodAny",
          () => oN,
          "ZodArray",
          () => oL,
          "ZodBase64",
          () => a9,
          "ZodBase64URL",
          () => a5,
          "ZodBigInt",
          () => oh,
          "ZodBigIntFormat",
          () => oy,
          "ZodBoolean",
          () => og,
          "ZodCIDRv4",
          () => a4,
          "ZodCIDRv6",
          () => a1,
          "ZodCUID",
          () => aB,
          "ZodCUID2",
          () => aF,
          "ZodCatch",
          () => u$,
          "ZodCodec",
          () => uS,
          "ZodCustom",
          () => uA,
          "ZodCustomStringFormat",
          () => or,
          "ZodDate",
          () => oA,
          "ZodDefault",
          () => uc,
          "ZodDiscriminatedUnion",
          () => oV,
          "ZodE164",
          () => a8,
          "ZodEmail",
          () => aS,
          "ZodEmoji",
          () => aA,
          "ZodEnum",
          () => o5,
          "ZodFile",
          () => ui,
          "ZodFunction",
          () => uT,
          "ZodGUID",
          () => aU,
          "ZodIPv4",
          () => aY,
          "ZodIPv6",
          () => aQ,
          "ZodIntersection",
          () => oq,
          "ZodJWT",
          () => ot,
          "ZodKSUID",
          () => aW,
          "ZodLazy",
          () => uO,
          "ZodLiteral",
          () => ue,
          "ZodMap",
          () => o1,
          "ZodNaN",
          () => ub,
          "ZodNanoID",
          () => aL,
          "ZodNever",
          () => oZ,
          "ZodNonOptional",
          () => uv,
          "ZodNull",
          () => oU,
          "ZodNullable",
          () => us,
          "ZodNumber",
          () => os,
          "ZodNumberFormat",
          () => od,
          "ZodObject",
          () => oX,
          "ZodOptional",
          () => uo,
          "ZodPipe",
          () => ux,
          "ZodPrefault",
          () => uf,
          "ZodPromise",
          () => uZ,
          "ZodReadonly",
          () => uU,
          "ZodRecord",
          () => o0,
          "ZodSet",
          () => o9,
          "ZodString",
          () => aI,
          "ZodStringFormat",
          () => ak,
          "ZodSuccess",
          () => u_,
          "ZodSymbol",
          () => ox,
          "ZodTemplateLiteral",
          () => uN,
          "ZodTransform",
          () => un,
          "ZodTuple",
          () => oH,
          "ZodType",
          () => ay,
          "ZodULID",
          () => aG,
          "ZodURL",
          () => aj,
          "ZodUUID",
          () => aN,
          "ZodUndefined",
          () => oS,
          "ZodUnion",
          () => oM,
          "ZodUnknown",
          () => oO,
          "ZodVoid",
          () => oT,
          "ZodXID",
          () => aK,
          "_ZodString",
          () => ab,
          "_default",
          () => um,
          "_function",
          () => uD,
          "any",
          () => oz,
          "array",
          () => oR,
          "base64",
          () => a3,
          "base64url",
          () => a7,
          "bigint",
          () => o$,
          "boolean",
          () => o_,
          "catch",
          () => uy,
          "check",
          () => uC,
          "cidrv4",
          () => a6,
          "cidrv6",
          () => a2,
          "codec",
          () => uw,
          "cuid",
          () => aX,
          "cuid2",
          () => aJ,
          "custom",
          () => uL,
          "date",
          () => oC,
          "discriminatedUnion",
          () => oW,
          "e164",
          () => oe,
          "email",
          () => aw,
          "emoji",
          () => aC,
          "enum",
          () => o7,
          "file",
          () => ur,
          "float32",
          () => om,
          "float64",
          () => of,
          "function",
          () => uD,
          "guid",
          () => aE,
          "hash",
          () => ou,
          "hex",
          () => oo,
          "hostname",
          () => oa,
          "httpUrl",
          () => aD,
          "instanceof",
          () => uX,
          "int",
          () => oc,
          "int32",
          () => op,
          "int64",
          () => ob,
          "intersection",
          () => oY,
          "ipv4",
          () => aH,
          "ipv6",
          () => a0,
          "json",
          () => uJ,
          "jwt",
          () => oi,
          "keyof",
          () => oB,
          "ksuid",
          () => aq,
          "lazy",
          () => uP,
          "literal",
          () => ut,
          "looseObject",
          () => oG,
          "map",
          () => o2,
          "nan",
          () => uI,
          "nanoid",
          () => aR,
          "nativeEnum",
          () => o8,
          "never",
          () => oj,
          "nonoptional",
          () => ug,
          "null",
          () => oE,
          "nullable",
          () => ul,
          "nullish",
          () => ud,
          "number",
          () => ol,
          "object",
          () => oF,
          "optional",
          () => uu,
          "partialRecord",
          () => o6,
          "pipe",
          () => uk,
          "prefault",
          () => up,
          "preprocess",
          () => uG,
          "promise",
          () => uj,
          "readonly",
          () => uE,
          "record",
          () => o4,
          "refine",
          () => uR,
          "set",
          () => o3,
          "strictObject",
          () => oJ,
          "string",
          () => ax,
          "stringFormat",
          () => on,
          "stringbool",
          () => uF,
          "success",
          () => uh,
          "superRefine",
          () => uB,
          "symbol",
          () => ok,
          "templateLiteral",
          () => uz,
          "transform",
          () => ua,
          "tuple",
          () => oQ,
          "uint32",
          () => ov,
          "uint64",
          () => oI,
          "ulid",
          () => aM,
          "undefined",
          () => ow,
          "union",
          () => oK,
          "unknown",
          () => oP,
          "url",
          () => aT,
          "uuid",
          () => az,
          "uuidv4",
          () => aO,
          "uuidv6",
          () => aP,
          "uuidv7",
          () => aZ,
          "void",
          () => oD,
          "xid",
          () => aV,
        ],
        362201,
      ));
    var n9 = e.i(682358),
      n9 = n9,
      n3 = e.i(922143),
      n3 = n3;
    (e.s([], 342332),
      e.s(
        [
          "ZodISODate",
          () => n8,
          "ZodISODateTime",
          () => n5,
          "ZodISODuration",
          () => ar,
          "ZodISOTime",
          () => at,
          "date",
          () => ae,
          "datetime",
          () => n7,
          "duration",
          () => an,
          "time",
          () => ai,
        ],
        49732,
      ));
    let n5 = n("ZodISODateTime", (e, t) => {
      (tV.init(e, t), ak.init(e, t));
    });
    function n7(e) {
      return rO(n5, e);
    }
    let n8 = n("ZodISODate", (e, t) => {
      (tW.init(e, t), ak.init(e, t));
    });
    function ae(e) {
      return rP(n8, e);
    }
    let at = n("ZodISOTime", (e, t) => {
      (tq.init(e, t), ak.init(e, t));
    });
    function ai(e) {
      return rZ(at, e);
    }
    let ar = n("ZodISODuration", (e, t) => {
      (tY.init(e, t), ak.init(e, t));
    });
    function an(e) {
      return rj(ar, e);
    }
    let aa = (e, t) => {
        (M.init(e, t),
          (e.name = "ZodError"),
          Object.defineProperties(e, {
            format: { value: (t) => W(e, t) },
            flatten: { value: (t) => V(e, t) },
            addIssue: {
              value: (t) => {
                (e.issues.push(t), (e.message = JSON.stringify(e.issues, m, 2)));
              },
            },
            addIssues: {
              value: (t) => {
                (e.issues.push(...t), (e.message = JSON.stringify(e.issues, m, 2)));
              },
            },
            isEmpty: { get: () => 0 === e.issues.length },
          }));
      },
      ao = n("ZodError", aa),
      au = n("ZodError", aa, { Parent: Error });
    e.s(["ZodError", 0, ao, "ZodRealError", 0, au], 789282);
    let as = Q(au),
      al = et(au),
      ad = er(au),
      ac = ea(au),
      am = eu(au),
      af = el(au),
      ap = ec(au),
      av = ef(au),
      ag = ev(au),
      a_ = e_(au),
      ah = e$(au),
      a$ = eb(au);
    e.s(
      [
        "decode",
        0,
        af,
        "decodeAsync",
        0,
        av,
        "encode",
        0,
        am,
        "encodeAsync",
        0,
        ap,
        "parse",
        0,
        as,
        "parseAsync",
        0,
        al,
        "safeDecode",
        0,
        a_,
        "safeDecodeAsync",
        0,
        a$,
        "safeEncode",
        0,
        ag,
        "safeEncodeAsync",
        0,
        ah,
        "safeParse",
        0,
        ad,
        "safeParseAsync",
        0,
        ac,
      ],
      100364,
    );
    let ay = n(
        "ZodType",
        (e, t) => (
          tj.init(e, t),
          (e.def = t),
          (e.type = t.type),
          Object.defineProperty(e, "_def", { value: t }),
          (e.check = function () {
            for (var i = arguments.length, r = Array(i), n = 0; n < i; n++) r[n] = arguments[n];
            return e.clone(
              n3.mergeDefs(t, {
                checks: [
                  ...(t.checks ?? []),
                  ...r.map((e) =>
                    "function" == typeof e
                      ? { _zod: { check: e, def: { check: "custom" }, onattach: [] } }
                      : e,
                  ),
                ],
              }),
            );
          }),
          (e.clone = (t, i) => z(e, t, i)),
          (e.brand = () => e),
          (e.register = (t, i) => (t.add(e, i), e)),
          (e.parse = (t, i) => as(e, t, i, { callee: e.parse })),
          (e.safeParse = (t, i) => ad(e, t, i)),
          (e.parseAsync = async (t, i) => al(e, t, i, { callee: e.parseAsync })),
          (e.safeParseAsync = async (t, i) => ac(e, t, i)),
          (e.spa = e.safeParseAsync),
          (e.encode = (t, i) => am(e, t, i)),
          (e.decode = (t, i) => af(e, t, i)),
          (e.encodeAsync = async (t, i) => ap(e, t, i)),
          (e.decodeAsync = async (t, i) => av(e, t, i)),
          (e.safeEncode = (t, i) => ag(e, t, i)),
          (e.safeDecode = (t, i) => a_(e, t, i)),
          (e.safeEncodeAsync = async (t, i) => ah(e, t, i)),
          (e.safeDecodeAsync = async (t, i) => a$(e, t, i)),
          (e.refine = (t, i) => e.check(uR(t, i))),
          (e.superRefine = (t) => e.check(uB(t))),
          (e.overwrite = (t) => e.check(n_(t))),
          (e.optional = () => uu(e)),
          (e.nullable = () => ul(e)),
          (e.nullish = () => uu(ul(e))),
          (e.nonoptional = (t) => ug(e, t)),
          (e.array = () => oR(e)),
          (e.or = (t) => oK([e, t])),
          (e.and = (t) => oY(e, t)),
          (e.transform = (t) => uk(e, ua(t))),
          (e.default = (t) => um(e, t)),
          (e.prefault = (t) => up(e, t)),
          (e.catch = (t) => uy(e, t)),
          (e.pipe = (t) => uk(e, t)),
          (e.readonly = () => uE(e)),
          (e.describe = (t) => {
            let i = e.clone();
            return (n6.add(i, { description: t }), i);
          }),
          Object.defineProperty(e, "description", { get: () => n6.get(e)?.description, configurable: !0 }),
          (e.meta = function () {
            for (var t = arguments.length, i = Array(t), r = 0; r < t; r++) i[r] = arguments[r];
            if (0 === i.length) return n6.get(e);
            let n = e.clone();
            return (n6.add(n, i[0]), n);
          }),
          (e.isOptional = () => e.safeParse(void 0).success),
          (e.isNullable = () => e.safeParse(null).success),
          e
        ),
      ),
      ab = n("_ZodString", (e, t) => {
        (tT.init(e, t), ay.init(e, t));
        let i = e._zod.bag;
        ((e.format = i.format ?? null),
          (e.minLength = i.minimum ?? null),
          (e.maxLength = i.maximum ?? null),
          (e.regex = function () {
            for (var t = arguments.length, i = Array(t), r = 0; r < t; r++) i[r] = arguments[r];
            return e.check(nl(...i));
          }),
          (e.includes = function () {
            for (var t = arguments.length, i = Array(t), r = 0; r < t; r++) i[r] = arguments[r];
            return e.check(nm(...i));
          }),
          (e.startsWith = function () {
            for (var t = arguments.length, i = Array(t), r = 0; r < t; r++) i[r] = arguments[r];
            return e.check(nf(...i));
          }),
          (e.endsWith = function () {
            for (var t = arguments.length, i = Array(t), r = 0; r < t; r++) i[r] = arguments[r];
            return e.check(np(...i));
          }),
          (e.min = function () {
            for (var t = arguments.length, i = Array(t), r = 0; r < t; r++) i[r] = arguments[r];
            return e.check(nu(...i));
          }),
          (e.max = function () {
            for (var t = arguments.length, i = Array(t), r = 0; r < t; r++) i[r] = arguments[r];
            return e.check(no(...i));
          }),
          (e.length = function () {
            for (var t = arguments.length, i = Array(t), r = 0; r < t; r++) i[r] = arguments[r];
            return e.check(ns(...i));
          }),
          (e.nonempty = function () {
            for (var t = arguments.length, i = Array(t), r = 0; r < t; r++) i[r] = arguments[r];
            return e.check(nu(1, ...i));
          }),
          (e.lowercase = (t) => e.check(nd(t))),
          (e.uppercase = (t) => e.check(nc(t))),
          (e.trim = () => e.check(n$())),
          (e.normalize = function () {
            for (var t = arguments.length, i = Array(t), r = 0; r < t; r++) i[r] = arguments[r];
            return e.check(nh(...i));
          }),
          (e.toLowerCase = () => e.check(ny())),
          (e.toUpperCase = () => e.check(nb())));
      }),
      aI = n("ZodString", (e, t) => {
        (tT.init(e, t),
          ab.init(e, t),
          (e.email = (t) => e.check(rs(aS, t))),
          (e.url = (t) => e.check(rp(aj, t))),
          (e.jwt = (t) => e.check(rN(ot, t))),
          (e.emoji = (t) => e.check(rv(aA, t))),
          (e.guid = (t) => e.check(rl(aU, t))),
          (e.uuid = (t) => e.check(rd(aN, t))),
          (e.uuidv4 = (t) => e.check(rc(aN, t))),
          (e.uuidv6 = (t) => e.check(rm(aN, t))),
          (e.uuidv7 = (t) => e.check(rf(aN, t))),
          (e.nanoid = (t) => e.check(rg(aL, t))),
          (e.guid = (t) => e.check(rl(aU, t))),
          (e.cuid = (t) => e.check(r_(aB, t))),
          (e.cuid2 = (t) => e.check(rh(aF, t))),
          (e.ulid = (t) => e.check(r$(aG, t))),
          (e.base64 = (t) => e.check(rw(a9, t))),
          (e.base64url = (t) => e.check(rU(a5, t))),
          (e.xid = (t) => e.check(ry(aK, t))),
          (e.ksuid = (t) => e.check(rb(aW, t))),
          (e.ipv4 = (t) => e.check(rI(aY, t))),
          (e.ipv6 = (t) => e.check(rx(aQ, t))),
          (e.cidrv4 = (t) => e.check(rk(a4, t))),
          (e.cidrv6 = (t) => e.check(rS(a1, t))),
          (e.e164 = (t) => e.check(rE(a8, t))),
          (e.datetime = (t) => e.check(n7(t))),
          (e.date = (t) => e.check(ae(t))),
          (e.time = (t) => e.check(ai(t))),
          (e.duration = (t) => e.check(an(t))));
      });
    function ax(e) {
      return ro(aI, e);
    }
    let ak = n("ZodStringFormat", (e, t) => {
        (tD.init(e, t), ab.init(e, t));
      }),
      aS = n("ZodEmail", (e, t) => {
        (tL.init(e, t), ak.init(e, t));
      });
    function aw(e) {
      return rs(aS, e);
    }
    let aU = n("ZodGUID", (e, t) => {
      (tA.init(e, t), ak.init(e, t));
    });
    function aE(e) {
      return rl(aU, e);
    }
    let aN = n("ZodUUID", (e, t) => {
      (tC.init(e, t), ak.init(e, t));
    });
    function az(e) {
      return rd(aN, e);
    }
    function aO(e) {
      return rc(aN, e);
    }
    function aP(e) {
      return rm(aN, e);
    }
    function aZ(e) {
      return rf(aN, e);
    }
    let aj = n("ZodURL", (e, t) => {
      (tR.init(e, t), ak.init(e, t));
    });
    function aT(e) {
      return rp(aj, e);
    }
    function aD(e) {
      return rp(aj, { protocol: /^https?$/, hostname: n9.domain, ...n3.normalizeParams(e) });
    }
    let aA = n("ZodEmoji", (e, t) => {
      (tB.init(e, t), ak.init(e, t));
    });
    function aC(e) {
      return rv(aA, e);
    }
    let aL = n("ZodNanoID", (e, t) => {
      (tX.init(e, t), ak.init(e, t));
    });
    function aR(e) {
      return rg(aL, e);
    }
    let aB = n("ZodCUID", (e, t) => {
      (tF.init(e, t), ak.init(e, t));
    });
    function aX(e) {
      return r_(aB, e);
    }
    let aF = n("ZodCUID2", (e, t) => {
      (tJ.init(e, t), ak.init(e, t));
    });
    function aJ(e) {
      return rh(aF, e);
    }
    let aG = n("ZodULID", (e, t) => {
      (tG.init(e, t), ak.init(e, t));
    });
    function aM(e) {
      return r$(aG, e);
    }
    let aK = n("ZodXID", (e, t) => {
      (tM.init(e, t), ak.init(e, t));
    });
    function aV(e) {
      return ry(aK, e);
    }
    let aW = n("ZodKSUID", (e, t) => {
      (tK.init(e, t), ak.init(e, t));
    });
    function aq(e) {
      return rb(aW, e);
    }
    let aY = n("ZodIPv4", (e, t) => {
      (tH.init(e, t), ak.init(e, t));
    });
    function aH(e) {
      return rI(aY, e);
    }
    let aQ = n("ZodIPv6", (e, t) => {
      (tQ.init(e, t), ak.init(e, t));
    });
    function a0(e) {
      return rx(aQ, e);
    }
    let a4 = n("ZodCIDRv4", (e, t) => {
      (t0.init(e, t), ak.init(e, t));
    });
    function a6(e) {
      return rk(a4, e);
    }
    let a1 = n("ZodCIDRv6", (e, t) => {
      (t4.init(e, t), ak.init(e, t));
    });
    function a2(e) {
      return rS(a1, e);
    }
    let a9 = n("ZodBase64", (e, t) => {
      (t1.init(e, t), ak.init(e, t));
    });
    function a3(e) {
      return rw(a9, e);
    }
    let a5 = n("ZodBase64URL", (e, t) => {
      (t9.init(e, t), ak.init(e, t));
    });
    function a7(e) {
      return rU(a5, e);
    }
    let a8 = n("ZodE164", (e, t) => {
      (t3.init(e, t), ak.init(e, t));
    });
    function oe(e) {
      return rE(a8, e);
    }
    let ot = n("ZodJWT", (e, t) => {
      (t7.init(e, t), ak.init(e, t));
    });
    function oi(e) {
      return rN(ot, e);
    }
    let or = n("ZodCustomStringFormat", (e, t) => {
      (t8.init(e, t), ak.init(e, t));
    });
    function on(e, t) {
      let i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
      return nY(or, e, t, i);
    }
    function oa(e) {
      return nY(or, "hostname", n9.hostname, e);
    }
    function oo(e) {
      return nY(or, "hex", n9.hex, e);
    }
    function ou(e, t) {
      let i = t?.enc ?? "hex",
        r = `${e}_${i}`,
        n = n9[r];
      if (!n) throw Error(`Unrecognized hash format: ${r}`);
      return nY(or, r, n, t);
    }
    let os = n("ZodNumber", (e, t) => {
      (ie.init(e, t),
        ay.init(e, t),
        (e.gt = (t, i) => e.check(r3(t, i))),
        (e.gte = (t, i) => e.check(r5(t, i))),
        (e.min = (t, i) => e.check(r5(t, i))),
        (e.lt = (t, i) => e.check(r2(t, i))),
        (e.lte = (t, i) => e.check(r9(t, i))),
        (e.max = (t, i) => e.check(r9(t, i))),
        (e.int = (t) => e.check(oc(t))),
        (e.safe = (t) => e.check(oc(t))),
        (e.positive = (t) => e.check(r3(0, t))),
        (e.nonnegative = (t) => e.check(r5(0, t))),
        (e.negative = (t) => e.check(r2(0, t))),
        (e.nonpositive = (t) => e.check(r9(0, t))),
        (e.multipleOf = (t, i) => e.check(ni(t, i))),
        (e.step = (t, i) => e.check(ni(t, i))),
        (e.finite = () => e));
      let i = e._zod.bag;
      ((e.minValue = Math.max(i.minimum ?? -1 / 0, i.exclusiveMinimum ?? -1 / 0) ?? null),
        (e.maxValue = Math.min(i.maximum ?? 1 / 0, i.exclusiveMaximum ?? 1 / 0) ?? null),
        (e.isInt = (i.format ?? "").includes("int") || Number.isSafeInteger(i.multipleOf ?? 0.5)),
        (e.isFinite = !0),
        (e.format = i.format ?? null));
    });
    function ol(e) {
      return rT(os, e);
    }
    let od = n("ZodNumberFormat", (e, t) => {
      (it.init(e, t), os.init(e, t));
    });
    function oc(e) {
      return rA(od, e);
    }
    function om(e) {
      return rC(od, e);
    }
    function of(e) {
      return rL(od, e);
    }
    function op(e) {
      return rR(od, e);
    }
    function ov(e) {
      return rB(od, e);
    }
    let og = n("ZodBoolean", (e, t) => {
      (ii.init(e, t), ay.init(e, t));
    });
    function o_(e) {
      return rX(og, e);
    }
    let oh = n("ZodBigInt", (e, t) => {
      (ir.init(e, t),
        ay.init(e, t),
        (e.gte = (t, i) => e.check(r5(t, i))),
        (e.min = (t, i) => e.check(r5(t, i))),
        (e.gt = (t, i) => e.check(r3(t, i))),
        (e.gte = (t, i) => e.check(r5(t, i))),
        (e.min = (t, i) => e.check(r5(t, i))),
        (e.lt = (t, i) => e.check(r2(t, i))),
        (e.lte = (t, i) => e.check(r9(t, i))),
        (e.max = (t, i) => e.check(r9(t, i))),
        (e.positive = (t) => e.check(r3(BigInt(0), t))),
        (e.negative = (t) => e.check(r2(BigInt(0), t))),
        (e.nonpositive = (t) => e.check(r9(BigInt(0), t))),
        (e.nonnegative = (t) => e.check(r5(BigInt(0), t))),
        (e.multipleOf = (t, i) => e.check(ni(t, i))));
      let i = e._zod.bag;
      ((e.minValue = i.minimum ?? null), (e.maxValue = i.maximum ?? null), (e.format = i.format ?? null));
    });
    function o$(e) {
      return rJ(oh, e);
    }
    let oy = n("ZodBigIntFormat", (e, t) => {
      (ia.init(e, t), oh.init(e, t));
    });
    function ob(e) {
      return rM(oy, e);
    }
    function oI(e) {
      return rK(oy, e);
    }
    let ox = n("ZodSymbol", (e, t) => {
      (io.init(e, t), ay.init(e, t));
    });
    function ok(e) {
      return rV(ox, e);
    }
    let oS = n("ZodUndefined", (e, t) => {
      (iu.init(e, t), ay.init(e, t));
    });
    function ow(e) {
      return rW(oS, e);
    }
    let oU = n("ZodNull", (e, t) => {
      (is.init(e, t), ay.init(e, t));
    });
    function oE(e) {
      return rq(oU, e);
    }
    let oN = n("ZodAny", (e, t) => {
      (il.init(e, t), ay.init(e, t));
    });
    function oz() {
      return rY(oN);
    }
    let oO = n("ZodUnknown", (e, t) => {
      (id.init(e, t), ay.init(e, t));
    });
    function oP() {
      return rH(oO);
    }
    let oZ = n("ZodNever", (e, t) => {
      (ic.init(e, t), ay.init(e, t));
    });
    function oj(e) {
      return rQ(oZ, e);
    }
    let oT = n("ZodVoid", (e, t) => {
      (im.init(e, t), ay.init(e, t));
    });
    function oD(e) {
      return r0(oT, e);
    }
    let oA = n("ZodDate", (e, t) => {
      (ip.init(e, t),
        ay.init(e, t),
        (e.min = (t, i) => e.check(r5(t, i))),
        (e.max = (t, i) => e.check(r9(t, i))));
      let i = e._zod.bag;
      ((e.minDate = i.minimum ? new Date(i.minimum) : null),
        (e.maxDate = i.maximum ? new Date(i.maximum) : null));
    });
    function oC(e) {
      return r4(oA, e);
    }
    let oL = n("ZodArray", (e, t) => {
      (ig.init(e, t),
        ay.init(e, t),
        (e.element = t.element),
        (e.min = (t, i) => e.check(nu(t, i))),
        (e.nonempty = (t) => e.check(nu(1, t))),
        (e.max = (t, i) => e.check(no(t, i))),
        (e.length = (t, i) => e.check(ns(t, i))),
        (e.unwrap = () => e.element));
    });
    function oR(e, t) {
      return nI(oL, e, t);
    }
    function oB(e) {
      return o7(Object.keys(e._zod.def.shape));
    }
    let oX = n("ZodObject", (e, t) => {
      (ib.init(e, t),
        ay.init(e, t),
        n3.defineLazy(e, "shape", () => t.shape),
        (e.keyof = () => o7(Object.keys(e._zod.def.shape))),
        (e.catchall = (t) => e.clone({ ...e._zod.def, catchall: t })),
        (e.passthrough = () => e.clone({ ...e._zod.def, catchall: oP() })),
        (e.loose = () => e.clone({ ...e._zod.def, catchall: oP() })),
        (e.strict = () => e.clone({ ...e._zod.def, catchall: oj() })),
        (e.strip = () => e.clone({ ...e._zod.def, catchall: void 0 })),
        (e.extend = (t) => n3.extend(e, t)),
        (e.safeExtend = (t) => n3.safeExtend(e, t)),
        (e.merge = (t) => n3.merge(e, t)),
        (e.pick = (t) => n3.pick(e, t)),
        (e.omit = (t) => n3.omit(e, t)),
        (e.partial = function () {
          for (var t = arguments.length, i = Array(t), r = 0; r < t; r++) i[r] = arguments[r];
          return n3.partial(uo, e, i[0]);
        }),
        (e.required = function () {
          for (var t = arguments.length, i = Array(t), r = 0; r < t; r++) i[r] = arguments[r];
          return n3.required(uv, e, i[0]);
        }));
    });
    function oF(e, t) {
      return new oX({ type: "object", shape: e ?? {}, ...n3.normalizeParams(t) });
    }
    function oJ(e, t) {
      return new oX({ type: "object", shape: e, catchall: oj(), ...n3.normalizeParams(t) });
    }
    function oG(e, t) {
      return new oX({ type: "object", shape: e, catchall: oP(), ...n3.normalizeParams(t) });
    }
    let oM = n("ZodUnion", (e, t) => {
      (ix.init(e, t), ay.init(e, t), (e.options = t.options));
    });
    function oK(e, t) {
      return new oM({ type: "union", options: e, ...n3.normalizeParams(t) });
    }
    let oV = n("ZodDiscriminatedUnion", (e, t) => {
      (oM.init(e, t), ik.init(e, t));
    });
    function oW(e, t, i) {
      return new oV({ type: "union", options: t, discriminator: e, ...n3.normalizeParams(i) });
    }
    let oq = n("ZodIntersection", (e, t) => {
      (iS.init(e, t), ay.init(e, t));
    });
    function oY(e, t) {
      return new oq({ type: "intersection", left: e, right: t });
    }
    let oH = n("ZodTuple", (e, t) => {
      (iU.init(e, t), ay.init(e, t), (e.rest = (t) => e.clone({ ...e._zod.def, rest: t })));
    });
    function oQ(e, t, i) {
      let r = t instanceof tj,
        n = r ? i : t;
      return new oH({ type: "tuple", items: e, rest: r ? t : null, ...n3.normalizeParams(n) });
    }
    let o0 = n("ZodRecord", (e, t) => {
      (iN.init(e, t), ay.init(e, t), (e.keyType = t.keyType), (e.valueType = t.valueType));
    });
    function o4(e, t, i) {
      return new o0({ type: "record", keyType: e, valueType: t, ...n3.normalizeParams(i) });
    }
    function o6(e, t, i) {
      let r = z(e);
      return (
        (r._zod.values = void 0),
        new o0({ type: "record", keyType: r, valueType: t, ...n3.normalizeParams(i) })
      );
    }
    let o1 = n("ZodMap", (e, t) => {
      (iz.init(e, t), ay.init(e, t), (e.keyType = t.keyType), (e.valueType = t.valueType));
    });
    function o2(e, t, i) {
      return new o1({ type: "map", keyType: e, valueType: t, ...n3.normalizeParams(i) });
    }
    let o9 = n("ZodSet", (e, t) => {
      (iP.init(e, t),
        ay.init(e, t),
        (e.min = function () {
          for (var t = arguments.length, i = Array(t), r = 0; r < t; r++) i[r] = arguments[r];
          return e.check(nn(...i));
        }),
        (e.nonempty = (t) => e.check(nn(1, t))),
        (e.max = function () {
          for (var t = arguments.length, i = Array(t), r = 0; r < t; r++) i[r] = arguments[r];
          return e.check(nr(...i));
        }),
        (e.size = function () {
          for (var t = arguments.length, i = Array(t), r = 0; r < t; r++) i[r] = arguments[r];
          return e.check(na(...i));
        }));
    });
    function o3(e, t) {
      return new o9({ type: "set", valueType: e, ...n3.normalizeParams(t) });
    }
    let o5 = n("ZodEnum", (e, t) => {
      (ij.init(e, t), ay.init(e, t), (e.enum = t.entries), (e.options = Object.values(t.entries)));
      let i = new Set(Object.keys(t.entries));
      ((e.extract = (e, r) => {
        let n = {};
        for (let r of e)
          if (i.has(r)) n[r] = t.entries[r];
          else throw Error(`Key ${r} not found in enum`);
        return new o5({ ...t, checks: [], ...n3.normalizeParams(r), entries: n });
      }),
        (e.exclude = (e, r) => {
          let n = { ...t.entries };
          for (let t of e)
            if (i.has(t)) delete n[t];
            else throw Error(`Key ${t} not found in enum`);
          return new o5({ ...t, checks: [], ...n3.normalizeParams(r), entries: n });
        }));
    });
    function o7(e, t) {
      return new o5({
        type: "enum",
        entries: Array.isArray(e) ? Object.fromEntries(e.map((e) => [e, e])) : e,
        ...n3.normalizeParams(t),
      });
    }
    function o8(e, t) {
      return new o5({ type: "enum", entries: e, ...n3.normalizeParams(t) });
    }
    let ue = n("ZodLiteral", (e, t) => {
      (iT.init(e, t),
        ay.init(e, t),
        (e.values = new Set(t.values)),
        Object.defineProperty(e, "value", {
          get() {
            if (t.values.length > 1)
              throw Error("This schema contains multiple valid literal values. Use `.values` instead.");
            return t.values[0];
          },
        }));
    });
    function ut(e, t) {
      return new ue({ type: "literal", values: Array.isArray(e) ? e : [e], ...n3.normalizeParams(t) });
    }
    let ui = n("ZodFile", (e, t) => {
      (iD.init(e, t),
        ay.init(e, t),
        (e.min = (t, i) => e.check(nn(t, i))),
        (e.max = (t, i) => e.check(nr(t, i))),
        (e.mime = (t, i) => e.check(ng(Array.isArray(t) ? t : [t], i))));
    });
    function ur(e) {
      return nZ(ui, e);
    }
    let un = n("ZodTransform", (e, t) => {
      (iA.init(e, t),
        ay.init(e, t),
        (e._zod.parse = (i, r) => {
          if ("backward" === r.direction) throw new u(e.constructor.name);
          i.addIssue = (r) => {
            "string" == typeof r
              ? i.issues.push(n3.issue(r, i.value, t))
              : (r.fatal && (r.continue = !1),
                r.code ?? (r.code = "custom"),
                r.input ?? (r.input = i.value),
                r.inst ?? (r.inst = e),
                i.issues.push(n3.issue(r)));
          };
          let n = t.transform(i.value, i);
          return n instanceof Promise ? n.then((e) => ((i.value = e), i)) : ((i.value = n), i);
        }));
    });
    function ua(e) {
      return new un({ type: "transform", transform: e });
    }
    let uo = n("ZodOptional", (e, t) => {
      (iL.init(e, t), ay.init(e, t), (e.unwrap = () => e._zod.def.innerType));
    });
    function uu(e) {
      return new uo({ type: "optional", innerType: e });
    }
    let us = n("ZodNullable", (e, t) => {
      (iR.init(e, t), ay.init(e, t), (e.unwrap = () => e._zod.def.innerType));
    });
    function ul(e) {
      return new us({ type: "nullable", innerType: e });
    }
    function ud(e) {
      return uu(ul(e));
    }
    let uc = n("ZodDefault", (e, t) => {
      (iB.init(e, t), ay.init(e, t), (e.unwrap = () => e._zod.def.innerType), (e.removeDefault = e.unwrap));
    });
    function um(e, t) {
      return new uc({
        type: "default",
        innerType: e,
        get defaultValue() {
          return "function" == typeof t ? t() : n3.shallowClone(t);
        },
      });
    }
    let uf = n("ZodPrefault", (e, t) => {
      (iF.init(e, t), ay.init(e, t), (e.unwrap = () => e._zod.def.innerType));
    });
    function up(e, t) {
      return new uf({
        type: "prefault",
        innerType: e,
        get defaultValue() {
          return "function" == typeof t ? t() : n3.shallowClone(t);
        },
      });
    }
    let uv = n("ZodNonOptional", (e, t) => {
      (iJ.init(e, t), ay.init(e, t), (e.unwrap = () => e._zod.def.innerType));
    });
    function ug(e, t) {
      return new uv({ type: "nonoptional", innerType: e, ...n3.normalizeParams(t) });
    }
    let u_ = n("ZodSuccess", (e, t) => {
      (iM.init(e, t), ay.init(e, t), (e.unwrap = () => e._zod.def.innerType));
    });
    function uh(e) {
      return new u_({ type: "success", innerType: e });
    }
    let u$ = n("ZodCatch", (e, t) => {
      (iK.init(e, t), ay.init(e, t), (e.unwrap = () => e._zod.def.innerType), (e.removeCatch = e.unwrap));
    });
    function uy(e, t) {
      return new u$({ type: "catch", innerType: e, catchValue: "function" == typeof t ? t : () => t });
    }
    let ub = n("ZodNaN", (e, t) => {
      (iV.init(e, t), ay.init(e, t));
    });
    function uI(e) {
      return r1(ub, e);
    }
    let ux = n("ZodPipe", (e, t) => {
      (iW.init(e, t), ay.init(e, t), (e.in = t.in), (e.out = t.out));
    });
    function uk(e, t) {
      return new ux({ type: "pipe", in: e, out: t });
    }
    let uS = n("ZodCodec", (e, t) => {
      (ux.init(e, t), iY.init(e, t));
    });
    function uw(e, t, i) {
      return new uS({ type: "pipe", in: e, out: t, transform: i.decode, reverseTransform: i.encode });
    }
    let uU = n("ZodReadonly", (e, t) => {
      (i0.init(e, t), ay.init(e, t), (e.unwrap = () => e._zod.def.innerType));
    });
    function uE(e) {
      return new uU({ type: "readonly", innerType: e });
    }
    let uN = n("ZodTemplateLiteral", (e, t) => {
      (i6.init(e, t), ay.init(e, t));
    });
    function uz(e, t) {
      return new uN({ type: "template_literal", parts: e, ...n3.normalizeParams(t) });
    }
    let uO = n("ZodLazy", (e, t) => {
      (i9.init(e, t), ay.init(e, t), (e.unwrap = () => e._zod.def.getter()));
    });
    function uP(e) {
      return new uO({ type: "lazy", getter: e });
    }
    let uZ = n("ZodPromise", (e, t) => {
      (i2.init(e, t), ay.init(e, t), (e.unwrap = () => e._zod.def.innerType));
    });
    function uj(e) {
      return new uZ({ type: "promise", innerType: e });
    }
    let uT = n("ZodFunction", (e, t) => {
      (i1.init(e, t), ay.init(e, t));
    });
    function uD(e) {
      return new uT({
        type: "function",
        input: Array.isArray(e?.input) ? oQ(e?.input) : (e?.input ?? oR(oP())),
        output: e?.output ?? oP(),
      });
    }
    let uA = n("ZodCustom", (e, t) => {
      (i3.init(e, t), ay.init(e, t));
    });
    function uC(e) {
      let t = new ts({ check: "custom" });
      return ((t._zod.check = e), t);
    }
    function uL(e, t) {
      return nM(uA, e ?? (() => !0), t);
    }
    function uR(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
      return nK(uA, e, t);
    }
    function uB(e) {
      return nV(e);
    }
    function uX(e) {
      let t =
          arguments.length > 1 && void 0 !== arguments[1]
            ? arguments[1]
            : { error: `Input not instance of ${e.name}` },
        i = new uA({
          type: "custom",
          check: "custom",
          fn: (t) => t instanceof e,
          abort: !0,
          ...n3.normalizeParams(t),
        });
      return ((i._zod.bag.Class = e), i);
    }
    let uF = function () {
      for (var e = arguments.length, t = Array(e), i = 0; i < e; i++) t[i] = arguments[i];
      return nq({ Codec: uS, Boolean: og, String: aI }, ...t);
    };
    function uJ(e) {
      let t = uP(() => oK([ax(e), ol(), o_(), oE(), oR(t), o4(ax(), t)]));
      return t;
    }
    function uG(e, t) {
      return uk(ua(e), t);
    }
    let uM = {
      invalid_type: "invalid_type",
      too_big: "too_big",
      too_small: "too_small",
      invalid_format: "invalid_format",
      not_multiple_of: "not_multiple_of",
      unrecognized_keys: "unrecognized_keys",
      invalid_union: "invalid_union",
      invalid_key: "invalid_key",
      invalid_element: "invalid_element",
      invalid_value: "invalid_value",
      custom: "custom",
    };
    function uK(e) {
      l({ customError: e });
    }
    function uV() {
      return l().customError;
    }
    (t || (t = {}),
      e.s(
        ["ZodFirstPartyTypeKind", 0, t, "ZodIssueCode", 0, uM, "getErrorMap", 0, uV, "setErrorMap", 0, uK],
        306034,
      ),
      e.s(
        [
          "bigint",
          0,
          function (e) {
            return rG(oh, e);
          },
          "boolean",
          0,
          function (e) {
            return rF(og, e);
          },
          "date",
          0,
          function (e) {
            return r6(oA, e);
          },
          "number",
          0,
          function (e) {
            return rD(os, e);
          },
          "string",
          0,
          function (e) {
            return ru(aI, e);
          },
        ],
        313657,
      ),
      l(i8()),
      e.s([], 298821),
      e.i(298821),
      e.i(292135),
      e.i(197753),
      e.i(803108),
      e.i(374969),
      e.i(676094),
      e.s(
        [
          "$ZodAny",
          0,
          il,
          "$ZodArray",
          0,
          ig,
          "$ZodBase64",
          0,
          t1,
          "$ZodBase64URL",
          0,
          t9,
          "$ZodBigInt",
          0,
          ir,
          "$ZodBigIntFormat",
          0,
          ia,
          "$ZodBoolean",
          0,
          ii,
          "$ZodCIDRv4",
          0,
          t0,
          "$ZodCIDRv6",
          0,
          t4,
          "$ZodCUID",
          0,
          tF,
          "$ZodCUID2",
          0,
          tJ,
          "$ZodCatch",
          0,
          iK,
          "$ZodCodec",
          0,
          iY,
          "$ZodCustom",
          0,
          i3,
          "$ZodCustomStringFormat",
          0,
          t8,
          "$ZodDate",
          0,
          ip,
          "$ZodDefault",
          0,
          iB,
          "$ZodDiscriminatedUnion",
          0,
          ik,
          "$ZodE164",
          0,
          t3,
          "$ZodEmail",
          0,
          tL,
          "$ZodEmoji",
          0,
          tB,
          "$ZodEnum",
          0,
          ij,
          "$ZodFile",
          0,
          iD,
          "$ZodFunction",
          0,
          i1,
          "$ZodGUID",
          0,
          tA,
          "$ZodIPv4",
          0,
          tH,
          "$ZodIPv6",
          0,
          tQ,
          "$ZodISODate",
          0,
          tW,
          "$ZodISODateTime",
          0,
          tV,
          "$ZodISODuration",
          0,
          tY,
          "$ZodISOTime",
          0,
          tq,
          "$ZodIntersection",
          0,
          iS,
          "$ZodJWT",
          0,
          t7,
          "$ZodKSUID",
          0,
          tK,
          "$ZodLazy",
          0,
          i9,
          "$ZodLiteral",
          0,
          iT,
          "$ZodMap",
          0,
          iz,
          "$ZodNaN",
          0,
          iV,
          "$ZodNanoID",
          0,
          tX,
          "$ZodNever",
          0,
          ic,
          "$ZodNonOptional",
          0,
          iJ,
          "$ZodNull",
          0,
          is,
          "$ZodNullable",
          0,
          iR,
          "$ZodNumber",
          0,
          ie,
          "$ZodNumberFormat",
          0,
          it,
          "$ZodObject",
          0,
          iy,
          "$ZodObjectJIT",
          0,
          ib,
          "$ZodOptional",
          0,
          iL,
          "$ZodPipe",
          0,
          iW,
          "$ZodPrefault",
          0,
          iF,
          "$ZodPromise",
          0,
          i2,
          "$ZodReadonly",
          0,
          i0,
          "$ZodRecord",
          0,
          iN,
          "$ZodSet",
          0,
          iP,
          "$ZodString",
          0,
          tT,
          "$ZodStringFormat",
          0,
          tD,
          "$ZodSuccess",
          0,
          iM,
          "$ZodSymbol",
          0,
          io,
          "$ZodTemplateLiteral",
          0,
          i6,
          "$ZodTransform",
          0,
          iA,
          "$ZodTuple",
          0,
          iU,
          "$ZodType",
          0,
          tj,
          "$ZodULID",
          0,
          tG,
          "$ZodURL",
          0,
          tR,
          "$ZodUUID",
          0,
          tC,
          "$ZodUndefined",
          0,
          iu,
          "$ZodUnion",
          0,
          ix,
          "$ZodUnknown",
          0,
          id,
          "$ZodVoid",
          0,
          im,
          "$ZodXID",
          0,
          tM,
          "clone",
          0,
          z,
          "isValidBase64",
          0,
          t6,
          "isValidBase64URL",
          0,
          t2,
          "isValidJWT",
          0,
          t5,
        ],
        532952,
      ),
      e.i(532952),
      e.i(355605),
      e.i(398477));
    var uW = n3,
      uq = n9;
    (e.i(543365),
      e.s(
        [
          "ar",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "حرف", verb: "أن يحوي" },
                  file: { unit: "بايت", verb: "أن يحوي" },
                  array: { unit: "عنصر", verb: "أن يحوي" },
                  set: { unit: "عنصر", verb: "أن يحوي" },
                }),
                (t = {
                  regex: "مدخل",
                  email: "بريد إلكتروني",
                  url: "رابط",
                  emoji: "إيموجي",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "تاريخ ووقت بمعيار ISO",
                  date: "تاريخ بمعيار ISO",
                  time: "وقت بمعيار ISO",
                  duration: "مدة بمعيار ISO",
                  ipv4: "عنوان IPv4",
                  ipv6: "عنوان IPv6",
                  cidrv4: "مدى عناوين بصيغة IPv4",
                  cidrv6: "مدى عناوين بصيغة IPv6",
                  base64: "نَص بترميز base64-encoded",
                  base64url: "نَص بترميز base64url-encoded",
                  json_string: "نَص على هيئة JSON",
                  e164: "رقم هاتف بمعيار E.164",
                  jwt: "JWT",
                  template_literal: "مدخل",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `مدخلات غير مقبولة: يفترض إدخال ${i.expected}، ولكن تم إدخال ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "number";
                          case "object":
                            if (Array.isArray(e)) return "array";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `مدخلات غير مقبولة: يفترض إدخال ${P(i.values[0])}`;
                      return `اختيار غير مقبول: يتوقع انتقاء أحد هذه الخيارات: ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return ` أكبر من اللازم: يفترض أن تكون ${i.origin ?? "القيمة"} ${t} ${i.maximum.toString()} ${r.unit ?? "عنصر"}`;
                      return `أكبر من اللازم: يفترض أن تكون ${i.origin ?? "القيمة"} ${t} ${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `أصغر من اللازم: يفترض لـ ${i.origin} أن يكون ${t} ${i.minimum.toString()} ${r.unit}`;
                      return `أصغر من اللازم: يفترض لـ ${i.origin} أن يكون ${t} ${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format) return `نَص غير مقبول: يجب أن يبدأ بـ "${i.prefix}"`;
                      if ("ends_with" === i.format) return `نَص غير مقبول: يجب أن ينتهي بـ "${i.suffix}"`;
                      if ("includes" === i.format) return `نَص غير مقبول: يجب أن يتضمَّن "${i.includes}"`;
                      if ("regex" === i.format) return `نَص غير مقبول: يجب أن يطابق النمط ${i.pattern}`;
                      return `${t[i.format] ?? i.format} غير مقبول`;
                    case "not_multiple_of":
                      return `رقم غير مقبول: يجب أن يكون من مضاعفات ${i.divisor}`;
                    case "unrecognized_keys":
                      return `معرف${i.keys.length > 1 ? "ات" : ""} غريب${i.keys.length > 1 ? "ة" : ""}: ${c(i.keys, "، ")}`;
                    case "invalid_key":
                      return `معرف غير مقبول في ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "مدخل غير مقبول";
                    case "invalid_element":
                      return `مدخل غير مقبول في ${i.origin}`;
                  }
                }),
            };
          },
          "az",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "simvol", verb: "olmalıdır" },
                  file: { unit: "bayt", verb: "olmalıdır" },
                  array: { unit: "element", verb: "olmalıdır" },
                  set: { unit: "element", verb: "olmalıdır" },
                }),
                (t = {
                  regex: "input",
                  email: "email address",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO datetime",
                  date: "ISO date",
                  time: "ISO time",
                  duration: "ISO duration",
                  ipv4: "IPv4 address",
                  ipv6: "IPv6 address",
                  cidrv4: "IPv4 range",
                  cidrv6: "IPv6 range",
                  base64: "base64-encoded string",
                  base64url: "base64url-encoded string",
                  json_string: "JSON string",
                  e164: "E.164 number",
                  jwt: "JWT",
                  template_literal: "input",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Yanlış dəyər: g\xf6zlənilən ${i.expected}, daxil olan ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "number";
                          case "object":
                            if (Array.isArray(e)) return "array";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `Yanlış dəyər: g\xf6zlənilən ${P(i.values[0])}`;
                      return `Yanlış se\xe7im: aşağıdakılardan biri olmalıdır: ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `\xc7ox b\xf6y\xfck: g\xf6zlənilən ${i.origin ?? "dəyər"} ${t}${i.maximum.toString()} ${r.unit ?? "element"}`;
                      return `\xc7ox b\xf6y\xfck: g\xf6zlənilən ${i.origin ?? "dəyər"} ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `\xc7ox ki\xe7ik: g\xf6zlənilən ${i.origin} ${t}${i.minimum.toString()} ${r.unit}`;
                      return `\xc7ox ki\xe7ik: g\xf6zlənilən ${i.origin} ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format) return `Yanlış mətn: "${i.prefix}" ilə başlamalıdır`;
                      if ("ends_with" === i.format) return `Yanlış mətn: "${i.suffix}" ilə bitməlidir`;
                      if ("includes" === i.format) return `Yanlış mətn: "${i.includes}" daxil olmalıdır`;
                      if ("regex" === i.format) return `Yanlış mətn: ${i.pattern} şablonuna uyğun olmalıdır`;
                      return `Yanlış ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `Yanlış ədəd: ${i.divisor} ilə b\xf6l\xfcnə bilən olmalıdır`;
                    case "unrecognized_keys":
                      return `Tanınmayan a\xe7ar${i.keys.length > 1 ? "lar" : ""}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `${i.origin} daxilində yanlış a\xe7ar`;
                    case "invalid_union":
                    default:
                      return "Yanlış dəyər";
                    case "invalid_element":
                      return `${i.origin} daxilində yanlış dəyər`;
                  }
                }),
            };
          },
          "be",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: { one: "сімвал", few: "сімвалы", many: "сімвалаў" }, verb: "мець" },
                  array: { unit: { one: "элемент", few: "элементы", many: "элементаў" }, verb: "мець" },
                  set: { unit: { one: "элемент", few: "элементы", many: "элементаў" }, verb: "мець" },
                  file: { unit: { one: "байт", few: "байты", many: "байтаў" }, verb: "мець" },
                }),
                (t = {
                  regex: "увод",
                  email: "email адрас",
                  url: "URL",
                  emoji: "эмодзі",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO дата і час",
                  date: "ISO дата",
                  time: "ISO час",
                  duration: "ISO працягласць",
                  ipv4: "IPv4 адрас",
                  ipv6: "IPv6 адрас",
                  cidrv4: "IPv4 дыяпазон",
                  cidrv6: "IPv6 дыяпазон",
                  base64: "радок у фармаце base64",
                  base64url: "радок у фармаце base64url",
                  json_string: "JSON радок",
                  e164: "нумар E.164",
                  jwt: "JWT",
                  template_literal: "увод",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Няправільны ўвод: чакаўся ${i.expected}, атрымана ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "лік";
                          case "object":
                            if (Array.isArray(e)) return "масіў";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `Няправільны ўвод: чакалася ${P(i.values[0])}`;
                      return `Няправільны варыянт: чакаўся адзін з ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r) {
                        let e = i7(Number(i.maximum), r.unit.one, r.unit.few, r.unit.many);
                        return `Занадта вялікі: чакалася, што ${i.origin ?? "значэнне"} павінна ${r.verb} ${t}${i.maximum.toString()} ${e}`;
                      }
                      return `Занадта вялікі: чакалася, што ${i.origin ?? "значэнне"} павінна быць ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r) {
                        let e = i7(Number(i.minimum), r.unit.one, r.unit.few, r.unit.many);
                        return `Занадта малы: чакалася, што ${i.origin} павінна ${r.verb} ${t}${i.minimum.toString()} ${e}`;
                      }
                      return `Занадта малы: чакалася, што ${i.origin} павінна быць ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `Няправільны радок: павінен пачынацца з "${i.prefix}"`;
                      if ("ends_with" === i.format)
                        return `Няправільны радок: павінен заканчвацца на "${i.suffix}"`;
                      if ("includes" === i.format)
                        return `Няправільны радок: павінен змяшчаць "${i.includes}"`;
                      if ("regex" === i.format)
                        return `Няправільны радок: павінен адпавядаць шаблону ${i.pattern}`;
                      return `Няправільны ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `Няправільны лік: павінен быць кратным ${i.divisor}`;
                    case "unrecognized_keys":
                      return `Нераспазнаны ${i.keys.length > 1 ? "ключы" : "ключ"}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Няправільны ключ у ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Няправільны ўвод";
                    case "invalid_element":
                      return `Няправільнае значэнне ў ${i.origin}`;
                  }
                }),
            };
          },
          "bg",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "символа", verb: "да съдържа" },
                  file: { unit: "байта", verb: "да съдържа" },
                  array: { unit: "елемента", verb: "да съдържа" },
                  set: { unit: "елемента", verb: "да съдържа" },
                }),
                (t = {
                  regex: "вход",
                  email: "имейл адрес",
                  url: "URL",
                  emoji: "емоджи",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO време",
                  date: "ISO дата",
                  time: "ISO време",
                  duration: "ISO продължителност",
                  ipv4: "IPv4 адрес",
                  ipv6: "IPv6 адрес",
                  cidrv4: "IPv4 диапазон",
                  cidrv6: "IPv6 диапазон",
                  base64: "base64-кодиран низ",
                  base64url: "base64url-кодиран низ",
                  json_string: "JSON низ",
                  e164: "E.164 номер",
                  jwt: "JWT",
                  template_literal: "вход",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Невалиден вход: очакван ${i.expected}, получен ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "число";
                          case "object":
                            if (Array.isArray(e)) return "масив";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `Невалиден вход: очакван ${P(i.values[0])}`;
                      return `Невалидна опция: очаквано едно от ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Твърде голямо: очаква се ${i.origin ?? "стойност"} да съдържа ${t}${i.maximum.toString()} ${r.unit ?? "елемента"}`;
                      return `Твърде голямо: очаква се ${i.origin ?? "стойност"} да бъде ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Твърде малко: очаква се ${i.origin} да съдържа ${t}${i.minimum.toString()} ${r.unit}`;
                      return `Твърде малко: очаква се ${i.origin} да бъде ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format": {
                      if ("starts_with" === i.format)
                        return `Невалиден низ: трябва да започва с "${i.prefix}"`;
                      if ("ends_with" === i.format)
                        return `Невалиден низ: трябва да завършва с "${i.suffix}"`;
                      if ("includes" === i.format) return `Невалиден низ: трябва да включва "${i.includes}"`;
                      if ("regex" === i.format) return `Невалиден низ: трябва да съвпада с ${i.pattern}`;
                      let e = "Невалиден";
                      return (
                        "emoji" === i.format && (e = "Невалидно"),
                        "datetime" === i.format && (e = "Невалидно"),
                        "date" === i.format && (e = "Невалидна"),
                        "time" === i.format && (e = "Невалидно"),
                        "duration" === i.format && (e = "Невалидна"),
                        `${e} ${t[i.format] ?? i.format}`
                      );
                    }
                    case "not_multiple_of":
                      return `Невалидно число: трябва да бъде кратно на ${i.divisor}`;
                    case "unrecognized_keys":
                      return `Неразпознат${i.keys.length > 1 ? "и" : ""} ключ${i.keys.length > 1 ? "ове" : ""}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Невалиден ключ в ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Невалиден вход";
                    case "invalid_element":
                      return `Невалидна стойност в ${i.origin}`;
                  }
                }),
            };
          },
          "ca",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "caràcters", verb: "contenir" },
                  file: { unit: "bytes", verb: "contenir" },
                  array: { unit: "elements", verb: "contenir" },
                  set: { unit: "elements", verb: "contenir" },
                }),
                (t = {
                  regex: "entrada",
                  email: "adreça electrònica",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "data i hora ISO",
                  date: "data ISO",
                  time: "hora ISO",
                  duration: "durada ISO",
                  ipv4: "adreça IPv4",
                  ipv6: "adreça IPv6",
                  cidrv4: "rang IPv4",
                  cidrv6: "rang IPv6",
                  base64: "cadena codificada en base64",
                  base64url: "cadena codificada en base64url",
                  json_string: "cadena JSON",
                  e164: "número E.164",
                  jwt: "JWT",
                  template_literal: "entrada",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Tipus inv\xe0lid: s'esperava ${i.expected}, s'ha rebut ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "number";
                          case "object":
                            if (Array.isArray(e)) return "array";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `Valor inv\xe0lid: s'esperava ${P(i.values[0])}`;
                      return `Opci\xf3 inv\xe0lida: s'esperava una de ${c(i.values, " o ")}`;
                    case "too_big": {
                      let t = i.inclusive ? "com a màxim" : "menys de",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Massa gran: s'esperava que ${i.origin ?? "el valor"} contingu\xe9s ${t} ${i.maximum.toString()} ${r.unit ?? "elements"}`;
                      return `Massa gran: s'esperava que ${i.origin ?? "el valor"} fos ${t} ${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? "com a mínim" : "més de",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Massa petit: s'esperava que ${i.origin} contingu\xe9s ${t} ${i.minimum.toString()} ${r.unit}`;
                      return `Massa petit: s'esperava que ${i.origin} fos ${t} ${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `Format inv\xe0lid: ha de comen\xe7ar amb "${i.prefix}"`;
                      if ("ends_with" === i.format) return `Format inv\xe0lid: ha d'acabar amb "${i.suffix}"`;
                      if ("includes" === i.format) return `Format inv\xe0lid: ha d'incloure "${i.includes}"`;
                      if ("regex" === i.format)
                        return `Format inv\xe0lid: ha de coincidir amb el patr\xf3 ${i.pattern}`;
                      return `Format inv\xe0lid per a ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `N\xfamero inv\xe0lid: ha de ser m\xfaltiple de ${i.divisor}`;
                    case "unrecognized_keys":
                      return `Clau${i.keys.length > 1 ? "s" : ""} no reconeguda${i.keys.length > 1 ? "s" : ""}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Clau inv\xe0lida a ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Entrada invàlida";
                    case "invalid_element":
                      return `Element inv\xe0lid a ${i.origin}`;
                  }
                }),
            };
          },
          "cs",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "znaků", verb: "mít" },
                  file: { unit: "bajtů", verb: "mít" },
                  array: { unit: "prvků", verb: "mít" },
                  set: { unit: "prvků", verb: "mít" },
                }),
                (t = {
                  regex: "regulární výraz",
                  email: "e-mailová adresa",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "datum a čas ve formátu ISO",
                  date: "datum ve formátu ISO",
                  time: "čas ve formátu ISO",
                  duration: "doba trvání ISO",
                  ipv4: "IPv4 adresa",
                  ipv6: "IPv6 adresa",
                  cidrv4: "rozsah IPv4",
                  cidrv6: "rozsah IPv6",
                  base64: "řetězec zakódovaný ve formátu base64",
                  base64url: "řetězec zakódovaný ve formátu base64url",
                  json_string: "řetězec ve formátu JSON",
                  e164: "číslo E.164",
                  jwt: "JWT",
                  template_literal: "vstup",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Neplatn\xfd vstup: oček\xe1v\xe1no ${i.expected}, obdrženo ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "číslo";
                          case "string":
                            return "řetězec";
                          case "boolean":
                            return "boolean";
                          case "bigint":
                            return "bigint";
                          case "function":
                            return "funkce";
                          case "symbol":
                            return "symbol";
                          case "undefined":
                            return "undefined";
                          case "object":
                            if (Array.isArray(e)) return "pole";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length)
                        return `Neplatn\xfd vstup: oček\xe1v\xe1no ${P(i.values[0])}`;
                      return `Neplatn\xe1 možnost: oček\xe1v\xe1na jedna z hodnot ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Hodnota je př\xedliš velk\xe1: ${i.origin ?? "hodnota"} mus\xed m\xedt ${t}${i.maximum.toString()} ${r.unit ?? "prvků"}`;
                      return `Hodnota je př\xedliš velk\xe1: ${i.origin ?? "hodnota"} mus\xed b\xfdt ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Hodnota je př\xedliš mal\xe1: ${i.origin ?? "hodnota"} mus\xed m\xedt ${t}${i.minimum.toString()} ${r.unit ?? "prvků"}`;
                      return `Hodnota je př\xedliš mal\xe1: ${i.origin ?? "hodnota"} mus\xed b\xfdt ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `Neplatn\xfd řetězec: mus\xed zač\xednat na "${i.prefix}"`;
                      if ("ends_with" === i.format)
                        return `Neplatn\xfd řetězec: mus\xed končit na "${i.suffix}"`;
                      if ("includes" === i.format)
                        return `Neplatn\xfd řetězec: mus\xed obsahovat "${i.includes}"`;
                      if ("regex" === i.format)
                        return `Neplatn\xfd řetězec: mus\xed odpov\xeddat vzoru ${i.pattern}`;
                      return `Neplatn\xfd form\xe1t ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `Neplatn\xe9 č\xedslo: mus\xed b\xfdt n\xe1sobkem ${i.divisor}`;
                    case "unrecognized_keys":
                      return `Nezn\xe1m\xe9 kl\xedče: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Neplatn\xfd kl\xedč v ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Neplatný vstup";
                    case "invalid_element":
                      return `Neplatn\xe1 hodnota v ${i.origin}`;
                  }
                }),
            };
          },
          "da",
          0,
          function () {
            let e, t, i;
            return {
              localeError:
                ((e = {
                  string: { unit: "tegn", verb: "havde" },
                  file: { unit: "bytes", verb: "havde" },
                  array: { unit: "elementer", verb: "indeholdt" },
                  set: { unit: "elementer", verb: "indeholdt" },
                }),
                (t = {
                  string: "streng",
                  number: "tal",
                  boolean: "boolean",
                  array: "liste",
                  object: "objekt",
                  set: "sæt",
                  file: "fil",
                }),
                (i = {
                  regex: "input",
                  email: "e-mailadresse",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO dato- og klokkeslæt",
                  date: "ISO-dato",
                  time: "ISO-klokkeslæt",
                  duration: "ISO-varighed",
                  ipv4: "IPv4-område",
                  ipv6: "IPv6-område",
                  cidrv4: "IPv4-spektrum",
                  cidrv6: "IPv6-spektrum",
                  base64: "base64-kodet streng",
                  base64url: "base64url-kodet streng",
                  json_string: "JSON-streng",
                  e164: "E.164-nummer",
                  jwt: "JWT",
                  template_literal: "input",
                }),
                (r) => {
                  var n, a, o, u;
                  switch (r.code) {
                    case "invalid_type":
                      return `Ugyldigt input: forventede ${t[(n = r.expected)] ?? n}, fik ${
                        t[
                          (a = ((e) => {
                            let t = typeof e;
                            switch (t) {
                              case "number":
                                return Number.isNaN(e) ? "NaN" : "tal";
                              case "object":
                                if (Array.isArray(e)) return "liste";
                                if (null === e) return "null";
                                if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                                  return e.constructor.name;
                                return "objekt";
                            }
                            return t;
                          })(r.input))
                        ] ?? a
                      }`;
                    case "invalid_value":
                      if (1 === r.values.length) return `Ugyldig v\xe6rdi: forventede ${P(r.values[0])}`;
                      return `Ugyldigt valg: forventede en af f\xf8lgende ${c(r.values, "|")}`;
                    case "too_big": {
                      let i = r.inclusive ? "<=" : "<",
                        n = e[r.origin] ?? null,
                        a = t[(o = r.origin)] ?? o;
                      if (n)
                        return `For stor: forventede ${a ?? "value"} ${n.verb} ${i} ${r.maximum.toString()} ${n.unit ?? "elementer"}`;
                      return `For stor: forventede ${a ?? "value"} havde ${i} ${r.maximum.toString()}`;
                    }
                    case "too_small": {
                      let i = r.inclusive ? ">=" : ">",
                        n = e[r.origin] ?? null,
                        a = t[(u = r.origin)] ?? u;
                      if (n)
                        return `For lille: forventede ${a} ${n.verb} ${i} ${r.minimum.toString()} ${n.unit}`;
                      return `For lille: forventede ${a} havde ${i} ${r.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === r.format) return `Ugyldig streng: skal starte med "${r.prefix}"`;
                      if ("ends_with" === r.format) return `Ugyldig streng: skal ende med "${r.suffix}"`;
                      if ("includes" === r.format) return `Ugyldig streng: skal indeholde "${r.includes}"`;
                      if ("regex" === r.format)
                        return `Ugyldig streng: skal matche m\xf8nsteret ${r.pattern}`;
                      return `Ugyldig ${i[r.format] ?? r.format}`;
                    case "not_multiple_of":
                      return `Ugyldigt tal: skal v\xe6re deleligt med ${r.divisor}`;
                    case "unrecognized_keys":
                      return `${r.keys.length > 1 ? "Ukendte nøgler" : "Ukendt nøgle"}: ${c(r.keys, ", ")}`;
                    case "invalid_key":
                      return `Ugyldig n\xf8gle i ${r.origin}`;
                    case "invalid_union":
                      return "Ugyldigt input: matcher ingen af de tilladte typer";
                    case "invalid_element":
                      return `Ugyldig v\xe6rdi i ${r.origin}`;
                    default:
                      return "Ugyldigt input";
                  }
                }),
            };
          },
          "de",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "Zeichen", verb: "zu haben" },
                  file: { unit: "Bytes", verb: "zu haben" },
                  array: { unit: "Elemente", verb: "zu haben" },
                  set: { unit: "Elemente", verb: "zu haben" },
                }),
                (t = {
                  regex: "Eingabe",
                  email: "E-Mail-Adresse",
                  url: "URL",
                  emoji: "Emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO-Datum und -Uhrzeit",
                  date: "ISO-Datum",
                  time: "ISO-Uhrzeit",
                  duration: "ISO-Dauer",
                  ipv4: "IPv4-Adresse",
                  ipv6: "IPv6-Adresse",
                  cidrv4: "IPv4-Bereich",
                  cidrv6: "IPv6-Bereich",
                  base64: "Base64-codierter String",
                  base64url: "Base64-URL-codierter String",
                  json_string: "JSON-String",
                  e164: "E.164-Nummer",
                  jwt: "JWT",
                  template_literal: "Eingabe",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Ung\xfcltige Eingabe: erwartet ${i.expected}, erhalten ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "Zahl";
                          case "object":
                            if (Array.isArray(e)) return "Array";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `Ung\xfcltige Eingabe: erwartet ${P(i.values[0])}`;
                      return `Ung\xfcltige Option: erwartet eine von ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Zu gro\xdf: erwartet, dass ${i.origin ?? "Wert"} ${t}${i.maximum.toString()} ${r.unit ?? "Elemente"} hat`;
                      return `Zu gro\xdf: erwartet, dass ${i.origin ?? "Wert"} ${t}${i.maximum.toString()} ist`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Zu klein: erwartet, dass ${i.origin} ${t}${i.minimum.toString()} ${r.unit} hat`;
                      return `Zu klein: erwartet, dass ${i.origin} ${t}${i.minimum.toString()} ist`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `Ung\xfcltiger String: muss mit "${i.prefix}" beginnen`;
                      if ("ends_with" === i.format)
                        return `Ung\xfcltiger String: muss mit "${i.suffix}" enden`;
                      if ("includes" === i.format)
                        return `Ung\xfcltiger String: muss "${i.includes}" enthalten`;
                      if ("regex" === i.format)
                        return `Ung\xfcltiger String: muss dem Muster ${i.pattern} entsprechen`;
                      return `Ung\xfcltig: ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `Ung\xfcltige Zahl: muss ein Vielfaches von ${i.divisor} sein`;
                    case "unrecognized_keys":
                      return `${i.keys.length > 1 ? "Unbekannte Schlüssel" : "Unbekannter Schlüssel"}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Ung\xfcltiger Schl\xfcssel in ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Ungültige Eingabe";
                    case "invalid_element":
                      return `Ung\xfcltiger Wert in ${i.origin}`;
                  }
                }),
            };
          },
          "en",
          0,
          i8,
          "eo",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "karaktrojn", verb: "havi" },
                  file: { unit: "bajtojn", verb: "havi" },
                  array: { unit: "elementojn", verb: "havi" },
                  set: { unit: "elementojn", verb: "havi" },
                }),
                (t = {
                  regex: "enigo",
                  email: "retadreso",
                  url: "URL",
                  emoji: "emoĝio",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO-datotempo",
                  date: "ISO-dato",
                  time: "ISO-tempo",
                  duration: "ISO-daŭro",
                  ipv4: "IPv4-adreso",
                  ipv6: "IPv6-adreso",
                  cidrv4: "IPv4-rango",
                  cidrv6: "IPv6-rango",
                  base64: "64-ume kodita karaktraro",
                  base64url: "URL-64-ume kodita karaktraro",
                  json_string: "JSON-karaktraro",
                  e164: "E.164-nombro",
                  jwt: "JWT",
                  template_literal: "enigo",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Nevalida enigo: atendiĝis ${i.expected}, riceviĝis ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "nombro";
                          case "object":
                            if (Array.isArray(e)) return "tabelo";
                            if (null === e) return "senvalora";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `Nevalida enigo: atendiĝis ${P(i.values[0])}`;
                      return `Nevalida opcio: atendiĝis unu el ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Tro granda: atendiĝis ke ${i.origin ?? "valoro"} havu ${t}${i.maximum.toString()} ${r.unit ?? "elementojn"}`;
                      return `Tro granda: atendiĝis ke ${i.origin ?? "valoro"} havu ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Tro malgranda: atendiĝis ke ${i.origin} havu ${t}${i.minimum.toString()} ${r.unit}`;
                      return `Tro malgranda: atendiĝis ke ${i.origin} estu ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `Nevalida karaktraro: devas komenciĝi per "${i.prefix}"`;
                      if ("ends_with" === i.format)
                        return `Nevalida karaktraro: devas finiĝi per "${i.suffix}"`;
                      if ("includes" === i.format)
                        return `Nevalida karaktraro: devas inkluzivi "${i.includes}"`;
                      if ("regex" === i.format)
                        return `Nevalida karaktraro: devas kongrui kun la modelo ${i.pattern}`;
                      return `Nevalida ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `Nevalida nombro: devas esti oblo de ${i.divisor}`;
                    case "unrecognized_keys":
                      return `Nekonata${i.keys.length > 1 ? "j" : ""} ŝlosilo${i.keys.length > 1 ? "j" : ""}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Nevalida ŝlosilo en ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Nevalida enigo";
                    case "invalid_element":
                      return `Nevalida valoro en ${i.origin}`;
                  }
                }),
            };
          },
          "es",
          0,
          function () {
            return {
              localeError: (() => {
                let e = {
                    string: { unit: "caracteres", verb: "tener" },
                    file: { unit: "bytes", verb: "tener" },
                    array: { unit: "elementos", verb: "tener" },
                    set: { unit: "elementos", verb: "tener" },
                  },
                  t = {
                    string: "texto",
                    number: "número",
                    boolean: "booleano",
                    array: "arreglo",
                    object: "objeto",
                    set: "conjunto",
                    file: "archivo",
                    date: "fecha",
                    bigint: "número grande",
                    symbol: "símbolo",
                    undefined: "indefinido",
                    null: "nulo",
                    function: "función",
                    map: "mapa",
                    record: "registro",
                    tuple: "tupla",
                    enum: "enumeración",
                    union: "unión",
                    literal: "literal",
                    promise: "promesa",
                    void: "vacío",
                    never: "nunca",
                    unknown: "desconocido",
                    any: "cualquiera",
                  };
                function i(e) {
                  return t[e] ?? e;
                }
                let r = {
                  regex: "entrada",
                  email: "dirección de correo electrónico",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "fecha y hora ISO",
                  date: "fecha ISO",
                  time: "hora ISO",
                  duration: "duración ISO",
                  ipv4: "dirección IPv4",
                  ipv6: "dirección IPv6",
                  cidrv4: "rango IPv4",
                  cidrv6: "rango IPv6",
                  base64: "cadena codificada en base64",
                  base64url: "URL codificada en base64",
                  json_string: "cadena JSON",
                  e164: "número E.164",
                  jwt: "JWT",
                  template_literal: "entrada",
                };
                return (t) => {
                  switch (t.code) {
                    case "invalid_type":
                      return `Entrada inv\xe1lida: se esperaba ${i(t.expected)}, recibido ${i(
                        ((e) => {
                          let t = typeof e;
                          switch (t) {
                            case "number":
                              return Number.isNaN(e) ? "NaN" : "number";
                            case "object":
                              if (Array.isArray(e)) return "array";
                              if (null === e) return "null";
                              if (Object.getPrototypeOf(e) !== Object.prototype) return e.constructor.name;
                              return "object";
                          }
                          return t;
                        })(t.input),
                      )}`;
                    case "invalid_value":
                      if (1 === t.values.length) return `Entrada inv\xe1lida: se esperaba ${P(t.values[0])}`;
                      return `Opci\xf3n inv\xe1lida: se esperaba una de ${c(t.values, "|")}`;
                    case "too_big": {
                      let r = t.inclusive ? "<=" : "<",
                        n = e[t.origin] ?? null,
                        a = i(t.origin);
                      if (n)
                        return `Demasiado grande: se esperaba que ${a ?? "valor"} tuviera ${r}${t.maximum.toString()} ${n.unit ?? "elementos"}`;
                      return `Demasiado grande: se esperaba que ${a ?? "valor"} fuera ${r}${t.maximum.toString()}`;
                    }
                    case "too_small": {
                      let r = t.inclusive ? ">=" : ">",
                        n = e[t.origin] ?? null,
                        a = i(t.origin);
                      if (n)
                        return `Demasiado peque\xf1o: se esperaba que ${a} tuviera ${r}${t.minimum.toString()} ${n.unit}`;
                      return `Demasiado peque\xf1o: se esperaba que ${a} fuera ${r}${t.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === t.format)
                        return `Cadena inv\xe1lida: debe comenzar con "${t.prefix}"`;
                      if ("ends_with" === t.format)
                        return `Cadena inv\xe1lida: debe terminar en "${t.suffix}"`;
                      if ("includes" === t.format) return `Cadena inv\xe1lida: debe incluir "${t.includes}"`;
                      if ("regex" === t.format)
                        return `Cadena inv\xe1lida: debe coincidir con el patr\xf3n ${t.pattern}`;
                      return `Inv\xe1lido ${r[t.format] ?? t.format}`;
                    case "not_multiple_of":
                      return `N\xfamero inv\xe1lido: debe ser m\xfaltiplo de ${t.divisor}`;
                    case "unrecognized_keys":
                      return `Llave${t.keys.length > 1 ? "s" : ""} desconocida${t.keys.length > 1 ? "s" : ""}: ${c(t.keys, ", ")}`;
                    case "invalid_key":
                      return `Llave inv\xe1lida en ${i(t.origin)}`;
                    case "invalid_union":
                    default:
                      return "Entrada inválida";
                    case "invalid_element":
                      return `Valor inv\xe1lido en ${i(t.origin)}`;
                  }
                };
              })(),
            };
          },
          "fa",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "کاراکتر", verb: "داشته باشد" },
                  file: { unit: "بایت", verb: "داشته باشد" },
                  array: { unit: "آیتم", verb: "داشته باشد" },
                  set: { unit: "آیتم", verb: "داشته باشد" },
                }),
                (t = {
                  regex: "ورودی",
                  email: "آدرس ایمیل",
                  url: "URL",
                  emoji: "ایموجی",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "تاریخ و زمان ایزو",
                  date: "تاریخ ایزو",
                  time: "زمان ایزو",
                  duration: "مدت زمان ایزو",
                  ipv4: "IPv4 آدرس",
                  ipv6: "IPv6 آدرس",
                  cidrv4: "IPv4 دامنه",
                  cidrv6: "IPv6 دامنه",
                  base64: "base64-encoded رشته",
                  base64url: "base64url-encoded رشته",
                  json_string: "JSON رشته",
                  e164: "E.164 عدد",
                  jwt: "JWT",
                  template_literal: "ورودی",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `ورودی نامعتبر: می‌بایست ${i.expected} می‌بود، ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "عدد";
                          case "object":
                            if (Array.isArray(e)) return "آرایه";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)} دریافت شد`;
                    case "invalid_value":
                      if (1 === i.values.length) return `ورودی نامعتبر: می‌بایست ${P(i.values[0])} می‌بود`;
                      return `گزینه نامعتبر: می‌بایست یکی از ${c(i.values, "|")} می‌بود`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `خیلی بزرگ: ${i.origin ?? "مقدار"} باید ${t}${i.maximum.toString()} ${r.unit ?? "عنصر"} باشد`;
                      return `خیلی بزرگ: ${i.origin ?? "مقدار"} باید ${t}${i.maximum.toString()} باشد`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r) return `خیلی کوچک: ${i.origin} باید ${t}${i.minimum.toString()} ${r.unit} باشد`;
                      return `خیلی کوچک: ${i.origin} باید ${t}${i.minimum.toString()} باشد`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format) return `رشته نامعتبر: باید با "${i.prefix}" شروع شود`;
                      if ("ends_with" === i.format) return `رشته نامعتبر: باید با "${i.suffix}" تمام شود`;
                      if ("includes" === i.format) return `رشته نامعتبر: باید شامل "${i.includes}" باشد`;
                      if ("regex" === i.format)
                        return `رشته نامعتبر: باید با الگوی ${i.pattern} مطابقت داشته باشد`;
                      return `${t[i.format] ?? i.format} نامعتبر`;
                    case "not_multiple_of":
                      return `عدد نامعتبر: باید مضرب ${i.divisor} باشد`;
                    case "unrecognized_keys":
                      return `کلید${i.keys.length > 1 ? "های" : ""} ناشناس: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `کلید ناشناس در ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "ورودی نامعتبر";
                    case "invalid_element":
                      return `مقدار نامعتبر در ${i.origin}`;
                  }
                }),
            };
          },
          "fi",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "merkkiä", subject: "merkkijonon" },
                  file: { unit: "tavua", subject: "tiedoston" },
                  array: { unit: "alkiota", subject: "listan" },
                  set: { unit: "alkiota", subject: "joukon" },
                  number: { unit: "", subject: "luvun" },
                  bigint: { unit: "", subject: "suuren kokonaisluvun" },
                  int: { unit: "", subject: "kokonaisluvun" },
                  date: { unit: "", subject: "päivämäärän" },
                }),
                (t = {
                  regex: "säännöllinen lauseke",
                  email: "sähköpostiosoite",
                  url: "URL-osoite",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO-aikaleima",
                  date: "ISO-päivämäärä",
                  time: "ISO-aika",
                  duration: "ISO-kesto",
                  ipv4: "IPv4-osoite",
                  ipv6: "IPv6-osoite",
                  cidrv4: "IPv4-alue",
                  cidrv6: "IPv6-alue",
                  base64: "base64-koodattu merkkijono",
                  base64url: "base64url-koodattu merkkijono",
                  json_string: "JSON-merkkijono",
                  e164: "E.164-luku",
                  jwt: "JWT",
                  template_literal: "templaattimerkkijono",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Virheellinen tyyppi: odotettiin ${i.expected}, oli ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "number";
                          case "object":
                            if (Array.isArray(e)) return "array";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length)
                        return `Virheellinen sy\xf6te: t\xe4ytyy olla ${P(i.values[0])}`;
                      return `Virheellinen valinta: t\xe4ytyy olla yksi seuraavista: ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Liian suuri: ${r.subject} t\xe4ytyy olla ${t}${i.maximum.toString()} ${r.unit}`.trim();
                      return `Liian suuri: arvon t\xe4ytyy olla ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Liian pieni: ${r.subject} t\xe4ytyy olla ${t}${i.minimum.toString()} ${r.unit}`.trim();
                      return `Liian pieni: arvon t\xe4ytyy olla ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `Virheellinen sy\xf6te: t\xe4ytyy alkaa "${i.prefix}"`;
                      if ("ends_with" === i.format)
                        return `Virheellinen sy\xf6te: t\xe4ytyy loppua "${i.suffix}"`;
                      if ("includes" === i.format)
                        return `Virheellinen sy\xf6te: t\xe4ytyy sis\xe4lt\xe4\xe4 "${i.includes}"`;
                      if ("regex" === i.format)
                        return `Virheellinen sy\xf6te: t\xe4ytyy vastata s\xe4\xe4nn\xf6llist\xe4 lauseketta ${i.pattern}`;
                      return `Virheellinen ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `Virheellinen luku: t\xe4ytyy olla luvun ${i.divisor} monikerta`;
                    case "unrecognized_keys":
                      return `${i.keys.length > 1 ? "Tuntemattomat avaimet" : "Tuntematon avain"}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return "Virheellinen avain tietueessa";
                    case "invalid_union":
                      return "Virheellinen unioni";
                    case "invalid_element":
                      return "Virheellinen arvo joukossa";
                    default:
                      return "Virheellinen syöte";
                  }
                }),
            };
          },
          "fr",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "caractères", verb: "avoir" },
                  file: { unit: "octets", verb: "avoir" },
                  array: { unit: "éléments", verb: "avoir" },
                  set: { unit: "éléments", verb: "avoir" },
                }),
                (t = {
                  regex: "entrée",
                  email: "adresse e-mail",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "date et heure ISO",
                  date: "date ISO",
                  time: "heure ISO",
                  duration: "durée ISO",
                  ipv4: "adresse IPv4",
                  ipv6: "adresse IPv6",
                  cidrv4: "plage IPv4",
                  cidrv6: "plage IPv6",
                  base64: "chaîne encodée en base64",
                  base64url: "chaîne encodée en base64url",
                  json_string: "chaîne JSON",
                  e164: "numéro E.164",
                  jwt: "JWT",
                  template_literal: "entrée",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Entr\xe9e invalide : ${i.expected} attendu, ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "nombre";
                          case "object":
                            if (Array.isArray(e)) return "tableau";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)} re\xe7u`;
                    case "invalid_value":
                      if (1 === i.values.length) return `Entr\xe9e invalide : ${P(i.values[0])} attendu`;
                      return `Option invalide : une valeur parmi ${c(i.values, "|")} attendue`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Trop grand : ${i.origin ?? "valeur"} doit ${r.verb} ${t}${i.maximum.toString()} ${r.unit ?? "élément(s)"}`;
                      return `Trop grand : ${i.origin ?? "valeur"} doit \xeatre ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Trop petit : ${i.origin} doit ${r.verb} ${t}${i.minimum.toString()} ${r.unit}`;
                      return `Trop petit : ${i.origin} doit \xeatre ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `Cha\xeene invalide : doit commencer par "${i.prefix}"`;
                      if ("ends_with" === i.format)
                        return `Cha\xeene invalide : doit se terminer par "${i.suffix}"`;
                      if ("includes" === i.format) return `Cha\xeene invalide : doit inclure "${i.includes}"`;
                      if ("regex" === i.format)
                        return `Cha\xeene invalide : doit correspondre au mod\xe8le ${i.pattern}`;
                      return `${t[i.format] ?? i.format} invalide`;
                    case "not_multiple_of":
                      return `Nombre invalide : doit \xeatre un multiple de ${i.divisor}`;
                    case "unrecognized_keys":
                      return `Cl\xe9${i.keys.length > 1 ? "s" : ""} non reconnue${i.keys.length > 1 ? "s" : ""} : ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Cl\xe9 invalide dans ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Entrée invalide";
                    case "invalid_element":
                      return `Valeur invalide dans ${i.origin}`;
                  }
                }),
            };
          },
          "frCA",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "caractères", verb: "avoir" },
                  file: { unit: "octets", verb: "avoir" },
                  array: { unit: "éléments", verb: "avoir" },
                  set: { unit: "éléments", verb: "avoir" },
                }),
                (t = {
                  regex: "entrée",
                  email: "adresse courriel",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "date-heure ISO",
                  date: "date ISO",
                  time: "heure ISO",
                  duration: "durée ISO",
                  ipv4: "adresse IPv4",
                  ipv6: "adresse IPv6",
                  cidrv4: "plage IPv4",
                  cidrv6: "plage IPv6",
                  base64: "chaîne encodée en base64",
                  base64url: "chaîne encodée en base64url",
                  json_string: "chaîne JSON",
                  e164: "numéro E.164",
                  jwt: "JWT",
                  template_literal: "entrée",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Entr\xe9e invalide : attendu ${i.expected}, re\xe7u ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "number";
                          case "object":
                            if (Array.isArray(e)) return "array";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `Entr\xe9e invalide : attendu ${P(i.values[0])}`;
                      return `Option invalide : attendu l'une des valeurs suivantes ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "≤" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Trop grand : attendu que ${i.origin ?? "la valeur"} ait ${t}${i.maximum.toString()} ${r.unit}`;
                      return `Trop grand : attendu que ${i.origin ?? "la valeur"} soit ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? "≥" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Trop petit : attendu que ${i.origin} ait ${t}${i.minimum.toString()} ${r.unit}`;
                      return `Trop petit : attendu que ${i.origin} soit ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `Cha\xeene invalide : doit commencer par "${i.prefix}"`;
                      if ("ends_with" === i.format)
                        return `Cha\xeene invalide : doit se terminer par "${i.suffix}"`;
                      if ("includes" === i.format) return `Cha\xeene invalide : doit inclure "${i.includes}"`;
                      if ("regex" === i.format)
                        return `Cha\xeene invalide : doit correspondre au motif ${i.pattern}`;
                      return `${t[i.format] ?? i.format} invalide`;
                    case "not_multiple_of":
                      return `Nombre invalide : doit \xeatre un multiple de ${i.divisor}`;
                    case "unrecognized_keys":
                      return `Cl\xe9${i.keys.length > 1 ? "s" : ""} non reconnue${i.keys.length > 1 ? "s" : ""} : ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Cl\xe9 invalide dans ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Entrée invalide";
                    case "invalid_element":
                      return `Valeur invalide dans ${i.origin}`;
                  }
                }),
            };
          },
          "he",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "אותיות", verb: "לכלול" },
                  file: { unit: "בייטים", verb: "לכלול" },
                  array: { unit: "פריטים", verb: "לכלול" },
                  set: { unit: "פריטים", verb: "לכלול" },
                }),
                (t = {
                  regex: "קלט",
                  email: "כתובת אימייל",
                  url: "כתובת רשת",
                  emoji: "אימוג'י",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "תאריך וזמן ISO",
                  date: "תאריך ISO",
                  time: "זמן ISO",
                  duration: "משך זמן ISO",
                  ipv4: "כתובת IPv4",
                  ipv6: "כתובת IPv6",
                  cidrv4: "טווח IPv4",
                  cidrv6: "טווח IPv6",
                  base64: "מחרוזת בבסיס 64",
                  base64url: "מחרוזת בבסיס 64 לכתובות רשת",
                  json_string: "מחרוזת JSON",
                  e164: "מספר E.164",
                  jwt: "JWT",
                  template_literal: "קלט",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `קלט לא תקין: צריך ${i.expected}, התקבל ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "number";
                          case "object":
                            if (Array.isArray(e)) return "array";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `קלט לא תקין: צריך ${P(i.values[0])}`;
                      return `קלט לא תקין: צריך אחת מהאפשרויות  ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `גדול מדי: ${i.origin ?? "value"} צריך להיות ${t}${i.maximum.toString()} ${r.unit ?? "elements"}`;
                      return `גדול מדי: ${i.origin ?? "value"} צריך להיות ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r) return `קטן מדי: ${i.origin} צריך להיות ${t}${i.minimum.toString()} ${r.unit}`;
                      return `קטן מדי: ${i.origin} צריך להיות ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format) return `מחרוזת לא תקינה: חייבת להתחיל ב"${i.prefix}"`;
                      if ("ends_with" === i.format) return `מחרוזת לא תקינה: חייבת להסתיים ב "${i.suffix}"`;
                      if ("includes" === i.format) return `מחרוזת לא תקינה: חייבת לכלול "${i.includes}"`;
                      if ("regex" === i.format) return `מחרוזת לא תקינה: חייבת להתאים לתבנית ${i.pattern}`;
                      return `${t[i.format] ?? i.format} לא תקין`;
                    case "not_multiple_of":
                      return `מספר לא תקין: חייב להיות מכפלה של ${i.divisor}`;
                    case "unrecognized_keys":
                      return `מפתח${i.keys.length > 1 ? "ות" : ""} לא מזוה${i.keys.length > 1 ? "ים" : "ה"}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `מפתח לא תקין ב${i.origin}`;
                    case "invalid_union":
                    default:
                      return "קלט לא תקין";
                    case "invalid_element":
                      return `ערך לא תקין ב${i.origin}`;
                  }
                }),
            };
          },
          "hu",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "karakter", verb: "legyen" },
                  file: { unit: "byte", verb: "legyen" },
                  array: { unit: "elem", verb: "legyen" },
                  set: { unit: "elem", verb: "legyen" },
                }),
                (t = {
                  regex: "bemenet",
                  email: "email cím",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO időbélyeg",
                  date: "ISO dátum",
                  time: "ISO idő",
                  duration: "ISO időintervallum",
                  ipv4: "IPv4 cím",
                  ipv6: "IPv6 cím",
                  cidrv4: "IPv4 tartomány",
                  cidrv6: "IPv6 tartomány",
                  base64: "base64-kódolt string",
                  base64url: "base64url-kódolt string",
                  json_string: "JSON string",
                  e164: "E.164 szám",
                  jwt: "JWT",
                  template_literal: "bemenet",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `\xc9rv\xe9nytelen bemenet: a v\xe1rt \xe9rt\xe9k ${i.expected}, a kapott \xe9rt\xe9k ${((
                        e,
                      ) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "szám";
                          case "object":
                            if (Array.isArray(e)) return "tömb";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length)
                        return `\xc9rv\xe9nytelen bemenet: a v\xe1rt \xe9rt\xe9k ${P(i.values[0])}`;
                      return `\xc9rv\xe9nytelen opci\xf3: valamelyik \xe9rt\xe9k v\xe1rt ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `T\xfal nagy: ${i.origin ?? "érték"} m\xe9rete t\xfal nagy ${t}${i.maximum.toString()} ${r.unit ?? "elem"}`;
                      return `T\xfal nagy: a bemeneti \xe9rt\xe9k ${i.origin ?? "érték"} t\xfal nagy: ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `T\xfal kicsi: a bemeneti \xe9rt\xe9k ${i.origin} m\xe9rete t\xfal kicsi ${t}${i.minimum.toString()} ${r.unit}`;
                      return `T\xfal kicsi: a bemeneti \xe9rt\xe9k ${i.origin} t\xfal kicsi ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `\xc9rv\xe9nytelen string: "${i.prefix}" \xe9rt\xe9kkel kell kezdődnie`;
                      if ("ends_with" === i.format)
                        return `\xc9rv\xe9nytelen string: "${i.suffix}" \xe9rt\xe9kkel kell v\xe9gződnie`;
                      if ("includes" === i.format)
                        return `\xc9rv\xe9nytelen string: "${i.includes}" \xe9rt\xe9ket kell tartalmaznia`;
                      if ("regex" === i.format)
                        return `\xc9rv\xe9nytelen string: ${i.pattern} mint\xe1nak kell megfelelnie`;
                      return `\xc9rv\xe9nytelen ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `\xc9rv\xe9nytelen sz\xe1m: ${i.divisor} t\xf6bbsz\xf6r\xf6s\xe9nek kell lennie`;
                    case "unrecognized_keys":
                      return `Ismeretlen kulcs${i.keys.length > 1 ? "s" : ""}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `\xc9rv\xe9nytelen kulcs ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Érvénytelen bemenet";
                    case "invalid_element":
                      return `\xc9rv\xe9nytelen \xe9rt\xe9k: ${i.origin}`;
                  }
                }),
            };
          },
          "id",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "karakter", verb: "memiliki" },
                  file: { unit: "byte", verb: "memiliki" },
                  array: { unit: "item", verb: "memiliki" },
                  set: { unit: "item", verb: "memiliki" },
                }),
                (t = {
                  regex: "input",
                  email: "alamat email",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "tanggal dan waktu format ISO",
                  date: "tanggal format ISO",
                  time: "jam format ISO",
                  duration: "durasi format ISO",
                  ipv4: "alamat IPv4",
                  ipv6: "alamat IPv6",
                  cidrv4: "rentang alamat IPv4",
                  cidrv6: "rentang alamat IPv6",
                  base64: "string dengan enkode base64",
                  base64url: "string dengan enkode base64url",
                  json_string: "string JSON",
                  e164: "angka E.164",
                  jwt: "JWT",
                  template_literal: "input",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Input tidak valid: diharapkan ${i.expected}, diterima ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "number";
                          case "object":
                            if (Array.isArray(e)) return "array";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `Input tidak valid: diharapkan ${P(i.values[0])}`;
                      return `Pilihan tidak valid: diharapkan salah satu dari ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Terlalu besar: diharapkan ${i.origin ?? "value"} memiliki ${t}${i.maximum.toString()} ${r.unit ?? "elemen"}`;
                      return `Terlalu besar: diharapkan ${i.origin ?? "value"} menjadi ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Terlalu kecil: diharapkan ${i.origin} memiliki ${t}${i.minimum.toString()} ${r.unit}`;
                      return `Terlalu kecil: diharapkan ${i.origin} menjadi ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `String tidak valid: harus dimulai dengan "${i.prefix}"`;
                      if ("ends_with" === i.format)
                        return `String tidak valid: harus berakhir dengan "${i.suffix}"`;
                      if ("includes" === i.format)
                        return `String tidak valid: harus menyertakan "${i.includes}"`;
                      if ("regex" === i.format) return `String tidak valid: harus sesuai pola ${i.pattern}`;
                      return `${t[i.format] ?? i.format} tidak valid`;
                    case "not_multiple_of":
                      return `Angka tidak valid: harus kelipatan dari ${i.divisor}`;
                    case "unrecognized_keys":
                      return `Kunci tidak dikenali ${i.keys.length > 1 ? "s" : ""}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Kunci tidak valid di ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Input tidak valid";
                    case "invalid_element":
                      return `Nilai tidak valid di ${i.origin}`;
                  }
                }),
            };
          },
          "is",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "stafi", verb: "að hafa" },
                  file: { unit: "bæti", verb: "að hafa" },
                  array: { unit: "hluti", verb: "að hafa" },
                  set: { unit: "hluti", verb: "að hafa" },
                }),
                (t = {
                  regex: "gildi",
                  email: "netfang",
                  url: "vefslóð",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO dagsetning og tími",
                  date: "ISO dagsetning",
                  time: "ISO tími",
                  duration: "ISO tímalengd",
                  ipv4: "IPv4 address",
                  ipv6: "IPv6 address",
                  cidrv4: "IPv4 range",
                  cidrv6: "IPv6 range",
                  base64: "base64-encoded strengur",
                  base64url: "base64url-encoded strengur",
                  json_string: "JSON strengur",
                  e164: "E.164 tölugildi",
                  jwt: "JWT",
                  template_literal: "gildi",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Rangt gildi: \xde\xfa sl\xf3st inn ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "númer";
                          case "object":
                            if (Array.isArray(e)) return "fylki";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)} \xfear sem \xe1 a\xf0 vera ${i.expected}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `Rangt gildi: gert r\xe1\xf0 fyrir ${P(i.values[0])}`;
                      return `\xd3gilt val: m\xe1 vera eitt af eftirfarandi ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Of st\xf3rt: gert er r\xe1\xf0 fyrir a\xf0 ${i.origin ?? "gildi"} hafi ${t}${i.maximum.toString()} ${r.unit ?? "hluti"}`;
                      return `Of st\xf3rt: gert er r\xe1\xf0 fyrir a\xf0 ${i.origin ?? "gildi"} s\xe9 ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Of l\xedti\xf0: gert er r\xe1\xf0 fyrir a\xf0 ${i.origin} hafi ${t}${i.minimum.toString()} ${r.unit}`;
                      return `Of l\xedti\xf0: gert er r\xe1\xf0 fyrir a\xf0 ${i.origin} s\xe9 ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `\xd3gildur strengur: ver\xf0ur a\xf0 byrja \xe1 "${i.prefix}"`;
                      if ("ends_with" === i.format)
                        return `\xd3gildur strengur: ver\xf0ur a\xf0 enda \xe1 "${i.suffix}"`;
                      if ("includes" === i.format)
                        return `\xd3gildur strengur: ver\xf0ur a\xf0 innihalda "${i.includes}"`;
                      if ("regex" === i.format)
                        return `\xd3gildur strengur: ver\xf0ur a\xf0 fylgja mynstri ${i.pattern}`;
                      return `Rangt ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `R\xf6ng tala: ver\xf0ur a\xf0 vera margfeldi af ${i.divisor}`;
                    case "unrecognized_keys":
                      return `\xd3\xfeekkt ${i.keys.length > 1 ? "ir lyklar" : "ur lykill"}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Rangur lykill \xed ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Rangt gildi";
                    case "invalid_element":
                      return `Rangt gildi \xed ${i.origin}`;
                  }
                }),
            };
          },
          "it",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "caratteri", verb: "avere" },
                  file: { unit: "byte", verb: "avere" },
                  array: { unit: "elementi", verb: "avere" },
                  set: { unit: "elementi", verb: "avere" },
                }),
                (t = {
                  regex: "input",
                  email: "indirizzo email",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "data e ora ISO",
                  date: "data ISO",
                  time: "ora ISO",
                  duration: "durata ISO",
                  ipv4: "indirizzo IPv4",
                  ipv6: "indirizzo IPv6",
                  cidrv4: "intervallo IPv4",
                  cidrv6: "intervallo IPv6",
                  base64: "stringa codificata in base64",
                  base64url: "URL codificata in base64",
                  json_string: "stringa JSON",
                  e164: "numero E.164",
                  jwt: "JWT",
                  template_literal: "input",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Input non valido: atteso ${i.expected}, ricevuto ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "numero";
                          case "object":
                            if (Array.isArray(e)) return "vettore";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `Input non valido: atteso ${P(i.values[0])}`;
                      return `Opzione non valida: atteso uno tra ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Troppo grande: ${i.origin ?? "valore"} deve avere ${t}${i.maximum.toString()} ${r.unit ?? "elementi"}`;
                      return `Troppo grande: ${i.origin ?? "valore"} deve essere ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Troppo piccolo: ${i.origin} deve avere ${t}${i.minimum.toString()} ${r.unit}`;
                      return `Troppo piccolo: ${i.origin} deve essere ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `Stringa non valida: deve iniziare con "${i.prefix}"`;
                      if ("ends_with" === i.format)
                        return `Stringa non valida: deve terminare con "${i.suffix}"`;
                      if ("includes" === i.format)
                        return `Stringa non valida: deve includere "${i.includes}"`;
                      if ("regex" === i.format)
                        return `Stringa non valida: deve corrispondere al pattern ${i.pattern}`;
                      return `Invalid ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `Numero non valido: deve essere un multiplo di ${i.divisor}`;
                    case "unrecognized_keys":
                      return `Chiav${i.keys.length > 1 ? "i" : "e"} non riconosciut${i.keys.length > 1 ? "e" : "a"}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Chiave non valida in ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Input non valido";
                    case "invalid_element":
                      return `Valore non valido in ${i.origin}`;
                  }
                }),
            };
          },
          "ja",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "文字", verb: "である" },
                  file: { unit: "バイト", verb: "である" },
                  array: { unit: "要素", verb: "である" },
                  set: { unit: "要素", verb: "である" },
                }),
                (t = {
                  regex: "入力値",
                  email: "メールアドレス",
                  url: "URL",
                  emoji: "絵文字",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO日時",
                  date: "ISO日付",
                  time: "ISO時刻",
                  duration: "ISO期間",
                  ipv4: "IPv4アドレス",
                  ipv6: "IPv6アドレス",
                  cidrv4: "IPv4範囲",
                  cidrv6: "IPv6範囲",
                  base64: "base64エンコード文字列",
                  base64url: "base64urlエンコード文字列",
                  json_string: "JSON文字列",
                  e164: "E.164番号",
                  jwt: "JWT",
                  template_literal: "入力値",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `無効な入力: ${i.expected}が期待されましたが、${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "数値";
                          case "object":
                            if (Array.isArray(e)) return "配列";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}が入力されました`;
                    case "invalid_value":
                      if (1 === i.values.length) return `無効な入力: ${P(i.values[0])}が期待されました`;
                      return `無効な選択: ${c(i.values, "、")}のいずれかである必要があります`;
                    case "too_big": {
                      let t = i.inclusive ? "以下である" : "より小さい",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `大きすぎる値: ${i.origin ?? "値"}は${i.maximum.toString()}${r.unit ?? "要素"}${t}必要があります`;
                      return `大きすぎる値: ${i.origin ?? "値"}は${i.maximum.toString()}${t}必要があります`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? "以上である" : "より大きい",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `小さすぎる値: ${i.origin}は${i.minimum.toString()}${r.unit}${t}必要があります`;
                      return `小さすぎる値: ${i.origin}は${i.minimum.toString()}${t}必要があります`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `無効な文字列: "${i.prefix}"で始まる必要があります`;
                      if ("ends_with" === i.format)
                        return `無効な文字列: "${i.suffix}"で終わる必要があります`;
                      if ("includes" === i.format) return `無効な文字列: "${i.includes}"を含む必要があります`;
                      if ("regex" === i.format)
                        return `無効な文字列: パターン${i.pattern}に一致する必要があります`;
                      return `無効な${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `無効な数値: ${i.divisor}の倍数である必要があります`;
                    case "unrecognized_keys":
                      return `認識されていないキー${i.keys.length > 1 ? "群" : ""}: ${c(i.keys, "、")}`;
                    case "invalid_key":
                      return `${i.origin}内の無効なキー`;
                    case "invalid_union":
                    default:
                      return "無効な入力";
                    case "invalid_element":
                      return `${i.origin}内の無効な値`;
                  }
                }),
            };
          },
          "ka",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "სიმბოლო", verb: "უნდა შეიცავდეს" },
                  file: { unit: "ბაიტი", verb: "უნდა შეიცავდეს" },
                  array: { unit: "ელემენტი", verb: "უნდა შეიცავდეს" },
                  set: { unit: "ელემენტი", verb: "უნდა შეიცავდეს" },
                }),
                (t = {
                  regex: "შეყვანა",
                  email: "ელ-ფოსტის მისამართი",
                  url: "URL",
                  emoji: "ემოჯი",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "თარიღი-დრო",
                  date: "თარიღი",
                  time: "დრო",
                  duration: "ხანგრძლივობა",
                  ipv4: "IPv4 მისამართი",
                  ipv6: "IPv6 მისამართი",
                  cidrv4: "IPv4 დიაპაზონი",
                  cidrv6: "IPv6 დიაპაზონი",
                  base64: "base64-კოდირებული სტრინგი",
                  base64url: "base64url-კოდირებული სტრინგი",
                  json_string: "JSON სტრინგი",
                  e164: "E.164 ნომერი",
                  jwt: "JWT",
                  template_literal: "შეყვანა",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `არასწორი შეყვანა: მოსალოდნელი ${i.expected}, მიღებული ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "რიცხვი";
                          case "object":
                            if (Array.isArray(e)) return "მასივი";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return (
                          {
                            string: "სტრინგი",
                            boolean: "ბულეანი",
                            undefined: "undefined",
                            bigint: "bigint",
                            symbol: "symbol",
                            function: "ფუნქცია",
                          }[t] ?? t
                        );
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `არასწორი შეყვანა: მოსალოდნელი ${P(i.values[0])}`;
                      return `არასწორი ვარიანტი: მოსალოდნელია ერთ-ერთი ${c(i.values, "|")}-დან`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `ზედმეტად დიდი: მოსალოდნელი ${i.origin ?? "მნიშვნელობა"} ${r.verb} ${t}${i.maximum.toString()} ${r.unit}`;
                      return `ზედმეტად დიდი: მოსალოდნელი ${i.origin ?? "მნიშვნელობა"} იყოს ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `ზედმეტად პატარა: მოსალოდნელი ${i.origin} ${r.verb} ${t}${i.minimum.toString()} ${r.unit}`;
                      return `ზედმეტად პატარა: მოსალოდნელი ${i.origin} იყოს ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `არასწორი სტრინგი: უნდა იწყებოდეს "${i.prefix}"-ით`;
                      if ("ends_with" === i.format)
                        return `არასწორი სტრინგი: უნდა მთავრდებოდეს "${i.suffix}"-ით`;
                      if ("includes" === i.format)
                        return `არასწორი სტრინგი: უნდა შეიცავდეს "${i.includes}"-ს`;
                      if ("regex" === i.format)
                        return `არასწორი სტრინგი: უნდა შეესაბამებოდეს შაბლონს ${i.pattern}`;
                      return `არასწორი ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `არასწორი რიცხვი: უნდა იყოს ${i.divisor}-ის ჯერადი`;
                    case "unrecognized_keys":
                      return `უცნობი გასაღებ${i.keys.length > 1 ? "ები" : "ი"}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `არასწორი გასაღები ${i.origin}-ში`;
                    case "invalid_union":
                    default:
                      return "არასწორი შეყვანა";
                    case "invalid_element":
                      return `არასწორი მნიშვნელობა ${i.origin}-ში`;
                  }
                }),
            };
          },
          "kh",
          0,
          function () {
            return re();
          },
          "km",
          0,
          re,
          "ko",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "문자", verb: "to have" },
                  file: { unit: "바이트", verb: "to have" },
                  array: { unit: "개", verb: "to have" },
                  set: { unit: "개", verb: "to have" },
                }),
                (t = {
                  regex: "입력",
                  email: "이메일 주소",
                  url: "URL",
                  emoji: "이모지",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO 날짜시간",
                  date: "ISO 날짜",
                  time: "ISO 시간",
                  duration: "ISO 기간",
                  ipv4: "IPv4 주소",
                  ipv6: "IPv6 주소",
                  cidrv4: "IPv4 범위",
                  cidrv6: "IPv6 범위",
                  base64: "base64 인코딩 문자열",
                  base64url: "base64url 인코딩 문자열",
                  json_string: "JSON 문자열",
                  e164: "E.164 번호",
                  jwt: "JWT",
                  template_literal: "입력",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `잘못된 입력: 예상 타입은 ${i.expected}, 받은 타입은 ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "number";
                          case "object":
                            if (Array.isArray(e)) return "array";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}입니다`;
                    case "invalid_value":
                      if (1 === i.values.length) return `잘못된 입력: 값은 ${P(i.values[0])} 이어야 합니다`;
                      return `잘못된 옵션: ${c(i.values, "또는 ")} 중 하나여야 합니다`;
                    case "too_big": {
                      let t = i.inclusive ? "이하" : "미만",
                        r = "미만" === t ? "이어야 합니다" : "여야 합니다",
                        n = e[i.origin] ?? null,
                        a = n?.unit ?? "요소";
                      if (n) return `${i.origin ?? "값"}이 너무 큽니다: ${i.maximum.toString()}${a} ${t}${r}`;
                      return `${i.origin ?? "값"}이 너무 큽니다: ${i.maximum.toString()} ${t}${r}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? "이상" : "초과",
                        r = "이상" === t ? "이어야 합니다" : "여야 합니다",
                        n = e[i.origin] ?? null,
                        a = n?.unit ?? "요소";
                      if (n)
                        return `${i.origin ?? "값"}이 너무 작습니다: ${i.minimum.toString()}${a} ${t}${r}`;
                      return `${i.origin ?? "값"}이 너무 작습니다: ${i.minimum.toString()} ${t}${r}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `잘못된 문자열: "${i.prefix}"(으)로 시작해야 합니다`;
                      if ("ends_with" === i.format) return `잘못된 문자열: "${i.suffix}"(으)로 끝나야 합니다`;
                      if ("includes" === i.format)
                        return `잘못된 문자열: "${i.includes}"을(를) 포함해야 합니다`;
                      if ("regex" === i.format)
                        return `잘못된 문자열: 정규식 ${i.pattern} 패턴과 일치해야 합니다`;
                      return `잘못된 ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `잘못된 숫자: ${i.divisor}의 배수여야 합니다`;
                    case "unrecognized_keys":
                      return `인식할 수 없는 키: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `잘못된 키: ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "잘못된 입력";
                    case "invalid_element":
                      return `잘못된 값: ${i.origin}`;
                  }
                }),
            };
          },
          "lt",
          0,
          function () {
            return {
              localeError: (() => {
                let e = {
                  string: {
                    unit: { one: "simbolis", few: "simboliai", many: "simbolių" },
                    verb: {
                      smaller: {
                        inclusive: "turi būti ne ilgesnė kaip",
                        notInclusive: "turi būti trumpesnė kaip",
                      },
                      bigger: {
                        inclusive: "turi būti ne trumpesnė kaip",
                        notInclusive: "turi būti ilgesnė kaip",
                      },
                    },
                  },
                  file: {
                    unit: { one: "baitas", few: "baitai", many: "baitų" },
                    verb: {
                      smaller: {
                        inclusive: "turi būti ne didesnis kaip",
                        notInclusive: "turi būti mažesnis kaip",
                      },
                      bigger: {
                        inclusive: "turi būti ne mažesnis kaip",
                        notInclusive: "turi būti didesnis kaip",
                      },
                    },
                  },
                  array: {
                    unit: { one: "elementą", few: "elementus", many: "elementų" },
                    verb: {
                      smaller: {
                        inclusive: "turi turėti ne daugiau kaip",
                        notInclusive: "turi turėti mažiau kaip",
                      },
                      bigger: {
                        inclusive: "turi turėti ne mažiau kaip",
                        notInclusive: "turi turėti daugiau kaip",
                      },
                    },
                  },
                  set: {
                    unit: { one: "elementą", few: "elementus", many: "elementų" },
                    verb: {
                      smaller: {
                        inclusive: "turi turėti ne daugiau kaip",
                        notInclusive: "turi turėti mažiau kaip",
                      },
                      bigger: {
                        inclusive: "turi turėti ne mažiau kaip",
                        notInclusive: "turi turėti daugiau kaip",
                      },
                    },
                  },
                };
                function t(t, i, r, n) {
                  let a = e[t] ?? null;
                  return null === a
                    ? a
                    : { unit: a.unit[i], verb: a.verb[n][r ? "inclusive" : "notInclusive"] };
                }
                let i = {
                  regex: "įvestis",
                  email: "el. pašto adresas",
                  url: "URL",
                  emoji: "jaustukas",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO data ir laikas",
                  date: "ISO data",
                  time: "ISO laikas",
                  duration: "ISO trukmė",
                  ipv4: "IPv4 adresas",
                  ipv6: "IPv6 adresas",
                  cidrv4: "IPv4 tinklo prefiksas (CIDR)",
                  cidrv6: "IPv6 tinklo prefiksas (CIDR)",
                  base64: "base64 užkoduota eilutė",
                  base64url: "base64url užkoduota eilutė",
                  json_string: "JSON eilutė",
                  e164: "E.164 numeris",
                  jwt: "JWT",
                  template_literal: "įvestis",
                };
                return (e) => {
                  switch (e.code) {
                    case "invalid_type":
                      var r;
                      return `Gautas tipas ${rt(typeof (r = e.input), r)}, o tikėtasi - ${rt(e.expected)}`;
                    case "invalid_value":
                      if (1 === e.values.length) return `Privalo būti ${P(e.values[0])}`;
                      return `Privalo būti vienas iš ${c(e.values, "|")} pasirinkimų`;
                    case "too_big": {
                      let i = rt(e.origin),
                        r = t(e.origin, rr(Number(e.maximum)), e.inclusive ?? !1, "smaller");
                      if (r?.verb)
                        return `${ri(i ?? e.origin ?? "reikšmė")} ${r.verb} ${e.maximum.toString()} ${r.unit ?? "elementų"}`;
                      let n = e.inclusive ? "ne didesnis kaip" : "mažesnis kaip";
                      return `${ri(i ?? e.origin ?? "reikšmė")} turi būti ${n} ${e.maximum.toString()} ${r?.unit}`;
                    }
                    case "too_small": {
                      let i = rt(e.origin),
                        r = t(e.origin, rr(Number(e.minimum)), e.inclusive ?? !1, "bigger");
                      if (r?.verb)
                        return `${ri(i ?? e.origin ?? "reikšmė")} ${r.verb} ${e.minimum.toString()} ${r.unit ?? "elementų"}`;
                      let n = e.inclusive ? "ne mažesnis kaip" : "didesnis kaip";
                      return `${ri(i ?? e.origin ?? "reikšmė")} turi būti ${n} ${e.minimum.toString()} ${r?.unit}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === e.format) return `Eilutė privalo prasidėti "${e.prefix}"`;
                      if ("ends_with" === e.format) return `Eilutė privalo pasibaigti "${e.suffix}"`;
                      if ("includes" === e.format) return `Eilutė privalo įtraukti "${e.includes}"`;
                      if ("regex" === e.format) return `Eilutė privalo atitikti ${e.pattern}`;
                      return `Neteisingas ${i[e.format] ?? e.format}`;
                    case "not_multiple_of":
                      return `Skaičius privalo būti ${e.divisor} kartotinis.`;
                    case "unrecognized_keys":
                      return `Neatpažint${e.keys.length > 1 ? "i" : "as"} rakt${e.keys.length > 1 ? "ai" : "as"}: ${c(e.keys, ", ")}`;
                    case "invalid_key":
                      return "Rastas klaidingas raktas";
                    case "invalid_union":
                    default:
                      return "Klaidinga įvestis";
                    case "invalid_element": {
                      let t = rt(e.origin);
                      return `${ri(t ?? e.origin ?? "reikšmė")} turi klaidingą įvestį`;
                    }
                  }
                };
              })(),
            };
          },
          "mk",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "знаци", verb: "да имаат" },
                  file: { unit: "бајти", verb: "да имаат" },
                  array: { unit: "ставки", verb: "да имаат" },
                  set: { unit: "ставки", verb: "да имаат" },
                }),
                (t = {
                  regex: "внес",
                  email: "адреса на е-пошта",
                  url: "URL",
                  emoji: "емоџи",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO датум и време",
                  date: "ISO датум",
                  time: "ISO време",
                  duration: "ISO времетраење",
                  ipv4: "IPv4 адреса",
                  ipv6: "IPv6 адреса",
                  cidrv4: "IPv4 опсег",
                  cidrv6: "IPv6 опсег",
                  base64: "base64-енкодирана низа",
                  base64url: "base64url-енкодирана низа",
                  json_string: "JSON низа",
                  e164: "E.164 број",
                  jwt: "JWT",
                  template_literal: "внес",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Грешен внес: се очекува ${i.expected}, примено ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "број";
                          case "object":
                            if (Array.isArray(e)) return "низа";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `Invalid input: expected ${P(i.values[0])}`;
                      return `Грешана опција: се очекува една ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Премногу голем: се очекува ${i.origin ?? "вредноста"} да има ${t}${i.maximum.toString()} ${r.unit ?? "елементи"}`;
                      return `Премногу голем: се очекува ${i.origin ?? "вредноста"} да биде ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Премногу мал: се очекува ${i.origin} да има ${t}${i.minimum.toString()} ${r.unit}`;
                      return `Премногу мал: се очекува ${i.origin} да биде ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `Неважечка низа: мора да започнува со "${i.prefix}"`;
                      if ("ends_with" === i.format)
                        return `Неважечка низа: мора да завршува со "${i.suffix}"`;
                      if ("includes" === i.format) return `Неважечка низа: мора да вклучува "${i.includes}"`;
                      if ("regex" === i.format)
                        return `Неважечка низа: мора да одгоара на патернот ${i.pattern}`;
                      return `Invalid ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `Грешен број: мора да биде делив со ${i.divisor}`;
                    case "unrecognized_keys":
                      return `${i.keys.length > 1 ? "Непрепознаени клучеви" : "Непрепознаен клуч"}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Грешен клуч во ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Грешен внес";
                    case "invalid_element":
                      return `Грешна вредност во ${i.origin}`;
                  }
                }),
            };
          },
          "ms",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "aksara", verb: "mempunyai" },
                  file: { unit: "bait", verb: "mempunyai" },
                  array: { unit: "elemen", verb: "mempunyai" },
                  set: { unit: "elemen", verb: "mempunyai" },
                }),
                (t = {
                  regex: "input",
                  email: "alamat e-mel",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "tarikh masa ISO",
                  date: "tarikh ISO",
                  time: "masa ISO",
                  duration: "tempoh ISO",
                  ipv4: "alamat IPv4",
                  ipv6: "alamat IPv6",
                  cidrv4: "julat IPv4",
                  cidrv6: "julat IPv6",
                  base64: "string dikodkan base64",
                  base64url: "string dikodkan base64url",
                  json_string: "string JSON",
                  e164: "nombor E.164",
                  jwt: "JWT",
                  template_literal: "input",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Input tidak sah: dijangka ${i.expected}, diterima ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "nombor";
                          case "object":
                            if (Array.isArray(e)) return "array";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `Input tidak sah: dijangka ${P(i.values[0])}`;
                      return `Pilihan tidak sah: dijangka salah satu daripada ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Terlalu besar: dijangka ${i.origin ?? "nilai"} ${r.verb} ${t}${i.maximum.toString()} ${r.unit ?? "elemen"}`;
                      return `Terlalu besar: dijangka ${i.origin ?? "nilai"} adalah ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Terlalu kecil: dijangka ${i.origin} ${r.verb} ${t}${i.minimum.toString()} ${r.unit}`;
                      return `Terlalu kecil: dijangka ${i.origin} adalah ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `String tidak sah: mesti bermula dengan "${i.prefix}"`;
                      if ("ends_with" === i.format)
                        return `String tidak sah: mesti berakhir dengan "${i.suffix}"`;
                      if ("includes" === i.format)
                        return `String tidak sah: mesti mengandungi "${i.includes}"`;
                      if ("regex" === i.format)
                        return `String tidak sah: mesti sepadan dengan corak ${i.pattern}`;
                      return `${t[i.format] ?? i.format} tidak sah`;
                    case "not_multiple_of":
                      return `Nombor tidak sah: perlu gandaan ${i.divisor}`;
                    case "unrecognized_keys":
                      return `Kunci tidak dikenali: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Kunci tidak sah dalam ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Input tidak sah";
                    case "invalid_element":
                      return `Nilai tidak sah dalam ${i.origin}`;
                  }
                }),
            };
          },
          "nl",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "tekens" },
                  file: { unit: "bytes" },
                  array: { unit: "elementen" },
                  set: { unit: "elementen" },
                }),
                (t = {
                  regex: "invoer",
                  email: "emailadres",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO datum en tijd",
                  date: "ISO datum",
                  time: "ISO tijd",
                  duration: "ISO duur",
                  ipv4: "IPv4-adres",
                  ipv6: "IPv6-adres",
                  cidrv4: "IPv4-bereik",
                  cidrv6: "IPv6-bereik",
                  base64: "base64-gecodeerde tekst",
                  base64url: "base64 URL-gecodeerde tekst",
                  json_string: "JSON string",
                  e164: "E.164-nummer",
                  jwt: "JWT",
                  template_literal: "invoer",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Ongeldige invoer: verwacht ${i.expected}, ontving ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "getal";
                          case "object":
                            if (Array.isArray(e)) return "array";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `Ongeldige invoer: verwacht ${P(i.values[0])}`;
                      return `Ongeldige optie: verwacht \xe9\xe9n van ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Te lang: verwacht dat ${i.origin ?? "waarde"} ${t}${i.maximum.toString()} ${r.unit ?? "elementen"} bevat`;
                      return `Te lang: verwacht dat ${i.origin ?? "waarde"} ${t}${i.maximum.toString()} is`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Te kort: verwacht dat ${i.origin} ${t}${i.minimum.toString()} ${r.unit} bevat`;
                      return `Te kort: verwacht dat ${i.origin} ${t}${i.minimum.toString()} is`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `Ongeldige tekst: moet met "${i.prefix}" beginnen`;
                      if ("ends_with" === i.format) return `Ongeldige tekst: moet op "${i.suffix}" eindigen`;
                      if ("includes" === i.format) return `Ongeldige tekst: moet "${i.includes}" bevatten`;
                      if ("regex" === i.format)
                        return `Ongeldige tekst: moet overeenkomen met patroon ${i.pattern}`;
                      return `Ongeldig: ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `Ongeldig getal: moet een veelvoud van ${i.divisor} zijn`;
                    case "unrecognized_keys":
                      return `Onbekende key${i.keys.length > 1 ? "s" : ""}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Ongeldige key in ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Ongeldige invoer";
                    case "invalid_element":
                      return `Ongeldige waarde in ${i.origin}`;
                  }
                }),
            };
          },
          "no",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "tegn", verb: "å ha" },
                  file: { unit: "bytes", verb: "å ha" },
                  array: { unit: "elementer", verb: "å inneholde" },
                  set: { unit: "elementer", verb: "å inneholde" },
                }),
                (t = {
                  regex: "input",
                  email: "e-postadresse",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO dato- og klokkeslett",
                  date: "ISO-dato",
                  time: "ISO-klokkeslett",
                  duration: "ISO-varighet",
                  ipv4: "IPv4-område",
                  ipv6: "IPv6-område",
                  cidrv4: "IPv4-spekter",
                  cidrv6: "IPv6-spekter",
                  base64: "base64-enkodet streng",
                  base64url: "base64url-enkodet streng",
                  json_string: "JSON-streng",
                  e164: "E.164-nummer",
                  jwt: "JWT",
                  template_literal: "input",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Ugyldig input: forventet ${i.expected}, fikk ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "tall";
                          case "object":
                            if (Array.isArray(e)) return "liste";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `Ugyldig verdi: forventet ${P(i.values[0])}`;
                      return `Ugyldig valg: forventet en av ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `For stor(t): forventet ${i.origin ?? "value"} til \xe5 ha ${t}${i.maximum.toString()} ${r.unit ?? "elementer"}`;
                      return `For stor(t): forventet ${i.origin ?? "value"} til \xe5 ha ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `For lite(n): forventet ${i.origin} til \xe5 ha ${t}${i.minimum.toString()} ${r.unit}`;
                      return `For lite(n): forventet ${i.origin} til \xe5 ha ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format) return `Ugyldig streng: m\xe5 starte med "${i.prefix}"`;
                      if ("ends_with" === i.format) return `Ugyldig streng: m\xe5 ende med "${i.suffix}"`;
                      if ("includes" === i.format) return `Ugyldig streng: m\xe5 inneholde "${i.includes}"`;
                      if ("regex" === i.format)
                        return `Ugyldig streng: m\xe5 matche m\xf8nsteret ${i.pattern}`;
                      return `Ugyldig ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `Ugyldig tall: m\xe5 v\xe6re et multiplum av ${i.divisor}`;
                    case "unrecognized_keys":
                      return `${i.keys.length > 1 ? "Ukjente nøkler" : "Ukjent nøkkel"}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Ugyldig n\xf8kkel i ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Ugyldig input";
                    case "invalid_element":
                      return `Ugyldig verdi i ${i.origin}`;
                  }
                }),
            };
          },
          "ota",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "harf", verb: "olmalıdır" },
                  file: { unit: "bayt", verb: "olmalıdır" },
                  array: { unit: "unsur", verb: "olmalıdır" },
                  set: { unit: "unsur", verb: "olmalıdır" },
                }),
                (t = {
                  regex: "giren",
                  email: "epostagâh",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO hengâmı",
                  date: "ISO tarihi",
                  time: "ISO zamanı",
                  duration: "ISO müddeti",
                  ipv4: "IPv4 nişânı",
                  ipv6: "IPv6 nişânı",
                  cidrv4: "IPv4 menzili",
                  cidrv6: "IPv6 menzili",
                  base64: "base64-şifreli metin",
                  base64url: "base64url-şifreli metin",
                  json_string: "JSON metin",
                  e164: "E.164 sayısı",
                  jwt: "JWT",
                  template_literal: "giren",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `F\xe2sit giren: umulan ${i.expected}, alınan ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "numara";
                          case "object":
                            if (Array.isArray(e)) return "saf";
                            if (null === e) return "gayb";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `F\xe2sit giren: umulan ${P(i.values[0])}`;
                      return `F\xe2sit tercih: m\xfbteberler ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Fazla b\xfcy\xfck: ${i.origin ?? "value"}, ${t}${i.maximum.toString()} ${r.unit ?? "elements"} sahip olmalıydı.`;
                      return `Fazla b\xfcy\xfck: ${i.origin ?? "value"}, ${t}${i.maximum.toString()} olmalıydı.`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Fazla k\xfc\xe7\xfck: ${i.origin}, ${t}${i.minimum.toString()} ${r.unit} sahip olmalıydı.`;
                      return `Fazla k\xfc\xe7\xfck: ${i.origin}, ${t}${i.minimum.toString()} olmalıydı.`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format) return `F\xe2sit metin: "${i.prefix}" ile başlamalı.`;
                      if ("ends_with" === i.format) return `F\xe2sit metin: "${i.suffix}" ile bitmeli.`;
                      if ("includes" === i.format) return `F\xe2sit metin: "${i.includes}" ihtiv\xe2 etmeli.`;
                      if ("regex" === i.format) return `F\xe2sit metin: ${i.pattern} nakşına uymalı.`;
                      return `F\xe2sit ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `F\xe2sit sayı: ${i.divisor} katı olmalıydı.`;
                    case "unrecognized_keys":
                      return `Tanınmayan anahtar ${i.keys.length > 1 ? "s" : ""}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `${i.origin} i\xe7in tanınmayan anahtar var.`;
                    case "invalid_union":
                      return "Giren tanınamadı.";
                    case "invalid_element":
                      return `${i.origin} i\xe7in tanınmayan kıymet var.`;
                    default:
                      return "Kıymet tanınamadı.";
                  }
                }),
            };
          },
          "pl",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "znaków", verb: "mieć" },
                  file: { unit: "bajtów", verb: "mieć" },
                  array: { unit: "elementów", verb: "mieć" },
                  set: { unit: "elementów", verb: "mieć" },
                }),
                (t = {
                  regex: "wyrażenie",
                  email: "adres email",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "data i godzina w formacie ISO",
                  date: "data w formacie ISO",
                  time: "godzina w formacie ISO",
                  duration: "czas trwania ISO",
                  ipv4: "adres IPv4",
                  ipv6: "adres IPv6",
                  cidrv4: "zakres IPv4",
                  cidrv6: "zakres IPv6",
                  base64: "ciąg znaków zakodowany w formacie base64",
                  base64url: "ciąg znaków zakodowany w formacie base64url",
                  json_string: "ciąg znaków w formacie JSON",
                  e164: "liczba E.164",
                  jwt: "JWT",
                  template_literal: "wejście",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Nieprawidłowe dane wejściowe: oczekiwano ${i.expected}, otrzymano ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "liczba";
                          case "object":
                            if (Array.isArray(e)) return "tablica";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length)
                        return `Nieprawidłowe dane wejściowe: oczekiwano ${P(i.values[0])}`;
                      return `Nieprawidłowa opcja: oczekiwano jednej z wartości ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Za duża wartość: oczekiwano, że ${i.origin ?? "wartość"} będzie mieć ${t}${i.maximum.toString()} ${r.unit ?? "elementów"}`;
                      return `Zbyt duż(y/a/e): oczekiwano, że ${i.origin ?? "wartość"} będzie wynosić ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Za mała wartość: oczekiwano, że ${i.origin ?? "wartość"} będzie mieć ${t}${i.minimum.toString()} ${r.unit ?? "elementów"}`;
                      return `Zbyt mał(y/a/e): oczekiwano, że ${i.origin ?? "wartość"} będzie wynosić ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `Nieprawidłowy ciąg znak\xf3w: musi zaczynać się od "${i.prefix}"`;
                      if ("ends_with" === i.format)
                        return `Nieprawidłowy ciąg znak\xf3w: musi kończyć się na "${i.suffix}"`;
                      if ("includes" === i.format)
                        return `Nieprawidłowy ciąg znak\xf3w: musi zawierać "${i.includes}"`;
                      if ("regex" === i.format)
                        return `Nieprawidłowy ciąg znak\xf3w: musi odpowiadać wzorcowi ${i.pattern}`;
                      return `Nieprawidłow(y/a/e) ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `Nieprawidłowa liczba: musi być wielokrotnością ${i.divisor}`;
                    case "unrecognized_keys":
                      return `Nierozpoznane klucze${i.keys.length > 1 ? "s" : ""}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Nieprawidłowy klucz w ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Nieprawidłowe dane wejściowe";
                    case "invalid_element":
                      return `Nieprawidłowa wartość w ${i.origin}`;
                  }
                }),
            };
          },
          "ps",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "توکي", verb: "ولري" },
                  file: { unit: "بایټس", verb: "ولري" },
                  array: { unit: "توکي", verb: "ولري" },
                  set: { unit: "توکي", verb: "ولري" },
                }),
                (t = {
                  regex: "ورودي",
                  email: "بریښنالیک",
                  url: "یو آر ال",
                  emoji: "ایموجي",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "نیټه او وخت",
                  date: "نېټه",
                  time: "وخت",
                  duration: "موده",
                  ipv4: "د IPv4 پته",
                  ipv6: "د IPv6 پته",
                  cidrv4: "د IPv4 ساحه",
                  cidrv6: "د IPv6 ساحه",
                  base64: "base64-encoded متن",
                  base64url: "base64url-encoded متن",
                  json_string: "JSON متن",
                  e164: "د E.164 شمېره",
                  jwt: "JWT",
                  template_literal: "ورودي",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `ناسم ورودي: باید ${i.expected} وای, مګر ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "عدد";
                          case "object":
                            if (Array.isArray(e)) return "ارې";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)} ترلاسه شو`;
                    case "invalid_value":
                      if (1 === i.values.length) return `ناسم ورودي: باید ${P(i.values[0])} وای`;
                      return `ناسم انتخاب: باید یو له ${c(i.values, "|")} څخه وای`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `ډیر لوی: ${i.origin ?? "ارزښت"} باید ${t}${i.maximum.toString()} ${r.unit ?? "عنصرونه"} ولري`;
                      return `ډیر لوی: ${i.origin ?? "ارزښت"} باید ${t}${i.maximum.toString()} وي`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r) return `ډیر کوچنی: ${i.origin} باید ${t}${i.minimum.toString()} ${r.unit} ولري`;
                      return `ډیر کوچنی: ${i.origin} باید ${t}${i.minimum.toString()} وي`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format) return `ناسم متن: باید د "${i.prefix}" سره پیل شي`;
                      if ("ends_with" === i.format) return `ناسم متن: باید د "${i.suffix}" سره پای ته ورسيږي`;
                      if ("includes" === i.format) return `ناسم متن: باید "${i.includes}" ولري`;
                      if ("regex" === i.format) return `ناسم متن: باید د ${i.pattern} سره مطابقت ولري`;
                      return `${t[i.format] ?? i.format} ناسم دی`;
                    case "not_multiple_of":
                      return `ناسم عدد: باید د ${i.divisor} مضرب وي`;
                    case "unrecognized_keys":
                      return `ناسم ${i.keys.length > 1 ? "کلیډونه" : "کلیډ"}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `ناسم کلیډ په ${i.origin} کې`;
                    case "invalid_union":
                    default:
                      return "ناسمه ورودي";
                    case "invalid_element":
                      return `ناسم عنصر په ${i.origin} کې`;
                  }
                }),
            };
          },
          "pt",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "caracteres", verb: "ter" },
                  file: { unit: "bytes", verb: "ter" },
                  array: { unit: "itens", verb: "ter" },
                  set: { unit: "itens", verb: "ter" },
                }),
                (t = {
                  regex: "padrão",
                  email: "endereço de e-mail",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "data e hora ISO",
                  date: "data ISO",
                  time: "hora ISO",
                  duration: "duração ISO",
                  ipv4: "endereço IPv4",
                  ipv6: "endereço IPv6",
                  cidrv4: "faixa de IPv4",
                  cidrv6: "faixa de IPv6",
                  base64: "texto codificado em base64",
                  base64url: "URL codificada em base64",
                  json_string: "texto JSON",
                  e164: "número E.164",
                  jwt: "JWT",
                  template_literal: "entrada",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Tipo inv\xe1lido: esperado ${i.expected}, recebido ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "número";
                          case "object":
                            if (Array.isArray(e)) return "array";
                            if (null === e) return "nulo";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `Entrada inv\xe1lida: esperado ${P(i.values[0])}`;
                      return `Op\xe7\xe3o inv\xe1lida: esperada uma das ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Muito grande: esperado que ${i.origin ?? "valor"} tivesse ${t}${i.maximum.toString()} ${r.unit ?? "elementos"}`;
                      return `Muito grande: esperado que ${i.origin ?? "valor"} fosse ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Muito pequeno: esperado que ${i.origin} tivesse ${t}${i.minimum.toString()} ${r.unit}`;
                      return `Muito pequeno: esperado que ${i.origin} fosse ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `Texto inv\xe1lido: deve come\xe7ar com "${i.prefix}"`;
                      if ("ends_with" === i.format)
                        return `Texto inv\xe1lido: deve terminar com "${i.suffix}"`;
                      if ("includes" === i.format) return `Texto inv\xe1lido: deve incluir "${i.includes}"`;
                      if ("regex" === i.format)
                        return `Texto inv\xe1lido: deve corresponder ao padr\xe3o ${i.pattern}`;
                      return `${t[i.format] ?? i.format} inv\xe1lido`;
                    case "not_multiple_of":
                      return `N\xfamero inv\xe1lido: deve ser m\xfaltiplo de ${i.divisor}`;
                    case "unrecognized_keys":
                      return `Chave${i.keys.length > 1 ? "s" : ""} desconhecida${i.keys.length > 1 ? "s" : ""}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Chave inv\xe1lida em ${i.origin}`;
                    case "invalid_union":
                      return "Entrada inválida";
                    case "invalid_element":
                      return `Valor inv\xe1lido em ${i.origin}`;
                    default:
                      return "Campo inválido";
                  }
                }),
            };
          },
          "ru",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: { one: "символ", few: "символа", many: "символов" }, verb: "иметь" },
                  file: { unit: { one: "байт", few: "байта", many: "байт" }, verb: "иметь" },
                  array: { unit: { one: "элемент", few: "элемента", many: "элементов" }, verb: "иметь" },
                  set: { unit: { one: "элемент", few: "элемента", many: "элементов" }, verb: "иметь" },
                }),
                (t = {
                  regex: "ввод",
                  email: "email адрес",
                  url: "URL",
                  emoji: "эмодзи",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO дата и время",
                  date: "ISO дата",
                  time: "ISO время",
                  duration: "ISO длительность",
                  ipv4: "IPv4 адрес",
                  ipv6: "IPv6 адрес",
                  cidrv4: "IPv4 диапазон",
                  cidrv6: "IPv6 диапазон",
                  base64: "строка в формате base64",
                  base64url: "строка в формате base64url",
                  json_string: "JSON строка",
                  e164: "номер E.164",
                  jwt: "JWT",
                  template_literal: "ввод",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Неверный ввод: ожидалось ${i.expected}, получено ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "число";
                          case "object":
                            if (Array.isArray(e)) return "массив";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `Неверный ввод: ожидалось ${P(i.values[0])}`;
                      return `Неверный вариант: ожидалось одно из ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r) {
                        let e = rn(Number(i.maximum), r.unit.one, r.unit.few, r.unit.many);
                        return `Слишком большое значение: ожидалось, что ${i.origin ?? "значение"} будет иметь ${t}${i.maximum.toString()} ${e}`;
                      }
                      return `Слишком большое значение: ожидалось, что ${i.origin ?? "значение"} будет ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r) {
                        let e = rn(Number(i.minimum), r.unit.one, r.unit.few, r.unit.many);
                        return `Слишком маленькое значение: ожидалось, что ${i.origin} будет иметь ${t}${i.minimum.toString()} ${e}`;
                      }
                      return `Слишком маленькое значение: ожидалось, что ${i.origin} будет ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `Неверная строка: должна начинаться с "${i.prefix}"`;
                      if ("ends_with" === i.format)
                        return `Неверная строка: должна заканчиваться на "${i.suffix}"`;
                      if ("includes" === i.format) return `Неверная строка: должна содержать "${i.includes}"`;
                      if ("regex" === i.format)
                        return `Неверная строка: должна соответствовать шаблону ${i.pattern}`;
                      return `Неверный ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `Неверное число: должно быть кратным ${i.divisor}`;
                    case "unrecognized_keys":
                      return `Нераспознанн${i.keys.length > 1 ? "ые" : "ый"} ключ${i.keys.length > 1 ? "и" : ""}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Неверный ключ в ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Неверные входные данные";
                    case "invalid_element":
                      return `Неверное значение в ${i.origin}`;
                  }
                }),
            };
          },
          "sl",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "znakov", verb: "imeti" },
                  file: { unit: "bajtov", verb: "imeti" },
                  array: { unit: "elementov", verb: "imeti" },
                  set: { unit: "elementov", verb: "imeti" },
                }),
                (t = {
                  regex: "vnos",
                  email: "e-poštni naslov",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO datum in čas",
                  date: "ISO datum",
                  time: "ISO čas",
                  duration: "ISO trajanje",
                  ipv4: "IPv4 naslov",
                  ipv6: "IPv6 naslov",
                  cidrv4: "obseg IPv4",
                  cidrv6: "obseg IPv6",
                  base64: "base64 kodiran niz",
                  base64url: "base64url kodiran niz",
                  json_string: "JSON niz",
                  e164: "E.164 številka",
                  jwt: "JWT",
                  template_literal: "vnos",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Neveljaven vnos: pričakovano ${i.expected}, prejeto ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "število";
                          case "object":
                            if (Array.isArray(e)) return "tabela";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `Neveljaven vnos: pričakovano ${P(i.values[0])}`;
                      return `Neveljavna možnost: pričakovano eno izmed ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Preveliko: pričakovano, da bo ${i.origin ?? "vrednost"} imelo ${t}${i.maximum.toString()} ${r.unit ?? "elementov"}`;
                      return `Preveliko: pričakovano, da bo ${i.origin ?? "vrednost"} ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Premajhno: pričakovano, da bo ${i.origin} imelo ${t}${i.minimum.toString()} ${r.unit}`;
                      return `Premajhno: pričakovano, da bo ${i.origin} ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format) return `Neveljaven niz: mora se začeti z "${i.prefix}"`;
                      if ("ends_with" === i.format) return `Neveljaven niz: mora se končati z "${i.suffix}"`;
                      if ("includes" === i.format) return `Neveljaven niz: mora vsebovati "${i.includes}"`;
                      if ("regex" === i.format) return `Neveljaven niz: mora ustrezati vzorcu ${i.pattern}`;
                      return `Neveljaven ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `Neveljavno število: mora biti večkratnik ${i.divisor}`;
                    case "unrecognized_keys":
                      return `Neprepoznan${i.keys.length > 1 ? "i ključi" : " ključ"}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Neveljaven ključ v ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Neveljaven vnos";
                    case "invalid_element":
                      return `Neveljavna vrednost v ${i.origin}`;
                  }
                }),
            };
          },
          "sv",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "tecken", verb: "att ha" },
                  file: { unit: "bytes", verb: "att ha" },
                  array: { unit: "objekt", verb: "att innehålla" },
                  set: { unit: "objekt", verb: "att innehålla" },
                }),
                (t = {
                  regex: "reguljärt uttryck",
                  email: "e-postadress",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO-datum och tid",
                  date: "ISO-datum",
                  time: "ISO-tid",
                  duration: "ISO-varaktighet",
                  ipv4: "IPv4-intervall",
                  ipv6: "IPv6-intervall",
                  cidrv4: "IPv4-spektrum",
                  cidrv6: "IPv6-spektrum",
                  base64: "base64-kodad sträng",
                  base64url: "base64url-kodad sträng",
                  json_string: "JSON-sträng",
                  e164: "E.164-nummer",
                  jwt: "JWT",
                  template_literal: "mall-literal",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Ogiltig inmatning: f\xf6rv\xe4ntat ${i.expected}, fick ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "antal";
                          case "object":
                            if (Array.isArray(e)) return "lista";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length)
                        return `Ogiltig inmatning: f\xf6rv\xe4ntat ${P(i.values[0])}`;
                      return `Ogiltigt val: f\xf6rv\xe4ntade en av ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `F\xf6r stor(t): f\xf6rv\xe4ntade ${i.origin ?? "värdet"} att ha ${t}${i.maximum.toString()} ${r.unit ?? "element"}`;
                      return `F\xf6r stor(t): f\xf6rv\xe4ntat ${i.origin ?? "värdet"} att ha ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `F\xf6r lite(t): f\xf6rv\xe4ntade ${i.origin ?? "värdet"} att ha ${t}${i.minimum.toString()} ${r.unit}`;
                      return `F\xf6r lite(t): f\xf6rv\xe4ntade ${i.origin ?? "värdet"} att ha ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `Ogiltig str\xe4ng: m\xe5ste b\xf6rja med "${i.prefix}"`;
                      if ("ends_with" === i.format)
                        return `Ogiltig str\xe4ng: m\xe5ste sluta med "${i.suffix}"`;
                      if ("includes" === i.format)
                        return `Ogiltig str\xe4ng: m\xe5ste inneh\xe5lla "${i.includes}"`;
                      if ("regex" === i.format)
                        return `Ogiltig str\xe4ng: m\xe5ste matcha m\xf6nstret "${i.pattern}"`;
                      return `Ogiltig(t) ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `Ogiltigt tal: m\xe5ste vara en multipel av ${i.divisor}`;
                    case "unrecognized_keys":
                      return `${i.keys.length > 1 ? "Okända nycklar" : "Okänd nyckel"}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Ogiltig nyckel i ${i.origin ?? "värdet"}`;
                    case "invalid_union":
                    default:
                      return "Ogiltig input";
                    case "invalid_element":
                      return `Ogiltigt v\xe4rde i ${i.origin ?? "värdet"}`;
                  }
                }),
            };
          },
          "ta",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "எழுத்துக்கள்", verb: "கொண்டிருக்க வேண்டும்" },
                  file: { unit: "பைட்டுகள்", verb: "கொண்டிருக்க வேண்டும்" },
                  array: { unit: "உறுப்புகள்", verb: "கொண்டிருக்க வேண்டும்" },
                  set: { unit: "உறுப்புகள்", verb: "கொண்டிருக்க வேண்டும்" },
                }),
                (t = {
                  regex: "உள்ளீடு",
                  email: "மின்னஞ்சல் முகவரி",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO தேதி நேரம்",
                  date: "ISO தேதி",
                  time: "ISO நேரம்",
                  duration: "ISO கால அளவு",
                  ipv4: "IPv4 முகவரி",
                  ipv6: "IPv6 முகவரி",
                  cidrv4: "IPv4 வரம்பு",
                  cidrv6: "IPv6 வரம்பு",
                  base64: "base64-encoded சரம்",
                  base64url: "base64url-encoded சரம்",
                  json_string: "JSON சரம்",
                  e164: "E.164 எண்",
                  jwt: "JWT",
                  template_literal: "input",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `தவறான உள்ளீடு: எதிர்பார்க்கப்பட்டது ${i.expected}, பெறப்பட்டது ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "எண் அல்லாதது" : "எண்";
                          case "object":
                            if (Array.isArray(e)) return "அணி";
                            if (null === e) return "வெறுமை";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length)
                        return `தவறான உள்ளீடு: எதிர்பார்க்கப்பட்டது ${P(i.values[0])}`;
                      return `தவறான விருப்பம்: எதிர்பார்க்கப்பட்டது ${c(i.values, "|")} இல் ஒன்று`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `மிக பெரியது: எதிர்பார்க்கப்பட்டது ${i.origin ?? "மதிப்பு"} ${t}${i.maximum.toString()} ${r.unit ?? "உறுப்புகள்"} ஆக இருக்க வேண்டும்`;
                      return `மிக பெரியது: எதிர்பார்க்கப்பட்டது ${i.origin ?? "மதிப்பு"} ${t}${i.maximum.toString()} ஆக இருக்க வேண்டும்`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `மிகச் சிறியது: எதிர்பார்க்கப்பட்டது ${i.origin} ${t}${i.minimum.toString()} ${r.unit} ஆக இருக்க வேண்டும்`;
                      return `மிகச் சிறியது: எதிர்பார்க்கப்பட்டது ${i.origin} ${t}${i.minimum.toString()} ஆக இருக்க வேண்டும்`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format) return `தவறான சரம்: "${i.prefix}" இல் தொடங்க வேண்டும்`;
                      if ("ends_with" === i.format) return `தவறான சரம்: "${i.suffix}" இல் முடிவடைய வேண்டும்`;
                      if ("includes" === i.format) return `தவறான சரம்: "${i.includes}" ஐ உள்ளடக்க வேண்டும்`;
                      if ("regex" === i.format)
                        return `தவறான சரம்: ${i.pattern} முறைபாட்டுடன் பொருந்த வேண்டும்`;
                      return `தவறான ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `தவறான எண்: ${i.divisor} இன் பலமாக இருக்க வேண்டும்`;
                    case "unrecognized_keys":
                      return `அடையாளம் தெரியாத விசை${i.keys.length > 1 ? "கள்" : ""}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `${i.origin} இல் தவறான விசை`;
                    case "invalid_union":
                    default:
                      return "தவறான உள்ளீடு";
                    case "invalid_element":
                      return `${i.origin} இல் தவறான மதிப்பு`;
                  }
                }),
            };
          },
          "th",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "ตัวอักษร", verb: "ควรมี" },
                  file: { unit: "ไบต์", verb: "ควรมี" },
                  array: { unit: "รายการ", verb: "ควรมี" },
                  set: { unit: "รายการ", verb: "ควรมี" },
                }),
                (t = {
                  regex: "ข้อมูลที่ป้อน",
                  email: "ที่อยู่อีเมล",
                  url: "URL",
                  emoji: "อิโมจิ",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "วันที่เวลาแบบ ISO",
                  date: "วันที่แบบ ISO",
                  time: "เวลาแบบ ISO",
                  duration: "ช่วงเวลาแบบ ISO",
                  ipv4: "ที่อยู่ IPv4",
                  ipv6: "ที่อยู่ IPv6",
                  cidrv4: "ช่วง IP แบบ IPv4",
                  cidrv6: "ช่วง IP แบบ IPv6",
                  base64: "ข้อความแบบ Base64",
                  base64url: "ข้อความแบบ Base64 สำหรับ URL",
                  json_string: "ข้อความแบบ JSON",
                  e164: "เบอร์โทรศัพท์ระหว่างประเทศ (E.164)",
                  jwt: "โทเคน JWT",
                  template_literal: "ข้อมูลที่ป้อน",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `ประเภทข้อมูลไม่ถูกต้อง: ควรเป็น ${i.expected} แต่ได้รับ ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "ไม่ใช่ตัวเลข (NaN)" : "ตัวเลข";
                          case "object":
                            if (Array.isArray(e)) return "อาร์เรย์ (Array)";
                            if (null === e) return "ไม่มีค่า (null)";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `ค่าไม่ถูกต้อง: ควรเป็น ${P(i.values[0])}`;
                      return `ตัวเลือกไม่ถูกต้อง: ควรเป็นหนึ่งใน ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "ไม่เกิน" : "น้อยกว่า",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `เกินกำหนด: ${i.origin ?? "ค่า"} ควรมี${t} ${i.maximum.toString()} ${r.unit ?? "รายการ"}`;
                      return `เกินกำหนด: ${i.origin ?? "ค่า"} ควรมี${t} ${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? "อย่างน้อย" : "มากกว่า",
                        r = e[i.origin] ?? null;
                      if (r) return `น้อยกว่ากำหนด: ${i.origin} ควรมี${t} ${i.minimum.toString()} ${r.unit}`;
                      return `น้อยกว่ากำหนด: ${i.origin} ควรมี${t} ${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `รูปแบบไม่ถูกต้อง: ข้อความต้องขึ้นต้นด้วย "${i.prefix}"`;
                      if ("ends_with" === i.format)
                        return `รูปแบบไม่ถูกต้อง: ข้อความต้องลงท้ายด้วย "${i.suffix}"`;
                      if ("includes" === i.format)
                        return `รูปแบบไม่ถูกต้อง: ข้อความต้องมี "${i.includes}" อยู่ในข้อความ`;
                      if ("regex" === i.format)
                        return `รูปแบบไม่ถูกต้อง: ต้องตรงกับรูปแบบที่กำหนด ${i.pattern}`;
                      return `รูปแบบไม่ถูกต้อง: ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `ตัวเลขไม่ถูกต้อง: ต้องเป็นจำนวนที่หารด้วย ${i.divisor} ได้ลงตัว`;
                    case "unrecognized_keys":
                      return `พบคีย์ที่ไม่รู้จัก: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `คีย์ไม่ถูกต้องใน ${i.origin}`;
                    case "invalid_union":
                      return "ข้อมูลไม่ถูกต้อง: ไม่ตรงกับรูปแบบยูเนียนที่กำหนดไว้";
                    case "invalid_element":
                      return `ข้อมูลไม่ถูกต้องใน ${i.origin}`;
                    default:
                      return "ข้อมูลไม่ถูกต้อง";
                  }
                }),
            };
          },
          "tr",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "karakter", verb: "olmalı" },
                  file: { unit: "bayt", verb: "olmalı" },
                  array: { unit: "öğe", verb: "olmalı" },
                  set: { unit: "öğe", verb: "olmalı" },
                }),
                (t = {
                  regex: "girdi",
                  email: "e-posta adresi",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO tarih ve saat",
                  date: "ISO tarih",
                  time: "ISO saat",
                  duration: "ISO süre",
                  ipv4: "IPv4 adresi",
                  ipv6: "IPv6 adresi",
                  cidrv4: "IPv4 aralığı",
                  cidrv6: "IPv6 aralığı",
                  base64: "base64 ile şifrelenmiş metin",
                  base64url: "base64url ile şifrelenmiş metin",
                  json_string: "JSON dizesi",
                  e164: "E.164 sayısı",
                  jwt: "JWT",
                  template_literal: "Şablon dizesi",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Ge\xe7ersiz değer: beklenen ${i.expected}, alınan ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "number";
                          case "object":
                            if (Array.isArray(e)) return "array";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `Ge\xe7ersiz değer: beklenen ${P(i.values[0])}`;
                      return `Ge\xe7ersiz se\xe7enek: aşağıdakilerden biri olmalı: ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `\xc7ok b\xfcy\xfck: beklenen ${i.origin ?? "değer"} ${t}${i.maximum.toString()} ${r.unit ?? "öğe"}`;
                      return `\xc7ok b\xfcy\xfck: beklenen ${i.origin ?? "değer"} ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `\xc7ok k\xfc\xe7\xfck: beklenen ${i.origin} ${t}${i.minimum.toString()} ${r.unit}`;
                      return `\xc7ok k\xfc\xe7\xfck: beklenen ${i.origin} ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format) return `Ge\xe7ersiz metin: "${i.prefix}" ile başlamalı`;
                      if ("ends_with" === i.format) return `Ge\xe7ersiz metin: "${i.suffix}" ile bitmeli`;
                      if ("includes" === i.format) return `Ge\xe7ersiz metin: "${i.includes}" i\xe7ermeli`;
                      if ("regex" === i.format) return `Ge\xe7ersiz metin: ${i.pattern} desenine uymalı`;
                      return `Ge\xe7ersiz ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `Ge\xe7ersiz sayı: ${i.divisor} ile tam b\xf6l\xfcnebilmeli`;
                    case "unrecognized_keys":
                      return `Tanınmayan anahtar${i.keys.length > 1 ? "lar" : ""}: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `${i.origin} i\xe7inde ge\xe7ersiz anahtar`;
                    case "invalid_union":
                    default:
                      return "Geçersiz değer";
                    case "invalid_element":
                      return `${i.origin} i\xe7inde ge\xe7ersiz değer`;
                  }
                }),
            };
          },
          "ua",
          0,
          function () {
            return ra();
          },
          "uk",
          0,
          ra,
          "ur",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "حروف", verb: "ہونا" },
                  file: { unit: "بائٹس", verb: "ہونا" },
                  array: { unit: "آئٹمز", verb: "ہونا" },
                  set: { unit: "آئٹمز", verb: "ہونا" },
                }),
                (t = {
                  regex: "ان پٹ",
                  email: "ای میل ایڈریس",
                  url: "یو آر ایل",
                  emoji: "ایموجی",
                  uuid: "یو یو آئی ڈی",
                  uuidv4: "یو یو آئی ڈی وی 4",
                  uuidv6: "یو یو آئی ڈی وی 6",
                  nanoid: "نینو آئی ڈی",
                  guid: "جی یو آئی ڈی",
                  cuid: "سی یو آئی ڈی",
                  cuid2: "سی یو آئی ڈی 2",
                  ulid: "یو ایل آئی ڈی",
                  xid: "ایکس آئی ڈی",
                  ksuid: "کے ایس یو آئی ڈی",
                  datetime: "آئی ایس او ڈیٹ ٹائم",
                  date: "آئی ایس او تاریخ",
                  time: "آئی ایس او وقت",
                  duration: "آئی ایس او مدت",
                  ipv4: "آئی پی وی 4 ایڈریس",
                  ipv6: "آئی پی وی 6 ایڈریس",
                  cidrv4: "آئی پی وی 4 رینج",
                  cidrv6: "آئی پی وی 6 رینج",
                  base64: "بیس 64 ان کوڈڈ سٹرنگ",
                  base64url: "بیس 64 یو آر ایل ان کوڈڈ سٹرنگ",
                  json_string: "جے ایس او این سٹرنگ",
                  e164: "ای 164 نمبر",
                  jwt: "جے ڈبلیو ٹی",
                  template_literal: "ان پٹ",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `غلط ان پٹ: ${i.expected} متوقع تھا، ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "نمبر";
                          case "object":
                            if (Array.isArray(e)) return "آرے";
                            if (null === e) return "نل";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)} موصول ہوا`;
                    case "invalid_value":
                      if (1 === i.values.length) return `غلط ان پٹ: ${P(i.values[0])} متوقع تھا`;
                      return `غلط آپشن: ${c(i.values, "|")} میں سے ایک متوقع تھا`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `بہت بڑا: ${i.origin ?? "ویلیو"} کے ${t}${i.maximum.toString()} ${r.unit ?? "عناصر"} ہونے متوقع تھے`;
                      return `بہت بڑا: ${i.origin ?? "ویلیو"} کا ${t}${i.maximum.toString()} ہونا متوقع تھا`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `بہت چھوٹا: ${i.origin} کے ${t}${i.minimum.toString()} ${r.unit} ہونے متوقع تھے`;
                      return `بہت چھوٹا: ${i.origin} کا ${t}${i.minimum.toString()} ہونا متوقع تھا`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format) return `غلط سٹرنگ: "${i.prefix}" سے شروع ہونا چاہیے`;
                      if ("ends_with" === i.format) return `غلط سٹرنگ: "${i.suffix}" پر ختم ہونا چاہیے`;
                      if ("includes" === i.format) return `غلط سٹرنگ: "${i.includes}" شامل ہونا چاہیے`;
                      if ("regex" === i.format) return `غلط سٹرنگ: پیٹرن ${i.pattern} سے میچ ہونا چاہیے`;
                      return `غلط ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `غلط نمبر: ${i.divisor} کا مضاعف ہونا چاہیے`;
                    case "unrecognized_keys":
                      return `غیر تسلیم شدہ کی${i.keys.length > 1 ? "ز" : ""}: ${c(i.keys, "، ")}`;
                    case "invalid_key":
                      return `${i.origin} میں غلط کی`;
                    case "invalid_union":
                    default:
                      return "غلط ان پٹ";
                    case "invalid_element":
                      return `${i.origin} میں غلط ویلیو`;
                  }
                }),
            };
          },
          "vi",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "ký tự", verb: "có" },
                  file: { unit: "byte", verb: "có" },
                  array: { unit: "phần tử", verb: "có" },
                  set: { unit: "phần tử", verb: "có" },
                }),
                (t = {
                  regex: "đầu vào",
                  email: "địa chỉ email",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ngày giờ ISO",
                  date: "ngày ISO",
                  time: "giờ ISO",
                  duration: "khoảng thời gian ISO",
                  ipv4: "địa chỉ IPv4",
                  ipv6: "địa chỉ IPv6",
                  cidrv4: "dải IPv4",
                  cidrv6: "dải IPv6",
                  base64: "chuỗi mã hóa base64",
                  base64url: "chuỗi mã hóa base64url",
                  json_string: "chuỗi JSON",
                  e164: "số E.164",
                  jwt: "JWT",
                  template_literal: "đầu vào",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `Đầu v\xe0o kh\xf4ng hợp lệ: mong đợi ${i.expected}, nhận được ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "số";
                          case "object":
                            if (Array.isArray(e)) return "mảng";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length)
                        return `Đầu v\xe0o kh\xf4ng hợp lệ: mong đợi ${P(i.values[0])}`;
                      return `T\xf9y chọn kh\xf4ng hợp lệ: mong đợi một trong c\xe1c gi\xe1 trị ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Qu\xe1 lớn: mong đợi ${i.origin ?? "giá trị"} ${r.verb} ${t}${i.maximum.toString()} ${r.unit ?? "phần tử"}`;
                      return `Qu\xe1 lớn: mong đợi ${i.origin ?? "giá trị"} ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `Qu\xe1 nhỏ: mong đợi ${i.origin} ${r.verb} ${t}${i.minimum.toString()} ${r.unit}`;
                      return `Qu\xe1 nhỏ: mong đợi ${i.origin} ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format)
                        return `Chuỗi kh\xf4ng hợp lệ: phải bắt đầu bằng "${i.prefix}"`;
                      if ("ends_with" === i.format)
                        return `Chuỗi kh\xf4ng hợp lệ: phải kết th\xfac bằng "${i.suffix}"`;
                      if ("includes" === i.format)
                        return `Chuỗi kh\xf4ng hợp lệ: phải bao gồm "${i.includes}"`;
                      if ("regex" === i.format)
                        return `Chuỗi kh\xf4ng hợp lệ: phải khớp với mẫu ${i.pattern}`;
                      return `${t[i.format] ?? i.format} kh\xf4ng hợp lệ`;
                    case "not_multiple_of":
                      return `Số kh\xf4ng hợp lệ: phải l\xe0 bội số của ${i.divisor}`;
                    case "unrecognized_keys":
                      return `Kh\xf3a kh\xf4ng được nhận dạng: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Kh\xf3a kh\xf4ng hợp lệ trong ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Đầu vào không hợp lệ";
                    case "invalid_element":
                      return `Gi\xe1 trị kh\xf4ng hợp lệ trong ${i.origin}`;
                  }
                }),
            };
          },
          "yo",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "àmi", verb: "ní" },
                  file: { unit: "bytes", verb: "ní" },
                  array: { unit: "nkan", verb: "ní" },
                  set: { unit: "nkan", verb: "ní" },
                }),
                (t = {
                  regex: "ẹ̀rọ ìbáwọlé",
                  email: "àdírẹ́sì ìmẹ́lì",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "àkókò ISO",
                  date: "ọjọ́ ISO",
                  time: "àkókò ISO",
                  duration: "àkókò tó pé ISO",
                  ipv4: "àdírẹ́sì IPv4",
                  ipv6: "àdírẹ́sì IPv6",
                  cidrv4: "àgbègbè IPv4",
                  cidrv6: "àgbègbè IPv6",
                  base64: "ọ̀rọ̀ tí a kọ́ ní base64",
                  base64url: "ọ̀rọ̀ base64url",
                  json_string: "ọ̀rọ̀ JSON",
                  e164: "nọ́mbà E.164",
                  jwt: "JWT",
                  template_literal: "ẹ̀rọ ìbáwọlé",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `\xccb\xe1wọl\xe9 aṣ\xecṣe: a n\xed l\xe1ti fi ${i.expected}, \xe0mọ̀ a r\xed ${((
                        e,
                      ) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "nọ́mbà";
                          case "object":
                            if (Array.isArray(e)) return "akopọ";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length)
                        return `\xccb\xe1wọl\xe9 aṣ\xecṣe: a n\xed l\xe1ti fi ${P(i.values[0])}`;
                      return `\xc0ṣ\xe0y\xe0n aṣ\xecṣe: yan ọ̀kan l\xe1ra ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `T\xf3 pọ̀ j\xf9: a n\xed l\xe1ti jẹ́ p\xe9 ${i.origin ?? "iye"} ${r.verb} ${t}${i.maximum} ${r.unit}`;
                      return `T\xf3 pọ̀ j\xf9: a n\xed l\xe1ti jẹ́ ${t}${i.maximum}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `K\xe9r\xe9 ju: a n\xed l\xe1ti jẹ́ p\xe9 ${i.origin} ${r.verb} ${t}${i.minimum} ${r.unit}`;
                      return `K\xe9r\xe9 ju: a n\xed l\xe1ti jẹ́ ${t}${i.minimum}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format) return `Ọ̀rọ̀ aṣ\xecṣe: gbọ́dọ̀ bẹ̀rẹ̀ pẹ̀l\xfa "${i.prefix}"`;
                      if ("ends_with" === i.format)
                        return `Ọ̀rọ̀ aṣ\xecṣe: gbọ́dọ̀ par\xed pẹ̀l\xfa "${i.suffix}"`;
                      if ("includes" === i.format) return `Ọ̀rọ̀ aṣ\xecṣe: gbọ́dọ̀ n\xed "${i.includes}"`;
                      if ("regex" === i.format) return `Ọ̀rọ̀ aṣ\xecṣe: gbọ́dọ̀ b\xe1 \xe0pẹẹrẹ mu ${i.pattern}`;
                      return `Aṣ\xecṣe: ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `Nọ́mb\xe0 aṣ\xecṣe: gbọ́dọ̀ jẹ́ \xe8y\xe0 p\xedp\xedn ti ${i.divisor}`;
                    case "unrecognized_keys":
                      return `Bọt\xecn\xec \xe0\xecmọ̀: ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `Bọt\xecn\xec aṣ\xecṣe n\xedn\xfa ${i.origin}`;
                    case "invalid_union":
                    default:
                      return "Ìbáwọlé aṣìṣe";
                    case "invalid_element":
                      return `Iye aṣ\xecṣe n\xedn\xfa ${i.origin}`;
                  }
                }),
            };
          },
          "zhCN",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "字符", verb: "包含" },
                  file: { unit: "字节", verb: "包含" },
                  array: { unit: "项", verb: "包含" },
                  set: { unit: "项", verb: "包含" },
                }),
                (t = {
                  regex: "输入",
                  email: "电子邮件",
                  url: "URL",
                  emoji: "表情符号",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO日期时间",
                  date: "ISO日期",
                  time: "ISO时间",
                  duration: "ISO时长",
                  ipv4: "IPv4地址",
                  ipv6: "IPv6地址",
                  cidrv4: "IPv4网段",
                  cidrv6: "IPv6网段",
                  base64: "base64编码字符串",
                  base64url: "base64url编码字符串",
                  json_string: "JSON字符串",
                  e164: "E.164号码",
                  jwt: "JWT",
                  template_literal: "输入",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `无效输入：期望 ${i.expected}，实际接收 ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "非数字(NaN)" : "数字";
                          case "object":
                            if (Array.isArray(e)) return "数组";
                            if (null === e) return "空值(null)";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `无效输入：期望 ${P(i.values[0])}`;
                      return `无效选项：期望以下之一 ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `数值过大：期望 ${i.origin ?? "值"} ${t}${i.maximum.toString()} ${r.unit ?? "个元素"}`;
                      return `数值过大：期望 ${i.origin ?? "值"} ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r) return `数值过小：期望 ${i.origin} ${t}${i.minimum.toString()} ${r.unit}`;
                      return `数值过小：期望 ${i.origin} ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format) return `无效字符串：必须以 "${i.prefix}" 开头`;
                      if ("ends_with" === i.format) return `无效字符串：必须以 "${i.suffix}" 结尾`;
                      if ("includes" === i.format) return `无效字符串：必须包含 "${i.includes}"`;
                      if ("regex" === i.format) return `无效字符串：必须满足正则表达式 ${i.pattern}`;
                      return `无效${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `无效数字：必须是 ${i.divisor} 的倍数`;
                    case "unrecognized_keys":
                      return `出现未知的键(key): ${c(i.keys, ", ")}`;
                    case "invalid_key":
                      return `${i.origin} 中的键(key)无效`;
                    case "invalid_union":
                    default:
                      return "无效输入";
                    case "invalid_element":
                      return `${i.origin} 中包含无效值(value)`;
                  }
                }),
            };
          },
          "zhTW",
          0,
          function () {
            let e, t;
            return {
              localeError:
                ((e = {
                  string: { unit: "字元", verb: "擁有" },
                  file: { unit: "位元組", verb: "擁有" },
                  array: { unit: "項目", verb: "擁有" },
                  set: { unit: "項目", verb: "擁有" },
                }),
                (t = {
                  regex: "輸入",
                  email: "郵件地址",
                  url: "URL",
                  emoji: "emoji",
                  uuid: "UUID",
                  uuidv4: "UUIDv4",
                  uuidv6: "UUIDv6",
                  nanoid: "nanoid",
                  guid: "GUID",
                  cuid: "cuid",
                  cuid2: "cuid2",
                  ulid: "ULID",
                  xid: "XID",
                  ksuid: "KSUID",
                  datetime: "ISO 日期時間",
                  date: "ISO 日期",
                  time: "ISO 時間",
                  duration: "ISO 期間",
                  ipv4: "IPv4 位址",
                  ipv6: "IPv6 位址",
                  cidrv4: "IPv4 範圍",
                  cidrv6: "IPv6 範圍",
                  base64: "base64 編碼字串",
                  base64url: "base64url 編碼字串",
                  json_string: "JSON 字串",
                  e164: "E.164 數值",
                  jwt: "JWT",
                  template_literal: "輸入",
                }),
                (i) => {
                  switch (i.code) {
                    case "invalid_type":
                      return `無效的輸入值：預期為 ${i.expected}，但收到 ${((e) => {
                        let t = typeof e;
                        switch (t) {
                          case "number":
                            return Number.isNaN(e) ? "NaN" : "number";
                          case "object":
                            if (Array.isArray(e)) return "array";
                            if (null === e) return "null";
                            if (Object.getPrototypeOf(e) !== Object.prototype && e.constructor)
                              return e.constructor.name;
                        }
                        return t;
                      })(i.input)}`;
                    case "invalid_value":
                      if (1 === i.values.length) return `無效的輸入值：預期為 ${P(i.values[0])}`;
                      return `無效的選項：預期為以下其中之一 ${c(i.values, "|")}`;
                    case "too_big": {
                      let t = i.inclusive ? "<=" : "<",
                        r = e[i.origin] ?? null;
                      if (r)
                        return `數值過大：預期 ${i.origin ?? "值"} 應為 ${t}${i.maximum.toString()} ${r.unit ?? "個元素"}`;
                      return `數值過大：預期 ${i.origin ?? "值"} 應為 ${t}${i.maximum.toString()}`;
                    }
                    case "too_small": {
                      let t = i.inclusive ? ">=" : ">",
                        r = e[i.origin] ?? null;
                      if (r) return `數值過小：預期 ${i.origin} 應為 ${t}${i.minimum.toString()} ${r.unit}`;
                      return `數值過小：預期 ${i.origin} 應為 ${t}${i.minimum.toString()}`;
                    }
                    case "invalid_format":
                      if ("starts_with" === i.format) return `無效的字串：必須以 "${i.prefix}" 開頭`;
                      if ("ends_with" === i.format) return `無效的字串：必須以 "${i.suffix}" 結尾`;
                      if ("includes" === i.format) return `無效的字串：必須包含 "${i.includes}"`;
                      if ("regex" === i.format) return `無效的字串：必須符合格式 ${i.pattern}`;
                      return `無效的 ${t[i.format] ?? i.format}`;
                    case "not_multiple_of":
                      return `無效的數字：必須為 ${i.divisor} 的倍數`;
                    case "unrecognized_keys":
                      return `無法識別的鍵值${i.keys.length > 1 ? "們" : ""}：${c(i.keys, "、")}`;
                    case "invalid_key":
                      return `${i.origin} 中有無效的鍵值`;
                    case "invalid_union":
                    default:
                      return "無效的輸入值";
                    case "invalid_element":
                      return `${i.origin} 中有無效的值`;
                  }
                }),
            };
          },
        ],
        554580,
      ));
    var uY = e.i(554580);
    (e.i(525527), e.i(698530), e.i(650215), e.i(34966), e.s([], 818249));
    var uH = e.i(818249);
    e.s(
      [
        "$ZodAny",
        0,
        il,
        "$ZodArray",
        0,
        ig,
        "$ZodAsyncError",
        0,
        o,
        "$ZodBase64",
        0,
        t1,
        "$ZodBase64URL",
        0,
        t9,
        "$ZodBigInt",
        0,
        ir,
        "$ZodBigIntFormat",
        0,
        ia,
        "$ZodBoolean",
        0,
        ii,
        "$ZodCIDRv4",
        0,
        t0,
        "$ZodCIDRv6",
        0,
        t4,
        "$ZodCUID",
        0,
        tF,
        "$ZodCUID2",
        0,
        tJ,
        "$ZodCatch",
        0,
        iK,
        "$ZodCheck",
        0,
        ts,
        "$ZodCheckBigIntFormat",
        0,
        tp,
        "$ZodCheckEndsWith",
        0,
        tU,
        "$ZodCheckGreaterThan",
        0,
        tc,
        "$ZodCheckIncludes",
        0,
        tS,
        "$ZodCheckLengthEquals",
        0,
        ty,
        "$ZodCheckLessThan",
        0,
        td,
        "$ZodCheckLowerCase",
        0,
        tx,
        "$ZodCheckMaxLength",
        0,
        th,
        "$ZodCheckMaxSize",
        0,
        tv,
        "$ZodCheckMimeType",
        0,
        tz,
        "$ZodCheckMinLength",
        0,
        t$,
        "$ZodCheckMinSize",
        0,
        tg,
        "$ZodCheckMultipleOf",
        0,
        tm,
        "$ZodCheckNumberFormat",
        0,
        tf,
        "$ZodCheckOverwrite",
        0,
        tO,
        "$ZodCheckProperty",
        0,
        tN,
        "$ZodCheckRegex",
        0,
        tI,
        "$ZodCheckSizeEquals",
        0,
        t_,
        "$ZodCheckStartsWith",
        0,
        tw,
        "$ZodCheckStringFormat",
        0,
        tb,
        "$ZodCheckUpperCase",
        0,
        tk,
        "$ZodCodec",
        0,
        iY,
        "$ZodCustom",
        0,
        i3,
        "$ZodCustomStringFormat",
        0,
        t8,
        "$ZodDate",
        0,
        ip,
        "$ZodDefault",
        0,
        iB,
        "$ZodDiscriminatedUnion",
        0,
        ik,
        "$ZodE164",
        0,
        t3,
        "$ZodEmail",
        0,
        tL,
        "$ZodEmoji",
        0,
        tB,
        "$ZodEncodeError",
        0,
        u,
        "$ZodEnum",
        0,
        ij,
        "$ZodError",
        0,
        M,
        "$ZodFile",
        0,
        iD,
        "$ZodFunction",
        0,
        i1,
        "$ZodGUID",
        0,
        tA,
        "$ZodIPv4",
        0,
        tH,
        "$ZodIPv6",
        0,
        tQ,
        "$ZodISODate",
        0,
        tW,
        "$ZodISODateTime",
        0,
        tV,
        "$ZodISODuration",
        0,
        tY,
        "$ZodISOTime",
        0,
        tq,
        "$ZodIntersection",
        0,
        iS,
        "$ZodJWT",
        0,
        t7,
        "$ZodKSUID",
        0,
        tK,
        "$ZodLazy",
        0,
        i9,
        "$ZodLiteral",
        0,
        iT,
        "$ZodMap",
        0,
        iz,
        "$ZodNaN",
        0,
        iV,
        "$ZodNanoID",
        0,
        tX,
        "$ZodNever",
        0,
        ic,
        "$ZodNonOptional",
        0,
        iJ,
        "$ZodNull",
        0,
        is,
        "$ZodNullable",
        0,
        iR,
        "$ZodNumber",
        0,
        ie,
        "$ZodNumberFormat",
        0,
        it,
        "$ZodObject",
        0,
        iy,
        "$ZodObjectJIT",
        0,
        ib,
        "$ZodOptional",
        0,
        iL,
        "$ZodPipe",
        0,
        iW,
        "$ZodPrefault",
        0,
        iF,
        "$ZodPromise",
        0,
        i2,
        "$ZodReadonly",
        0,
        i0,
        "$ZodRealError",
        0,
        K,
        "$ZodRecord",
        0,
        iN,
        "$ZodRegistry",
        0,
        n0,
        "$ZodSet",
        0,
        iP,
        "$ZodString",
        0,
        tT,
        "$ZodStringFormat",
        0,
        tD,
        "$ZodSuccess",
        0,
        iM,
        "$ZodSymbol",
        0,
        io,
        "$ZodTemplateLiteral",
        0,
        i6,
        "$ZodTransform",
        0,
        iA,
        "$ZodTuple",
        0,
        iU,
        "$ZodType",
        0,
        tj,
        "$ZodULID",
        0,
        tG,
        "$ZodURL",
        0,
        tR,
        "$ZodUUID",
        0,
        tC,
        "$ZodUndefined",
        0,
        iu,
        "$ZodUnion",
        0,
        ix,
        "$ZodUnknown",
        0,
        id,
        "$ZodVoid",
        0,
        im,
        "$ZodXID",
        0,
        tM,
        "$brand",
        0,
        a,
        "$constructor",
        0,
        n,
        "$input",
        0,
        nQ,
        "$output",
        0,
        nH,
        "Doc",
        0,
        tP,
        "JSONSchema",
        0,
        uH,
        "JSONSchemaGenerator",
        0,
        n1,
        "NEVER",
        0,
        r,
        "TimePrecision",
        0,
        rz,
        "_any",
        0,
        rY,
        "_array",
        0,
        nI,
        "_base64",
        0,
        rw,
        "_base64url",
        0,
        rU,
        "_bigint",
        0,
        rJ,
        "_boolean",
        0,
        rX,
        "_catch",
        0,
        nR,
        "_check",
        0,
        nW,
        "_cidrv4",
        0,
        rk,
        "_cidrv6",
        0,
        rS,
        "_coercedBigint",
        0,
        rG,
        "_coercedBoolean",
        0,
        rF,
        "_coercedDate",
        0,
        r6,
        "_coercedNumber",
        0,
        rD,
        "_coercedString",
        0,
        ru,
        "_cuid",
        0,
        r_,
        "_cuid2",
        0,
        rh,
        "_custom",
        0,
        nM,
        "_date",
        0,
        r4,
        "_decode",
        0,
        el,
        "_decodeAsync",
        0,
        ef,
        "_default",
        0,
        nA,
        "_discriminatedUnion",
        0,
        nk,
        "_e164",
        0,
        rE,
        "_email",
        0,
        rs,
        "_emoji",
        0,
        rv,
        "_encode",
        0,
        eu,
        "_encodeAsync",
        0,
        ec,
        "_endsWith",
        0,
        np,
        "_enum",
        0,
        nz,
        "_file",
        0,
        nZ,
        "_float32",
        0,
        rC,
        "_float64",
        0,
        rL,
        "_gt",
        0,
        r3,
        "_gte",
        0,
        r5,
        "_guid",
        0,
        rl,
        "_includes",
        0,
        nm,
        "_int",
        0,
        rA,
        "_int32",
        0,
        rR,
        "_int64",
        0,
        rM,
        "_intersection",
        0,
        nS,
        "_ipv4",
        0,
        rI,
        "_ipv6",
        0,
        rx,
        "_isoDate",
        0,
        rP,
        "_isoDateTime",
        0,
        rO,
        "_isoDuration",
        0,
        rj,
        "_isoTime",
        0,
        rZ,
        "_jwt",
        0,
        rN,
        "_ksuid",
        0,
        rb,
        "_lazy",
        0,
        nJ,
        "_length",
        0,
        ns,
        "_literal",
        0,
        nP,
        "_lowercase",
        0,
        nd,
        "_lt",
        0,
        r2,
        "_lte",
        0,
        r9,
        "_map",
        0,
        nE,
        "_max",
        0,
        r9,
        "_maxLength",
        0,
        no,
        "_maxSize",
        0,
        nr,
        "_mime",
        0,
        ng,
        "_min",
        0,
        r5,
        "_minLength",
        0,
        nu,
        "_minSize",
        0,
        nn,
        "_multipleOf",
        0,
        ni,
        "_nan",
        0,
        r1,
        "_nanoid",
        0,
        rg,
        "_nativeEnum",
        0,
        nO,
        "_negative",
        0,
        r8,
        "_never",
        0,
        rQ,
        "_nonnegative",
        0,
        nt,
        "_nonoptional",
        0,
        nC,
        "_nonpositive",
        0,
        ne,
        "_normalize",
        0,
        nh,
        "_null",
        0,
        rq,
        "_nullable",
        0,
        nD,
        "_number",
        0,
        rT,
        "_optional",
        0,
        nT,
        "_overwrite",
        0,
        n_,
        "_parse",
        0,
        Q,
        "_parseAsync",
        0,
        et,
        "_pipe",
        0,
        nB,
        "_positive",
        0,
        r7,
        "_promise",
        0,
        nG,
        "_property",
        0,
        nv,
        "_readonly",
        0,
        nX,
        "_record",
        0,
        nU,
        "_refine",
        0,
        nK,
        "_regex",
        0,
        nl,
        "_safeDecode",
        0,
        e_,
        "_safeDecodeAsync",
        0,
        eb,
        "_safeEncode",
        0,
        ev,
        "_safeEncodeAsync",
        0,
        e$,
        "_safeParse",
        0,
        er,
        "_safeParseAsync",
        0,
        ea,
        "_set",
        0,
        nN,
        "_size",
        0,
        na,
        "_startsWith",
        0,
        nf,
        "_string",
        0,
        ro,
        "_stringFormat",
        0,
        nY,
        "_stringbool",
        0,
        nq,
        "_success",
        0,
        nL,
        "_superRefine",
        0,
        nV,
        "_symbol",
        0,
        rV,
        "_templateLiteral",
        0,
        nF,
        "_toLowerCase",
        0,
        ny,
        "_toUpperCase",
        0,
        nb,
        "_transform",
        0,
        nj,
        "_trim",
        0,
        n$,
        "_tuple",
        0,
        nw,
        "_uint32",
        0,
        rB,
        "_uint64",
        0,
        rK,
        "_ulid",
        0,
        r$,
        "_undefined",
        0,
        rW,
        "_union",
        0,
        nx,
        "_unknown",
        0,
        rH,
        "_uppercase",
        0,
        nc,
        "_url",
        0,
        rp,
        "_uuid",
        0,
        rd,
        "_uuidv4",
        0,
        rc,
        "_uuidv6",
        0,
        rm,
        "_uuidv7",
        0,
        rf,
        "_void",
        0,
        r0,
        "_xid",
        0,
        ry,
        "clone",
        0,
        z,
        "config",
        0,
        l,
        "decode",
        0,
        ed,
        "decodeAsync",
        0,
        ep,
        "encode",
        0,
        es,
        "encodeAsync",
        0,
        em,
        "flattenError",
        0,
        V,
        "formatError",
        0,
        W,
        "globalConfig",
        0,
        s,
        "globalRegistry",
        0,
        n6,
        "isValidBase64",
        0,
        t6,
        "isValidBase64URL",
        0,
        t2,
        "isValidJWT",
        0,
        t5,
        "locales",
        0,
        uY,
        "parse",
        0,
        ee,
        "parseAsync",
        0,
        ei,
        "prettifyError",
        0,
        H,
        "regexes",
        0,
        uq,
        "registry",
        0,
        n4,
        "safeDecode",
        0,
        eh,
        "safeDecodeAsync",
        0,
        eI,
        "safeEncode",
        0,
        eg,
        "safeEncodeAsync",
        0,
        ey,
        "safeParse",
        0,
        en,
        "safeParseAsync",
        0,
        eo,
        "toDotPath",
        0,
        Y,
        "toJSONSchema",
        0,
        n2,
        "treeifyError",
        0,
        q,
        "util",
        0,
        uW,
        "version",
        0,
        tZ,
      ],
      712717,
    );
    var uQ = e.i(712717);
    (e.i(362201),
      e.i(342332),
      e.s(
        [
          "endsWith",
          0,
          np,
          "gt",
          0,
          r3,
          "gte",
          0,
          r5,
          "includes",
          0,
          nm,
          "length",
          0,
          ns,
          "lowercase",
          0,
          nd,
          "lt",
          0,
          r2,
          "lte",
          0,
          r9,
          "maxLength",
          0,
          no,
          "maxSize",
          0,
          nr,
          "mime",
          0,
          ng,
          "minLength",
          0,
          nu,
          "minSize",
          0,
          nn,
          "multipleOf",
          0,
          ni,
          "negative",
          0,
          r8,
          "nonnegative",
          0,
          nt,
          "nonpositive",
          0,
          ne,
          "normalize",
          0,
          nh,
          "overwrite",
          0,
          n_,
          "positive",
          0,
          r7,
          "property",
          0,
          nv,
          "regex",
          0,
          nl,
          "size",
          0,
          na,
          "startsWith",
          0,
          nf,
          "toLowerCase",
          0,
          ny,
          "toUpperCase",
          0,
          nb,
          "trim",
          0,
          n$,
          "uppercase",
          0,
          nc,
        ],
        430421,
      ),
      e.i(430421),
      e.i(789282),
      e.i(100364),
      e.i(306034),
      e.s(
        [
          "$brand",
          0,
          a,
          "ZodFirstPartyTypeKind",
          0,
          t,
          "ZodIssueCode",
          0,
          uM,
          "config",
          0,
          l,
          "getErrorMap",
          0,
          uV,
          "setErrorMap",
          0,
          uK,
        ],
        458829,
      ),
      e.i(458829));
    var n9 = n9,
      n3 = n3,
      u0 = e.i(49732),
      u4 = e.i(313657);
    e.s(
      [
        "$brand",
        0,
        a,
        "$input",
        0,
        nQ,
        "$output",
        0,
        nH,
        "NEVER",
        0,
        r,
        "TimePrecision",
        0,
        rz,
        "ZodAny",
        0,
        oN,
        "ZodArray",
        0,
        oL,
        "ZodBase64",
        0,
        a9,
        "ZodBase64URL",
        0,
        a5,
        "ZodBigInt",
        0,
        oh,
        "ZodBigIntFormat",
        0,
        oy,
        "ZodBoolean",
        0,
        og,
        "ZodCIDRv4",
        0,
        a4,
        "ZodCIDRv6",
        0,
        a1,
        "ZodCUID",
        0,
        aB,
        "ZodCUID2",
        0,
        aF,
        "ZodCatch",
        0,
        u$,
        "ZodCodec",
        0,
        uS,
        "ZodCustom",
        0,
        uA,
        "ZodCustomStringFormat",
        0,
        or,
        "ZodDate",
        0,
        oA,
        "ZodDefault",
        0,
        uc,
        "ZodDiscriminatedUnion",
        0,
        oV,
        "ZodE164",
        0,
        a8,
        "ZodEmail",
        0,
        aS,
        "ZodEmoji",
        0,
        aA,
        "ZodEnum",
        0,
        o5,
        "ZodError",
        0,
        ao,
        "ZodFile",
        0,
        ui,
        "ZodFirstPartyTypeKind",
        0,
        t,
        "ZodFunction",
        0,
        uT,
        "ZodGUID",
        0,
        aU,
        "ZodIPv4",
        0,
        aY,
        "ZodIPv6",
        0,
        aQ,
        "ZodISODate",
        0,
        n8,
        "ZodISODateTime",
        0,
        n5,
        "ZodISODuration",
        0,
        ar,
        "ZodISOTime",
        0,
        at,
        "ZodIntersection",
        0,
        oq,
        "ZodIssueCode",
        0,
        uM,
        "ZodJWT",
        0,
        ot,
        "ZodKSUID",
        0,
        aW,
        "ZodLazy",
        0,
        uO,
        "ZodLiteral",
        0,
        ue,
        "ZodMap",
        0,
        o1,
        "ZodNaN",
        0,
        ub,
        "ZodNanoID",
        0,
        aL,
        "ZodNever",
        0,
        oZ,
        "ZodNonOptional",
        0,
        uv,
        "ZodNull",
        0,
        oU,
        "ZodNullable",
        0,
        us,
        "ZodNumber",
        0,
        os,
        "ZodNumberFormat",
        0,
        od,
        "ZodObject",
        0,
        oX,
        "ZodOptional",
        0,
        uo,
        "ZodPipe",
        0,
        ux,
        "ZodPrefault",
        0,
        uf,
        "ZodPromise",
        0,
        uZ,
        "ZodReadonly",
        0,
        uU,
        "ZodRealError",
        0,
        au,
        "ZodRecord",
        0,
        o0,
        "ZodSet",
        0,
        o9,
        "ZodString",
        0,
        aI,
        "ZodStringFormat",
        0,
        ak,
        "ZodSuccess",
        0,
        u_,
        "ZodSymbol",
        0,
        ox,
        "ZodTemplateLiteral",
        0,
        uN,
        "ZodTransform",
        0,
        un,
        "ZodTuple",
        0,
        oH,
        "ZodType",
        0,
        ay,
        "ZodULID",
        0,
        aG,
        "ZodURL",
        0,
        aj,
        "ZodUUID",
        0,
        aN,
        "ZodUndefined",
        0,
        oS,
        "ZodUnion",
        0,
        oM,
        "ZodUnknown",
        0,
        oO,
        "ZodVoid",
        0,
        oT,
        "ZodXID",
        0,
        aK,
        "_ZodString",
        0,
        ab,
        "_default",
        0,
        um,
        "_function",
        0,
        uD,
        "any",
        0,
        oz,
        "array",
        0,
        oR,
        "base64",
        0,
        a3,
        "base64url",
        0,
        a7,
        "bigint",
        0,
        o$,
        "boolean",
        0,
        o_,
        "catch",
        0,
        uy,
        "check",
        0,
        uC,
        "cidrv4",
        0,
        a6,
        "cidrv6",
        0,
        a2,
        "clone",
        0,
        z,
        "codec",
        0,
        uw,
        "coerce",
        0,
        u4,
        "config",
        0,
        l,
        "core",
        0,
        uQ,
        "cuid",
        0,
        aX,
        "cuid2",
        0,
        aJ,
        "custom",
        0,
        uL,
        "date",
        0,
        oC,
        "decode",
        0,
        af,
        "decodeAsync",
        0,
        av,
        "discriminatedUnion",
        0,
        oW,
        "e164",
        0,
        oe,
        "email",
        0,
        aw,
        "emoji",
        0,
        aC,
        "encode",
        0,
        am,
        "encodeAsync",
        0,
        ap,
        "endsWith",
        0,
        np,
        "enum",
        0,
        o7,
        "file",
        0,
        ur,
        "flattenError",
        0,
        V,
        "float32",
        0,
        om,
        "float64",
        0,
        of,
        "formatError",
        0,
        W,
        "function",
        0,
        uD,
        "getErrorMap",
        0,
        uV,
        "globalRegistry",
        0,
        n6,
        "gt",
        0,
        r3,
        "gte",
        0,
        r5,
        "guid",
        0,
        aE,
        "hash",
        0,
        ou,
        "hex",
        0,
        oo,
        "hostname",
        0,
        oa,
        "httpUrl",
        0,
        aD,
        "includes",
        0,
        nm,
        "instanceof",
        0,
        uX,
        "int",
        0,
        oc,
        "int32",
        0,
        op,
        "int64",
        0,
        ob,
        "intersection",
        0,
        oY,
        "ipv4",
        0,
        aH,
        "ipv6",
        0,
        a0,
        "iso",
        0,
        u0,
        "json",
        0,
        uJ,
        "jwt",
        0,
        oi,
        "keyof",
        0,
        oB,
        "ksuid",
        0,
        aq,
        "lazy",
        0,
        uP,
        "length",
        0,
        ns,
        "literal",
        0,
        ut,
        "locales",
        0,
        uY,
        "looseObject",
        0,
        oG,
        "lowercase",
        0,
        nd,
        "lt",
        0,
        r2,
        "lte",
        0,
        r9,
        "map",
        0,
        o2,
        "maxLength",
        0,
        no,
        "maxSize",
        0,
        nr,
        "mime",
        0,
        ng,
        "minLength",
        0,
        nu,
        "minSize",
        0,
        nn,
        "multipleOf",
        0,
        ni,
        "nan",
        0,
        uI,
        "nanoid",
        0,
        aR,
        "nativeEnum",
        0,
        o8,
        "negative",
        0,
        r8,
        "never",
        0,
        oj,
        "nonnegative",
        0,
        nt,
        "nonoptional",
        0,
        ug,
        "nonpositive",
        0,
        ne,
        "normalize",
        0,
        nh,
        "null",
        0,
        oE,
        "nullable",
        0,
        ul,
        "nullish",
        0,
        ud,
        "number",
        0,
        ol,
        "object",
        0,
        oF,
        "optional",
        0,
        uu,
        "overwrite",
        0,
        n_,
        "parse",
        0,
        as,
        "parseAsync",
        0,
        al,
        "partialRecord",
        0,
        o6,
        "pipe",
        0,
        uk,
        "positive",
        0,
        r7,
        "prefault",
        0,
        up,
        "preprocess",
        0,
        uG,
        "prettifyError",
        0,
        H,
        "promise",
        0,
        uj,
        "property",
        0,
        nv,
        "readonly",
        0,
        uE,
        "record",
        0,
        o4,
        "refine",
        0,
        uR,
        "regex",
        0,
        nl,
        "regexes",
        () => n9,
        "registry",
        0,
        n4,
        "safeDecode",
        0,
        a_,
        "safeDecodeAsync",
        0,
        a$,
        "safeEncode",
        0,
        ag,
        "safeEncodeAsync",
        0,
        ah,
        "safeParse",
        0,
        ad,
        "safeParseAsync",
        0,
        ac,
        "set",
        0,
        o3,
        "setErrorMap",
        0,
        uK,
        "size",
        0,
        na,
        "startsWith",
        0,
        nf,
        "strictObject",
        0,
        oJ,
        "string",
        0,
        ax,
        "stringFormat",
        0,
        on,
        "stringbool",
        0,
        uF,
        "success",
        0,
        uh,
        "superRefine",
        0,
        uB,
        "symbol",
        0,
        ok,
        "templateLiteral",
        0,
        uz,
        "toJSONSchema",
        0,
        n2,
        "toLowerCase",
        0,
        ny,
        "toUpperCase",
        0,
        nb,
        "transform",
        0,
        ua,
        "treeifyError",
        0,
        q,
        "trim",
        0,
        n$,
        "tuple",
        0,
        oQ,
        "uint32",
        0,
        ov,
        "uint64",
        0,
        oI,
        "ulid",
        0,
        aM,
        "undefined",
        0,
        ow,
        "union",
        0,
        oK,
        "unknown",
        0,
        oP,
        "uppercase",
        0,
        nc,
        "url",
        0,
        aT,
        "util",
        () => n3,
        "uuid",
        0,
        az,
        "uuidv4",
        0,
        aO,
        "uuidv6",
        0,
        aP,
        "uuidv7",
        0,
        aZ,
        "void",
        0,
        oD,
        "xid",
        0,
        aV,
      ],
      722219,
    );
    var u6 = e.i(722219),
      u6 = u6;
    function u1(e, t) {
      if (e instanceof Promise) throw Error(t);
    }
    function u2(e) {
      let t = "object" == typeof e.client ? e.client : {},
        r = "object" == typeof e.server ? e.server : {},
        n = e.shared,
        a = e.runtimeEnv ? e.runtimeEnv : { ...i.default.env, ...e.experimental__runtimeEnv };
      return (function (e) {
        let t = e.runtimeEnvStrict ?? e.runtimeEnv ?? i.default.env;
        if (e.emptyStringAsUndefined) for (let [e, i] of Object.entries(t)) "" === i && delete t[e];
        if (e.skipValidation) return t;
        let r = "object" == typeof e.client ? e.client : {},
          n = "object" == typeof e.server ? e.server : {},
          a = "object" == typeof e.shared ? e.shared : {},
          o = e.isServer ?? ("u" < typeof window || "Deno" in window),
          u = o ? { ...n, ...a, ...r } : { ...r, ...a },
          s =
            e.createFinalSchema?.(u, o)["~standard"].validate(t) ??
            (function (e, t) {
              let i = {},
                r = [];
              for (let n in e) {
                let a = e[n]["~standard"].validate(t[n]);
                if ((u1(a, `Validation must be synchronous, but ${n} returned a Promise.`), a.issues)) {
                  r.push(
                    ...a.issues.map((e) => ({ ...e, message: e.message, path: [n, ...(e.path ?? [])] })),
                  );
                  continue;
                }
                i[n] = a.value;
              }
              return r.length ? { issues: r } : { value: i };
            })(u, t);
        u1(s, "Validation must be synchronous");
        let l =
            e.onValidationError ??
            ((e) => {
              throw (
                console.error("❌ Invalid environment variables:", e),
                Error("Invalid environment variables")
              );
            }),
          d =
            e.onInvalidAccess ??
            (() => {
              throw Error("❌ Attempted to access a server-side environment variable on the client");
            });
        return s.issues
          ? l(s.issues)
          : new Proxy(
              Object.assign(
                (e.extends ?? []).reduce((e, t) => Object.assign(e, t), {}),
                s.value,
              ),
              {
                get(t, i) {
                  if ("string" == typeof i && "__esModule" !== i && "$$typeof" !== i)
                    return o || (e.clientPrefix && (i.startsWith(e.clientPrefix) || i in a))
                      ? Reflect.get(t, i)
                      : d(i);
                },
              },
            );
      })({ ...e, shared: n, client: t, server: r, clientPrefix: "NEXT_PUBLIC_", runtimeEnv: a });
    }
    let u9 = u2({
      client: {
        NEXT_PUBLIC_NODE_ENV: u6.enum(["development", "production"]).optional().default("development"),
        NEXT_PUBLIC_APP_URL: u6.string().min(1, { message: "NEXT_PUBLIC_APP_URL is required" }),
        NEXT_PUBLIC_APP_ENV: u6.enum(["development", "stage", "production"], {
          message: "NEXT_PUBLIC_APP_ENV is required",
        }),
        NEXT_PUBLIC_SERVER_URL: u6.string().min(1, { message: "NEXT_PUBLIC_SERVER_URL is required" }),
        NEXT_PUBLIC_GTM: u6.string().min(1, { message: "NEXT_PUBLIC_GTM is required" }),
        NEXT_PUBLIC_GA: u6.string().min(1, { message: "NEXT_PUBLIC_GA is required" }),
        NEXT_PUBLIC_GROWTHBOOK_API_HOST: u6
          .string()
          .min(1, { message: "NEXT_PUBLIC_GROWTHBOOK_API_HOST is required" }),
        NEXT_PUBLIC_GROWTHBOOK_CLIENT_KEY: u6
          .string()
          .min(1, { message: "NEXT_PUBLIC_GROWTHBOOK_CLIENT_KEY is required" }),
        NEXT_PUBLIC_MIXPANEL_PROJECT_TOKEN: u6
          .string()
          .min(1, { message: "NEXT_PUBLIC_MIXPANEL_PROJECT_TOKEN is required" }),
        NEXT_PUBLIC_MIXPANEL_API_HOST: u6
          .string()
          .min(1, { message: "NEXT_PUBLIC_MIXPANEL_API_HOST is required" }),
        NEXT_PUBLIC_PAYNEXT_ENV: u6.enum(["sandbox", "production"], {
          message: "NEXT_PUBLIC_PAYNEXT_ENV is required",
        }),
        NEXT_PUBLIC_PAYMENT_ENV: u6.string().min(1, { message: "NEXT_PUBLIC_PAYMENT_ENV is required" }),
        NEXT_PUBLIC_BILLING_HOSTNAME: u6
          .string()
          .min(1, { message: "NEXT_PUBLIC_BILLING_HOSTNAME is required" }),
        NEXT_PUBLIC_BRAINTREE_AUTHORIZATION: u6
          .string()
          .min(1, { message: "NEXT_PUBLIC_BRAINTREE_AUTHORIZATION is required" }),
        NEXT_PUBLIC_QUIZ_DISABLED: u6.string().optional(),
        NEXT_PUBLIC_GAMEZOP_GAME_URL: u6
          .string()
          .min(1, { message: "NEXT_PUBLIC_GAMEZOP_GAME_URL is required" }),
        NEXT_PUBLIC_GAMEZOP_API: u6.string().min(1, { message: "NEXT_PUBLIC_GAMEZOP_API is required" }),
        NEXT_PUBLIC_PAY_PAL_MERCHANT_ID: u6
          .string()
          .min(1, { message: "NEXT_PUBLIC_PAY_PAL_MERCHANT_ID is required" }),
        NEXT_PUBLIC_RE_CAPTCHA_KEY: u6.string().min(1, { message: "NEXT_PUBLIC_RE_CAPTCHA_KEY is required" }),
        NEXT_PUBLIC_RE_CAPTCHA_INVISIBLE_KEY: u6
          .string()
          .min(1, { message: "NEXT_PUBLIC_RE_CAPTCHA_INVISIBLE_KEY is required" }),
        NEXT_PUBLIC_STRIPE_PUBLIC_KEY: u6
          .string()
          .min(1, { message: "NEXT_PUBLIC_STRIPE_PUBLIC_KEY is required" }),
        NEXT_PUBLIC_STRIPE_CA_PUBLIC_KEY: u6
          .string()
          .min(1, { message: "NEXT_PUBLIC_STRIPE_CA_PUBLIC_KEY is required" }),
        NEXT_PUBLIC_STRIPE_AU_PUBLIC_KEY: u6
          .string()
          .min(1, { message: "NEXT_PUBLIC_STRIPE_AU_PUBLIC_KEY is required" }),
        NEXT_PUBLIC_STRIPE_EU_PUBLIC_KEY: u6
          .string()
          .min(1, { message: "NEXT_PUBLIC_STRIPE_EU_PUBLIC_KEY is required" }),
        NEXT_PUBLIC_STRIPE_UK_PUBLIC_KEY: u6
          .string()
          .min(1, { message: "NEXT_PUBLIC_STRIPE_UK_PUBLIC_KEY is required" }),
        NEXT_PUBLIC_ONESIGNAL_APP_ID: u6
          .string()
          .min(1, { message: "NEXT_PUBLIC_ONESIGNAL_APP_ID is required" }),
        NEXT_PUBLIC_SERVER_API: u6.string().min(1, { message: "NEXT_PUBLIC_SERVER_API is required" }),
        NEXT_PUBLIC_GOOGLE_MAPS_API_KEY: u6.string().optional(),
        NEXT_PUBLIC_IS_PREVIEW: u6.string().optional().default("false"),
        NEXT_PUBLIC_BETTER_STACK_SOURCE_TOKEN: u6.string().optional(),
        NEXT_PUBLIC_BETTER_STACK_INGESTING_URL: u6.string().optional(),
      },
      emptyStringAsUndefined: !0,
      runtimeEnv: {
        NEXT_PUBLIC_APP_URL: "https://myiq.com",
        NEXT_PUBLIC_APP_ENV: "production",
        NEXT_PUBLIC_SERVER_URL: "https://myiq.com/api",
        NEXT_PUBLIC_GTM: "GTM-NLBH2NG2",
        NEXT_PUBLIC_GA: "G-B613LVD5DE",
        NEXT_PUBLIC_GROWTHBOOK_API_HOST: "https://cdn.growthbook.io",
        NEXT_PUBLIC_GROWTHBOOK_CLIENT_KEY: "sdk-5QHSF9qrdBDpLYOm",
        NEXT_PUBLIC_MIXPANEL_PROJECT_TOKEN: "d95075c82bd089e38084c964d094f779",
        NEXT_PUBLIC_MIXPANEL_API_HOST: "https://mp.myiq.com",
        NEXT_PUBLIC_PAYNEXT_ENV: "production",
        NEXT_PUBLIC_PAYMENT_ENV: "envest",
        NEXT_PUBLIC_BILLING_HOSTNAME: "myiq.com",
        NEXT_PUBLIC_BRAINTREE_AUTHORIZATION: "production_3ndcfm6k_hygrmhmg9txg9xxq",
        NEXT_PUBLIC_QUIZ_DISABLED: i.default.env.NEXT_PUBLIC_QUIZ_DISABLED,
        NEXT_PUBLIC_GAMEZOP_GAME_URL: "https://10449.play.gamezop.com/g/",
        NEXT_PUBLIC_GAMEZOP_API: "https://pub.gamezop.com/v3/games?id=10449",
        NEXT_PUBLIC_PAY_PAL_MERCHANT_ID: "R6U4WAJ8H6WS4",
        NEXT_PUBLIC_RE_CAPTCHA_KEY: "6Le7PwsqAAAAAOKyoSdYEIH07QWsSBDbc_NycUn6",
        NEXT_PUBLIC_RE_CAPTCHA_INVISIBLE_KEY: "6LdyypsrAAAAAKgt1NrZqNeINqz7PU6pk7-9sBoI",
        NEXT_PUBLIC_STRIPE_PUBLIC_KEY:
          "pk_live_51PYnJ2Ch4PlSmd7DUMcXYTvM4Dlk1DbkB21sQxRqrbdQadGlq2KvjwPGEp08Jx8FECU2TNjotkEWDxGD38fHkoBq000YFIZPDH",
        NEXT_PUBLIC_STRIPE_CA_PUBLIC_KEY:
          "pk_live_51Po4ZkBC04Pl5wHoYOG3mTDMabnjh0tqQ8hvrIbn2v5qQDppUAt6kZfokHmGj285pEgFNKwJQubIYKyTfYxiyfQ000X8s7kLSY",
        NEXT_PUBLIC_STRIPE_AU_PUBLIC_KEY:
          "pk_live_51Po2P3GJN0sfw5rYWF616GiMhiZUNpGrWUIDTt0ZFveanqaLjJ13vuxdXavljCBM9JrDrXRmEeL1VRe5d9nUPywr00LtBbxd8F",
        NEXT_PUBLIC_STRIPE_EU_PUBLIC_KEY:
          "pk_live_51PoOt0DVSIwmXhwZgLNSmJIDuorexFzuPNivMZyZVf95B6ZPNXvzzkzDHpG2b6NUbp2Xe2r3DIZ3GVydx1GYpzbd009DaGo98Y",
        NEXT_PUBLIC_STRIPE_UK_PUBLIC_KEY:
          "pk_live_51PoNu7CuJeiBs943x8wjTwTYwuLlF2OtUmBm5olg8Nv5GSnHtwUHFXJmaJP9aNJud9hVfgUUs6LwOv3TXL7xNfrz003LmPuapq",
        NEXT_PUBLIC_ONESIGNAL_APP_ID: "cdbeb056-0c43-4f41-a9d6-a5231dc0717c",
        NEXT_PUBLIC_SERVER_API: "https://myiq.com/api/v2",
        NEXT_PUBLIC_NODE_ENV: "production",
        NEXT_PUBLIC_GOOGLE_MAPS_API_KEY: "AIzaSyBfCbMBJDnihlEReORfuoitM6jVo50sQSA",
        NEXT_PUBLIC_IS_PREVIEW: i.default.env.NEXT_PUBLIC_IS_PREVIEW,
        NEXT_PUBLIC_BETTER_STACK_SOURCE_TOKEN: "9LaiZJ2JFWZzTK5RBLcRAuak",
        NEXT_PUBLIC_BETTER_STACK_INGESTING_URL: "https://s2340140.us-east-9.betterstackdata.com",
      },
    });
    e.s(["envClient", 0, u9], 542516);
    var u6 = u6;
    let u3 = u2({
      server: {
        NODE_ENV: u6.enum(["development", "production"]).optional().default("development"),
        JWT_SECRET: u6.string().min(1, { message: "JWT_SECRET is required" }),
        NEXTAUTH_SECRET: u6.string().min(1, { message: "NEXTAUTH_SECRET is required" }),
        GOOGLE_CLIENT_ID: u6.string().min(1, { message: "GOOGLE_CLIENT_ID is required" }),
        GOOGLE_CLIENT_SECRET: u6.string().min(1, { message: "GOOGLE_CLIENT_SECRET is required" }),
        AZURE_AD_CLIENT_ID: u6.string().min(1, { message: "AZURE_AD_CLIENT_ID is required" }),
        AZURE_AD_CLIENT_SECRET: u6.string().min(1, { message: "AZURE_AD_CLIENT_SECRET is required" }),
        YANDEX_CLIENT_ID: u6.string().min(1, { message: "YANDEX_CLIENT_ID is required" }),
        YANDEX_CLIENT_SECRET: u6.string().min(1, { message: "YANDEX_CLIENT_SECRET is required" }),
        REVIEWS_IO_STORE_ID: u6.string().min(1, { message: "REVIEWS_IO_STORE_ID is required" }),
        REVIEWS_IO_API_KEY: u6.string().min(1, { message: "REVIEWS_IO_API_KEY is required" }),
        BETTER_STACK_APP_NAME: u6.string().optional(),
        FLAGSHIP_APP_ID: u6.string().optional(),
        FLAGSHIP_ACCOUNT_ID: u6.string().optional(),
        FLAGSHIP_API_TOKEN: u6.string().optional(),
      },
      shared: { BUILD_VERSION: u6.string().optional(), INSTANCE_REGION: u6.string().optional() },
      emptyStringAsUndefined: !0,
      runtimeEnv: {
        NODE_ENV: "production",
        JWT_SECRET: i.default.env.JWT_SECRET,
        NEXTAUTH_SECRET: i.default.env.NEXTAUTH_SECRET,
        GOOGLE_CLIENT_ID: i.default.env.GOOGLE_CLIENT_ID,
        GOOGLE_CLIENT_SECRET: i.default.env.GOOGLE_CLIENT_SECRET,
        AZURE_AD_CLIENT_ID: i.default.env.AZURE_AD_CLIENT_ID,
        AZURE_AD_CLIENT_SECRET: i.default.env.AZURE_AD_CLIENT_SECRET,
        YANDEX_CLIENT_ID: i.default.env.YANDEX_CLIENT_ID,
        YANDEX_CLIENT_SECRET: i.default.env.YANDEX_CLIENT_SECRET,
        BUILD_VERSION: "v1.3.3-a17679c",
        INSTANCE_REGION: "prod-worker",
        REVIEWS_IO_STORE_ID: i.default.env.REVIEWS_IO_STORE_ID,
        REVIEWS_IO_API_KEY: i.default.env.REVIEWS_IO_API_KEY,
        BETTER_STACK_APP_NAME: i.default.env.BETTER_STACK_APP_NAME,
        FLAGSHIP_APP_ID: i.default.env.FLAGSHIP_APP_ID,
        FLAGSHIP_ACCOUNT_ID: i.default.env.FLAGSHIP_ACCOUNT_ID,
        FLAGSHIP_API_TOKEN: i.default.env.FLAGSHIP_API_TOKEN,
      },
    });
    (e.s(["envServer", 0, u3], 846911), e.s([], 756503));
  },
]);
