(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  666137,
  (e) => {
    "use strict";
    e.s([
      "BluredCertificate",
      0,
      "/images/certificate/blured-certificate.webp",
      "BluredCertificateLove",
      0,
      "/images/certificate/blured-certificate-love.webp",
      "ImgCertificateLogo",
      0,
      "/images/certificate/logo.png",
      "ImgLogoText",
      0,
      "/images/certificate/logo-text.png",
      "ImgLoveFunnelLogo",
      0,
      "/images/certificate/logo-love.png",
      "ImgPrintedCertificateReport",
      0,
      "/images/certificate/print-certificate.webp",
      "ImgSignature1",
      0,
      "/images/certificate/sign-1.png",
      "ImgSignature2",
      0,
      "/images/certificate/sign-2.png",
    ]);
  },
  734423,
  150763,
  (e) => {
    "use strict";
    let t = 3120 / 2160,
      i = `${((1 / t) * 100 + 10).toFixed(2)}%`;
    (e.s(
      [
        "ASPECT",
        0,
        t,
        "CONTAINER_PB",
        0,
        i,
        "FLUID_LG_CLASSES",
        0,
        {
          container: "lg:[container-type:inline-size]",
          frame: "lg:border-[length:2.03cqw]",
          badge: "lg:h-[15.25cqw] lg:w-[15.25cqw]",
          logo: "lg:h-[3.73cqw] lg:max-w-[13.56cqw]",
          title: "lg:mt-[2.03cqw] lg:text-[length:4.07cqw] lg:leading-[5.42cqw]",
          label: "lg:text-[length:1.86cqw]",
          value: "lg:text-[length:4.41cqw]",
          description: "lg:text-[length:1.61cqw]",
          footer: "lg:[gap:4.07cqw]",
          meta: "lg:[gap:3.39cqw] lg:text-[length:1.53cqw]",
          signatures: "lg:[gap:3.39cqw] lg:text-[length:1.36cqw]",
          signatureWide: "lg:w-[23.73cqw]",
          signatureNarrow: "lg:w-[16.95cqw]",
          signatureLine: "lg:h-[5.42cqw]",
        },
      ],
      150763,
    ),
      e.s([], 734423));
  },
  451747,
  (e) => {
    "use strict";
    var t = e.i(843476);
    let i = (0, e.i(475254).default)("lock-keyhole", [
      ["circle", { cx: "12", cy: "16", r: "1", key: "1au0dj" }],
      ["rect", { x: "3", y: "10", width: "18", height: "12", rx: "2", key: "6s8ecr" }],
      ["path", { d: "M7 10V7a5 5 0 0 1 10 0v3", key: "1pqi11" }],
    ]);
    var l = e.i(657688),
      a = e.i(948148),
      r = e.i(666137);
    e.i(734423);
    var s = e.i(150763);
    e.s(
      [
        "default",
        0,
        () => {
          let e = (0, a.useTranslations)();
          return (0, t.jsxs)("div", {
            className: "relative mx-auto -mb-10 mt-2 w-full origin-bottom select-none lg:-mb-0 lg:mt-0",
            style: { paddingBottom: s.CONTAINER_PB },
            children: [
              (0, t.jsx)("div", {
                className:
                  "absolute rounded-xl border border-[#ECEFF6] bg-[#FAFBFE] shadow-[0_6px_18px_rgba(10,27,94,0.06)]",
                style: {
                  top: 0,
                  left: 0,
                  right: 0,
                  aspectRatio: s.ASPECT,
                  transform: "translate(6px, 8px) rotate(0.5deg)",
                },
              }),
              (0, t.jsx)("div", {
                className:
                  "absolute overflow-hidden rounded-xl border border-[#E5DEFF] bg-white shadow-[0_14px_36px_rgba(26,107,255,0.14),_0_3px_10px_rgba(10,27,94,0.10)]",
                style: { top: 0, left: 0, right: 0, aspectRatio: s.ASPECT },
                children: (0, t.jsxs)("div", {
                  className:
                    "relative flex h-full w-full flex-col px-[4%] py-[2.5%] min-[542px]:px-6 min-[542px]:py-4 lg:px-[5%] lg:py-[3.5%]",
                  children: [
                    (0, t.jsx)(l.default, {
                      src: r.ImgCertificateLogo,
                      alt: "myIQ badge",
                      width: 90,
                      height: 90,
                      className:
                        "absolute right-[4%] top-[4%] h-[13.3vw] w-[13.3vw] object-contain min-[542px]:right-6 min-[542px]:top-4 min-[542px]:h-[72px] min-[542px]:w-[72px] lg:right-[4%] lg:top-[4%] lg:h-[72px] lg:w-[72px]",
                    }),
                    (0, t.jsx)(l.default, {
                      src: r.ImgLogoText,
                      alt: "myIQ",
                      width: 80,
                      height: 22,
                      className:
                        "h-[3.33vw] w-auto max-w-[13vw] min-[542px]:h-[18px] min-[542px]:max-w-[65px] lg:h-[22px] lg:max-w-[80px]",
                    }),
                    (0, t.jsx)("h3", {
                      className:
                        "mt-2 text-[4.07vw] font-bold leading-tight text-blue-custom min-[542px]:mt-3 min-[542px]:text-[22px] lg:text-xl",
                      children: e.rich("certificate_card_iq_test_title", {
                        span: (e) => (0, t.jsx)("span", { className: "text-dark-custom", children: e }),
                      }),
                    }),
                    (0, t.jsx)("div", {
                      className:
                        "mt-[2.5%] text-[1.85vw] text-cert-grey min-[542px]:mt-2 min-[542px]:text-[10px] lg:mt-[2.5%] lg:text-[11px]",
                      children: e("certificate_card_proudly_presented_to"),
                    }),
                    (0, t.jsx)("div", {
                      className:
                        "mt-[0.5%] text-[4.07vw] font-medium leading-tight text-dark-custom blur-[7px] min-[542px]:mt-0.5 min-[542px]:text-[22px] lg:mt-[0.5%] lg:text-[26px]",
                      children: "???? ?????",
                    }),
                    (0, t.jsx)("div", {
                      className:
                        "mt-[2.5%] text-[1.85vw] text-cert-grey min-[542px]:mt-2 min-[542px]:text-[10px] lg:mt-[2.5%] lg:text-[11px]",
                      children: e("certificate_card_iq_test_subtitle"),
                    }),
                    (0, t.jsx)("div", {
                      className:
                        "mt-[0.5%] text-[4.07vw] font-semibold leading-none text-blue-custom blur-[7px] min-[542px]:mt-0.5 min-[542px]:text-[22px] lg:mt-[0.5%] lg:text-[26px]",
                      children: "???",
                    }),
                    (0, t.jsxs)("div", {
                      className: "mt-auto flex flex-row items-end justify-between gap-3 pb-0 lg:gap-6",
                      children: [
                        (0, t.jsxs)("div", {
                          className:
                            "flex gap-3 text-[1.15vw] min-[542px]:gap-4 min-[542px]:text-[7px] lg:gap-5 lg:text-[9px]",
                          children: [
                            (0, t.jsxs)("div", {
                              children: [
                                (0, t.jsx)("div", {
                                  className: "text-cert-grey-light",
                                  children: e("certificate_card_date_of_receiving"),
                                }),
                                (0, t.jsx)("div", {
                                  className: "mt-0.5 font-medium text-dark-custom blur-[4px]",
                                  children: "01.01.2026",
                                }),
                              ],
                            }),
                            (0, t.jsxs)("div", {
                              children: [
                                (0, t.jsx)("div", {
                                  className: "text-cert-grey-light",
                                  children: e("certificate_card_certificate_id"),
                                }),
                                (0, t.jsx)("div", {
                                  className: "mt-0.5 font-medium text-dark-custom blur-[4px]",
                                  children: "429 479",
                                }),
                              ],
                            }),
                          ],
                        }),
                        (0, t.jsxs)("div", {
                          className:
                            "mb-[0.8vw] flex gap-3 text-center text-[0.95vw] text-cert-grey-light min-[542px]:mb-0 min-[542px]:gap-4 min-[542px]:text-[6px] lg:gap-5 lg:text-[8px]",
                          children: [
                            (0, t.jsxs)("div", {
                              className: "w-[20vw] min-[542px]:w-[116px] lg:w-[100px]",
                              children: [
                                (0, t.jsx)("div", {
                                  className:
                                    "relative flex h-[5vw] items-end border-b border-cert-grey-pale min-[542px]:h-[24px] lg:h-[32px]",
                                  children: (0, t.jsx)(l.default, {
                                    src: r.ImgSignature1,
                                    alt: "Director of Assessments",
                                    fill: !0,
                                    className: "!object-contain object-bottom",
                                  }),
                                }),
                                (0, t.jsx)("div", {
                                  className: "mt-0.5",
                                  children: e("certificate_card_director_of_assessments"),
                                }),
                              ],
                            }),
                            (0, t.jsxs)("div", {
                              className: "w-[13vw] min-[542px]:w-[82px] lg:w-[80px]",
                              children: [
                                (0, t.jsx)("div", {
                                  className:
                                    "relative flex h-[5vw] items-end border-b border-cert-grey-pale min-[542px]:h-[24px] lg:h-[32px]",
                                  children: (0, t.jsx)(l.default, {
                                    src: r.ImgSignature2,
                                    alt: "Validation Officer",
                                    fill: !0,
                                    className: "!object-contain object-bottom",
                                  }),
                                }),
                                (0, t.jsx)("div", {
                                  className: "mt-0.5",
                                  children: e("certificate_card_validation_officer"),
                                }),
                              ],
                            }),
                          ],
                        }),
                      ],
                    }),
                  ],
                }),
              }),
              (0, t.jsx)("div", {
                className: "pointer-events-none absolute inset-0 grid place-items-center",
                children: (0, t.jsx)("div", {
                  className:
                    "grid h-[50px] w-[50px] place-items-center rounded-full border border-[rgba(26,107,255,0.30)] bg-white/90 shadow-[0_4px_16px_rgba(10,27,94,0.10)]",
                  style: { backdropFilter: "blur(2px)" },
                  children: (0, t.jsx)(i, { size: 18, className: "text-[#1A6BFF]" }),
                }),
              }),
            ],
          });
        },
      ],
      451747,
    );
  },
  932607,
  function (e) {
    e.n(e.i(451747));
  },
]);
