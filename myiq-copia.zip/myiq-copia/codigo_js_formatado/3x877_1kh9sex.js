(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  882983,
  (e) => {
    "use strict";
    var i = e.i(265840),
      t = e.i(271645),
      a = e.i(273830),
      l = e.i(620253),
      n = e.i(75540),
      s = e.i(843476),
      o = (0, a.forwardRef)((e, a) => {
        let { as: o, children: r, className: d, ...c } = e,
          { slots: f, classNames: m, bodyId: u, setBodyMounted: p } = (0, i.useModalContext)(),
          x = (0, l.useDOMRef)(a);
        return (
          (0, t.useEffect)(() => (p(!0), () => p(!1)), [p]),
          (0, s.jsx)(o || "div", {
            ref: x,
            className: f.body({ class: (0, n.clsx)(null == m ? void 0 : m.body, d) }),
            id: u,
            ...c,
            children: r,
          })
        );
      });
    ((o.displayName = "HeroUI.ModalBody"), e.s(["ModalBody", 0, o], 882983));
  },
  317197,
  231529,
  (e) => {
    "use strict";
    var i = e.i(843476),
      t = e.i(882983),
      a = e.i(742214),
      l = e.i(663615);
    e.i(680460);
    var n = e.i(885944);
    (e.s([], 317197),
      e.s(
        [
          "ModalBodyComponent",
          0,
          (e) => {
            let {
              children: s,
              title: o,
              subtitle: r,
              className: d = "",
              bodyClassName: c,
              titleClassName: f,
            } = e;
            return (0, i.jsx)(a.ModalContent, {
              className: d,
              children: (0, i.jsxs)(t.ModalBody, {
                className: (0, l.cn)(
                  "flex h-full w-full flex-col gap-5 p-5 antialiased md:p-6 [@media(max-height:580px)]:gap-3 [@media(max-height:580px)]:p-4",
                  c,
                ),
                children: [
                  (o || r) &&
                    (0, i.jsx)(n.ModalHeaderComponent, { title: o, subtitle: r, titleClassName: f }),
                  s,
                ],
              }),
            });
          },
        ],
        231529,
      ));
  },
  253163,
  (e) => {
    "use strict";
    var i = e.i(843476),
      t = e.i(948148),
      a = e.i(271645);
    e.i(317197);
    var l = e.i(231529),
      n = e.i(523173),
      s = e.i(622963);
    e.i(568267);
    var o = e.i(154692);
    e.i(470366);
    var r = e.i(504001);
    (e.s([], 130693),
      e.i(130693),
      e.s(
        [
          "PrintedCertificateConfirmModalComponent",
          0,
          (e) => {
            let { user: d, price: c, onConfirm: f, onClose: m } = e,
              u = (0, t.useTranslations)(),
              p = (0, s.useModalStore)((e) => e.handleChangeModalStore),
              [x, h] = (0, a.useState)(!1);
            (0, a.useEffect)(() => {
              (0, r.trackClientEvents)({
                event: n.EAnalyticEvents.PRINTED_CERTIFICATE_PAY_MODAL_VIEWED,
                user: d,
                params: { funnel: d?.funnel },
              });
            }, []);
            let _ = async () => {
              h(!0);
              try {
                await f();
              } finally {
                h(!1);
              }
            };
            return (0, i.jsxs)(l.ModalBodyComponent, {
              title: u("printed_certificate_confirm_title"),
              subtitle: u("printed_certificate_confirm_subtitle", { price: c }),
              children: [
                (0, i.jsxs)("div", {
                  className: "flex flex-col gap-2.5",
                  children: [
                    (0, i.jsx)(o.ButtonComponent, {
                      size: "sm",
                      fullWidth: !0,
                      onClick: _,
                      isLoading: x,
                      children: u("printed_certificate_confirm_btn_charge", { price: c }),
                    }),
                    (0, i.jsx)(o.ButtonComponent, {
                      variant: "default",
                      size: "sm",
                      onClick: () => {
                        (m?.(), p({ isModalVisible: !1, modalComponent: null }));
                      },
                      isDisabled: x,
                      children: u("printed_certificate_confirm_btn_cancel"),
                    }),
                  ],
                }),
                (0, i.jsxs)("div", {
                  className:
                    "mt-2 gap-0.5 break-keep text-center text-xs italic leading-tight text-default-600",
                  children: [
                    (0, i.jsx)("div", { className: "inline", children: "*" }),
                    u("printed_certificate_confirm_disclaimer", { price: c }),
                  ],
                }),
              ],
            });
          },
        ],
        253163,
      ));
  },
  833323,
  function (e) {
    e.n(e.i(253163));
  },
]);
