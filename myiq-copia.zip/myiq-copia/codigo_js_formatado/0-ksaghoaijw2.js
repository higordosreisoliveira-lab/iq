(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  882983,
  (e) => {
    "use strict";
    var t = e.i(265840),
      i = e.i(271645),
      a = e.i(273830),
      r = e.i(620253),
      s = e.i(75540),
      n = e.i(843476),
      l = (0, a.forwardRef)((e, a) => {
        let { as: l, children: o, className: c, ...d } = e,
          { slots: p, classNames: m, bodyId: u, setBodyMounted: h } = (0, t.useModalContext)(),
          v = (0, r.useDOMRef)(a);
        return (
          (0, i.useEffect)(() => (h(!0), () => h(!1)), [h]),
          (0, n.jsx)(l || "div", {
            ref: v,
            className: p.body({ class: (0, s.clsx)(null == m ? void 0 : m.body, c) }),
            id: u,
            ...d,
            children: o,
          })
        );
      });
    ((l.displayName = "HeroUI.ModalBody"), e.s(["ModalBody", 0, l], 882983));
  },
  949411,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("clock", [
      ["path", { d: "M12 6v6l4 2", key: "mmk7yg" }],
      ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
    ]);
    e.s(["default", 0, t]);
  },
  503116,
  (e) => {
    "use strict";
    var t = e.i(949411);
    e.s(["Clock", () => t.default]);
  },
  914299,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("heart", [
      [
        "path",
        {
          d: "M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5",
          key: "mvr1a0",
        },
      ],
    ]);
    e.s(["default", 0, t]);
  },
  790597,
  (e) => {
    "use strict";
    var t = e.i(914299);
    e.s(["Heart", () => t.default]);
  },
  531278,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("loader-circle", [
      ["path", { d: "M21 12a9 9 0 1 1-6.219-8.56", key: "13zald" }],
    ]);
    e.s(["Loader2", 0, t], 531278);
  },
  661263,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("split", [
      ["path", { d: "M16 3h5v5", key: "1806ms" }],
      ["path", { d: "M8 3H3v5", key: "15dfkv" }],
      ["path", { d: "M12 22v-8.3a4 4 0 0 0-1.172-2.872L3 3", key: "1qrqzj" }],
      ["path", { d: "m15 9 6-6", key: "ko1vev" }],
    ]);
    e.s(["Split", 0, t], 661263);
  },
  732832,
  85170,
  (e) => {
    "use strict";
    var t = e.i(843476);
    let i = {
      "arrow-right": (0, t.jsxs)(t.Fragment, {
        children: [(0, t.jsx)("path", { d: "M5 12h14" }), (0, t.jsx)("path", { d: "m12 5 7 7-7 7" })],
      }),
      brain: (0, t.jsxs)(t.Fragment, {
        children: [
          (0, t.jsx)("path", { d: "M12 18V5" }),
          (0, t.jsx)("path", { d: "M15 13a4.17 4.17 0 0 1-3-4 4.17 4.17 0 0 1-3 4" }),
          (0, t.jsx)("path", { d: "M17.598 6.5A3 3 0 1 0 12 5a3 3 0 1 0-5.598 1.5" }),
          (0, t.jsx)("path", { d: "M17.997 5.125a4 4 0 0 1 2.526 5.77" }),
          (0, t.jsx)("path", { d: "M18 18a4 4 0 0 0 2-7.464" }),
          (0, t.jsx)("path", { d: "M19.967 17.483A4 4 0 1 1 12 18a4 4 0 1 1-7.967-.517" }),
          (0, t.jsx)("path", { d: "M6 18a4 4 0 0 1-2-7.464" }),
          (0, t.jsx)("path", { d: "M6.003 5.125a4 4 0 0 0-2.526 5.77" }),
        ],
      }),
      check: (0, t.jsx)("path", { d: "M20 6 9 17l-5-5" }),
      clock: (0, t.jsxs)(t.Fragment, {
        children: [
          (0, t.jsx)("path", { d: "M12 6v6l4 2" }),
          (0, t.jsx)("circle", { cx: "12", cy: "12", r: "10" }),
        ],
      }),
      eye: (0, t.jsxs)(t.Fragment, {
        children: [
          (0, t.jsx)("path", {
            d: "M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",
          }),
          (0, t.jsx)("circle", { cx: "12", cy: "12", r: "3" }),
        ],
      }),
      flame: (0, t.jsx)("path", {
        d: "M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z",
      }),
      gift: (0, t.jsxs)(t.Fragment, {
        children: [
          (0, t.jsx)("rect", { height: "4", rx: "1", width: "18", x: "3", y: "8" }),
          (0, t.jsx)("path", { d: "M12 8v13" }),
          (0, t.jsx)("path", { d: "M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7" }),
          (0, t.jsx)("path", {
            d: "M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5",
          }),
        ],
      }),
      heart: (0, t.jsx)("path", {
        d: "M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5",
      }),
      "heart-crack": (0, t.jsxs)(t.Fragment, {
        children: [
          (0, t.jsx)("path", {
            d: "M12.409 5.824c-.702.792-1.15 1.496-1.415 2.166l2.153 2.156a.5.5 0 0 1 0 .707l-2.293 2.293a.5.5 0 0 0 0 .707L12 15",
          }),
          (0, t.jsx)("path", {
            d: "M13.508 20.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5a5.5 5.5 0 0 1 9.591-3.677.6.6 0 0 0 .818.001A5.5 5.5 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5z",
          }),
        ],
      }),
      plus: (0, t.jsxs)(t.Fragment, {
        children: [(0, t.jsx)("path", { d: "M5 12h14" }), (0, t.jsx)("path", { d: "M12 5v14" })],
      }),
      puzzle: (0, t.jsx)("path", {
        d: "M15.39 4.39a1 1 0 0 0 1.68-.474 2.5 2.5 0 1 1 3.014 3.015 1 1 0 0 0-.474 1.68l1.683 1.682a2.414 2.414 0 0 1 0 3.414L19.61 15.39a1 1 0 0 1-1.68-.474 2.5 2.5 0 1 0-3.014 3.015 1 1 0 0 1 .474 1.68l-1.683 1.682a2.414 2.414 0 0 1-3.414 0L8.61 19.61a1 1 0 0 0-1.68.474 2.5 2.5 0 1 1-3.014-3.015 1 1 0 0 0 .474-1.68l-1.683-1.682a2.414 2.414 0 0 1 0-3.414L4.39 8.61a1 1 0 0 1 1.68.474 2.5 2.5 0 1 0 3.014-3.015 1 1 0 0 1-.474-1.68l1.683-1.682a2.414 2.414 0 0 1 3.414 0z",
      }),
      split: (0, t.jsxs)(t.Fragment, {
        children: [
          (0, t.jsx)("path", { d: "M16 3h5v5" }),
          (0, t.jsx)("path", { d: "M8 3H3v5" }),
          (0, t.jsx)("path", { d: "M12 22v-8.3a4 4 0 0 0-1.172-2.872L3 3" }),
          (0, t.jsx)("path", { d: "m15 9 6-6" }),
        ],
      }),
      target: (0, t.jsxs)(t.Fragment, {
        children: [
          (0, t.jsx)("circle", { cx: "12", cy: "12", r: "10" }),
          (0, t.jsx)("circle", { cx: "12", cy: "12", r: "6" }),
          (0, t.jsx)("circle", { cx: "12", cy: "12", r: "2" }),
        ],
      }),
      timer: (0, t.jsxs)(t.Fragment, {
        children: [
          (0, t.jsx)("line", { x1: "10", x2: "14", y1: "2", y2: "2" }),
          (0, t.jsx)("line", { x1: "12", x2: "15", y1: "14", y2: "11" }),
          (0, t.jsx)("circle", { cx: "12", cy: "14", r: "8" }),
        ],
      }),
      x: (0, t.jsxs)(t.Fragment, {
        children: [(0, t.jsx)("path", { d: "M18 6 6 18" }), (0, t.jsx)("path", { d: "m6 6 12 12" })],
      }),
      zap: (0, t.jsx)("path", {
        d: "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",
      }),
    };
    (e.s([], 732832),
      e.s(
        [
          "TriviaIconComponent",
          0,
          (e) => {
            let { className: a, isFilled: r = !1, name: s } = e;
            return (0, t.jsx)("svg", {
              "aria-hidden": !0,
              className: a,
              fill: r ? "currentColor" : "none",
              stroke: "currentColor",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: 1.5,
              viewBox: "0 0 24 24",
              xmlns: "http://www.w3.org/2000/svg",
              children: i[s],
            });
          },
        ],
        85170,
      ));
  },
  496724,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(531278),
      a = e.i(948148),
      r = e.i(271645),
      s = e.i(503116),
      n = e.i(790597),
      l = e.i(661263);
    e.i(804751);
    var o = e.i(818660),
      c = e.i(48859);
    e.i(476643);
    var d = e.i(408241),
      p = e.i(903354),
      m = e.i(946684);
    e.i(380251);
    var u = e.i(618208);
    e.i(317197);
    var h = e.i(231529),
      v = e.i(523173),
      x = e.i(622963),
      y = e.i(86596),
      g = e.i(265832);
    e.i(470366);
    var f = e.i(504001),
      b = e.i(998198);
    let _ = (e, t) => {
        let { priceForView: i } = (0, b.getPaymentPlanPrice)({ paymentPlan: e, user: t });
        return (0, b.getCalculatePriceForView)(i, t);
      },
      I = (e) => ("hearts" in e ? e.hearts : "uses" in e ? e.uses : 0);
    e.i(80460);
    var T = e.i(973654);
    let j = {
      "extra-time": T.EOffers.TRIVIA_TIME,
      "fifty-fifty": T.EOffers.TRIVIA_HINTS,
      hearts: T.EOffers.TRIVIA_CREDITS,
    };
    e.i(732832);
    var A = e.i(85170);
    let k = (e) => {
        let { isDisabled: i = !1, label: a, onClick: r } = e;
        return (0, t.jsx)("button", {
          "aria-label": a,
          className:
            "absolute end-3 top-3 z-[var(--ds-primitive-layer-raised)] flex h-10 w-10 items-center justify-center rounded-[var(--ds-semantic-radius-pill)] bg-[var(--ds-semantic-color-surface-page)] text-[var(--ds-semantic-color-text-secondary)] transition-colors duration-[var(--ds-semantic-motion-instant)] hover:bg-[color-mix(in_srgb,var(--ds-semantic-color-state-layer-on-light)_4%,var(--ds-semantic-color-surface-page))] hover:text-[var(--ds-semantic-color-text-primary)] focus-visible:outline focus-visible:outline-[length:var(--ds-primitive-dimension-borderWidth-thick)] focus-visible:outline-offset-[var(--ds-primitive-dimension-size-half-2)] focus-visible:outline-[var(--ds-semantic-color-border-focus)] active:bg-[color-mix(in_srgb,var(--ds-semantic-color-state-layer-on-light)_6%,var(--ds-semantic-color-surface-page))] disabled:cursor-not-allowed disabled:opacity-[var(--ds-semantic-opacity-disabled-content)] motion-reduce:transition-none",
          disabled: i,
          onClick: r,
          type: "button",
          children: (0, t.jsx)(A.TriviaIconComponent, { className: "h-6 w-6", name: "x" }),
        });
      },
      M = (e) => {
        let { glyph: i, isClosable: a, text: r, title: s } = e;
        return (0, t.jsxs)("div", {
          className: "flex flex-col items-center gap-4",
          children: [
            i,
            (0, t.jsx)("h2", {
              className: `w-full text-balance text-center text-[length:var(--ds-primitive-typography-scale-h3-font-size)] font-bold leading-[var(--ds-primitive-typography-scale-h3-line-height)] tracking-[var(--ds-primitive-typography-scale-h3-letter-spacing)] text-[var(--ds-semantic-color-text-primary)] ${a ? "px-10" : ""}`,
              children: s,
            }),
            (0, t.jsx)("p", {
              className:
                "w-full text-pretty text-center text-[length:var(--ds-primitive-typography-scale-body-font-size)] leading-[var(--ds-primitive-typography-scale-body-line-height)] tracking-[var(--ds-primitive-typography-scale-body-letter-spacing)] text-[var(--ds-semantic-color-text-secondary)]",
              children: r,
            }),
          ],
        });
      },
      R = {
        head: "size-12 bg-[var(--ds-semantic-color-surface-raised)]",
        "row-inset": "size-10 bg-[var(--ds-semantic-color-surface-page)]",
      },
      E = (e) => {
        let { kind: i, plate: a } = e,
          r =
            "hearts" === i
              ? (0, t.jsx)(A.TriviaIconComponent, {
                  className: "h-6 w-6 shrink-0 text-[var(--ds-semantic-color-feedback-danger)]",
                  isFilled: !0,
                  name: "heart",
                })
              : "extra-time" === i
                ? (0, t.jsx)(A.TriviaIconComponent, {
                    className: "h-6 w-6 shrink-0 text-[var(--ds-semantic-color-brand-base)]",
                    name: "clock",
                  })
                : (0, t.jsx)(A.TriviaIconComponent, {
                    className: "h-6 w-6 shrink-0 text-[var(--ds-semantic-color-text-primary)]",
                    name: "split",
                  });
        return (0, t.jsx)("span", {
          "aria-hidden": !0,
          className: `flex shrink-0 items-center justify-center rounded-[var(--ds-semantic-radius-pill)] ${R[a]}`,
          children: r,
        });
      };
    var C = e.i(361582),
      S = e.i(785817),
      L = e.i(239512);
    let V =
        "text-[length:var(--ds-primitive-typography-scale-body-font-size)] font-semibold leading-[var(--ds-primitive-typography-scale-body-line-height)] tracking-[var(--ds-primitive-typography-scale-body-letter-spacing)] tabular-nums",
      N =
        "flex size-6 shrink-0 items-center justify-center rounded-[var(--ds-semantic-radius-pill)] border-[length:var(--ds-primitive-dimension-borderWidth-light)] border-solid",
      w = (e) => {
        let { isDisabled: i, kind: a, onSelect: r, packages: s, selectedIndex: n, t: l } = e,
          { onKeyDown: o, setRef: c } = (0, S.useRovingRadio)(s.length, n, r);
        return (0, t.jsx)("div", {
          "aria-label": l(C.TRIVIA_SHOP_KEYS.selectPackage),
          className: "flex flex-col gap-3",
          onKeyDown: o,
          role: "radiogroup",
          children: s.map((e, s) => {
            let o = s === n;
            return (0, t.jsxs)(
              "button",
              {
                ref: c(s),
                "aria-checked": o,
                className: `flex min-h-14 w-full items-center gap-3 rounded-[var(--ds-semantic-radius-card)] border-[length:var(--ds-primitive-dimension-borderWidth-hairline)] border-solid bg-[var(--ds-semantic-color-surface-page)] px-4 py-3 text-start transition-[background-color,border-color,color,transform] duration-[var(--ds-semantic-motion-instant)] hover:bg-[var(--ds-primitive-color-neutral-50)] focus-visible:outline focus-visible:outline-[length:var(--ds-primitive-dimension-borderWidth-thick)] focus-visible:outline-offset-[var(--ds-primitive-dimension-size-half-2)] focus-visible:outline-[var(--ds-semantic-color-border-focus)] active:scale-[0.97] disabled:cursor-not-allowed motion-reduce:transition-none motion-reduce:active:scale-100 ${o ? "border-[color:var(--ds-semantic-color-border-accent)]" : "border-[color:var(--ds-semantic-color-border-strong)] hover:border-[color:var(--ds-primitive-color-neutral-400)]"}`,
                disabled: i,
                onClick: () => r(s),
                role: "radio",
                tabIndex: o ? 0 : -1,
                type: "button",
                children: [
                  o
                    ? (0, t.jsx)("span", {
                        "aria-hidden": !0,
                        className: `${N} border-[color:var(--ds-semantic-color-border-accent)] bg-[var(--ds-semantic-color-accent-base)] text-[var(--ds-semantic-color-text-on-accent)]`,
                        children: (0, t.jsx)(A.TriviaIconComponent, { className: "h-4 w-4", name: "check" }),
                      })
                    : (0, t.jsx)("span", {
                        "aria-hidden": !0,
                        className: `${N} border-[color:var(--ds-semantic-color-border-strong)] bg-[var(--ds-semantic-color-surface-page)]`,
                      }),
                  (0, t.jsxs)("span", {
                    className: "flex min-w-0 flex-1 flex-wrap items-center gap-x-2 gap-y-1",
                    children: [
                      (0, t.jsx)("span", {
                        className: `${V} ${o ? "text-[var(--ds-semantic-color-accent-base)]" : "text-[var(--ds-semantic-color-text-primary)]"}`,
                        children: (0, L.getAmountLabel)(l, a, e.amount),
                      }),
                      e.isBestValue
                        ? (0, t.jsx)("span", {
                            className:
                              "inline-flex h-6 items-center whitespace-nowrap rounded-[var(--ds-semantic-radius-pill)] bg-[var(--ds-semantic-color-surface-brand-muted)] px-2 text-[length:var(--ds-primitive-typography-scale-caption-font-size)] font-semibold leading-[var(--ds-primitive-typography-scale-caption-line-height)] tracking-[var(--ds-primitive-typography-scale-caption-letter-spacing)] text-[var(--ds-semantic-color-text-primary)]",
                            children: l(C.TRIVIA_SHOP_KEYS.bestValue),
                          })
                        : null,
                    ],
                  }),
                  (0, t.jsx)("span", {
                    className: `${V} shrink-0 text-[var(--ds-semantic-color-text-primary)]`,
                    children: e.price,
                  }),
                ],
              },
              e.amount,
            );
          }),
        });
      };
    (e.s([], 730018),
      e.i(730018),
      e.s(
        [
          "TriviaPurchaseModalComponent",
          0,
          (e) => {
            let { type: T } = e,
              A = (0, r.useRef)(!1),
              R = (0, a.useTranslations)(),
              S = (0, y.useUserStore)((e) => e.user),
              { data: V } = (0, m.useGetProfileQuery)(S?.email || ""),
              N = V?.data?.user_info,
              F = (0, x.useModalStore)((e) => e.handleChangeModalStore),
              z = (0, d.useTriviaTestStore)((e) => e.handleTriviaTestStore),
              P = (0, d.useTriviaTestStore)((e) => e.fiftyFiftyRefillAt),
              B = (0, d.useTriviaTestStore)((e) => e.extraTimeRefillAt),
              D = (0, d.useTriviaTestStore)((e) => e.currentCognitiveSkill),
              H = (0, d.useTriviaTestStore)((e) => e.heartsRefillAt),
              { timeUntilNextTest: O } = (0, o.useProfileTriviaService)(N || null, D),
              [Y, W] = (0, r.useState)(!1),
              [U, $] = (0, r.useState)(!1),
              [K, G] = (0, r.useState)("");
            (0, r.useEffect)(() => {
              let e = () => {
                "fifty-fifty" === T && P
                  ? G((0, c.getRefillTimeRemaining)(P))
                  : "extra-time" === T && B
                    ? G((0, c.getRefillTimeRemaining)(B))
                    : "hearts" === T
                      ? G(O)
                      : G("");
              };
              e();
              let t = setInterval(e, 1e3);
              return () => clearInterval(t);
            }, [T, P, B, O]);
            let X = ((e, t) => {
                switch (e) {
                  case "hearts":
                    return [
                      { id: "small", hearts: 5, price: _("TRIVIA_HEARTS_SMALL", t), isBestValue: !1 },
                      { id: "medium", hearts: 20, price: _("TRIVIA_HEARTS_MEDIUM", t), isBestValue: !1 },
                      { id: "large", hearts: 50, price: _("TRIVIA_HEARTS_LARGE", t), isBestValue: !0 },
                    ];
                  case "fifty-fifty":
                    return [
                      {
                        id: "fifty-fifty-small",
                        uses: 5,
                        price: _("TRIVIA_FIFTY_FIFTY_SMALL", t),
                        bestValue: !1,
                      },
                      {
                        id: "fifty-fifty-medium",
                        uses: 15,
                        price: _("TRIVIA_FIFTY_FIFTY_MEDIUM", t),
                        bestValue: !1,
                      },
                      {
                        id: "fifty-fifty-large",
                        uses: 50,
                        price: _("TRIVIA_FIFTY_FIFTY_LARGE", t),
                        bestValue: !0,
                      },
                    ];
                  case "extra-time":
                    let i;
                    return [
                      {
                        id: "extra-time-small",
                        uses: 5,
                        price: _("TRIVIA_EXTRA_TIME_SMALL", (i = t)),
                        bestValue: !1,
                      },
                      {
                        id: "extra-time-medium",
                        uses: 15,
                        price: _("TRIVIA_EXTRA_TIME_MEDIUM", i),
                        bestValue: !1,
                      },
                      {
                        id: "extra-time-large",
                        uses: 50,
                        price: _("TRIVIA_EXTRA_TIME_LARGE", i),
                        bestValue: !0,
                      },
                    ];
                  default:
                    return [];
                }
              })(T, S),
              q = X.map((e) => ({ amount: I(e), isBestValue: !!e.isBestValue, price: String(e.price) })),
              [Q, J] = (0, r.useState)(C.TRIVIA_SHOP_DEFAULT_PACKAGE_INDEX),
              Z = X[Q] ?? X[0],
              ee = q[Q] ?? q[0],
              et = {
                hearts: {
                  icon: n.Heart,
                  color: "red",
                  iconColor: "text-red-500 fill-red-500",
                  title: function () {
                    let e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    return R(
                      e ? "trivia_purchase_hearts_title_ran_out" : "trivia_purchase_hearts_title_get_more",
                    );
                  },
                  subtitle: function () {
                    let e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    return R(
                      e
                        ? "trivia_purchase_hearts_subtitle_required"
                        : "trivia_purchase_hearts_subtitle_optional",
                    );
                  },
                  itemLabel: R("trivia_purchase_hearts_item_label"),
                  buttonLabel: (e) => R("trivia_purchase_hearts_button_label", { amount: String(e) }),
                  waitLabel: function () {
                    let e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
                      t = arguments.length > 1 ? arguments[1] : void 0;
                    return t
                      ? R("trivia_purchase_wait_refill", { time: t })
                      : R(e ? "trivia_purchase_wait_30_min" : "trivia_purchase_close");
                  },
                  event_name: "credits",
                },
                "fifty-fifty": {
                  icon: l.Split,
                  color: "purple",
                  iconColor: "text-slate-700",
                  title: () => R("trivia_purchase_fifty_fifty_title"),
                  subtitle: () => R("trivia_purchase_fifty_fifty_subtitle"),
                  itemLabel: R("trivia_purchase_fifty_fifty_item_label"),
                  buttonLabel: (e) => R("trivia_purchase_fifty_fifty_button_label", { amount: String(e) }),
                  event_name: "hints",
                },
                "extra-time": {
                  icon: s.Clock,
                  color: "blue",
                  iconColor: "text-slate-700",
                  title: () => R("trivia_purchase_extra_time_title"),
                  subtitle: () => R("trivia_purchase_extra_time_subtitle"),
                  itemLabel: R("trivia_purchase_extra_time_item_label"),
                  buttonLabel: (e) => R("trivia_purchase_extra_time_button_label", { amount: String(e) }),
                  event_name: "time",
                },
              }[T],
              ei = "hearts" === T && "isRequired" in e && !!e.isRequired,
              ea = "hearts" !== T || !ei,
              er = (0, L.getCtaLabel)(R, T, ee),
              es = (0, L.getWaitLabel)(R, T, ei, K);
            (0, r.useEffect)(() => {
              A.current ||
                ((0, f.trackClientEvents)({
                  event: v.EAnalyticEvents.TRIVIA_ADD_ON_MODAL_VIEWED,
                  params: {
                    add_on_type: et.event_name,
                    modal_placement: e?.isFromRefillBanner ? "Refill Banner" : "Trivia Test",
                  },
                }),
                (A.current = !0));
            }, [T]);
            let en = ea
              ? (0, t.jsx)(k, {
                  isDisabled: Y,
                  label: R(C.TRIVIA_SHOP_KEYS.close),
                  onClick: () => {
                    (e.onClose?.(), F({ isModalVisible: !1, modalComponent: null }));
                  },
                })
              : null;
            return U
              ? (0, t.jsxs)(h.ModalBodyComponent, {
                  bodyClassName: "relative gap-6 p-6 md:p-8",
                  children: [
                    (0, t.jsx)(M, {
                      isClosable: ea,
                      text: (0, L.getConfirmText)(R, T, ee),
                      title: R(C.TRIVIA_SHOP_KEYS.confirmTitle),
                    }),
                    (0, t.jsxs)("div", {
                      className:
                        "flex items-center gap-3 rounded-[var(--ds-semantic-radius-card)] bg-[var(--ds-semantic-color-surface-raised)] p-3",
                      children: [
                        (0, t.jsx)(E, { kind: T, plate: "row-inset" }),
                        (0, t.jsx)("span", {
                          className:
                            "min-w-0 flex-1 text-[length:var(--ds-primitive-typography-scale-body-font-size)] font-semibold tabular-nums leading-[var(--ds-primitive-typography-scale-body-line-height)] tracking-[var(--ds-primitive-typography-scale-body-letter-spacing)] text-[var(--ds-semantic-color-text-primary)]",
                          children: (0, L.getAmountLabel)(R, T, ee.amount),
                        }),
                        (0, t.jsx)("span", {
                          className:
                            "shrink-0 pe-1 text-[length:var(--ds-primitive-typography-scale-body-font-size)] font-semibold tabular-nums leading-[var(--ds-primitive-typography-scale-body-line-height)] tracking-[var(--ds-primitive-typography-scale-body-letter-spacing)] text-[var(--ds-semantic-color-text-primary)]",
                          children: ee.price,
                        }),
                      ],
                    }),
                    (0, t.jsxs)("div", {
                      className: "flex flex-col gap-3",
                      children: [
                        (0, t.jsxs)(u.ButtonComponent, {
                          disabled: Y,
                          fullWidth: !0,
                          onClick: () => {
                            var t;
                            let i;
                            W(!0);
                            let a = (0, p.preparePaynextParams)({
                              user: N || S,
                              metadata: {
                                amount:
                                  ((t = N || S),
                                  (i = ((e, t) => {
                                    if ("hearts" === t)
                                      switch (e.id) {
                                        case "small":
                                          return "TRIVIA_HEARTS_SMALL";
                                        case "medium":
                                          return "TRIVIA_HEARTS_MEDIUM";
                                        case "large":
                                          return "TRIVIA_HEARTS_LARGE";
                                      }
                                    else if ("fifty-fifty" === t)
                                      switch (e.id) {
                                        case "fifty-fifty-small":
                                          return "TRIVIA_FIFTY_FIFTY_SMALL";
                                        case "fifty-fifty-medium":
                                          return "TRIVIA_FIFTY_FIFTY_MEDIUM";
                                        case "fifty-fifty-large":
                                          return "TRIVIA_FIFTY_FIFTY_LARGE";
                                      }
                                    else if ("extra-time" === t)
                                      switch (e.id) {
                                        case "extra-time-small":
                                          return "TRIVIA_EXTRA_TIME_SMALL";
                                        case "extra-time-medium":
                                          return "TRIVIA_EXTRA_TIME_MEDIUM";
                                        case "extra-time-large":
                                          return "TRIVIA_EXTRA_TIME_LARGE";
                                      }
                                    return null;
                                  })(Z, T))
                                    ? ((e, t) => {
                                        let { priceForPay: i } = (0, b.getPaymentPlanPrice)({
                                          paymentPlan: e,
                                          user: t,
                                        });
                                        return i;
                                      })(i, t)
                                    : 0),
                                add_on_type: et.event_name,
                                product_type: "trivia",
                                currency: "USD",
                                user_id: S?.id || "",
                                mixpanel_user_id: S?.id || "",
                                language: S?.locale || "",
                                country: S?.currency?.countryCode || "",
                              },
                              offer: j[T],
                            });
                            ((0, p.trackPaynextPurchaseAttempt)({ user: N || S, paynextParams: a }),
                            "hearts" === e.type)
                              ? e.onBuyHearts(Z, W, $)
                              : e.onBuyPowerUp(Z, W, $);
                          },
                          size: "lg",
                          variant: "primary",
                          children: [
                            Y
                              ? (0, t.jsx)(i.Loader2, {
                                  "aria-hidden": !0,
                                  className: "h-4 w-4 shrink-0 animate-spin",
                                })
                              : null,
                            R(C.TRIVIA_SHOP_KEYS.confirm),
                          ],
                        }),
                        (0, t.jsx)(u.ButtonComponent, {
                          disabled: Y,
                          fullWidth: !0,
                          onClick: () => $(!1),
                          size: "lg",
                          variant: "secondary",
                          children: R(C.TRIVIA_SHOP_KEYS.back),
                        }),
                      ],
                    }),
                    (0, t.jsx)("p", {
                      className:
                        "text-pretty text-center text-[length:var(--ds-primitive-typography-scale-note-font-size)] leading-[var(--ds-primitive-typography-scale-note-line-height)] tracking-[var(--ds-primitive-typography-scale-note-letter-spacing)] text-[var(--ds-semantic-color-text-muted)]",
                      children: (0, L.getDisclaimer)(R, T, R(C.TRIVIA_SHOP_KEYS.confirm), ee.price, K),
                    }),
                    en,
                  ],
                })
              : (0, t.jsxs)(h.ModalBodyComponent, {
                  bodyClassName: "relative gap-6 p-6 md:p-8",
                  children: [
                    (0, t.jsx)(M, {
                      glyph: (0, t.jsx)(E, { kind: T, plate: "head" }),
                      isClosable: ea,
                      text: (0, L.getPurchaseText)(R, T, ei),
                      title: (0, L.getPurchaseTitle)(R, T, ei),
                    }),
                    (0, t.jsx)(w, {
                      isDisabled: Y,
                      kind: T,
                      onSelect: J,
                      packages: q,
                      selectedIndex: Q,
                      t: R,
                    }),
                    (0, t.jsxs)("div", {
                      className: "flex flex-col gap-3",
                      children: [
                        (0, t.jsxs)(u.ButtonComponent, {
                          disabled: Y,
                          fullWidth: !0,
                          onClick: () => {
                            ((0, f.trackClientEvents)({
                              event: v.EAnalyticEvents.TRIVIA_ADD_ON_BUY_CLICKED,
                              params: {
                                content_value: `${"hearts" === T ? "Buy" : "Get"} ${et.buttonLabel(I(Z), ei)}`,
                                add_on_type: et.event_name,
                                add_on_count: I(Z),
                                modal_placement: e?.isFromRefillBanner ? "Refill Banner" : "Trivia Test",
                              },
                            }),
                              $(!0));
                          },
                          size: "lg",
                          variant: "primary",
                          children: [
                            Y
                              ? (0, t.jsx)(i.Loader2, {
                                  "aria-hidden": !0,
                                  className: "h-4 w-4 shrink-0 animate-spin",
                                })
                              : null,
                            er,
                          ],
                        }),
                        es
                          ? (0, t.jsx)(u.ButtonComponent, {
                              disabled: Y,
                              fullWidth: !0,
                              onClick: () => {
                                ((0, f.trackClientEvents)({
                                  event: v.EAnalyticEvents.TRIVIA_ADD_ON_SKIP_CLICKED,
                                  params: {
                                    skip_option:
                                      ei || e?.isFromRefillBanner ? "Wait 30 Minutes" : "Close Button",
                                  },
                                }),
                                "hearts" === e.type &&
                                  (z({ heartsRefillAt: H || Date.now() + g.POWER_UPS_CONFIG.REFILL_TIME }),
                                  e.onWaitForNextTest))
                                  ? e.onWaitForNextTest()
                                  : F({ isModalVisible: !1, modalComponent: null });
                              },
                              size: "lg",
                              variant: "secondary",
                              children: es,
                            })
                          : null,
                      ],
                    }),
                    (0, t.jsx)("p", {
                      className:
                        "text-pretty text-center text-[length:var(--ds-primitive-typography-scale-note-font-size)] leading-[var(--ds-primitive-typography-scale-note-line-height)] tracking-[var(--ds-primitive-typography-scale-note-letter-spacing)] text-[var(--ds-semantic-color-text-muted)]",
                      children: (0, L.getDisclaimer)(R, T, er, ee.price, K),
                    }),
                    en,
                  ],
                });
          },
        ],
        496724,
      ));
  },
  335769,
  function (e) {
    e.n(e.i(496724));
  },
  380251,
  618208,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(202042);
    let a = /^(https?:|mailto:|\/|#)/i,
      r = /^(https?:|mailto:)/i,
      s = {
        sm: "h-[var(--ds-primitive-dimension-size-36)] px-[var(--ds-primitive-dimension-spacing-16)] text-[length:var(--ds-primitive-typography-scale-body-sm-font-size)] leading-[var(--ds-primitive-typography-scale-body-sm-line-height)] tracking-[var(--ds-primitive-typography-scale-body-sm-letter-spacing)]",
        md: "h-[var(--ds-primitive-dimension-size-44)] px-[var(--ds-primitive-dimension-spacing-20)] text-[length:var(--ds-primitive-typography-scale-body-sm-font-size)] leading-[var(--ds-primitive-typography-scale-body-sm-line-height)] tracking-[var(--ds-primitive-typography-scale-body-sm-letter-spacing)]",
        lg: "h-[var(--ds-primitive-dimension-size-48)] px-[var(--ds-primitive-dimension-spacing-24)] text-[length:var(--ds-primitive-typography-scale-body-font-size)] leading-[var(--ds-primitive-typography-scale-body-line-height)] tracking-[var(--ds-primitive-typography-scale-body-letter-spacing)]",
        xl: "h-[var(--ds-primitive-dimension-size-52)] px-[var(--ds-primitive-dimension-spacing-24)] text-[length:var(--ds-primitive-typography-scale-body-font-size)] leading-[var(--ds-primitive-typography-scale-body-line-height)] tracking-[var(--ds-primitive-typography-scale-body-letter-spacing)]",
      },
      n = {
        primary:
          "border-transparent bg-[var(--ds-semantic-color-accent-base)] text-[var(--ds-semantic-color-text-on-accent)]",
        secondary:
          "border-[var(--ds-semantic-color-border-accent)] bg-[var(--ds-semantic-color-surface-page)] text-[var(--ds-semantic-color-accent-base)]",
        ghost: "border-transparent bg-transparent text-[var(--ds-semantic-color-text-muted)]",
      },
      l = {
        primary:
          "group-hover:opacity-[var(--ds-semantic-opacity-hover-on-fill)] group-active:opacity-[var(--ds-semantic-opacity-pressed-on-fill)]",
        secondary:
          "group-hover:opacity-[var(--ds-semantic-opacity-hover-on-surface)] group-active:opacity-[var(--ds-semantic-opacity-pressed-on-surface)]",
        ghost:
          "group-hover:opacity-[var(--ds-semantic-opacity-hover-on-surface)] group-active:opacity-[var(--ds-semantic-opacity-pressed-on-surface)]",
      },
      o = { false: "w-auto", true: "w-full", "until-md": "w-full md:w-auto" },
      c = (e) => (a.test(e) ? e : "#");
    (e.s([], 380251),
      e.s(
        [
          "ButtonComponent",
          0,
          (e) => {
            let {
                children: a,
                className: d,
                disabled: p = !1,
                fullWidth: m = !1,
                href: u,
                icon: h,
                onClick: v,
                size: x = "md",
                type: y = "button",
                variant: g = "primary",
              } = e,
              f = `group relative isolate inline-flex items-center justify-center gap-x-[var(--ds-primitive-dimension-spacing-8)] overflow-hidden rounded-[var(--ds-semantic-radius-pill)] border-[length:var(--ds-primitive-dimension-borderWidth-hairline)] border-solid font-medium no-underline transition-[color,background-color,border-color,text-decoration-color,fill,stroke] duration-[var(--ds-semantic-motion-instant)] motion-reduce:transition-none focus-visible:outline focus-visible:outline-[length:var(--ds-primitive-dimension-borderWidth-thick)] focus-visible:outline-offset-[var(--ds-primitive-dimension-size-half-2)] focus-visible:outline-[var(--ds-semantic-color-border-focus)] disabled:opacity-[0.5] disabled:cursor-not-allowed ${s[x]} ${n[g]} ${o[String(m)]} ${d ?? ""}`,
              b = (0, t.jsx)("span", {
                "aria-hidden": "true",
                className: `absolute inset-0 -z-10 bg-[var(--ds-semantic-color-state-layer-on-light)] opacity-0 transition-opacity duration-[var(--ds-semantic-motion-instant)] motion-reduce:transition-none ${l[g]}`,
              });
            return u && r.test(u)
              ? (0, t.jsxs)("a", {
                  className: f,
                  href: c(u),
                  onClick: v,
                  rel: "noopener noreferrer",
                  target: "_blank",
                  children: [b, a, h],
                })
              : u
                ? (0, t.jsxs)(i.Link, { className: f, href: c(u), onClick: v, children: [b, a, h] })
                : (0, t.jsxs)("button", {
                    className: f,
                    disabled: p,
                    onClick: v,
                    type: y,
                    children: [b, a, h],
                  });
          },
        ],
        618208,
      ));
  },
  317197,
  231529,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(882983),
      a = e.i(742214),
      r = e.i(663615);
    e.i(680460);
    var s = e.i(885944);
    (e.s([], 317197),
      e.s(
        [
          "ModalBodyComponent",
          0,
          (e) => {
            let {
              children: n,
              title: l,
              subtitle: o,
              className: c = "",
              bodyClassName: d,
              titleClassName: p,
            } = e;
            return (0, t.jsx)(a.ModalContent, {
              className: c,
              children: (0, t.jsxs)(i.ModalBody, {
                className: (0, r.cn)(
                  "flex h-full w-full flex-col gap-5 p-5 antialiased md:p-6 [@media(max-height:580px)]:gap-3 [@media(max-height:580px)]:p-4",
                  d,
                ),
                children: [
                  (l || o) &&
                    (0, t.jsx)(s.ModalHeaderComponent, { title: l, subtitle: o, titleClassName: p }),
                  n,
                ],
              }),
            });
          },
        ],
        231529,
      ));
  },
]);
