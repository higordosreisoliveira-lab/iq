(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  985272,
  (e) => {
    "use strict";
    let t;
    var n = Object.defineProperty,
      a = (e, t, a) => {
        let r;
        return (r = "symbol" != typeof t ? t + "" : t) in e
          ? n(e, r, { enumerable: !0, configurable: !0, writable: !0, value: a })
          : (e[r] = a);
      };
    let r = null,
      i = null;
    class o extends Error {
      constructor(e, t = !0, n = !1) {
        const r =
          n && "u" > typeof window
            ? (function () {
                let e = navigator.connection || navigator.mozConnection || navigator.webkitConnection,
                  t = {
                    online: navigator.onLine,
                    documentHidden: document.hidden,
                    userAgent: navigator.userAgent,
                    timestamp: new Date().toISOString(),
                  };
                return (
                  e &&
                    ((t.connectionType = e.type),
                    (t.effectiveType = e.effectiveType),
                    (t.downlink = e.downlink),
                    (t.rtt = e.rtt),
                    (t.saveData = e.saveData)),
                  navigator.onLine
                    ? document.hidden
                      ? (t.likelyCause = "background_tab")
                      : e?.effectiveType === "slow-2g" || e?.effectiveType === "2g"
                        ? (t.likelyCause = "slow_connection")
                        : e?.downlink !== void 0 && e.downlink < 0.5 && (t.likelyCause = "poor_bandwidth")
                    : (t.likelyCause = "offline"),
                  t
                );
              })()
            : null;
        (super(
          r
            ? `${e} [${(function (e) {
                let t = [];
                return (
                  e.likelyCause && t.push(`cause=${e.likelyCause}`),
                  t.push(`online=${e.online}`),
                  t.push(`hidden=${e.documentHidden}`),
                  e.effectiveType && t.push(`net=${e.effectiveType}`),
                  void 0 !== e.downlink && t.push(`downlink=${e.downlink}Mbps`),
                  void 0 !== e.rtt && t.push(`rtt=${e.rtt}ms`),
                  t.join(", ")
                );
              })(r)}]`
            : e,
        ),
          a(this, "retryable"),
          a(this, "diagnostics"),
          (this.retryable = t),
          (this.name = "SDKLoadError"),
          (this.diagnostics = r));
      }
    }
    let s = "PayNextSDK";
    function l() {
      return typeof window > "u" ? null : window[s];
    }
    function c(e) {
      return new Promise((t) => setTimeout(t, e));
    }
    async function u() {
      let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 5e3,
        t = Math.ceil(e / 50);
      for (let e = 0; e < t; e++) {
        let e = l();
        if (e) return e;
        await c(50);
      }
      throw new o("PayNextSDK not found in window after waiting", !0, !0);
    }
    async function d(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
        n = e?.toLowerCase(),
        a =
          (n?.includes("develop") || n?.includes("staging") || n?.includes("preview")
            ? "develop"
            : "production") == "develop"
            ? "https://cdn-sdk-dev.paynext.com/index.cdn.js"
            : "https://cdn-sdk.paynext.com/index.cdn.js";
      try {
        return (
          l() ||
          (await new Promise((e, t) => {
            let n = document.querySelector(`script[src="${a}"]`);
            if (n) {
              if (l()) return void e();
              let a = setTimeout(() => {
                  (n.removeEventListener("load", r),
                    n.removeEventListener("error", i),
                    t(new o("Existing SDK script loading timeout", !0, !0)));
                }, 15e3),
                r = () => {
                  (clearTimeout(a), n.removeEventListener("load", r), n.removeEventListener("error", i), e());
                },
                i = () => {
                  (clearTimeout(a),
                    n.removeEventListener("load", r),
                    n.removeEventListener("error", i),
                    t(new o("Existing SDK script failed to load", !0, !0)));
                };
              return (n.addEventListener("load", r), void n.addEventListener("error", i));
            }
            let r = setTimeout(() => {
                (s(), t(new o("SDK script loading timeout", !0, !0)));
              }, 15e3),
              i = document.createElement("script");
            ((i.src = a),
              (i.crossOrigin = "anonymous"),
              (i.async = !0),
              i.setAttribute("data-paynext-sdk", "true"));
            let s = () => {
              (clearTimeout(r), (i.onload = null), (i.onerror = null));
            };
            ((i.onload = () => {
              (s(), e());
            }),
              (i.onerror = (e) => {
                (console.error("[PayNext CDN] Script load error:", e), s());
                try {
                  i.parentNode && i.parentNode.removeChild(i);
                } catch (e) {
                  console.warn("[PayNext CDN] Failed to remove script:", e);
                }
                t(new o("Failed to load SDK script from CDN", !0, !0));
              }));
            try {
              document.head.appendChild(i);
            } catch {
              (s(), t(new o("Failed to append script to document", !1)));
            }
          }),
          await u(5e3))
        );
      } catch (n) {
        if ((!(n instanceof o) || n.retryable) && t < 5)
          return (
            console.warn(`[PayNext CDN] Load attempt ${t} failed, retrying in 1500ms...`, n),
            await c(1500 * t),
            d(e, t + 1)
          );
        throw (console.error(`[PayNext CDN] Failed to load SDK after ${t} attempts:`, n), n);
      }
    }
    async function p(e) {
      if (i) return i;
      if (r) return r;
      if (typeof window > "u") throw new o("PayNext SDK can only be loaded in browser environment", !1);
      let t = l();
      return t
        ? (i = t)
        : (r = (async () => {
            try {
              let t = await d(e);
              return ((i = t), typeof window > "u" || (window[s] = t), t);
            } catch (e) {
              throw ((r = null), e);
            }
          })());
    }
    class _ {
      constructor() {
        (a(this, "cdnInstance", null),
          a(this, "initPromise", null),
          a(this, "isDestroyed", !1),
          a(this, "errorBoundary", null));
      }
      setErrorHandler(e) {
        this.errorBoundary = e;
      }
      handleError(e, t) {
        if ((console.error(`[PayNext SDK Error - ${t}]: ${e.message}`, e), this.errorBoundary))
          try {
            this.errorBoundary(e);
          } catch (e) {
            console.error("[PayNext SDK] Error in custom error handler:", e);
          }
      }
      async initialize(e) {
        if (this.isDestroyed) throw new o("Cannot initialize destroyed SDK instance", !1);
        return (
          this.initPromise ||
            (this.initPromise = (async () => {
              try {
                let t = await p(e);
                if (!t || !t.PayNextCheckout)
                  throw new o("PayNextCheckout not found in loaded SDK module", !1);
                try {
                  this.cdnInstance = new t.PayNextCheckout();
                } catch (e) {
                  throw new o(
                    `Failed to instantiate PayNextCheckout: ${e instanceof Error ? e.message : "Unknown error"}`,
                    !1,
                  );
                }
              } catch (e) {
                throw ((this.initPromise = null), e);
              }
            })()),
          this.initPromise
        );
      }
      assertReady() {
        if (this.isDestroyed) throw new o("SDK instance has been destroyed", !1);
        if (!this.initPromise) throw new o("SDK initialization not started", !1);
        if (!this.cdnInstance) throw new o("SDK instance not created", !1);
      }
      async mount(e, t) {
        try {
          if (!e || "string" != typeof e) throw new o("Invalid containerId provided", !1);
          if (!t || !t.environment) throw new o("Invalid config provided", !1);
          if (!document.getElementById(e)) throw new o(`Container element with id "${e}" not found`, !1);
          (await this.initialize(t.environment), this.assertReady(), await this.cdnInstance.mount(e, t));
        } catch (t) {
          let e = t instanceof o ? t : new o(t instanceof Error ? t.message : "Unknown mount error", !0);
          throw (this.handleError(e, "mount"), e);
        }
      }
      update(e) {
        try {
          if (this.isDestroyed) return void console.warn("[PayNext SDK] update called on destroyed instance");
          if (!this.cdnInstance) return void console.warn("[PayNext SDK] update called before mount");
          "function" == typeof this.cdnInstance.update
            ? this.cdnInstance.update(e)
            : console.warn(
                "[PayNext SDK] update() is not supported by the loaded CDN bundle; a newer SDK version is required",
              );
        } catch (t) {
          let e = t instanceof Error ? t : Error(String(t));
          this.handleError(e, "update");
        }
      }
      setPaymentsEnabled(e) {
        try {
          if (this.isDestroyed)
            return void console.warn("[PayNext SDK] setPaymentsEnabled called on destroyed instance");
          if (!this.cdnInstance)
            return void console.warn("[PayNext SDK] setPaymentsEnabled called before mount");
          "function" == typeof this.cdnInstance.setPaymentsEnabled && this.cdnInstance.setPaymentsEnabled(e);
        } catch (t) {
          let e = t instanceof Error ? t : Error(String(t));
          this.handleError(e, "setPaymentsEnabled");
        }
      }
      async unmount() {
        try {
          if (this.isDestroyed) return void console.warn("[PayNext SDK] Instance already destroyed");
          if (!this.cdnInstance) return void console.warn("[PayNext SDK] No instance to unmount");
          try {
            "function" == typeof this.cdnInstance.unmount && (await this.cdnInstance.unmount());
          } catch (t) {
            let e = t instanceof Error ? t : Error(String(t));
            this.handleError(e, "unmount");
          }
          ((this.cdnInstance = null), (this.initPromise = null));
        } catch (t) {
          let e = t instanceof Error ? t : Error(String(t));
          this.handleError(e, "unmount");
        }
      }
      static async preload(e) {
        try {
          await p(e);
        } catch (e) {
          throw (console.error("[PayNext SDK] Preload failed:", e), e);
        }
      }
    }
    _.preload;
    var m =
      (((t = m || {}).PAYPAL = "PAYPAL"),
      (t.APPLE_PAY = "APPLEPAY"),
      (t.GOOGLE_PAY = "GPAY"),
      (t.CARD = "CARD"),
      (t.VENMO = "VENMO"),
      (t.CASHAPP = "CASHAPP"),
      (t.AMAZONPAY = "AMAZONPAY"),
      (t.PIX_AUTOMATICO = "PIX_AUTOMATICO"),
      (t.UPI = "UPI"),
      (t.BLIK = "BLIK"),
      t);
    e.s(["PayNextCheckout", 0, _, "PaymentMethod", 0, m]);
  },
  812384,
  408110,
  (e) => {
    "use strict";
    var t = e.i(954616),
      n = e.i(86596);
    e.i(682770);
    var a = e.i(934952),
      r = e.i(117595),
      i = e.i(866897),
      o = e.i(134404),
      s = e.i(157273),
      l = e.i(60423);
    e.i(756503);
    var c = e.i(542516);
    e.i(531122);
    var u = e.i(81844);
    let d = async (e) => {
        let t = await u.httpInstance.post(o.EApiRoutes.CHECKOUT_SESSION, {
            json: ((e) => {
              if (!e.userData || e.userData.quiz_answers_additional?.length) return e;
              let t = l.accessLocalStorage.getItem(s.StorageKeys.MYIQ_NON_IMAGE_ANSWERS);
              if (!t) return e;
              try {
                let n = JSON.parse(t);
                if (Array.isArray(n) && n.length)
                  return { ...e, userData: { ...e.userData, quiz_answers_additional: n } };
              } catch {}
              return e;
            })(
              ((e) => {
                if (!e.userData || e.userData.quiz_answers?.length) return e;
                let t = l.accessLocalStorage.getItem(s.StorageKeys.QUIZ_ANSWERS);
                if (!t) return e;
                try {
                  let n = JSON.parse(t);
                  if (Array.isArray(n) && n.length)
                    return { ...e, userData: { ...e.userData, quiz_answers: n } };
                } catch {}
                return e;
              })(e),
            ),
            throwHttpErrors: !1,
          }),
          n = await t.json();
        return (
          n.success &&
            n.data?.paynextClientSessionId &&
            r.default.set(i.ECookieArg.PAYNEXT_SESSION, n.data?.paynextClientSessionId, {
              secure: "production" === c.envClient.NEXT_PUBLIC_APP_ENV,
              expires: 40 / 24,
              path: "/",
              sameSite: "lax",
            }),
          n
        );
      },
      p = async (e) => {
        let t = await u.httpInstance.post(o.EApiRoutes.CHECKOUT_SESSION, { json: e, throwHttpErrors: !1 });
        return (await t.json()).data ?? null;
      },
      _ = async (e) =>
        (
          await u.httpInstance.post(o.EApiRoutes.CHECKOUT_SESSION_FRAUD_SESSIONS, {
            json: e,
            throwHttpErrors: !1,
          })
        ).json();
    (e.s(
      [
        "createUserSessionFetcher",
        0,
        d,
        "getCheckoutSessionPriceFetcher",
        0,
        p,
        "updateCheckoutSessionFraudSessionsFetcher",
        0,
        _,
      ],
      408110,
    ),
      e.s(
        [
          "useCreateUserSessionMutation",
          0,
          () => {
            let e = (0, n.useUserStore)((e) => e.handleChangeUserStore),
              r = (0, t.useMutation)({
                mutationFn: d,
                onSuccess(t) {
                  t.success
                    ? t.data &&
                      e({
                        user: {
                          paymentInfo: {
                            ...t.data,
                            paynextAmountPayment: t.data.paynextAmountPayment?.toString(),
                          },
                        },
                      })
                    : (0, a.customToast)(t?.error || "", "error");
                },
              });
            return { ...r, trigger: r.mutateAsync };
          },
          "useUpdateCheckoutSessionFraudSessionsMutation",
          0,
          () => {
            let e = (0, t.useMutation)({ mutationFn: _ });
            return { ...e, trigger: e.mutateAsync };
          },
        ],
        812384,
      ));
  },
  842582,
  76399,
  (e) => {
    "use strict";
    var t = e.i(618566),
      n = e.i(271645);
    e.i(879568);
    var a = e.i(480408),
      r = e.i(866897),
      i = e.i(924254),
      o = e.i(5117);
    (e.s(
      [
        "useCollectParams",
        0,
        () => {
          let e,
            s = (0, t.useSearchParams)(),
            [l, c] = (0, n.useState)(null),
            [u, d] = (0, n.useState)(!1),
            p = () => {
              let e = s ? new URLSearchParams(s.toString()) : void 0,
                t = a.attributionUtil.collectAttributionData(e);
              (0, o.getClientAnalyticsConsent)().allowed && a.attributionUtil.saveAttributionData(t);
              let n = a.attributionUtil.readAttributionData() ?? t;
              return (c(n), d(!0), n);
            },
            _ = () => l || a.attributionUtil.readAttributionData();
          return (
            (0, n.useEffect)(() => {
              u || p();
            }, [s, u]),
            {
              attributionData: _(),
              isInitialized: u,
              initializeAttribution: p,
              getAttributionMetadata: () => {
                let e = _();
                return a.attributionUtil.formatForPaymentMetadata(e);
              },
              clearAttribution: () => {
                (i.accessCookie.removeItem(r.ECookieArg.ATTRIBUTION_STORAGE_KEY), c(null));
              },
              hasAttribution: null !== (e = _()) && Object.keys(e).length > 0,
              getAttributionData: _,
            }
          );
        },
      ],
      76399,
    ),
      e.s([], 842582));
  },
  112015,
  557213,
  (e) => {
    "use strict";
    var t,
      n = e.i(194613),
      a = (((t = {}).WEEKLY = "weekly"), (t.MONTHLY = "monthly"), (t.QUARTERLY = "quarterly"), t);
    e.s(["EPlanPickerPlan", () => a], 557213);
    let r = [
        {
          id: a.WEEKLY,
          planId: n.EPaynextPlanIds.PLAN_PICKER_WEEKLY,
          planName: "PLAN_PICKER_WEEKLY",
          labelKey: "plan_picker_weekly_label",
          trialPriceKey: "PLAN_PICKER_WEEKLY_TRIAL",
          renewalPriceKey: "PLAN_PICKER_WEEKLY_RENEWAL",
          perDayDivisor: 7,
          disclaimerKey: "plan_picker_disclaimer_weekly",
        },
        {
          id: a.MONTHLY,
          planId: n.EPaynextPlanIds.PLAN_PICKER_MONTHLY,
          planName: "PLAN_PICKER_MONTHLY",
          labelKey: "plan_picker_monthly_label",
          trialPriceKey: "PLAN_PICKER_MONTHLY_TRIAL",
          renewalPriceKey: "PLAN_PICKER_MONTHLY_RENEWAL",
          perDayDivisor: 28,
          disclaimerKey: "plan_picker_disclaimer_month",
          badgeKey: "plan_picker_monthly_badge",
        },
        {
          id: a.QUARTERLY,
          planId: n.EPaynextPlanIds.PLAN_PICKER_QUARTERLY,
          planName: "PLAN_PICKER_QUARTERLY",
          labelKey: "plan_picker_quarterly_label",
          trialPriceKey: "PLAN_PICKER_QUARTERLY_TRIAL",
          renewalPriceKey: "PLAN_PICKER_QUARTERLY_RENEWAL",
          perDayDivisor: 84,
          disclaimerKey: "plan_picker_disclaimer_quarter",
        },
      ],
      i = a.MONTHLY;
    e.s(["DEFAULT_PLAN_PICKER_PLAN", 0, i, "PLAN_PICKER_CONFIG", 0, r], 112015);
  },
  473189,
  823933,
  (e) => {
    "use strict";
    (e.i(476880), e.i(352883));
    var t = e.i(112015);
    let n = (e) => t.PLAN_PICKER_CONFIG.find((t) => t.id === e);
    (e.s(
      [
        "getPlanPickerConfig",
        0,
        n,
        "getPlanPickerPlanId",
        0,
        (e) => n(e)?.planId ?? "",
        "getPlanPickerPlanName",
        0,
        (e) => n(e)?.planName ?? "",
      ],
      823933,
    ),
      e.s([], 473189));
  },
  476880,
  882345,
  (e) => {
    "use strict";
    e.i(569311);
    var t = e.i(896855);
    let n = () =>
      Object.fromEntries(
        Object.entries({
          utm_campaign: t.mixpanelClient.peopleGetProperty("utm_campaign"),
          utm_campaign_id: t.mixpanelClient.peopleGetProperty("utm_campaign_id"),
          utm_source: t.mixpanelClient.peopleGetProperty("utm_source"),
          utm_medium: t.mixpanelClient.peopleGetProperty("utm_medium"),
          utm_adgroup_id:
            t.mixpanelClient.peopleGetProperty("utm_adgroup_id") ||
            t.mixpanelClient.peopleGetProperty("utm_adset_id"),
          utm_adgroup:
            t.mixpanelClient.peopleGetProperty("utm_adgroup") ||
            t.mixpanelClient.peopleGetProperty("utm_adset"),
          utm_ad_id: t.mixpanelClient.peopleGetProperty("utm_ad_id"),
          utm_term: t.mixpanelClient.peopleGetProperty("utm_term"),
          utm_content: t.mixpanelClient.peopleGetProperty("utm_content"),
          gclid: t.mixpanelClient.peopleGetProperty("gclid"),
          fbclid: t.mixpanelClient.peopleGetProperty("fbclid"),
          kwai_click_id: t.mixpanelClient.peopleGetProperty("kwai_click_id"),
          referral_domain: t.mixpanelClient.peopleGetProperty("referral_domain"),
          utm_ad_name: t.mixpanelClient.peopleGetProperty("utm_ad_name"),
          utm_target_id: t.mixpanelClient.peopleGetProperty("utm_target_id"),
          wbraid: t.mixpanelClient.peopleGetProperty("wbraid"),
          utm_content_id: t.mixpanelClient.peopleGetProperty("utm_content_id"),
        }).filter((e) => {
          let [t, n] = e;
          return null != n;
        }),
      );
    e.s(
      [
        "getMixpanelFallbackMetadata",
        0,
        n,
        "getPaymentAttributionData",
        0,
        (e) => {
          let t = {};
          for (let [e, a] of Object.entries(n())) t[e] = String(a);
          return { ...t, ...(e || {}) };
        },
      ],
      476880,
    );
    var a = e.i(117595);
    (e.i(618566), e.i(271645));
    var r = e.i(866897);
    e.s(
      [
        "getIsBrCampaign",
        0,
        () =>
          "true" === a.default.get(r.ECookieArg.BR_CAMPAIGN) ||
          "1" === new URLSearchParams(window.location.search).get("br"),
      ],
      882345,
    );
  },
  352883,
  (e) => {
    "use strict";
    e.i(879568);
    var t = e.i(480408),
      n = e.i(882345),
      a = e.i(49587),
      r = e.i(891133),
      i = e.i(523173),
      o = e.i(429067),
      s = e.i(279816);
    e.i(756503);
    var l = e.i(542516);
    e.i(470366);
    var c = e.i(504001);
    e.i(569311);
    var u = e.i(896855),
      d = e.i(194613),
      p = e.i(476880);
    let _ = async (e) => {
      let {
          data: _,
          isMarketingSource: m,
          user: y,
          router: E,
          variant: P,
          friendEncodedData: I = "",
          quizAnswers: f = null,
          nonImageQuizAnswers: A = null,
          triggerCreateSession: b,
          triggerCreatePaynextSubscription: C,
          abMyiqPromoPrice: R,
          abMyiqAb100Vs199: T,
          abMyiqRevolutMonzoBlock: h,
          abMyiqBrazilMastercardOnly: g,
          abMyiqProductFeedbackWidget: S,
          abMyiqPrintCertificateUpsell: N,
          handleChangeUserStore: v,
          clearQuizAnswersFromLocalStorage: L,
          handleChangeQuizStore: w,
          ftMyiqReviewPlatformSplit: D,
          checkoutTimerExpired: x,
          results: O,
          depressionResult: k,
          isPlanPickerFunnel: U,
          planPickerPlanId: M,
          planPickerPlanName: K,
          successNoticeMinVisibleMs: B = 0,
        } = e,
        F = Date.now(),
        Y = "promo_price" === R && !!m,
        z = {
          app_version: "v2",
          currency: y?.paymentInfo?.paynextAmountCurrency,
          email: y?.email,
          customer_id: y?.id,
          mixpanel_user_id: y?.id,
          payment_id: _.payment.id,
          payment_card_brand: _?.paymentСardBrand,
          payment_method_type: _?.paymentMethodType,
          user_id: y?.id,
          language: y?.locale,
          country: y?.currency?.countryCode,
          payment_processor: _.paymentProcessor,
          flow_type: "web_onboarding",
          error_code: "",
          funnel: y?.funnel,
          plan_name: U && K ? K : Y ? "SPLIT_TRIAL_PROMO_PRICE" : "SPLIT_TRIAL",
          ...(U && { plan_picker_funnel: !0 }),
          ...((0, a.getIsRedesignFunnel)() && { redesign_funnel: !0 }),
          paymentOrchestrator: "PayNext",
          amount: Number(y?.paymentInfo?.paynextAmountPayment),
          paynextSessionId: y?.paymentInfo?.paynextClientSessionId,
          paynextPaymentMethod: _?.paymentMethodType,
          attributionData: _.attributionData,
          paynextPaymentCardBrand: _?.paymentСardBrand,
          paynextPaymentCurrency: y?.paymentInfo?.paynextAmountCurrency,
          paynextPaymentAmount: Number(y?.paymentInfo?.paynextAmountPayment),
          paynextSubscriptionId: y?.paymentInfo?.subscriptionId,
          displayedCurrency: y?.paymentInfo?.paynextAmountDisplayedCurrency,
          displayedAmount: y?.paymentInfo?.paynextAmountDisplayed,
          supabase_user_id: y?.id || "",
          first_name: y?.paymentInfo?.firstName || "",
          last_name: y?.paymentInfo?.lastName || "",
          hostname: `${l.envClient.NEXT_PUBLIC_BILLING_HOSTNAME}`,
          sub_order_country: y?.currency?.countryCode || "",
          paynextPlanID:
            U && M ? M : Y ? d.EPaynextPlanIds.SPLIT_TRIAL_PROMO_PRICE : d.EPaynextPlanIds.SPLIT_TRIAL,
          billing_weeks: y?.paymentInfo?.billing_weeks,
          billing_price: y?.paymentInfo?.billing_price,
        },
        G = y?.funnel || "myiq",
        H = "depression" === G ? "depression_funnel" : G,
        V = y?.test_result || {},
        q = {
          ...V,
          [H]: {
            ...V[H],
            status: "analyzed",
            result: "depression" === G ? (k ?? V[H]?.result ?? null) : V[H]?.result || null,
            answers: V[H]?.answers || {},
          },
        },
        X = _.payment,
        $ = t.attributionUtil.readAttributionData()?.kwai_click_id,
        j = await C({
          userInfo: {
            ...(!y?.mainFunnel &&
              (() => {
                switch (P) {
                  case "personality":
                    return {
                      personality_quiz: "analyzed",
                      love_quiz: null,
                      funnel: "personality",
                      quiz: null,
                      mainFunnel: "personality",
                    };
                  case "love_language":
                    return {
                      personality_quiz: null,
                      love_quiz: "analyzed",
                      funnel: "love_language",
                      quiz: null,
                      mainFunnel: "love_language",
                    };
                  case "autism":
                    return {
                      personality_quiz: null,
                      love_quiz: null,
                      autism_quiz: "analyzed",
                      funnel: "autism",
                      quiz: null,
                      mainFunnel: "autism",
                    };
                  case "enneagram":
                    return {
                      personality_quiz: null,
                      love_quiz: null,
                      enneagram_quiz: "analyzed",
                      funnel: "enneagram",
                      quiz: null,
                      mainFunnel: "enneagram",
                    };
                  default:
                    return {
                      personality_quiz: null,
                      love_quiz: null,
                      funnel: "myiq",
                      quiz: "analyzed",
                      mainFunnel: "myiq",
                    };
                }
              })()),
            ...y,
            results: O ?? y?.results,
            firstName: _.firstName,
            lastName: _.lastName,
            isMarketingSource: !!m,
            email_validation_status: "skipped",
            ...(f && f.length > 0 ? { quiz_answers: f } : {}),
            ...(A && A.length > 0 ? { quiz_answers_additional: A } : {}),
            paymentInfo: {
              ...y?.paymentInfo,
              id: X.id,
              paynextCustomerId: X.customer.id,
              paymentMethodType: _.paymentMethodType,
              paymentСardBrand: _.paymentСardBrand,
              currencyCode: _.currencyCode,
              paymentProcessor: _.paymentProcessor,
              paymentProcessorId: _.processorMerchantId,
              statementDescriptor: _.statementDescriptor,
              taxAmount: _.taxAmount,
              taxAmountSubtotal: _.taxAmountSubtotal,
            },
          },
          subscription: { id: X?.subscription?.id || "" },
          testResult: q,
          friendEncodedData: I,
          ...(m && R ? { abMyiqPromoPrice: R } : {}),
          ...("v1_trial_1_99" === T ? { abMyiqAb100Vs199: T } : {}),
          ...((0, r.getIsUsA1Campaign)() ? { isUsA1Campaign: !0 } : {}),
          ...((0, n.getIsBrCampaign)() ? { isBrCampaign: !0 } : {}),
          ...(U && M ? { planPickerPlanId: M } : {}),
          checkoutTimerExpired: x,
          metadata: {
            ...z,
            plan_name: x ? "SPLIT_TRIAL_SECOND_EXPIRED" : "SPLIT_TRIAL_SECOND",
            paynextPlanID: x
              ? d.EPaynextPlanIds.SPLIT_TRIAL_SECOND_EXPIRED
              : d.EPaynextPlanIds.SPLIT_TRIAL_SECOND,
            flow_type: "second_payment",
            ...("block" === h || "not_block" === h ? { ab_myiq_revolut_monzo_block: h } : {}),
            ...("v1_mastercard_only" === g || "control" === g ? { ab_myiq_brazil_mastercard_only: g } : {}),
            ...(0, p.getMixpanelFallbackMetadata)(),
            ...($ && { kwai_click_id: $ }),
          },
        });
      (j.success
        ? (0, o.markNativeReturningCustomer)()
        : (0, c.trackClientEvents)({
            user: y,
            event: i.EAnalyticEvents.SUBSCRIPTION_CREATE_ERROR,
            params: { error_message: JSON.stringify(j.error) },
          }),
        (0, c.trackClientEvents)({
          user: y,
          event: i.EAnalyticEvents.SUBSCRIPTION_PURCHASED_SUCCESS,
          params: {
            ...z,
            paynextCustomerId: X.customer.id,
            paynextPaymentID: X.id,
            paynextAmountUsd: X.amount_usd,
            paynextPaymentAmount: X.amount,
            amount: X.amount,
            ab_myiq_promo_price: R,
            isMarketingSource: !!m,
          },
        }),
        (0, c.setPeopleAnalytic)({
          user_token: y?.userToken,
          referral: I,
          payment_method_type: _.paymentMethodType,
          payment_card_brand: _.paymentСardBrand,
          funnel: y?.funnel,
          ab_myiq_product_feedback_widget: S,
          ab_myiq_print_certificate_upsell: N,
          ft_myiq_review_platform_split: D,
        }),
        "production" === l.envClient.NEXT_PUBLIC_APP_ENV && u.mixpanelClient.startSessionRecording(),
        await b(y),
        (0, c.setPeopleAnalytic)({ email_validation_status: "skipped" }),
        v({
          user: {
            email_validation_status: "skipped",
            billingSubscriptionData: void 0,
            isPaynextSubscribed: !0,
            nextBillingDate: void 0,
            paynextSubscription: void 0,
            paymentInfo: {
              ...y?.paymentInfo,
              paynextCustomerId: X.customer.id,
              paymentMethodType: _.paymentMethodType,
              paymentProcessor: _.paymentProcessor,
              paymentProcessorId: _.processorMerchantId,
              statementDescriptor: _.statementDescriptor,
              taxAmount: _.taxAmount,
              taxAmountSubtotal: _.taxAmountSubtotal,
            },
          },
        }));
      let W = B - (Date.now() - F);
      (W > 0 && (await new Promise((e) => setTimeout(e, W))),
        E.replace((0, s.getReportLink)(P)),
        E.refresh(),
        w({ userScore: null, spentTime: 0, sectionsResult: null, percentScoreResult: null }),
        L());
    };
    e.s(["onCheckoutSuccess", 0, _]);
  },
  715413,
  (e) => {
    "use strict";
    var t = e.i(271645);
    e.i(756503);
    var n = e.i(542516);
    let a = [
      "https://js.braintreegateway.com/web/3.133.0/js/client.min.js",
      "https://js.braintreegateway.com/web/3.133.0/js/data-collector.min.js",
    ];
    e.s([
      "useBraintreeDataCollector",
      0,
      () => {
        let [e, r] = (0, t.useState)(null),
          [i, o] = (0, t.useState)(!1),
          [s, l] = (0, t.useState)(null);
        return (
          (0, t.useEffect)(() => {
            if ("u" > typeof document)
              for (let e of a) {
                if (document.querySelector(`script[src="${e}"]`)) continue;
                let t = document.createElement("script");
                ((t.src = e), (t.async = !0), document.head.appendChild(t));
              }
            let e = null,
              t = null,
              i = Date.now(),
              s = () =>
                !!(window.braintree?.client && window.braintree?.dataCollector) &&
                (e && (clearInterval(e), (e = null)),
                t && (clearTimeout(t), (t = null)),
                o(!0),
                l(null),
                window.braintree?.client?.create(
                  { authorization: n.envClient.NEXT_PUBLIC_BRAINTREE_AUTHORIZATION || "" },
                  function (e, t) {
                    if (e) {
                      (r(""), o(!1));
                      return;
                    }
                    window?.braintree?.dataCollector?.create({ client: t }, function (e, t) {
                      (o(!1), e) ? r("") : r(t.deviceData);
                    });
                  },
                ),
                !0);
            if (!s())
              return (
                (e = setInterval(() => {
                  !s() && Date.now() - i >= 1e4 && (e && (clearInterval(e), (e = null)), r(""));
                }, 100)),
                (t = setTimeout(() => {
                  (e && (clearInterval(e), (e = null)), window.braintree || r(""));
                }, 1e4)),
                () => {
                  (e && clearInterval(e), t && clearTimeout(t));
                }
              );
          }, []),
          { deviceData: e, isCollecting: i, error: s }
        );
      },
    ]);
  },
  49587,
  302433,
  (e) => {
    "use strict";
    var t = e.i(117595),
      n = e.i(866897),
      a = e.i(134404);
    let r = [
        a.EClientRoutes.QUIZ,
        a.EClientRoutes.QUIZ_ANALYZING,
        a.EClientRoutes.EMAIL,
        a.EClientRoutes.CHECKOUT,
      ],
      i = (e) => "true" !== e;
    (e.s(
      [
        "REDESIGN_FUNNEL_PROPERTY",
        0,
        "redesign_funnel",
        "isRedesignFunnelPage",
        0,
        (e) => r.includes(e),
        "isRedesignFunnelRequest",
        0,
        i,
      ],
      302433,
    ),
      e.s(["getIsRedesignFunnel", 0, () => i(t.default.get(n.ECookieArg.LEGACY_FUNNEL))], 49587));
  },
  891133,
  (e) => {
    "use strict";
    var t = e.i(117595),
      n = e.i(618566),
      a = e.i(271645),
      r = e.i(866897);
    let i = "us_a1";
    e.s([
      "getIsUsA1Campaign",
      0,
      () =>
        "true" === t.default.get(r.ECookieArg.US_A1_CAMPAIGN) ||
        new URLSearchParams(window.location.search).get("p") === i,
      "useIsUsA1Campaign",
      0,
      () => {
        let e = (0, n.useSearchParams)();
        return (0, a.useMemo)(
          () => "true" === t.default.get(r.ECookieArg.US_A1_CAMPAIGN) || e.get("p") === i,
          [e],
        );
      },
    ]);
  },
  279816,
  (e) => {
    "use strict";
    var t = e.i(134404);
    e.s([
      "getReportLink",
      0,
      (e) => {
        switch (e) {
          case "love_language":
            return t.EClientRoutes.REPORT_LOVE;
          case "personality":
            return t.EClientRoutes.REPORT_PERSONALITY;
          case "careers":
            return t.EClientRoutes.REPORT_CAREERS;
          case "work":
            return t.EClientRoutes.REPORT_WORK;
          case "burnout":
            return t.EClientRoutes.REPORT_BURNOUT;
          case "emotional":
            return t.EClientRoutes.REPORT_EMOTIONAL;
          case "depression":
            return t.EClientRoutes.REPORT_DEPRESSION_FUNNEL;
          case "time_management":
            return t.EClientRoutes.REPORT_TIME_MANAGEMENT;
          case "adhd":
            return t.EClientRoutes.REPORT_ADHD;
          case "attachment":
            return t.EClientRoutes.REPORT_ATTACHMENT;
          case "imposter_syndrome":
            return t.EClientRoutes.REPORT_IMPOSTER_SYNDROME;
          case "procrastination":
            return t.EClientRoutes.REPORT_PROCRASTINATION;
          case "psychological_archetypes":
            return t.EClientRoutes.REPORT_PSYCHOLOGICAL_ARCHETYPES;
          case "anxiety":
            return t.EClientRoutes.REPORT_ANXIETY;
          case "confidence":
            return t.EClientRoutes.REPORT_CONFIDENCE;
          case "strengths":
            return t.EClientRoutes.REPORT_STRENGTHS;
          case "autism":
            return t.EClientRoutes.REPORT_AUTISM;
          case "enneagram":
            return t.EClientRoutes.REPORT_ENNEAGRAM;
          default:
            return t.EClientRoutes.REPORT;
        }
      },
    ]);
  },
  210209,
  (e) => {
    "use strict";
    var t = e.i(360067);
    e.s([
      "getPayerNameFromCheckoutResult",
      0,
      (e) => {
        let t = ((e) => {
          let [t = "", ...n] = e
            .replace(/^[-_\s]+/, "")
            .trim()
            .split(/\s+/);
          return { firstName: t, lastName: n.join(" ") };
        })(e?.customer?.full_name || "");
        if (t.firstName) return t;
        let n = e?.payment_method?.details?.payer_info;
        return { firstName: (n?.first_name || "").trim(), lastName: (n?.last_name || "").trim() };
      },
      "getSuggestedCertificateName",
      0,
      (e) =>
        ((e) => {
          let n,
            a,
            r = (0, t.sanitizeNameInput)(e || "")
              .replace(/[^\p{L}\p{M}\s'-]/gu, "")
              .replace(/\s+/g, " ")
              .replace(/^[-\s]+/, "")
              .slice(0, 35)
              .trim();
          return r.length < 2
            ? ""
            : ((n = r === r.toLocaleUpperCase()),
              (a = r === r.toLocaleLowerCase()),
              n || a
                ? r.toLocaleLowerCase().replace(/(^|[\s'-])(\p{L})/gu, (e, t, n) => t + n.toLocaleUpperCase())
                : r);
        })([e?.firstName, e?.lastName].filter(Boolean).join(" ")),
    ]);
  },
  360067,
  (e) => {
    "use strict";
    let t = { value: /^[\p{L}\p{M}\s'][\p{L}\p{M}\s'-]*$/u, message: "error_name_format" },
      n = (e) => e.replace(/[\u200E\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g, "");
    e.s([
      "NAME_MAX_LENGTH",
      0,
      35,
      "emailPattern",
      0,
      {
        value:
          /^(?=.{1,311}$)([a-zA-Z0-9_](?:[a-zA-Z0-9_.+-]*(?:\.[a-zA-Z0-9_.+-]+)*[a-zA-Z0-9_])?@[a-zA-Z0-9]+(?:[.-][a-zA-Z0-9]+)*\.[a-zA-Z]{2,})$/,
        message: "error_email_format",
      },
      "getRequiredMessage",
      0,
      (e) => e("error_required_field"),
      "maxLengthPattern",
      0,
      (e, t) => ({ value: RegExp(`^.{2,${e}}$`), message: t("error_max_characters", { count: `${e}` }) }),
      "minLength2Pattern",
      0,
      { value: /^.{2,}$/, message: "error_min_2_characters" },
      "namePattern",
      0,
      t,
      "sanitizeNameInput",
      0,
      n,
      "validateName",
      0,
      (e, a) => {
        let r = n(e);
        return r && r.trim().length > 0 && !t.value.test(r)
          ? a("error_name_format")
          : r.length > 35
            ? a("error_max_characters", { count: "35" })
            : null;
      },
    ]);
  },
  218099,
  (e) => {
    "use strict";
    var t = e.i(843476),
      n = e.i(117595),
      a = e.i(618566),
      r = e.i(271645),
      i = e.i(985272),
      o = e.i(812384);
    e.i(842582);
    var s = e.i(76399);
    e.i(473189);
    var l = e.i(476880),
      c = e.i(715413),
      u = e.i(882345),
      d = e.i(49587),
      p = e.i(891133),
      _ = e.i(523173),
      m = e.i(866897),
      y = e.i(622963),
      E = e.i(86596),
      P = e.i(190899),
      I = e.i(210209);
    e.i(756503);
    var f = e.i(542516);
    e.i(470366);
    var A = e.i(504001),
      b = e.i(194613),
      C = e.i(202042);
    e.i(999126);
    var R = e.i(548248);
    let T = "ALREADY_SUBSCRIBED",
      h = new Set([
        "ar",
        "bg",
        "cs",
        "da",
        "de",
        "el",
        "en",
        "es",
        "et",
        "fi",
        "fil",
        "fr",
        "hr",
        "hu",
        "id",
        "is",
        "it",
        "ja",
        "ko",
        "lt",
        "lv",
        "ms",
        "mt",
        "nl",
        "nl-BE",
        "no",
        "pl",
        "pt",
        "ro",
        "ru",
        "sk",
        "sl",
        "sr",
        "sv",
        "th",
        "tr",
        "uk",
        "vi",
        "zh",
      ]);
    e.s(
      [
        "default",
        0,
        (e) => {
          let {
              locale: g,
              user: S,
              handleCheckoutSuccess: N,
              attributionData: v,
              containerId: L = "checkout-container",
              abMyiqPromoPrice: w,
              abMyiqAb100Vs199: D,
              abMyiqRevolutMonzoBlock: x,
              abMyiqBrazilMastercardOnly: O,
              isMarketingSource: k,
              isCheckoutTimerExpired: U = !1,
              reuseSession: M = !1,
              isPlanPickerFunnel: K = !1,
              planName: B,
              paynextPlanId: F,
              paymentsEnabled: Y,
              onPaymentsBlocked: z,
              onProcessingChange: G,
              onPaymentSucceeded: H,
              onAlreadySubscribed: V,
            } = e,
            [, q] = (0, r.useState)(null),
            X = (0, r.useRef)(null),
            $ = (0, r.useRef)(Y);
          $.current = Y;
          let j = (0, y.useModalStore)((e) => e.handleChangeModalStore),
            W = (0, r.useRef)(null),
            Q = (0, r.useRef)(null),
            Z = (0, r.useRef)(new Set()),
            J = (0, r.useRef)(!1),
            { trigger: ee } = (0, o.useCreateUserSessionMutation)(),
            { deviceData: et } = (0, c.useBraintreeDataCollector)(),
            { getAttributionData: en } = (0, s.useCollectParams)(),
            ea = (0, E.useUserStore)((e) => e.handleChangeUserStore),
            [er, ei] = (0, r.useState)(n.default.get(m.ECookieArg.PAYNEXT_SESSION)),
            eo = (0, C.usePathname)(),
            es = (0, a.useSearchParams)(),
            el = async () => {
              S &&
                ee({
                  attributionData: (0, l.getPaymentAttributionData)(en()) || {},
                  abMyiqRevolutMonzoBlock: "block" === x || "not_block" === x ? x : void 0,
                  ...(("v1_mastercard_only" === O || "control" === O) && { abMyiqBrazilMastercardOnly: O }),
                  ...(w && k && { abMyiqPromoPrice: w }),
                  ...("v1_trial_1_99" === D && { abMyiqAb100Vs199: D }),
                  ...((0, p.getIsUsA1Campaign)() && { isUsA1Campaign: !0 }),
                  ...((0, u.getIsBrCampaign)() && { isBrCampaign: !0 }),
                  ...((0, d.getIsRedesignFunnel)() && { redesignFunnel: !0 }),
                  isMarketingSource: !!k,
                  deviceData: "string" == typeof et ? et : JSON.stringify(et) || "",
                  userData: S,
                  planId: b.EPaynextPlanIds.SPLIT_TRIAL_TIMER_EXPIRED,
                  isCheckoutRefresh: !0,
                }).then((e) => {
                  if (e?.code === T) return void V?.();
                  if (e?.data) {
                    let t = e.data;
                    (ea({
                      user: {
                        ...S,
                        paymentInfo: { ...t, paynextAmountPayment: t?.paynextAmountPayment?.toString() },
                      },
                    }),
                      ei(t.paynextClientSessionId));
                  }
                });
            },
            ec = async () => {
              S &&
                ee({
                  attributionData: (0, l.getPaymentAttributionData)(en()) || {},
                  abMyiqRevolutMonzoBlock: "block" === x || "not_block" === x ? x : void 0,
                  ...(("v1_mastercard_only" === O || "control" === O) && { abMyiqBrazilMastercardOnly: O }),
                  ...(w && k && { abMyiqPromoPrice: w }),
                  ...("v1_trial_1_99" === D && { abMyiqAb100Vs199: D }),
                  ...((0, p.getIsUsA1Campaign)() && { isUsA1Campaign: !0 }),
                  ...((0, u.getIsBrCampaign)() && { isBrCampaign: !0 }),
                  ...((0, d.getIsRedesignFunnel)() && { redesignFunnel: !0 }),
                  isMarketingSource: !!k,
                  deviceData: "string" == typeof et ? et : JSON.stringify(et) || "",
                  userData: S,
                  isCheckoutRefresh: !0,
                }).then((e) => {
                  if (e?.code === T) return void V?.();
                  if (e?.data) {
                    let t = e.data;
                    (ea({
                      user: {
                        ...S,
                        paymentInfo: { ...t, paynextAmountPayment: t?.paynextAmountPayment?.toString() },
                      },
                    }),
                      ei(t.paynextClientSessionId));
                  }
                });
            };
          ((0, r.useEffect)(() => {
            if (!M) return;
            let e = S?.paymentInfo?.paynextClientSessionId;
            e && e !== er && ei(e);
          }, [M, S?.paymentInfo?.paynextClientSessionId]),
            (0, r.useEffect)(() => {
              M ||
                (!K &&
                  S?.paymentInfo &&
                  ((S.paymentInfo?.paynextClientSessionExpiryDate &&
                    new Date(S.paymentInfo?.paynextClientSessionExpiryDate) < new Date()) ||
                    !er) &&
                  ec());
            }, [S]),
            (0, r.useEffect)(() => {
              M || (!K && U && !J.current && S && ((J.current = !0), el()));
            }, [U, S]));
          let eu = (e, t) => {
              (0, A.trackClientEvents)({
                event: _.EAnalyticEvents.PURCHASE_ERROR,
                user: S,
                params: { error_code: e || "Error processing payment", ...(t && { detailed_message: t }) },
              });
            },
            ed = async () => {
              let e = {
                app_version: "v2",
                currency: S?.paymentInfo?.paynextAmountCurrency,
                email: S?.email,
                customer_id: S?.id,
                mixpanel_user_id: S?.id,
                user_id: S?.id,
                language: S?.locale,
                country: S?.currency?.countryCode,
                flow_type: "web_onboarding",
                plan_name: K && B ? B : "SPLIT_TRIAL",
                ...(K && { plan_picker_funnel: !0 }),
                paymentOrchestrator: "PayNext",
                paynextSessionId: S?.paymentInfo?.paynextClientSessionId,
                paynextPaymentCurrency: S?.paymentInfo?.paynextAmountCurrency,
                paynextPaymentAmount: Number(S?.paymentInfo?.paynextAmountPayment),
                displayedCurrency: S?.paymentInfo?.paynextAmountDisplayedCurrency,
                displayedAmount: S?.paymentInfo?.paynextAmountDisplayed,
                amount: Number(S?.paymentInfo?.paynextAmountPayment),
                supabase_user_id: S?.id || "",
                first_name: S?.paymentInfo?.firstName || "",
                last_name: S?.paymentInfo?.lastName || "",
                hostname: `${f.envClient.NEXT_PUBLIC_BILLING_HOSTNAME}`,
                sub_order_country: S?.currency?.countryCode || "",
                paynextPlanID: K && F ? F : b.EPaynextPlanIds.SPLIT_TRIAL,
                billing_weeks: S?.paymentInfo?.billing_weeks,
                billing_price: S?.paymentInfo?.billing_price,
                paynextSubscriptionId: S?.paymentInfo?.subscriptionId,
                ...v,
              };
              if (!er) return void eu("PayNext client session not found");
              if (!document.getElementById(L)) return void eu("Checkout container not found");
              let t = new i.PayNextCheckout(),
                n =
                  "v1_mastercard_only" === O
                    ? {
                        [i.PaymentMethod.CARD]: ["mastercard"],
                        [i.PaymentMethod.APPLE_PAY]: ["mastercard"],
                        [i.PaymentMethod.GOOGLE_PAY]: ["mastercard"],
                      }
                    : void 0;
              (await t.mount(L, {
                clientToken: er,
                environment: f.envClient.NEXT_PUBLIC_PAYNEXT_ENV,
                apiVersion: "1.0.0",
                locale: ((e) => {
                  if (h.has(e)) return e;
                  let t = e.split("-")[0].toLowerCase();
                  return h.has(t) ? t : "en";
                })(g),
                variant: "compact",
                ...(n && { acceptedCardNetworks: n }),
                ...("boolean" == typeof Y && { paymentsEnabled: Y }),
                returnUrl: `${f.envClient.NEXT_PUBLIC_APP_URL}${eo}?scroll=checkout`,
                styles: {
                  SubmitButton: {
                    iconSvg:
                      '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" aria-hidden="true" viewBox="0 0 20 20" class="inline h-5 w-5" focusable="false"><path fill-rule="evenodd" d="M10 1a4.5 4.5 0 0 0-4.5 4.5V9H5a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2h-.5V5.5A4.5 4.5 0 0 0 10 1m3 8V5.5a3 3 0 1 0-6 0V9z" clip-rule="evenodd"></path></svg>',
                  },
                },
                onCheckoutLoaded: (e) => {
                  if (((0, R.debugUtil)({ text: "PayNext form loaded", value: e }), e.success)) {
                    (0, A.trackClientEvents)({
                      event: _.EAnalyticEvents.PAYMENT_FORM_VIEWED,
                      user: S,
                      params: { paymentOrchestrator: "PayNext" },
                    });
                    let e = document.getElementById(L);
                    e &&
                      (e.addEventListener("click", (e) => {
                        let t = e.target;
                        if (!t) return;
                        let n = t.closest("button");
                        n &&
                          n instanceof HTMLElement &&
                          W.current !== n &&
                          ((W.current = n),
                          (0, A.trackClientEvents)({
                            event: _.EAnalyticEvents.PAGE_CLICKED,
                            user: S,
                            params: { page_name: "paymentMethodButtonClicked", payment_method: "card" },
                          }));
                      }),
                      "checkout" === es.get("scroll") &&
                        "checkout-container" === L &&
                        setTimeout(() => {
                          let e = document.getElementById("checkout-coupon-disclaimer");
                          if (e) {
                            let t = e.getBoundingClientRect().top + window.scrollY;
                            window.scrollTo({ top: t - 30, behavior: "smooth" });
                          }
                        }, 100));
                  }
                },
                onCheckoutAttempt(t) {
                  (G?.(!0),
                    (0, A.trackClientEvents)({
                      event: _.EAnalyticEvents.PURCHASE_ATTEMPT,
                      user: S,
                      params: {
                        ...e,
                        payment_card_brand: t.cardType?.toUpperCase() || "",
                        payment_method_type: t.paymentMethod,
                      },
                    }));
                },
                onCheckoutBlocked: (e) => {
                  (G?.(!1),
                    (0, A.trackClientEvents)({
                      event: _.EAnalyticEvents.PAGE_CLICKED,
                      user: S,
                      params: { page_name: "paymentBlockedNoConsent", payment_method: e.paymentMethod },
                    }),
                    z?.(e));
                },
                onCheckoutComplete: (t) => {
                  var n;
                  (0, R.debugUtil)({ text: "PayNext Payment completed", value: t });
                  let a = t?.id;
                  if (!a) return;
                  if (Z.current.has(a)) {
                    P.accessSessionStorageUtil.getItem("paymentId") !== a &&
                      j({ modalComponent: "payment-processed-other-tab", isModalVisible: !0 });
                    return;
                  }
                  (Z.current.add(a),
                    P.accessSessionStorageUtil.setItem("paymentId", a),
                    H?.(),
                    Q.current && Q.current.postMessage({ type: "payment-completed", paymentId: a }),
                    (0, A.trackClientEvents)({
                      user: S,
                      event: _.EAnalyticEvents.PURCHASE_SUCCESS,
                      params: {
                        ...e,
                        payment_method_type: t?.payment_method?.type,
                        payment_card_brand: t?.payment_method?.details?.bin_data?.brand?.toUpperCase() || "",
                        payment_id: t?.id,
                        payment_processor: t?.processor?.type || "",
                      },
                    }));
                  let { firstName: r, lastName: i } = (0, I.getPayerNameFromCheckoutResult)(t),
                    o = t?.tax?.amount_tax || 0,
                    s = t?.tax?.amount_subtotal || 0,
                    l = t?.statement_descriptor || "";
                  N({
                    orderId: (n = {
                      payment: t,
                      paymentMethod:
                        t?.payment_method?.details?.bin_data?.brand?.toUpperCase() || t?.payment_method?.type,
                      paymentСardBrand: t?.payment_method?.details?.bin_data?.brand?.toUpperCase() || "",
                      paymentMethodType: t?.payment_method?.type,
                      processorMerchantId: t?.processor?.processor_merchant_id || "",
                      statementDescriptor: l,
                      paymentProcessor: t?.processor?.type || "",
                      currencyCode: t?.currency_code || "USD",
                      first6Digits: t?.payment_method?.details?.last4?.substring(0, 6) || "",
                      firstName: r,
                      lastName: i,
                      taxAmount: o,
                      taxAmountSubtotal: s,
                    }).payment.id,
                    payment: n.payment,
                    paymentMethod: n.paymentMethod,
                    paymentMethodType: n.paymentMethodType || "",
                    paymentСardBrand: n.paymentСardBrand || "",
                    paymentProcessor: n.paymentProcessor,
                    currencyCode: n.currencyCode,
                    first6Digits: n.first6Digits?.toString() || "",
                    processorMerchantId: n.processorMerchantId,
                    statementDescriptor: n.statementDescriptor,
                    firstName: n.firstName,
                    lastName: n.lastName,
                    attributionData: n.attributionData,
                    taxAmount: n.taxAmount,
                    taxAmountSubtotal: n.taxAmountSubtotal,
                  });
                },
                onCheckoutFail: (e) => {
                  (G?.(!1),
                    (0, R.debugUtil)({ text: "PayNext Payment failed", value: e }),
                    eu(e?.status_reason?.message || "Payment failed. Please try again."),
                    (e?.status_reason?.message.toLowerCase().includes("client_session_id") ||
                      e?.status_reason?.message.toLowerCase().includes("client session") ||
                      e?.status_reason?.message.toLowerCase().includes("invalid cl") ||
                      e?.status_reason?.message.toLowerCase().includes("transaction config")) &&
                      ec(),
                    (0, A.trackClientEvents)({
                      event: _.EAnalyticEvents.PURCHASE_ERROR,
                      user: S,
                      params: {
                        amount: Number(S?.paymentInfo?.paynextAmountPayment),
                        currency: S?.paymentInfo?.paynextAmountCurrency,
                        paymentOrchestrator: "PayNext",
                        paynextAdviceCode: e?.status_reason?.advice_code || "",
                        paynextDeclineCode: e?.status_reason?.decline_code || "",
                        paynextSDKError: e?.status === "sdk_failed",
                        paynextDeclineMessage:
                          e?.status !== "sdk_failed" && e?.status_reason?.message
                            ? e.status_reason.message
                            : "SDK Initialisation Failed",
                      },
                    }));
                },
              }),
                (X.current = t),
                "boolean" == typeof $.current && t.setPaymentsEnabled($.current),
                q(t));
            };
          return (
            (0, r.useEffect)(() => {
              Q.current = new BroadcastChannel("payment-processing");
              let e = Q.current;
              return (
                (e.onmessage = (e) => {
                  let { type: t, paymentId: n } = e.data;
                  "payment-completed" === t &&
                    n &&
                    (Z.current.add(n),
                    P.accessSessionStorageUtil.getItem("paymentId") !== n &&
                      j({ modalComponent: "payment-processed-other-tab", isModalVisible: !0 }));
                }),
                () => {
                  e.close();
                }
              );
            }, [j]),
            (0, r.useEffect)(() => {
              if (er) {
                let e = S?.paymentInfo?.paynextClientSessionExpiryDate;
                (e && new Date(e) < new Date()) ||
                  ed().catch((e) => {
                    let t = document.getElementById(L);
                    (t && (t.innerHTML = ""),
                      ed().catch((t) => {
                        eu(
                          "Failed to load payment form. Please refresh the page",
                          t?.message || e?.message || String(t),
                        );
                      }));
                  });
              }
            }, [er]),
            (0, r.useEffect)(() => {
              if ("checkout" === es.get("scroll") && "checkout-container" === L) {
                let e = document.getElementById(L);
                e && e.scrollIntoView({ behavior: "smooth", block: "center" });
              }
            }, [es, L]),
            (0, r.useEffect)(() => {
              "boolean" == typeof Y && X.current?.setPaymentsEnabled(Y);
            }, [Y]),
            (0, t.jsx)("div", {
              id: "checkout-form-section",
              className: "w-full",
              children: (0, t.jsx)("div", {
                style: { display: "grid", gridAutoFlow: "row", zIndex: 0, width: "100%" },
                children: (0, t.jsx)("div", { className: "w-full text-left", id: L, style: { zIndex: 1 } }),
              }),
            })
          );
        },
      ],
      218099,
    );
  },
  149278,
  function (e) {
    e.n(e.i(218099));
  },
  194613,
  (e) => {
    "use strict";
    e.i(756503);
    var t,
      n,
      a = e.i(542516),
      r =
        (((t = {}).SPLIT_TRIAL = "price_28ab40cd-1eb6-44c4-a11d-409cd7a8c59f"),
        (t.SPLIT_TRIAL_SECOND = "price_24a1725c-cbbe-4f34-9eca-876b9e7093da"),
        (t.SPLIT_TRIAL_PAYPAL = "price_31e0469d-6f9a-47be-b92e-c75e8556f8bc"),
        (t.SPLIT_TRIAL_CASHAPP = "price_a48b42ac-8ea2-457f-a781-99a8fede9a5d"),
        (t.SPLIT_TRIAL_PROMO_PRICE = "price_c1a24246-8ef8-4105-a614-c0a4b71178dd"),
        (t.TRIVIA_HEARTS_OTP_5 = "price_4e0bb9fb-d47b-44fc-92a2-f4a57b2920a8"),
        (t.TRIVIA_HEARTS_OTP_20 = "price_07b5b189-4240-4b4d-b635-32c16f31f888"),
        (t.TRIVIA_HEARTS_OTP_50 = "price_e271dce4-d347-411f-970f-a71cb2f78d97"),
        (t.TRIVIA_FIFTY_OTP_5 = "price_11d417ca-2d98-46a2-a591-2ac9e95c5f6b"),
        (t.TRIVIA_FIFTY_OTP_15 = "price_2de429d3-5b21-47c4-ab9b-2788a42b8183"),
        (t.TRIVIA_FIFTY_OTP_40 = "price_bce8ff41-3836-483d-9a21-c75d14d651f7"),
        (t.TRIVIA_EXTRA_TIME_OTP_5 = "price_cc0e09fe-22cd-4ff8-a0a4-005c4bdf8f0c"),
        (t.TRIVIA_EXTRA_TIME_OTP_15 = "price_67f3a405-5cd6-4851-90da-e1e81b36e934"),
        (t.TRIVIA_EXTRA_TIME_OTP_40 = "price_adecce61-6e20-4acd-8404-4bad3572ba29"),
        (t.DOWNGRADED_SUBSCRIPTION = "price_bf2864f3-4835-4ffc-a188-0284b4da920d"),
        (t.DOWNGRADED_SUBSCRIPTION_6_99 = "price_564c5f0f-4a71-4e37-b664-e3d0083251ad"),
        (t.DOWNGRADED_SUBSCRIPTION_9_99 = "price_a5dbadc4-ff56-4bad-bbb6-3b3376e6e6c6"),
        (t.PRINTED_CERTIFICATE_UPSELL = "price_94bdf33b-db92-4aff-bab4-2bb088dbb904"),
        (t.FAST_TRACK_REPORT_UNLOCK = "price_a34a46de-fca6-4175-8b3c-3a358b800070"),
        (t.BUY_TRIVIA_UPSELL_V3 = "price_f11cc629-4cf7-4224-9f5f-5d305fd8d370"),
        (t.BUY_TRIVIA_UPSELL_EXIT = "price_b0b581bd-d991-401b-bb68-38e8b4ffc9ea"),
        (t.SKIP_TRIAL_AB = "price_c466a672-e9a6-4f76-b0c4-389475ec3afd"),
        (t.SKIP_TRIAL_AB_V2 = "price_27971406-8be3-47b1-b8fc-e3bf5bef8de7"),
        (t.RETAKE_IQ_BASE = "price_16bd8029-114a-4032-a5d5-3758e45ff7cb"),
        (t.RETAKE_IQ_ADVANCED = "price_3198f7da-adf6-4720-a6c3-35ada36febf3"),
        (t.SPLIT_TRIAL_TIMER_EXPIRED = "price_b2ed6deb-b7ff-433b-a71c-08da6b9819b1"),
        (t.SPLIT_TRIAL_SECOND_EXPIRED = "price_bc127d58-a19b-4b5b-acae-5e680e598166"),
        (t.PLAN_PICKER_WEEKLY = "price_3877b33a-5505-4aa2-98a5-406002d21e99"),
        (t.PLAN_PICKER_MONTHLY = "price_25eb958a-86b7-4918-9e40-d0c9ae5417b5"),
        (t.PLAN_PICKER_QUARTERLY = "price_74eb2df1-146c-4d6e-b1b8-7b7a68537d36"),
        t),
      i =
        (((n = {}).SPLIT_TRIAL = "price_97cced15-887e-453e-9473-61e4aeab9219"),
        (n.SPLIT_TRIAL_SECOND = "price_becb0124-0330-4b26-8f9a-a14a5c704bd3"),
        (n.SPLIT_TRIAL_PAYPAL = "price_95321730-8959-454b-899c-75be62f284ac"),
        (n.SPLIT_TRIAL_CASHAPP = "price_8fcb11dd-4161-4dc7-bdef-6d567565c1bc"),
        (n.SPLIT_TRIAL_PROMO_PRICE = "price_4cf92053-5660-49a6-a2b8-1a442b46b5c0"),
        (n.TRIVIA_HEARTS_OTP_5 = "price_1a9e2116-fce9-4f06-9a1f-23dc7a8be283"),
        (n.TRIVIA_HEARTS_OTP_20 = "price_70829646-1a27-4044-b8b2-bb4e5a5cd398"),
        (n.TRIVIA_HEARTS_OTP_50 = "price_c684ed53-441e-4af5-8107-3c7ca577f971"),
        (n.TRIVIA_FIFTY_OTP_5 = "price_1928343b-22e6-4c58-a9e6-3922c278650c"),
        (n.TRIVIA_FIFTY_OTP_15 = "price_b277eb6a-c329-437f-85bb-3b370e0d84e1"),
        (n.TRIVIA_FIFTY_OTP_40 = "price_2d40f14d-9ea9-434a-986b-74f929a25de3"),
        (n.TRIVIA_EXTRA_TIME_OTP_5 = "price_6b06ba8e-9b0c-424a-9d9d-d669b2165786"),
        (n.TRIVIA_EXTRA_TIME_OTP_15 = "price_34771465-2aa9-4747-87d6-b62eb0e841db"),
        (n.TRIVIA_EXTRA_TIME_OTP_40 = "price_426595f3-e83b-4a55-bf2e-7c00389f551a"),
        (n.DOWNGRADED_SUBSCRIPTION = "price_bcddbded-fefc-4673-9179-f9830b8c9352"),
        (n.DOWNGRADED_SUBSCRIPTION_6_99 = "price_ba942205-783f-4936-9b5e-95ae3a172b7b"),
        (n.DOWNGRADED_SUBSCRIPTION_9_99 = "price_bd425670-dd91-45bc-afd9-c80975d3956e"),
        (n.PRINTED_CERTIFICATE_UPSELL = "price_02fa8dc7-1606-4bb8-8260-8491d31b0ee1"),
        (n.FAST_TRACK_REPORT_UNLOCK = "price_2218ce0c-1547-4235-a80f-1e59e298e5e6"),
        (n.BUY_TRIVIA_UPSELL_V3 = "price_a72859eb-603a-4c04-8a7b-86815cbba4eb"),
        (n.BUY_TRIVIA_UPSELL_EXIT = "price_498359c1-d083-41ee-a3ee-3ec769e913db"),
        (n.SKIP_TRIAL_AB = "price_2f9f67da-6c99-41b4-ac03-e4180a9cd0df"),
        (n.SKIP_TRIAL_AB_V2 = "price_4f7cc975-6e4e-4683-b4e7-fd320bf01b63"),
        (n.RETAKE_IQ_BASE = "price_7b75f6d6-5884-4690-a6e7-d59c9ad93e91"),
        (n.RETAKE_IQ_ADVANCED = "price_36b27094-d8bd-4297-9bd9-4b21caed26eb"),
        (n.SPLIT_TRIAL_TIMER_EXPIRED = "price_ec5a9c51-933a-45d3-ac6f-b64405797f03"),
        (n.SPLIT_TRIAL_SECOND_EXPIRED = "price_874b2f4c-33c6-4d2f-8eef-c5a20e265c3b"),
        (n.PLAN_PICKER_WEEKLY = "price_bcce7c71-aec4-4af8-8dea-6a14956a2b2e"),
        (n.PLAN_PICKER_MONTHLY = "price_dcae0301-9a8d-4986-95a0-90983f7809d9"),
        (n.PLAN_PICKER_QUARTERLY = "price_2425461b-cb08-44f2-86cd-f6fe17ccf2a5"),
        n);
    let o = "production" === a.envClient.NEXT_PUBLIC_PAYNEXT_ENV ? r : i;
    e.s(["EPaynextPlanIds", 0, o]);
  },
]);
