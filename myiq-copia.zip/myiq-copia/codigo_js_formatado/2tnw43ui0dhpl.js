(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  648430,
  (e) => {
    "use strict";
    let t = ["628", "1124", "599", "583", "7024"];
    e.s([
      "NUMBER_RECALL_583_BASE_ID",
      0,
      201,
      "NUMBER_RECALL_583_NUMBER",
      0,
      "583",
      "getNumberRecall583Question",
      0,
      (e) => ({
        title: e("ab_myiq_quiz_number_recall_question_title"),
        answers: t,
        id: 201,
        baseId: 201,
        isDefaultColor: !0,
        correctAnswer: "583",
      }),
    ]);
  },
  371301,
  454247,
  71926,
  701116,
  239104,
  859787,
  247675,
  780193,
  821762,
  269705,
  510851,
  680363,
  469661,
  686799,
  542991,
  698012,
  110594,
  376031,
  856095,
  (e) => {
    "use strict";
    let t = {
        baseId: 560,
        columns: 3,
        shapes: ["circle", "circle", "circle", "circle", "circle", "square", "circle", "circle", "circle"],
        correctIndex: 5,
      },
      r = {
        baseId: 561,
        columns: 4,
        shapes: [
          "circle",
          "circle",
          "circle",
          "circle",
          "circle",
          "circle",
          "circle",
          "circle",
          "circle",
          "square",
          "circle",
          "circle",
          "circle",
          "circle",
          "circle",
          "circle",
        ],
        correctIndex: 9,
      },
      s = "correct",
      i = (e) => {
        let { t, definition: r } = e,
          { baseId: i, columns: a, shapes: n, correctIndex: l } = r;
        return {
          title: t("ab_myiq_quiz_odd_one_out_title"),
          id: i,
          baseId: i,
          answers: [s],
          correctAnswer: s,
          oddOneOutShapes: n,
          oddOneOutColumns: a,
          oddOneOutCorrectIndex: l,
        };
      };
    e.s(
      [
        "getOddOneOutQuestions",
        0,
        (e) => ({ easy: i({ t: e, definition: t }), hard: i({ t: e, definition: r }) }),
      ],
      371301,
    );
    (e.s(
      [
        "getVerbalAnalogiesQuestions",
        0,
        (e) => ({
          hotCold: {
            title: e("ab_myiq_quiz_verbal_analogies_hot_cold_title"),
            answers: [
              e("ab_myiq_quiz_verbal_analogies_hot_cold_answer_1"),
              e("ab_myiq_quiz_verbal_analogies_hot_cold_answer_2"),
              e("ab_myiq_quiz_verbal_analogies_hot_cold_answer_3"),
              e("ab_myiq_quiz_verbal_analogies_hot_cold_answer_4"),
              e("ab_myiq_quiz_verbal_analogies_hot_cold_answer_5"),
            ],
            correctAnswer: e("ab_myiq_quiz_verbal_analogies_hot_cold_answer_2"),
            id: 600,
            baseId: 600,
            isDefaultColor: !0,
            answersNormalCase: !0,
          },
          penBrush: {
            title: e("ab_myiq_quiz_verbal_analogies_pen_brush_title"),
            answers: [
              e("ab_myiq_quiz_verbal_analogies_pen_brush_answer_1"),
              e("ab_myiq_quiz_verbal_analogies_pen_brush_answer_2"),
              e("ab_myiq_quiz_verbal_analogies_pen_brush_answer_3"),
              e("ab_myiq_quiz_verbal_analogies_pen_brush_answer_4"),
              e("ab_myiq_quiz_verbal_analogies_pen_brush_answer_5"),
            ],
            correctAnswer: e("ab_myiq_quiz_verbal_analogies_pen_brush_answer_3"),
            id: 601,
            baseId: 601,
            isDefaultColor: !0,
            answersNormalCase: !0,
          },
        }),
      ],
      454247,
    ),
      e.i(381069));
    var a = e.i(696207);
    (e.s(
      [
        "applyAlgebraShapesV2Questions",
        0,
        (e) => {
          let { questions: t, variant: r } = e,
            s = ((e, t) => {
              let r = { ...a.SHAPE_ALGEBRA_PUZZLES.two_circles, excludeFromScoring: !0 },
                s = { ...a.SHAPE_ALGEBRA_PUZZLES.three_squares, excludeFromScoring: !0 },
                i = { ...a.SHAPE_ALGEBRA_PUZZLES.triangle_circle, excludeFromScoring: !0 };
              switch (t) {
                case "v1_block2_after_q3":
                  return [...e.slice(0, 3), r, i, ...e.slice(3)];
                case "v2_block3_after_q3":
                  return [...e.slice(0, 3), r, s, i, ...e.slice(3)];
                case "v3_block2_after_q6":
                  return [...e.slice(0, 6), r, i, ...e.slice(6)];
                case "v4_block3_after_q6":
                  return [...e.slice(0, 6), r, s, i, ...e.slice(6)];
                default:
                  return null;
              }
            })(t, r);
          return s ? s.map((e, t) => ({ ...e, id: t + 1 })) : null;
        },
      ],
      71926,
    ),
      e.s(
        [
          "applyClassicIllusionQuestions",
          0,
          (e) => {
            let {
                nonImageStart: t,
                mainQuestions: r,
                finalQuestions: s,
                classicIllusionQuestions: i,
                variant: a,
              } = e,
              n = ((e, t, r) => {
                let { mullerLyer: s, jastrow: i, kanizsa: a } = t;
                switch (r) {
                  case "v1_pair_add_q2_q3":
                    return [...e.slice(0, 1), s, i, ...e.slice(1)];
                  case "v2_pair_add_q1_q2":
                    return [s, i, ...e];
                  case "v3_triple_add_q2_q4":
                    return [...e.slice(0, 1), s, i, a, ...e.slice(1)];
                  case "v4_single_add_q2":
                    return [...e.slice(0, 1), s, ...e.slice(1)];
                  default:
                    return null;
                }
              })(t, i, a);
            return n ? [...n, ...r, ...s].map((e, t) => ({ ...e, id: t + 1 })) : null;
          },
        ],
        701116,
      ),
      e.s(
        [
          "applyCountGridQuestions",
          0,
          (e) => {
            let {
                nonImageStart: t,
                mainQuestions: r,
                finalQuestions: s,
                countGridQuestions: i,
                variant: a,
              } = e,
              n = ((e, t, r) => {
                let { easy: s, hard: i } = t;
                switch (r) {
                  case "v1_block2_after_q3":
                    return [...e.slice(0, 3), s, i, ...e.slice(3)];
                  case "v2_replace_q4_likert_block":
                    return [...e.slice(0, 3), s, i, ...e.slice(4)];
                  case "v3_block2_after_q6":
                    return [...e.slice(0, 6), s, i, ...e.slice(6)];
                  case "v4_replace_q5_q6":
                    return [...e.slice(0, 4), s, i, ...e.slice(6)];
                  default:
                    return null;
                }
              })(t, i, a);
            return n ? [...n, ...r, ...s].map((e, t) => ({ ...e, id: t + 1 })) : null;
          },
        ],
        239104,
      ),
      e.s(
        [
          "applyFlagTriviaQuestions",
          0,
          (e) => {
            let { nonImageStart: t, mainQuestions: r, finalQuestions: s, flagQuestions: i, variant: a } = e,
              n = ((e, t, r) => {
                let { japan: s, germany: i, italy: a } = t;
                switch (r) {
                  case "v1_block2_after_q3":
                    return [...e.slice(0, 3), s, i, ...e.slice(3)];
                  case "v2_block3_after_q3":
                    return [...e.slice(0, 3), s, i, a, ...e.slice(3)];
                  case "v3_block2_after_q6":
                    return [...e.slice(0, 6), s, i, ...e.slice(6)];
                  case "v4_spread_q4_q7":
                    return [...e.slice(0, 3), s, ...e.slice(3, 5), i, ...e.slice(5)];
                  default:
                    return null;
                }
              })(t, i, a);
            return n ? [...n, ...r, ...s].map((e, t) => ({ ...e, id: t + 1 })) : null;
          },
        ],
        859787,
      ),
      e.s(
        [
          "applyMathsTriviaQuestions",
          0,
          (e) => {
            let {
                nonImageStart: t,
                mainQuestions: r,
                finalQuestions: s,
                mathsTriviaQuestions: i,
                variant: a,
              } = e,
              n = ((e, t, r) => {
                let { tenHours: s, twoAndHalfHours: i } = t;
                switch (r) {
                  case "v1_pair_add_q1_q2":
                    return [s, i, ...e];
                  case "v2_pair_add_q4_q5":
                    return [...e.slice(0, 3), s, i, ...e.slice(3)];
                  case "v3_pair_replace_likert_q4":
                    return [...e.slice(0, 3), s, i, ...e.slice(4)];
                  case "v4_single_replace_likert_q4":
                    return [...e.slice(0, 3), i, ...e.slice(4)];
                  default:
                    return null;
                }
              })(t, i, a);
            return n ? [...n, ...r, ...s].map((e, t) => ({ ...e, id: t + 1 })) : null;
          },
        ],
        247675,
      ),
      e.s(
        [
          "applyMirrorWordsQuestions",
          0,
          (e) => {
            let {
                nonImageStart: t,
                mainQuestions: r,
                finalQuestions: s,
                mirrorWordQuestions: i,
                variant: a,
              } = e,
              n = ((e, t, r) => {
                let { brain: s, logic: i } = t;
                switch (r) {
                  case "v1_block2_after_q3":
                    return [...e.slice(0, 3), s, i, ...e.slice(3)];
                  case "v2_replace_q4_likert_block":
                    return [...e.slice(0, 3), s, i, ...e.slice(4)];
                  case "v3_block2_after_q6":
                    return [...e.slice(0, 6), s, i, ...e.slice(6)];
                  case "v4_replace_q5_q6":
                    return [...e.slice(0, 4), s, i, ...e.slice(6)];
                  default:
                    return null;
                }
              })(t, i, a);
            return n ? [...n, ...r, ...s].map((e, t) => ({ ...e, id: t + 1 })) : null;
          },
        ],
        780193,
      ));
    var n = e.i(648430);
    let l = {
      v1_recall_q25: 20,
      v2_recall_q28: 23,
      v3_recall_q32_4726_relocated: 27,
      v4_recall_q36_4726_relocated: 31,
    };
    (e.s(
      [
        "applyNumberRecallQuestions",
        0,
        (e) => {
          let {
              nonImageStart: t,
              mainQuestions: r,
              finalQuestions: s,
              numberRecallQuestion: i,
              variant: a,
            } = e,
            n = a && l[a];
          if (!n) return null;
          let o = r.findIndex((e) => e.baseId === n);
          return -1 === o
            ? null
            : [...t, ...r.slice(0, o), i, ...r.slice(o), ...s].map((e, t) => ({ ...e, id: t + 1 }));
        },
        "getNumberRecallTriggerQuestionId",
        0,
        (e) => {
          let { questions: t, defaultAnchorBaseId: r, variant: s } = e,
            i = "v1_recall_q25" === s ? r : n.NUMBER_RECALL_583_BASE_ID;
          return t.find((e) => e.baseId === i)?.id;
        },
      ],
      821762,
    ),
      e.s(
        [
          "applyOddOneOutQuestions",
          0,
          (e) => {
            let {
                nonImageStart: t,
                mainQuestions: r,
                finalQuestions: s,
                oddOneOutQuestions: i,
                variant: a,
              } = e,
              n = ((e, t, r) => {
                let { easy: s, hard: i } = t;
                switch (r) {
                  case "v1_block2_after_q3":
                    return [...e.slice(0, 3), s, i, ...e.slice(3)];
                  case "v2_replace_q4_likert_block":
                    return [...e.slice(0, 3), s, i, ...e.slice(4)];
                  case "v3_block2_after_q6":
                    return [...e.slice(0, 6), s, i, ...e.slice(6)];
                  case "v4_replace_q5_q6":
                    return [...e.slice(0, 4), s, i, ...e.slice(6)];
                  default:
                    return null;
                }
              })(t, i, a);
            return n ? [...n, ...r, ...s].map((e, t) => ({ ...e, id: t + 1 })) : null;
          },
        ],
        269705,
      ),
      e.s(
        [
          "applyOpticalIllusionQuestions",
          0,
          (e) => {
            let {
                nonImageStart: t,
                mainQuestions: r,
                finalQuestions: s,
                opticalIllusionQuestions: i,
                variant: a,
              } = e,
              n = ((e, t, r) => {
                let { rings: s, waves: i } = t;
                switch (r) {
                  case "v1_pair_add_q2_q3":
                    return [...e.slice(0, 1), s, i, ...e.slice(1)];
                  case "v2_pair_add_q1_q2":
                    return [s, i, ...e];
                  case "v3_pair_replace_likert_q4":
                    return [...e.slice(0, 3), s, i, ...e.slice(4)];
                  case "v4_pair_replace_likert_q10":
                    return [...e.slice(0, 9), s, i, ...e.slice(10)];
                  default:
                    return null;
                }
              })(t, i, a);
            return n ? [...n, ...r, ...s].map((e, t) => ({ ...e, id: t + 1 })) : null;
          },
        ],
        510851,
      ),
      e.s(
        [
          "applyPerceptionQuestions",
          0,
          (e) => {
            let {
              nonImageStart: t,
              mainQuestions: r,
              finalQuestions: s,
              perceptionQuestions: i,
              variant: a,
            } = e;
            if (!a || "default_quiz_flow" === a) return null;
            let n = t,
              l = [];
            switch (a) {
              case "v3_before_memorization":
                n = [...t.slice(0, 6), ...i, ...t.slice(6)];
                break;
              case "v1_after_memorization":
                n = [...t.slice(0, 9), ...i, ...t.slice(9)];
                break;
              case "v2_after_q10_likert":
                n = [...t, ...i];
                break;
              case "v4_after_image_matrix":
                l = i;
                break;
              default:
                return null;
            }
            return [...n, ...r, ...l, ...s].map((e, t) => ({ ...e, id: t + 1 }));
          },
        ],
        680363,
      ));
    let o = "images",
      c = {
        v1_chat_in_place: [1, 2, 3, 4, 5, 6, 10, 32, 33, 34, 35, 7, 8, 9, o],
        v2_start_intake_ramp: [34, 35, 2, 3, 1, 5, 6, 4, 10, 32, 33, 7, 8, 9, o],
        v3_end_demo_last: [7, 8, 9, o, 2, 3, 1, 5, 6, 4, 10, 32, 33, 34, 35],
        v4_end_reflect_last: [7, 8, 9, o, 1, 2, 3, 5, 6, 34, 35, 4, 10, 32, 33],
      },
      u = (e) => !!(e && "default_quiz_flow" !== e && e in c);
    (e.s(
      [
        "CHAT_LAYOUT_IMAGE_BLOCK",
        0,
        o,
        "CHAT_LAYOUT_MAX_VIEWPORT_WIDTH",
        0,
        768,
        "CHAT_LAYOUT_ORDERS",
        0,
        c,
        "isQuizChatLayoutArm",
        0,
        u,
      ],
      469661,
    ),
      e.s(
        [
          "applyQuizChatLayout",
          0,
          (e) => {
            let { startQuestions: t, imageBlockQuestions: r, finalQuestions: s, variant: i } = e;
            if (!u(i)) return null;
            let a = c[i],
              n = [...t, ...s],
              l = new Map();
            n.forEach((e) => {
              void 0 === e.baseId || l.has(e.baseId) || l.set(e.baseId, e);
            });
            let _ = new Set(),
              d = [],
              p = [];
            if (
              (a.forEach((e) => {
                if (e === o) return void p.push({ type: "images" });
                let t = l.get(e);
                if (!t) return;
                _.add(e);
                let r = p.at(-1);
                r?.type === "text"
                  ? d[r.runIndex].push(t)
                  : (d.push([t]), p.push({ type: "text", runIndex: d.length - 1 }));
              }),
              !d.length)
            )
              return null;
            let m = (e) => void 0 === e.baseId || !_.has(e.baseId);
            return (
              d[0].push(...t.filter(m)),
              d[d.length - 1].push(...s.filter(m)),
              p
                .flatMap((e) =>
                  "images" === e.type
                    ? r
                    : d[e.runIndex].map((e) => ({
                        ...e,
                        isChatQuestion: !(e.memorizationSequence || e.memorizationShapes?.length),
                      })),
                )
                .map((e, t) => ({ ...e, id: t + 1 }))
            );
          },
          "getChatLayoutNumberRecallQuestionId",
          0,
          (e) => {
            let { questions: t, imageBlockQuestions: r, imageBlockIndex: s } = e,
              i = r[s]?.baseId;
            if (void 0 !== i) return t.find((e) => e.baseId === i)?.id;
          },
        ],
        686799,
      ),
      e.s(
        [
          "applyStroopQuestions",
          0,
          (e) => {
            let { nonImageStart: t, mainQuestions: r, finalQuestions: s, stroopQuestions: i, variant: a } = e,
              n = ((e, t, r) => {
                let { blueInRed: s, greenInBlue: i, yellowInGreen: a } = t;
                switch (r) {
                  case "v1_block2_after_q3":
                    return [...e.slice(0, 3), s, i, ...e.slice(3)];
                  case "v2_block3_after_q3":
                    return [...e.slice(0, 3), s, i, a, ...e.slice(3)];
                  case "v3_block2_after_q6":
                    return [...e.slice(0, 6), s, i, ...e.slice(6)];
                  case "v4_replace_q4_likert_block":
                    return [...e.slice(0, 3), s, i, ...e.slice(4)];
                  default:
                    return null;
                }
              })(t, i, a);
            return n ? [...n, ...r, ...s].map((e, t) => ({ ...e, id: t + 1 })) : null;
          },
        ],
        542991,
      ),
      e.s(
        [
          "applyVerbalAnalogiesQuestions",
          0,
          (e) => {
            let {
                nonImageStart: t,
                mainQuestions: r,
                finalQuestions: s,
                verbalAnalogiesQuestions: i,
                variant: a,
              } = e,
              n = ((e, t, r) => {
                let { hotCold: s, penBrush: i } = t;
                switch (r) {
                  case "v1_pair_add_q2_q3":
                    return [...e.slice(0, 1), s, i, ...e.slice(1)];
                  case "v2_pair_add_q1_q2":
                    return [s, i, ...e];
                  case "v3_pair_replace_likert_q4":
                    return [...e.slice(0, 3), s, i, ...e.slice(4)];
                  default:
                    return null;
                }
              })(t, i, a);
            return n ? [...n, ...r, ...s].map((e, t) => ({ ...e, id: t + 1 })) : null;
          },
        ],
        698012,
      ));
    var _ = e.i(841977);
    let d = [
        { primary: "pattern", secondary: "analytical" },
        { primary: "pattern", secondary: "spatial" },
        { primary: "visual", secondary: "pattern" },
        { primary: "analytical", secondary: "visual" },
        { primary: "visual", secondary: "analytical" },
        { primary: "visual", secondary: "pattern" },
        { primary: "abstract", secondary: "pattern" },
        { primary: "pattern", secondary: "visual" },
        { primary: "analytical", secondary: "spatial" },
        { primary: "visual", secondary: "analytical" },
        { primary: "pattern", secondary: "abstract" },
        { primary: "analytical", secondary: "spatial" },
        { primary: "spatial", secondary: "visual" },
        { primary: "spatial", secondary: "visual" },
        { primary: "pattern", secondary: "abstract" },
        { primary: "abstract", secondary: "spatial" },
        { primary: "spatial", secondary: "analytical" },
        { primary: "abstract", secondary: "spatial" },
        { primary: "abstract", secondary: "pattern" },
        { primary: "spatial", secondary: "abstract" },
        { primary: "visual", secondary: "analytical" },
        { primary: "analytical", secondary: "pattern" },
        { primary: "spatial", secondary: "abstract" },
        { primary: "abstract", secondary: "visual" },
        { primary: "analytical", secondary: "abstract" },
      ],
      p = (e) => {
        let t = {};
        return (
          e
            .filter((e) => void 0 !== e.correctAnswer)
            .forEach((e, r) => {
              r < d.length && (t[e.id] = d[r]);
            }),
          t
        );
      },
      m = { analytical: 22, spatial: 21, pattern: 24, abstract: 26, visual: 28 },
      g = {
        analytical: 93 - m.analytical,
        spatial: 93 - m.spatial,
        pattern: 93 - m.pattern,
        abstract: 93 - m.abstract,
        visual: 93 - m.visual,
      };
    var v = e.i(468387);
    e.s(
      [
        "calculateCognitiveSkillScores",
        0,
        (e, t) => {
          let r = t || p(e),
            s = { visual: 0, abstract: 0, pattern: 0, spatial: 0, analytical: 0 },
            i = {
              visual: { primary: 0, secondary: 0 },
              abstract: { primary: 0, secondary: 0 },
              pattern: { primary: 0, secondary: 0 },
              spatial: { primary: 0, secondary: 0 },
              analytical: { primary: 0, secondary: 0 },
            },
            a = {
              visual: { primary: [], secondary: [] },
              abstract: { primary: [], secondary: [] },
              pattern: { primary: [], secondary: [] },
              spatial: { primary: [], secondary: [] },
              analytical: { primary: [], secondary: [] },
            };
          e.forEach((e) => {
            if (!e.correctAnswer || void 0 === e.userAnswer) return;
            let t = r[e.id];
            if (!t) return;
            let n = t.primary,
              l = t.secondary;
            (i[n].primary++,
              i[l].secondary++,
              String(e.userAnswer).trim().toUpperCase() === String(e.correctAnswer).trim().toUpperCase() &&
                ((s[n] += 1), a[n].primary.push(e.id), (s[l] += 0.5), a[l].secondary.push(e.id)));
          });
          let n = {};
          return (
            Object.keys(s).forEach((e) => {
              let t = s[e],
                r = +i[e].primary + 0.5 * i[e].secondary;
              if (0 === r) n[e] = m[e];
              else {
                let s = m[e] + (t / r) * g[e];
                n[e] = Math.ceil(s);
              }
            }),
            n
          );
        },
        "countAnsweredQuestions",
        0,
        (e, t) => {
          let r = t || p(e);
          return e.filter((e) => void 0 !== r[e.id] && void 0 !== e.userAnswer && null !== e.userAnswer)
            .length;
        },
        "countCorrectAnswers",
        0,
        (e, t) => {
          let r = t || p(e);
          return e.filter(
            (e) =>
              void 0 !== r[e.id] &&
              void 0 !== e.userAnswer &&
              null !== e.userAnswer &&
              e.userAnswer === e.correctAnswer,
          ).length;
        },
        "countUserScore",
        0,
        (e, t) => {
          let r = e.slice(0, 12),
            s = e.slice(12),
            i = r.reduce((e, t) => (t.userAnswer === t.correctAnswer ? e + _.EASY_QUESTION_POINTS : e), 0),
            a = s.reduce((e, t) => (t.userAnswer === t.correctAnswer ? e + _.HARD_QUESTION_POINTS : e), 0),
            n = 0;
          return (
            t <= _.FIVE_MINUTES
              ? (n = _.BONUS_POINTS.under_five)
              : t <= _.SEVEN_MINUTES
                ? (n = _.BONUS_POINTS.under_seven)
                : t <= _.TEN_MINUTES && (n = _.BONUS_POINTS.under_ten),
            Math.round(_.MINIMAL_IQ_SCORE + i + a + n)
          );
        },
        "countUserScoreUsUk",
        0,
        (e, t) => {
          let r = e.reduce((e, t) => (t.userAnswer === t.correctAnswer ? e + 1 : e), 0),
            { mean: s, sd: i } = v.US_UK_AGE_GROUP_NORMS[t ?? v.US_UK_DEFAULT_AGE_GROUP];
          return Math.round(
            Math.min(v.US_UK_IQ_BOUNDS.max, Math.max(v.US_UK_IQ_BOUNDS.min, 100 + ((r - s) / i) * 15)),
          );
        },
        "generateSectionScore",
        0,
        (e, t) => Math.floor(Math.random() * (t - e + 1)) + e,
      ],
      110594,
    );
    let h = "after_last_question";
    (e.s(
      [
        "REACTION_TAP_GAME_AFTER_LAST_QUESTION",
        0,
        h,
        "getReactionTapGameAnchor",
        0,
        (e) => {
          let { questions: t, variant: r } = e;
          switch (r) {
            case "v1_tap_1st_question":
              return t.at(0)?.id ?? null;
            case "v2_tap_4th_before_likert":
              return t.find((e) => 4 === e.baseId)?.id ?? t.at(3)?.id ?? null;
            case "v3_tap_before_last_demos":
              return t.at(-2)?.id ?? null;
            case "v4_tap_last_question":
              return h;
            default:
              return null;
          }
        },
      ],
      376031,
    ),
      e.s(
        [
          "getProgressPercentage",
          0,
          (e, t) => Math.min(100, Math.max(0, (e / t) * 100)),
          "getQuizButtonText",
          0,
          (e, t, r) =>
            t && e ? e("btn_see_report") : r ? "Submit my Answers" : e ? e("quiz_get_my_results") : "",
          "scrollToBottom",
          0,
          function () {
            let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 100;
            setTimeout(() => {
              let e = document.querySelector("footer")?.getBoundingClientRect().height ?? 0,
                t = document.body.scrollHeight - window.innerHeight;
              document.scrollingElement?.scrollTo({ top: Math.max(0, t - e), behavior: "smooth" });
            }, e);
          },
          "scrollToTop",
          0,
          function () {
            let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 100;
            setTimeout(() => {
              window.scrollTo({ top: 0, behavior: "smooth" });
            }, e);
          },
        ],
        856095,
      ));
  },
  118360,
  189837,
  301405,
  45180,
  (e) => {
    "use strict";
    var t = e.i(843476);
    e.i(381069);
    var r = e.i(468387),
      s = e.i(707301);
    let i = [
        s.IconMotivationQuizOne.src,
        s.IconMotivationQuizTwo.src,
        s.IconMotivationQuizThree.src,
        s.IconMotivationQuizFour.src,
      ],
      a = {
        AU: {
          11: 89.7,
          10: 73.8,
          9: 56.9,
          8: 41.2,
          7: 28,
          6: 17.3,
          5: 9.8,
          4: 5.2,
          3: 2.1,
          2: 0.7,
          1: 0.1,
          0: 0,
        },
        BE: {
          11: 89.4,
          10: 72.6,
          9: 53,
          8: 36,
          7: 23,
          6: 13.1,
          5: 7.4,
          4: 3.7,
          3: 1.7,
          2: 0.6,
          1: 0.2,
          0: 0,
        },
        CA: {
          11: 89.1,
          10: 72.6,
          9: 54.9,
          8: 39.3,
          7: 26.5,
          6: 16.2,
          5: 9.2,
          4: 4.7,
          3: 2.2,
          2: 0.8,
          1: 0.1,
          0: 0,
        },
        CZ: {
          11: 79.1,
          10: 54.5,
          9: 35.6,
          8: 22.1,
          7: 12.3,
          6: 6.7,
          5: 3.1,
          4: 1.4,
          3: 0.6,
          2: 0.2,
          1: 0,
          0: 0,
        },
        DE: {
          11: 89.2,
          10: 71.2,
          9: 52.8,
          8: 36.7,
          7: 23.9,
          6: 14.3,
          5: 8.1,
          4: 4.5,
          3: 1.9,
          2: 0.7,
          1: 0.1,
          0: 0,
        },
        ES: {
          11: 88.9,
          10: 71.9,
          9: 53.7,
          8: 36.3,
          7: 22.9,
          6: 13.4,
          5: 7.3,
          4: 3.6,
          3: 1.6,
          2: 0.5,
          1: 0.1,
          0: 0,
        },
        FR: {
          11: 89.6,
          10: 72.5,
          9: 53.9,
          8: 36.6,
          7: 23.3,
          6: 13.2,
          5: 7,
          4: 3.4,
          3: 1.3,
          2: 0.4,
          1: 0.1,
          0: 0,
        },
        GB: {
          11: 89.6,
          10: 74,
          9: 56.8,
          8: 40.5,
          7: 27.2,
          6: 16.7,
          5: 9.5,
          4: 4.8,
          3: 2,
          2: 0.6,
          1: 0.1,
          0: 0,
        },
        IL: {
          11: 89.6,
          10: 72.4,
          9: 53.1,
          8: 35.9,
          7: 22.3,
          6: 12.9,
          5: 6.8,
          4: 2.9,
          3: 1.3,
          2: 0.5,
          1: 0,
          0: 0,
        },
        IT: {
          11: 87.5,
          10: 68.6,
          9: 49.7,
          8: 34.1,
          7: 21.5,
          6: 12.7,
          5: 7.1,
          4: 3.6,
          3: 1.7,
          2: 0.6,
          1: 0.1,
          0: 0,
        },
        JP: {
          11: 82.3,
          10: 58.7,
          9: 39.1,
          8: 23.8,
          7: 13.6,
          6: 6.9,
          5: 3.4,
          4: 1.6,
          3: 0.6,
          2: 0.1,
          1: 0,
          0: 0,
        },
        NL: {
          11: 86.3,
          10: 67.2,
          9: 47.9,
          8: 30.5,
          7: 18.5,
          6: 9.8,
          5: 4.6,
          4: 2,
          3: 1,
          2: 0.3,
          1: 0.1,
          0: 0,
        },
        PL: {
          11: 83.5,
          10: 61.9,
          9: 42.4,
          8: 26.4,
          7: 15.3,
          6: 8.1,
          5: 4.4,
          4: 2,
          3: 0.9,
          2: 0.4,
          1: 0.1,
          0: 0,
        },
        SA: {
          11: 91.7,
          10: 76.5,
          9: 60.4,
          8: 44.3,
          7: 30.9,
          6: 20.4,
          5: 12.4,
          4: 6.2,
          3: 3,
          2: 1,
          1: 0.2,
          0: 0,
        },
        US: {
          11: 91.6,
          10: 77.3,
          9: 60.7,
          8: 44.2,
          7: 29.8,
          6: 18.4,
          5: 10.3,
          4: 5.2,
          3: 2.2,
          2: 0.7,
          1: 0.1,
          0: 0,
        },
      };
    (e.s(["COUNTRY_SCORE_TABLE", 0, a, "MOTIVATIONAL_SCREEN_IMAGE_SRCS", 0, i], 189837), e.s([], 301405));
    let n = {
        CA: { top1: 60, top5: 60, top10: 90, top20: 120, top30: 120, top50: 150, top80: 210 },
        CZ: { top1: 60, top5: 60, top10: 90, top20: 120, top30: 120, top50: 150, top80: 210 },
        US: { top1: 60, top5: 60, top10: 90, top20: 90, top30: 120, top50: 150, top80: 210 },
        IL: { top1: 60, top5: 60, top10: 90, top20: 90, top30: 120, top50: 150, top80: 210 },
        AU: { top1: 60, top5: 60, top10: 90, top20: 90, top30: 120, top50: 150, top80: 210 },
        PL: { top1: 60, top5: 60, top10: 90, top20: 90, top30: 120, top50: 150, top80: 180 },
        IT: { top1: 60, top5: 60, top10: 90, top20: 90, top30: 120, top50: 150, top80: 180 },
        ES: { top1: 30, top5: 60, top10: 90, top20: 90, top30: 120, top50: 150, top80: 180 },
        DE: { top1: 30, top5: 60, top10: 90, top20: 90, top30: 120, top50: 120, top80: 180 },
        FR: { top1: 30, top5: 60, top10: 90, top20: 90, top30: 120, top50: 120, top80: 180 },
        SA: { top1: 30, top5: 60, top10: 60, top20: 90, top30: 120, top50: 120, top80: 180 },
        BE: { top1: 30, top5: 60, top10: 60, top20: 90, top30: 120, top50: 120, top80: 180 },
        GB: { top1: 30, top5: 60, top10: 60, top20: 90, top30: 120, top50: 120, top80: 180 },
        NL: { top1: 30, top5: 60, top10: 60, top20: 90, top30: 90, top50: 120, top80: 180 },
        JP: { top1: 30, top5: 60, top10: 60, top20: 90, top30: 90, top50: 120, top80: 180 },
      },
      l = [
        { key: "top1", percentile: 99 },
        { key: "top5", percentile: 95 },
        { key: "top10", percentile: 90 },
        { key: "top20", percentile: 80 },
        { key: "top30", percentile: 70 },
        { key: "top50", percentile: 50 },
        { key: "top80", percentile: 20 },
      ];
    var o = e.i(567697);
    e.i(743893);
    var c = e.i(852016);
    e.i(910661);
    var u = e.i(642871),
      _ = e.i(869404);
    let d = (e, t) => {
      let [s, i, a] = r.MOTIVATION_SCREEN_AB_V6.percentages.map((t) => Math.ceil(e * t)),
        n = [s, t ? e : i, t ? i : a],
        l = e - 4;
      return void 0 !== l ? [...n, l] : n;
    };
    (e.s(
      [
        "getMotivationImage",
        0,
        (e, r, i, a) => {
          let n = a ? a - 4 : void 0;
          return void 0 !== n && e === n
            ? (0, t.jsx)(s.IconMotivationQuizFour, { className: "h-full w-full" })
            : e === r
              ? (0, t.jsx)(s.IconMotivationQuizOne, { className: "h-full w-full" })
              : e === i
                ? (0, t.jsx)(s.IconMotivationQuizTwo, { className: "h-full w-full" })
                : (0, t.jsx)(s.IconMotivationQuizThree, { className: "h-full w-full" });
        },
        "getMotivationQuestionIds",
        0,
        d,
        "getMotivationalScreenDescription",
        0,
        (e, t, r, s, i, a) => {
          let n = i ? i - 4 : void 0;
          if (void 0 !== n && e === n && i) {
            let r = Math.round(((e - 1) / i) * 100),
              s = i - e + 1;
            return t("quiz_page_quiz_get_motivation_description_4", {
              answeredPercent: r.toString(),
              numberOfQuestionsLeft: s.toString(),
            });
          }
          return e === r
            ? t("quiz_page_quiz_get_motivation_description_1")
            : e === s
              ? t(
                  a
                    ? "quiz_page_quiz_bt_motivation_description_4"
                    : "quiz_page_quiz_get_motivation_description_2",
                )
              : t("quiz_page_quiz_get_motivation_description_3");
        },
        "getMotivationalScreenTitle",
        0,
        (e, r, s, i, a, n, l, u) => {
          let _ = l ? l - 4 : void 0;
          if (void 0 !== _ && e === _ && l) {
            let s = l - e + 1;
            return r.rich("quiz_page_quiz_get_motivation_title_4", {
              numberOfQuestionsLeft: s.toString(),
              span: (e) => (0, t.jsx)("span", { className: "font-sans text-blue-600", children: e }),
            });
          }
          return e === i
            ? r.rich("quiz_page_quiz_get_motivation_title_1", {
                percent: s.toString(),
                span: (e) => (0, t.jsx)("span", { className: "font-sans text-blue-600", children: e }),
              })
            : e === a
              ? u
                ? r.rich("quiz_page_quiz_bt_motivation_title_3", {
                    span: (e) => (0, t.jsx)("span", { className: "text-blue-600", children: e }),
                  })
                : r.rich("quiz_page_quiz_get_motivation_title_2", {
                    percent: s.toString(),
                    country: (0, o.getCountryData)("name", n),
                    image: (0, o.getCountryData)("flag", n),
                    img: () =>
                      (0, t.jsx)(c.Flag, {
                        className: "mb-1 inline-block h-5 w-[30px] rounded object-cover",
                        code: n?.currency?.countryCode || "USA",
                        alt: n?.currency?.countryCode || "USA",
                      }),
                    span: (e) => (0, t.jsx)("span", { className: "text-blue-600", children: e }),
                  })
              : r("quiz_page_quiz_get_motivation_title_3");
        },
        "getOrGeneratePercentage",
        0,
        (e, t, r, s) => {
          let i,
            o = u.useQuizStore.getState(),
            c = o.motivationalPercentages;
          if (c && void 0 !== c[e]) return c[e];
          let d = s?.currency?.countryCode || "US";
          if (e === r) {
            var p;
            let e, t;
            ((p = (o.userAnswers || []).filter((e) => e.id < r && e.userAnswer === e.correctAnswer).length),
              (e = Math.max(0, Math.min(11, p))),
              (i =
                (t = (a[d] ?? a.US)[e] ?? a.US[e]) < 20 ? (0, _.getRandomInterval)(20, 30) : Math.ceil(t)));
          } else
            i =
              e === t
                ? ((e, t) => {
                    let r = n[t] ?? n.US,
                      s = l.map((e) => {
                        let { key: t, percentile: s } = e;
                        return { seconds: r[t], percentile: s };
                      }),
                      i = s[0];
                    if (e <= i.seconds) return i.percentile;
                    for (let t = 0; t < s.length - 1; t++) {
                      let r = s[t],
                        i = s[t + 1];
                      if (e <= i.seconds) {
                        let t = i.seconds - r.seconds;
                        if (t <= 0) return i.percentile;
                        let s = (e - r.seconds) / t;
                        return Math.round(r.percentile + s * (i.percentile - r.percentile));
                      }
                    }
                    let a = s[s.length - 1],
                      o = s[s.length - 2],
                      c = a.seconds - o.seconds;
                    if (c <= 0) return Math.max(5, a.percentile);
                    let u = (a.percentile - o.percentile) / c;
                    return Math.max(5, Math.round(a.percentile + u * (e - a.seconds)));
                  })(o.secondsPassed, d)
                : ((e, t) => {
                    let [r, s] = e === t ? [75, 89] : [4, 25],
                      i = (0, _.getRandomInterval)(r, s);
                    return i > 0 ? i : r;
                  })(e, t);
          let m = { ...(c || {}), [e]: i };
          return (o.handleChangeQuizStore({ motivationalPercentages: m }), i);
        },
        "isMotivationScreen",
        0,
        (e, t, r) => d(t, r).includes(e),
      ],
      45180,
    ),
      e.s([], 118360));
  },
  165037,
  50866,
  98636,
  (e) => {
    "use strict";
    (e.s([], 165037), e.s(["useQuizModuleService", () => eu], 98636));
    var t = e.i(618566),
      r = e.i(948148),
      s = e.i(271645),
      i = e.i(984574),
      a = e.i(775367),
      n = e.i(157273),
      l = e.i(406655),
      o = e.i(429067);
    e.i(910661);
    var c = e.i(642871),
      u = e.i(86596),
      _ = e.i(60423),
      d = e.i(190899),
      p = e.i(915113);
    e.i(381069);
    var m = e.i(548554),
      g = e.i(268041),
      v = e.i(468387),
      h = e.i(841977),
      f = e.i(465634),
      y = e.i(82709),
      b = e.i(477545),
      x = e.i(756306),
      w = e.i(678089),
      S = e.i(648430),
      A = e.i(371301),
      Q = e.i(784992),
      I = e.i(781901),
      N = e.i(16211),
      T = e.i(454247),
      E = e.i(134573),
      q = e.i(71926),
      k = e.i(701116),
      C = e.i(239104),
      P = e.i(859787),
      R = e.i(247675),
      O = e.i(780193),
      j = e.i(821762),
      M = e.i(269705),
      z = e.i(510851),
      U = e.i(680363),
      L = e.i(686799),
      B = e.i(542991),
      D = e.i(698012),
      F = e.i(339386),
      G = e.i(110594),
      H = e.i(376031),
      V = e.i(224033),
      K = e.i(856095),
      Z = e.i(735857),
      W = e.i(448006),
      Y = e.i(324523),
      $ = e.i(236801),
      X = e.i(382963),
      J = e.i(538117),
      ee = e.i(523173),
      et = e.i(51742),
      er = e.i(134404),
      es = e.i(622963);
    e.i(756503);
    var ei = e.i(542516);
    e.i(470366);
    var ea = e.i(504001),
      en = e.i(202042),
      el = e.i(469661);
    let eo = () => () => {},
      ec = () => !0;
    e.s([], 50866);
    let eu = (e) => {
      let eu,
        e_,
        ed,
        {
          userProfile: ep,
          isProfile: em,
          experiments: eg = {},
          isBrainTrain: ev,
          useRetakeQuestions: eh,
          isUsUkTraffic: ef,
          isRedesignFunnel: ey,
        } = e,
        {
          abMyiqQuizCompletionCtaRemoval: eb,
          abMyiqQuizChaosBlockQ1122: ex,
          abMyiqQuizTextQsChatLayout: ew,
          abMyiqQuizOpenerSwap: eS,
          abMyiqQuizMidrunSwap: eA,
          abMyiqQuizFewerOptions: eQ,
          abMyiqQuizPerceptionQuestions: eI,
          abMyiqQuizAlgebraShapesV2: eN,
          abMyiqQuizFlagTrivia: eT,
          abMyiqQuizStroopColorBlock: eE,
          abMyiqQuizMirrorWords: eq,
          abMyiqQuizCountGridPlacement: ek,
          abMyiqQuizOddOneOutMicrogame: eC,
          abMyiqQuizNumberRecall: eP,
          abMyiqQuizMathsTrivia: eR,
          abMyiqQuizOpticalIllusionNumbers: eO,
          abMyiqQuizClassicIllusionsV2: ej,
          abMyiqQuizVerbalAnalogies: eM,
          abMyiqQuizReactionTapGame: ez,
          ftMemorizeContinueAnalytics: eU,
          ftMemorizeContinueAnalyticsRedesign: eL,
        } = eg,
        eB = ey ? "with_analytics" === eL : "with_analytics" === eU,
        eD = (0, r.useTranslations)(),
        eF = (0, en.useRouter)(),
        eG = (0, t.useSearchParams)(),
        eH = (0, p.getIsMarketingSource)(),
        { user: eV, handleChangeUserStore: eK } = (0, u.useUserStore)(),
        { getPercentageRank: eZ } = (0, J.useReport)(eV),
        eW = em || eh ? void 0 : eS,
        eY = em || eh ? void 0 : eQ,
        e$ = (0, g.ADDITIONAL_QUESTIONS_NON_IMAGE_START)({
          t: eD,
          abMyiqQuizOpenerSwap: eW,
          abMyiqQuizFewerOptions: eY,
        }),
        eX = (0, v.getDefaultQuizQuestionWithAnswers)({
          additionalQuestionsNonImageStart: e$,
          t: eD,
          abMyiqQuizChaosBlockQ1122: ex,
          abMyiqQuizMidrunSwap: eA,
          abMyiqQuizFewerOptions: eY,
        }),
        eJ = {},
        e0 = e$.length + eX.length,
        e1 = (0, m.ADDITIONAL_QUESTIONS_FINAL)(eD, e0, ev),
        e3 =
          ((eu = (0, s.useRef)(void 0)),
          (e_ = (0, s.useCallback)(
            () => (
              void 0 === eu.current &&
                (eu.current = document.documentElement.clientWidth < el.CHAT_LAYOUT_MAX_VIEWPORT_WIDTH),
              eu.current
            ),
            [],
          )),
          (0, s.useSyncExternalStore)(eo, e_, ec)),
        e2 = em || eh || !e3 ? void 0 : ew,
        e6 = (0, L.applyQuizChatLayout)({
          startQuestions: e$,
          imageBlockQuestions: eX,
          finalQuestions: e1,
          variant: e2,
        }),
        e5 = !e6 && ("v1_chaos_block_disperse" === ex || "v3_disperse_taskline" === ex),
        e4 = em || eh || e6 || e5 ? void 0 : eI,
        e8 = (0, U.applyPerceptionQuestions)({
          nonImageStart: e$,
          mainQuestions: eX,
          finalQuestions: e1,
          perceptionQuestions: (0, I.getPerceptionQuestions)(eD),
          variant: e4,
        }),
        e9 = em || eh || e6 || e5 || e8 ? void 0 : eT,
        e7 = (0, P.applyFlagTriviaQuestions)({
          nonImageStart: e$,
          mainQuestions: eX,
          finalQuestions: e1,
          flagQuestions: (0, b.getFlagTriviaQuestions)(eD),
          variant: e9,
        }),
        te = em || eh || e6 || e5 || e8 || e7 ? void 0 : eE,
        tt = (0, B.applyStroopQuestions)({
          nonImageStart: e$,
          mainQuestions: eX,
          finalQuestions: e1,
          stroopQuestions: (0, N.getStroopQuestions)(eD),
          variant: te,
        }),
        tr = em || eh || e6 || e5 || e8 || e7 || tt ? void 0 : eN,
        ts = [...e$, ...eX, ...e1],
        ti = (0, q.applyAlgebraShapesV2Questions)({ questions: ts, variant: tr }),
        ta = em || eh || e6 || e5 || e8 || e7 || tt ? void 0 : eq,
        tn = (0, O.applyMirrorWordsQuestions)({
          nonImageStart: e$,
          mainQuestions: eX,
          finalQuestions: e1,
          mirrorWordQuestions: (0, w.getMirrorWordQuestions)(eD),
          variant: ta,
        }),
        tl = em || eh || e6 || e5 || e8 || e7 || tt || ti || tn ? void 0 : ek,
        to = (0, C.applyCountGridQuestions)({
          nonImageStart: e$,
          mainQuestions: eX,
          finalQuestions: e1,
          countGridQuestions: (0, y.getCountGridQuestions)(eD),
          variant: tl,
        }),
        tc = em || eh || e6 || e5 || e8 || e7 || tt || ti || tn || to ? void 0 : eC,
        tu = (0, M.applyOddOneOutQuestions)({
          nonImageStart: e$,
          mainQuestions: eX,
          finalQuestions: e1,
          oddOneOutQuestions: (0, A.getOddOneOutQuestions)(eD),
          variant: tc,
        }),
        t_ = em || eh || e6 || e5 || e8 || e7 || tt || ti || tn || to || tu ? void 0 : eP,
        td = (0, j.applyNumberRecallQuestions)({
          nonImageStart: e$,
          mainQuestions: eX,
          finalQuestions: e1,
          numberRecallQuestion: (0, S.getNumberRecall583Question)(eD),
          variant: t_,
        }),
        tp = em || eh || e6 || e5 || e8 || e7 || tt || tn || to || tu || td ? void 0 : eR,
        tm = (0, R.applyMathsTriviaQuestions)({
          nonImageStart: e$,
          mainQuestions: eX,
          finalQuestions: e1,
          mathsTriviaQuestions: (0, x.getMathsTriviaQuestions)(eD),
          variant: tp,
        }),
        tg = em || eh || e6 || e5 || e8 || e7 || tt || ti || tn || to || tu || td || tm ? void 0 : eO,
        tv = (0, z.applyOpticalIllusionQuestions)({
          nonImageStart: e$,
          mainQuestions: eX,
          finalQuestions: e1,
          opticalIllusionQuestions: (0, Q.getOpticalIllusionQuestions)(eD),
          variant: tg,
        }),
        th = em || eh || e6 || e5 || e8 || e7 || tt || ti || tn || to || tu || td || tm || tv ? void 0 : ej,
        tf = (0, k.applyClassicIllusionQuestions)({
          nonImageStart: e$,
          mainQuestions: eX,
          finalQuestions: e1,
          classicIllusionQuestions: (0, f.getClassicIllusionQuestions)(eD),
          variant: th,
        }),
        ty = em || eh || e6 || e5 || e8 || e7 || tt || tn || to || tu || td || tm || tv || tf ? void 0 : eM,
        tb = (0, D.applyVerbalAnalogiesQuestions)({
          nonImageStart: e$,
          mainQuestions: eX,
          finalQuestions: e1,
          verbalAnalogiesQuestions: (0, T.getVerbalAnalogiesQuestions)(eD),
          variant: ty,
        }),
        tx = e6 ?? e8 ?? e7 ?? tt ?? tn ?? to ?? tu ?? td ?? tm ?? tv ?? tf ?? tb ?? ts,
        tw = (0, q.applyAlgebraShapesV2Questions)({ questions: tx, variant: tr }) ?? tx,
        tS = e$.length - 0,
        tA =
          e5 && tS >= 0 && tw.length >= tS + v.CHAOS_BLOCK_Q11_22_SIZE
            ? [
                ...tw.slice(0, tS),
                ...(0, v.disperseChaosBlockWindow)(tw.slice(tS, tS + v.CHAOS_BLOCK_Q11_22_SIZE)),
                ...tw.slice(tS + v.CHAOS_BLOCK_Q11_22_SIZE),
              ].map((e, t) => ({ ...e, id: t + 1 }))
            : tw,
        tQ = eh
          ? (0, E.getABQuizQuestions)()
              .filter((e) => v.US_UK_QUESTION_IDS.includes(e.baseId ?? e.id))
              .map((e, t) => ({ ...e, id: t + 1, baseId: e.baseId ?? e.id }))
          : tA,
        tI = tQ.length - 2,
        tN = (0, H.getReactionTapGameAnchor)({ questions: tQ, variant: em || eh ? void 0 : ez }),
        tT = em || eh || ef ? void 0 : a.NUMBER_RECALL_QUESTION_POSITION,
        tE =
          void 0 === tT
            ? void 0
            : td
              ? (0, j.getNumberRecallTriggerQuestionId)({
                  questions: tQ,
                  defaultAnchorBaseId:
                    eX[a.NUMBER_RECALL_IMAGE_BLOCK_INDEX]?.baseId ?? a.NUMBER_RECALL_QUESTION_POSITION,
                  variant: t_,
                })
              : e6 || e8 || e7 || ti || tn || to || tu || tm || tv || tf || tb
                ? (0, L.getChatLayoutNumberRecallQuestionId)({
                    questions: tQ,
                    imageBlockQuestions: eX,
                    imageBlockIndex: a.NUMBER_RECALL_IMAGE_BLOCK_INDEX,
                  })
                : tT - 0,
        tq = (0, c.useQuizStore)((e) => e.userAnswers),
        tk = (0, c.useQuizStore)((e) => e.additionalAnswers),
        tC = (0, c.useQuizStore)((e) => e.questionTimes),
        tP = (0, c.useQuizStore)((e) => e.currentQuestionId),
        tR = (0, c.useQuizStore)((e) => e.showResultButton),
        tO = (0, c.useQuizStore)((e) => e.isShowMotivation),
        tj = (0, c.useQuizStore)((e) => e.isQuizFinished),
        tM = (0, s.useRef)("true" === d.accessSessionStorageUtil.getItem("quiz-language-change")),
        [tz, tU] = (0, s.useState)(() => (tM.current && tP && !tj ? tP : (tQ?.at(0)?.id ?? 1))),
        tL = tQ.filter((e) => "icons" in e && !e.excludeFromScoring),
        [tB, tD] = (0, s.useState)(() =>
          tM.current && tq && !tj
            ? tL.map((e) => {
                let t = tq.find((t) => t.id === e.id);
                return t ? { ...e, userAnswer: t.userAnswer } : e;
              })
            : tL,
        ),
        [tF, tG] = (0, s.useState)(() => (tM.current && tk && !tj ? tk : {})),
        [tH, tV] = (0, s.useState)(() => !!tM.current && !!tR && !tj && tR),
        [tK, tZ] = (0, s.useState)(() => !eh && !!tM.current && !!tO && !tj && tO),
        [tW, tY] = (0, s.useState)(!1),
        [t$, tX] = (0, s.useState)(!1),
        [tJ, t0] = (0, s.useState)(!1),
        [t1, t3] = (0, s.useState)(!1),
        [t2, t6] = (0, s.useState)(!1),
        [t5, t4] = (0, s.useState)(!1),
        [t8, t9] = (0, s.useState)(!1),
        t7 = (0, s.useRef)(null),
        [re, rt] = (0, s.useState)(!1),
        [rr, rs] = (0, s.useState)(Date.now()),
        [ri, ra] = (0, s.useState)(() => (tM.current && tC && !tj ? tC : {})),
        { trigger: rn } = (0, X.useUpdateUserInDatabaseMutation)(),
        { trigger: rl, isPending: ro } = (0, $.useQuizStarted)(et.EFunnels.MYIQ),
        rc = (0, c.useQuizStore)((e) => e.secondsPassed),
        ru = (0, c.useQuizStore)((e) => e.timerResetKey),
        r_ = (0, c.useQuizStore)((e) => e.handleChangeQuizStore),
        rd = (0, es.useModalStore)((e) => e.handleChangeModalStore),
        rp = (0, s.useRef)(!1),
        rm = (0, Z.createQuizFlowActions)(ev),
        rg = (0, W.createQuizNavigationService)(),
        rv = (0, Y.createQuizStateService)(),
        rh = (e) => rg.isAdditionalQuestion({ questionId: e, allQuestions: tQ }),
        rf = rg.getActiveQuestion({ allQuestions: tQ, currentQuestionId: tz }),
        ry = null !== tN && !t1 && (tN === H.REACTION_TAP_GAME_AFTER_LAST_QUESTION ? t2 : tz === tN && !tH),
        rb = async () => {
          let e = tB.filter((e) => void 0 !== e.userAnswer),
            t = Object.entries((0, G.calculateCognitiveSkillScores)(e)).map((e) => {
              let [t, r] = e;
              return { key: t, result: r };
            }),
            r = eh ? (0, G.countUserScoreUsUk)(tB, t7.current) : (0, G.countUserScore)(tB, rc),
            s = (0, G.countAnsweredQuestions)(tB),
            a = e.filter(
              (e) =>
                String(e.userAnswer).trim().toUpperCase() === String(e.correctAnswer).trim().toUpperCase(),
            ).length,
            n = tB.length ? Math.round((a / tB.length) * 100) : 0,
            l = { ...eJ };
          return (
            r_({
              userScore: r,
              spentTime: rc,
              isQuizFinished: !0,
              sectionsResult: t,
              percentScoreResult: eZ(r),
              accuracyResult: n,
              userAnswers: null,
              additionalAnswers: null,
              questionTimes: null,
              currentQuestionId: null,
              showResultButton: !1,
              isShowMotivation: !1,
            }),
            (0, ea.trackClientEvents)({
              event: ee.EAnalyticEvents.PAGE_CLICKED,
              params: { page_name: "finishQuizButtonClicked", funnel: "myiq" },
              user: eV,
            }),
            em ||
              eK({
                user: {
                  results: { userScore: r, spentTime: rc, sectionsResult: t, answeredQuestionsCount: s },
                  certificate_id_myiq: (0, i.generateCertificateId)(),
                  ...(Object.keys(l).length > 0 && { ab_test_results: l }),
                },
              }),
            { userScore: r, spentTime: rc, sectionResults: t }
          );
        },
        [rx] = (0, s.useState)(o.getIsNativeApp),
        rw = (0, G.countAnsweredQuestions)(tB),
        rS = (0, G.countCorrectAnswers)(tB),
        rA = eG.get("test"),
        rQ = rw <= h.WARNING_THRESHOLD,
        rI = rc < (eh ? h.FOUR_MINUTES : h.MINUTE_SECONDS),
        rN = eh ? h.CORRECT_ANSWER_MIN_COUNT : v.CORRECT_ANSWER_MIN_COUNT_REST,
        rT =
          !rA &&
          !rx &&
          !ey &&
          "production" === ei.envClient.NEXT_PUBLIC_APP_ENV &&
          (rQ || rI || rS < rN) &&
          !em,
        rE = () => {
          let {
            userAnswers: e,
            additionalAnswers: t,
            questionTimes: r,
          } = rv.resetAnswersFromQuestion({
            fromQuestionId: 1,
            toQuestionId: tQ.length,
            currentUserAnswers: tB,
            currentAdditionalAnswers: tF,
            currentQuestionTimes: ri,
          });
          (tD(e),
            tG(t),
            ra(r),
            d.accessSessionStorageUtil.removeItem(n.StorageKeys.EMAIL_SPEED_PERCENTILE),
            r_({ secondsPassed: 0, timerResetKey: ru + 1 }),
            tU(tQ[0].id),
            rs(Date.now()),
            tZ(!1),
            tV(!1),
            rt(!1));
          let s = e.map((e) => ({
            id: e.id,
            baseId: e.baseId,
            correctAnswer: e.correctAnswer,
            userAnswer: e.userAnswer,
          }));
          (r_({
            currentQuestionId: tQ[0].id,
            isShowMotivation: !1,
            showResultButton: !1,
            userAnswers: s,
            additionalAnswers: t,
            questionTimes: r,
          }),
            rd({ modalComponent: null, isModalVisible: !1 }));
        },
        rq = async () => {
          if (!tJ) {
            t0(!0);
            try {
              let { userScore: e, spentTime: t, sectionResults: r } = await rb(),
                s = (0, V.saveQuizAnswersToLocalStorage)({
                  userAnswers: tB,
                  questionTimes: ri,
                  totalSpentTime: em ? void 0 : t,
                  isProfile: em,
                  isABQuiz: eh,
                }),
                a = (0, F.buildNonImageQuizAnswers)({
                  allQuestions: tQ,
                  additionalAnswers: tF,
                  questionTimes: ri,
                });
              if ((em || (0, F.saveNonImageQuizAnswersToLocalStorage)(a), em)) {
                let l = {
                  ...(ep?.test_result || {}),
                  [et.EFunnels.MYIQ]: {
                    status: "analyzed",
                    result: { userScore: e, spentTime: t, sectionsResult: r },
                    ...(s && s.length > 0 ? { answers: s } : {}),
                    ...(a.length > 0 ? { answers_additional: a } : {}),
                    certificate_id: (0, i.generateCertificateId)(),
                  },
                };
                (_.accessLocalStorage.setItem(n.StorageKeys.CHOSEN_TEST, et.EFunnels.MYIQ),
                  await rn({
                    email: ep?.email || "",
                    testResult: l,
                    ...(Object.keys(eJ).length > 0
                      ? { userInfo: { ab_test_results: { ...ep?.ab_test_results, ...eJ } } }
                      : {}),
                  }),
                  setTimeout(() => {
                    eF.replace(er.EClientRoutes.REPORT);
                  }, 50));
                return;
              }
              ((0, K.scrollToTop)(0), tY(!0));
            } catch (e) {
              throw (t0(!1), e);
            }
            t0(!1);
          }
        },
        rk = async () => {
          rT
            ? rd({
                isModalVisible: !0,
                modalComponent: "warning-fewer-questions",
                modalProps: { handleContinueToUnansweredQuestion: rE, user: eV || ep },
              })
            : eh && !t7.current
              ? rt(!0)
              : rq();
        },
        rC = () => {
          eF.replace(er.EClientRoutes.QUIZ_ANALYZING);
        };
      return (
        (0, s.useEffect)(() => {
          tW && eF.prefetch(er.EClientRoutes.QUIZ_ANALYZING, v.QUIZ_ANALYZING_PREFETCH_OPTIONS);
        }, [tW, eF]),
        (0, s.useEffect)(() => {
          (async () => {
            let e = c.useQuizStore.getState(),
              t = tM.current;
            if (
              (t && d.accessSessionStorageUtil.removeItem("quiz-language-change"),
              e.isQuizFinished
                ? (d.accessSessionStorageUtil.removeItem(n.StorageKeys.EMAIL_SPEED_PERCENTILE),
                  (0, c.fullResetQuizStore)())
                : t
                  ? r_({
                      userScore: null,
                      spentTime: 0,
                      isQuizFinished: !1,
                      sectionsResult: null,
                      percentScoreResult: null,
                      isShowTestimonials: !1,
                      showScienceBased: !1,
                      isLoadingPageBeforeQuizTest: !0,
                      motivationalPercentages: null,
                      ...{
                        secondsPassed: e.secondsPassed,
                        timerResetKey: e.timerResetKey,
                        currentQuestionIndex: e.currentQuestionIndex,
                        totalQuestions: e.totalQuestions,
                        userAnswers: e.userAnswers,
                        additionalAnswers: e.additionalAnswers,
                        questionTimes: e.questionTimes,
                        currentQuestionId: e.currentQuestionId,
                        showResultButton: e.showResultButton,
                        isShowMotivation: e.isShowMotivation,
                      },
                    })
                  : r_({
                      userScore: null,
                      spentTime: 0,
                      isQuizFinished: !1,
                      sectionsResult: null,
                      percentScoreResult: null,
                      isShowTestimonials: !1,
                      showScienceBased: !1,
                      isLoadingPageBeforeQuizTest: !0,
                      motivationalPercentages: null,
                      userAnswers: null,
                      additionalAnswers: null,
                      questionTimes: null,
                      currentQuestionId: null,
                      showResultButton: !1,
                      isShowMotivation: !1,
                      secondsPassed: 0,
                      timerResetKey: e.timerResetKey,
                      currentQuestionIndex: 0,
                      totalQuestions: 0,
                    }),
              !rp.current)
            ) {
              let e = eV?.email || ep?.email;
              (em && e && (await rl(e)), (rp.current = !0));
            }
          })();
        }, [em, rl, eV?.email, ep?.email, r_]),
        (0, s.useEffect)(() => {
          if (tM.current) {
            if (tq && tq.length > 0 && !tj) {
              let e = tL.map((e) => {
                let t = tq.find((t) => t.id === e.id);
                return t ? { ...e, userAnswer: t.userAnswer } : e;
              });
              JSON.stringify(tB.map((e) => ({ id: e.id, userAnswer: e.userAnswer }))) !==
                JSON.stringify(e.map((e) => ({ id: e.id, userAnswer: e.userAnswer }))) && tD(e);
            }
            (tk && Object.keys(tk).length > 0 && !tj && tG(tk),
              tP && !tj && tP !== tz && tU(tP),
              tC && Object.keys(tC).length > 0 && !tj && ra(tC),
              void 0 !== tR && tR !== tH && tV(tR),
              eh || void 0 === tO || tO === tK || tZ(tO));
          }
        }, [tq, tk, tP, tC, tR, tO, tj]),
        (0, s.useEffect)(() => {
          tW && !em && r_({ isShowTestimonials: !0 });
        }, [tW, em, r_]),
        {
          currentQuestionId: tz,
          activeQuestion: rf,
          allQuestions: tQ,
          showResultButton: tH,
          isShowMotivation: tK,
          isShowTestimonials: tW,
          showHeroAfterTestimonials: t$,
          handleHeroAfterTestimonialsContinue: () => {
            rC();
          },
          userAnswers: tB,
          isLoading: tJ,
          isMutatingQuizStarted: ro,
          selectedOption:
            ((ed = rh(tz)),
            rg.getCurrentQuestionChoice({
              currentQuestionId: tz,
              isAdditional: ed,
              additionalAnswers: tF,
              userAnswers: tB,
            })),
          userData: eV,
          showAgeQuestion: re,
          handleAgeSelect: (e) => {
            ((t7.current = e), (0, ea.setPeopleAnalytic)({ age: e }));
          },
          showSecondWordIntro: t8,
          handleSecondWordIntroComplete: () => {
            (eB &&
              (0, ea.trackClientEvents)({
                event: ee.EAnalyticEvents.QUIZ_CONTINUE,
                params: { question_number: tz, screen_type: "memorize" },
                user: eV,
              }),
              t9(!1));
          },
          showNumberRecallIntro: t5,
          handleNumberRecallIntroComplete: () => {
            (eB &&
              (0, ea.trackClientEvents)({
                event: ee.EAnalyticEvents.QUIZ_CONTINUE,
                params: { question_number: tz, screen_type: "memorize" },
                user: eV,
              }),
              t4(!1));
          },
          showReactionTapGame: ry,
          handleReactionTapGameComplete: () => {
            (t3(!0), rs(Date.now()), t2 && (t6(!1), tV(!0), r_({ showResultButton: !0 }), rk()));
          },
          handleSelectOption: (e) => {
            let t = tQ.find((e) => e.id === tz);
            eB &&
              (0, ea.trackClientEvents)({
                event: ee.EAnalyticEvents.QUIZ_CONTINUE,
                params: { question_number: tz },
                user: eV,
              });
            let r = rv.calculateTimeSpent({ questionStartTime: rr }),
              s = rv.updateQuestionTime({ questionId: tz, timeSpent: r, currentQuestionTimes: ri });
            ra(s);
            let i = rh(tz),
              { userAnswers: a, additionalAnswers: n } = rv.saveAnswer({
                questionId: tz,
                userChoice: e,
                isAdditional: i,
                currentUserAnswers: tB,
                currentAdditionalAnswers: tF,
              });
            if ((tD(a), tG(n), t && "baseId" in t && 34 === t.baseId)) {
              let r = "answers" in t ? t.answers : [],
                s = r?.indexOf(e),
                i = e;
              (0 === s ? (i = "18-25") : s === (r?.length ?? 0) - 1 && (i = ">61"),
                (0, ea.setPeopleAnalytic)({ age: i }));
              let a = (0, l.getAgeRangeFromAnswer)(r, e);
              a && eK({ user: { ageRange: a } });
            }
            let o = a.map((e) => ({
              id: e.id,
              baseId: e.baseId,
              correctAnswer: e.correctAnswer,
              userAnswer: e.userAnswer,
            }));
            if (
              (r_({
                currentQuestionIndex: tz + 1 || 1,
                totalQuestions: tQ.length,
                userAnswers: o,
                additionalAnswers: n,
                questionTimes: s,
              }),
              eh && tz === tQ.length && !t7.current)
            )
              return void rt(!0);
            let c = !em && !eh && tz === tI;
            (c && t9(!0),
            c || tz !== tE || t4(!0),
            tN !== H.REACTION_TAP_GAME_AFTER_LAST_QUESTION || t1 || tz !== tQ.length)
              ? rm.moveToNextQuestion({
                  currentQuestionId: tz,
                  totalQuestions: tQ.length,
                  onQuestionChange: (e) => {
                    (tU(e), r_({ currentQuestionId: e }));
                  },
                  onMotivationChange: (e) => {
                    let t = !eh && e;
                    (tZ(t), r_({ isShowMotivation: t }));
                  },
                  onResultButtonChange: (e) => {
                    (tV(e), r_({ showResultButton: e }));
                  },
                  onTimeReset: () => rs(Date.now()),
                  abMyiqQuizCompletionCtaRemoval: eb,
                  handleShowResultsClick: rk,
                })
              : t6(!0);
          },
          handleShowResultsClick: rk,
          handleTestimonialsContinue: () => {
            eH ? tX(!0) : rC();
          },
          handlePagination: (e) => {
            (tU(e), rs(Date.now()), r_({ currentQuestionId: e }));
          },
          handleMotivationContinue: () => {
            (tZ(!1), r_({ isShowMotivation: !1 }));
          },
          isProfile: em,
          handleChangeQuizStore: r_,
        }
      );
    };
  },
  735857,
  448006,
  324523,
  (e) => {
    "use strict";
    e.i(118360);
    var t = e.i(45180);
    (e.s(
      [
        "createQuizFlowActions",
        0,
        (e) => ({
          moveToNextQuestion: (r) => {
            let {
              currentQuestionId: s,
              totalQuestions: i,
              onQuestionChange: a,
              onMotivationChange: n,
              onResultButtonChange: l,
              onTimeReset: o,
              abMyiqQuizCompletionCtaRemoval: c,
              handleShowResultsClick: u,
            } = r;
            if (s !== i) {
              let r = s + 1;
              (a(r), o(), n((0, t.isMotivationScreen)(r, i, e)));
            } else if (s === i) {
              if ("removed_cta" === c) return void u();
              l(!0);
            }
          },
          shouldShowResultButton: (e) => {
            let { currentQuestionId: t, totalQuestions: r } = e;
            return t === r;
          },
          shouldShowMotivation: (r) => {
            let { nextQuestionId: s, totalQuestions: i } = r;
            return (0, t.isMotivationScreen)(s, i, e);
          },
          isLastQuestion: (e) => {
            let { currentQuestionId: t, totalQuestions: r } = e;
            return t === r;
          },
        }),
      ],
      735857,
    ),
      e.s(
        [
          "createQuizNavigationService",
          0,
          () => ({
            getActiveQuestion: (e) => {
              let { allQuestions: t, currentQuestionId: r } = e;
              return t.find((e) => e.id === r) || t[0];
            },
            isAdditionalQuestion: (e) => {
              let { questionId: t, allQuestions: r } = e,
                s = r.find((e) => e.id === t);
              return !!s && !("icons" in s);
            },
            getCurrentQuestionChoice: (e) => {
              let { currentQuestionId: t, isAdditional: r, additionalAnswers: s, userAnswers: i } = e;
              return r ? s[t] : i?.find((e) => e.id === t)?.userAnswer;
            },
            canNavigateBack: (e) => {
              let { currentQuestionId: t } = e;
              return t > 1;
            },
            canNavigateForward: (e) => {
              let { currentQuestionId: t, totalQuestions: r } = e;
              return t < r;
            },
          }),
        ],
        448006,
      ),
      e.s(
        [
          "createQuizStateService",
          0,
          () => ({
            saveAnswer: (e) => {
              let {
                questionId: t,
                userChoice: r,
                isAdditional: s,
                currentUserAnswers: i,
                currentAdditionalAnswers: a,
              } = e;
              return s
                ? { userAnswers: i, additionalAnswers: { ...a, [t]: r } }
                : {
                    userAnswers: i.map((e) => (e.id === t ? { ...e, userAnswer: r } : e)),
                    additionalAnswers: a,
                  };
            },
            calculateTimeSpent: (e) => {
              let { questionStartTime: t } = e;
              return Math.floor((Date.now() - t) / 1e3);
            },
            updateQuestionTime: (e) => {
              let { questionId: t, timeSpent: r, currentQuestionTimes: s } = e;
              return { ...s, [t]: r };
            },
            resetAnswersFromQuestion: (e) => {
              let {
                fromQuestionId: t,
                toQuestionId: r,
                currentUserAnswers: s,
                currentAdditionalAnswers: i,
                currentQuestionTimes: a,
              } = e;
              return {
                userAnswers: s.map((e) => (e.id >= t && e.id <= r ? { ...e, userAnswer: void 0 } : e)),
                additionalAnswers: Object.fromEntries(
                  Object.entries(i).filter((e) => {
                    let [r] = e;
                    return Number(r) < t;
                  }),
                ),
                questionTimes: Object.fromEntries(
                  Object.entries(a).filter((e) => {
                    let [r] = e;
                    return Number(r) < t;
                  }),
                ),
              };
            },
          }),
        ],
        324523,
      ));
  },
  538117,
  (e) => {
    "use strict";
    e.s(["useReport", () => I], 538117);
    var t = e.i(843476),
      r = e.i(948148);
    e.i(165037);
    var s = e.i(110594);
    let i = (e) => {
      let s,
        { userPosition: i } = e,
        a = (0, r.useTranslations)(),
        n = [
          {
            value: (s = (0, r.useTranslations)())("report_above_131_key"),
            description: s("report_highly_intelligent"),
            key: 1,
          },
          { value: s("report_116_130_key"), description: s("report_116_130_value"), key: 2 },
          { value: s("report_101_115_key"), description: s("report_101_115_value"), key: 3 },
          { value: s("report_85_100_key"), description: s("report_85_100_value"), key: 4 },
          { value: s("report_75_84_key"), description: s("report_75_84_value"), key: 5 },
          { value: s("report_below_70_key"), description: s("report_below_70_value"), key: 6 },
        ];
      return (0, t.jsxs)("div", {
        className: "mx-auto grid w-full max-w-md gap-4 overflow-x-scroll rounded-3xl bg-blue-50 p-6",
        children: [
          (0, t.jsx)("h6", {
            className: "font-semibold text-report-card",
            children: a("report_test_classification"),
          }),
          (0, t.jsx)("ul", {
            className: "grid",
            children: n?.map((e) =>
              (0, t.jsxs)(
                "li",
                {
                  className: `flex items-center justify-between gap-2 rounded-md p-2 text-xs xs-l:grid-cols-[9rem_1fr] sm:text-base ${i === e.key ? "bg-blue-500" : ""}`,
                  children: [
                    (0, t.jsxs)("span", {
                      className: `${i === e.key ? "text-white" : "text-report-card"} `,
                      children: [e.value, ":"],
                    }),
                    (0, t.jsx)("span", {
                      className: `hyphens-auto text-right font-medium ${i === e.key ? "text-white" : "text-[#151B28]"}`,
                      children: e.description,
                    }),
                  ],
                },
                e.value,
              ),
            ),
          }),
        ],
      });
    };
    var a = e.i(273830),
      n = e.i(595494),
      l = e.i(121712),
      o = e.i(620253),
      c = e.i(75540),
      u = e.i(271645),
      _ = e.i(104688),
      d = e.i(139391),
      p = (0, a.forwardRef)((e, r) => {
        let {
            Component: s,
            slots: i,
            classNames: p,
            label: m,
            showValueLabel: g,
            getProgressBarProps: v,
            getLabelProps: h,
            getSvgProps: f,
            getIndicatorProps: y,
            getTrackProps: b,
          } = (function (e) {
            var t, r, s;
            let i = (0, n.useProviderContext)(),
              [p, m] = (0, a.mapPropsVariants)(e, l.circularProgress.variantKeys),
              {
                ref: g,
                as: v,
                id: h,
                className: f,
                classNames: y,
                label: b,
                valueLabel: x,
                value: w,
                minValue: S = 0,
                maxValue: A = 100,
                strokeWidth: Q,
                showValueLabel: I = !1,
                formatOptions: N = { style: "percent" },
                ...T
              } = p,
              E = (0, o.useDOMRef)(g),
              q = (0, c.clsx)(null == y ? void 0 : y.base, f),
              [, k] = (0, _.useIsMounted)({ rerender: !0, delay: 100 }),
              C = (null == (t = e.isIndeterminate) || t) && void 0 === w,
              P =
                null !=
                  (s = null != (r = e.disableAnimation) ? r : null == i ? void 0 : i.disableAnimation) && s,
              { progressBarProps: R, labelProps: O } = (0, d.useProgressBar)({
                id: h,
                label: b,
                value: w,
                minValue: S,
                maxValue: A,
                valueLabel: x,
                formatOptions: N,
                isIndeterminate: C,
                "aria-labelledby": e["aria-labelledby"],
                "aria-label": e["aria-label"],
              }),
              j = (0, u.useMemo)(
                () => (0, l.circularProgress)({ ...m, disableAnimation: P, isIndeterminate: C }),
                [(0, c.objectToDeps)(m), P, C],
              ),
              M = !!P || k,
              z = Q || ("sm" === e.size ? 2 : 3),
              U = 16 - z,
              L = 2 * U * Math.PI,
              B =
                L -
                (0, u.useMemo)(
                  () => (M ? (C ? 0.25 : w ? (0, c.clampPercentage)((w - S) / (A - S), 1) : 0) : 0),
                  [M, w, S, A, C],
                ) *
                  L,
              D = (0, u.useCallback)(
                function () {
                  let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                  return {
                    ref: E,
                    "data-indeterminate": (0, c.dataAttr)(C),
                    "data-disabled": (0, c.dataAttr)(e.isDisabled),
                    className: j.base({ class: q }),
                    ...(0, c.mergeProps)(R, T, t),
                  };
                },
                [E, j, C, e.isDisabled, q, R, T],
              ),
              F = (0, u.useCallback)(
                function () {
                  let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                  return {
                    className: j.label({ class: null == y ? void 0 : y.label }),
                    ...(0, c.mergeProps)(O, e),
                  };
                },
                [j, y, O],
              ),
              G = (0, u.useCallback)(
                function () {
                  let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                  return {
                    viewBox: "0 0 32 32",
                    fill: "none",
                    strokeWidth: z,
                    className: j.svg({ class: null == y ? void 0 : y.svg }),
                    ...e,
                  };
                },
                [z, j, y],
              ),
              H = (0, u.useCallback)(
                function () {
                  let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                  return {
                    cx: 16,
                    cy: 16,
                    r: U,
                    role: "presentation",
                    strokeDasharray: `${L} ${L}`,
                    strokeDashoffset: B,
                    transform: "rotate(-90 16 16)",
                    strokeLinecap: "round",
                    className: j.indicator({ class: null == y ? void 0 : y.indicator }),
                    ...e,
                  };
                },
                [j, y, B, L, U],
              ),
              V = (0, u.useCallback)(
                function () {
                  let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                  return {
                    cx: 16,
                    cy: 16,
                    r: U,
                    role: "presentation",
                    strokeDasharray: `${L} ${L}`,
                    strokeDashoffset: 0,
                    transform: "rotate(-90 16 16)",
                    strokeLinecap: "round",
                    className: j.track({ class: null == y ? void 0 : y.track }),
                    ...e,
                  };
                },
                [j, y, L, U],
              );
            return {
              Component: v || "div",
              domRef: E,
              slots: j,
              classNames: y,
              label: b,
              showValueLabel: I,
              getProgressBarProps: D,
              getLabelProps: F,
              getSvgProps: G,
              getIndicatorProps: H,
              getTrackProps: V,
            };
          })({ ref: r, ...e }),
          x = v();
        return (0, t.jsxs)(s, {
          ...x,
          children: [
            (0, t.jsxs)("div", {
              className: i.svgWrapper({ class: null == p ? void 0 : p.svgWrapper }),
              children: [
                (0, t.jsxs)("svg", {
                  ...f(),
                  children: [(0, t.jsx)("circle", { ...b() }), (0, t.jsx)("circle", { ...y() })],
                }),
                g &&
                  (0, t.jsx)("span", {
                    className: i.value({ class: null == p ? void 0 : p.value }),
                    children: x["aria-valuetext"],
                  }),
              ],
            }),
            m && (0, t.jsx)("span", { ...h(), children: m }),
          ],
        });
      });
    p.displayName = "HeroUI.CircularProgress";
    var m = e.i(47252);
    let g = (e) => {
      let { score: r, maxValue: s, title: i, description: a, titlePosition: n = "top" } = e;
      return (0, t.jsxs)("div", {
        className: "grid justify-items-center gap-4 p-6",
        children: [
          i &&
            "top" === n &&
            (0, t.jsx)("h5", { className: "text-lg font-bold text-[#0758B4] md:text-2xl", children: i }),
          (0, t.jsx)(p, {
            showValueLabel: !0,
            size: "lg",
            value: r,
            color: "primary",
            strokeWidth: 1.5,
            maxValue: s,
            formatOptions: { minimumFractionDigits: 0 },
            "aria-label": i,
            classNames: { svg: "w-[174px] h-[174px]", value: "text-[68px] font-semibold text-blue-custom" },
          }),
          i &&
            "bottom" === n &&
            (0, t.jsx)("h5", { className: "text-lg font-bold text-[#0758B4] md:text-2xl", children: i }),
          a &&
            ("string" == typeof a
              ? (0, t.jsx)("p", {
                  className: "px-5 text-center",
                  dangerouslySetInnerHTML: { __html: (0, m.sanitizeTranslationHtml)(a) },
                })
              : (0, t.jsx)("p", { className: "px-5 text-center", children: a })),
        ],
      });
    };
    var v = e.i(657688);
    let h = (e) => {
        let { src: r, alt: s, isPdf: i, width: a, height: n } = e;
        return i
          ? (0, t.jsx)("div", {
              className: "m-auto",
              style: { width: a || 200, height: n || 200, position: "relative" },
              children: (0, t.jsx)("img", {
                src: r,
                alt: s,
                style: {
                  width: "100%",
                  height: "100%",
                  objectFit: "contain",
                  background: "#fff",
                  display: "block",
                },
                crossOrigin: "anonymous",
              }),
            })
          : (0, t.jsx)("div", {
              className: "relative h-[200px] w-full self-end md:h-full",
              children: (0, t.jsx)(v.default, {
                src: r,
                className: "object-contain object-bottom",
                alt: s,
                fill: !0,
                sizes: "(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw",
              }),
            });
      },
      f = (e) => {
        let { listItems: r } = e;
        return (0, t.jsx)("ul", {
          className: "grid",
          children: r.map((e) =>
            (0, t.jsx)(
              "li",
              { dangerouslySetInnerHTML: { __html: (0, m.sanitizeTranslationHtml)(e.title) } },
              e.title,
            ),
          ),
        });
      };
    var y = e.i(714060);
    let b = (e) => {
        let { sectionsResult: s, isPdf: i } = e,
          a = (0, r.useTranslations)(),
          { getSectionResult: n } = I();
        return i
          ? (0, t.jsxs)("div", {
              className: "mx-auto w-full max-w-md overflow-visible rounded-3xl bg-blue-50 p-6",
              children: [
                (0, t.jsxs)("div", {
                  className:
                    "mb-4 grid grid-cols-[4fr_3fr_3fr] gap-1 text-base font-semibold text-report-card",
                  children: [
                    (0, t.jsx)("span", { children: a("report_card_cognitive_skill") }),
                    (0, t.jsx)("span", { className: "text-center", children: a("report_card_results") }),
                    (0, t.jsx)("span", { className: "text-right", children: a("report_card_ranking") }),
                  ],
                }),
                (0, t.jsx)("div", {
                  className: "grid gap-4",
                  children: s?.map((e, r) =>
                    (0, t.jsxs)(
                      u.Fragment,
                      {
                        children: [
                          0 !== r && (0, t.jsx)("div", { className: "my-2 h-px bg-[#BBCCDF]" }),
                          (0, t.jsxs)("li", {
                            className:
                              "grid grid-cols-[4fr_1fr_4fr] gap-1 text-xs font-medium text-[#151B28] sm:text-base",
                            children: [
                              (0, t.jsx)("span", {
                                className: "min-w-0 hyphens-auto font-normal text-report-card",
                                children: e?.name,
                              }),
                              (0, t.jsx)("span", {
                                className: "min-w-0 hyphens-auto text-center",
                                children: e?.result,
                              }),
                              (0, t.jsx)("span", {
                                className: "min-w-0 hyphens-auto text-right",
                                children: n(e?.result),
                              }),
                            ],
                          }),
                        ],
                      },
                      e?.key,
                    ),
                  ),
                }),
              ],
            })
          : (0, t.jsxs)("div", {
              className:
                "mx-auto grid w-full max-w-md gap-4 overflow-x-hidden rounded-3xl bg-blue-50 p-6 sm:overflow-x-scroll",
              children: [
                (0, t.jsxs)("div", {
                  className:
                    "grid grid-cols-[4fr_3fr_3fr] gap-1 text-[13px] font-semibold text-report-card sm:text-base",
                  children: [
                    (0, t.jsx)("span", { children: a("report_card_cognitive_skill") }),
                    (0, t.jsx)("span", { className: "text-center", children: a("report_card_results") }),
                    (0, t.jsx)("span", { className: "text-right", children: a("report_card_ranking") }),
                  ],
                }),
                (0, t.jsx)("ul", {
                  className: "grid gap-2 xs-sm:gap-4",
                  children: s?.map((e, r) =>
                    (0, t.jsxs)(
                      u.Fragment,
                      {
                        children: [
                          0 !== r && (0, t.jsx)(y.Divider, { className: "bg-[#BBCCDF]" }),
                          (0, t.jsxs)("li", {
                            className:
                              "grid grid-cols-[4fr_1fr_4fr] gap-1 text-xs font-medium text-[#151B28] sm:text-base",
                            children: [
                              (0, t.jsx)("span", {
                                className: "min-w-0 hyphens-auto font-normal text-report-card",
                                children: e?.name,
                              }),
                              (0, t.jsx)("span", {
                                className: "min-w-0 hyphens-auto text-center",
                                children: e?.result,
                              }),
                              (0, t.jsx)("span", {
                                className: "min-w-0 hyphens-auto text-right",
                                children: n(e?.result),
                              }),
                            ],
                          }),
                        ],
                      },
                      e?.key,
                    ),
                  ),
                }),
              ],
            });
      },
      x = (e) => {
        let { content: r, isBackground: s } = e;
        return (0, t.jsx)("div", {
          className: `grid gap-6 ${s ? "rounded-3xl bg-[#F2F8FF] p-6" : ""}`,
          children: r.map((e) => (0, t.jsx)("p", { children: e }, e)),
        });
      },
      w = (e) => {
        let s,
          { userPosition: i } = e,
          a = (0, r.useTranslations)(),
          { getSectionPosition: n } = I(),
          l = n(i),
          o = [
            { value: (s = (0, r.useTranslations)())("report_highly_intelligent") },
            { value: s("report_116_130_value") },
            { value: s("report_101_115_value") },
            { value: s("report_85_100_value") },
            { value: s("report_75_84_value") },
            { value: s("report_below_70_value") },
          ];
        return (0, t.jsxs)("div", {
          className: "mx-auto grid w-full max-w-md gap-4 overflow-x-scroll rounded-3xl bg-blue-50 p-6",
          children: [
            (0, t.jsx)("h6", {
              className: "font-semibold text-report-card",
              children: a("report_card_user_ranking_table_title"),
            }),
            (0, t.jsx)("ul", {
              className: "grid",
              children: o?.map((e, r) =>
                (0, t.jsxs)(
                  "li",
                  {
                    className: `flex items-center justify-between gap-2 rounded-md p-2 text-xs sm:text-base ${l === r + 1 ? "bg-blue-500" : ""}`,
                    children: [
                      (0, t.jsx)("span", {
                        className: `hyphens-auto font-medium ${l === r + 1 ? "text-white" : ""}`,
                        children: e.value,
                      }),
                      l === r + 1 &&
                        (0, t.jsx)("span", {
                          className: "text-[#9EC4EF]",
                          children: a("report_card_your_ranking"),
                        }),
                    ],
                  },
                  e.value,
                ),
              ),
            }),
            (0, t.jsx)(y.Divider, { className: "bg-[#bbccdf]" }),
            (0, t.jsx)("p", {
              className: "px-3 text-sm text-[#151B28]",
              children: a("report_card_user_ranking_table_info"),
            }),
          ],
        });
      };
    var S = e.i(573348);
    let A = function () {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 90,
          t = (0, r.useTranslations)();
        if (e > 80) return t("report_highly_intelligent");
        if (e > 64 && e <= 80) return t("report_116_130_value");
        if (e > 48 && e <= 64) return t("report_101_115_value");
        if (e > 32 && e <= 48) return t("report_85_100_value");
        if (e > 16 && e <= 32) return t("report_75_84_value");
        else return t("report_below_70_value");
      },
      Q = (e) => {
        let t = (0, r.useTranslations)();
        switch (e) {
          case "visual":
            return t("report_card_visual_perception");
          case "abstract":
            return t("report_card_abstract_reasoning");
          case "pattern":
            return t("report_card_pattern_recognition");
          case "spatial":
            return t("report_card_spatial_orientation");
          case "analytical":
            return t("report_card_analytical_thinking");
          default:
            return "Category";
        }
      },
      I = (e, a) => {
        let n = (0, r.useTranslations)(),
          l = [
            { key: "visual", name: n("report_card_visual_perception") },
            { key: "abstract", name: n("report_card_abstract_reasoning") },
            { key: "pattern", name: n("report_card_pattern_recognition") },
            { key: "spatial", name: n("report_card_spatial_orientation") },
            { key: "analytical", name: n("report_card_analytical_thinking") },
          ];
        return {
          userReportData: ((e, s) => {
            let a,
              { generalScore: n, percentageRank: l, sectionsResult: o, resultPosition: c } = e,
              u = (0, r.useTranslations)(),
              _ = [
                { title: (a = (0, r.useTranslations)()).raw("report_card_1_list_1") },
                { title: a.raw("report_card_1_list_2") },
                { title: a.raw("report_card_1_list_3") },
                { title: a.raw("report_card_1_list_4") },
                { title: a.raw("report_card_1_list_5") },
              ];
            return [
              {
                order: 1,
                title: u("report_card_1_title"),
                topText: u("report_card_1_top"),
                bottomText: u("report_card_1_bottom"),
                leftPart: (0, t.jsx)(f, { listItems: _ }),
                rightPart: (0, t.jsx)(h, {
                  isPdf: s,
                  src: s ? "/images/report/pdf-png/mascot-laptop.png" : "/images/report/mascot-laptop.webp",
                  alt: "myIQ mascot",
                }),
              },
              {
                order: 2,
                title: u("report_card_2_title"),
                topText: u("report_card_2_top"),
                leftPart: (0, t.jsx)(x, {
                  content: [u("report_card_2_text_content_1"), u("report_card_2_text_content_3")],
                }),
                rightPart: (0, t.jsx)(h, {
                  isPdf: s,
                  src: s ? "/images/report/pdf-png/age-chart.png" : "/images/report/age-chart.webp",
                  alt: "age chart",
                  width: 400,
                  height: 310,
                }),
              },
              {
                order: 3,
                title: u("report_card_3_title"),
                leftPart: (0, t.jsx)(g, {
                  score: n,
                  maxValue: 140,
                  title: u("report_card_your_iq_results"),
                  description: u.rich("report_card_your_test_results", {
                    percent: `${l}`,
                    span: (e) =>
                      (0, t.jsx)("span", { className: "font-semibold text-blue-custom", children: e }),
                  }),
                  isPdf: s,
                }),
                rightPart: (0, t.jsx)(t.Fragment, { children: (0, t.jsx)(i, { userPosition: c }) }),
              },
              {
                order: 4,
                title: u("report_card_visual_perception"),
                topText: u("report_card_4_top"),
                leftPart: (0, t.jsx)(x, {
                  content: [u("report_card_4_text_content_1"), u("report_card_4_text_content_2")],
                  isBackground: !0,
                }),
                rightPart: (0, t.jsx)(h, {
                  isPdf: s,
                  src: s ? "/images/report/pdf-png/mascot-visual.png" : "/images/report/mascot-visual.webp",
                  alt: "myIQ mascot",
                }),
              },
              {
                order: 5,
                title: u("report_card_5_title"),
                leftPart: (0, t.jsx)(g, {
                  score: o?.find((e) => e?.key === "visual")?.result ?? 90,
                  maxValue: 100,
                  titlePosition: "bottom",
                  title: o?.find((e) => e?.key === "visual")?.description,
                  description: u.raw("report_card_5_info"),
                  isPdf: s,
                }),
                rightPart: (0, t.jsx)(w, { userPosition: o?.find((e) => e?.key === "visual")?.result }),
              },
              {
                order: 6,
                title: u("report_card_abstract_reasoning"),
                topText: u("report_card_abstract_reasoning_top_text"),
                leftPart: (0, t.jsx)(x, {
                  content: [
                    u("report_card_abstract_reasoning_text_content_1"),
                    u("report_card_abstract_reasoning_text_content_2"),
                  ],
                  isBackground: !0,
                }),
                rightPart: (0, t.jsx)(h, {
                  isPdf: s,
                  src: s
                    ? "/images/report/pdf-png/mascot-abstract.png"
                    : "/images/report/mascot-abstract.webp",
                  alt: "myIQ mascot",
                }),
              },
              {
                order: 7,
                title: u("report_card_abstract_reasoning_your_score"),
                leftPart: (0, t.jsx)(g, {
                  score: o?.find((e) => e?.key === "abstract")?.result ?? 90,
                  maxValue: 100,
                  titlePosition: "bottom",
                  title: o?.find((e) => e?.key === "abstract")?.description,
                  description: u.raw("report_card_abstract_reasoning_score_desc"),
                  isPdf: s,
                }),
                rightPart: (0, t.jsx)(w, { userPosition: o?.find((e) => e?.key === "abstract")?.result }),
              },
              {
                order: 8,
                title: u("report_card_pattern_recognition"),
                topText: u("report_card_pattern_recognition_top_text"),
                leftPart: (0, t.jsx)(x, {
                  content: [
                    u("report_card_pattern_recognition_text_content_1"),
                    u("report_card_pattern_recognition_text_content_2"),
                  ],
                  isBackground: !0,
                }),
                rightPart: (0, t.jsx)(h, {
                  isPdf: s,
                  src: s ? "/images/report/pdf-png/mascot-pattern.png" : "/images/report/mascot-pattern.webp",
                  alt: "myIQ mascot",
                }),
              },
              {
                order: 9,
                title: u("report_card_pattern_recognition_your_score"),
                leftPart: (0, t.jsx)(g, {
                  score: o?.find((e) => e?.key === "pattern")?.result ?? 90,
                  maxValue: 100,
                  titlePosition: "bottom",
                  title: o?.find((e) => e?.key === "pattern")?.description,
                  description: u.raw("report_card_pattern_recognition_score_desc"),
                  isPdf: s,
                }),
                rightPart: (0, t.jsx)(w, { userPosition: o?.find((e) => e?.key === "pattern")?.result }),
              },
              {
                order: 10,
                title: u("report_card_spatial_orientation"),
                topText: u("report_card_spatial_orientation_top"),
                leftPart: (0, t.jsx)(x, {
                  content: [
                    u("report_card_spatial_orientation_text_content_1"),
                    u("report_card_spatial_orientation_text_content_2"),
                  ],
                  isBackground: !0,
                }),
                rightPart: (0, t.jsx)(h, {
                  isPdf: s,
                  src: s ? "/images/report/pdf-png/mascot-spatial.png" : "/images/report/mascot-spatial.webp",
                  alt: "myIQ mascot",
                }),
              },
              {
                order: 11,
                title: u("report_card_spatial_orientation_your_score"),
                leftPart: (0, t.jsx)(g, {
                  score: o?.find((e) => e?.key === "spatial")?.result ?? 90,
                  maxValue: 100,
                  titlePosition: "bottom",
                  title: o?.find((e) => e?.key === "spatial")?.description,
                  description: u.raw("report_card_spatial_orientation_score_desc"),
                  isPdf: s,
                }),
                rightPart: (0, t.jsx)(w, { userPosition: o?.find((e) => e?.key === "spatial")?.result }),
              },
              {
                order: 12,
                title: u("report_card_analytical_thinking"),
                topText: u("report_card_analytical_thinking_top"),
                leftPart: (0, t.jsx)(x, {
                  content: [
                    u("report_card_analytical_thinking_text_content_1"),
                    u("report_card_analytical_thinking_text_content_2"),
                  ],
                  isBackground: !0,
                }),
                rightPart: (0, t.jsx)(h, {
                  isPdf: s,
                  src: s
                    ? "/images/report/pdf-png/mascot-analytical.png"
                    : "/images/report/mascot-analytical.webp",
                  alt: "myIQ mascot",
                }),
              },
              {
                order: 13,
                title: u("report_card_analytical_thinking_your_score"),
                leftPart: (0, t.jsx)(g, {
                  score: o?.find((e) => e?.key === "analytical")?.result ?? 90,
                  maxValue: 100,
                  titlePosition: "bottom",
                  title: o?.find((e) => e?.key === "analytical")?.description,
                  description: u.raw("report_card_analytical_thinking_score_desc"),
                  isPdf: s,
                }),
                rightPart: (0, t.jsx)(w, { userPosition: o?.find((e) => e?.key === "analytical")?.result }),
              },
              {
                order: 14,
                title: u("report_card_your_results"),
                leftPart: (0, t.jsx)(g, {
                  score: n,
                  maxValue: 140,
                  title: u("report_card_your_iq_results"),
                  description: u.rich("report_card_your_test_results", {
                    percent: `${l}`,
                    span: (e) =>
                      (0, t.jsx)("span", { className: "font-semibold text-blue-custom", children: e }),
                  }),
                  isPdf: s,
                }),
                rightPart: (0, t.jsx)(b, { sectionsResult: o, isPdf: s }),
              },
            ];
          })(
            {
              percentageRank: e?.results?.percentScoreResult ?? "",
              generalScore: Number(e?.results?.userScore) || S.DEFAULT_GENERAL_SCORE,
              resultPosition: (() => {
                let t = e?.results?.userScore ? +e?.results?.userScore : 99;
                if (t > 131) return 1;
                if (t >= 116 && t <= 130) return 2;
                if (t >= 101 && t <= 115) return 3;
                if (t >= 85 && t <= 100) return 4;
                if (t >= 75 && t <= 84) return 5;
                else return 6;
              })(),
              sectionsResult:
                (e?.results?.sectionsResult
                  ? e.results.sectionsResult.map((e) => ({ ...e, description: A(e.result), name: Q(e.key) }))
                  : l.map((e) => ({
                      key: e.key,
                      result: S.DEFAULT_SECTION_SCORES[e.key],
                      description: A(S.DEFAULT_SECTION_SCORES[e.key]),
                      name: Q(e.key),
                    }))) ?? null,
            },
            a,
          ),
          getPercentageRank: (t) => {
            let r = t || (e?.results?.userScore ? +e?.results?.userScore : 99);
            if (r >= 130) return "97";
            if (r >= 120 && r <= 129) return "91";
            if (r >= 110 && r <= 119) return "79";
            if (r >= 90 && r <= 109) return "62";
            if (r >= 80 && r <= 89) return "45";
            return "30";
          },
          sections: l,
          generateSectionsResults: () =>
            l.map((e) => ({ key: e.key, result: (0, s.generateSectionScore)(20, 93) })),
          getSectionResult: A,
          getSectionPosition: function () {
            let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 90;
            if (e > 80) return 1;
            if (e > 64 && e <= 80) return 2;
            if (e > 48 && e <= 64) return 3;
            if (e > 32 && e <= 48) return 4;
            if (e > 16 && e <= 32) return 5;
            else return 6;
          },
        };
      };
  },
  406655,
  756306,
  (e) => {
    "use strict";
    let t = ["18-25", "26-29", "30-44", "45-60", "61+"];
    e.s(
      [
        "getAgeRangeFromAnswer",
        0,
        (e, r) => {
          if ("string" == typeof r && e?.length) return t[e.indexOf(r)];
        },
      ],
      406655,
    );
    e.s(
      [
        "getMathsTriviaQuestions",
        0,
        (e) => ({
          tenHours: {
            title: e("ab_myiq_quiz_maths_trivia_10h_title"),
            answers: ["60", "100", "360", "600", "900"],
            correctAnswer: "600",
            id: 570,
            baseId: 570,
            isDefaultColor: !0,
            answersNormalCase: !0,
          },
          twoAndHalfHours: {
            title: e("ab_myiq_quiz_maths_trivia_2h5_title"),
            answers: ["120", "130", "150", "170", "250"],
            correctAnswer: "150",
            id: 571,
            baseId: 571,
            isDefaultColor: !0,
            answersNormalCase: !0,
          },
        }),
      ],
      756306,
    );
  },
]);
