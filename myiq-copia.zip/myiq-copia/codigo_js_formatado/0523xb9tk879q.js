(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  632729,
  (e) => {
    "use strict";
    let t;
    class r extends Error {}
    class n extends r {
      constructor(e) {
        super(`Invalid DateTime: ${e.toMessage()}`);
      }
    }
    class i extends r {
      constructor(e) {
        super(`Invalid Interval: ${e.toMessage()}`);
      }
    }
    class s extends r {
      constructor(e) {
        super(`Invalid Duration: ${e.toMessage()}`);
      }
    }
    class a extends r {}
    class l extends r {
      constructor(e) {
        super(`Invalid unit ${e}`);
      }
    }
    class o extends r {}
    class u extends r {
      constructor() {
        super("Zone is an abstract class");
      }
    }
    let h = "numeric",
      c = "short",
      d = "long",
      m = { year: h, month: h, day: h },
      f = { year: h, month: c, day: h },
      y = { year: h, month: c, day: h, weekday: c },
      g = { year: h, month: d, day: h },
      w = { year: h, month: d, day: h, weekday: d },
      v = { hour: h, minute: h },
      p = { hour: h, minute: h, second: h },
      k = { hour: h, minute: h, second: h, timeZoneName: c },
      T = { hour: h, minute: h, second: h, timeZoneName: d },
      S = { hour: h, minute: h, hourCycle: "h23" },
      O = { hour: h, minute: h, second: h, hourCycle: "h23" },
      N = { hour: h, minute: h, second: h, hourCycle: "h23", timeZoneName: c },
      b = { hour: h, minute: h, second: h, hourCycle: "h23", timeZoneName: d },
      M = { year: h, month: h, day: h, hour: h, minute: h },
      D = { year: h, month: h, day: h, hour: h, minute: h, second: h },
      I = { year: h, month: c, day: h, hour: h, minute: h },
      V = { year: h, month: c, day: h, hour: h, minute: h, second: h },
      E = { year: h, month: c, day: h, weekday: c, hour: h, minute: h },
      x = { year: h, month: d, day: h, hour: h, minute: h, timeZoneName: c },
      F = { year: h, month: d, day: h, hour: h, minute: h, second: h, timeZoneName: c },
      C = { year: h, month: d, day: h, weekday: d, hour: h, minute: h, timeZoneName: d },
      $ = { year: h, month: d, day: h, weekday: d, hour: h, minute: h, second: h, timeZoneName: d };
    class W {
      get type() {
        throw new u();
      }
      get name() {
        throw new u();
      }
      get ianaName() {
        return this.name;
      }
      get isUniversal() {
        throw new u();
      }
      offsetName(e, t) {
        throw new u();
      }
      formatOffset(e, t) {
        throw new u();
      }
      offset(e) {
        throw new u();
      }
      equals(e) {
        throw new u();
      }
      get isValid() {
        throw new u();
      }
    }
    let Z = null;
    class L extends W {
      static get instance() {
        return (null === Z && (Z = new L()), Z);
      }
      get type() {
        return "system";
      }
      get name() {
        return new Intl.DateTimeFormat().resolvedOptions().timeZone;
      }
      get isUniversal() {
        return !1;
      }
      offsetName(e, t) {
        let { format: r, locale: n } = t;
        return e2(e, r, n);
      }
      formatOffset(e, t) {
        return e5(this.offset(e), t);
      }
      offset(e) {
        return -new Date(e).getTimezoneOffset();
      }
      equals(e) {
        return "system" === e.type;
      }
      get isValid() {
        return !0;
      }
    }
    let z = new Map(),
      A = { year: 0, month: 1, day: 2, era: 3, hour: 4, minute: 5, second: 6 },
      q = new Map();
    class j extends W {
      static create(e) {
        let t = q.get(e);
        return (void 0 === t && q.set(e, (t = new j(e))), t);
      }
      static resetCache() {
        (q.clear(), z.clear());
      }
      static isValidSpecifier(e) {
        return this.isValidZone(e);
      }
      static isValidZone(e) {
        if (!e) return !1;
        try {
          return (new Intl.DateTimeFormat("en-US", { timeZone: e }).format(), !0);
        } catch (e) {
          return !1;
        }
      }
      constructor(e) {
        (super(), (this.zoneName = e), (this.valid = j.isValidZone(e)));
      }
      get type() {
        return "iana";
      }
      get name() {
        return this.zoneName;
      }
      get isUniversal() {
        return !1;
      }
      offsetName(e, t) {
        let { format: r, locale: n } = t;
        return e2(e, r, n, this.name);
      }
      formatOffset(e, t) {
        return e5(this.offset(e), t);
      }
      offset(e) {
        var t;
        let r;
        if (!this.valid) return NaN;
        let n = new Date(e);
        if (isNaN(n)) return NaN;
        let i =
            ((t = this.name),
            void 0 === (r = z.get(t)) &&
              ((r = new Intl.DateTimeFormat("en-US", {
                hour12: !1,
                timeZone: t,
                year: "numeric",
                month: "2-digit",
                day: "2-digit",
                hour: "2-digit",
                minute: "2-digit",
                second: "2-digit",
                era: "short",
              })),
              z.set(t, r)),
            r),
          [s, a, l, o, u, h, c] = i.formatToParts
            ? (function (e, t) {
                let r = e.formatToParts(t),
                  n = [];
                for (let e = 0; e < r.length; e++) {
                  let { type: t, value: i } = r[e],
                    s = A[t];
                  "era" === t ? (n[s] = i) : eW(s) || (n[s] = parseInt(i, 10));
                }
                return n;
              })(i, n)
            : (function (e, t) {
                let r = e.format(t).replace(/\u200E/g, ""),
                  [, n, i, s, a, l, o, u] = /(\d+)\/(\d+)\/(\d+) (AD|BC),? (\d+):(\d+):(\d+)/.exec(r);
                return [s, n, i, a, l, o, u];
              })(i, n);
        "BC" === o && (s = -Math.abs(s) + 1);
        let d = eK({
            year: s,
            month: a,
            day: l,
            hour: 24 === u ? 0 : u,
            minute: h,
            second: c,
            millisecond: 0,
          }),
          m = +n,
          f = m % 1e3;
        return (d - (m -= f >= 0 ? f : 1e3 + f)) / 6e4;
      }
      equals(e) {
        return "iana" === e.type && e.name === this.name;
      }
      get isValid() {
        return this.valid;
      }
    }
    let U = {},
      _ = new Map();
    function Y(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
        r = JSON.stringify([e, t]),
        n = _.get(r);
      return (void 0 === n && ((n = new Intl.DateTimeFormat(e, t)), _.set(r, n)), n);
    }
    let R = new Map(),
      H = new Map(),
      P = null,
      J = new Map();
    function G(e) {
      let t = J.get(e);
      return (void 0 === t && ((t = new Intl.DateTimeFormat(e).resolvedOptions()), J.set(e, t)), t);
    }
    let B = new Map();
    function Q(e, t, r, n) {
      let i = e.listingMode();
      return "error" === i ? null : "en" === i ? r(t) : n(t);
    }
    class K {
      constructor(e, t, r) {
        ((this.padTo = r.padTo || 0), (this.floor = r.floor || !1));
        const { padTo: n, floor: i, ...s } = r;
        if (!t || Object.keys(s).length > 0) {
          const t = { useGrouping: !1, ...r };
          (r.padTo > 0 && (t.minimumIntegerDigits = r.padTo),
            (this.inf = (function (e) {
              let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                r = JSON.stringify([e, t]),
                n = R.get(r);
              return (void 0 === n && ((n = new Intl.NumberFormat(e, t)), R.set(r, n)), n);
            })(e, t)));
        }
      }
      format(e) {
        if (!this.inf) return eY(this.floor ? Math.floor(e) : eJ(e, 3), this.padTo);
        {
          let t = this.floor ? Math.floor(e) : e;
          return this.inf.format(t);
        }
      }
    }
    class X {
      constructor(e, t, r) {
        let n;
        if (((this.opts = r), (this.originalZone = void 0), this.opts.timeZone)) this.dt = e;
        else if ("fixed" === e.zone.type) {
          const t = -1 * (e.offset / 60),
            r = t >= 0 ? `Etc/GMT+${t}` : `Etc/GMT${t}`;
          0 !== e.offset && j.create(r).valid
            ? ((n = r), (this.dt = e))
            : ((n = "UTC"),
              (this.dt = 0 === e.offset ? e : e.setZone("UTC").plus({ minutes: e.offset })),
              (this.originalZone = e.zone));
        } else
          "system" === e.zone.type
            ? (this.dt = e)
            : "iana" === e.zone.type
              ? ((this.dt = e), (n = e.zone.name))
              : ((n = "UTC"),
                (this.dt = e.setZone("UTC").plus({ minutes: e.offset })),
                (this.originalZone = e.zone));
        const i = { ...this.opts };
        ((i.timeZone = i.timeZone || n), (this.dtf = Y(t, i)));
      }
      format() {
        return this.originalZone
          ? this.formatToParts()
              .map((e) => {
                let { value: t } = e;
                return t;
              })
              .join("")
          : this.dtf.format(this.dt.toJSDate());
      }
      formatToParts() {
        let e = this.dtf.formatToParts(this.dt.toJSDate());
        return this.originalZone
          ? e.map((e) => {
              if ("timeZoneName" !== e.type) return e;
              {
                let t = this.originalZone.offsetName(this.dt.ts, {
                  locale: this.dt.locale,
                  format: this.opts.timeZoneName,
                });
                return { ...e, value: t };
              }
            })
          : e;
      }
      resolvedOptions() {
        return this.dtf.resolvedOptions();
      }
    }
    class ee {
      constructor(e, t, r) {
        ((this.opts = { style: "long", ...r }),
          !t &&
            ez() &&
            (this.rtf = (function (e) {
              let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                { base: r, ...n } = t,
                i = JSON.stringify([e, n]),
                s = H.get(i);
              return (void 0 === s && ((s = new Intl.RelativeTimeFormat(e, t)), H.set(i, s)), s);
            })(e, r)));
      }
      format(e, t) {
        return this.rtf
          ? this.rtf.format(e, t)
          : (function (e, t) {
              let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "always",
                n = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
                i = {
                  years: ["year", "yr."],
                  quarters: ["quarter", "qtr."],
                  months: ["month", "mo."],
                  weeks: ["week", "wk."],
                  days: ["day", "day", "days"],
                  hours: ["hour", "hr."],
                  minutes: ["minute", "min."],
                  seconds: ["second", "sec."],
                },
                s = -1 === ["hours", "minutes", "seconds"].indexOf(e);
              if ("auto" === r && s) {
                let r = "days" === e;
                switch (t) {
                  case 1:
                    return r ? "tomorrow" : `next ${i[e][0]}`;
                  case -1:
                    return r ? "yesterday" : `last ${i[e][0]}`;
                  case 0:
                    return r ? "today" : `this ${i[e][0]}`;
                }
              }
              let a = Object.is(t, -0) || t < 0,
                l = Math.abs(t),
                o = 1 === l,
                u = i[e],
                h = n ? (o ? u[1] : u[2] || u[1]) : o ? i[e][0] : e;
              return a ? `${l} ${h} ago` : `in ${l} ${h}`;
            })(t, e, this.opts.numeric, "long" !== this.opts.style);
      }
      formatToParts(e, t) {
        return this.rtf ? this.rtf.formatToParts(e, t) : [];
      }
    }
    let et = { firstDay: 1, minimalDays: 4, weekend: [6, 7] };
    class er {
      static fromOpts(e) {
        return er.create(e.locale, e.numberingSystem, e.outputCalendar, e.weekSettings, e.defaultToEN);
      }
      static create(e, t, r, n) {
        let i = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
          s = e || ek.defaultLocale;
        return new er(
          s || (i ? "en-US" : P || (P = new Intl.DateTimeFormat().resolvedOptions().locale)),
          t || ek.defaultNumberingSystem,
          r || ek.defaultOutputCalendar,
          eU(n) || ek.defaultWeekSettings,
          s,
        );
      }
      static resetCache() {
        ((P = null), _.clear(), R.clear(), H.clear(), J.clear(), B.clear());
      }
      static fromObject() {
        let {
          locale: e,
          numberingSystem: t,
          outputCalendar: r,
          weekSettings: n,
        } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return er.create(e, t, r, n);
      }
      constructor(e, t, r, n, i) {
        const [s, a, l] = (function (e) {
          let t = e.indexOf("-x-");
          -1 !== t && (e = e.substring(0, t));
          let r = e.indexOf("-u-");
          if (-1 === r) return [e];
          {
            let t, n;
            try {
              ((t = Y(e).resolvedOptions()), (n = e));
            } catch (s) {
              let i = e.substring(0, r);
              ((t = Y(i).resolvedOptions()), (n = i));
            }
            let { numberingSystem: i, calendar: s } = t;
            return [n, i, s];
          }
        })(e);
        ((this.locale = s),
          (this.numberingSystem = t || a || null),
          (this.outputCalendar = r || l || null),
          (this.weekSettings = n),
          (this.intl = (function (e, t, r) {
            return (
              (r || t) && (e.includes("-u-") || (e += "-u"), r && (e += `-ca-${r}`), t && (e += `-nu-${t}`)),
              e
            );
          })(this.locale, this.numberingSystem, this.outputCalendar)),
          (this.weekdaysCache = { format: {}, standalone: {} }),
          (this.monthsCache = { format: {}, standalone: {} }),
          (this.meridiemCache = null),
          (this.eraCache = {}),
          (this.specifiedLocale = i),
          (this.fastNumbersCached = null));
      }
      get fastNumbers() {
        return (
          null == this.fastNumbersCached &&
            (this.fastNumbersCached =
              (!this.numberingSystem || "latn" === this.numberingSystem) &&
              ("latn" === this.numberingSystem ||
                !this.locale ||
                this.locale.startsWith("en") ||
                "latn" === G(this.locale).numberingSystem)),
          this.fastNumbersCached
        );
      }
      listingMode() {
        let e = this.isEnglish(),
          t =
            (null === this.numberingSystem || "latn" === this.numberingSystem) &&
            (null === this.outputCalendar || "gregory" === this.outputCalendar);
        return e && t ? "en" : "intl";
      }
      clone(e) {
        return e && 0 !== Object.getOwnPropertyNames(e).length
          ? er.create(
              e.locale || this.specifiedLocale,
              e.numberingSystem || this.numberingSystem,
              e.outputCalendar || this.outputCalendar,
              eU(e.weekSettings) || this.weekSettings,
              e.defaultToEN || !1,
            )
          : this;
      }
      redefaultToEN() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return this.clone({ ...e, defaultToEN: !0 });
      }
      redefaultToSystem() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return this.clone({ ...e, defaultToEN: !1 });
      }
      months(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return Q(this, e, tt, () => {
          let r = "ja" === this.intl || this.intl.startsWith("ja-"),
            n = (t &= !r) ? { month: e, day: "numeric" } : { month: e },
            i = t ? "format" : "standalone";
          if (!this.monthsCache[i][e]) {
            let t = r ? (e) => this.dtFormatter(e, n).format() : (e) => this.extract(e, n, "month");
            this.monthsCache[i][e] = (function (e) {
              let t = [];
              for (let r = 1; r <= 12; r++) {
                let n = rH.utc(2009, r, 1);
                t.push(e(n));
              }
              return t;
            })(t);
          }
          return this.monthsCache[i][e];
        });
      }
      weekdays(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return Q(this, e, ts, () => {
          let r = t ? { weekday: e, year: "numeric", month: "long", day: "numeric" } : { weekday: e },
            n = t ? "format" : "standalone";
          return (
            this.weekdaysCache[n][e] ||
              (this.weekdaysCache[n][e] = (function (e) {
                let t = [];
                for (let r = 1; r <= 7; r++) {
                  let n = rH.utc(2016, 11, 13 + r);
                  t.push(e(n));
                }
                return t;
              })((e) => this.extract(e, r, "weekday"))),
            this.weekdaysCache[n][e]
          );
        });
      }
      meridiems() {
        return Q(
          this,
          void 0,
          () => ta,
          () => {
            if (!this.meridiemCache) {
              let e = { hour: "numeric", hourCycle: "h12" };
              this.meridiemCache = [rH.utc(2016, 11, 13, 9), rH.utc(2016, 11, 13, 19)].map((t) =>
                this.extract(t, e, "dayperiod"),
              );
            }
            return this.meridiemCache;
          },
        );
      }
      eras(e) {
        return Q(this, e, th, () => {
          let t = { era: e };
          return (
            this.eraCache[e] ||
              (this.eraCache[e] = [rH.utc(-40, 1, 1), rH.utc(2017, 1, 1)].map((e) =>
                this.extract(e, t, "era"),
              )),
            this.eraCache[e]
          );
        });
      }
      extract(e, t, r) {
        let n = this.dtFormatter(e, t)
          .formatToParts()
          .find((e) => e.type.toLowerCase() === r);
        return n ? n.value : null;
      }
      numberFormatter() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return new K(this.intl, e.forceSimple || this.fastNumbers, e);
      }
      dtFormatter(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return new X(e, this.intl, t);
      }
      relFormatter() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return new ee(this.intl, this.isEnglish(), e);
      }
      listFormatter() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (function (e) {
          let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
            r = JSON.stringify([e, t]),
            n = U[r];
          return (n || ((n = new Intl.ListFormat(e, t)), (U[r] = n)), n);
        })(this.intl, e);
      }
      isEnglish() {
        return (
          "en" === this.locale ||
          "en-us" === this.locale.toLowerCase() ||
          G(this.intl).locale.startsWith("en-us")
        );
      }
      getWeekSettings() {
        if (this.weekSettings) return this.weekSettings;
        if (!eA()) return et;
        var e = this.locale;
        let t = B.get(e);
        if (!t) {
          let r = new Intl.Locale(e);
          ("minimalDays" in (t = "getWeekInfo" in r ? r.getWeekInfo() : r.weekInfo) || (t = { ...et, ...t }),
            B.set(e, t));
        }
        return t;
      }
      getStartOfWeek() {
        return this.getWeekSettings().firstDay;
      }
      getMinDaysInFirstWeek() {
        return this.getWeekSettings().minimalDays;
      }
      getWeekendDays() {
        return this.getWeekSettings().weekend;
      }
      equals(e) {
        return (
          this.locale === e.locale &&
          this.numberingSystem === e.numberingSystem &&
          this.outputCalendar === e.outputCalendar
        );
      }
      toString() {
        return `Locale(${this.locale}, ${this.numberingSystem}, ${this.outputCalendar})`;
      }
    }
    let en = null;
    class ei extends W {
      static get utcInstance() {
        return (null === en && (en = new ei(0)), en);
      }
      static instance(e) {
        return 0 === e ? ei.utcInstance : new ei(e);
      }
      static parseSpecifier(e) {
        if (e) {
          let t = e.match(/^utc(?:([+-]\d{1,2})(?::(\d{2}))?)?$/i);
          if (t) return new ei(e3(t[1], t[2]));
        }
        return null;
      }
      constructor(e) {
        (super(), (this.fixed = e));
      }
      get type() {
        return "fixed";
      }
      get name() {
        return 0 === this.fixed ? "UTC" : `UTC${e5(this.fixed, "narrow")}`;
      }
      get ianaName() {
        return 0 === this.fixed ? "Etc/UTC" : `Etc/GMT${e5(-this.fixed, "narrow")}`;
      }
      offsetName() {
        return this.name;
      }
      formatOffset(e, t) {
        return e5(this.fixed, t);
      }
      get isUniversal() {
        return !0;
      }
      offset() {
        return this.fixed;
      }
      equals(e) {
        return "fixed" === e.type && e.fixed === this.fixed;
      }
      get isValid() {
        return !0;
      }
    }
    class es extends W {
      constructor(e) {
        (super(), (this.zoneName = e));
      }
      get type() {
        return "invalid";
      }
      get name() {
        return this.zoneName;
      }
      get isUniversal() {
        return !1;
      }
      offsetName() {
        return null;
      }
      formatOffset() {
        return "";
      }
      offset() {
        return NaN;
      }
      equals() {
        return !1;
      }
      get isValid() {
        return !1;
      }
    }
    function ea(e, t) {
      if (eW(e) || null === e) return t;
      if (e instanceof W) return e;
      if ("string" == typeof e) {
        let r = e.toLowerCase();
        return "default" === r
          ? t
          : "local" === r || "system" === r
            ? L.instance
            : "utc" === r || "gmt" === r
              ? ei.utcInstance
              : ei.parseSpecifier(r) || j.create(e);
      }
      if (eZ(e)) return ei.instance(e);
      if ("object" == typeof e && "offset" in e && "function" == typeof e.offset) return e;
      else return new es(e);
    }
    let el = {
        arab: "[٠-٩]",
        arabext: "[۰-۹]",
        bali: "[᭐-᭙]",
        beng: "[০-৯]",
        deva: "[०-९]",
        fullwide: "[０-９]",
        gujr: "[૦-૯]",
        hanidec: "[〇|一|二|三|四|五|六|七|八|九]",
        khmr: "[០-៩]",
        knda: "[೦-೯]",
        laoo: "[໐-໙]",
        limb: "[᥆-᥏]",
        mlym: "[൦-൯]",
        mong: "[᠐-᠙]",
        mymr: "[၀-၉]",
        orya: "[୦-୯]",
        tamldec: "[௦-௯]",
        telu: "[౦-౯]",
        thai: "[๐-๙]",
        tibt: "[༠-༩]",
        latn: "\\d",
      },
      eo = {
        arab: [1632, 1641],
        arabext: [1776, 1785],
        bali: [6992, 7001],
        beng: [2534, 2543],
        deva: [2406, 2415],
        fullwide: [65296, 65303],
        gujr: [2790, 2799],
        khmr: [6112, 6121],
        knda: [3302, 3311],
        laoo: [3792, 3801],
        limb: [6470, 6479],
        mlym: [3430, 3439],
        mong: [6160, 6169],
        mymr: [4160, 4169],
        orya: [2918, 2927],
        tamldec: [3046, 3055],
        telu: [3174, 3183],
        thai: [3664, 3673],
        tibt: [3872, 3881],
      },
      eu = el.hanidec.replace(/[\[|\]]/g, "").split(""),
      eh = new Map();
    function ec(e) {
      let { numberingSystem: t } = e,
        r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
        n = t || "latn",
        i = eh.get(n);
      void 0 === i && ((i = new Map()), eh.set(n, i));
      let s = i.get(r);
      return (void 0 === s && ((s = RegExp(`${el[n]}${r}`)), i.set(r, s)), s);
    }
    let ed = () => Date.now(),
      em = "system",
      ef = null,
      ey = null,
      eg = null,
      ew = 60,
      ev,
      ep = null;
    class ek {
      static get now() {
        return ed;
      }
      static set now(e) {
        ed = e;
      }
      static set defaultZone(e) {
        em = e;
      }
      static get defaultZone() {
        return ea(em, L.instance);
      }
      static get defaultLocale() {
        return ef;
      }
      static set defaultLocale(e) {
        ef = e;
      }
      static get defaultNumberingSystem() {
        return ey;
      }
      static set defaultNumberingSystem(e) {
        ey = e;
      }
      static get defaultOutputCalendar() {
        return eg;
      }
      static set defaultOutputCalendar(e) {
        eg = e;
      }
      static get defaultWeekSettings() {
        return ep;
      }
      static set defaultWeekSettings(e) {
        ep = eU(e);
      }
      static get twoDigitCutoffYear() {
        return ew;
      }
      static set twoDigitCutoffYear(e) {
        ew = e % 100;
      }
      static get throwOnInvalid() {
        return ev;
      }
      static set throwOnInvalid(e) {
        ev = e;
      }
      static resetCaches() {
        (er.resetCache(), j.resetCache(), rH.resetCache(), eh.clear());
      }
    }
    class eT {
      constructor(e, t) {
        ((this.reason = e), (this.explanation = t));
      }
      toMessage() {
        return this.explanation ? `${this.reason}: ${this.explanation}` : this.reason;
      }
    }
    let eS = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334],
      eO = [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335];
    function eN(e, t) {
      return new eT(
        "unit out of range",
        `you specified ${t} (of type ${typeof t}) as a ${e}, which is invalid`,
      );
    }
    function eb(e, t, r) {
      let n = new Date(Date.UTC(e, t - 1, r));
      e < 100 && e >= 0 && n.setUTCFullYear(n.getUTCFullYear() - 1900);
      let i = n.getUTCDay();
      return 0 === i ? 7 : i;
    }
    function eM(e, t) {
      let r = eG(e) ? eO : eS,
        n = r.findIndex((e) => e < t),
        i = t - r[n];
      return { month: n + 1, day: i };
    }
    function eD(e, t) {
      return ((e - t + 7) % 7) + 1;
    }
    function eI(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 4,
        r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
        { year: n, month: i, day: s } = e,
        a = s + (eG(n) ? eO : eS)[i - 1],
        l = eD(eb(n, i, s), r),
        o = Math.floor((a - l + 14 - t) / 7),
        u;
      return (
        o < 1 ? (o = e0((u = n - 1), t, r)) : o > e0(n, t, r) ? ((u = n + 1), (o = 1)) : (u = n),
        { weekYear: u, weekNumber: o, weekday: l, ...e7(e) }
      );
    }
    function eV(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 4,
        r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
        { weekYear: n, weekNumber: i, weekday: s } = e,
        a = eD(eb(n, 1, t), r),
        l = eB(n),
        o = 7 * i + s - a - 7 + t,
        u;
      o < 1 ? (o += eB((u = n - 1))) : o > l ? ((u = n + 1), (o -= eB(n))) : (u = n);
      let { month: h, day: c } = eM(u, o);
      return { year: u, month: h, day: c, ...e7(e) };
    }
    function eE(e) {
      let { year: t, month: r, day: n } = e,
        i = n + (eG(t) ? eO : eS)[r - 1];
      return { year: t, ordinal: i, ...e7(e) };
    }
    function ex(e) {
      let { year: t, ordinal: r } = e,
        { month: n, day: i } = eM(t, r);
      return { year: t, month: n, day: i, ...e7(e) };
    }
    function eF(e, t) {
      if (!(!eW(e.localWeekday) || !eW(e.localWeekNumber) || !eW(e.localWeekYear)))
        return { minDaysInFirstWeek: 4, startOfWeek: 1 };
      if (!eW(e.weekday) || !eW(e.weekNumber) || !eW(e.weekYear))
        throw new a("Cannot mix locale-based week fields with ISO-based week fields");
      return (
        eW(e.localWeekday) || (e.weekday = e.localWeekday),
        eW(e.localWeekNumber) || (e.weekNumber = e.localWeekNumber),
        eW(e.localWeekYear) || (e.weekYear = e.localWeekYear),
        delete e.localWeekday,
        delete e.localWeekNumber,
        delete e.localWeekYear,
        { minDaysInFirstWeek: t.getMinDaysInFirstWeek(), startOfWeek: t.getStartOfWeek() }
      );
    }
    function eC(e) {
      let t = eL(e.year),
        r = e_(e.month, 1, 12),
        n = e_(e.day, 1, eQ(e.year, e.month));
      return t ? (r ? !n && eN("day", e.day) : eN("month", e.month)) : eN("year", e.year);
    }
    function e$(e) {
      let { hour: t, minute: r, second: n, millisecond: i } = e,
        s = e_(t, 0, 23) || (24 === t && 0 === r && 0 === n && 0 === i),
        a = e_(r, 0, 59),
        l = e_(n, 0, 59),
        o = e_(i, 0, 999);
      return s ? (a ? (l ? !o && eN("millisecond", i) : eN("second", n)) : eN("minute", r)) : eN("hour", t);
    }
    function eW(e) {
      return void 0 === e;
    }
    function eZ(e) {
      return "number" == typeof e;
    }
    function eL(e) {
      return "number" == typeof e && e % 1 == 0;
    }
    function ez() {
      try {
        return "u" > typeof Intl && !!Intl.RelativeTimeFormat;
      } catch (e) {
        return !1;
      }
    }
    function eA() {
      try {
        return (
          "u" > typeof Intl &&
          !!Intl.Locale &&
          ("weekInfo" in Intl.Locale.prototype || "getWeekInfo" in Intl.Locale.prototype)
        );
      } catch (e) {
        return !1;
      }
    }
    function eq(e, t, r) {
      if (0 !== e.length)
        return e.reduce((e, n) => {
          let i = [t(n), n];
          return e && r(e[0], i[0]) === e[0] ? e : i;
        }, null)[1];
    }
    function ej(e, t) {
      return Object.prototype.hasOwnProperty.call(e, t);
    }
    function eU(e) {
      if (null == e) return null;
      if ("object" != typeof e) throw new o("Week settings must be an object");
      if (
        !e_(e.firstDay, 1, 7) ||
        !e_(e.minimalDays, 1, 7) ||
        !Array.isArray(e.weekend) ||
        e.weekend.some((e) => !e_(e, 1, 7))
      )
        throw new o("Invalid week settings");
      return { firstDay: e.firstDay, minimalDays: e.minimalDays, weekend: Array.from(e.weekend) };
    }
    function e_(e, t, r) {
      return eL(e) && e >= t && e <= r;
    }
    function eY(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2;
      return e < 0 ? "-" + ("" + -e).padStart(t, "0") : ("" + e).padStart(t, "0");
    }
    function eR(e) {
      if (!eW(e) && null !== e && "" !== e) return parseInt(e, 10);
    }
    function eH(e) {
      if (!eW(e) && null !== e && "" !== e) return parseFloat(e);
    }
    function eP(e) {
      if (!eW(e) && null !== e && "" !== e) return Math.floor(1e3 * parseFloat("0." + e));
    }
    function eJ(e, t) {
      let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "round",
        n = 10 ** t;
      switch (r) {
        case "expand":
          return e > 0 ? Math.ceil(e * n) / n : Math.floor(e * n) / n;
        case "trunc":
          return Math.trunc(e * n) / n;
        case "round":
          return Math.round(e * n) / n;
        case "floor":
          return Math.floor(e * n) / n;
        case "ceil":
          return Math.ceil(e * n) / n;
        default:
          throw RangeError(`Value rounding ${r} is out of range`);
      }
    }
    function eG(e) {
      return e % 4 == 0 && (e % 100 != 0 || e % 400 == 0);
    }
    function eB(e) {
      return eG(e) ? 366 : 365;
    }
    function eQ(e, t) {
      var r;
      let n = (r = t - 1) - 12 * Math.floor(r / 12) + 1;
      return 2 === n
        ? eG(e + (t - n) / 12)
          ? 29
          : 28
        : [31, null, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][n - 1];
    }
    function eK(e) {
      let t = Date.UTC(e.year, e.month - 1, e.day, e.hour, e.minute, e.second, e.millisecond);
      return (
        e.year < 100 && e.year >= 0 && (t = new Date(t)).setUTCFullYear(e.year, e.month - 1, e.day),
        +t
      );
    }
    function eX(e, t, r) {
      return -eD(eb(e, 1, t), r) + t - 1;
    }
    function e0(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 4,
        r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
        n = eX(e, t, r),
        i = eX(e + 1, t, r);
      return (eB(e) - n + i) / 7;
    }
    function e1(e) {
      return e > 99 ? e : e > ek.twoDigitCutoffYear ? 1900 + e : 2e3 + e;
    }
    function e2(e, t, r) {
      let n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
        i = new Date(e),
        s = {
          hourCycle: "h23",
          year: "numeric",
          month: "2-digit",
          day: "2-digit",
          hour: "2-digit",
          minute: "2-digit",
        };
      n && (s.timeZone = n);
      let a = { timeZoneName: t, ...s },
        l = new Intl.DateTimeFormat(r, a)
          .formatToParts(i)
          .find((e) => "timezonename" === e.type.toLowerCase());
      return l ? l.value : null;
    }
    function e3(e, t) {
      let r = parseInt(e, 10);
      Number.isNaN(r) && (r = 0);
      let n = parseInt(t, 10) || 0,
        i = r < 0 || Object.is(r, -0) ? -n : n;
      return 60 * r + i;
    }
    function e4(e) {
      let t = Number(e);
      if ("boolean" == typeof e || "" === e || !Number.isFinite(t)) throw new o(`Invalid unit value ${e}`);
      return t;
    }
    function e6(e, t) {
      let r = {};
      for (let n in e)
        if (ej(e, n)) {
          let i = e[n];
          if (null == i) continue;
          r[t(n)] = e4(i);
        }
      return r;
    }
    function e5(e, t) {
      let r = Math.trunc(Math.abs(e / 60)),
        n = Math.trunc(Math.abs(e % 60)),
        i = e >= 0 ? "+" : "-";
      switch (t) {
        case "short":
          return `${i}${eY(r, 2)}:${eY(n, 2)}`;
        case "narrow":
          return `${i}${r}${n > 0 ? `:${n}` : ""}`;
        case "techie":
          return `${i}${eY(r, 2)}${eY(n, 2)}`;
        default:
          throw RangeError(`Value format ${t} is out of range for property format`);
      }
    }
    function e7(e) {
      return ["hour", "minute", "second", "millisecond"].reduce((t, r) => ((t[r] = e[r]), t), {});
    }
    let e9 = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
      ],
      e8 = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
      te = ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"];
    function tt(e) {
      switch (e) {
        case "narrow":
          return [...te];
        case "short":
          return [...e8];
        case "long":
          return [...e9];
        case "numeric":
          return ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"];
        case "2-digit":
          return ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
        default:
          return null;
      }
    }
    let tr = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
      tn = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
      ti = ["M", "T", "W", "T", "F", "S", "S"];
    function ts(e) {
      switch (e) {
        case "narrow":
          return [...ti];
        case "short":
          return [...tn];
        case "long":
          return [...tr];
        case "numeric":
          return ["1", "2", "3", "4", "5", "6", "7"];
        default:
          return null;
      }
    }
    let ta = ["AM", "PM"],
      tl = ["Before Christ", "Anno Domini"],
      to = ["BC", "AD"],
      tu = ["B", "A"];
    function th(e) {
      switch (e) {
        case "narrow":
          return [...tu];
        case "short":
          return [...to];
        case "long":
          return [...tl];
        default:
          return null;
      }
    }
    function tc(e, t) {
      let r = "";
      for (let n of e) n.literal ? (r += n.val) : (r += t(n.val));
      return r;
    }
    let td = {
      D: m,
      DD: f,
      DDD: g,
      DDDD: w,
      t: v,
      tt: p,
      ttt: k,
      tttt: T,
      T: S,
      TT: O,
      TTT: N,
      TTTT: b,
      f: M,
      ff: I,
      fff: x,
      ffff: C,
      F: D,
      FF: V,
      FFF: F,
      FFFF: $,
    };
    class tm {
      static create(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return new tm(e, t);
      }
      static parseFormat(e) {
        let t = null,
          r = "",
          n = !1,
          i = [];
        for (let s = 0; s < e.length; s++) {
          let a = e.charAt(s);
          "'" === a
            ? ((r.length > 0 || n) && i.push({ literal: n || /^\s+$/.test(r), val: "" === r ? "'" : r }),
              (t = null),
              (r = ""),
              (n = !n))
            : n || a === t
              ? (r += a)
              : (r.length > 0 && i.push({ literal: /^\s+$/.test(r), val: r }), (r = a), (t = a));
        }
        return (r.length > 0 && i.push({ literal: n || /^\s+$/.test(r), val: r }), i);
      }
      static macroTokenToFormatOpts(e) {
        return td[e];
      }
      constructor(e, t) {
        ((this.opts = t), (this.loc = e), (this.systemLoc = null));
      }
      formatWithSystemDefault(e, t) {
        return (
          null === this.systemLoc && (this.systemLoc = this.loc.redefaultToSystem()),
          this.systemLoc.dtFormatter(e, { ...this.opts, ...t }).format()
        );
      }
      dtFormatter(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return this.loc.dtFormatter(e, { ...this.opts, ...t });
      }
      formatDateTime(e, t) {
        return this.dtFormatter(e, t).format();
      }
      formatDateTimeParts(e, t) {
        return this.dtFormatter(e, t).formatToParts();
      }
      formatInterval(e, t) {
        return this.dtFormatter(e.start, t).dtf.formatRange(e.start.toJSDate(), e.end.toJSDate());
      }
      resolvedOptions(e, t) {
        return this.dtFormatter(e, t).resolvedOptions();
      }
      num(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0;
        if (this.opts.forceSimple) return eY(e, t);
        let n = { ...this.opts };
        return (t > 0 && (n.padTo = t), r && (n.signDisplay = r), this.loc.numberFormatter(n).format(e));
      }
      formatDateTimeFromString(e, t) {
        let r = "en" === this.loc.listingMode(),
          n = this.loc.outputCalendar && "gregory" !== this.loc.outputCalendar,
          i = (t, r) => this.loc.extract(e, t, r),
          s = (t) =>
            e.isOffsetFixed && 0 === e.offset && t.allowZ
              ? "Z"
              : e.isValid
                ? e.zone.formatOffset(e.ts, t.format)
                : "",
          a = (t, n) =>
            r ? tt(t)[e.month - 1] : i(n ? { month: t } : { month: t, day: "numeric" }, "month"),
          l = (t, n) =>
            r
              ? ts(t)[e.weekday - 1]
              : i(n ? { weekday: t } : { weekday: t, month: "long", day: "numeric" }, "weekday"),
          o = (t) => {
            let r = tm.macroTokenToFormatOpts(t);
            return r ? this.formatWithSystemDefault(e, r) : t;
          },
          u = (t) => (r ? th(t)[e.year < 0 ? 0 : 1] : i({ era: t }, "era")),
          h = (t) => {
            switch (t) {
              case "S":
                return this.num(e.millisecond);
              case "u":
              case "SSS":
                return this.num(e.millisecond, 3);
              case "s":
                return this.num(e.second);
              case "ss":
                return this.num(e.second, 2);
              case "uu":
                return this.num(Math.floor(e.millisecond / 10), 2);
              case "uuu":
                return this.num(Math.floor(e.millisecond / 100));
              case "m":
                return this.num(e.minute);
              case "mm":
                return this.num(e.minute, 2);
              case "h":
                return this.num(e.hour % 12 == 0 ? 12 : e.hour % 12);
              case "hh":
                return this.num(e.hour % 12 == 0 ? 12 : e.hour % 12, 2);
              case "H":
                return this.num(e.hour);
              case "HH":
                return this.num(e.hour, 2);
              case "Z":
                return s({ format: "narrow", allowZ: this.opts.allowZ });
              case "ZZ":
                return s({ format: "short", allowZ: this.opts.allowZ });
              case "ZZZ":
                return s({ format: "techie", allowZ: this.opts.allowZ });
              case "ZZZZ":
                return e.zone.offsetName(e.ts, { format: "short", locale: this.loc.locale });
              case "ZZZZZ":
                return e.zone.offsetName(e.ts, { format: "long", locale: this.loc.locale });
              case "z":
                return e.zoneName;
              case "a":
                return r ? ta[e.hour < 12 ? 0 : 1] : i({ hour: "numeric", hourCycle: "h12" }, "dayperiod");
              case "d":
                return n ? i({ day: "numeric" }, "day") : this.num(e.day);
              case "dd":
                return n ? i({ day: "2-digit" }, "day") : this.num(e.day, 2);
              case "c":
              case "E":
                return this.num(e.weekday);
              case "ccc":
                return l("short", !0);
              case "cccc":
                return l("long", !0);
              case "ccccc":
                return l("narrow", !0);
              case "EEE":
                return l("short", !1);
              case "EEEE":
                return l("long", !1);
              case "EEEEE":
                return l("narrow", !1);
              case "L":
                return n ? i({ month: "numeric", day: "numeric" }, "month") : this.num(e.month);
              case "LL":
                return n ? i({ month: "2-digit", day: "numeric" }, "month") : this.num(e.month, 2);
              case "LLL":
                return a("short", !0);
              case "LLLL":
                return a("long", !0);
              case "LLLLL":
                return a("narrow", !0);
              case "M":
                return n ? i({ month: "numeric" }, "month") : this.num(e.month);
              case "MM":
                return n ? i({ month: "2-digit" }, "month") : this.num(e.month, 2);
              case "MMM":
                return a("short", !1);
              case "MMMM":
                return a("long", !1);
              case "MMMMM":
                return a("narrow", !1);
              case "y":
                return n ? i({ year: "numeric" }, "year") : this.num(e.year);
              case "yy":
                return n ? i({ year: "2-digit" }, "year") : this.num(e.year.toString().slice(-2), 2);
              case "yyyy":
                return n ? i({ year: "numeric" }, "year") : this.num(e.year, 4);
              case "yyyyyy":
                return n ? i({ year: "numeric" }, "year") : this.num(e.year, 6);
              case "G":
                return u("short");
              case "GG":
                return u("long");
              case "GGGGG":
                return u("narrow");
              case "kk":
                return this.num(e.weekYear.toString().slice(-2), 2);
              case "kkkk":
                return this.num(e.weekYear, 4);
              case "W":
                return this.num(e.weekNumber);
              case "WW":
                return this.num(e.weekNumber, 2);
              case "n":
                return this.num(e.localWeekNumber);
              case "nn":
                return this.num(e.localWeekNumber, 2);
              case "ii":
                return this.num(e.localWeekYear.toString().slice(-2), 2);
              case "iiii":
                return this.num(e.localWeekYear, 4);
              case "o":
                return this.num(e.ordinal);
              case "ooo":
                return this.num(e.ordinal, 3);
              case "q":
                return this.num(e.quarter);
              case "qq":
                return this.num(e.quarter, 2);
              case "X":
                return this.num(Math.floor(e.ts / 1e3));
              case "x":
                return this.num(e.ts);
              default:
                return o(t);
            }
          };
        return tc(tm.parseFormat(t), h);
      }
      formatDurationFromString(e, t) {
        let r = "negativeLargestOnly" === this.opts.signMode ? -1 : 1,
          n = (e) => {
            switch (e[0]) {
              case "S":
                return "milliseconds";
              case "s":
                return "seconds";
              case "m":
                return "minutes";
              case "h":
                return "hours";
              case "d":
                return "days";
              case "w":
                return "weeks";
              case "M":
                return "months";
              case "y":
                return "years";
              default:
                return null;
            }
          },
          i = (e, t) => (i) => {
            let s = n(i);
            if (!s) return i;
            {
              let n,
                a = t.isNegativeDuration && s !== t.largestUnit ? r : 1;
              return (
                (n =
                  "negativeLargestOnly" === this.opts.signMode && s !== t.largestUnit
                    ? "never"
                    : "all" === this.opts.signMode
                      ? "always"
                      : "auto"),
                this.num(e.get(s) * a, i.length, n)
              );
            }
          },
          s = tm.parseFormat(t),
          a = s.reduce((e, t) => {
            let { literal: r, val: n } = t;
            return r ? e : e.concat(n);
          }, []),
          l = e.shiftTo(...a.map(n).filter((e) => e)),
          o = { isNegativeDuration: l < 0, largestUnit: Object.keys(l.values)[0] };
        return tc(s, i(l, o));
      }
    }
    let tf = /[A-Za-z_+-]{1,256}(?::?\/[A-Za-z0-9_+-]{1,256}(?:\/[A-Za-z0-9_+-]{1,256})?)?/;
    function ty() {
      for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
      let n = t.reduce((e, t) => e + t.source, "");
      return RegExp(`^${n}$`);
    }
    function tg() {
      for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
      return (e) =>
        t
          .reduce(
            (t, r) => {
              let [n, i, s] = t,
                [a, l, o] = r(e, s);
              return [{ ...n, ...a }, l || i, o];
            },
            [{}, null, 1],
          )
          .slice(0, 2);
    }
    function tw(e) {
      for (var t = arguments.length, r = Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++) r[n - 1] = arguments[n];
      if (null == e) return [null, null];
      for (let [t, n] of r) {
        let r = t.exec(e);
        if (r) return n(r);
      }
      return [null, null];
    }
    function tv() {
      for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
      return (e, r) => {
        let n,
          i = {};
        for (n = 0; n < t.length; n++) i[t[n]] = eR(e[r + n]);
        return [i, null, r + n];
      };
    }
    let tp = /(?:([Zz])|([+-]\d\d)(?::?(\d\d))?)/,
      tk = `(?:${tp.source}?(?:\\[(${tf.source})\\])?)?`,
      tT = /(\d\d)(?::?(\d\d)(?::?(\d\d)(?:[.,](\d{1,30}))?)?)?/,
      tS = RegExp(`${tT.source}${tk}`),
      tO = RegExp(`(?:[Tt]${tS.source})?`),
      tN = tv("weekYear", "weekNumber", "weekDay"),
      tb = tv("year", "ordinal"),
      tM = RegExp(`${tT.source} ?(?:${tp.source}|(${tf.source}))?`),
      tD = RegExp(`(?: ${tM.source})?`);
    function tI(e, t, r) {
      let n = e[t];
      return eW(n) ? r : eR(n);
    }
    function tV(e, t) {
      return [
        {
          hours: tI(e, t, 0),
          minutes: tI(e, t + 1, 0),
          seconds: tI(e, t + 2, 0),
          milliseconds: eP(e[t + 3]),
        },
        null,
        t + 4,
      ];
    }
    function tE(e, t) {
      let r = !e[t] && !e[t + 1],
        n = e3(e[t + 1], e[t + 2]);
      return [{}, r ? null : ei.instance(n), t + 3];
    }
    function tx(e, t) {
      return [{}, e[t] ? j.create(e[t]) : null, t + 1];
    }
    let tF = RegExp(`^T?${tT.source}$`),
      tC =
        /^-?P(?:(?:(-?\d{1,20}(?:\.\d{1,20})?)Y)?(?:(-?\d{1,20}(?:\.\d{1,20})?)M)?(?:(-?\d{1,20}(?:\.\d{1,20})?)W)?(?:(-?\d{1,20}(?:\.\d{1,20})?)D)?(?:T(?:(-?\d{1,20}(?:\.\d{1,20})?)H)?(?:(-?\d{1,20}(?:\.\d{1,20})?)M)?(?:(-?\d{1,20})(?:[.,](-?\d{1,20}))?S)?)?)$/;
    function t$(e) {
      let [t, r, n, i, s, a, l, o, u] = e,
        h = "-" === t[0],
        c = o && "-" === o[0],
        d = function (e) {
          let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          return void 0 !== e && (t || (e && h)) ? -e : e;
        };
      return [
        {
          years: d(eH(r)),
          months: d(eH(n)),
          weeks: d(eH(i)),
          days: d(eH(s)),
          hours: d(eH(a)),
          minutes: d(eH(l)),
          seconds: d(eH(o), "-0" === o),
          milliseconds: d(eP(u), c),
        },
      ];
    }
    let tW = {
      GMT: 0,
      EDT: -240,
      EST: -300,
      CDT: -300,
      CST: -360,
      MDT: -360,
      MST: -420,
      PDT: -420,
      PST: -480,
    };
    function tZ(e, t, r, n, i, s, a) {
      let l = {
        year: 2 === t.length ? e1(eR(t)) : eR(t),
        month: e8.indexOf(r) + 1,
        day: eR(n),
        hour: eR(i),
        minute: eR(s),
      };
      return (
        a && (l.second = eR(a)),
        e && (l.weekday = e.length > 3 ? tr.indexOf(e) + 1 : tn.indexOf(e) + 1),
        l
      );
    }
    let tL =
      /^(?:(Mon|Tue|Wed|Thu|Fri|Sat|Sun),\s)?(\d{1,2})\s(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s(\d{2,4})\s(\d\d):(\d\d)(?::(\d\d))?\s(?:(UT|GMT|[ECMP][SD]T)|([Zz])|(?:([+-]\d\d)(\d\d)))$/;
    function tz(e) {
      let [, t, r, n, i, s, a, l, o, u, h, c] = e;
      return [tZ(t, i, n, r, s, a, l), new ei(o ? tW[o] : u ? 0 : e3(h, c))];
    }
    let tA =
        /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun), (\d\d) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) (\d{4}) (\d\d):(\d\d):(\d\d) GMT$/,
      tq =
        /^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday), (\d\d)-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-(\d\d) (\d\d):(\d\d):(\d\d) GMT$/,
      tj =
        /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) ( \d|\d\d) (\d\d):(\d\d):(\d\d) (\d{4})$/;
    function tU(e) {
      let [, t, r, n, i, s, a, l] = e;
      return [tZ(t, i, n, r, s, a, l), ei.utcInstance];
    }
    function t_(e) {
      let [, t, r, n, i, s, a, l] = e;
      return [tZ(t, l, r, n, i, s, a), ei.utcInstance];
    }
    let tY = ty(/([+-]\d{6}|\d{4})(?:-?(\d\d)(?:-?(\d\d))?)?/, tO),
      tR = ty(/(\d{4})-?W(\d\d)(?:-?(\d))?/, tO),
      tH = ty(/(\d{4})-?(\d{3})/, tO),
      tP = ty(tS),
      tJ = tg(
        function (e, t) {
          return [{ year: tI(e, t), month: tI(e, t + 1, 1), day: tI(e, t + 2, 1) }, null, t + 3];
        },
        tV,
        tE,
        tx,
      ),
      tG = tg(tN, tV, tE, tx),
      tB = tg(tb, tV, tE, tx),
      tQ = tg(tV, tE, tx),
      tK = tg(tV),
      tX = ty(/(\d{4})-(\d\d)-(\d\d)/, tD),
      t0 = ty(tM),
      t1 = tg(tV, tE, tx),
      t2 = "Invalid Duration",
      t3 = {
        weeks: { days: 7, hours: 168, minutes: 10080, seconds: 604800, milliseconds: 6048e5 },
        days: { hours: 24, minutes: 1440, seconds: 86400, milliseconds: 864e5 },
        hours: { minutes: 60, seconds: 3600, milliseconds: 36e5 },
        minutes: { seconds: 60, milliseconds: 6e4 },
        seconds: { milliseconds: 1e3 },
      },
      t4 = {
        years: {
          quarters: 4,
          months: 12,
          weeks: 52,
          days: 365,
          hours: 8760,
          minutes: 525600,
          seconds: 31536e3,
          milliseconds: 31536e6,
        },
        quarters: {
          months: 3,
          weeks: 13,
          days: 91,
          hours: 2184,
          minutes: 131040,
          seconds: 7862400,
          milliseconds: 78624e5,
        },
        months: { weeks: 4, days: 30, hours: 720, minutes: 43200, seconds: 2592e3, milliseconds: 2592e6 },
        ...t3,
      },
      t6 = {
        years: {
          quarters: 4,
          months: 12,
          weeks: 52.1775,
          days: 365.2425,
          hours: 8765.82,
          minutes: 525949.2,
          seconds: 0x1e18558,
          milliseconds: 31556952e3,
        },
        quarters: {
          months: 3,
          weeks: 13.044375,
          days: 91.310625,
          hours: 2191.455,
          minutes: 131487.3,
          seconds: 7889238,
          milliseconds: 7889238e3,
        },
        months: {
          weeks: 30.436875 / 7,
          days: 30.436875,
          hours: 730.485,
          minutes: 43829.1,
          seconds: 2629746,
          milliseconds: 2629746e3,
        },
        ...t3,
      },
      t5 = ["years", "quarters", "months", "weeks", "days", "hours", "minutes", "seconds", "milliseconds"],
      t7 = t5.slice(0).reverse();
    function t9(e, t) {
      let r = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
      return new rr({
        values: r ? t.values : { ...e.values, ...(t.values || {}) },
        loc: e.loc.clone(t.loc),
        conversionAccuracy: t.conversionAccuracy || e.conversionAccuracy,
        matrix: t.matrix || e.matrix,
      });
    }
    function t8(e, t) {
      let r = t.milliseconds ?? 0;
      for (let n of t7.slice(1)) t[n] && (r += t[n] * e[n].milliseconds);
      return r;
    }
    function re(e, t) {
      let r = 0 > t8(e, t) ? -1 : 1;
      (t5.reduceRight((n, i) => {
        if (eW(t[i])) return n;
        if (n) {
          let s = t[n] * r,
            a = e[i][n],
            l = Math.floor(s / a);
          ((t[i] += l * r), (t[n] -= l * a * r));
        }
        return i;
      }, null),
        t5.reduce((r, n) => {
          if (eW(t[n])) return r;
          if (r) {
            let i = t[r] % 1;
            ((t[r] -= i), (t[n] += i * e[r][n]));
          }
          return n;
        }, null));
    }
    function rt(e) {
      let t = {};
      for (let [r, n] of Object.entries(e)) 0 !== n && (t[r] = n);
      return t;
    }
    class rr {
      constructor(e) {
        const t = "longterm" === e.conversionAccuracy;
        let r = t ? t6 : t4;
        (e.matrix && (r = e.matrix),
          (this.values = e.values),
          (this.loc = e.loc || er.create()),
          (this.conversionAccuracy = t ? "longterm" : "casual"),
          (this.invalid = e.invalid || null),
          (this.matrix = r),
          (this.isLuxonDuration = !0));
      }
      static fromMillis(e, t) {
        return rr.fromObject({ milliseconds: e }, t);
      }
      static fromObject(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        if (null == e || "object" != typeof e)
          throw new o(
            `Duration.fromObject: argument expected to be an object, got ${null === e ? "null" : typeof e}`,
          );
        return new rr({
          values: e6(e, rr.normalizeUnit),
          loc: er.fromObject(t),
          conversionAccuracy: t.conversionAccuracy,
          matrix: t.matrix,
        });
      }
      static fromDurationLike(e) {
        if (eZ(e)) return rr.fromMillis(e);
        if (rr.isDuration(e)) return e;
        if ("object" == typeof e) return rr.fromObject(e);
        throw new o(`Unknown duration argument ${e} of type ${typeof e}`);
      }
      static fromISO(e, t) {
        let [r] = tw(e, [tC, t$]);
        return r
          ? rr.fromObject(r, t)
          : rr.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`);
      }
      static fromISOTime(e, t) {
        let [r] = tw(e, [tF, tK]);
        return r
          ? rr.fromObject(r, t)
          : rr.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`);
      }
      static invalid(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        if (!e) throw new o("need to specify a reason the Duration is invalid");
        let r = e instanceof eT ? e : new eT(e, t);
        if (!ek.throwOnInvalid) return new rr({ invalid: r });
        throw new s(r);
      }
      static normalizeUnit(e) {
        let t = {
          year: "years",
          years: "years",
          quarter: "quarters",
          quarters: "quarters",
          month: "months",
          months: "months",
          week: "weeks",
          weeks: "weeks",
          day: "days",
          days: "days",
          hour: "hours",
          hours: "hours",
          minute: "minutes",
          minutes: "minutes",
          second: "seconds",
          seconds: "seconds",
          millisecond: "milliseconds",
          milliseconds: "milliseconds",
        }[e ? e.toLowerCase() : e];
        if (!t) throw new l(e);
        return t;
      }
      static isDuration(e) {
        return (e && e.isLuxonDuration) || !1;
      }
      get locale() {
        return this.isValid ? this.loc.locale : null;
      }
      get numberingSystem() {
        return this.isValid ? this.loc.numberingSystem : null;
      }
      toFormat(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          r = { ...t, floor: !1 !== t.round && !1 !== t.floor };
        return this.isValid ? tm.create(this.loc, r).formatDurationFromString(this, e) : t2;
      }
      toHuman() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        if (!this.isValid) return t2;
        let t = !1 !== e.showZeros,
          r = t5
            .map((r) => {
              let n = this.values[r];
              return eW(n) || (0 === n && !t)
                ? null
                : this.loc
                    .numberFormatter({ style: "unit", unitDisplay: "long", ...e, unit: r.slice(0, -1) })
                    .format(n);
            })
            .filter((e) => e);
        return this.loc
          .listFormatter({ type: "conjunction", style: e.listStyle || "narrow", ...e })
          .format(r);
      }
      toObject() {
        return this.isValid ? { ...this.values } : {};
      }
      toISO() {
        if (!this.isValid) return null;
        let e = "P";
        return (
          0 !== this.years && (e += this.years + "Y"),
          (0 !== this.months || 0 !== this.quarters) && (e += this.months + 3 * this.quarters + "M"),
          0 !== this.weeks && (e += this.weeks + "W"),
          0 !== this.days && (e += this.days + "D"),
          (0 !== this.hours || 0 !== this.minutes || 0 !== this.seconds || 0 !== this.milliseconds) &&
            (e += "T"),
          0 !== this.hours && (e += this.hours + "H"),
          0 !== this.minutes && (e += this.minutes + "M"),
          (0 !== this.seconds || 0 !== this.milliseconds) &&
            (e += eJ(this.seconds + this.milliseconds / 1e3, 3) + "S"),
          "P" === e && (e += "T0S"),
          e
        );
      }
      toISOTime() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        if (!this.isValid) return null;
        let t = this.toMillis();
        return t < 0 || t >= 864e5
          ? null
          : ((e = {
              suppressMilliseconds: !1,
              suppressSeconds: !1,
              includePrefix: !1,
              format: "extended",
              ...e,
              includeOffset: !1,
            }),
            rH.fromMillis(t, { zone: "UTC" }).toISOTime(e));
      }
      toJSON() {
        return this.toISO();
      }
      toString() {
        return this.toISO();
      }
      [Symbol.for("nodejs.util.inspect.custom")]() {
        return this.isValid
          ? `Duration { values: ${JSON.stringify(this.values)} }`
          : `Duration { Invalid, reason: ${this.invalidReason} }`;
      }
      toMillis() {
        return this.isValid ? t8(this.matrix, this.values) : NaN;
      }
      valueOf() {
        return this.toMillis();
      }
      plus(e) {
        if (!this.isValid) return this;
        let t = rr.fromDurationLike(e),
          r = {};
        for (let e of t5) (ej(t.values, e) || ej(this.values, e)) && (r[e] = t.get(e) + this.get(e));
        return t9(this, { values: r }, !0);
      }
      minus(e) {
        if (!this.isValid) return this;
        let t = rr.fromDurationLike(e);
        return this.plus(t.negate());
      }
      mapUnits(e) {
        if (!this.isValid) return this;
        let t = {};
        for (let r of Object.keys(this.values)) t[r] = e4(e(this.values[r], r));
        return t9(this, { values: t }, !0);
      }
      get(e) {
        return this[rr.normalizeUnit(e)];
      }
      set(e) {
        return this.isValid ? t9(this, { values: { ...this.values, ...e6(e, rr.normalizeUnit) } }) : this;
      }
      reconfigure() {
        let {
          locale: e,
          numberingSystem: t,
          conversionAccuracy: r,
          matrix: n,
        } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return t9(this, {
          loc: this.loc.clone({ locale: e, numberingSystem: t }),
          matrix: n,
          conversionAccuracy: r,
        });
      }
      as(e) {
        return this.isValid ? this.shiftTo(e).get(e) : NaN;
      }
      normalize() {
        if (!this.isValid) return this;
        let e = this.toObject();
        return (re(this.matrix, e), t9(this, { values: e }, !0));
      }
      rescale() {
        return this.isValid ? t9(this, { values: rt(this.normalize().shiftToAll().toObject()) }, !0) : this;
      }
      shiftTo() {
        let e;
        for (var t = arguments.length, r = Array(t), n = 0; n < t; n++) r[n] = arguments[n];
        if (!this.isValid || 0 === r.length) return this;
        r = r.map((e) => rr.normalizeUnit(e));
        let i = {},
          s = {},
          a = this.toObject();
        for (let t of t5)
          if (r.indexOf(t) >= 0) {
            e = t;
            let r = 0;
            for (let e in s) ((r += this.matrix[e][t] * s[e]), (s[e] = 0));
            eZ(a[t]) && (r += a[t]);
            let n = Math.trunc(r);
            ((i[t] = n), (s[t] = (1e3 * r - 1e3 * n) / 1e3));
          } else eZ(a[t]) && (s[t] = a[t]);
        for (let t in s) 0 !== s[t] && (i[e] += t === e ? s[t] : s[t] / this.matrix[e][t]);
        return (re(this.matrix, i), t9(this, { values: i }, !0));
      }
      shiftToAll() {
        return this.isValid
          ? this.shiftTo("years", "months", "weeks", "days", "hours", "minutes", "seconds", "milliseconds")
          : this;
      }
      negate() {
        if (!this.isValid) return this;
        let e = {};
        for (let t of Object.keys(this.values)) e[t] = 0 === this.values[t] ? 0 : -this.values[t];
        return t9(this, { values: e }, !0);
      }
      removeZeros() {
        return this.isValid ? t9(this, { values: rt(this.values) }, !0) : this;
      }
      get years() {
        return this.isValid ? this.values.years || 0 : NaN;
      }
      get quarters() {
        return this.isValid ? this.values.quarters || 0 : NaN;
      }
      get months() {
        return this.isValid ? this.values.months || 0 : NaN;
      }
      get weeks() {
        return this.isValid ? this.values.weeks || 0 : NaN;
      }
      get days() {
        return this.isValid ? this.values.days || 0 : NaN;
      }
      get hours() {
        return this.isValid ? this.values.hours || 0 : NaN;
      }
      get minutes() {
        return this.isValid ? this.values.minutes || 0 : NaN;
      }
      get seconds() {
        return this.isValid ? this.values.seconds || 0 : NaN;
      }
      get milliseconds() {
        return this.isValid ? this.values.milliseconds || 0 : NaN;
      }
      get isValid() {
        return null === this.invalid;
      }
      get invalidReason() {
        return this.invalid ? this.invalid.reason : null;
      }
      get invalidExplanation() {
        return this.invalid ? this.invalid.explanation : null;
      }
      equals(e) {
        if (!this.isValid || !e.isValid || !this.loc.equals(e.loc)) return !1;
        for (let n of t5) {
          var t, r;
          if (
            ((t = this.values[n]),
            (r = e.values[n]),
            void 0 === t || 0 === t ? void 0 !== r && 0 !== r : t !== r)
          )
            return !1;
        }
        return !0;
      }
    }
    let rn = "Invalid Interval";
    class ri {
      constructor(e) {
        ((this.s = e.start),
          (this.e = e.end),
          (this.invalid = e.invalid || null),
          (this.isLuxonInterval = !0));
      }
      static invalid(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        if (!e) throw new o("need to specify a reason the Interval is invalid");
        let r = e instanceof eT ? e : new eT(e, t);
        if (!ek.throwOnInvalid) return new ri({ invalid: r });
        throw new i(r);
      }
      static fromDateTimes(e, t) {
        var r, n;
        let i = rP(e),
          s = rP(t),
          a =
            ((r = i),
            (n = s),
            r && r.isValid
              ? n && n.isValid
                ? n < r
                  ? ri.invalid(
                      "end before start",
                      `The end of an interval must be after its start, but you had start=${r.toISO()} and end=${n.toISO()}`,
                    )
                  : null
                : ri.invalid("missing or invalid end")
              : ri.invalid("missing or invalid start"));
        return null == a ? new ri({ start: i, end: s }) : a;
      }
      static after(e, t) {
        let r = rr.fromDurationLike(t),
          n = rP(e);
        return ri.fromDateTimes(n, n.plus(r));
      }
      static before(e, t) {
        let r = rr.fromDurationLike(t),
          n = rP(e);
        return ri.fromDateTimes(n.minus(r), n);
      }
      static fromISO(e, t) {
        let [r, n] = (e || "").split("/", 2);
        if (r && n) {
          let e, i, s, a;
          try {
            i = (e = rH.fromISO(r, t)).isValid;
          } catch (e) {
            i = !1;
          }
          try {
            a = (s = rH.fromISO(n, t)).isValid;
          } catch (e) {
            a = !1;
          }
          if (i && a) return ri.fromDateTimes(e, s);
          if (i) {
            let r = rr.fromISO(n, t);
            if (r.isValid) return ri.after(e, r);
          } else if (a) {
            let e = rr.fromISO(r, t);
            if (e.isValid) return ri.before(s, e);
          }
        }
        return ri.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`);
      }
      static isInterval(e) {
        return (e && e.isLuxonInterval) || !1;
      }
      get start() {
        return this.isValid ? this.s : null;
      }
      get end() {
        return this.isValid ? this.e : null;
      }
      get lastDateTime() {
        return this.isValid && this.e ? this.e.minus(1) : null;
      }
      get isValid() {
        return null === this.invalidReason;
      }
      get invalidReason() {
        return this.invalid ? this.invalid.reason : null;
      }
      get invalidExplanation() {
        return this.invalid ? this.invalid.explanation : null;
      }
      length() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "milliseconds";
        return this.isValid ? this.toDuration(e).get(e) : NaN;
      }
      count() {
        let e,
          t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "milliseconds",
          r = arguments.length > 1 ? arguments[1] : void 0;
        if (!this.isValid) return NaN;
        let n = this.start.startOf(t, r);
        return (
          Math.floor(
            (e = (e = r?.useLocaleWeeks ? this.end.reconfigure({ locale: n.locale }) : this.end).startOf(
              t,
              r,
            ))
              .diff(n, t)
              .get(t),
          ) +
          (e.valueOf() !== this.end.valueOf())
        );
      }
      hasSame(e) {
        return !!this.isValid && (this.isEmpty() || this.e.minus(1).hasSame(this.s, e));
      }
      isEmpty() {
        return this.s.valueOf() === this.e.valueOf();
      }
      isAfter(e) {
        return !!this.isValid && this.s > e;
      }
      isBefore(e) {
        return !!this.isValid && this.e <= e;
      }
      contains(e) {
        return !!this.isValid && this.s <= e && this.e > e;
      }
      set() {
        let { start: e, end: t } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return this.isValid ? ri.fromDateTimes(e || this.s, t || this.e) : this;
      }
      splitAt() {
        for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
        if (!this.isValid) return [];
        let n = t
            .map(rP)
            .filter((e) => this.contains(e))
            .sort((e, t) => e.toMillis() - t.toMillis()),
          i = [],
          { s } = this,
          a = 0;
        for (; s < this.e;) {
          let e = n[a] || this.e,
            t = +e > +this.e ? this.e : e;
          (i.push(ri.fromDateTimes(s, t)), (s = t), (a += 1));
        }
        return i;
      }
      splitBy(e) {
        let t = rr.fromDurationLike(e);
        if (!this.isValid || !t.isValid || 0 === t.as("milliseconds")) return [];
        let { s: r } = this,
          n = 1,
          i,
          s = [];
        for (; r < this.e;) {
          let e = this.start.plus(t.mapUnits((e) => e * n));
          ((i = +e > +this.e ? this.e : e), s.push(ri.fromDateTimes(r, i)), (r = i), (n += 1));
        }
        return s;
      }
      divideEqually(e) {
        return this.isValid ? this.splitBy(this.length() / e).slice(0, e) : [];
      }
      overlaps(e) {
        return this.e > e.s && this.s < e.e;
      }
      abutsStart(e) {
        return !!this.isValid && +this.e == +e.s;
      }
      abutsEnd(e) {
        return !!this.isValid && +e.e == +this.s;
      }
      engulfs(e) {
        return !!this.isValid && this.s <= e.s && this.e >= e.e;
      }
      equals(e) {
        return !!this.isValid && !!e.isValid && this.s.equals(e.s) && this.e.equals(e.e);
      }
      intersection(e) {
        if (!this.isValid) return this;
        let t = this.s > e.s ? this.s : e.s,
          r = this.e < e.e ? this.e : e.e;
        return t >= r ? null : ri.fromDateTimes(t, r);
      }
      union(e) {
        if (!this.isValid) return this;
        let t = this.s < e.s ? this.s : e.s,
          r = this.e > e.e ? this.e : e.e;
        return ri.fromDateTimes(t, r);
      }
      static merge(e) {
        let [t, r] = e
          .sort((e, t) => e.s - t.s)
          .reduce(
            (e, t) => {
              let [r, n] = e;
              return n ? (n.overlaps(t) || n.abutsStart(t) ? [r, n.union(t)] : [r.concat([n]), t]) : [r, t];
            },
            [[], null],
          );
        return (r && t.push(r), t);
      }
      static xor(e) {
        let t = null,
          r = 0,
          n = [],
          i = e.map((e) => [
            { time: e.s, type: "s" },
            { time: e.e, type: "e" },
          ]);
        for (let e of Array.prototype.concat(...i).sort((e, t) => e.time - t.time))
          1 === (r += "s" === e.type ? 1 : -1)
            ? (t = e.time)
            : (t && +t != +e.time && n.push(ri.fromDateTimes(t, e.time)), (t = null));
        return ri.merge(n);
      }
      difference() {
        for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
        return ri
          .xor([this].concat(t))
          .map((e) => this.intersection(e))
          .filter((e) => e && !e.isEmpty());
      }
      toString() {
        return this.isValid ? `[${this.s.toISO()} – ${this.e.toISO()})` : rn;
      }
      [Symbol.for("nodejs.util.inspect.custom")]() {
        return this.isValid
          ? `Interval { start: ${this.s.toISO()}, end: ${this.e.toISO()} }`
          : `Interval { Invalid, reason: ${this.invalidReason} }`;
      }
      toLocaleString() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : m,
          t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return this.isValid ? tm.create(this.s.loc.clone(t), e).formatInterval(this) : rn;
      }
      toISO(e) {
        return this.isValid ? `${this.s.toISO(e)}/${this.e.toISO(e)}` : rn;
      }
      toISODate() {
        return this.isValid ? `${this.s.toISODate()}/${this.e.toISODate()}` : rn;
      }
      toISOTime(e) {
        return this.isValid ? `${this.s.toISOTime(e)}/${this.e.toISOTime(e)}` : rn;
      }
      toFormat(e) {
        let { separator: t = " – " } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return this.isValid ? `${this.s.toFormat(e)}${t}${this.e.toFormat(e)}` : rn;
      }
      toDuration(e, t) {
        return this.isValid ? this.e.diff(this.s, e, t) : rr.invalid(this.invalidReason);
      }
      mapEndpoints(e) {
        return ri.fromDateTimes(e(this.s), e(this.e));
      }
    }
    class rs {
      static hasDST() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : ek.defaultZone,
          t = rH.now().setZone(e).set({ month: 12 });
        return !e.isUniversal && t.offset !== t.set({ month: 6 }).offset;
      }
      static isValidIANAZone(e) {
        return j.isValidZone(e);
      }
      static normalizeZone(e) {
        return ea(e, ek.defaultZone);
      }
      static getStartOfWeek() {
        let { locale: e = null, locObj: t = null } =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (t || er.create(e)).getStartOfWeek();
      }
      static getMinimumDaysInFirstWeek() {
        let { locale: e = null, locObj: t = null } =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (t || er.create(e)).getMinDaysInFirstWeek();
      }
      static getWeekendWeekdays() {
        let { locale: e = null, locObj: t = null } =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (t || er.create(e)).getWeekendDays().slice();
      }
      static months() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "long",
          {
            locale: t = null,
            numberingSystem: r = null,
            locObj: n = null,
            outputCalendar: i = "gregory",
          } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (n || er.create(t, r, i)).months(e);
      }
      static monthsFormat() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "long",
          {
            locale: t = null,
            numberingSystem: r = null,
            locObj: n = null,
            outputCalendar: i = "gregory",
          } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (n || er.create(t, r, i)).months(e, !0);
      }
      static weekdays() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "long",
          {
            locale: t = null,
            numberingSystem: r = null,
            locObj: n = null,
          } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (n || er.create(t, r, null)).weekdays(e);
      }
      static weekdaysFormat() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "long",
          {
            locale: t = null,
            numberingSystem: r = null,
            locObj: n = null,
          } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (n || er.create(t, r, null)).weekdays(e, !0);
      }
      static meridiems() {
        let { locale: e = null } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return er.create(e).meridiems();
      }
      static eras() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "short",
          { locale: t = null } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return er.create(t, null, "gregory").eras(e);
      }
      static features() {
        return { relative: ez(), localeWeek: eA() };
      }
    }
    function ra(e, t) {
      let r = (e) => e.toUTC(0, { keepLocalTime: !0 }).startOf("day").valueOf(),
        n = r(t) - r(e);
      return Math.floor(rr.fromMillis(n).as("days"));
    }
    function rl(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : (e) => e;
      return {
        regex: e,
        deser: (e) => {
          let [r] = e;
          return t(
            (function (e) {
              let t = parseInt(e, 10);
              if (!isNaN(t)) return t;
              t = "";
              for (let r = 0; r < e.length; r++) {
                let n = e.charCodeAt(r);
                if (-1 !== e[r].search(el.hanidec)) t += eu.indexOf(e[r]);
                else
                  for (let e in eo) {
                    let [r, i] = eo[e];
                    n >= r && n <= i && (t += n - r);
                  }
              }
              return parseInt(t, 10);
            })(r),
          );
        },
      };
    }
    let ro = String.fromCharCode(160),
      ru = `[ ${ro}]`,
      rh = RegExp(ru, "g");
    function rc(e) {
      return e.replace(/\./g, "\\.?").replace(rh, ru);
    }
    function rd(e) {
      return e.replace(/\./g, "").replace(rh, " ").toLowerCase();
    }
    function rm(e, t) {
      return null === e
        ? null
        : {
            regex: RegExp(e.map(rc).join("|")),
            deser: (r) => {
              let [n] = r;
              return e.findIndex((e) => rd(n) === rd(e)) + t;
            },
          };
    }
    function rf(e, t) {
      return {
        regex: e,
        deser: (e) => {
          let [, t, r] = e;
          return e3(t, r);
        },
        groups: t,
      };
    }
    function ry(e) {
      return {
        regex: e,
        deser: (e) => {
          let [t] = e;
          return t;
        },
      };
    }
    let rg = {
        year: { "2-digit": "yy", numeric: "yyyyy" },
        month: { numeric: "M", "2-digit": "MM", short: "MMM", long: "MMMM" },
        day: { numeric: "d", "2-digit": "dd" },
        weekday: { short: "EEE", long: "EEEE" },
        dayperiod: "a",
        dayPeriod: "a",
        hour12: { numeric: "h", "2-digit": "hh" },
        hour24: { numeric: "H", "2-digit": "HH" },
        minute: { numeric: "m", "2-digit": "mm" },
        second: { numeric: "s", "2-digit": "ss" },
        timeZoneName: { long: "ZZZZZ", short: "ZZZ" },
      },
      rw = null;
    function rv(e, t) {
      return Array.prototype.concat(
        ...e.map((e) =>
          (function (e, t) {
            if (e.literal) return e;
            let r = rT(tm.macroTokenToFormatOpts(e.val), t);
            return null == r || r.includes(void 0) ? e : r;
          })(e, t),
        ),
      );
    }
    class rp {
      constructor(e, t) {
        if (
          ((this.locale = e),
          (this.format = t),
          (this.tokens = rv(tm.parseFormat(t), e)),
          (this.units = this.tokens.map((t) => {
            let r, n, i, s, a, l, o, u, h, c, d, m, f;
            return (
              (r = ec(e)),
              (n = ec(e, "{2}")),
              (i = ec(e, "{3}")),
              (s = ec(e, "{4}")),
              (a = ec(e, "{6}")),
              (l = ec(e, "{1,2}")),
              (o = ec(e, "{1,3}")),
              (u = ec(e, "{1,6}")),
              (h = ec(e, "{1,9}")),
              (c = ec(e, "{2,4}")),
              (d = ec(e, "{4,6}")),
              (m = (e) => ({
                regex: RegExp(e.val.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&")),
                deser: (e) => {
                  let [t] = e;
                  return t;
                },
                literal: !0,
              })),
              ((f = ((f) => {
                if (t.literal) return m(f);
                switch (f.val) {
                  case "G":
                    return rm(e.eras("short"), 0);
                  case "GG":
                    return rm(e.eras("long"), 0);
                  case "y":
                    return rl(u);
                  case "yy":
                  case "kk":
                    return rl(c, e1);
                  case "yyyy":
                  case "kkkk":
                    return rl(s);
                  case "yyyyy":
                    return rl(d);
                  case "yyyyyy":
                    return rl(a);
                  case "M":
                  case "L":
                  case "d":
                  case "H":
                  case "h":
                  case "m":
                  case "q":
                  case "s":
                  case "W":
                    return rl(l);
                  case "MM":
                  case "LL":
                  case "dd":
                  case "HH":
                  case "hh":
                  case "mm":
                  case "qq":
                  case "ss":
                  case "WW":
                    return rl(n);
                  case "MMM":
                    return rm(e.months("short", !0), 1);
                  case "MMMM":
                    return rm(e.months("long", !0), 1);
                  case "LLL":
                    return rm(e.months("short", !1), 1);
                  case "LLLL":
                    return rm(e.months("long", !1), 1);
                  case "o":
                  case "S":
                    return rl(o);
                  case "ooo":
                  case "SSS":
                    return rl(i);
                  case "u":
                    return ry(h);
                  case "uu":
                    return ry(l);
                  case "uuu":
                  case "E":
                  case "c":
                    return rl(r);
                  case "a":
                    return rm(e.meridiems(), 0);
                  case "EEE":
                    return rm(e.weekdays("short", !1), 1);
                  case "EEEE":
                    return rm(e.weekdays("long", !1), 1);
                  case "ccc":
                    return rm(e.weekdays("short", !0), 1);
                  case "cccc":
                    return rm(e.weekdays("long", !0), 1);
                  case "Z":
                  case "ZZ":
                    return rf(RegExp(`([+-]${l.source})(?::(${n.source}))?`), 2);
                  case "ZZZ":
                    return rf(RegExp(`([+-]${l.source})(${n.source})?`), 2);
                  case "z":
                    return ry(/[a-z_+-/]{1,256}?/i);
                  case " ":
                    return ry(/[^\S\n\r]/);
                  default:
                    return m(f);
                }
              })(t) || { invalidReason: "missing Intl.DateTimeFormat.formatToParts support" }).token = t),
              f
            );
          })),
          (this.disqualifyingUnit = this.units.find((e) => e.invalidReason)),
          !this.disqualifyingUnit)
        ) {
          const [e, t] = (function (e) {
            let t = e.map((e) => e.regex).reduce((e, t) => `${e}(${t.source})`, "");
            return [`^${t}$`, e];
          })(this.units);
          ((this.regex = RegExp(e, "i")), (this.handlers = t));
        }
      }
      explainFromTokens(e) {
        if (!this.isValid) return { input: e, tokens: this.tokens, invalidReason: this.invalidReason };
        {
          let t,
            r,
            [n, i] = (function (e, t, r) {
              let n = e.match(t);
              if (!n) return [n, {}];
              {
                let e = {},
                  t = 1;
                for (let i in r)
                  if (ej(r, i)) {
                    let s = r[i],
                      a = s.groups ? s.groups + 1 : 1;
                    (!s.literal && s.token && (e[s.token.val[0]] = s.deser(n.slice(t, t + a))), (t += a));
                  }
                return [n, e];
              }
            })(e, this.regex, this.handlers),
            [s, l, o] = i
              ? ((r = null),
                eW(i.z) || (r = j.create(i.z)),
                eW(i.Z) || (r || (r = new ei(i.Z)), (t = i.Z)),
                eW(i.q) || (i.M = (i.q - 1) * 3 + 1),
                eW(i.h) || (i.h < 12 && 1 === i.a ? (i.h += 12) : 12 === i.h && 0 === i.a && (i.h = 0)),
                0 === i.G && i.y && (i.y = -i.y),
                eW(i.u) || (i.S = eP(i.u)),
                [
                  Object.keys(i).reduce((e, t) => {
                    let r = ((e) => {
                      switch (e) {
                        case "S":
                          return "millisecond";
                        case "s":
                          return "second";
                        case "m":
                          return "minute";
                        case "h":
                        case "H":
                          return "hour";
                        case "d":
                          return "day";
                        case "o":
                          return "ordinal";
                        case "L":
                        case "M":
                          return "month";
                        case "y":
                          return "year";
                        case "E":
                        case "c":
                          return "weekday";
                        case "W":
                          return "weekNumber";
                        case "k":
                          return "weekYear";
                        case "q":
                          return "quarter";
                        default:
                          return null;
                      }
                    })(t);
                    return (r && (e[r] = i[t]), e);
                  }, {}),
                  r,
                  t,
                ])
              : [null, null, void 0];
          if (ej(i, "a") && ej(i, "H")) throw new a("Can't include meridiem when specifying 24-hour format");
          return {
            input: e,
            tokens: this.tokens,
            regex: this.regex,
            rawMatches: n,
            matches: i,
            result: s,
            zone: l,
            specificOffset: o,
          };
        }
      }
      get isValid() {
        return !this.disqualifyingUnit;
      }
      get invalidReason() {
        return this.disqualifyingUnit ? this.disqualifyingUnit.invalidReason : null;
      }
    }
    function rk(e, t, r) {
      return new rp(e, r).explainFromTokens(t);
    }
    function rT(e, t) {
      if (!e) return null;
      let r = tm.create(t, e).dtFormatter((rw || (rw = rH.fromMillis(0x16a2e5618e3)), rw)),
        n = r.formatToParts(),
        i = r.resolvedOptions();
      return n.map((t) =>
        (function (e, t, r) {
          let { type: n, value: i } = e;
          if ("literal" === n) {
            let e = /^\s+$/.test(i);
            return { literal: !e, val: e ? " " : i };
          }
          let s = t[n],
            a = n;
          "hour" === n &&
            (a =
              null != t.hour12
                ? t.hour12
                  ? "hour12"
                  : "hour24"
                : null != t.hourCycle
                  ? "h11" === t.hourCycle || "h12" === t.hourCycle
                    ? "hour12"
                    : "hour24"
                  : r.hour12
                    ? "hour12"
                    : "hour24");
          let l = rg[a];
          if (("object" == typeof l && (l = l[s]), l)) return { literal: !1, val: l };
        })(t, e, i),
      );
    }
    let rS = "Invalid DateTime";
    function rO(e) {
      return new eT("unsupported zone", `the zone "${e.name}" is not supported`);
    }
    function rN(e) {
      return (null === e.weekData && (e.weekData = eI(e.c)), e.weekData);
    }
    function rb(e) {
      return (
        null === e.localWeekData &&
          (e.localWeekData = eI(e.c, e.loc.getMinDaysInFirstWeek(), e.loc.getStartOfWeek())),
        e.localWeekData
      );
    }
    function rM(e, t) {
      let r = { ts: e.ts, zone: e.zone, c: e.c, o: e.o, loc: e.loc, invalid: e.invalid };
      return new rH({ ...r, ...t, old: r });
    }
    function rD(e, t, r) {
      let n = e - 60 * t * 1e3,
        i = r.offset(n);
      if (t === i) return [n, t];
      n -= (i - t) * 6e4;
      let s = r.offset(n);
      return i === s ? [n, i] : [e - 60 * Math.min(i, s) * 1e3, Math.max(i, s)];
    }
    function rI(e, t) {
      let r = new Date((e += 60 * t * 1e3));
      return {
        year: r.getUTCFullYear(),
        month: r.getUTCMonth() + 1,
        day: r.getUTCDate(),
        hour: r.getUTCHours(),
        minute: r.getUTCMinutes(),
        second: r.getUTCSeconds(),
        millisecond: r.getUTCMilliseconds(),
      };
    }
    function rV(e, t) {
      let r = e.o,
        n = e.c.year + Math.trunc(t.years),
        i = e.c.month + Math.trunc(t.months) + 3 * Math.trunc(t.quarters),
        s = {
          ...e.c,
          year: n,
          month: i,
          day: Math.min(e.c.day, eQ(n, i)) + Math.trunc(t.days) + 7 * Math.trunc(t.weeks),
        },
        a = rr
          .fromObject({
            years: t.years - Math.trunc(t.years),
            quarters: t.quarters - Math.trunc(t.quarters),
            months: t.months - Math.trunc(t.months),
            weeks: t.weeks - Math.trunc(t.weeks),
            days: t.days - Math.trunc(t.days),
            hours: t.hours,
            minutes: t.minutes,
            seconds: t.seconds,
            milliseconds: t.milliseconds,
          })
          .as("milliseconds"),
        [l, o] = rD(eK(s), r, e.zone);
      return (0 !== a && ((l += a), (o = e.zone.offset(l))), { ts: l, o });
    }
    function rE(e, t, r, n, i, s) {
      let { setZone: a, zone: l } = r;
      if ((!e || 0 === Object.keys(e).length) && !t)
        return rH.invalid(new eT("unparsable", `the input "${i}" can't be parsed as ${n}`));
      {
        let n = rH.fromObject(e, { ...r, zone: t || l, specificOffset: s });
        return a ? n : n.setZone(l);
      }
    }
    function rx(e, t) {
      let r = !(arguments.length > 2) || void 0 === arguments[2] || arguments[2];
      return e.isValid
        ? tm.create(er.create("en-US"), { allowZ: r, forceSimple: !0 }).formatDateTimeFromString(e, t)
        : null;
    }
    function rF(e, t, r) {
      let n = e.c.year > 9999 || e.c.year < 0,
        i = "";
      if ((n && e.c.year >= 0 && (i += "+"), (i += eY(e.c.year, n ? 6 : 4)), "year" === r)) return i;
      if (t) {
        if (((i += "-"), (i += eY(e.c.month)), "month" === r)) return i;
        i += "-";
      } else if (((i += eY(e.c.month)), "month" === r)) return i;
      return i + eY(e.c.day);
    }
    function rC(e, t, r, n, i, s, a) {
      let l = !r || 0 !== e.c.millisecond || 0 !== e.c.second,
        o = "";
      switch (a) {
        case "day":
        case "month":
        case "year":
          break;
        default:
          if (((o += eY(e.c.hour)), "hour" === a)) break;
          if (t) {
            if (((o += ":"), (o += eY(e.c.minute)), "minute" === a)) break;
            l && ((o += ":"), (o += eY(e.c.second)));
          } else {
            if (((o += eY(e.c.minute)), "minute" === a)) break;
            l && (o += eY(e.c.second));
          }
          if ("second" === a) break;
          l && (!n || 0 !== e.c.millisecond) && ((o += "."), (o += eY(e.c.millisecond, 3)));
      }
      return (
        i &&
          (e.isOffsetFixed && 0 === e.offset && !s
            ? (o += "Z")
            : e.o < 0
              ? ((o += "-"), (o += eY(Math.trunc(-e.o / 60))), (o += ":"), (o += eY(Math.trunc(-e.o % 60))))
              : ((o += "+"), (o += eY(Math.trunc(e.o / 60))), (o += ":"), (o += eY(Math.trunc(e.o % 60))))),
        s && (o += "[" + e.zone.ianaName + "]"),
        o
      );
    }
    let r$ = { month: 1, day: 1, hour: 0, minute: 0, second: 0, millisecond: 0 },
      rW = { weekNumber: 1, weekday: 1, hour: 0, minute: 0, second: 0, millisecond: 0 },
      rZ = { ordinal: 1, hour: 0, minute: 0, second: 0, millisecond: 0 },
      rL = ["year", "month", "day", "hour", "minute", "second", "millisecond"],
      rz = ["weekYear", "weekNumber", "weekday", "hour", "minute", "second", "millisecond"],
      rA = ["year", "ordinal", "hour", "minute", "second", "millisecond"];
    function rq(e) {
      let t = {
        year: "year",
        years: "year",
        month: "month",
        months: "month",
        day: "day",
        days: "day",
        hour: "hour",
        hours: "hour",
        minute: "minute",
        minutes: "minute",
        quarter: "quarter",
        quarters: "quarter",
        second: "second",
        seconds: "second",
        millisecond: "millisecond",
        milliseconds: "millisecond",
        weekday: "weekday",
        weekdays: "weekday",
        weeknumber: "weekNumber",
        weeksnumber: "weekNumber",
        weeknumbers: "weekNumber",
        weekyear: "weekYear",
        weekyears: "weekYear",
        ordinal: "ordinal",
      }[e.toLowerCase()];
      if (!t) throw new l(e);
      return t;
    }
    function rj(e) {
      switch (e.toLowerCase()) {
        case "localweekday":
        case "localweekdays":
          return "localWeekday";
        case "localweeknumber":
        case "localweeknumbers":
          return "localWeekNumber";
        case "localweekyear":
        case "localweekyears":
          return "localWeekYear";
        default:
          return rq(e);
      }
    }
    function rU(e, r) {
      let n,
        i,
        s = ea(r.zone, ek.defaultZone);
      if (!s.isValid) return rH.invalid(rO(s));
      let a = er.fromObject(r);
      if (eW(e.year)) n = ek.now();
      else {
        for (let t of rL) eW(e[t]) && (e[t] = r$[t]);
        let r = eC(e) || e$(e);
        if (r) return rH.invalid(r);
        let a = (function (e) {
          if ((void 0 === t && (t = ek.now()), "iana" !== e.type)) return e.offset(t);
          let r = e.name,
            n = rR.get(r);
          return (void 0 === n && ((n = e.offset(t)), rR.set(r, n)), n);
        })(s);
        [n, i] = rD(eK(e), a, s);
      }
      return new rH({ ts: n, zone: s, loc: a, o: i });
    }
    function r_(e, t, r) {
      let n = !!eW(r.round) || r.round,
        i = eW(r.rounding) ? "trunc" : r.rounding,
        s = (e, s) => (
          (e = eJ(e, n || r.calendary ? 0 : 2, r.calendary ? "round" : i)),
          t.loc.clone(r).relFormatter(r).format(e, s)
        ),
        a = (n) =>
          r.calendary
            ? t.hasSame(e, n)
              ? 0
              : t.startOf(n).diff(e.startOf(n), n).get(n)
            : t.diff(e, n).get(n);
      if (r.unit) return s(a(r.unit), r.unit);
      for (let e of r.units) {
        let t = a(e);
        if (Math.abs(t) >= 1) return s(t, e);
      }
      return s(e > t ? -0 : 0, r.units[r.units.length - 1]);
    }
    function rY(e) {
      let t = {},
        r;
      return (
        e.length > 0 && "object" == typeof e[e.length - 1]
          ? ((t = e[e.length - 1]), (r = Array.from(e).slice(0, e.length - 1)))
          : (r = Array.from(e)),
        [t, r]
      );
    }
    let rR = new Map();
    class rH {
      constructor(e) {
        const t = e.zone || ek.defaultZone;
        let r =
          e.invalid || (Number.isNaN(e.ts) ? new eT("invalid input") : null) || (t.isValid ? null : rO(t));
        this.ts = eW(e.ts) ? ek.now() : e.ts;
        let n = null,
          i = null;
        if (!r)
          if (e.old && e.old.ts === this.ts && e.old.zone.equals(t)) [n, i] = [e.old.c, e.old.o];
          else {
            const s = eZ(e.o) && !e.old ? e.o : t.offset(this.ts);
            ((n = (r = Number.isNaN((n = rI(this.ts, s)).year) ? new eT("invalid input") : null) ? null : n),
              (i = r ? null : s));
          }
        ((this._zone = t),
          (this.loc = e.loc || er.create()),
          (this.invalid = r),
          (this.weekData = null),
          (this.localWeekData = null),
          (this.c = n),
          (this.o = i),
          (this.isLuxonDateTime = !0));
      }
      static now() {
        return new rH({});
      }
      static local() {
        let [e, t] = rY(arguments),
          [r, n, i, s, a, l, o] = t;
        return rU({ year: r, month: n, day: i, hour: s, minute: a, second: l, millisecond: o }, e);
      }
      static utc() {
        let [e, t] = rY(arguments),
          [r, n, i, s, a, l, o] = t;
        return (
          (e.zone = ei.utcInstance),
          rU({ year: r, month: n, day: i, hour: s, minute: a, second: l, millisecond: o }, e)
        );
      }
      static fromJSDate(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          r = "[object Date]" === Object.prototype.toString.call(e) ? e.valueOf() : NaN;
        if (Number.isNaN(r)) return rH.invalid("invalid input");
        let n = ea(t.zone, ek.defaultZone);
        return n.isValid ? new rH({ ts: r, zone: n, loc: er.fromObject(t) }) : rH.invalid(rO(n));
      }
      static fromMillis(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        if (eZ(e))
          if (e < -864e13 || e > 864e13) return rH.invalid("Timestamp out of range");
          else return new rH({ ts: e, zone: ea(t.zone, ek.defaultZone), loc: er.fromObject(t) });
        throw new o(`fromMillis requires a numerical input, but received a ${typeof e} with value ${e}`);
      }
      static fromSeconds(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        if (eZ(e)) return new rH({ ts: 1e3 * e, zone: ea(t.zone, ek.defaultZone), loc: er.fromObject(t) });
        throw new o("fromSeconds requires a numerical input");
      }
      static fromObject(e) {
        var t;
        let r,
          n,
          i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        e = e || {};
        let s = ea(i.zone, ek.defaultZone);
        if (!s.isValid) return rH.invalid(rO(s));
        let l = er.fromObject(i),
          o = e6(e, rj),
          { minDaysInFirstWeek: u, startOfWeek: h } = eF(o, l),
          c = ek.now(),
          d = eW(i.specificOffset) ? s.offset(c) : i.specificOffset,
          m = !eW(o.ordinal),
          f = !eW(o.year),
          y = !eW(o.month) || !eW(o.day),
          g = f || y,
          w = o.weekYear || o.weekNumber;
        if ((g || m) && w) throw new a("Can't mix weekYear/weekNumber units with year/month/day or ordinals");
        if (y && m) throw new a("Can't mix ordinal dates with month/day");
        let v = w || (o.weekday && !g),
          p,
          k,
          T = rI(c, d);
        v
          ? ((p = rz), (k = rW), (T = eI(T, u, h)))
          : m
            ? ((p = rA), (k = rZ), (T = eE(T)))
            : ((p = rL), (k = r$));
        let S = !1;
        for (let e of p) eW(o[e]) ? (S ? (o[e] = k[e]) : (o[e] = T[e])) : (S = !0);
        let O =
          (v
            ? (function (e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 4,
                  r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
                  n = eL(e.weekYear),
                  i = e_(e.weekNumber, 1, e0(e.weekYear, t, r)),
                  s = e_(e.weekday, 1, 7);
                return n
                  ? i
                    ? !s && eN("weekday", e.weekday)
                    : eN("week", e.weekNumber)
                  : eN("weekYear", e.weekYear);
              })(o, u, h)
            : m
              ? ((r = eL(o.year)),
                (n = e_(o.ordinal, 1, eB(o.year))),
                r ? !n && eN("ordinal", o.ordinal) : eN("year", o.year))
              : eC(o)) || e$(o);
        if (O) return rH.invalid(O);
        let [N, b] = ((t = v ? eV(o, u, h) : m ? ex(o) : o), rD(eK(t), d, s)),
          M = new rH({ ts: N, zone: s, o: b, loc: l });
        return o.weekday && g && e.weekday !== M.weekday
          ? rH.invalid(
              "mismatched weekday",
              `you can't specify both a weekday of ${o.weekday} and a date of ${M.toISO()}`,
            )
          : M.isValid
            ? M
            : rH.invalid(M.invalid);
      }
      static fromISO(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          [r, n] = tw(e, [tY, tJ], [tR, tG], [tH, tB], [tP, tQ]);
        return rE(r, n, t, "ISO 8601", e);
      }
      static fromRFC2822(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          [r, n] = tw(
            e
              .replace(/\([^()]*\)|[\n\t]/g, " ")
              .replace(/(\s\s+)/g, " ")
              .trim(),
            [tL, tz],
          );
        return rE(r, n, t, "RFC 2822", e);
      }
      static fromHTTP(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          [r, n] = tw(e, [tA, tU], [tq, tU], [tj, t_]);
        return rE(r, n, t, "HTTP", t);
      }
      static fromFormat(e, t) {
        let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        if (eW(e) || eW(t)) throw new o("fromFormat requires an input string and a format");
        let { locale: n = null, numberingSystem: i = null } = r,
          [s, a, l, u] = (function (e, t, r) {
            let { result: n, zone: i, specificOffset: s, invalidReason: a } = rk(e, t, r);
            return [n, i, s, a];
          })(er.fromOpts({ locale: n, numberingSystem: i, defaultToEN: !0 }), e, t);
        return u ? rH.invalid(u) : rE(s, a, r, `format ${t}`, e, l);
      }
      static fromString(e, t) {
        let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        return rH.fromFormat(e, t, r);
      }
      static fromSQL(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          [r, n] = tw(e, [tX, tJ], [t0, t1]);
        return rE(r, n, t, "SQL", e);
      }
      static invalid(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        if (!e) throw new o("need to specify a reason the DateTime is invalid");
        let r = e instanceof eT ? e : new eT(e, t);
        if (!ek.throwOnInvalid) return new rH({ invalid: r });
        throw new n(r);
      }
      static isDateTime(e) {
        return (e && e.isLuxonDateTime) || !1;
      }
      static parseFormatForOpts(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          r = rT(e, er.fromObject(t));
        return r ? r.map((e) => (e ? e.val : null)).join("") : null;
      }
      static expandFormat(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return rv(tm.parseFormat(e), er.fromObject(t))
          .map((e) => e.val)
          .join("");
      }
      static resetCache() {
        ((t = void 0), rR.clear());
      }
      get(e) {
        return this[e];
      }
      get isValid() {
        return null === this.invalid;
      }
      get invalidReason() {
        return this.invalid ? this.invalid.reason : null;
      }
      get invalidExplanation() {
        return this.invalid ? this.invalid.explanation : null;
      }
      get locale() {
        return this.isValid ? this.loc.locale : null;
      }
      get numberingSystem() {
        return this.isValid ? this.loc.numberingSystem : null;
      }
      get outputCalendar() {
        return this.isValid ? this.loc.outputCalendar : null;
      }
      get zone() {
        return this._zone;
      }
      get zoneName() {
        return this.isValid ? this.zone.name : null;
      }
      get year() {
        return this.isValid ? this.c.year : NaN;
      }
      get quarter() {
        return this.isValid ? Math.ceil(this.c.month / 3) : NaN;
      }
      get month() {
        return this.isValid ? this.c.month : NaN;
      }
      get day() {
        return this.isValid ? this.c.day : NaN;
      }
      get hour() {
        return this.isValid ? this.c.hour : NaN;
      }
      get minute() {
        return this.isValid ? this.c.minute : NaN;
      }
      get second() {
        return this.isValid ? this.c.second : NaN;
      }
      get millisecond() {
        return this.isValid ? this.c.millisecond : NaN;
      }
      get weekYear() {
        return this.isValid ? rN(this).weekYear : NaN;
      }
      get weekNumber() {
        return this.isValid ? rN(this).weekNumber : NaN;
      }
      get weekday() {
        return this.isValid ? rN(this).weekday : NaN;
      }
      get isWeekend() {
        return this.isValid && this.loc.getWeekendDays().includes(this.weekday);
      }
      get localWeekday() {
        return this.isValid ? rb(this).weekday : NaN;
      }
      get localWeekNumber() {
        return this.isValid ? rb(this).weekNumber : NaN;
      }
      get localWeekYear() {
        return this.isValid ? rb(this).weekYear : NaN;
      }
      get ordinal() {
        return this.isValid ? eE(this.c).ordinal : NaN;
      }
      get monthShort() {
        return this.isValid ? rs.months("short", { locObj: this.loc })[this.month - 1] : null;
      }
      get monthLong() {
        return this.isValid ? rs.months("long", { locObj: this.loc })[this.month - 1] : null;
      }
      get weekdayShort() {
        return this.isValid ? rs.weekdays("short", { locObj: this.loc })[this.weekday - 1] : null;
      }
      get weekdayLong() {
        return this.isValid ? rs.weekdays("long", { locObj: this.loc })[this.weekday - 1] : null;
      }
      get offset() {
        return this.isValid ? +this.o : NaN;
      }
      get offsetNameShort() {
        return this.isValid ? this.zone.offsetName(this.ts, { format: "short", locale: this.locale }) : null;
      }
      get offsetNameLong() {
        return this.isValid ? this.zone.offsetName(this.ts, { format: "long", locale: this.locale }) : null;
      }
      get isOffsetFixed() {
        return this.isValid ? this.zone.isUniversal : null;
      }
      get isInDST() {
        return (
          !this.isOffsetFixed &&
          (this.offset > this.set({ month: 1, day: 1 }).offset || this.offset > this.set({ month: 5 }).offset)
        );
      }
      getPossibleOffsets() {
        if (!this.isValid || this.isOffsetFixed) return [this];
        let e = eK(this.c),
          t = this.zone.offset(e - 864e5),
          r = this.zone.offset(e + 864e5),
          n = this.zone.offset(e - 6e4 * t),
          i = this.zone.offset(e - 6e4 * r);
        if (n === i) return [this];
        let s = e - 6e4 * n,
          a = e - 6e4 * i,
          l = rI(s, n),
          o = rI(a, i);
        return l.hour === o.hour &&
          l.minute === o.minute &&
          l.second === o.second &&
          l.millisecond === o.millisecond
          ? [rM(this, { ts: s }), rM(this, { ts: a })]
          : [this];
      }
      get isInLeapYear() {
        return eG(this.year);
      }
      get daysInMonth() {
        return eQ(this.year, this.month);
      }
      get daysInYear() {
        return this.isValid ? eB(this.year) : NaN;
      }
      get weeksInWeekYear() {
        return this.isValid ? e0(this.weekYear) : NaN;
      }
      get weeksInLocalWeekYear() {
        return this.isValid
          ? e0(this.localWeekYear, this.loc.getMinDaysInFirstWeek(), this.loc.getStartOfWeek())
          : NaN;
      }
      resolvedLocaleOptions() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          {
            locale: t,
            numberingSystem: r,
            calendar: n,
          } = tm.create(this.loc.clone(e), e).resolvedOptions(this);
        return { locale: t, numberingSystem: r, outputCalendar: n };
      }
      toUTC() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return this.setZone(ei.instance(e), t);
      }
      toLocal() {
        return this.setZone(ek.defaultZone);
      }
      setZone(e) {
        let { keepLocalTime: t = !1, keepCalendarTime: r = !1 } =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        if ((e = ea(e, ek.defaultZone)).equals(this.zone)) return this;
        {
          if (!e.isValid) return rH.invalid(rO(e));
          let i = this.ts;
          if (t || r) {
            var n;
            let t = e.offset(this.ts),
              r = this.toObject();
            [i] = ((n = e), rD(eK(r), t, n));
          }
          return rM(this, { ts: i, zone: e });
        }
      }
      reconfigure() {
        let {
          locale: e,
          numberingSystem: t,
          outputCalendar: r,
        } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return rM(this, { loc: this.loc.clone({ locale: e, numberingSystem: t, outputCalendar: r }) });
      }
      setLocale(e) {
        return this.reconfigure({ locale: e });
      }
      set(e) {
        var t, r, n;
        let i;
        if (!this.isValid) return this;
        let s = e6(e, rj),
          { minDaysInFirstWeek: l, startOfWeek: o } = eF(s, this.loc),
          u = !eW(s.weekYear) || !eW(s.weekNumber) || !eW(s.weekday),
          h = !eW(s.ordinal),
          c = !eW(s.year),
          d = !eW(s.month) || !eW(s.day),
          m = s.weekYear || s.weekNumber;
        if ((c || d || h) && m)
          throw new a("Can't mix weekYear/weekNumber units with year/month/day or ordinals");
        if (d && h) throw new a("Can't mix ordinal dates with month/day");
        u
          ? (i = eV({ ...eI(this.c, l, o), ...s }, l, o))
          : eW(s.ordinal)
            ? ((i = { ...this.toObject(), ...s }),
              eW(s.day) && (i.day = Math.min(eQ(i.year, i.month), i.day)))
            : (i = ex({ ...eE(this.c), ...s }));
        let [f, y] = ((t = i), (r = this.o), (n = this.zone), rD(eK(t), r, n));
        return rM(this, { ts: f, o: y });
      }
      plus(e) {
        return this.isValid ? rM(this, rV(this, rr.fromDurationLike(e))) : this;
      }
      minus(e) {
        return this.isValid ? rM(this, rV(this, rr.fromDurationLike(e).negate())) : this;
      }
      startOf(e) {
        let { useLocaleWeeks: t = !1 } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        if (!this.isValid) return this;
        let r = {},
          n = rr.normalizeUnit(e);
        switch (n) {
          case "years":
            r.month = 1;
          case "quarters":
          case "months":
            r.day = 1;
          case "weeks":
          case "days":
            r.hour = 0;
          case "hours":
            r.minute = 0;
          case "minutes":
            r.second = 0;
          case "seconds":
            r.millisecond = 0;
        }
        if ("weeks" === n)
          if (t) {
            let e = this.loc.getStartOfWeek(),
              { weekday: t } = this;
            (t < e && (r.weekNumber = this.weekNumber - 1), (r.weekday = e));
          } else r.weekday = 1;
        return ("quarters" === n && (r.month = (Math.ceil(this.month / 3) - 1) * 3 + 1), this.set(r));
      }
      endOf(e, t) {
        return this.isValid
          ? this.plus({ [e]: 1 })
              .startOf(e, t)
              .minus(1)
          : this;
      }
      toFormat(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return this.isValid ? tm.create(this.loc.redefaultToEN(t)).formatDateTimeFromString(this, e) : rS;
      }
      toLocaleString() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : m,
          t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return this.isValid ? tm.create(this.loc.clone(t), e).formatDateTime(this) : rS;
      }
      toLocaleParts() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return this.isValid ? tm.create(this.loc.clone(e), e).formatDateTimeParts(this) : [];
      }
      toISO() {
        let {
          format: e = "extended",
          suppressSeconds: t = !1,
          suppressMilliseconds: r = !1,
          includeOffset: n = !0,
          extendedZone: i = !1,
          precision: s = "milliseconds",
        } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        if (!this.isValid) return null;
        s = rq(s);
        let a = "extended" === e,
          l = rF(this, a, s);
        return (rL.indexOf(s) >= 3 && (l += "T"), (l += rC(this, a, t, r, n, i, s)));
      }
      toISODate() {
        let { format: e = "extended", precision: t = "day" } =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return this.isValid ? rF(this, "extended" === e, rq(t)) : null;
      }
      toISOWeekDate() {
        return rx(this, "kkkk-'W'WW-c");
      }
      toISOTime() {
        let {
          suppressMilliseconds: e = !1,
          suppressSeconds: t = !1,
          includeOffset: r = !0,
          includePrefix: n = !1,
          extendedZone: i = !1,
          format: s = "extended",
          precision: a = "milliseconds",
        } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return this.isValid
          ? ((a = rq(a)), (n && rL.indexOf(a) >= 3 ? "T" : "") + rC(this, "extended" === s, t, e, r, i, a))
          : null;
      }
      toRFC2822() {
        return rx(this, "EEE, dd LLL yyyy HH:mm:ss ZZZ", !1);
      }
      toHTTP() {
        return rx(this.toUTC(), "EEE, dd LLL yyyy HH:mm:ss 'GMT'");
      }
      toSQLDate() {
        return this.isValid ? rF(this, !0) : null;
      }
      toSQLTime() {
        let {
            includeOffset: e = !0,
            includeZone: t = !1,
            includeOffsetSpace: r = !0,
          } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          n = "HH:mm:ss.SSS";
        return ((t || e) && (r && (n += " "), t ? (n += "z") : e && (n += "ZZ")), rx(this, n, !0));
      }
      toSQL() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return this.isValid ? `${this.toSQLDate()} ${this.toSQLTime(e)}` : null;
      }
      toString() {
        return this.isValid ? this.toISO() : rS;
      }
      [Symbol.for("nodejs.util.inspect.custom")]() {
        return this.isValid
          ? `DateTime { ts: ${this.toISO()}, zone: ${this.zone.name}, locale: ${this.locale} }`
          : `DateTime { Invalid, reason: ${this.invalidReason} }`;
      }
      valueOf() {
        return this.toMillis();
      }
      toMillis() {
        return this.isValid ? this.ts : NaN;
      }
      toSeconds() {
        return this.isValid ? this.ts / 1e3 : NaN;
      }
      toUnixInteger() {
        return this.isValid ? Math.floor(this.ts / 1e3) : NaN;
      }
      toJSON() {
        return this.toISO();
      }
      toBSON() {
        return this.toJSDate();
      }
      toObject() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        if (!this.isValid) return {};
        let t = { ...this.c };
        return (
          e.includeConfig &&
            ((t.outputCalendar = this.outputCalendar),
            (t.numberingSystem = this.loc.numberingSystem),
            (t.locale = this.loc.locale)),
          t
        );
      }
      toJSDate() {
        return new Date(this.isValid ? this.ts : NaN);
      }
      diff(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "milliseconds",
          r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        if (!this.isValid || !e.isValid) return rr.invalid("created by diffing an invalid DateTime");
        let n = { locale: this.locale, numberingSystem: this.numberingSystem, ...r },
          i = (Array.isArray(t) ? t : [t]).map(rr.normalizeUnit),
          s = e.valueOf() > this.valueOf(),
          a = (function (e, t, r, n) {
            let [i, s, a, l] = (function (e, t, r) {
                let n,
                  i,
                  s = {},
                  a = e;
                for (let [l, o] of [
                  ["years", (e, t) => t.year - e.year],
                  ["quarters", (e, t) => t.quarter - e.quarter + (t.year - e.year) * 4],
                  ["months", (e, t) => t.month - e.month + (t.year - e.year) * 12],
                  [
                    "weeks",
                    (e, t) => {
                      let r = ra(e, t);
                      return (r - (r % 7)) / 7;
                    },
                  ],
                  ["days", ra],
                ])
                  r.indexOf(l) >= 0 &&
                    ((n = l),
                    (s[l] = o(e, t)),
                    (i = a.plus(s)) > t
                      ? (s[l]--, (e = a.plus(s)) > t && ((i = e), s[l]--, (e = a.plus(s))))
                      : (e = i));
                return [e, s, i, n];
              })(e, t, r),
              o = t - i,
              u = r.filter((e) => ["hours", "minutes", "seconds", "milliseconds"].indexOf(e) >= 0);
            0 === u.length &&
              (a < t && (a = i.plus({ [l]: 1 })), a !== i && (s[l] = (s[l] || 0) + o / (a - i)));
            let h = rr.fromObject(s, n);
            return u.length > 0
              ? rr
                  .fromMillis(o, n)
                  .shiftTo(...u)
                  .plus(h)
              : h;
          })(s ? this : e, s ? e : this, i, n);
        return s ? a.negate() : a;
      }
      diffNow() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "milliseconds",
          t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return this.diff(rH.now(), e, t);
      }
      until(e) {
        return this.isValid ? ri.fromDateTimes(this, e) : this;
      }
      hasSame(e, t, r) {
        if (!this.isValid) return !1;
        let n = e.valueOf(),
          i = this.setZone(e.zone, { keepLocalTime: !0 });
        return i.startOf(t, r) <= n && n <= i.endOf(t, r);
      }
      equals(e) {
        return (
          this.isValid &&
          e.isValid &&
          this.valueOf() === e.valueOf() &&
          this.zone.equals(e.zone) &&
          this.loc.equals(e.loc)
        );
      }
      toRelative() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        if (!this.isValid) return null;
        let t = e.base || rH.fromObject({}, { zone: this.zone }),
          r = e.padding ? (this < t ? -e.padding : e.padding) : 0,
          n = ["years", "months", "days", "hours", "minutes", "seconds"],
          i = e.unit;
        return (
          Array.isArray(e.unit) && ((n = e.unit), (i = void 0)),
          r_(t, this.plus(r), { ...e, numeric: "always", units: n, unit: i })
        );
      }
      toRelativeCalendar() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return this.isValid
          ? r_(e.base || rH.fromObject({}, { zone: this.zone }), this, {
              ...e,
              numeric: "auto",
              units: ["years", "months", "days"],
              calendary: !0,
            })
          : null;
      }
      static min() {
        for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
        if (!t.every(rH.isDateTime)) throw new o("min requires all arguments be DateTimes");
        return eq(t, (e) => e.valueOf(), Math.min);
      }
      static max() {
        for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
        if (!t.every(rH.isDateTime)) throw new o("max requires all arguments be DateTimes");
        return eq(t, (e) => e.valueOf(), Math.max);
      }
      static fromFormatExplain(e, t) {
        let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
          { locale: n = null, numberingSystem: i = null } = r;
        return rk(er.fromOpts({ locale: n, numberingSystem: i, defaultToEN: !0 }), e, t);
      }
      static fromStringExplain(e, t) {
        let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        return rH.fromFormatExplain(e, t, r);
      }
      static buildFormatParser(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          { locale: r = null, numberingSystem: n = null } = t;
        return new rp(er.fromOpts({ locale: r, numberingSystem: n, defaultToEN: !0 }), e);
      }
      static fromFormatParser(e, t) {
        let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        if (eW(e) || eW(t)) throw new o("fromFormatParser requires an input string and a format parser");
        let { locale: n = null, numberingSystem: i = null } = r,
          s = er.fromOpts({ locale: n, numberingSystem: i, defaultToEN: !0 });
        if (!s.equals(t.locale))
          throw new o(
            `fromFormatParser called with a locale of ${s}, but the format parser was created for ${t.locale}`,
          );
        let { result: a, zone: l, specificOffset: u, invalidReason: h } = t.explainFromTokens(e);
        return h ? rH.invalid(h) : rE(a, l, r, `format ${t.format}`, e, u);
      }
      static get DATE_SHORT() {
        return m;
      }
      static get DATE_MED() {
        return f;
      }
      static get DATE_MED_WITH_WEEKDAY() {
        return y;
      }
      static get DATE_FULL() {
        return g;
      }
      static get DATE_HUGE() {
        return w;
      }
      static get TIME_SIMPLE() {
        return v;
      }
      static get TIME_WITH_SECONDS() {
        return p;
      }
      static get TIME_WITH_SHORT_OFFSET() {
        return k;
      }
      static get TIME_WITH_LONG_OFFSET() {
        return T;
      }
      static get TIME_24_SIMPLE() {
        return S;
      }
      static get TIME_24_WITH_SECONDS() {
        return O;
      }
      static get TIME_24_WITH_SHORT_OFFSET() {
        return N;
      }
      static get TIME_24_WITH_LONG_OFFSET() {
        return b;
      }
      static get DATETIME_SHORT() {
        return M;
      }
      static get DATETIME_SHORT_WITH_SECONDS() {
        return D;
      }
      static get DATETIME_MED() {
        return I;
      }
      static get DATETIME_MED_WITH_SECONDS() {
        return V;
      }
      static get DATETIME_MED_WITH_WEEKDAY() {
        return E;
      }
      static get DATETIME_FULL() {
        return x;
      }
      static get DATETIME_FULL_WITH_SECONDS() {
        return F;
      }
      static get DATETIME_HUGE() {
        return C;
      }
      static get DATETIME_HUGE_WITH_SECONDS() {
        return $;
      }
    }
    function rP(e) {
      if (rH.isDateTime(e)) return e;
      if (e && e.valueOf && eZ(e.valueOf())) return rH.fromJSDate(e);
      if (e && "object" == typeof e) return rH.fromObject(e);
      throw new o(`Unknown datetime argument: ${e}, of type ${typeof e}`);
    }
    e.s(["DateTime", 0, rH]);
  },
]);
