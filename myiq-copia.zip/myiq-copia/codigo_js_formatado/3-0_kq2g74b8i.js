(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  985272,
  (e) => {
    "use strict";
    let t;
    var n = Object.defineProperty,
      a = (e, t, a) => {
        let r;
        return (r = "symbol" != typeof t ? t + "" : t) in e
          ? n(e, r, { enumerable: !0, configurable: !0, writable: !0, value: a })
          : (e[r] = a);
      };
    let r = null,
      o = null;
    class s extends Error {
      constructor(e, t = !0, n = !1) {
        const r =
          n && "u" > typeof window
            ? (function () {
                let e = navigator.connection || navigator.mozConnection || navigator.webkitConnection,
                  t = {
                    online: navigator.onLine,
                    documentHidden: document.hidden,
                    userAgent: navigator.userAgent,
                    timestamp: new Date().toISOString(),
                  };
                return (
                  e &&
                    ((t.connectionType = e.type),
                    (t.effectiveType = e.effectiveType),
                    (t.downlink = e.downlink),
                    (t.rtt = e.rtt),
                    (t.saveData = e.saveData)),
                  navigator.onLine
                    ? document.hidden
                      ? (t.likelyCause = "background_tab")
                      : e?.effectiveType === "slow-2g" || e?.effectiveType === "2g"
                        ? (t.likelyCause = "slow_connection")
                        : e?.downlink !== void 0 && e.downlink < 0.5 && (t.likelyCause = "poor_bandwidth")
                    : (t.likelyCause = "offline"),
                  t
                );
              })()
            : null;
        (super(
          r
            ? `${e} [${(function (e) {
                let t = [];
                return (
                  e.likelyCause && t.push(`cause=${e.likelyCause}`),
                  t.push(`online=${e.online}`),
                  t.push(`hidden=${e.documentHidden}`),
                  e.effectiveType && t.push(`net=${e.effectiveType}`),
                  void 0 !== e.downlink && t.push(`downlink=${e.downlink}Mbps`),
                  void 0 !== e.rtt && t.push(`rtt=${e.rtt}ms`),
                  t.join(", ")
                );
              })(r)}]`
            : e,
        ),
          a(this, "retryable"),
          a(this, "diagnostics"),
          (this.retryable = t),
          (this.name = "SDKLoadError"),
          (this.diagnostics = r));
      }
    }
    let i = "PayNextSDK";
    function l() {
      return typeof window > "u" ? null : window[i];
    }
    function c(e) {
      return new Promise((t) => setTimeout(t, e));
    }
    async function u() {
      let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 5e3,
        t = Math.ceil(e / 50);
      for (let e = 0; e < t; e++) {
        let e = l();
        if (e) return e;
        await c(50);
      }
      throw new s("PayNextSDK not found in window after waiting", !0, !0);
    }
    async function d(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
        n = e?.toLowerCase(),
        a =
          (n?.includes("develop") || n?.includes("staging") || n?.includes("preview")
            ? "develop"
            : "production") == "develop"
            ? "https://cdn-sdk-dev.paynext.com/index.cdn.js"
            : "https://cdn-sdk.paynext.com/index.cdn.js";
      try {
        return (
          l() ||
          (await new Promise((e, t) => {
            let n = document.querySelector(`script[src="${a}"]`);
            if (n) {
              if (l()) return void e();
              let a = setTimeout(() => {
                  (n.removeEventListener("load", r),
                    n.removeEventListener("error", o),
                    t(new s("Existing SDK script loading timeout", !0, !0)));
                }, 15e3),
                r = () => {
                  (clearTimeout(a), n.removeEventListener("load", r), n.removeEventListener("error", o), e());
                },
                o = () => {
                  (clearTimeout(a),
                    n.removeEventListener("load", r),
                    n.removeEventListener("error", o),
                    t(new s("Existing SDK script failed to load", !0, !0)));
                };
              return (n.addEventListener("load", r), void n.addEventListener("error", o));
            }
            let r = setTimeout(() => {
                (i(), t(new s("SDK script loading timeout", !0, !0)));
              }, 15e3),
              o = document.createElement("script");
            ((o.src = a),
              (o.crossOrigin = "anonymous"),
              (o.async = !0),
              o.setAttribute("data-paynext-sdk", "true"));
            let i = () => {
              (clearTimeout(r), (o.onload = null), (o.onerror = null));
            };
            ((o.onload = () => {
              (i(), e());
            }),
              (o.onerror = (e) => {
                (console.error("[PayNext CDN] Script load error:", e), i());
                try {
                  o.parentNode && o.parentNode.removeChild(o);
                } catch (e) {
                  console.warn("[PayNext CDN] Failed to remove script:", e);
                }
                t(new s("Failed to load SDK script from CDN", !0, !0));
              }));
            try {
              document.head.appendChild(o);
            } catch {
              (i(), t(new s("Failed to append script to document", !1)));
            }
          }),
          await u(5e3))
        );
      } catch (n) {
        if ((!(n instanceof s) || n.retryable) && t < 5)
          return (
            console.warn(`[PayNext CDN] Load attempt ${t} failed, retrying in 1500ms...`, n),
            await c(1500 * t),
            d(e, t + 1)
          );
        throw (console.error(`[PayNext CDN] Failed to load SDK after ${t} attempts:`, n), n);
      }
    }
    async function m(e) {
      if (o) return o;
      if (r) return r;
      if (typeof window > "u") throw new s("PayNext SDK can only be loaded in browser environment", !1);
      let t = l();
      return t
        ? (o = t)
        : (r = (async () => {
            try {
              let t = await d(e);
              return ((o = t), typeof window > "u" || (window[i] = t), t);
            } catch (e) {
              throw ((r = null), e);
            }
          })());
    }
    class y {
      constructor() {
        (a(this, "cdnInstance", null),
          a(this, "initPromise", null),
          a(this, "isDestroyed", !1),
          a(this, "errorBoundary", null));
      }
      setErrorHandler(e) {
        this.errorBoundary = e;
      }
      handleError(e, t) {
        if ((console.error(`[PayNext SDK Error - ${t}]: ${e.message}`, e), this.errorBoundary))
          try {
            this.errorBoundary(e);
          } catch (e) {
            console.error("[PayNext SDK] Error in custom error handler:", e);
          }
      }
      async initialize(e) {
        if (this.isDestroyed) throw new s("Cannot initialize destroyed SDK instance", !1);
        return (
          this.initPromise ||
            (this.initPromise = (async () => {
              try {
                let t = await m(e);
                if (!t || !t.PayNextCheckout)
                  throw new s("PayNextCheckout not found in loaded SDK module", !1);
                try {
                  this.cdnInstance = new t.PayNextCheckout();
                } catch (e) {
                  throw new s(
                    `Failed to instantiate PayNextCheckout: ${e instanceof Error ? e.message : "Unknown error"}`,
                    !1,
                  );
                }
              } catch (e) {
                throw ((this.initPromise = null), e);
              }
            })()),
          this.initPromise
        );
      }
      assertReady() {
        if (this.isDestroyed) throw new s("SDK instance has been destroyed", !1);
        if (!this.initPromise) throw new s("SDK initialization not started", !1);
        if (!this.cdnInstance) throw new s("SDK instance not created", !1);
      }
      async mount(e, t) {
        try {
          if (!e || "string" != typeof e) throw new s("Invalid containerId provided", !1);
          if (!t || !t.environment) throw new s("Invalid config provided", !1);
          if (!document.getElementById(e)) throw new s(`Container element with id "${e}" not found`, !1);
          (await this.initialize(t.environment), this.assertReady(), await this.cdnInstance.mount(e, t));
        } catch (t) {
          let e = t instanceof s ? t : new s(t instanceof Error ? t.message : "Unknown mount error", !0);
          throw (this.handleError(e, "mount"), e);
        }
      }
      update(e) {
        try {
          if (this.isDestroyed) return void console.warn("[PayNext SDK] update called on destroyed instance");
          if (!this.cdnInstance) return void console.warn("[PayNext SDK] update called before mount");
          "function" == typeof this.cdnInstance.update
            ? this.cdnInstance.update(e)
            : console.warn(
                "[PayNext SDK] update() is not supported by the loaded CDN bundle; a newer SDK version is required",
              );
        } catch (t) {
          let e = t instanceof Error ? t : Error(String(t));
          this.handleError(e, "update");
        }
      }
      setPaymentsEnabled(e) {
        try {
          if (this.isDestroyed)
            return void console.warn("[PayNext SDK] setPaymentsEnabled called on destroyed instance");
          if (!this.cdnInstance)
            return void console.warn("[PayNext SDK] setPaymentsEnabled called before mount");
          "function" == typeof this.cdnInstance.setPaymentsEnabled && this.cdnInstance.setPaymentsEnabled(e);
        } catch (t) {
          let e = t instanceof Error ? t : Error(String(t));
          this.handleError(e, "setPaymentsEnabled");
        }
      }
      async unmount() {
        try {
          if (this.isDestroyed) return void console.warn("[PayNext SDK] Instance already destroyed");
          if (!this.cdnInstance) return void console.warn("[PayNext SDK] No instance to unmount");
          try {
            "function" == typeof this.cdnInstance.unmount && (await this.cdnInstance.unmount());
          } catch (t) {
            let e = t instanceof Error ? t : Error(String(t));
            this.handleError(e, "unmount");
          }
          ((this.cdnInstance = null), (this.initPromise = null));
        } catch (t) {
          let e = t instanceof Error ? t : Error(String(t));
          this.handleError(e, "unmount");
        }
      }
      static async preload(e) {
        try {
          await m(e);
        } catch (e) {
          throw (console.error("[PayNext SDK] Preload failed:", e), e);
        }
      }
    }
    y.preload;
    var p =
      (((t = p || {}).PAYPAL = "PAYPAL"),
      (t.APPLE_PAY = "APPLEPAY"),
      (t.GOOGLE_PAY = "GPAY"),
      (t.CARD = "CARD"),
      (t.VENMO = "VENMO"),
      (t.CASHAPP = "CASHAPP"),
      (t.AMAZONPAY = "AMAZONPAY"),
      (t.PIX_AUTOMATICO = "PIX_AUTOMATICO"),
      (t.UPI = "UPI"),
      (t.BLIK = "BLIK"),
      t);
    e.s(["PayNextCheckout", 0, y, "PaymentMethod", 0, p]);
  },
  812384,
  408110,
  (e) => {
    "use strict";
    var t = e.i(954616),
      n = e.i(86596);
    e.i(682770);
    var a = e.i(934952),
      r = e.i(117595),
      o = e.i(866897),
      s = e.i(134404),
      i = e.i(157273),
      l = e.i(60423);
    e.i(756503);
    var c = e.i(542516);
    e.i(531122);
    var u = e.i(81844);
    let d = async (e) => {
        let t = await u.httpInstance.post(s.EApiRoutes.CHECKOUT_SESSION, {
            json: ((e) => {
              if (!e.userData || e.userData.quiz_answers_additional?.length) return e;
              let t = l.accessLocalStorage.getItem(i.StorageKeys.MYIQ_NON_IMAGE_ANSWERS);
              if (!t) return e;
              try {
                let n = JSON.parse(t);
                if (Array.isArray(n) && n.length)
                  return { ...e, userData: { ...e.userData, quiz_answers_additional: n } };
              } catch {}
              return e;
            })(
              ((e) => {
                if (!e.userData || e.userData.quiz_answers?.length) return e;
                let t = l.accessLocalStorage.getItem(i.StorageKeys.QUIZ_ANSWERS);
                if (!t) return e;
                try {
                  let n = JSON.parse(t);
                  if (Array.isArray(n) && n.length)
                    return { ...e, userData: { ...e.userData, quiz_answers: n } };
                } catch {}
                return e;
              })(e),
            ),
            throwHttpErrors: !1,
          }),
          n = await t.json();
        return (
          n.success &&
            n.data?.paynextClientSessionId &&
            r.default.set(o.ECookieArg.PAYNEXT_SESSION, n.data?.paynextClientSessionId, {
              secure: "production" === c.envClient.NEXT_PUBLIC_APP_ENV,
              expires: 40 / 24,
              path: "/",
              sameSite: "lax",
            }),
          n
        );
      },
      m = async (e) => {
        let t = await u.httpInstance.post(s.EApiRoutes.CHECKOUT_SESSION, { json: e, throwHttpErrors: !1 });
        return (await t.json()).data ?? null;
      },
      y = async (e) =>
        (
          await u.httpInstance.post(s.EApiRoutes.CHECKOUT_SESSION_FRAUD_SESSIONS, {
            json: e,
            throwHttpErrors: !1,
          })
        ).json();
    (e.s(
      [
        "createUserSessionFetcher",
        0,
        d,
        "getCheckoutSessionPriceFetcher",
        0,
        m,
        "updateCheckoutSessionFraudSessionsFetcher",
        0,
        y,
      ],
      408110,
    ),
      e.s(
        [
          "useCreateUserSessionMutation",
          0,
          () => {
            let e = (0, n.useUserStore)((e) => e.handleChangeUserStore),
              r = (0, t.useMutation)({
                mutationFn: d,
                onSuccess(t) {
                  t.success
                    ? t.data &&
                      e({
                        user: {
                          paymentInfo: {
                            ...t.data,
                            paynextAmountPayment: t.data.paynextAmountPayment?.toString(),
                          },
                        },
                      })
                    : (0, a.customToast)(t?.error || "", "error");
                },
              });
            return { ...r, trigger: r.mutateAsync };
          },
          "useUpdateCheckoutSessionFraudSessionsMutation",
          0,
          () => {
            let e = (0, t.useMutation)({ mutationFn: y });
            return { ...e, trigger: e.mutateAsync };
          },
        ],
        812384,
      ));
  },
  715413,
  (e) => {
    "use strict";
    var t = e.i(271645);
    e.i(756503);
    var n = e.i(542516);
    let a = [
      "https://js.braintreegateway.com/web/3.133.0/js/client.min.js",
      "https://js.braintreegateway.com/web/3.133.0/js/data-collector.min.js",
    ];
    e.s([
      "useBraintreeDataCollector",
      0,
      () => {
        let [e, r] = (0, t.useState)(null),
          [o, s] = (0, t.useState)(!1),
          [i, l] = (0, t.useState)(null);
        return (
          (0, t.useEffect)(() => {
            if ("u" > typeof document)
              for (let e of a) {
                if (document.querySelector(`script[src="${e}"]`)) continue;
                let t = document.createElement("script");
                ((t.src = e), (t.async = !0), document.head.appendChild(t));
              }
            let e = null,
              t = null,
              o = Date.now(),
              i = () =>
                !!(window.braintree?.client && window.braintree?.dataCollector) &&
                (e && (clearInterval(e), (e = null)),
                t && (clearTimeout(t), (t = null)),
                s(!0),
                l(null),
                window.braintree?.client?.create(
                  { authorization: n.envClient.NEXT_PUBLIC_BRAINTREE_AUTHORIZATION || "" },
                  function (e, t) {
                    if (e) {
                      (r(""), s(!1));
                      return;
                    }
                    window?.braintree?.dataCollector?.create({ client: t }, function (e, t) {
                      (s(!1), e) ? r("") : r(t.deviceData);
                    });
                  },
                ),
                !0);
            if (!i())
              return (
                (e = setInterval(() => {
                  !i() && Date.now() - o >= 1e4 && (e && (clearInterval(e), (e = null)), r(""));
                }, 100)),
                (t = setTimeout(() => {
                  (e && (clearInterval(e), (e = null)), window.braintree || r(""));
                }, 1e4)),
                () => {
                  (e && clearInterval(e), t && clearTimeout(t));
                }
              );
          }, []),
          { deviceData: e, isCollecting: o, error: i }
        );
      },
    ]);
  },
  210209,
  (e) => {
    "use strict";
    var t = e.i(360067);
    e.s([
      "getPayerNameFromCheckoutResult",
      0,
      (e) => {
        let t = ((e) => {
          let [t = "", ...n] = e
            .replace(/^[-_\s]+/, "")
            .trim()
            .split(/\s+/);
          return { firstName: t, lastName: n.join(" ") };
        })(e?.customer?.full_name || "");
        if (t.firstName) return t;
        let n = e?.payment_method?.details?.payer_info;
        return { firstName: (n?.first_name || "").trim(), lastName: (n?.last_name || "").trim() };
      },
      "getSuggestedCertificateName",
      0,
      (e) =>
        ((e) => {
          let n,
            a,
            r = (0, t.sanitizeNameInput)(e || "")
              .replace(/[^\p{L}\p{M}\s'-]/gu, "")
              .replace(/\s+/g, " ")
              .replace(/^[-\s]+/, "")
              .slice(0, 35)
              .trim();
          return r.length < 2
            ? ""
            : ((n = r === r.toLocaleUpperCase()),
              (a = r === r.toLocaleLowerCase()),
              n || a
                ? r.toLocaleLowerCase().replace(/(^|[\s'-])(\p{L})/gu, (e, t, n) => t + n.toLocaleUpperCase())
                : r);
        })([e?.firstName, e?.lastName].filter(Boolean).join(" ")),
    ]);
  },
  360067,
  (e) => {
    "use strict";
    let t = { value: /^[\p{L}\p{M}\s'][\p{L}\p{M}\s'-]*$/u, message: "error_name_format" },
      n = (e) => e.replace(/[\u200E\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g, "");
    e.s([
      "NAME_MAX_LENGTH",
      0,
      35,
      "emailPattern",
      0,
      {
        value:
          /^(?=.{1,311}$)([a-zA-Z0-9_](?:[a-zA-Z0-9_.+-]*(?:\.[a-zA-Z0-9_.+-]+)*[a-zA-Z0-9_])?@[a-zA-Z0-9]+(?:[.-][a-zA-Z0-9]+)*\.[a-zA-Z]{2,})$/,
        message: "error_email_format",
      },
      "getRequiredMessage",
      0,
      (e) => e("error_required_field"),
      "maxLengthPattern",
      0,
      (e, t) => ({ value: RegExp(`^.{2,${e}}$`), message: t("error_max_characters", { count: `${e}` }) }),
      "minLength2Pattern",
      0,
      { value: /^.{2,}$/, message: "error_min_2_characters" },
      "namePattern",
      0,
      t,
      "sanitizeNameInput",
      0,
      n,
      "validateName",
      0,
      (e, a) => {
        let r = n(e);
        return r && r.trim().length > 0 && !t.value.test(r)
          ? a("error_name_format")
          : r.length > 35
            ? a("error_max_characters", { count: "35" })
            : null;
      },
    ]);
  },
  218099,
  (e) => {
    "use strict";
    var t = e.i(843476),
      n = e.i(117595),
      a = e.i(618566),
      r = e.i(271645),
      o = e.i(985272),
      s = e.i(812384);
    e.i(842582);
    var i = e.i(76399);
    e.i(473189);
    var l = e.i(476880),
      c = e.i(715413),
      u = e.i(882345),
      d = e.i(49587),
      m = e.i(891133),
      y = e.i(523173),
      p = e.i(866897),
      h = e.i(622963),
      f = e.i(86596),
      g = e.i(190899),
      _ = e.i(210209);
    e.i(756503);
    var v = e.i(542516);
    e.i(470366);
    var w = e.i(504001),
      E = e.i(194613),
      C = e.i(202042);
    e.i(999126);
    var P = e.i(548248);
    let S = "ALREADY_SUBSCRIBED",
      I = new Set([
        "ar",
        "bg",
        "cs",
        "da",
        "de",
        "el",
        "en",
        "es",
        "et",
        "fi",
        "fil",
        "fr",
        "hr",
        "hu",
        "id",
        "is",
        "it",
        "ja",
        "ko",
        "lt",
        "lv",
        "ms",
        "mt",
        "nl",
        "nl-BE",
        "no",
        "pl",
        "pt",
        "ro",
        "ru",
        "sk",
        "sl",
        "sr",
        "sv",
        "th",
        "tr",
        "uk",
        "vi",
        "zh",
      ]);
    e.s(
      [
        "default",
        0,
        (e) => {
          let {
              locale: A,
              user: x,
              handleCheckoutSuccess: N,
              attributionData: b,
              containerId: D = "checkout-container",
              abMyiqPromoPrice: k,
              abMyiqAb100Vs199: L,
              abMyiqRevolutMonzoBlock: T,
              abMyiqBrazilMastercardOnly: M,
              isMarketingSource: R,
              isCheckoutTimerExpired: U = !1,
              reuseSession: B = !1,
              isPlanPickerFunnel: O = !1,
              planName: K,
              paynextPlanId: F,
              paymentsEnabled: $,
              onPaymentsBlocked: z,
              onProcessingChange: j,
              onPaymentSucceeded: H,
              onAlreadySubscribed: Y,
            } = e,
            [, V] = (0, r.useState)(null),
            X = (0, r.useRef)(null),
            q = (0, r.useRef)($);
          q.current = $;
          let Z = (0, h.useModalStore)((e) => e.handleChangeModalStore),
            G = (0, r.useRef)(null),
            J = (0, r.useRef)(null),
            W = (0, r.useRef)(new Set()),
            Q = (0, r.useRef)(!1),
            { trigger: ee } = (0, s.useCreateUserSessionMutation)(),
            { deviceData: et } = (0, c.useBraintreeDataCollector)(),
            { getAttributionData: en } = (0, i.useCollectParams)(),
            ea = (0, f.useUserStore)((e) => e.handleChangeUserStore),
            [er, eo] = (0, r.useState)(n.default.get(p.ECookieArg.PAYNEXT_SESSION)),
            es = (0, C.usePathname)(),
            ei = (0, a.useSearchParams)(),
            el = async () => {
              x &&
                ee({
                  attributionData: (0, l.getPaymentAttributionData)(en()) || {},
                  abMyiqRevolutMonzoBlock: "block" === T || "not_block" === T ? T : void 0,
                  ...(("v1_mastercard_only" === M || "control" === M) && { abMyiqBrazilMastercardOnly: M }),
                  ...(k && R && { abMyiqPromoPrice: k }),
                  ...("v1_trial_1_99" === L && { abMyiqAb100Vs199: L }),
                  ...((0, m.getIsUsA1Campaign)() && { isUsA1Campaign: !0 }),
                  ...((0, u.getIsBrCampaign)() && { isBrCampaign: !0 }),
                  ...((0, d.getIsRedesignFunnel)() && { redesignFunnel: !0 }),
                  isMarketingSource: !!R,
                  deviceData: "string" == typeof et ? et : JSON.stringify(et) || "",
                  userData: x,
                  planId: E.EPaynextPlanIds.SPLIT_TRIAL_TIMER_EXPIRED,
                  isCheckoutRefresh: !0,
                }).then((e) => {
                  if (e?.code === S) return void Y?.();
                  if (e?.data) {
                    let t = e.data;
                    (ea({
                      user: {
                        ...x,
                        paymentInfo: { ...t, paynextAmountPayment: t?.paynextAmountPayment?.toString() },
                      },
                    }),
                      eo(t.paynextClientSessionId));
                  }
                });
            },
            ec = async () => {
              x &&
                ee({
                  attributionData: (0, l.getPaymentAttributionData)(en()) || {},
                  abMyiqRevolutMonzoBlock: "block" === T || "not_block" === T ? T : void 0,
                  ...(("v1_mastercard_only" === M || "control" === M) && { abMyiqBrazilMastercardOnly: M }),
                  ...(k && R && { abMyiqPromoPrice: k }),
                  ...("v1_trial_1_99" === L && { abMyiqAb100Vs199: L }),
                  ...((0, m.getIsUsA1Campaign)() && { isUsA1Campaign: !0 }),
                  ...((0, u.getIsBrCampaign)() && { isBrCampaign: !0 }),
                  ...((0, d.getIsRedesignFunnel)() && { redesignFunnel: !0 }),
                  isMarketingSource: !!R,
                  deviceData: "string" == typeof et ? et : JSON.stringify(et) || "",
                  userData: x,
                  isCheckoutRefresh: !0,
                }).then((e) => {
                  if (e?.code === S) return void Y?.();
                  if (e?.data) {
                    let t = e.data;
                    (ea({
                      user: {
                        ...x,
                        paymentInfo: { ...t, paynextAmountPayment: t?.paynextAmountPayment?.toString() },
                      },
                    }),
                      eo(t.paynextClientSessionId));
                  }
                });
            };
          ((0, r.useEffect)(() => {
            if (!B) return;
            let e = x?.paymentInfo?.paynextClientSessionId;
            e && e !== er && eo(e);
          }, [B, x?.paymentInfo?.paynextClientSessionId]),
            (0, r.useEffect)(() => {
              B ||
                (!O &&
                  x?.paymentInfo &&
                  ((x.paymentInfo?.paynextClientSessionExpiryDate &&
                    new Date(x.paymentInfo?.paynextClientSessionExpiryDate) < new Date()) ||
                    !er) &&
                  ec());
            }, [x]),
            (0, r.useEffect)(() => {
              B || (!O && U && !Q.current && x && ((Q.current = !0), el()));
            }, [U, x]));
          let eu = (e, t) => {
              (0, w.trackClientEvents)({
                event: y.EAnalyticEvents.PURCHASE_ERROR,
                user: x,
                params: { error_code: e || "Error processing payment", ...(t && { detailed_message: t }) },
              });
            },
            ed = async () => {
              let e = {
                app_version: "v2",
                currency: x?.paymentInfo?.paynextAmountCurrency,
                email: x?.email,
                customer_id: x?.id,
                mixpanel_user_id: x?.id,
                user_id: x?.id,
                language: x?.locale,
                country: x?.currency?.countryCode,
                flow_type: "web_onboarding",
                plan_name: O && K ? K : "SPLIT_TRIAL",
                ...(O && { plan_picker_funnel: !0 }),
                paymentOrchestrator: "PayNext",
                paynextSessionId: x?.paymentInfo?.paynextClientSessionId,
                paynextPaymentCurrency: x?.paymentInfo?.paynextAmountCurrency,
                paynextPaymentAmount: Number(x?.paymentInfo?.paynextAmountPayment),
                displayedCurrency: x?.paymentInfo?.paynextAmountDisplayedCurrency,
                displayedAmount: x?.paymentInfo?.paynextAmountDisplayed,
                amount: Number(x?.paymentInfo?.paynextAmountPayment),
                supabase_user_id: x?.id || "",
                first_name: x?.paymentInfo?.firstName || "",
                last_name: x?.paymentInfo?.lastName || "",
                hostname: `${v.envClient.NEXT_PUBLIC_BILLING_HOSTNAME}`,
                sub_order_country: x?.currency?.countryCode || "",
                paynextPlanID: O && F ? F : E.EPaynextPlanIds.SPLIT_TRIAL,
                billing_weeks: x?.paymentInfo?.billing_weeks,
                billing_price: x?.paymentInfo?.billing_price,
                paynextSubscriptionId: x?.paymentInfo?.subscriptionId,
                ...b,
              };
              if (!er) return void eu("PayNext client session not found");
              if (!document.getElementById(D)) return void eu("Checkout container not found");
              let t = new o.PayNextCheckout(),
                n =
                  "v1_mastercard_only" === M
                    ? {
                        [o.PaymentMethod.CARD]: ["mastercard"],
                        [o.PaymentMethod.APPLE_PAY]: ["mastercard"],
                        [o.PaymentMethod.GOOGLE_PAY]: ["mastercard"],
                      }
                    : void 0;
              (await t.mount(D, {
                clientToken: er,
                environment: v.envClient.NEXT_PUBLIC_PAYNEXT_ENV,
                apiVersion: "1.0.0",
                locale: ((e) => {
                  if (I.has(e)) return e;
                  let t = e.split("-")[0].toLowerCase();
                  return I.has(t) ? t : "en";
                })(A),
                variant: "compact",
                ...(n && { acceptedCardNetworks: n }),
                ...("boolean" == typeof $ && { paymentsEnabled: $ }),
                returnUrl: `${v.envClient.NEXT_PUBLIC_APP_URL}${es}?scroll=checkout`,
                styles: {
                  SubmitButton: {
                    iconSvg:
                      '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" aria-hidden="true" viewBox="0 0 20 20" class="inline h-5 w-5" focusable="false"><path fill-rule="evenodd" d="M10 1a4.5 4.5 0 0 0-4.5 4.5V9H5a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2h-.5V5.5A4.5 4.5 0 0 0 10 1m3 8V5.5a3 3 0 1 0-6 0V9z" clip-rule="evenodd"></path></svg>',
                  },
                },
                onCheckoutLoaded: (e) => {
                  if (((0, P.debugUtil)({ text: "PayNext form loaded", value: e }), e.success)) {
                    (0, w.trackClientEvents)({
                      event: y.EAnalyticEvents.PAYMENT_FORM_VIEWED,
                      user: x,
                      params: { paymentOrchestrator: "PayNext" },
                    });
                    let e = document.getElementById(D);
                    e &&
                      (e.addEventListener("click", (e) => {
                        let t = e.target;
                        if (!t) return;
                        let n = t.closest("button");
                        n &&
                          n instanceof HTMLElement &&
                          G.current !== n &&
                          ((G.current = n),
                          (0, w.trackClientEvents)({
                            event: y.EAnalyticEvents.PAGE_CLICKED,
                            user: x,
                            params: { page_name: "paymentMethodButtonClicked", payment_method: "card" },
                          }));
                      }),
                      "checkout" === ei.get("scroll") &&
                        "checkout-container" === D &&
                        setTimeout(() => {
                          let e = document.getElementById("checkout-coupon-disclaimer");
                          if (e) {
                            let t = e.getBoundingClientRect().top + window.scrollY;
                            window.scrollTo({ top: t - 30, behavior: "smooth" });
                          }
                        }, 100));
                  }
                },
                onCheckoutAttempt(t) {
                  (j?.(!0),
                    (0, w.trackClientEvents)({
                      event: y.EAnalyticEvents.PURCHASE_ATTEMPT,
                      user: x,
                      params: {
                        ...e,
                        payment_card_brand: t.cardType?.toUpperCase() || "",
                        payment_method_type: t.paymentMethod,
                      },
                    }));
                },
                onCheckoutBlocked: (e) => {
                  (j?.(!1),
                    (0, w.trackClientEvents)({
                      event: y.EAnalyticEvents.PAGE_CLICKED,
                      user: x,
                      params: { page_name: "paymentBlockedNoConsent", payment_method: e.paymentMethod },
                    }),
                    z?.(e));
                },
                onCheckoutComplete: (t) => {
                  var n;
                  (0, P.debugUtil)({ text: "PayNext Payment completed", value: t });
                  let a = t?.id;
                  if (!a) return;
                  if (W.current.has(a)) {
                    g.accessSessionStorageUtil.getItem("paymentId") !== a &&
                      Z({ modalComponent: "payment-processed-other-tab", isModalVisible: !0 });
                    return;
                  }
                  (W.current.add(a),
                    g.accessSessionStorageUtil.setItem("paymentId", a),
                    H?.(),
                    J.current && J.current.postMessage({ type: "payment-completed", paymentId: a }),
                    (0, w.trackClientEvents)({
                      user: x,
                      event: y.EAnalyticEvents.PURCHASE_SUCCESS,
                      params: {
                        ...e,
                        payment_method_type: t?.payment_method?.type,
                        payment_card_brand: t?.payment_method?.details?.bin_data?.brand?.toUpperCase() || "",
                        payment_id: t?.id,
                        payment_processor: t?.processor?.type || "",
                      },
                    }));
                  let { firstName: r, lastName: o } = (0, _.getPayerNameFromCheckoutResult)(t),
                    s = t?.tax?.amount_tax || 0,
                    i = t?.tax?.amount_subtotal || 0,
                    l = t?.statement_descriptor || "";
                  N({
                    orderId: (n = {
                      payment: t,
                      paymentMethod:
                        t?.payment_method?.details?.bin_data?.brand?.toUpperCase() || t?.payment_method?.type,
                      paymentСardBrand: t?.payment_method?.details?.bin_data?.brand?.toUpperCase() || "",
                      paymentMethodType: t?.payment_method?.type,
                      processorMerchantId: t?.processor?.processor_merchant_id || "",
                      statementDescriptor: l,
                      paymentProcessor: t?.processor?.type || "",
                      currencyCode: t?.currency_code || "USD",
                      first6Digits: t?.payment_method?.details?.last4?.substring(0, 6) || "",
                      firstName: r,
                      lastName: o,
                      taxAmount: s,
                      taxAmountSubtotal: i,
                    }).payment.id,
                    payment: n.payment,
                    paymentMethod: n.paymentMethod,
                    paymentMethodType: n.paymentMethodType || "",
                    paymentСardBrand: n.paymentСardBrand || "",
                    paymentProcessor: n.paymentProcessor,
                    currencyCode: n.currencyCode,
                    first6Digits: n.first6Digits?.toString() || "",
                    processorMerchantId: n.processorMerchantId,
                    statementDescriptor: n.statementDescriptor,
                    firstName: n.firstName,
                    lastName: n.lastName,
                    attributionData: n.attributionData,
                    taxAmount: n.taxAmount,
                    taxAmountSubtotal: n.taxAmountSubtotal,
                  });
                },
                onCheckoutFail: (e) => {
                  (j?.(!1),
                    (0, P.debugUtil)({ text: "PayNext Payment failed", value: e }),
                    eu(e?.status_reason?.message || "Payment failed. Please try again."),
                    (e?.status_reason?.message.toLowerCase().includes("client_session_id") ||
                      e?.status_reason?.message.toLowerCase().includes("client session") ||
                      e?.status_reason?.message.toLowerCase().includes("invalid cl") ||
                      e?.status_reason?.message.toLowerCase().includes("transaction config")) &&
                      ec(),
                    (0, w.trackClientEvents)({
                      event: y.EAnalyticEvents.PURCHASE_ERROR,
                      user: x,
                      params: {
                        amount: Number(x?.paymentInfo?.paynextAmountPayment),
                        currency: x?.paymentInfo?.paynextAmountCurrency,
                        paymentOrchestrator: "PayNext",
                        paynextAdviceCode: e?.status_reason?.advice_code || "",
                        paynextDeclineCode: e?.status_reason?.decline_code || "",
                        paynextSDKError: e?.status === "sdk_failed",
                        paynextDeclineMessage:
                          e?.status !== "sdk_failed" && e?.status_reason?.message
                            ? e.status_reason.message
                            : "SDK Initialisation Failed",
                      },
                    }));
                },
              }),
                (X.current = t),
                "boolean" == typeof q.current && t.setPaymentsEnabled(q.current),
                V(t));
            };
          return (
            (0, r.useEffect)(() => {
              J.current = new BroadcastChannel("payment-processing");
              let e = J.current;
              return (
                (e.onmessage = (e) => {
                  let { type: t, paymentId: n } = e.data;
                  "payment-completed" === t &&
                    n &&
                    (W.current.add(n),
                    g.accessSessionStorageUtil.getItem("paymentId") !== n &&
                      Z({ modalComponent: "payment-processed-other-tab", isModalVisible: !0 }));
                }),
                () => {
                  e.close();
                }
              );
            }, [Z]),
            (0, r.useEffect)(() => {
              if (er) {
                let e = x?.paymentInfo?.paynextClientSessionExpiryDate;
                (e && new Date(e) < new Date()) ||
                  ed().catch((e) => {
                    let t = document.getElementById(D);
                    (t && (t.innerHTML = ""),
                      ed().catch((t) => {
                        eu(
                          "Failed to load payment form. Please refresh the page",
                          t?.message || e?.message || String(t),
                        );
                      }));
                  });
              }
            }, [er]),
            (0, r.useEffect)(() => {
              if ("checkout" === ei.get("scroll") && "checkout-container" === D) {
                let e = document.getElementById(D);
                e && e.scrollIntoView({ behavior: "smooth", block: "center" });
              }
            }, [ei, D]),
            (0, r.useEffect)(() => {
              "boolean" == typeof $ && X.current?.setPaymentsEnabled($);
            }, [$]),
            (0, t.jsx)("div", {
              id: "checkout-form-section",
              className: "w-full",
              children: (0, t.jsx)("div", {
                style: { display: "grid", gridAutoFlow: "row", zIndex: 0, width: "100%" },
                children: (0, t.jsx)("div", { className: "w-full text-left", id: D, style: { zIndex: 1 } }),
              }),
            })
          );
        },
      ],
      218099,
    );
  },
  149278,
  function (e) {
    e.n(e.i(218099));
  },
]);
