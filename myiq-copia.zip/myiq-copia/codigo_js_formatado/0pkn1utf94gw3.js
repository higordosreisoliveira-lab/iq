(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  882983,
  (e) => {
    "use strict";
    var i = e.i(265840),
      t = e.i(271645),
      s = e.i(273830),
      l = e.i(620253),
      a = e.i(75540),
      o = e.i(843476),
      d = (0, s.forwardRef)((e, s) => {
        let { as: d, children: r, className: n, ...c } = e,
          { slots: u, classNames: m, bodyId: p, setBodyMounted: h } = (0, i.useModalContext)(),
          f = (0, l.useDOMRef)(s);
        return (
          (0, t.useEffect)(() => (h(!0), () => h(!1)), [h]),
          (0, o.jsx)(d || "div", {
            ref: f,
            className: u.body({ class: (0, a.clsx)(null == m ? void 0 : m.body, n) }),
            id: p,
            ...c,
            children: r,
          })
        );
      });
    ((d.displayName = "HeroUI.ModalBody"), e.s(["ModalBody", 0, d], 882983));
  },
  269638,
  (e) => {
    "use strict";
    let i = (0, e.i(475254).default)("circle-check-big", [
      ["path", { d: "M21.801 10A10 10 0 1 1 17 3.335", key: "yps3ct" }],
      ["path", { d: "m9 11 3 3L22 4", key: "1pflzl" }],
    ]);
    e.s(["CheckCircle", 0, i], 269638);
  },
  317197,
  231529,
  (e) => {
    "use strict";
    var i = e.i(843476),
      t = e.i(882983),
      s = e.i(742214),
      l = e.i(663615);
    e.i(680460);
    var a = e.i(885944);
    (e.s([], 317197),
      e.s(
        [
          "ModalBodyComponent",
          0,
          (e) => {
            let {
              children: o,
              title: d,
              subtitle: r,
              className: n = "",
              bodyClassName: c,
              titleClassName: u,
            } = e;
            return (0, i.jsx)(s.ModalContent, {
              className: n,
              children: (0, i.jsxs)(t.ModalBody, {
                className: (0, l.cn)(
                  "flex h-full w-full flex-col gap-5 p-5 antialiased md:p-6 [@media(max-height:580px)]:gap-3 [@media(max-height:580px)]:p-4",
                  c,
                ),
                children: [
                  (d || r) &&
                    (0, i.jsx)(a.ModalHeaderComponent, { title: d, subtitle: r, titleClassName: u }),
                  o,
                ],
              }),
            });
          },
        ],
        231529,
      ));
  },
  864709,
  (e) => {
    "use strict";
    var i = e.i(843476),
      t = e.i(269638),
      s = e.i(134404),
      l = e.i(622963);
    e.i(568267);
    var a = e.i(154692),
      o = e.i(202042);
    e.i(317197);
    var d = e.i(231529);
    e.i(680460);
    var r = e.i(885944);
    (e.s([], 632203),
      e.i(632203),
      e.s(
        [
          "PrintedCertificateSuccessModalComponent",
          0,
          () => {
            let e = (0, o.useRouter)(),
              n = (0, l.useModalStore)((e) => e.handleChangeModalStore);
            return (0, i.jsxs)(d.ModalBodyComponent, {
              children: [
                (0, i.jsx)("div", {
                  className: "mx-auto flex w-fit items-center justify-center rounded-full bg-blue-50 p-3",
                  children: (0, i.jsx)(t.CheckCircle, {
                    className: "h-8 w-8 shrink-0 text-primary",
                    "aria-hidden": !0,
                  }),
                }),
                (0, i.jsxs)("div", {
                  className: "flex flex-col gap-2",
                  children: [
                    (0, i.jsx)(r.ModalHeaderComponent, { title: "Your order is confirmed!" }),
                    (0, i.jsx)(r.ModalHeaderComponent, {
                      subtitle: "We've got your shipping address. Your framed certificate is on its way.",
                    }),
                  ],
                }),
                (0, i.jsx)(a.ButtonComponent, {
                  size: "sm",
                  fullWidth: !0,
                  onClick: () => {
                    (n({ isModalVisible: !1, modalComponent: null }), e.push(s.EClientRoutes.REPORT));
                  },
                  text: "Done",
                }),
              ],
            });
          },
        ],
        864709,
      ));
  },
  39869,
  function (e) {
    e.n(e.i(864709));
  },
]);
