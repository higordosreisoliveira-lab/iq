(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  853754,
  319970,
  (e) => {
    "use strict";
    var t = e.i(436992);
    (e.s([], 853754), e.s(["DemoFooterComponent", () => t.default], 319970));
  },
  538318,
  (e) => {
    "use strict";
    e.s([
      "REVIEWS",
      0,
      [
        {
          id: "mirekiq",
          rating: 5,
          title: "ab_myiq_home_redesign_reviews_review1_title",
          body: "ab_myiq_home_redesign_reviews_review1_body",
          name: "Mirekiq",
          country: "ab_myiq_home_redesign_reviews_review1_country",
        },
        {
          id: "mbdaking",
          rating: 4,
          title: "ab_myiq_home_redesign_reviews_review2_title",
          body: "ab_myiq_home_redesign_reviews_review2_body",
          name: "Mbdaking",
          country: "ab_myiq_home_redesign_reviews_review2_country",
        },
        {
          id: "eb",
          rating: 5,
          title: "ab_myiq_home_redesign_reviews_review3_title",
          body: "ab_myiq_home_redesign_reviews_review3_body",
          name: "E.B.",
          country: "ab_myiq_home_redesign_reviews_review3_country",
        },
        {
          id: "col-done",
          rating: 4,
          title: "ab_myiq_home_redesign_reviews_review4_title",
          body: "ab_myiq_home_redesign_reviews_review4_body",
          name: "Col Done",
          country: "ab_myiq_home_redesign_reviews_review4_country",
        },
        {
          id: "d-horton",
          rating: 5,
          title: "ab_myiq_home_redesign_reviews_review5_title",
          body: "ab_myiq_home_redesign_reviews_review5_body",
          name: "D Horton",
          country: "ab_myiq_home_redesign_reviews_review5_country",
        },
        {
          id: "king-piper",
          rating: 3,
          title: "ab_myiq_home_redesign_reviews_review6_title",
          body: "ab_myiq_home_redesign_reviews_review6_body",
          name: "King Piper",
          country: "ab_myiq_home_redesign_reviews_review6_country",
        },
        {
          id: "stella",
          rating: 5,
          title: "ab_myiq_home_redesign_reviews_review7_title",
          body: "ab_myiq_home_redesign_reviews_review7_body",
          name: "Stella",
          country: "ab_myiq_home_redesign_reviews_review7_country",
        },
        {
          id: "cathy",
          rating: 4,
          title: "ab_myiq_home_redesign_reviews_review8_title",
          body: "ab_myiq_home_redesign_reviews_review8_body",
          name: "Cathy",
          country: "ab_myiq_home_redesign_reviews_review8_country",
        },
        {
          id: "gordon-stark",
          rating: 3,
          title: "ab_myiq_home_redesign_reviews_review9_title",
          body: "ab_myiq_home_redesign_reviews_review9_body",
          name: "Gordon Stark",
          country: "ab_myiq_home_redesign_reviews_review9_country",
        },
      ],
      "REVIEWS_BADGE",
      0,
      "ab_myiq_home_redesign_reviews_badge",
      "REVIEWS_FOOTER_COUNT",
      0,
      "ab_myiq_home_redesign_reviews_footer_count",
      "REVIEWS_FOOTER_MIDDLE",
      0,
      "ab_myiq_home_redesign_reviews_footer_middle",
      "REVIEWS_FOOTER_NOTE",
      0,
      "ab_myiq_home_redesign_reviews_footer_note",
      "REVIEWS_FOOTER_PREFIX",
      0,
      "ab_myiq_home_redesign_reviews_footer_prefix",
      "REVIEWS_FOOTER_SCORE",
      0,
      "4.1",
      "REVIEWS_LEDE",
      0,
      "ab_myiq_home_redesign_reviews_lede",
      "REVIEWS_NEXT_LABEL",
      0,
      "ab_myiq_home_redesign_reviews_next_label",
      "REVIEWS_PREV_LABEL",
      0,
      "ab_myiq_home_redesign_reviews_prev_label",
      "REVIEWS_TITLE",
      0,
      "ab_myiq_home_redesign_reviews_title",
      "REVIEWS_TRUSTPILOT_LABEL",
      0,
      "Trustpilot",
    ]);
  },
  371576,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(948148),
      r = e.i(271645),
      s = e.i(256889);
    e.i(365694);
    var n = e.i(283023);
    e.i(333163);
    var a = e.i(216839);
    e.i(600987);
    var o = e.i(752714),
      l = e.i(538318);
    let d =
      "absolute top-1/2 z-10 hidden size-10 -translate-y-1/2 items-center justify-center rounded-full bg-white text-black-custom shadow-rd-card ring-1 ring-black/[0.04] transition-opacity duration-200 lg:flex";
    e.s([
      "default",
      0,
      (e) => {
        let { translatedByKey: c } = e,
          m = (0, i.useTranslations)(),
          _ = (e) => c?.[e] ?? m(e),
          h = (0, r.useRef)(null),
          [u, v] = (0, r.useState)(!0),
          [b, g] = (0, r.useState)(!1),
          p = (0, r.useCallback)(() => {
            let e = h.current;
            e && (v(e.scrollLeft <= 4), g(e.scrollLeft >= e.scrollWidth - e.clientWidth - 4));
          }, []);
        (0, r.useEffect)(() => {
          let e = h.current;
          if (!e) return;
          let t = requestAnimationFrame(p);
          return (
            e.addEventListener("scroll", p, { passive: !0 }),
            window.addEventListener("resize", p),
            () => {
              (cancelAnimationFrame(t),
                e.removeEventListener("scroll", p),
                window.removeEventListener("resize", p));
            }
          );
        }, [p]);
        let x = (e) => {
          let t = h.current;
          if (!t) return;
          let i = t.firstElementChild,
            r = Number.parseFloat(getComputedStyle(t).columnGap) || 0,
            s = i ? i.offsetWidth + r : t.clientWidth,
            n = window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth";
          t.scrollBy({ left: e * s, behavior: n });
        };
        return (0, t.jsxs)("div", {
          className: "relative lg:px-14 2xl:px-0",
          children: [
            (0, t.jsx)("ul", {
              ref: h,
              className:
                "flex snap-x snap-mandatory gap-4 overflow-x-auto pb-1 [scrollbar-width:none] lg:gap-6 [&::-webkit-scrollbar]:hidden",
              children: l.REVIEWS.map((e) =>
                (0, t.jsx)(
                  "li",
                  {
                    className:
                      "w-[94%] shrink-0 snap-start xs-m:w-[85%] sm:w-[55%] md:w-[calc((100%-16px)/2)] lg:w-[calc((100%-48px)/3)]",
                    children: (0, t.jsx)(n.DemoCard, {
                      variant: "content",
                      children: (0, t.jsxs)("div", {
                        className: "grid h-full grid-rows-[auto_1fr_auto] gap-5",
                        children: [
                          (0, t.jsxs)("div", {
                            className: "flex items-center justify-between gap-3",
                            children: [
                              (0, t.jsx)(o.DemoStarsComponent, {
                                value: e.rating,
                                idSuffix: e.id,
                                className: "aspect-[27/5] h-5",
                              }),
                              (0, t.jsxs)("span", {
                                className:
                                  "inline-flex h-6 shrink-0 items-center gap-1 rounded-full bg-slate-100 px-2.5 text-hp-caption font-medium text-grey-deep",
                                children: [
                                  (0, t.jsx)(a.IconCheck, { className: "size-3 [stroke-width:2.5]" }),
                                  _(l.REVIEWS_BADGE),
                                ],
                              }),
                            ],
                          }),
                          (0, t.jsxs)("div", {
                            className: "flex flex-col gap-2",
                            children: [
                              (0, t.jsx)("h3", {
                                className: "text-balance text-hp-h4 text-black-custom",
                                children: _(e.title),
                              }),
                              (0, t.jsx)("p", {
                                className: "text-pretty text-hp-body-sm text-grey-deep",
                                children: _(e.body),
                              }),
                            ],
                          }),
                          (0, t.jsxs)("p", {
                            className: "text-hp-body-sm text-grey-deep",
                            children: [
                              (0, t.jsx)("span", {
                                className: "font-medium text-black-custom",
                                children: e.name,
                              }),
                              " · ",
                              _(e.country),
                            ],
                          }),
                        ],
                      }),
                    }),
                  },
                  e.id,
                ),
              ),
            }),
            (0, t.jsx)("button", {
              type: "button",
              "aria-label": _(l.REVIEWS_PREV_LABEL),
              onClick: () => x(-1),
              className: (0, s.cn)(
                d,
                "lg:left-2 2xl:-left-11",
                u ? "pointer-events-none opacity-0" : "opacity-100",
              ),
              children: (0, t.jsx)(a.IconChevronDown, { className: "size-4 rotate-90" }),
            }),
            (0, t.jsx)("button", {
              type: "button",
              "aria-label": _(l.REVIEWS_NEXT_LABEL),
              onClick: () => x(1),
              className: (0, s.cn)(
                d,
                "lg:right-2 2xl:-right-11",
                b ? "pointer-events-none opacity-0" : "opacity-100",
              ),
              children: (0, t.jsx)(a.IconChevronDown, { className: "size-4 -rotate-90" }),
            }),
          ],
        });
      },
    ]);
  },
  256889,
  (e) => {
    "use strict";
    e.s([
      "cn",
      0,
      function () {
        for (var e = arguments.length, t = Array(e), i = 0; i < e; i++) t[i] = arguments[i];
        return t.filter(Boolean).join(" ");
      },
    ]);
  },
  6437,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(271645),
      r = e.i(256889);
    e.s([
      "default",
      0,
      (e) => {
        let { items: s, split: n = !1, className: a, defaultOpenId: o = s[0]?.id ?? null } = e,
          l = n ? [s.slice(0, Math.ceil(s.length / 2)), s.slice(Math.ceil(s.length / 2))] : [s],
          [d, c] = (0, i.useState)(o);
        return (0, t.jsxs)(t.Fragment, {
          children: [
            (0, t.jsx)("div", {
              "data-demo-accordion": !0,
              className: (0, r.cn)(n && "grid grid-cols-1 items-start lg:grid-cols-2 lg:gap-x-16", a),
              children: l.map((e, i) =>
                (0, t.jsx)(
                  "div",
                  {
                    className: (0, r.cn)(
                      "divide-y divide-slate-100 border-y border-slate-100",
                      n && 1 === i && "border-t-0 lg:border-t",
                    ),
                    children: e.map((e) => {
                      let i = d === e.id;
                      return (0, t.jsxs)(
                        "div",
                        {
                          children: [
                            (0, t.jsx)("h3", {
                              children: (0, t.jsxs)("button", {
                                type: "button",
                                id: `${e.id}-trigger`,
                                "aria-expanded": i,
                                "aria-controls": `${e.id}-panel`,
                                onClick: () => c(i ? null : e.id),
                                className:
                                  "flex w-full items-center justify-between gap-4 rounded-lg py-4 text-start text-hp-lede text-black-custom focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom",
                                children: [
                                  e.question,
                                  (0, t.jsxs)("span", {
                                    "aria-hidden": !0,
                                    className: "relative size-4 shrink-0 text-black-custom",
                                    children: [
                                      (0, t.jsx)("span", {
                                        className:
                                          "absolute left-0 top-1/2 h-[1.5px] w-full -translate-y-1/2 rounded-full bg-current",
                                      }),
                                      (0, t.jsx)("span", {
                                        className: (0, r.cn)(
                                          "absolute left-1/2 top-0 h-full w-[1.5px] -translate-x-1/2 rounded-full bg-current transition-transform duration-200 motion-reduce:transition-none",
                                          i && "scale-y-0",
                                        ),
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            }),
                            (0, t.jsx)("div", {
                              id: `${e.id}-panel`,
                              role: "region",
                              "aria-labelledby": `${e.id}-trigger`,
                              className: (0, r.cn)(
                                "grid transition-[grid-template-rows] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] motion-reduce:transition-none",
                                i ? "grid-rows-[1fr]" : "grid-rows-[0fr]",
                              ),
                              children: (0, t.jsx)("div", {
                                className: "overflow-hidden",
                                children: (0, t.jsx)("p", {
                                  className: "text-pretty pb-6 text-hp-body text-grey-deep",
                                  children: e.answer,
                                }),
                              }),
                            }),
                          ],
                        },
                        e.id,
                      );
                    }),
                  },
                  e[0]?.id ?? i,
                ),
              ),
            }),
            (0, t.jsxs)("noscript", {
              children: [
                (0, t.jsx)("style", { children: "[data-demo-accordion]{display:none}" }),
                (0, t.jsx)("dl", {
                  className: (0, r.cn)("divide-y divide-slate-100 border-y border-slate-100", a),
                  children: s.map((e) =>
                    (0, t.jsxs)(
                      "div",
                      {
                        className: "py-4",
                        children: [
                          (0, t.jsx)("dt", {
                            className: "text-hp-lede text-black-custom",
                            children: e.question,
                          }),
                          (0, t.jsx)("dd", {
                            className: "mt-3 text-pretty text-hp-body text-grey-deep",
                            children: e.answer,
                          }),
                        ],
                      },
                      e.id,
                    ),
                  ),
                }),
              ],
            }),
          ],
        });
      },
    ]);
  },
  791371,
  642448,
  (e) => {
    "use strict";
    var t = e.i(843476);
    e.i(340609);
    var i = e.i(90147),
      r = e.i(256889);
    let s = { sm: "h-9 px-3 text-hp-body-sm", md: "h-11 px-5 text-hp-body-sm", lg: "h-12 px-6 text-hp-body" },
      n = {
        primary:
          "bg-green-custom text-white border-transparent [@media(hover:hover)]:hover:bg-[#0B635C] active:bg-[#094F4A]",
        secondary:
          "bg-white text-green-custom border-green-custom [@media(hover:hover)]:hover:bg-green-custom/[0.06] active:bg-green-custom/[0.10]",
        ghost:
          "bg-transparent text-grey-deep border-transparent [@media(hover:hover)]:hover:bg-black-custom/[0.04] [@media(hover:hover)]:hover:text-black-custom active:bg-black-custom/[0.06]",
        danger:
          "bg-danger-custom text-white border-transparent [@media(hover:hover)]:hover:bg-danger-custom/90 active:bg-danger-custom/80",
      },
      a = (0, t.jsx)(i.Spinner, { size: "sm", color: "current", "aria-hidden": "true" });
    (e.s([], 791371),
      e.s(
        [
          "DemoButton",
          0,
          (e) => {
            let {
                size: i = "md",
                variant: o = "primary",
                href: l,
                type: d,
                disabled: c,
                isLoading: m,
                dataNr: _,
                className: h,
                onClick: u,
                children: v,
              } = e,
              b = (0, r.cn)(
                "inline-flex items-center justify-center gap-2 shrink-0 select-none rounded-full border border-transparent font-medium whitespace-nowrap transition-colors duration-150 ease-[cubic-bezier(0.4,0,0.2,1)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom disabled:cursor-not-allowed disabled:opacity-50 [&_svg]:size-4 [&_svg]:shrink-0",
                s[i],
                n[o],
                h,
              );
            return l
              ? (0, t.jsx)("a", { href: l, className: b, onClick: u, "data-nr": _, children: v })
              : (0, t.jsxs)("button", {
                  type: d ?? "button",
                  disabled: c,
                  className: b,
                  onClick: u,
                  "data-nr": _,
                  "data-loading": m || void 0,
                  children: [m && a, v],
                });
          },
        ],
        642448,
      ));
  },
  365694,
  283023,
  600987,
  752714,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(256889);
    let r = {
      content: "flex h-full flex-col rounded-2xl border border-slate-200 bg-white p-5 lg:p-6",
      chip: "flex items-start gap-3 rounded-xl border border-slate-200 bg-white p-4",
      panel: "rounded-3xl bg-light-blue p-6 lg:p-10",
      vignette:
        "relative px-5 pb-5 lg:rounded-3xl lg:border lg:border-slate-200 lg:bg-white lg:p-6 lg:shadow-rd-card",
    };
    (e.s([], 365694),
      e.s(
        [
          "DemoCard",
          0,
          (e) => {
            let { variant: s = "content", interactive: n = !1, as: a = "div", className: o, children: l } = e;
            return (0, t.jsx)(a, {
              className: (0, i.cn)(
                r[s],
                n && "transition-colors duration-150 [@media(hover:hover)]:hover:border-slate-300",
                o,
              ),
              children: l,
            });
          },
        ],
        283023,
      ));
    let s = [0, 1, 2, 3, 4],
      n = s
        .map(
          (e) =>
            `M${10 + 22 * e} 3.5l1.55 4.77h4.95l-4.03 2.93 1.55 4.77-4.02-2.93-4.02 2.93 1.55-4.77-4.03-2.93h4.95z`,
        )
        .join(""),
      a = "#00b67a";
    (e.s([], 600987),
      e.s(
        [
          "DemoStarsComponent",
          0,
          (e) => {
            let { value: i, idSuffix: r, className: o } = e,
              l = `demo-stars-${r}`,
              d = Math.floor(i),
              c = Math.round((i % 1) * 2e3) / 100,
              m = 22 * d;
            return (0, t.jsxs)("svg", {
              viewBox: "0 0 108 20",
              preserveAspectRatio: "xMinYMid meet",
              role: "img",
              "aria-label": `Rated ${i} out of 5`,
              className: o,
              children: [
                s.map((e) =>
                  (0, t.jsx)(
                    "rect",
                    { x: 22 * e, width: "20", height: "20", rx: "2", fill: e < d ? a : "#DCDCE6" },
                    e,
                  ),
                ),
                c > 0 &&
                  d < s.length &&
                  (0, t.jsxs)(t.Fragment, {
                    children: [
                      (0, t.jsx)("clipPath", {
                        id: l,
                        children: (0, t.jsx)("rect", { x: m, width: c, height: "20" }),
                      }),
                      (0, t.jsx)("rect", {
                        x: m,
                        width: "20",
                        height: "20",
                        rx: "2",
                        fill: a,
                        clipPath: `url(#${l})`,
                      }),
                    ],
                  }),
                (0, t.jsx)("path", { d: n, fill: "#FFFFFF" }),
              ],
            });
          },
        ],
        752714,
      ));
  },
  872756,
  987132,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(256889);
    (e.s([], 872756),
      e.s(
        [
          "DemoContainer",
          0,
          (e) => {
            let { className: r, children: s } = e;
            return (0, t.jsx)("div", {
              className: (0, i.cn)("mx-auto w-full max-w-7xl px-4 md:px-6 lg:px-8", r),
              children: s,
            });
          },
        ],
        987132,
      ));
  },
  333163,
  216839,
  (e) => {
    "use strict";
    var t = e.i(843476);
    let i = {
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 1.5,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      "aria-hidden": !0,
    };
    (e.s(
      [
        "IconCheck",
        0,
        (e) => {
          let { className: r } = e;
          return (0, t.jsx)("svg", {
            ...i,
            className: r,
            children: (0, t.jsx)("path", { d: "M20 6 9 17l-5-5" }),
          });
        },
        "IconChevronDown",
        0,
        (e) => {
          let { className: r } = e;
          return (0, t.jsx)("svg", {
            ...i,
            className: r,
            children: (0, t.jsx)("path", { d: "m6 9 6 6 6-6" }),
          });
        },
        "IconClose",
        0,
        (e) => {
          let { className: r } = e;
          return (0, t.jsxs)("svg", {
            ...i,
            className: r,
            children: [(0, t.jsx)("path", { d: "m6 6 12 12" }), (0, t.jsx)("path", { d: "m18 6-12 12" })],
          });
        },
      ],
      216839,
    ),
      e.s([], 333163));
  },
  379551,
  90614,
  (e) => {
    "use strict";
    var t = e.i(271645);
    (e.s(
      [
        "useHeaderScroll",
        0,
        function () {
          let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 8,
            [i, r] = (0, t.useState)(!1);
          return (
            (0, t.useEffect)(() => {
              let t = () => {
                  r(window.scrollY > e);
                },
                i = requestAnimationFrame(t);
              return (
                window.addEventListener("scroll", t, { passive: !0 }),
                () => {
                  (cancelAnimationFrame(i), window.removeEventListener("scroll", t));
                }
              );
            }, [e]),
            i
          );
        },
      ],
      90614,
    ),
      e.s([], 379551));
  },
  833012,
  (e) => {
    "use strict";
    var t = e.i(770703);
    let i = (0, t.default)(() => e.A(891265), { loadableGenerated: { modules: [746398] } });
    ((0, t.default)(() => e.A(237841), { loadableGenerated: { modules: [932607] } }),
      e.s(["IqCertificateComponent", 0, i]));
  },
  237841,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/28265pioo2_-v.js"].map((t) => e.l(t))).then(() => t(932607)));
  },
  891265,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/2myhua2pk8h3h.js"].map((t) => e.l(t))).then(() => t(746398)));
  },
  117447,
  (e) => {
    "use strict";
    var t = e.i(271645);
    e.s([
      "useModalVh",
      0,
      () => {
        (0, t.useEffect)(() => {
          let e = () => {
            let e = 0.01 * window.innerHeight;
            document.documentElement.style.setProperty("--vh", `${e}px`);
          };
          e();
          let t = () => setTimeout(e, 100);
          return (
            window.addEventListener("resize", e),
            window.addEventListener("orientationchange", t),
            () => {
              (window.removeEventListener("resize", e), window.removeEventListener("orientationchange", t));
            }
          );
        }, []);
      },
    ]);
  },
  340609,
  90147,
  (e) => {
    "use strict";
    var t = e.i(23877);
    (e.s([], 340609), e.s(["Spinner", () => t.default], 90147));
  },
  23877,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(112041);
    e.s(["default", 0, (e) => (0, t.jsx)(i.Spinner, { ...e })]);
  },
]);
