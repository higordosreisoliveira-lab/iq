(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  175555,
  915823,
  (t) => {
    "use strict";
    var e = class {
      constructor() {
        ((this.listeners = new Set()), (this.subscribe = this.subscribe.bind(this)));
      }
      subscribe(t) {
        return (
          this.listeners.add(t),
          this.onSubscribe(),
          () => {
            (this.listeners.delete(t), this.onUnsubscribe());
          }
        );
      }
      hasListeners() {
        return this.listeners.size > 0;
      }
      onSubscribe() {}
      onUnsubscribe() {}
    };
    t.s(["Subscribable", 0, e], 915823);
    var i = t.i(619273),
      s = new (class extends e {
        #t;
        #e;
        #i;
        constructor() {
          (super(),
            (this.#i = (t) => {
              if (!i.isServer && window.addEventListener) {
                let e = () => t();
                return (
                  window.addEventListener("visibilitychange", e, !1),
                  () => {
                    window.removeEventListener("visibilitychange", e);
                  }
                );
              }
            }));
        }
        onSubscribe() {
          this.#e || this.setEventListener(this.#i);
        }
        onUnsubscribe() {
          this.hasListeners() || (this.#e?.(), (this.#e = void 0));
        }
        setEventListener(t) {
          ((this.#i = t),
            this.#e?.(),
            (this.#e = t((t) => {
              "boolean" == typeof t ? this.setFocused(t) : this.onFocus();
            })));
        }
        setFocused(t) {
          this.#t !== t && ((this.#t = t), this.onFocus());
        }
        onFocus() {
          let t = this.isFocused();
          this.listeners.forEach((e) => {
            e(t);
          });
        }
        isFocused() {
          return "boolean" == typeof this.#t ? this.#t : globalThis.document?.visibilityState !== "hidden";
        }
      })();
    t.s(["focusManager", 0, s], 175555);
  },
  372775,
  (t) => {
    "use strict";
    t.i(247167);
    var e = t.i(793803);
    function i(t) {
      return t;
    }
    t.s([
      "defaultShouldDehydrateQuery",
      0,
      function (t) {
        return "success" === t.state.status;
      },
      "hydrate",
      0,
      function (t, s, r) {
        if ("object" != typeof s || null === s) return;
        let a = t.getMutationCache(),
          n = t.getQueryCache(),
          o = r?.defaultOptions?.deserializeData ?? t.getDefaultOptions().hydrate?.deserializeData ?? i,
          u = s.mutations || [],
          l = s.queries || [];
        (u.forEach((e) => {
          let { state: i, ...s } = e;
          a.build(
            t,
            { ...t.getDefaultOptions().hydrate?.mutations, ...r?.defaultOptions?.mutations, ...s },
            i,
          );
        }),
          l.forEach((i) => {
            let { queryKey: s, state: a, queryHash: u, meta: l, promise: c, dehydratedAt: h } = i,
              p = c ? (0, e.tryResolveSync)(c) : void 0,
              d = void 0 === a.data ? p?.data : a.data,
              f = void 0 === d ? d : o(d),
              y = n.get(u),
              E = y?.state.status === "pending",
              T = y?.state.fetchStatus === "fetching";
            if (y) {
              let t = p && void 0 !== h && h > y.state.dataUpdatedAt;
              if (a.dataUpdatedAt > y.state.dataUpdatedAt || t) {
                let { fetchStatus: t, ...e } = a;
                y.setState({ ...e, data: f });
              }
            } else
              y = n.build(
                t,
                {
                  ...t.getDefaultOptions().hydrate?.queries,
                  ...r?.defaultOptions?.queries,
                  queryKey: s,
                  queryHash: u,
                  meta: l,
                },
                { ...a, data: f, fetchStatus: "idle", status: void 0 !== f ? "success" : a.status },
              );
            c &&
              !E &&
              !T &&
              (void 0 === h || h > y.state.dataUpdatedAt) &&
              y.fetch(void 0, { initialPromise: Promise.resolve(c).then(o) });
          }));
      },
    ]);
  },
  114272,
  (t) => {
    "use strict";
    var e = t.i(540143),
      i = t.i(88587),
      s = t.i(936553),
      r = class extends i.Removable {
        #s;
        #r;
        #a;
        #n;
        constructor(t) {
          (super(),
            (this.#s = t.client),
            (this.mutationId = t.mutationId),
            (this.#a = t.mutationCache),
            (this.#r = []),
            (this.state = t.state || a()),
            this.setOptions(t.options),
            this.scheduleGc());
        }
        setOptions(t) {
          ((this.options = t), this.updateGcTime(this.options.gcTime));
        }
        get meta() {
          return this.options.meta;
        }
        addObserver(t) {
          this.#r.includes(t) ||
            (this.#r.push(t),
            this.clearGcTimeout(),
            this.#a.notify({ type: "observerAdded", mutation: this, observer: t }));
        }
        removeObserver(t) {
          ((this.#r = this.#r.filter((e) => e !== t)),
            this.scheduleGc(),
            this.#a.notify({ type: "observerRemoved", mutation: this, observer: t }));
        }
        optionalRemove() {
          this.#r.length || ("pending" === this.state.status ? this.scheduleGc() : this.#a.remove(this));
        }
        continue() {
          return this.#n?.continue() ?? this.execute(this.state.variables);
        }
        async execute(t) {
          let e = () => {
              this.#o({ type: "continue" });
            },
            i = { client: this.#s, meta: this.options.meta, mutationKey: this.options.mutationKey };
          this.#n = (0, s.createRetryer)({
            fn: () =>
              this.options.mutationFn
                ? this.options.mutationFn(t, i)
                : Promise.reject(Error("No mutationFn found")),
            onFail: (t, e) => {
              this.#o({ type: "failed", failureCount: t, error: e });
            },
            onPause: () => {
              this.#o({ type: "pause" });
            },
            onContinue: e,
            retry: this.options.retry ?? 0,
            retryDelay: this.options.retryDelay,
            networkMode: this.options.networkMode,
            canRun: () => this.#a.canRun(this),
          });
          let r = "pending" === this.state.status,
            a = !this.#n.canStart();
          try {
            if (r) e();
            else {
              (this.#o({ type: "pending", variables: t, isPaused: a }),
                await this.#a.config.onMutate?.(t, this, i));
              let e = await this.options.onMutate?.(t, i);
              e !== this.state.context && this.#o({ type: "pending", context: e, variables: t, isPaused: a });
            }
            let s = await this.#n.start();
            return (
              await this.#a.config.onSuccess?.(s, t, this.state.context, this, i),
              await this.options.onSuccess?.(s, t, this.state.context, i),
              await this.#a.config.onSettled?.(s, null, this.state.variables, this.state.context, this, i),
              await this.options.onSettled?.(s, null, t, this.state.context, i),
              this.#o({ type: "success", data: s }),
              s
            );
          } catch (e) {
            try {
              throw (
                await this.#a.config.onError?.(e, t, this.state.context, this, i),
                await this.options.onError?.(e, t, this.state.context, i),
                await this.#a.config.onSettled?.(
                  void 0,
                  e,
                  this.state.variables,
                  this.state.context,
                  this,
                  i,
                ),
                await this.options.onSettled?.(void 0, e, t, this.state.context, i),
                e
              );
            } finally {
              this.#o({ type: "error", error: e });
            }
          } finally {
            this.#a.runNext(this);
          }
        }
        #o(t) {
          ((this.state = ((e) => {
            switch (t.type) {
              case "failed":
                return { ...e, failureCount: t.failureCount, failureReason: t.error };
              case "pause":
                return { ...e, isPaused: !0 };
              case "continue":
                return { ...e, isPaused: !1 };
              case "pending":
                return {
                  ...e,
                  context: t.context,
                  data: void 0,
                  failureCount: 0,
                  failureReason: null,
                  error: null,
                  isPaused: t.isPaused,
                  status: "pending",
                  variables: t.variables,
                  submittedAt: Date.now(),
                };
              case "success":
                return {
                  ...e,
                  data: t.data,
                  failureCount: 0,
                  failureReason: null,
                  error: null,
                  status: "success",
                  isPaused: !1,
                };
              case "error":
                return {
                  ...e,
                  data: void 0,
                  error: t.error,
                  failureCount: e.failureCount + 1,
                  failureReason: t.error,
                  isPaused: !1,
                  status: "error",
                };
            }
          })(this.state)),
            e.notifyManager.batch(() => {
              (this.#r.forEach((e) => {
                e.onMutationUpdate(t);
              }),
                this.#a.notify({ mutation: this, type: "updated", action: t }));
            }));
        }
      };
    function a() {
      return {
        context: void 0,
        data: void 0,
        error: null,
        failureCount: 0,
        failureReason: null,
        isPaused: !1,
        status: "idle",
        variables: void 0,
        submittedAt: 0,
      };
    }
    t.s(["Mutation", 0, r, "getDefaultState", 0, a]);
  },
  540143,
  (t) => {
    "use strict";
    let e, i, s, r, a, n;
    var o = t.i(180166).systemSetTimeoutZero,
      u =
        ((e = []),
        (i = 0),
        (s = (t) => {
          t();
        }),
        (r = (t) => {
          t();
        }),
        (a = o),
        {
          batch: (t) => {
            let n;
            i++;
            try {
              n = t();
            } finally {
              let t;
              --i ||
                ((t = e),
                (e = []),
                t.length &&
                  a(() => {
                    r(() => {
                      t.forEach((t) => {
                        s(t);
                      });
                    });
                  }));
            }
            return n;
          },
          batchCalls: (t) =>
            function () {
              for (var e = arguments.length, i = Array(e), s = 0; s < e; s++) i[s] = arguments[s];
              n(() => {
                t(...i);
              });
            },
          schedule: (n = (t) => {
            i
              ? e.push(t)
              : a(() => {
                  s(t);
                });
          }),
          setNotifyFunction: (t) => {
            s = t;
          },
          setBatchNotifyFunction: (t) => {
            r = t;
          },
          setScheduler: (t) => {
            a = t;
          },
        });
    t.s(["notifyManager", 0, u]);
  },
  286491,
  (t) => {
    "use strict";
    t.i(247167);
    var e = t.i(619273),
      i = t.i(540143),
      s = t.i(936553),
      r = t.i(88587),
      a = class extends r.Removable {
        #u;
        #l;
        #c;
        #s;
        #n;
        #h;
        #p;
        constructor(t) {
          (super(),
            (this.#p = !1),
            (this.#h = t.defaultOptions),
            this.setOptions(t.options),
            (this.observers = []),
            (this.#s = t.client),
            (this.#c = this.#s.getQueryCache()),
            (this.queryKey = t.queryKey),
            (this.queryHash = t.queryHash),
            (this.#u = o(this.options)),
            (this.state = t.state ?? this.#u),
            this.scheduleGc());
        }
        get meta() {
          return this.options.meta;
        }
        get promise() {
          return this.#n?.promise;
        }
        setOptions(t) {
          if (
            ((this.options = { ...this.#h, ...t }),
            this.updateGcTime(this.options.gcTime),
            this.state && void 0 === this.state.data)
          ) {
            let t = o(this.options);
            void 0 !== t.data &&
              (this.setData(t.data, { updatedAt: t.dataUpdatedAt, manual: !0 }), (this.#u = t));
          }
        }
        optionalRemove() {
          this.observers.length || "idle" !== this.state.fetchStatus || this.#c.remove(this);
        }
        setData(t, i) {
          let s = (0, e.replaceData)(this.state.data, t, this.options);
          return (this.#o({ data: s, type: "success", dataUpdatedAt: i?.updatedAt, manual: i?.manual }), s);
        }
        setState(t, e) {
          this.#o({ type: "setState", state: t, setStateOptions: e });
        }
        cancel(t) {
          let i = this.#n?.promise;
          return (this.#n?.cancel(t), i ? i.then(e.noop).catch(e.noop) : Promise.resolve());
        }
        destroy() {
          (super.destroy(), this.cancel({ silent: !0 }));
        }
        reset() {
          (this.destroy(), this.setState(this.#u));
        }
        isActive() {
          return this.observers.some((t) => !1 !== (0, e.resolveEnabled)(t.options.enabled, this));
        }
        isDisabled() {
          return this.getObserversCount() > 0
            ? !this.isActive()
            : this.options.queryFn === e.skipToken ||
                this.state.dataUpdateCount + this.state.errorUpdateCount === 0;
        }
        isStatic() {
          return (
            this.getObserversCount() > 0 &&
            this.observers.some((t) => "static" === (0, e.resolveStaleTime)(t.options.staleTime, this))
          );
        }
        isStale() {
          return this.getObserversCount() > 0
            ? this.observers.some((t) => t.getCurrentResult().isStale)
            : void 0 === this.state.data || this.state.isInvalidated;
        }
        isStaleByTime() {
          let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
          return (
            void 0 === this.state.data ||
            ("static" !== t &&
              (!!this.state.isInvalidated || !(0, e.timeUntilStale)(this.state.dataUpdatedAt, t)))
          );
        }
        onFocus() {
          let t = this.observers.find((t) => t.shouldFetchOnWindowFocus());
          (t?.refetch({ cancelRefetch: !1 }), this.#n?.continue());
        }
        onOnline() {
          let t = this.observers.find((t) => t.shouldFetchOnReconnect());
          (t?.refetch({ cancelRefetch: !1 }), this.#n?.continue());
        }
        addObserver(t) {
          this.observers.includes(t) ||
            (this.observers.push(t),
            this.clearGcTimeout(),
            this.#c.notify({ type: "observerAdded", query: this, observer: t }));
        }
        removeObserver(t) {
          this.observers.includes(t) &&
            ((this.observers = this.observers.filter((e) => e !== t)),
            this.observers.length ||
              (this.#n && (this.#p ? this.#n.cancel({ revert: !0 }) : this.#n.cancelRetry()),
              this.scheduleGc()),
            this.#c.notify({ type: "observerRemoved", query: this, observer: t }));
        }
        getObserversCount() {
          return this.observers.length;
        }
        invalidate() {
          this.state.isInvalidated || this.#o({ type: "invalidate" });
        }
        async fetch(t, i) {
          let r;
          if ("idle" !== this.state.fetchStatus && this.#n?.status() !== "rejected") {
            if (void 0 !== this.state.data && i?.cancelRefetch) this.cancel({ silent: !0 });
            else if (this.#n) return (this.#n.continueRetry(), this.#n.promise);
          }
          if ((t && this.setOptions(t), !this.options.queryFn)) {
            let t = this.observers.find((t) => t.options.queryFn);
            t && this.setOptions(t.options);
          }
          let a = new AbortController(),
            n = (t) => {
              Object.defineProperty(t, "signal", { enumerable: !0, get: () => ((this.#p = !0), a.signal) });
            },
            o = () => {
              let t,
                s = (0, e.ensureQueryFn)(this.options, i),
                r = (n((t = { client: this.#s, queryKey: this.queryKey, meta: this.meta })), t);
              return ((this.#p = !1), this.options.persister) ? this.options.persister(s, r, this) : s(r);
            },
            u =
              (n(
                (r = {
                  fetchOptions: i,
                  options: this.options,
                  queryKey: this.queryKey,
                  client: this.#s,
                  state: this.state,
                  fetchFn: o,
                }),
              ),
              r);
          (this.options.behavior?.onFetch(u, this),
            (this.#l = this.state),
            ("idle" === this.state.fetchStatus || this.state.fetchMeta !== u.fetchOptions?.meta) &&
              this.#o({ type: "fetch", meta: u.fetchOptions?.meta }),
            (this.#n = (0, s.createRetryer)({
              initialPromise: i?.initialPromise,
              fn: u.fetchFn,
              onCancel: (t) => {
                (t instanceof s.CancelledError &&
                  t.revert &&
                  this.setState({ ...this.#l, fetchStatus: "idle" }),
                  a.abort());
              },
              onFail: (t, e) => {
                this.#o({ type: "failed", failureCount: t, error: e });
              },
              onPause: () => {
                this.#o({ type: "pause" });
              },
              onContinue: () => {
                this.#o({ type: "continue" });
              },
              retry: u.options.retry,
              retryDelay: u.options.retryDelay,
              networkMode: u.options.networkMode,
              canRun: () => !0,
            })));
          try {
            let t = await this.#n.start();
            if (void 0 === t) throw Error(`${this.queryHash} data is undefined`);
            return (
              this.setData(t),
              this.#c.config.onSuccess?.(t, this),
              this.#c.config.onSettled?.(t, this.state.error, this),
              t
            );
          } catch (t) {
            if (t instanceof s.CancelledError) {
              if (t.silent) return this.#n.promise;
              else if (t.revert) {
                if (void 0 === this.state.data) throw t;
                return this.state.data;
              }
            }
            throw (
              this.#o({ type: "error", error: t }),
              this.#c.config.onError?.(t, this),
              this.#c.config.onSettled?.(this.state.data, t, this),
              t
            );
          } finally {
            this.scheduleGc();
          }
        }
        #o(t) {
          let e = (e) => {
            switch (t.type) {
              case "failed":
                return { ...e, fetchFailureCount: t.failureCount, fetchFailureReason: t.error };
              case "pause":
                return { ...e, fetchStatus: "paused" };
              case "continue":
                return { ...e, fetchStatus: "fetching" };
              case "fetch":
                return { ...e, ...n(e.data, this.options), fetchMeta: t.meta ?? null };
              case "success":
                let i = {
                  ...e,
                  data: t.data,
                  dataUpdateCount: e.dataUpdateCount + 1,
                  dataUpdatedAt: t.dataUpdatedAt ?? Date.now(),
                  error: null,
                  isInvalidated: !1,
                  status: "success",
                  ...(!t.manual && { fetchStatus: "idle", fetchFailureCount: 0, fetchFailureReason: null }),
                };
                return ((this.#l = t.manual ? i : void 0), i);
              case "error":
                let s = t.error;
                return {
                  ...e,
                  error: s,
                  errorUpdateCount: e.errorUpdateCount + 1,
                  errorUpdatedAt: Date.now(),
                  fetchFailureCount: e.fetchFailureCount + 1,
                  fetchFailureReason: s,
                  fetchStatus: "idle",
                  status: "error",
                };
              case "invalidate":
                return { ...e, isInvalidated: !0 };
              case "setState":
                return { ...e, ...t.state };
            }
          };
          ((this.state = e(this.state)),
            i.notifyManager.batch(() => {
              (this.observers.forEach((t) => {
                t.onQueryUpdate();
              }),
                this.#c.notify({ query: this, type: "updated", action: t }));
            }));
        }
      };
    function n(t, e) {
      return {
        fetchFailureCount: 0,
        fetchFailureReason: null,
        fetchStatus: (0, s.canFetch)(e.networkMode) ? "fetching" : "paused",
        ...(void 0 === t && { error: null, status: "pending" }),
      };
    }
    function o(t) {
      let e = "function" == typeof t.initialData ? t.initialData() : t.initialData,
        i = void 0 !== e,
        s = i
          ? "function" == typeof t.initialDataUpdatedAt
            ? t.initialDataUpdatedAt()
            : t.initialDataUpdatedAt
          : 0;
      return {
        data: e,
        dataUpdateCount: 0,
        dataUpdatedAt: i ? (s ?? Date.now()) : 0,
        error: null,
        errorUpdateCount: 0,
        errorUpdatedAt: 0,
        fetchFailureCount: 0,
        fetchFailureReason: null,
        fetchMeta: null,
        isInvalidated: !1,
        status: i ? "success" : "pending",
        fetchStatus: "idle",
      };
    }
    t.s(["Query", 0, a, "fetchState", 0, n]);
  },
  88587,
  (t) => {
    "use strict";
    var e = t.i(180166),
      i = t.i(619273),
      s = class {
        #d;
        destroy() {
          this.clearGcTimeout();
        }
        scheduleGc() {
          (this.clearGcTimeout(),
            (0, i.isValidTimeout)(this.gcTime) &&
              (this.#d = e.timeoutManager.setTimeout(() => {
                this.optionalRemove();
              }, this.gcTime)));
        }
        updateGcTime(t) {
          this.gcTime = Math.max(this.gcTime || 0, t ?? (i.isServer ? 1 / 0 : 3e5));
        }
        clearGcTimeout() {
          this.#d && (e.timeoutManager.clearTimeout(this.#d), (this.#d = void 0));
        }
      };
    t.s(["Removable", 0, s]);
  },
  936553,
  814448,
  (t) => {
    "use strict";
    var e = t.i(175555),
      i = t.i(915823),
      s = t.i(619273),
      r = new (class extends i.Subscribable {
        #f = !0;
        #e;
        #i;
        constructor() {
          (super(),
            (this.#i = (t) => {
              if (!s.isServer && window.addEventListener) {
                let e = () => t(!0),
                  i = () => t(!1);
                return (
                  window.addEventListener("online", e, !1),
                  window.addEventListener("offline", i, !1),
                  () => {
                    (window.removeEventListener("online", e), window.removeEventListener("offline", i));
                  }
                );
              }
            }));
        }
        onSubscribe() {
          this.#e || this.setEventListener(this.#i);
        }
        onUnsubscribe() {
          this.hasListeners() || (this.#e?.(), (this.#e = void 0));
        }
        setEventListener(t) {
          ((this.#i = t), this.#e?.(), (this.#e = t(this.setOnline.bind(this))));
        }
        setOnline(t) {
          this.#f !== t &&
            ((this.#f = t),
            this.listeners.forEach((e) => {
              e(t);
            }));
        }
        isOnline() {
          return this.#f;
        }
      })();
    t.s(["onlineManager", 0, r], 814448);
    var a = t.i(793803);
    function n(t) {
      return Math.min(1e3 * 2 ** t, 3e4);
    }
    function o(t) {
      return (t ?? "online") !== "online" || r.isOnline();
    }
    var u = class extends Error {
      constructor(t) {
        (super("CancelledError"), (this.revert = t?.revert), (this.silent = t?.silent));
      }
    };
    t.s(
      [
        "CancelledError",
        0,
        u,
        "canFetch",
        0,
        o,
        "createRetryer",
        0,
        function (t) {
          let i,
            l = !1,
            c = 0,
            h = (0, a.pendingThenable)(),
            p = () =>
              e.focusManager.isFocused() && ("always" === t.networkMode || r.isOnline()) && t.canRun(),
            d = () => o(t.networkMode) && t.canRun(),
            f = (t) => {
              "pending" === h.status && (i?.(), h.resolve(t));
            },
            y = (t) => {
              "pending" === h.status && (i?.(), h.reject(t));
            },
            E = () =>
              new Promise((e) => {
                ((i = (t) => {
                  ("pending" !== h.status || p()) && e(t);
                }),
                  t.onPause?.());
              }).then(() => {
                ((i = void 0), "pending" === h.status && t.onContinue?.());
              }),
            T = () => {
              let e;
              if ("pending" !== h.status) return;
              let i = 0 === c ? t.initialPromise : void 0;
              try {
                e = i ?? t.fn();
              } catch (t) {
                e = Promise.reject(t);
              }
              Promise.resolve(e)
                .then(f)
                .catch((e) => {
                  if ("pending" !== h.status) return;
                  let i = t.retry ?? 3 * !s.isServer,
                    r = t.retryDelay ?? n,
                    a = "function" == typeof r ? r(c, e) : r,
                    o = !0 === i || ("number" == typeof i && c < i) || ("function" == typeof i && i(c, e));
                  l || !o
                    ? y(e)
                    : (c++,
                      t.onFail?.(c, e),
                      (0, s.sleep)(a)
                        .then(() => (p() ? void 0 : E()))
                        .then(() => {
                          l ? y(e) : T();
                        }));
                });
            };
          return {
            promise: h,
            status: () => h.status,
            cancel: (e) => {
              if ("pending" === h.status) {
                let i = new u(e);
                (y(i), t.onCancel?.(i));
              }
            },
            continue: () => (i?.(), h),
            cancelRetry: () => {
              l = !0;
            },
            continueRetry: () => {
              l = !1;
            },
            canStart: d,
            start: () => (d() ? T() : E().then(T), h),
          };
        },
      ],
      936553,
    );
  },
  793803,
  180166,
  619273,
  (t) => {
    "use strict";
    var e = {
        setTimeout: (t, e) => setTimeout(t, e),
        clearTimeout: (t) => clearTimeout(t),
        setInterval: (t, e) => setInterval(t, e),
        clearInterval: (t) => clearInterval(t),
      },
      i = new (class {
        #y = e;
        #E = !1;
        setTimeoutProvider(t) {
          this.#y = t;
        }
        setTimeout(t, e) {
          return this.#y.setTimeout(t, e);
        }
        clearTimeout(t) {
          this.#y.clearTimeout(t);
        }
        setInterval(t, e) {
          return this.#y.setInterval(t, e);
        }
        clearInterval(t) {
          this.#y.clearInterval(t);
        }
      })();
    t.s(
      [
        "systemSetTimeoutZero",
        0,
        function (t) {
          setTimeout(t, 0);
        },
        "timeoutManager",
        0,
        i,
      ],
      180166,
    );
    var s = "u" < typeof window || "Deno" in globalThis;
    function r() {}
    function a(t, e) {
      return (e?.queryKeyHashFn || n)(t);
    }
    function n(t) {
      return JSON.stringify(t, (t, e) =>
        h(e)
          ? Object.keys(e)
              .sort()
              .reduce((t, i) => ((t[i] = e[i]), t), {})
          : e,
      );
    }
    function o(t, e) {
      return (
        t === e ||
        (typeof t == typeof e &&
          !!t &&
          !!e &&
          "object" == typeof t &&
          "object" == typeof e &&
          Object.keys(e).every((i) => o(t[i], e[i])))
      );
    }
    var u = Object.prototype.hasOwnProperty;
    function l(t, e) {
      if (t === e) return t;
      let i = c(t) && c(e);
      if (!i && !(h(t) && h(e))) return e;
      let s = (i ? t : Object.keys(t)).length,
        r = i ? e : Object.keys(e),
        a = r.length,
        n = i ? Array(a) : {},
        o = 0;
      for (let c = 0; c < a; c++) {
        let a = i ? c : r[c],
          h = t[a],
          p = e[a];
        if (h === p) {
          ((n[a] = h), (i ? c < s : u.call(t, a)) && o++);
          continue;
        }
        if (null === h || null === p || "object" != typeof h || "object" != typeof p) {
          n[a] = p;
          continue;
        }
        let d = l(h, p);
        ((n[a] = d), d === h && o++);
      }
      return s === a && o === s ? t : n;
    }
    function c(t) {
      return Array.isArray(t) && t.length === Object.keys(t).length;
    }
    function h(t) {
      if (!p(t)) return !1;
      let e = t.constructor;
      if (void 0 === e) return !0;
      let i = e.prototype;
      return !!p(i) && !!i.hasOwnProperty("isPrototypeOf") && Object.getPrototypeOf(t) === Object.prototype;
    }
    function p(t) {
      return "[object Object]" === Object.prototype.toString.call(t);
    }
    var d = Symbol();
    (t.s(
      [
        "addToEnd",
        0,
        function (t, e) {
          let i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
            s = [...t, e];
          return i && s.length > i ? s.slice(1) : s;
        },
        "addToStart",
        0,
        function (t, e) {
          let i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
            s = [e, ...t];
          return i && s.length > i ? s.slice(0, -1) : s;
        },
        "ensureQueryFn",
        0,
        function (t, e) {
          return !t.queryFn && e?.initialPromise
            ? () => e.initialPromise
            : t.queryFn && t.queryFn !== d
              ? t.queryFn
              : () => Promise.reject(Error(`Missing queryFn: '${t.queryHash}'`));
        },
        "functionalUpdate",
        0,
        function (t, e) {
          return "function" == typeof t ? t(e) : t;
        },
        "hashKey",
        0,
        n,
        "hashQueryKeyByOptions",
        0,
        a,
        "isServer",
        0,
        s,
        "isValidTimeout",
        0,
        function (t) {
          return "number" == typeof t && t >= 0 && t !== 1 / 0;
        },
        "keepPreviousData",
        0,
        function (t) {
          return t;
        },
        "matchMutation",
        0,
        function (t, e) {
          let { exact: i, status: s, predicate: r, mutationKey: a } = t;
          if (a) {
            if (!e.options.mutationKey) return !1;
            if (i) {
              if (n(e.options.mutationKey) !== n(a)) return !1;
            } else if (!o(e.options.mutationKey, a)) return !1;
          }
          return (!s || e.state.status === s) && (!r || !!r(e));
        },
        "matchQuery",
        0,
        function (t, e) {
          let { type: i = "all", exact: s, fetchStatus: r, predicate: n, queryKey: u, stale: l } = t;
          if (u) {
            if (s) {
              if (e.queryHash !== a(u, e.options)) return !1;
            } else if (!o(e.queryKey, u)) return !1;
          }
          if ("all" !== i) {
            let t = e.isActive();
            if (("active" === i && !t) || ("inactive" === i && t)) return !1;
          }
          return (
            ("boolean" != typeof l || e.isStale() === l) &&
            (!r || r === e.state.fetchStatus) &&
            (!n || !!n(e))
          );
        },
        "noop",
        0,
        r,
        "partialMatchKey",
        0,
        o,
        "replaceData",
        0,
        function (t, e, i) {
          return "function" == typeof i.structuralSharing
            ? i.structuralSharing(t, e)
            : !1 !== i.structuralSharing
              ? l(t, e)
              : e;
        },
        "replaceEqualDeep",
        0,
        l,
        "resolveEnabled",
        0,
        function (t, e) {
          return "function" == typeof t ? t(e) : t;
        },
        "resolveStaleTime",
        0,
        function (t, e) {
          return "function" == typeof t ? t(e) : t;
        },
        "shallowEqualObjects",
        0,
        function (t, e) {
          if (!e || Object.keys(t).length !== Object.keys(e).length) return !1;
          for (let i in t) if (t[i] !== e[i]) return !1;
          return !0;
        },
        "shouldThrowError",
        0,
        function (t, e) {
          return "function" == typeof t ? t(...e) : !!t;
        },
        "skipToken",
        0,
        d,
        "sleep",
        0,
        function (t) {
          return new Promise((e) => {
            i.setTimeout(e, t);
          });
        },
        "timeUntilStale",
        0,
        function (t, e) {
          return Math.max(t + (e || 0) - Date.now(), 0);
        },
      ],
      619273,
    ),
      t.s(
        [
          "pendingThenable",
          0,
          function () {
            let t,
              e,
              i = new Promise((i, s) => {
                ((t = i), (e = s));
              });
            function s(t) {
              (Object.assign(i, t), delete i.resolve, delete i.reject);
            }
            return (
              (i.status = "pending"),
              i.catch(() => {}),
              (i.resolve = (e) => {
                (s({ status: "fulfilled", value: e }), t(e));
              }),
              (i.reject = (t) => {
                (s({ status: "rejected", reason: t }), e(t));
              }),
              i
            );
          },
          "tryResolveSync",
          0,
          function (t) {
            let e;
            if ((t.then((t) => ((e = t), t), r)?.catch(r), void 0 !== e)) return { data: e };
          },
        ],
        793803,
      ));
  },
  912598,
  (t) => {
    "use strict";
    var e = t.i(271645),
      i = t.i(843476),
      s = e.createContext(void 0);
    t.s([
      "QueryClientContext",
      0,
      s,
      "QueryClientProvider",
      0,
      (t) => {
        let { client: r, children: a } = t;
        return (
          e.useEffect(
            () => (
              r.mount(),
              () => {
                r.unmount();
              }
            ),
            [r],
          ),
          (0, i.jsx)(s.Provider, { value: r, children: a })
        );
      },
      "useQueryClient",
      0,
      (t) => {
        let i = e.useContext(s);
        if (t) return t;
        if (!i) throw Error("No QueryClient set, use QueryClientProvider to set one");
        return i;
      },
    ]);
  },
  134404,
  (t) => {
    "use strict";
    var e,
      i,
      s,
      r,
      a,
      n =
        (((e = {}).BASE = "/"),
        (e.BASE_PROFILE = "/profile"),
        (e.START = "/start"),
        (e.START_PROFILE = "/profile/start"),
        (e.START_AD = "/start/ad"),
        (e.START_PERSONALITY = "/start/personality-test"),
        (e.START_PERSONALITY_PROFILE = "/profile/start/personality-test"),
        (e.START_LOVE = "/start/love-language"),
        (e.START_LOVE_PROFILE = "/profile/start/love-language"),
        (e.START_POLITICAL_COMPASS_PROFILE = "/profile/start/political-compass"),
        (e.START_ADHD = "/profile/start/adhd-test"),
        (e.START_ATTACHMENT = "/profile/start/attachment-style"),
        (e.START_PROCRASTINATION = "/profile/start/procrastination-test"),
        (e.START_CAREERS = "/profile/start/career-test"),
        (e.START_ANXIETY = "/profile/start/anxiety-test"),
        (e.START_CONFIDENCE = "/profile/start/self-confidence-test"),
        (e.START_STRENGTHS = "/profile/start/hidden-strengths-test"),
        (e.START_WORK = "/profile/start/work-test"),
        (e.START_BURNOUT = "/profile/start/burnout-test"),
        (e.START_EMOTIONAL = "/profile/start/emotional-test"),
        (e.START_DEPRESSION = "/profile/start/depression-test"),
        (e.START_TIME_MANAGEMENT = "/profile/start/time-management"),
        (e.START_IMPOSTER_SYNDROME = "/profile/start/imposter-syndrome"),
        (e.START_PSYCHOLOGICAL_ARCHETYPES = "/profile/start/psychological-archetypes"),
        (e.START_TRIVIA = "/profile/start/trivia-test"),
        (e.START_ENNEAGRAM = "/start/enneagram-test"),
        (e.QUIZ_ENNEAGRAM = "/quiz/enneagram-test"),
        (e.QUIZ_ANALYZING_ENNEAGRAM = "/analyzing/enneagram-test"),
        (e.EMAIL_ENNEAGRAM = "/email/enneagram-test"),
        (e.CHECKOUT_ENNEAGRAM = "/checkout/enneagram-test"),
        (e.REPORT_ENNEAGRAM = "/profile/report/enneagram"),
        (e.START_DEPRESSION_FUNNEL = "/start/depression-test"),
        (e.QUIZ_DEPRESSION_FUNNEL = "/quiz/depression-test"),
        (e.QUIZ_ANALYZING_DEPRESSION_FUNNEL = "/analyzing/depression-test"),
        (e.EMAIL_DEPRESSION_FUNNEL = "/email/depression-test"),
        (e.CHECKOUT_DEPRESSION_FUNNEL = "/checkout/depression-test"),
        (e.REPORT_DEPRESSION_FUNNEL = "/profile/report/depression"),
        (e.START_AUTISM = "/start/autism-test"),
        (e.QUIZ_AUTISM = "/quiz/autism-test"),
        (e.QUIZ_ANALYZING_AUTISM = "/analyzing/autism-test"),
        (e.EMAIL_AUTISM = "/email/autism-test"),
        (e.CHECKOUT_AUTISM = "/checkout/autism-test"),
        (e.REPORT_AUTISM = "/profile/report/autism"),
        (e.QUIZ = "/quiz"),
        (e.QUIZ_PROFILE = "/profile/quiz"),
        (e.QUIZ_PERSONALITY = "/quiz/personality-test"),
        (e.QUIZ_LOVE = "/quiz/love-language"),
        (e.QUIZ_PERSONALITY_PROFILE = "/profile/quiz/personality-test"),
        (e.QUIZ_LOVE_PROFILE = "/profile/quiz/love-language"),
        (e.QUIZ_POLITICAL_COMPASS_PROFILE = "/profile/quiz/political-compass"),
        (e.QUIZ_ATTACHMENT = "/profile/quiz/attachment-style"),
        (e.QUIZ_ADHD = "/profile/quiz/adhd-test"),
        (e.QUIZ_PROCRASTINATION = "/profile/quiz/procrastination-test"),
        (e.QUIZ_CAREERS = "/profile/quiz/career-test"),
        (e.QUIZ_WORK = "/profile/quiz/work-test"),
        (e.QUIZ_BURNOUT = "/profile/quiz/burnout-test"),
        (e.QUIZ_EMOTIONAL = "/profile/quiz/emotional-test"),
        (e.QUIZ_DEPRESSION = "/profile/quiz/depression-test"),
        (e.QUIZ_IMPOSTER_SYNDROME = "/profile/quiz/imposter-syndrome"),
        (e.QUIZ_PSYCHOLOGICAL_ARCHETYPES = "/profile/quiz/psychological-archetypes"),
        (e.QUIZ_ANXIETY = "/profile/quiz/anxiety-test"),
        (e.QUIZ_CONFIDENCE = "/profile/quiz/self-confidence-test"),
        (e.QUIZ_STRENGTHS = "/profile/quiz/hidden-strengths-test"),
        (e.QUIZ_TIME_MANAGEMENT = "/profile/quiz/time-management"),
        (e.QUIZ_TRIVIA = "/profile/quiz/trivia-test"),
        (e.QUIZ_ANALYZING = "/analyzing"),
        (e.QUIZ_ANALYZING_PROFILE = "/profile/analyzing"),
        (e.QUIZ_ANALYZING_PERSONALITY = "/analyzing/personality-test"),
        (e.QUIZ_ANALYZING_PERSONALITY_PROFILE = "/profile/analyzing/personality-test"),
        (e.QUIZ_ANALYZING_LOVE = "/analyzing/love-language"),
        (e.QUIZ_ANALYZING_LOVE_PROFILE = "/profile/analyzing/love-language"),
        (e.QUIZ_ANALYZING_POLITICAL_COMPASS_PROFILE = "/profile/analyzing/political-compass"),
        (e.QUIZ_ANALYZING_ATTACHMENT = "/profile/analyzing/attachment-style"),
        (e.QUIZ_ANALYZING_ADHD = "/profile/analyzing/adhd-test"),
        (e.QUIZ_ANALYZING_PROCRASTINATION = "/profile/analyzing/procrastination-test"),
        (e.QUIZ_ANALYZING_CAREERS = "/profile/analyzing/career-test"),
        (e.QUIZ_ANALYZING_WORK = "/profile/analyzing/work-test"),
        (e.QUIZ_ANALYZING_BURNOUT = "/profile/analyzing/burnout-test"),
        (e.QUIZ_ANALYZING_EMOTIONAL = "/profile/analyzing/emotional-test"),
        (e.QUIZ_ANALYZING_DEPRESSION = "/profile/analyzing/depression-test"),
        (e.QUIZ_ANALYZING_TIME_MANAGEMENT = "/profile/analyzing/time-management"),
        (e.QUIZ_ANALYZING_IMPOSTER_SYNDROME = "/profile/analyzing/imposter-syndrome"),
        (e.QUIZ_ANALYZING_PSYCHOLOGICAL_ARCHETYPES = "/profile/analyzing/psychological-archetypes"),
        (e.QUIZ_ANALYZING_ANXIETY = "/profile/analyzing/anxiety-test"),
        (e.QUIZ_ANALYZING_CONFIDENCE = "/profile/analyzing/self-confidence-test"),
        (e.QUIZ_ANALYZING_STRENGTHS = "/profile/analyzing/hidden-strengths-test"),
        (e.UPGRADE = "/upgrade"),
        (e.DYNAMIC_CERTIFICATE = "/dynamic-certificate"),
        (e.ADDITIONAL_QUIZ = "/additional-quiz"),
        (e.SIGN_IN = "/sign-in"),
        (e.SIGN_IN_REDESIGN = "/redesign/sign-in"),
        (e.ASK_NAME = "/name"),
        (e.EMAIL = "/email"),
        (e.EMAIL_PERSONALITY = "/email/personality-test"),
        (e.EMAIL_LOVE = "/email/love-language"),
        (e.EMAIL_ATTACHMENT = "/email/attachment-style"),
        (e.EMAIL_ADHD = "/email/adhd-test"),
        (e.EMAIL_VERIFICATION = "/email/verification"),
        (e.CHECKOUT = "/checkout"),
        (e.CHECKOUT_PERSONALITY = "/checkout/personality-test"),
        (e.CHECKOUT_LOVE = "/checkout/love-language"),
        (e.CHECKOUT_ADHD = "/checkout/adhd-test"),
        (e.CHECKOUT_PROMO = "/checkout/promo"),
        (e.CHECKOUT_ATTACHMENT = "/checkout/attachment-style"),
        (e.CORRECT_EMAIL = "/correct-email"),
        (e.CERTIFICATE = "/certificate"),
        (e.CERTIFICATE_VERIFY = "/certificate/verify"),
        (e.DEPRESSION_RESULT_SHARE = "/r"),
        (e.CONGRATULATIONS = "/profile/congratulations"),
        (e.PRINTED_CERTIFICATE_SHIPPING = "/profile/printed-certificate-shipping"),
        (e.INTRODUCTION = "/profile/introduction"),
        (e.REPORT = "/profile/report"),
        (e.REPORT_LOVE = "/profile/report/love-language"),
        (e.REPORT_PERSONALITY = "/profile/report/personality"),
        (e.REPORT_POLITICAL_COMPASS = "/profile/report/political-compass"),
        (e.REPORT_PROCRASTINATION = "/profile/report/procrastination"),
        (e.REPORT_DEPRESSION = "/profile/report/depression-test"),
        (e.REPORT_CAREERS = "/profile/report/career-test"),
        (e.REPORT_WORK = "/profile/report/work-test"),
        (e.REPORT_BURNOUT = "/profile/report/burnout-test"),
        (e.REPORT_EMOTIONAL = "/profile/report/emotional-test"),
        (e.REPORT_TIME_MANAGEMENT = "/profile/report/time-management"),
        (e.REPORT_ADHD = "/profile/report/adhd-test"),
        (e.REPORT_ATTACHMENT = "/profile/report/attachment-style"),
        (e.REPORT_IMPOSTER_SYNDROME = "/profile/report/imposter-syndrome"),
        (e.REPORT_PSYCHOLOGICAL_ARCHETYPES = "/profile/report/psychological-archetypes"),
        (e.REPORT_ANXIETY = "/profile/report/anxiety-test"),
        (e.REPORT_CONFIDENCE = "/profile/report/self-confidence-test"),
        (e.REPORT_STRENGTHS = "/profile/report/hidden-strengths-test"),
        (e.GAMES = "/profile/games"),
        (e.COURSES = "/profile/courses"),
        (e.PUZZLES = "/profile/puzzles"),
        (e.TESTS = "/profile/tests"),
        (e.MATH_CROSS = "/profile/math-crossword"),
        (e.WORD_SEARCH = "/profile/word-search"),
        (e.MEMORY_GRID = "/profile/memory-grid"),
        (e.COLOR_MATCH = "/profile/color-match"),
        (e.QUICK_SOLVE = "/profile/quick-solve"),
        (e.SEQUENCE_RECALL = "/profile/sequence-recall"),
        (e.EQUATION_BUILDER = "/profile/equation-builder"),
        (e.VISUAL_RECALL = "/profile/visual-recall"),
        (e.SKIP_TRIAL = "/profile/skip-trial"),
        (e.CANCEL_PLAN_HELP_CENTER = "/help/how-do-i-cancel-my-subscription"),
        (e.CONTACT_SUPPORT = "/help/contact-myiq-support"),
        (e.PRIVACY = "/privacy"),
        (e.TERMS = "/terms"),
        (e.REFUND_POLICY = "/terms#refund-policy"),
        (e.TERMS_EU = "/terms-eu"),
        (e.COOKIE = "/cookie"),
        (e.REVIEWS = "/reviews"),
        (e.HELP = "/help"),
        (e.BLOG = "/blog"),
        (e.CANCELLATION = "/cancellation"),
        (e.CANCELLATION_AUTH = "/cancellation/auth"),
        (e.DELETE_ACCOUNT = "/delete-account"),
        (e.DELETE_ACCOUNT_AUTH = "/delete-account/auth"),
        (e.PRICING = "/pricing"),
        (e.PRICING_REDESIGN = "/redesign/pricing"),
        (e.BILL_REDESIGN = "/redesign/bill"),
        (e.TERMS_REDESIGN = "/redesign/terms"),
        (e.PRIVACY_REDESIGN = "/redesign/privacy"),
        (e.COOKIE_REDESIGN = "/redesign/cookie"),
        (e.VISUAL_ALGEBRA = "/profile/visual-algebra"),
        (e.GLOBAL_LOGIC = "/profile/global-logic"),
        (e.FORMAL_LOGIC = "/profile/formal-logic"),
        (e.MATH_FUNDAMENTALS = "/profile/math-fundamentals"),
        (e.SCALES = "/profile/scales"),
        (e.START_ADDITIONAL_QUIZ = "/profile/start/additional-quiz"),
        (e.ADDITIONAL_QUIZ_PROFILE = "/profile/quiz/additional-test"),
        (e.RESULTS_PREVIEW = "/results-preview"),
        (e.SURVEYS = "/surveys"),
        (e.INTRO_IQ_SCORE = "/intro-iq-score"),
        (e.RETAKE_QUIZ = "/profile/quiz/retake-quiz"),
        e),
      o =
        (((i = {}).COOKIE = "cookie"),
        (i.PRIVACY = "privacy"),
        (i.TERMS = "terms"),
        (i.TERMS_EU = "terms-eu"),
        (i.HELP = "myiq-help-center"),
        (i.CANCELLATION = "cancellation"),
        (i.CANCELLATION_OFFERS = "offers"),
        (i.CANCELLATION_AUTH = "cancellation-auth"),
        (i.CANCELING_YOUR_SUBSCRIPTION = "how-do-i-cancel-my-subscription"),
        (i.BILL = "bill"),
        (i.PRIVACY_MX = "privacy-mx"),
        (i.TERMS_MX = "terms-mx"),
        (i.TERMS_CY = "terms-cy"),
        (i.TERMS_ID = "terms-id"),
        i),
      u =
        (((s = {}).AUTH_USER = "auth-profile"),
        (s.FREE_VERSION = "free-version"),
        (s.CUSTOMER_IO_IDENTIFY = "customer-io/identify"),
        (s.CUSTOMER_IO_EVENTS = "customer-io/events"),
        (s.PRINTED_CERTIFICATE_ORDER = "printed-certificate/order"),
        (s.PRINTED_CERTIFICATE_ADDRESS = "printed-certificate/address"),
        (s.CERTIFICATE_UPLOAD = "printed-certificate/upload-image"),
        (s.CERTIFICATE_EMAIL = "certificate-email"),
        (s.REPORT_EMAIL = "report-email"),
        (s.RESULT_LINK = "result-link"),
        (s.USER_SIGN_IN_CONFIRM = "profile/sign-in/confirm"),
        (s.USER_SIGN_OUT = "profile/sign-out"),
        (s.QUIZ_RESULTS = "test-results"),
        (s.SURVEYS = "surveys"),
        (s.USER_PAYNEXT_PAYMENT = "checkout/paynext-payment"),
        (s.USER_CARD_UPDATE = "checkout/payment/token-card"),
        (s.USER_SUBSCRIPTION_UPDATE = "checkout/subscription/update"),
        (s.USER_PAYMENT = "checkout/payment"),
        (s.CREATE_SESSION = "auth/create-session"),
        s),
      l =
        (((r = {}).DAILY_STAT_URL = "https://stat.myiq.com/daily"),
        (r.SHORT_URL = "https://ref.myiq.com"),
        (r.REVIEWS_IO_URL = "https://api.reviews.io/reviews"),
        (r.REVIEWS_IO_COLLECTOR_URL = "https://www.reviews.io/store/landing_new_review"),
        (r.TRUSTPILOT_STYLES = "https://widget.trustpilot.com/bootstrap/v5/tp.widget.bootstrap.min.js"),
        (r.TRUSTPILOT_PRODUCT_LINK = "https://www.trustpilot.com/review/myiq.com"),
        r),
      c =
        (((a = {}).SUBSCRIPTION = "subscription"),
        (a.PAYNEXT_CUSTOMER = "paynext-customer"),
        (a.PAYNEXT_PAYMENT = "paynext-payment"),
        (a.CHECKOUT_SESSION = "checkout-session"),
        (a.CHECKOUT_SESSION_FRAUD_SESSIONS = "checkout-session/fraud-sessions"),
        (a.COUNTRY_REVIEWS = "country-reviews"),
        (a.COUNTRY_DATA = "country-data"),
        (a.VALIDATE_EMAIL = "validate-email"),
        (a.COURSES = "courses"),
        (a.TEXT_COURSES = "text-courses"),
        (a.REVIEWS = "reviews"),
        (a.IQ_SCORE = "iq-score"),
        (a.REPORT_DATA = "report-data"),
        (a.REPORT_DELAY = "report-delay"),
        (a.RESULT_LINK = "result-link"),
        (a.FORMBRICKS_SINGLE_USE_LINKS = "formbricks/single-use-links"),
        (a.AUTH_USER = "auth/user"),
        (a.AUTH_VERIFY_REFRESH_TOKEN = "auth/verify-refresh-token"),
        (a.CUSTOMER_IO_EVENTS = "customer-io/events"),
        (a.CUSTOMER_IO_IDENTIFY = "customer-io/identify"),
        (a.GENERATE_PDF = "generate-report"),
        (a.TEST_DATA = "test-data"),
        (a.TEST_RESULTS = "test-results"),
        (a.FREE_VERSION = "free-version"),
        (a.TRUSTPILOT_REVIEWS = "trustpilot-reviews"),
        (a.USER_SIGN_IN = "sign-in"),
        (a.OTP_CODE = "otp-code"),
        (a.PAYNEXT_SUBSCRIPTIONS = "tests-counter/paynext"),
        (a.SURVEYS = "surveys"),
        (a.PRODUCT_FEEDBACK = "product-feedback"),
        (a.PRINTED_CERTIFICATE_ORDER = "printed-certificate/order"),
        (a.PRINTED_CERTIFICATE_ADDRESS = "printed-certificate/address"),
        (a.BANNER_USERS = "banner-users"),
        (a.SIMILAR_PCT = "similar-pct"),
        (a.DEPRESSION_SIMILAR_PCT = "depression/similar-pct"),
        (a.EMAIL_CHANGE_REQUEST = "email-change/request"),
        (a.EMAIL_CHANGE_CONFIRM = "email-change/confirm"),
        a);
    t.s([
      "EApiRoutes",
      () => c,
      "EClientRoutes",
      () => n,
      "ECommonUrls",
      () => l,
      "EServerRoutes",
      () => u,
      "EStaticPayloadRoutes",
      () => o,
    ]);
  },
  177851,
  (t) => {
    "use strict";
    let e;
    var i = t.i(843476),
      s = t.i(912598),
      r = function () {
        return null;
      },
      a = t.i(372775),
      n = t.i(619273),
      o = t.i(286491),
      u = t.i(540143),
      l = t.i(915823),
      c = class extends l.Subscribable {
        constructor(t = {}) {
          (super(), (this.config = t), (this.#T = new Map()));
        }
        #T;
        build(t, e, i) {
          let s = e.queryKey,
            r = e.queryHash ?? (0, n.hashQueryKeyByOptions)(s, e),
            a = this.get(r);
          return (
            a ||
              ((a = new o.Query({
                client: t,
                queryKey: s,
                queryHash: r,
                options: t.defaultQueryOptions(e),
                state: i,
                defaultOptions: t.getQueryDefaults(s),
              })),
              this.add(a)),
            a
          );
        }
        add(t) {
          this.#T.has(t.queryHash) || (this.#T.set(t.queryHash, t), this.notify({ type: "added", query: t }));
        }
        remove(t) {
          let e = this.#T.get(t.queryHash);
          e &&
            (t.destroy(), e === t && this.#T.delete(t.queryHash), this.notify({ type: "removed", query: t }));
        }
        clear() {
          u.notifyManager.batch(() => {
            this.getAll().forEach((t) => {
              this.remove(t);
            });
          });
        }
        get(t) {
          return this.#T.get(t);
        }
        getAll() {
          return [...this.#T.values()];
        }
        find(t) {
          let e = { exact: !0, ...t };
          return this.getAll().find((t) => (0, n.matchQuery)(e, t));
        }
        findAll() {
          let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
            e = this.getAll();
          return Object.keys(t).length > 0 ? e.filter((e) => (0, n.matchQuery)(t, e)) : e;
        }
        notify(t) {
          u.notifyManager.batch(() => {
            this.listeners.forEach((e) => {
              e(t);
            });
          });
        }
        onFocus() {
          u.notifyManager.batch(() => {
            this.getAll().forEach((t) => {
              t.onFocus();
            });
          });
        }
        onOnline() {
          u.notifyManager.batch(() => {
            this.getAll().forEach((t) => {
              t.onOnline();
            });
          });
        }
      },
      h = t.i(114272),
      p = l,
      d = class extends p.Subscribable {
        constructor(t = {}) {
          (super(), (this.config = t), (this.#m = new Set()), (this.#R = new Map()), (this.#I = 0));
        }
        #m;
        #R;
        #I;
        build(t, e, i) {
          let s = new h.Mutation({
            client: t,
            mutationCache: this,
            mutationId: ++this.#I,
            options: t.defaultMutationOptions(e),
            state: i,
          });
          return (this.add(s), s);
        }
        add(t) {
          this.#m.add(t);
          let e = f(t);
          if ("string" == typeof e) {
            let i = this.#R.get(e);
            i ? i.push(t) : this.#R.set(e, [t]);
          }
          this.notify({ type: "added", mutation: t });
        }
        remove(t) {
          if (this.#m.delete(t)) {
            let e = f(t);
            if ("string" == typeof e) {
              let i = this.#R.get(e);
              if (i)
                if (i.length > 1) {
                  let e = i.indexOf(t);
                  -1 !== e && i.splice(e, 1);
                } else i[0] === t && this.#R.delete(e);
            }
          }
          this.notify({ type: "removed", mutation: t });
        }
        canRun(t) {
          let e = f(t);
          if ("string" != typeof e) return !0;
          {
            let i = this.#R.get(e),
              s = i?.find((t) => "pending" === t.state.status);
            return !s || s === t;
          }
        }
        runNext(t) {
          let e = f(t);
          if ("string" != typeof e) return Promise.resolve();
          {
            let i = this.#R.get(e)?.find((e) => e !== t && e.state.isPaused);
            return i?.continue() ?? Promise.resolve();
          }
        }
        clear() {
          u.notifyManager.batch(() => {
            (this.#m.forEach((t) => {
              this.notify({ type: "removed", mutation: t });
            }),
              this.#m.clear(),
              this.#R.clear());
          });
        }
        getAll() {
          return Array.from(this.#m);
        }
        find(t) {
          let e = { exact: !0, ...t };
          return this.getAll().find((t) => (0, n.matchMutation)(e, t));
        }
        findAll() {
          let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
          return this.getAll().filter((e) => (0, n.matchMutation)(t, e));
        }
        notify(t) {
          u.notifyManager.batch(() => {
            this.listeners.forEach((e) => {
              e(t);
            });
          });
        }
        resumePausedMutations() {
          let t = this.getAll().filter((t) => t.state.isPaused);
          return u.notifyManager.batch(() => Promise.all(t.map((t) => t.continue().catch(n.noop))));
        }
      };
    function f(t) {
      return t.options.scope?.id;
    }
    var y = t.i(175555),
      E = t.i(814448);
    function T(t) {
      return {
        onFetch: (e, i) => {
          let s = e.options,
            r = e.fetchOptions?.meta?.fetchMore?.direction,
            a = e.state.data?.pages || [],
            o = e.state.data?.pageParams || [],
            u = { pages: [], pageParams: [] },
            l = 0,
            c = async () => {
              let i = !1,
                c = (0, n.ensureQueryFn)(e.options, e.fetchOptions),
                h = async (t, s, r) => {
                  let a;
                  if (i) return Promise.reject();
                  if (null == s && t.pages.length) return Promise.resolve(t);
                  let o =
                      (Object.defineProperty(
                        (a = {
                          client: e.client,
                          queryKey: e.queryKey,
                          pageParam: s,
                          direction: r ? "backward" : "forward",
                          meta: e.options.meta,
                        }),
                        "signal",
                        {
                          enumerable: !0,
                          get: () => (
                            e.signal.aborted
                              ? (i = !0)
                              : e.signal.addEventListener("abort", () => {
                                  i = !0;
                                }),
                            e.signal
                          ),
                        },
                      ),
                      a),
                    u = await c(o),
                    { maxPages: l } = e.options,
                    h = r ? n.addToStart : n.addToEnd;
                  return { pages: h(t.pages, u, l), pageParams: h(t.pageParams, s, l) };
                };
              if (r && a.length) {
                let t = "backward" === r,
                  e = { pages: a, pageParams: o },
                  i = (
                    t
                      ? function (t, e) {
                          let { pages: i, pageParams: s } = e;
                          return i.length > 0 ? t.getPreviousPageParam?.(i[0], i, s[0], s) : void 0;
                        }
                      : m
                  )(s, e);
                u = await h(e, i, t);
              } else {
                let e = t ?? a.length;
                do {
                  let t = 0 === l ? (o[0] ?? s.initialPageParam) : m(s, u);
                  if (l > 0 && null == t) break;
                  ((u = await h(u, t)), l++);
                } while (l < e);
              }
              return u;
            };
          e.options.persister
            ? (e.fetchFn = () =>
                e.options.persister?.(
                  c,
                  { client: e.client, queryKey: e.queryKey, meta: e.options.meta, signal: e.signal },
                  i,
                ))
            : (e.fetchFn = c);
        },
      };
    }
    function m(t, e) {
      let { pages: i, pageParams: s } = e,
        r = i.length - 1;
      return i.length > 0 ? t.getNextPageParam(i[r], i, s[r], s) : void 0;
    }
    var R = class {
      #A;
      #a;
      #h;
      #S;
      #O;
      #_;
      #g;
      #v;
      constructor(t = {}) {
        ((this.#A = t.queryCache || new c()),
          (this.#a = t.mutationCache || new d()),
          (this.#h = t.defaultOptions || {}),
          (this.#S = new Map()),
          (this.#O = new Map()),
          (this.#_ = 0));
      }
      mount() {
        (this.#_++,
          1 === this.#_ &&
            ((this.#g = y.focusManager.subscribe(async (t) => {
              t && (await this.resumePausedMutations(), this.#A.onFocus());
            })),
            (this.#v = E.onlineManager.subscribe(async (t) => {
              t && (await this.resumePausedMutations(), this.#A.onOnline());
            }))));
      }
      unmount() {
        (this.#_--, 0 === this.#_ && (this.#g?.(), (this.#g = void 0), this.#v?.(), (this.#v = void 0)));
      }
      isFetching(t) {
        return this.#A.findAll({ ...t, fetchStatus: "fetching" }).length;
      }
      isMutating(t) {
        return this.#a.findAll({ ...t, status: "pending" }).length;
      }
      getQueryData(t) {
        let e = this.defaultQueryOptions({ queryKey: t });
        return this.#A.get(e.queryHash)?.state.data;
      }
      ensureQueryData(t) {
        let e = this.defaultQueryOptions(t),
          i = this.#A.build(this, e),
          s = i.state.data;
        return void 0 === s
          ? this.fetchQuery(t)
          : (t.revalidateIfStale &&
              i.isStaleByTime((0, n.resolveStaleTime)(e.staleTime, i)) &&
              this.prefetchQuery(e),
            Promise.resolve(s));
      }
      getQueriesData(t) {
        return this.#A.findAll(t).map((t) => {
          let { queryKey: e, state: i } = t;
          return [e, i.data];
        });
      }
      setQueryData(t, e, i) {
        let s = this.defaultQueryOptions({ queryKey: t }),
          r = this.#A.get(s.queryHash),
          a = r?.state.data,
          o = (0, n.functionalUpdate)(e, a);
        if (void 0 !== o) return this.#A.build(this, s).setData(o, { ...i, manual: !0 });
      }
      setQueriesData(t, e, i) {
        return u.notifyManager.batch(() =>
          this.#A.findAll(t).map((t) => {
            let { queryKey: s } = t;
            return [s, this.setQueryData(s, e, i)];
          }),
        );
      }
      getQueryState(t) {
        let e = this.defaultQueryOptions({ queryKey: t });
        return this.#A.get(e.queryHash)?.state;
      }
      removeQueries(t) {
        let e = this.#A;
        u.notifyManager.batch(() => {
          e.findAll(t).forEach((t) => {
            e.remove(t);
          });
        });
      }
      resetQueries(t, e) {
        let i = this.#A;
        return u.notifyManager.batch(
          () => (
            i.findAll(t).forEach((t) => {
              t.reset();
            }),
            this.refetchQueries({ type: "active", ...t }, e)
          ),
        );
      }
      cancelQueries(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          i = { revert: !0, ...e };
        return Promise.all(u.notifyManager.batch(() => this.#A.findAll(t).map((t) => t.cancel(i))))
          .then(n.noop)
          .catch(n.noop);
      }
      invalidateQueries(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return u.notifyManager.batch(() =>
          (this.#A.findAll(t).forEach((t) => {
            t.invalidate();
          }),
          t?.refetchType === "none")
            ? Promise.resolve()
            : this.refetchQueries({ ...t, type: t?.refetchType ?? t?.type ?? "active" }, e),
        );
      }
      refetchQueries(t) {
        let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          i = { ...e, cancelRefetch: e.cancelRefetch ?? !0 };
        return Promise.all(
          u.notifyManager.batch(() =>
            this.#A
              .findAll(t)
              .filter((t) => !t.isDisabled() && !t.isStatic())
              .map((t) => {
                let e = t.fetch(void 0, i);
                return (
                  i.throwOnError || (e = e.catch(n.noop)),
                  "paused" === t.state.fetchStatus ? Promise.resolve() : e
                );
              }),
          ),
        ).then(n.noop);
      }
      fetchQuery(t) {
        let e = this.defaultQueryOptions(t);
        void 0 === e.retry && (e.retry = !1);
        let i = this.#A.build(this, e);
        return i.isStaleByTime((0, n.resolveStaleTime)(e.staleTime, i))
          ? i.fetch(e)
          : Promise.resolve(i.state.data);
      }
      prefetchQuery(t) {
        return this.fetchQuery(t).then(n.noop).catch(n.noop);
      }
      fetchInfiniteQuery(t) {
        return ((t.behavior = T(t.pages)), this.fetchQuery(t));
      }
      prefetchInfiniteQuery(t) {
        return this.fetchInfiniteQuery(t).then(n.noop).catch(n.noop);
      }
      ensureInfiniteQueryData(t) {
        return ((t.behavior = T(t.pages)), this.ensureQueryData(t));
      }
      resumePausedMutations() {
        return E.onlineManager.isOnline() ? this.#a.resumePausedMutations() : Promise.resolve();
      }
      getQueryCache() {
        return this.#A;
      }
      getMutationCache() {
        return this.#a;
      }
      getDefaultOptions() {
        return this.#h;
      }
      setDefaultOptions(t) {
        this.#h = t;
      }
      setQueryDefaults(t, e) {
        this.#S.set((0, n.hashKey)(t), { queryKey: t, defaultOptions: e });
      }
      getQueryDefaults(t) {
        let e = [...this.#S.values()],
          i = {};
        return (
          e.forEach((e) => {
            (0, n.partialMatchKey)(t, e.queryKey) && Object.assign(i, e.defaultOptions);
          }),
          i
        );
      }
      setMutationDefaults(t, e) {
        this.#O.set((0, n.hashKey)(t), { mutationKey: t, defaultOptions: e });
      }
      getMutationDefaults(t) {
        let e = [...this.#O.values()],
          i = {};
        return (
          e.forEach((e) => {
            (0, n.partialMatchKey)(t, e.mutationKey) && Object.assign(i, e.defaultOptions);
          }),
          i
        );
      }
      defaultQueryOptions(t) {
        if (t._defaulted) return t;
        let e = { ...this.#h.queries, ...this.getQueryDefaults(t.queryKey), ...t, _defaulted: !0 };
        return (
          e.queryHash || (e.queryHash = (0, n.hashQueryKeyByOptions)(e.queryKey, e)),
          void 0 === e.refetchOnReconnect && (e.refetchOnReconnect = "always" !== e.networkMode),
          void 0 === e.throwOnError && (e.throwOnError = !!e.suspense),
          !e.networkMode && e.persister && (e.networkMode = "offlineFirst"),
          e.queryFn === n.skipToken && (e.enabled = !1),
          e
        );
      }
      defaultMutationOptions(t) {
        return t?._defaulted
          ? t
          : {
              ...this.#h.mutations,
              ...(t?.mutationKey && this.getMutationDefaults(t.mutationKey)),
              ...t,
              _defaulted: !0,
            };
      }
      clear() {
        (this.#A.clear(), this.#a.clear());
      }
    };
    let I = () =>
      new R({
        defaultOptions: {
          queries: {
            staleTime: 3e5,
            gcTime: 3e5,
            networkMode: "offlineFirst",
            refetchOnWindowFocus: !1,
            placeholderData: n.keepPreviousData,
          },
          dehydrate: {
            shouldDehydrateQuery: (t) =>
              (0, a.defaultShouldDehydrateQuery)(t) || "pending" === t.state.status,
          },
        },
      });
    t.s(
      [
        "default",
        0,
        (t) => {
          let { children: a } = t,
            o = n.isServer ? I() : (e || (e = I()), e);
          return (0, i.jsxs)(s.QueryClientProvider, {
            client: o,
            children: [a, (0, i.jsx)(r, { initialIsOpen: !1 })],
          });
        },
      ],
      177851,
    );
  },
]);
