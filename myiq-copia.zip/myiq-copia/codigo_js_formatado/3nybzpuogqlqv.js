(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  378450,
  460715,
  (e) => {
    "use strict";
    let s = Object.entries({
        1: [[1, 12]],
        2: [
          [13, 22],
          [92, 100],
        ],
        3: [[23, 30]],
        4: [[31, 38]],
        5: [[39, 47]],
        6: [[48, 55]],
        7: [[56, 66]],
        8: [[67, 75]],
        9: [[76, 91]],
      }).reduce((e, s) => {
        let [i, t] = s;
        for (let [s, o] of t) for (let t = s; t <= o; t++) e[t] = Number(i);
        return e;
      }, {}),
      i = [25, 50, 70];
    (e.s(
      [
        "ENNEAGRAM_MOTIVATIONAL_STEPS",
        0,
        i,
        "ENNEAGRAM_QUESTION_TYPE_MAP",
        0,
        s,
        "ENNEAGRAM_TYPE_IDS",
        0,
        [1, 2, 3, 4, 5, 6, 7, 8, 9],
        "getEnneagramAdjacentTypes",
        0,
        (e) => [1 === e ? 9 : e - 1, 9 === e ? 1 : e + 1],
        "getEnneagramMotivationContent",
        0,
        (e) =>
          i.reduce(
            (s, i, t) => ({
              ...s,
              [i]: {
                title: e(`enneagram_quiz_motivation_${t + 1}_title`),
                description: e(`enneagram_quiz_motivation_${t + 1}_desc`),
              },
            }),
            {},
          ),
        "getEnneagramQuestionNumber",
        0,
        (e) => Number(e.split("_").pop()),
        "getEnneagramQuestions",
        0,
        (e) =>
          Array.from({ length: 100 }, (s, i) => {
            let t;
            return {
              id: ((t = i + 1), `enneagram_question_${t}`),
              title: e(`enneagram_quiz_q${i + 1}`),
              answers: [
                e("quiz_answer_strongly_agree"),
                e("quiz_answer_agree"),
                e("quiz_answer_neutral"),
                e("quiz_answer_disagree"),
                e("quiz_answer_strongly_disagree"),
              ],
            };
          }),
        "getEnneagramTypeName",
        0,
        (e, s) => e(`enneagram_type_${s}_name`),
        "getEnneagramTypeTrait",
        0,
        (e, s) => e(`enneagram_type_${s}_trait`),
        "mapEnneagramAnswerToLikert",
        0,
        (e, s) => {
          switch (e) {
            case s("quiz_answer_strongly_agree"):
              return 5;
            case s("quiz_answer_agree"):
              return 4;
            case s("quiz_answer_disagree"):
              return 2;
            case s("quiz_answer_strongly_disagree"):
              return 1;
            case s("quiz_answer_neutral"):
            default:
              return 3;
          }
        },
      ],
      460715,
    ),
      e.s([], 378450));
  },
  381069,
  468387,
  548554,
  465634,
  82709,
  477545,
  678089,
  784992,
  781901,
  16211,
  268041,
  (e) => {
    "use strict";
    e.i(817239);
    var s = e.i(843476),
      i = e.i(614383);
    let t = ["18-24", "25-34", "35-44", "45-54", "55-64", "65+"],
      o = (e) => [
        e("quiz_answer_strongly_agree"),
        e("quiz_answer_agree"),
        e("quiz_answer_neutral"),
        e("quiz_answer_disagree"),
        e("quiz_answer_strongly_disagree"),
      ],
      n = [7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18],
      r = [7, 14, 9, 17, 10, 18, 8, 13, 11, 16, 12, 15],
      a = [9, 10],
      l = n.length,
      u = [
        [21, 25],
        [28, 29],
      ],
      c = [12, 30];
    e.s(
      [
        "CHAOS_BLOCK_Q11_22_SIZE",
        0,
        l,
        "CORRECT_ANSWER_MIN_COUNT_REST",
        0,
        4,
        "MOTIVATION_SCREEN_AB_V6",
        0,
        { percentages: [0.3, 0.56, 0.8] },
        "QUIZ_ANALYZING_PREFETCH_OPTIONS",
        0,
        { kind: "full" },
        "US_UK_AGE_GROUPS_ORDER",
        0,
        t,
        "US_UK_AGE_GROUP_NORMS",
        0,
        {
          "18-24": { mean: 51, sd: 6 },
          "25-34": { mean: 49, sd: 7 },
          "35-44": { mean: 47, sd: 7 },
          "45-54": { mean: 44, sd: 8 },
          "55-64": { mean: 40, sd: 9 },
          "65+": { mean: 35, sd: 9 },
        },
        "US_UK_DEFAULT_AGE_GROUP",
        0,
        "25-34",
        "US_UK_IQ_BOUNDS",
        0,
        { min: 65, max: 135 },
        "US_UK_QUESTION_IDS",
        0,
        [
          1, 2, 5, 6, 7, 10, 12, 13, 15, 16, 18, 19, 20, 21, 23, 25, 27, 28, 30, 31, 33, 34, 35, 37, 38, 40,
          41, 43, 45, 46, 48, 49, 50, 52, 53, 55, 56, 58, 60, 61, 63, 65, 66, 68, 70, 71, 73, 74, 75, 76, 78,
          79, 80, 81, 83, 85, 86, 88, 89, 90,
        ],
        "WORD_RECALL_2ND_WORD",
        0,
        "ab_myiq_word_recall_2nd_answer_elephant",
        "WORD_RECALL_INTRO_WORD",
        0,
        "quiz_page_ab_myiq_word_recall_answer_cognitive",
        "answers",
        0,
        o,
        "disperseChaosBlockWindow",
        0,
        (e) => (e.length !== l ? e : r.map((s) => e[n.indexOf(s)])),
        "getDefaultQuizQuestionWithAnswers",
        0,
        (e) => {
          let {
              additionalQuestionsNonImageStart: t,
              removedBaseIds: o,
              t: n,
              abMyiqQuizChaosBlockQ1122: r,
              abMyiqQuizMidrunSwap: l,
              abMyiqQuizFewerOptions: _,
            } = e,
            m = t?.length || 0,
            g = "v1_image_4_options" === _ || "v2_image_text_4_options" === _,
            d = [...(o && o.length > 0 ? o : []), ...("v2_cut_q13_q14" === r ? a : [])],
            I = [
              {
                baseId: 7,
                correctAnswer: "A",
                fewerOptionsRemove: ["F", "E"],
                icons: {
                  question: (0, s.jsx)(i.Question1Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon11, {}) },
                    { B: (0, s.jsx)(i.QuizIcon12, {}) },
                    { C: (0, s.jsx)(i.QuizIcon13, {}) },
                    { D: (0, s.jsx)(i.QuizIcon14, {}) },
                    { E: (0, s.jsx)(i.QuizIcon15, {}) },
                    { F: (0, s.jsx)(i.QuizIcon16, {}) },
                  ],
                },
              },
              {
                baseId: 8,
                correctAnswer: "F",
                fewerOptionsRemove: ["E", "D"],
                icons: {
                  question: (0, s.jsx)(i.Question2Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon21, {}) },
                    { B: (0, s.jsx)(i.QuizIcon22, {}) },
                    { C: (0, s.jsx)(i.QuizIcon23, {}) },
                    { D: (0, s.jsx)(i.QuizIcon24, {}) },
                    { E: (0, s.jsx)(i.QuizIcon25, {}) },
                    { F: (0, s.jsx)(i.QuizIcon26, {}) },
                  ],
                },
              },
              {
                baseId: 9,
                correctAnswer: "B",
                fewerOptionsRemove: ["F", "E"],
                icons: {
                  question: (0, s.jsx)(i.Question3Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon31, {}) },
                    { B: (0, s.jsx)(i.QuizIcon32, {}) },
                    { C: (0, s.jsx)(i.QuizIcon33, {}) },
                    { D: (0, s.jsx)(i.QuizIcon34, {}) },
                    { E: (0, s.jsx)(i.QuizIcon35, {}) },
                    { F: (0, s.jsx)(i.QuizIcon36, {}) },
                  ],
                },
              },
              {
                baseId: 10,
                correctAnswer: "A",
                fewerOptionsRemove: ["F", "E"],
                icons: {
                  question: (0, s.jsx)(i.Question4Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon41, {}) },
                    { B: (0, s.jsx)(i.QuizIcon42, {}) },
                    { C: (0, s.jsx)(i.QuizIcon43, {}) },
                    { D: (0, s.jsx)(i.QuizIcon44, {}) },
                    { E: (0, s.jsx)(i.QuizIcon45, {}) },
                    { F: (0, s.jsx)(i.QuizIcon46, {}) },
                  ],
                },
              },
              {
                baseId: 11,
                correctAnswer: "C",
                fewerOptionsRemove: ["F", "E"],
                icons: {
                  question: (0, s.jsx)(i.Question5Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon51, {}) },
                    { B: (0, s.jsx)(i.QuizIcon52, {}) },
                    { C: (0, s.jsx)(i.QuizIcon53, {}) },
                    { D: (0, s.jsx)(i.QuizIcon54, {}) },
                    { E: (0, s.jsx)(i.QuizIcon55, {}) },
                    { F: (0, s.jsx)(i.QuizIcon56, {}) },
                  ],
                },
              },
              {
                baseId: 12,
                correctAnswer: "A",
                fewerOptionsRemove: ["F", "E"],
                icons: {
                  question: (0, s.jsx)(i.Question6Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon61, {}) },
                    { B: (0, s.jsx)(i.QuizIcon62, {}) },
                    { C: (0, s.jsx)(i.QuizIcon63, {}) },
                    { D: (0, s.jsx)(i.QuizIcon64, {}) },
                    { E: (0, s.jsx)(i.QuizIcon65, {}) },
                    { F: (0, s.jsx)(i.QuizIcon66, {}) },
                  ],
                },
              },
              {
                baseId: 13,
                correctAnswer: "F",
                fewerOptionsRemove: ["E", "D"],
                icons: {
                  question: (0, s.jsx)(i.Question7Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon71, {}) },
                    { B: (0, s.jsx)(i.QuizIcon72, {}) },
                    { C: (0, s.jsx)(i.QuizIcon73, {}) },
                    { D: (0, s.jsx)(i.QuizIcon74, {}) },
                    { E: (0, s.jsx)(i.QuizIcon75, {}) },
                    { F: (0, s.jsx)(i.QuizIcon76, {}) },
                  ],
                },
              },
              {
                baseId: 14,
                correctAnswer: "F",
                fewerOptionsRemove: ["E", "D"],
                icons: {
                  question: (0, s.jsx)(i.Question8Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon81, {}) },
                    { B: (0, s.jsx)(i.QuizIcon82, {}) },
                    { C: (0, s.jsx)(i.QuizIcon83, {}) },
                    { D: (0, s.jsx)(i.QuizIcon84, {}) },
                    { E: (0, s.jsx)(i.QuizIcon85, {}) },
                    { F: (0, s.jsx)(i.QuizIcon86, {}) },
                  ],
                },
              },
              {
                baseId: 15,
                correctAnswer: "E",
                fewerOptionsRemove: ["F", "D"],
                icons: {
                  question: (0, s.jsx)(i.Question9Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon91, {}) },
                    { B: (0, s.jsx)(i.QuizIcon92, {}) },
                    { C: (0, s.jsx)(i.QuizIcon93, {}) },
                    { D: (0, s.jsx)(i.QuizIcon94, {}) },
                    { E: (0, s.jsx)(i.QuizIcon95, {}) },
                    { F: (0, s.jsx)(i.QuizIcon96, {}) },
                  ],
                },
              },
              {
                baseId: 16,
                correctAnswer: "F",
                fewerOptionsRemove: ["E", "D"],
                icons: {
                  question: (0, s.jsx)(i.Question10Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon101, {}) },
                    { B: (0, s.jsx)(i.QuizIcon102, {}) },
                    { C: (0, s.jsx)(i.QuizIcon103, {}) },
                    { D: (0, s.jsx)(i.QuizIcon104, {}) },
                    { E: (0, s.jsx)(i.QuizIcon105, {}) },
                    { F: (0, s.jsx)(i.QuizIcon106, {}) },
                  ],
                },
              },
              {
                baseId: 17,
                correctAnswer: "E",
                fewerOptionsRemove: ["F", "D"],
                icons: {
                  question: (0, s.jsx)(i.Question11Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon111, {}) },
                    { B: (0, s.jsx)(i.QuizIcon112, {}) },
                    { C: (0, s.jsx)(i.QuizIcon113, {}) },
                    { D: (0, s.jsx)(i.QuizIcon114, {}) },
                    { E: (0, s.jsx)(i.QuizIcon115, {}) },
                    { F: (0, s.jsx)(i.QuizIcon116, {}) },
                  ],
                },
              },
              {
                baseId: 18,
                correctAnswer: "A",
                fewerOptionsRemove: ["F", "E"],
                icons: {
                  question: (0, s.jsx)(i.Question12Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon121, {}) },
                    { B: (0, s.jsx)(i.QuizIcon122, {}) },
                    { C: (0, s.jsx)(i.QuizIcon123, {}) },
                    { D: (0, s.jsx)(i.QuizIcon124, {}) },
                    { E: (0, s.jsx)(i.QuizIcon125, {}) },
                    { F: (0, s.jsx)(i.QuizIcon126, {}) },
                  ],
                },
              },
              {
                baseId: 19,
                correctAnswer: "E",
                fewerOptionsRemove: ["F", "D"],
                icons: {
                  question: (0, s.jsx)(i.Question13Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon131, {}) },
                    { B: (0, s.jsx)(i.QuizIcon132, {}) },
                    { C: (0, s.jsx)(i.QuizIcon133, {}) },
                    { D: (0, s.jsx)(i.QuizIcon134, {}) },
                    { E: (0, s.jsx)(i.QuizIcon135, {}) },
                    { F: (0, s.jsx)(i.QuizIcon136, {}) },
                  ],
                },
              },
              ...(n
                ? [
                    {
                      title: n("quiz_page_ab_myiq_word_recall_question_title"),
                      answers: [
                        n("quiz_page_ab_myiq_word_recall_answer_smart"),
                        ...("v2_image_text_4_options" === _
                          ? []
                          : [n("quiz_page_ab_myiq_word_recall_answer_iq")]),
                        n("quiz_page_ab_myiq_word_recall_answer_brain"),
                        n("quiz_page_ab_myiq_word_recall_answer_cognitive"),
                        n("quiz_page_ab_myiq_word_recall_answer_intelligence"),
                      ],
                      baseId: 200,
                      isDefaultColor: !0,
                      correctAnswer: n("quiz_page_ab_myiq_word_recall_answer_cognitive"),
                      questionKey: "recall_cognitive",
                    },
                  ]
                : []),
              {
                baseId: 20,
                correctAnswer: "C",
                fewerOptionsRemove: ["F", "E"],
                icons: {
                  question: (0, s.jsx)(i.Question14Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon141, {}) },
                    { B: (0, s.jsx)(i.QuizIcon142, {}) },
                    { C: (0, s.jsx)(i.QuizIcon143, {}) },
                    { D: (0, s.jsx)(i.QuizIcon144, {}) },
                    { E: (0, s.jsx)(i.QuizIcon145, {}) },
                    { F: (0, s.jsx)(i.QuizIcon146, {}) },
                  ],
                },
              },
              {
                baseId: 21,
                correctAnswer: "D",
                fewerOptionsRemove: ["F", "E"],
                icons: {
                  question: (0, s.jsx)(i.Question15Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon151, {}) },
                    { B: (0, s.jsx)(i.QuizIcon152, {}) },
                    { C: (0, s.jsx)(i.QuizIcon153, {}) },
                    { D: (0, s.jsx)(i.QuizIcon154, {}) },
                    { E: (0, s.jsx)(i.QuizIcon155, {}) },
                    { F: (0, s.jsx)(i.QuizIcon156, {}) },
                  ],
                },
              },
              {
                baseId: 22,
                correctAnswer: "A",
                fewerOptionsRemove: ["F", "E"],
                icons: {
                  question: (0, s.jsx)(i.Question16Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon161, {}) },
                    { B: (0, s.jsx)(i.QuizIcon162, {}) },
                    { C: (0, s.jsx)(i.QuizIcon163, {}) },
                    { D: (0, s.jsx)(i.QuizIcon164, {}) },
                    { E: (0, s.jsx)(i.QuizIcon165, {}) },
                    { F: (0, s.jsx)(i.QuizIcon166, {}) },
                  ],
                },
              },
              {
                baseId: 23,
                correctAnswer: "A",
                fewerOptionsRemove: ["F", "E"],
                icons: {
                  question: (0, s.jsx)(i.Question17Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon171, {}) },
                    { B: (0, s.jsx)(i.QuizIcon172, {}) },
                    { C: (0, s.jsx)(i.QuizIcon173, {}) },
                    { D: (0, s.jsx)(i.QuizIcon174, {}) },
                    { E: (0, s.jsx)(i.QuizIcon175, {}) },
                    { F: (0, s.jsx)(i.QuizIcon176, {}) },
                  ],
                },
              },
              {
                baseId: 24,
                correctAnswer: "D",
                fewerOptionsRemove: ["F", "E"],
                icons: {
                  question: (0, s.jsx)(i.Question18Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon181, {}) },
                    { B: (0, s.jsx)(i.QuizIcon182, {}) },
                    { C: (0, s.jsx)(i.QuizIcon183, {}) },
                    { D: (0, s.jsx)(i.QuizIcon184, {}) },
                    { E: (0, s.jsx)(i.QuizIcon185, {}) },
                    { F: (0, s.jsx)(i.QuizIcon186, {}) },
                  ],
                },
              },
              {
                baseId: 25,
                correctAnswer: "C",
                fewerOptionsRemove: ["F", "E"],
                icons: {
                  question: (0, s.jsx)(i.QuizIconSudokuQuestion3, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIconSudoku3AnswerA, {}) },
                    { B: (0, s.jsx)(i.QuizIconSudoku3AnswerB, {}) },
                    { C: (0, s.jsx)(i.QuizIconSudoku3AnswerC, {}) },
                    { D: (0, s.jsx)(i.QuizIconSudoku3AnswerD, {}) },
                    { E: (0, s.jsx)(i.QuizIconSudoku3AnswerE, {}) },
                    { F: (0, s.jsx)(i.QuizIconSudoku3AnswerF, {}) },
                  ],
                },
              },
              {
                baseId: 26,
                correctAnswer: "F",
                fewerOptionsRemove: ["E", "D"],
                icons: {
                  question: (0, s.jsx)(i.Question20Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon201, {}) },
                    { B: (0, s.jsx)(i.QuizIcon202, {}) },
                    { C: (0, s.jsx)(i.QuizIcon203, {}) },
                    { D: (0, s.jsx)(i.QuizIcon204, {}) },
                    { E: (0, s.jsx)(i.QuizIcon205, {}) },
                    { F: (0, s.jsx)(i.QuizIcon206, {}) },
                  ],
                },
              },
              {
                baseId: 27,
                correctAnswer: "E",
                fewerOptionsRemove: ["F", "D"],
                icons: {
                  question: (0, s.jsx)(i.Question21Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon211, {}) },
                    { B: (0, s.jsx)(i.QuizIcon212, {}) },
                    { C: (0, s.jsx)(i.QuizIcon213, {}) },
                    { D: (0, s.jsx)(i.QuizIcon214, {}) },
                    { E: (0, s.jsx)(i.QuizIcon215, {}) },
                    { F: (0, s.jsx)(i.QuizIcon216, {}) },
                  ],
                },
              },
              {
                baseId: 28,
                correctAnswer: "E",
                fewerOptionsRemove: ["F", "D"],
                icons: {
                  question: (0, s.jsx)(i.Question22Icon, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIcon221, {}) },
                    { B: (0, s.jsx)(i.QuizIcon222, {}) },
                    { C: (0, s.jsx)(i.QuizIcon223, {}) },
                    { D: (0, s.jsx)(i.QuizIcon224, {}) },
                    { E: (0, s.jsx)(i.QuizIcon225, {}) },
                    { F: (0, s.jsx)(i.QuizIcon226, {}) },
                  ],
                },
              },
              {
                baseId: 29,
                correctAnswer: "B",
                fewerOptionsRemove: ["F", "E"],
                icons: {
                  question: (0, s.jsx)(i.QuizIconSudokuQuestion4, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIconSudoku4AnswerA, {}) },
                    { B: (0, s.jsx)(i.QuizIconSudoku4AnswerB, {}) },
                    { C: (0, s.jsx)(i.QuizIconSudoku4AnswerC, {}) },
                    { D: (0, s.jsx)(i.QuizIconSudoku4AnswerD, {}) },
                    { E: (0, s.jsx)(i.QuizIconSudoku4AnswerE, {}) },
                    { F: (0, s.jsx)(i.QuizIconSudoku4AnswerF, {}) },
                  ],
                },
              },
              {
                baseId: 30,
                correctAnswer: "C",
                fewerOptionsRemove: ["F", "E"],
                icons: {
                  question: (0, s.jsx)(i.QuizIconNewImageQuestion1q, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIconNewImageQuestion1answerA, {}) },
                    { B: (0, s.jsx)(i.QuizIconNewImageQuestion1answerB, {}) },
                    { C: (0, s.jsx)(i.QuizIconNewImageQuestion1answerC, {}) },
                    { D: (0, s.jsx)(i.QuizIconNewImageQuestion1answerD, {}) },
                    { E: (0, s.jsx)(i.QuizIconNewImageQuestion1answerE, {}) },
                    { F: (0, s.jsx)(i.QuizIconNewImageQuestion1answerF, {}) },
                  ],
                },
              },
              {
                baseId: 31,
                correctAnswer: "D",
                fewerOptionsRemove: ["F", "E"],
                icons: {
                  question: (0, s.jsx)(i.QuizIconNewImageQuestion2q, {}),
                  options: [
                    { A: (0, s.jsx)(i.QuizIconNewImageQuestion2answerA, {}) },
                    { B: (0, s.jsx)(i.QuizIconNewImageQuestion2answerB, {}) },
                    { C: (0, s.jsx)(i.QuizIconNewImageQuestion2answerC, {}) },
                    { D: (0, s.jsx)(i.QuizIconNewImageQuestion2answerD, {}) },
                    { E: (0, s.jsx)(i.QuizIconNewImageQuestion2answerE, {}) },
                    { F: (0, s.jsx)(i.QuizIconNewImageQuestion2answerF, {}) },
                  ],
                },
              },
            ].map((e) =>
              ((e, s) => {
                if (!s || !e.fewerOptionsRemove || !e.icons) return e;
                let i = e.icons.options.filter((s) => !e.fewerOptionsRemove.includes(Object.keys(s)[0]));
                return { ...e, icons: { ...e.icons, options: i } };
              })(e, g),
            ),
            w = "v1_two_swaps" === l ? u : "v2_three_swaps" === l ? [...u, c] : [];
          return (
            w.length > 0
              ? ((e, s) => {
                  let i = new Map(e.map((e, s) => [e.baseId, s])),
                    t = [...e];
                  for (let [e, o] of s) {
                    let s = i.get(e),
                      n = i.get(o);
                    void 0 !== s && void 0 !== n && ([t[s], t[n]] = [t[n], t[s]]);
                  }
                  return t;
                })(I, w)
              : I
          )
            .filter((e) => void 0 === e.baseId || !d.includes(e.baseId))
            .map((e, s) => ({ ...e, id: m + s + 1 }));
        },
        "getOptionNode",
        0,
        (e, s) => (e ? (e[s] ?? null) : null),
        "getUsUkAgeAnswers",
        0,
        () => [...t],
      ],
      468387,
    );
    let _ = (e) => [
      e("quiz_additional_answer_18_25"),
      e("quiz_additional_answer_25_29"),
      "30–44",
      "45–60",
      e("quiz_page_61_or_older"),
    ];
    e.s(
      [
        "ADDITIONAL_QUESTIONS_FINAL",
        0,
        (e, s, i) => {
          let t = s + 1;
          return [
            {
              title: e("quiz_page_i_believe_intelligence_develops_through_continuous_effort"),
              answers: o(e),
              id: t,
              baseId: 32,
              isDefaultColor: !1,
              answersNormalCase: !0,
            },
            {
              title: e("quiz_page_i_often_reflect_on_how_i_perform_compared_to_others"),
              answers: o(e),
              id: t + 1,
              baseId: 33,
              isDefaultColor: !1,
              answersNormalCase: !0,
            },
            ...(i
              ? [
                  {
                    title: e("quiz_page_bt_cognitive_skill_question_title"),
                    answers: [
                      e("quiz_page_bt_cognitive_skill_answer_memory"),
                      e("quiz_page_bt_cognitive_skill_answer_speed"),
                      e("quiz_page_bt_cognitive_skill_answer_concentration"),
                      e("quiz_page_bt_cognitive_skill_answer_logic"),
                      e("quiz_page_bt_cognitive_skill_answer_all"),
                    ],
                    id: t + 2,
                    baseId: 35,
                    isDefaultColor: !0,
                  },
                  {
                    title: e("what_is_your_age"),
                    answers: _(e),
                    id: t + 3,
                    baseId: 34,
                    isDefaultColor: !0,
                    answersNormalCase: !0,
                  },
                ]
              : [
                  {
                    title: e("what_is_your_age"),
                    answers: _(e),
                    id: t + 2,
                    baseId: 34,
                    isDefaultColor: !0,
                    answersNormalCase: !0,
                  },
                  {
                    title: e("what_is_your_education_level"),
                    answers: [
                      e("quiz_page_some_high_school"),
                      e("quiz_page_high_school_diploma"),
                      e("quiz_page_college_trade_school"),
                      e("quiz_page_bachelors_degree"),
                      e("quiz_page_graduate_degree"),
                    ],
                    id: t + 3,
                    baseId: 35,
                    isDefaultColor: !0,
                  },
                ]),
          ];
        },
      ],
      548554,
    );
    let m = "block h-auto w-full select-none";
    e.s(
      [
        "getClassicIllusionQuestions",
        0,
        (e) => {
          let t = e("ab_myiq_quiz_classic_illusions_answer_same"),
            o = e("ab_myiq_quiz_classic_illusions_answer_none");
          return {
            mullerLyer: {
              title: e("ab_myiq_quiz_classic_illusions_muller_lyer_title"),
              stimulusImage: (0, s.jsx)(i.ClassicIllusionMullerLyerIcon, { className: m, draggable: !1 }),
              answers: [
                e("ab_myiq_quiz_classic_illusions_answer_line_a"),
                e("ab_myiq_quiz_classic_illusions_answer_line_b"),
                t,
              ],
              correctAnswer: t,
              id: 590,
              baseId: 590,
              isDefaultColor: !0,
              answersNormalCase: !0,
              stimulusLayout: "flush",
            },
            jastrow: {
              title: e("ab_myiq_quiz_classic_illusions_jastrow_title"),
              stimulusImage: (0, s.jsx)(i.ClassicIllusionJastrowIcon, { className: m, draggable: !1 }),
              answers: [
                e("ab_myiq_quiz_classic_illusions_answer_shape_a"),
                e("ab_myiq_quiz_classic_illusions_answer_shape_b"),
                t,
              ],
              correctAnswer: t,
              id: 591,
              baseId: 591,
              isDefaultColor: !0,
              answersNormalCase: !0,
              stimulusLayout: "flush",
            },
            kanizsa: {
              title: e("ab_myiq_quiz_classic_illusions_kanizsa_title"),
              stimulusImage: (0, s.jsx)(i.ClassicIllusionKanizsaIcon, { className: m, draggable: !1 }),
              answers: [
                o,
                e("ab_myiq_quiz_classic_illusions_answer_one"),
                e("ab_myiq_quiz_classic_illusions_answer_two"),
              ],
              correctAnswer: o,
              id: 592,
              baseId: 592,
              isDefaultColor: !0,
              answersNormalCase: !0,
              stimulusLayout: "flush",
            },
          };
        },
      ],
      465634,
    );
    let g = { EASY: 550, HARD: 551 },
      d = Object.values(g),
      I = {
        baseId: g.EASY,
        digitGrid: [
          [4, 2, 9, 4],
          [1, 6, 4, 3],
          [8, 5, 4, 7],
        ],
        targetDigit: 4,
        correctCount: 4,
      },
      w = {
        baseId: g.HARD,
        digitGrid: [
          [4, 7, 1, 9, 7],
          [3, 1, 2, 7, 4],
          [6, 1, 7, 9, 4],
          [1, 3, 7, 2, 4],
        ],
        targetDigit: 7,
        correctCount: 5,
      },
      p = (e) => {
        let { t: i, definition: t } = e,
          { baseId: o, digitGrid: n, targetDigit: r, correctCount: a } = t,
          l = n[0]?.length ?? 0;
        return {
          title: i("ab_myiq_quiz_count_grid_title", { digit: String(r) }),
          stimulusImage: (0, s.jsx)("div", {
            className: "flex w-full items-center justify-center",
            style: { height: 184 },
            children: (0, s.jsx)("div", {
              className: "grid gap-2",
              style: { gridTemplateColumns: `repeat(${l}, auto)` },
              children: n.flatMap((e, i) =>
                e.map((e, t) =>
                  (0, s.jsx)(
                    "span",
                    {
                      className:
                        "flex h-10 w-10 items-center justify-center rounded-lg bg-gray-100 text-lg font-bold text-dark-custom",
                      children: e,
                    },
                    `${i}-${t}`,
                  ),
                ),
              ),
            }),
          }),
          answers: [String(a - 1), String(a), String(a + 1), String(a + 2)],
          correctAnswer: String(a),
          id: o,
          baseId: o,
          isDefaultColor: !0,
          answersNormalCase: !0,
          stimulusLayout: "stack",
        };
      };
    e.s(
      [
        "getCountGridQuestions",
        0,
        (e) => ({ easy: p({ t: e, definition: I }), hard: p({ t: e, definition: w }) }),
        "isCountGridQuestion",
        0,
        (e) => void 0 !== e && d.includes(e),
      ],
      82709,
    );
    let h = { JAPAN: 520, GERMANY: 521, ITALY: 522 },
      v = Object.values(h),
      x = "block h-[140px] w-auto rounded-md",
      z = (e) => {
        let { t: s, baseId: i, image: t, answers: o } = e;
        return {
          title: s("ab_myiq_quiz_flag_trivia_title"),
          stimulusImage: t,
          answers: o,
          id: i,
          baseId: i,
          isDefaultColor: !0,
          answersNormalCase: !0,
          stimulusLayout: "stack",
        };
      };
    e.s(
      [
        "getFlagTriviaQuestions",
        0,
        (e) => ({
          japan: z({
            t: e,
            baseId: h.JAPAN,
            image: (0, s.jsx)(i.FlagTriviaJapanIcon, { className: x }),
            answers: [
              e("ab_myiq_quiz_flag_trivia_country_china"),
              e("ab_myiq_quiz_flag_trivia_country_south_korea"),
              e("ab_myiq_quiz_flag_trivia_country_japan"),
              e("ab_myiq_quiz_flag_trivia_country_turkey"),
            ],
          }),
          germany: z({
            t: e,
            baseId: h.GERMANY,
            image: (0, s.jsx)(i.FlagTriviaGermanyIcon, { className: x }),
            answers: [
              e("ab_myiq_quiz_flag_trivia_country_belgium"),
              e("ab_myiq_quiz_flag_trivia_country_germany"),
              e("ab_myiq_quiz_flag_trivia_country_austria"),
              e("ab_myiq_quiz_flag_trivia_country_hungary"),
            ],
          }),
          italy: z({
            t: e,
            baseId: h.ITALY,
            image: (0, s.jsx)(i.FlagTriviaItalyIcon, { className: x }),
            answers: [
              e("ab_myiq_quiz_flag_trivia_country_ireland"),
              e("ab_myiq_quiz_flag_trivia_country_mexico"),
              e("ab_myiq_quiz_flag_trivia_country_hungary"),
              e("ab_myiq_quiz_flag_trivia_country_italy"),
            ],
          }),
        }),
        "isFlagTriviaQuestion",
        0,
        (e) => void 0 !== e && v.includes(e),
      ],
      477545,
    );
    let j = (e, s) => {
        let i = Array.from(e);
        return s < 0 || s + 1 >= i.length ? e : (([i[s], i[s + 1]] = [i[s + 1], i[s]]), i.join(""));
      },
      q = (e) => {
        let { t: i, baseId: t, word: o, correctAnswerPosition: n } = e,
          r = ((e) => {
            let s = Array.from(e),
              i = Math.max(1, s.length - 3),
              t = [Array.from(e).reverse().join(""), j(e, 1), j(e, i)],
              o = new Set([e]),
              n = [];
            for (let e of t) o.has(e) || (o.add(e), n.push(e));
            for (let i = 0; n.length < 3 && i < s.length - 1; i += 1) {
              let s = j(e, i);
              o.has(s) || (o.add(s), n.push(s));
            }
            return n;
          })(o);
        return (
          r.splice(n, 0, o),
          {
            title: i("ab_myiq_quiz_mirror_words_title"),
            stimulusImage: (0, s.jsx)("div", {
              className: "flex h-[140px] w-full items-center justify-center px-4",
              children: (0, s.jsx)("span", {
                className:
                  "inline-block scale-x-[-1] text-[50px] font-bold uppercase leading-none tracking-[0.04em] text-dark-custom xs-l:text-[60px]",
                children: o,
              }),
            }),
            answers: r,
            correctAnswer: o,
            id: t,
            baseId: t,
            isDefaultColor: !0,
            answersNormalCase: !0,
            stimulusLayout: "stack",
          }
        );
      };
    e.s(
      [
        "getMirrorWordQuestions",
        0,
        (e) => ({
          brain: q({
            t: e,
            baseId: 540,
            word: e("ab_myiq_quiz_mirror_words_word_brain"),
            correctAnswerPosition: 1,
          }),
          logic: q({
            t: e,
            baseId: 541,
            word: e("ab_myiq_quiz_mirror_words_word_logic"),
            correctAnswerPosition: 2,
          }),
        }),
      ],
      678089,
    );
    let Q = "block h-auto w-full select-none";
    e.s(
      [
        "getOpticalIllusionQuestions",
        0,
        (e) => ({
          rings: {
            title: e("ab_myiq_quiz_optical_illusion_rings_title"),
            stimulusImage: (0, s.jsx)(i.OpticalIllusionRingsIcon, { className: Q, draggable: !1 }),
            answers: ["29", "20", "79"],
            correctAnswer: "29",
            id: 580,
            baseId: 580,
            isDefaultColor: !0,
            answersNormalCase: !0,
            stimulusLayout: "flush",
          },
          waves: {
            title: e("ab_myiq_quiz_optical_illusion_waves_title"),
            stimulusImage: (0, s.jsx)(i.OpticalIllusionWavesIcon, { className: Q, draggable: !1 }),
            answers: ["32", "52", "58"],
            correctAnswer: "52",
            id: 581,
            baseId: 581,
            isDefaultColor: !0,
            answersNormalCase: !0,
            stimulusLayout: "flush",
          },
        }),
      ],
      784992,
    );
    (e.s(
      [
        "getPerceptionQuestions",
        0,
        (e) => [
          {
            title: e("ab_myiq_quiz_perception_q1_title"),
            stimulusImage: (0, s.jsx)(i.PerceptionRubinVaseIcon, { className: "block h-[180px] w-auto" }),
            answers: [
              e("ab_myiq_quiz_perception_q1_answer_vase"),
              e("ab_myiq_quiz_perception_q1_answer_faces"),
            ],
            id: 500,
            baseId: 500,
            isDefaultColor: !0,
            answersNormalCase: !0,
          },
          {
            title: e("ab_myiq_quiz_perception_q2_title"),
            stimulusImage: (0, s.jsx)(i.PerceptionKanizsaTriangleIcon, {
              className: "block h-[180px] w-auto",
            }),
            answers: [
              e("ab_myiq_quiz_perception_q2_answer_triangle"),
              e("ab_myiq_quiz_perception_q2_answer_circles"),
            ],
            id: 501,
            baseId: 501,
            isDefaultColor: !0,
            answersNormalCase: !0,
          },
        ],
      ],
      781901,
    ),
      e.i(278718),
      e.i(696207));
    let b = { red: "text-[rgb(214,69,69)]", blue: "text-[rgb(47,111,228)]", green: "text-[rgb(46,158,99)]" },
      f = (e) => {
        let { baseId: i, word: t, ink: o, title: n, answers: r, correctAnswer: a } = e;
        return {
          title: n,
          stimulusImage: (0, s.jsx)("div", {
            className: "flex h-[227px] w-full items-center justify-center px-4",
            children: (0, s.jsx)("span", {
              className: `text-[50px] font-bold uppercase leading-none tracking-[0.04em] xs-l:text-[60px] ${b[o]}`,
              children: t,
            }),
          }),
          answers: r,
          correctAnswer: a,
          id: i,
          baseId: i,
          isDefaultColor: !0,
          answersNormalCase: !0,
          answersCentered: !0,
          stimulusLayout: "stack",
        };
      };
    e.s(
      [
        "getStroopQuestions",
        0,
        (e) => {
          let s = e("ab_myiq_quiz_stroop_answer_red"),
            i = e("ab_myiq_quiz_stroop_answer_blue"),
            t = e("ab_myiq_quiz_stroop_answer_green"),
            o = e("ab_myiq_quiz_stroop_answer_yellow"),
            n = e("ab_myiq_quiz_stroop_title");
          return {
            blueInRed: f({ baseId: 530, word: i, ink: "red", title: n, answers: [s, i], correctAnswer: s }),
            greenInBlue: f({
              baseId: 531,
              word: t,
              ink: "blue",
              title: n,
              answers: [t, i],
              correctAnswer: i,
            }),
            yellowInGreen: f({
              baseId: 532,
              word: o,
              ink: "green",
              title: n,
              answers: [o, t],
              correctAnswer: t,
            }),
          };
        },
      ],
      16211,
    );
    let y = { v1_easy_start: [2, 4, 0, 3, 1, 5], v2_easy_start_plus: [2, 4, 5, 3, 1, 0] };
    (e.s(
      [
        "ADDITIONAL_QUESTIONS_NON_IMAGE_START",
        0,
        (e) => {
          let s,
            i,
            t,
            n,
            { t: r, abMyiqQuizOpenerSwap: a, abMyiqQuizFewerOptions: l } = e,
            u = "v2_image_text_4_options" === l,
            c = (e) => {
              if ("patterns" === e || "spatial" === e) {
                let s = c(4).id + 1,
                  i = "patterns" === e ? s : s + 1;
                return { id: i, baseId: i };
              }
              let s = e + 4;
              return { id: s, baseId: s };
            },
            _ = [
              {
                title: r("quiz_page_ab_myiq_text_question_lateral_thinking_v1_sheep"),
                answers: ["7", "8", "15", "0", "3"],
                id: 1,
                baseId: 1,
                isDefaultColor: !0,
                correctAnswer: "8",
                questionKey: "text_sheep",
                fewerOptionsRemoveIndex: 4,
              },
              {
                title: r("quiz_page_additional_question_trivia_1_title"),
                answers: ["1", "4", "3", "2", "5"],
                id: 2,
                baseId: 2,
                isDefaultColor: !0,
                correctAnswer: "3",
                questionKey: "text_third_place",
                fewerOptionsRemoveIndex: 4,
              },
              {
                title: r("quiz_page_additional_question_trivia_2_title"),
                answers: ["6", "4", "8", "5", "7"],
                id: 3,
                baseId: 3,
                isDefaultColor: !0,
                correctAnswer: "8",
                questionKey: "text_cube_corners",
                fewerOptionsRemoveIndex: 4,
              },
              {
                title: r("quiz_page_i_prefer_learning_through_hands_on_experience"),
                answers: o(r),
                id: 4,
                baseId: 4,
                isDefaultColor: !1,
                answersNormalCase: !0,
              },
              {
                title: r("quiz_page_non_image_question_1_title"),
                answers: ["20", "24", "30", "32", "36"],
                ...c(1),
                isDefaultColor: !0,
                correctAnswer: "32",
                questionKey: "text_pattern_2_4_8_16",
                fewerOptionsRemoveIndex: 4,
              },
              ((s = c(2)),
              {
                title: r("quiz_page_non_image_question_2_title"),
                answers: ["13", "14", "15", "16", "17"],
                ...s,
                isDefaultColor: !0,
                correctAnswer: "15",
                questionKey: "text_missing_15",
                fewerOptionsRemoveIndex: 4,
              }),
              ((i = c(3)),
              {
                title: r("quiz_page_ab_myiq_memorization_task_1_title"),
                answers: ["7", "3", "8", "1", "5"],
                ...i,
                isDefaultColor: !0,
                correctAnswer: "3",
                memorizationSequence: "7385",
                memorizationAskedPosition: 2,
                questionKey: "mem_7385_pos2",
                fewerOptionsRemoveIndex: 4,
              }),
              ((t = c(4)),
              {
                title: r("quiz_page_ab_myiq_memorization_task_2_title"),
                answers: ["9", "2", "6", "3", "4"],
                ...t,
                isDefaultColor: !0,
                correctAnswer: "2",
                memorizationSequence: "49261",
                memorizationAskedPosition: 3,
                questionKey: "mem_49261_pos3",
                fewerOptionsRemoveIndex: 4,
              }),
              {
                title: r("quiz_page_ab_myiq_memorization_task_3_title"),
                answers: ["5", "1", "7", "9", "3"],
                ...c("patterns"),
                isDefaultColor: !0,
                correctAnswer: "1",
                memorizationSequence: "385174",
                memorizationAskedPosition: 4,
                questionKey: "mem_385174_pos4",
                fewerOptionsRemoveIndex: 4,
              },
              {
                title: r("quiz_page_quiz_additional_question_spatial"),
                answers: o(r),
                ...c("spatial"),
                isDefaultColor: !1,
                answersNormalCase: !0,
              },
            ].map((e) =>
              "icons" in e
                ? e
                : u && void 0 !== e.fewerOptionsRemoveIndex && e.answers
                  ? { ...e, answers: e.answers.filter((s, i) => i !== e.fewerOptionsRemoveIndex) }
                  : e,
            ),
            m = !!(a && y[a]),
            g = (n = a && y[a]) && !(_.length < n.length) ? [...n.map((e) => _[e]), ..._.slice(n.length)] : _;
          return m ? g.map((e, s) => ({ ...e, id: s + 1 })) : g;
        },
        "isDefaultColor",
        0,
        (e) => !0 === e.isDefaultColor,
      ],
      268041,
    ),
      e.s([], 381069));
  },
  702761,
  (e) => {
    "use strict";
    e.s([
      "CORRECT_ANSWERS",
      0,
      {
        7: "A",
        8: "F",
        9: "B",
        10: "A",
        11: "C",
        12: "A",
        13: "F",
        14: "F",
        15: "E",
        16: "F",
        17: "E",
        18: "A",
        19: "E",
        20: "C",
        21: "D",
        22: "A",
        23: "A",
        24: "D",
        25: "C",
        26: "F",
        27: "E",
        28: "E",
        29: "B",
        30: "C",
        31: "D",
      },
    ]);
  },
  768644,
  246088,
  885792,
  992767,
  984191,
  849411,
  210568,
  807962,
  883594,
  781697,
  284560,
  757331,
  996381,
  350015,
  413554,
  152594,
  482690,
  865917,
  419328,
  657732,
  782762,
  392566,
  (e) => {
    "use strict";
    var s,
      i,
      t,
      o,
      n,
      r,
      a,
      l,
      u,
      c,
      _,
      m,
      g,
      d,
      I,
      w,
      p,
      h,
      v,
      x,
      z,
      j,
      q,
      Q,
      b,
      f = e.i(264267),
      y = e.i(271645);
    function k() {
      return (k = Object.assign.bind()).apply(null, arguments);
    }
    e.s(
      [
        "default",
        0,
        (e) =>
          y.createElement(
            "svg",
            k({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 81 81" }, e),
            s ||
              (s = y.createElement("path", {
                stroke: "#2E8BF3",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeMiterlimit: 10,
                strokeWidth: 6.7,
                d: "m67.062 14.392-1.63 1.633M56.426 8.83v2.31m16.186 13.909h-2.305M61.043 53.48a25.04 25.04 0 0 0 3.354-12.886c-.176-13.826-11.659-25.01-25.542-24.902-12.637.098-23.058 6.459-24.846 18.573 0 0-.04 1.096-.087 2.46a19.57 19.57 0 0 1-2.948 9.652l-2.027 3.254c-.555 1 .06 2.245 1.195 2.418l3.306.56.695 11.012c.199 3.147 2.94 5.526 6.098 5.29 3.186-.237 6.518-.49 6.538-.516l1.112 4.435 20.392-2.692-.703-5.449a25 25 0 0 0 3.789-1.709",
              })),
            i ||
              (i = y.createElement("path", {
                stroke: "#2E8BF3",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeMiterlimit: 10,
                strokeWidth: 6.7,
                d: "M24.094 35.13c3.169-4.69 8.535-7.775 14.622-7.775 7.792 0 14.108 6.316 14.108 14.107 0 6.233-5.053 11.286-11.286 11.286a9.03 9.03 0 0 1-9.029-9.028 7.223 7.223 0 0 1 7.223-7.224",
              })),
          ),
      ],
      246088,
    );
    let E = (0, f.svgImage)("/illustrations/anxiety/motiv-1.svg", { width: 790, height: 1018 }),
      A = (0, f.svgImage)("/illustrations/anxiety/motiv-2.svg", { width: 901, height: 991 }),
      C = (0, f.svgImage)("/illustrations/anxiety/motiv-3.svg", { width: 630, height: 997 });
    function M() {
      return (M = Object.assign.bind()).apply(null, arguments);
    }
    (e.s(["IconAnxietyMotiv1", 0, E, "IconAnxietyMotiv2", 0, A, "IconAnxietyMotiv3", 0, C], 768644),
      e.s(
        [
          "default",
          0,
          (e) =>
            y.createElement(
              "svg",
              M({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 86 81" }, e),
              t ||
                (t = y.createElement("path", {
                  stroke: "#2E8BF3",
                  strokeMiterlimit: 10,
                  strokeWidth: 6.7,
                  d: "m80.676 7.144-5.64 5.64 5.64 5.641-5.64 5.641m-8.991 29.352v-24.82c0-9.346-7.576-16.923-16.922-16.923H32.2c-9.346 0-16.923 7.577-16.923 16.923V53.42c0 11.654 9.445 21.095 21.1 21.095h8.568c11.562 0 20.97-9.304 21.098-20.864z",
                })),
              o ||
                (o = y.createElement("path", {
                  stroke: "#2E8BF3",
                  strokeMiterlimit: 10,
                  strokeWidth: 6.7,
                  d: "M40.661 20.137c0 6.231-5.05 11.282-11.281 11.282H15.277m50.535 0H51.944c-6.23 0-11.282-5.051-11.282-11.282M26.56 39.88l5.641 5.64-5.64 5.642M54.762 39.88l-5.64 5.64 5.64 5.642M32.201 61.88h16.923",
                })),
            ),
        ],
        885792,
      ));
    let D = (0, f.svgImage)("/illustrations/burnout/motiv-burn-1.svg", { width: 1077, height: 1004 }),
      O = (0, f.svgImage)("/illustrations/burnout/motiv-burn-2.svg", { width: 1019, height: 965 }),
      F = (0, f.svgImage)("/illustrations/burnout/motiv-burn-3.svg", { width: 940, height: 991 });
    function N() {
      return (N = Object.assign.bind()).apply(null, arguments);
    }
    (e.s(["IconBurnoutMotiv1", 0, D, "IconBurnoutMotiv2", 0, O, "IconBurnoutMotiv3", 0, F], 992767),
      e.s(
        [
          "default",
          0,
          (e) =>
            y.createElement(
              "svg",
              N({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 81 80" }, e),
              y.createElement(
                "mask",
                {
                  id: "start-icon_svg__a",
                  width: 68,
                  height: 68,
                  x: 7,
                  y: 6,
                  maskUnits: "userSpaceOnUse",
                  style: { maskType: "luminance" },
                },
                n || (n = y.createElement("path", { fill: "#fff", d: "M74.176 6.5h-67v67h67z" })),
              ),
              y.createElement(
                "g",
                { mask: "url(#start-icon_svg__a)" },
                y.createElement(
                  "mask",
                  {
                    id: "start-icon_svg__b",
                    width: 68,
                    height: 68,
                    x: 7,
                    y: 6,
                    maskUnits: "userSpaceOnUse",
                    style: { maskType: "luminance" },
                  },
                  r || (r = y.createElement("path", { fill: "#fff", d: "M7.176 6.5h67v67h-67z" })),
                ),
                a ||
                  (a = y.createElement(
                    "g",
                    {
                      stroke: "#2E8BF3",
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeMiterlimit: 10,
                      strokeWidth: 6.7,
                      mask: "url(#start-icon_svg__b)",
                    },
                    y.createElement("path", {
                      d: "M30.205 24.297v-5.235a5.234 5.234 0 0 1 5.235-5.234h10.468a5.234 5.234 0 0 1 5.235 5.234v5.235",
                    }),
                    y.createElement("path", {
                      d: "M71.557 29.531a10.4 10.4 0 0 1-5.07 8.946c-5.031 3.01-13.287 6.757-25.813 6.757s-20.782-3.747-25.814-6.757a10.4 10.4 0 0 1-5.069-8.946c0-2.879 2.355-5.234 5.234-5.234h51.297c2.88 0 5.235 2.355 5.235 5.234",
                    }),
                    y.createElement("path", {
                      d: "M66.322 38.575v22.362a5.234 5.234 0 0 1-5.234 5.235H20.26a5.235 5.235 0 0 1-5.235-5.234V38.575M40.674 40v10.469",
                    }),
                  )),
              ),
            ),
        ],
        984191,
      ));
    let B = (0, f.svgImage)("/illustrations/careers/motiv-careers-1.svg", { width: 1080, height: 953 }),
      R = (0, f.svgImage)("/illustrations/careers/motiv-careers-2.svg", { width: 982, height: 967 }),
      L = (0, f.svgImage)("/illustrations/careers/motiv-careers-3.svg", { width: 1073, height: 653 });
    function S() {
      return (S = Object.assign.bind()).apply(null, arguments);
    }
    (e.s(["IconCareersMotiv1", 0, B, "IconCareersMotiv2", 0, R, "IconCareersMotiv3", 0, L], 849411),
      e.s(
        [
          "default",
          0,
          (e) =>
            y.createElement(
              "svg",
              S({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 81 81" }, e),
              l ||
                (l = y.createElement("path", {
                  stroke: "#2E8BF3",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeMiterlimit: 10,
                  strokeWidth: 6.7,
                  d: "M58.176 61.33h-5m5-10h10l-4.16-12.48c-.558-1.673-.794-3.424-.98-5.177-1.514-14.257-15.061-24.976-30.26-21.774-9.687 2.041-17.408 10.039-19.177 19.778-1.556 8.565 1.293 16.526 6.655 22.036 1.84 1.891 2.921 4.386 2.921 7.024v4.593a5 5 0 0 0 5 5h25.001a5 5 0 0 0 5-5v-4m0 0h-5",
                })),
              u ||
                (u = y.createElement("path", {
                  stroke: "#2E8BF3",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeMiterlimit: 10,
                  strokeWidth: 6.7,
                  d: "m38.176 21.33 4.408 8.933 9.858 1.432-7.133 6.953 1.684 9.817-8.817-4.635-8.817 4.635 1.684-9.817-7.133-6.953 9.858-1.433z",
                })),
            ),
        ],
        210568,
      ));
    let T = (0, f.svgImage)("/illustrations/confidence/motiv-1.svg", { width: 620, height: 981 }),
      W = (0, f.svgImage)("/illustrations/confidence/motiv-2.svg", { width: 874, height: 1027 }),
      U = (0, f.svgImage)("/illustrations/confidence/motiv-3.svg", { width: 827, height: 1013 });
    function P() {
      return (P = Object.assign.bind()).apply(null, arguments);
    }
    (e.s(["IconConfidenceMotiv1", 0, T, "IconConfidenceMotiv2", 0, W, "IconConfidenceMotiv3", 0, U], 807962),
      e.s(
        [
          "default",
          0,
          (e) =>
            y.createElement(
              "svg",
              P({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 81 80" }, e),
              c ||
                (c = y.createElement("path", {
                  stroke: "#2E8BF3",
                  strokeMiterlimit: 10,
                  strokeWidth: 6.7,
                  d: "M26.76 45.465c-7.686 0-13.916-6.23-13.916-13.916 0-7.064 5.28-12.834 12.098-13.733C27.192 11.25 33.348 6.5 40.676 6.5c9.222 0 16.699 7.476 16.699 16.7 6.148 0 11.133 4.983 11.133 11.132 0 6.148-4.985 11.133-11.133 11.133zm5.344 0-7.59 13.916h9.124L24.722 73.5M54.37 45.465 46.78 59.38h9.124L46.988 73.5",
                })),
            ),
        ],
        883594,
      ));
    let G = (0, f.svgImage)("/illustrations/depression/motiv-depr-1.svg", { width: 1081, height: 1046 }),
      K = (0, f.svgImage)("/illustrations/depression/motiv-depr-2.svg", { width: 959, height: 969 }),
      $ = (0, f.svgImage)("/illustrations/depression/motiv-depr-3.svg", { width: 972, height: 636 });
    function H() {
      return (H = Object.assign.bind()).apply(null, arguments);
    }
    (e.s(["IconDeprMotiv1", 0, G, "IconDeprMotiv2", 0, K, "IconDeprMotiv3", 0, $], 781697),
      e.s(
        [
          "default",
          0,
          (e) =>
            y.createElement(
              "svg",
              H({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 81 81" }, e),
              _ ||
                (_ = y.createElement("path", {
                  stroke: "#2E8BF3",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeMiterlimit: 10,
                  strokeWidth: 6.7,
                  d: "M42.984 56.938c0 6.757-4.624 9.586-9.928 10.569-6.531 1.21-11.51-.317-12.738-.54l-.07-.012c-2.262-.435-3.888-2.43-3.888-4.735v-8.806a1.18 1.18 0 0 0-1.115-1.181c-2.16-.116-5.802-.719-4.506-3.744 1.554-3.627 3.43-8.862 3.864-10.316q.06-.205.052-.417c-.641-16.588 20.888-37.962 44.1-23.91 25.534 15.456 2.828 38.405 2.828 42.403 0 11-.052 16.118-.052 16.118h-25.53v-5.634",
                })),
              m ||
                (m = y.createElement("path", {
                  stroke: "#2E8BF3",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeMiterlimit: 10,
                  strokeWidth: 6.7,
                  d: "M50.277 23.633a6.97 6.97 0 0 0-6.504 4.45 6.97 6.97 0 0 0-6.503-4.45c-4.042-.011-6.953 3.435-6.953 7.49h0v.081c.024 3.128 1.377 5.952 3.218 8.351 2.954 3.85 7.161 6.608 9.138 7.776a2.23 2.23 0 0 0 2.244.014c1.986-1.138 6.15-3.844 9.088-7.79 1.759-2.362 3.077-5.17 3.228-8.351q.015-.3.016-.607a6.97 6.97 0 0 0-6.972-6.964",
                })),
            ),
        ],
        284560,
      ));
    let Y = (0, f.svgImage)("/illustrations/imposter-syndrome/motiv-imposter-syndrome-1.svg", {
        width: 750,
        height: 971,
      }),
      V = (0, f.svgImage)("/illustrations/imposter-syndrome/motiv-imposter-syndrome-2.svg", {
        width: 830,
        height: 951,
      }),
      Z = (0, f.svgImage)("/illustrations/imposter-syndrome/motiv-imposter-syndrome-3.svg", {
        width: 1080,
        height: 742,
      });
    function J() {
      return (J = Object.assign.bind()).apply(null, arguments);
    }
    (e.s(
      [
        "IconImposterSyndromeMotiv1",
        0,
        Y,
        "IconImposterSyndromeMotiv2",
        0,
        V,
        "IconImposterSyndromeMotiv3",
        0,
        Z,
      ],
      757331,
    ),
      e.s(
        [
          "default",
          0,
          (e) =>
            y.createElement(
              "svg",
              J({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 81 81" }, e),
              g ||
                (g = y.createElement("path", {
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeMiterlimit: 10,
                  strokeWidth: 6.7,
                  d: "M66.42 42.003c.166-1.177.297-2.376.297-3.594 0-15.719-12.743-28.462-28.462-28.462-15.72 0-28.462 12.743-28.462 28.462 0 13.778 9.767 25.32 22.77 27.95m4.727-26.985-8.653 8.523m9.553-26.303v14.041",
                })),
              d ||
                (d = y.createElement("path", {
                  fill: "currentColor",
                  d: "M42.115 38.344a3.926 3.926 0 1 0-7.851 0 3.926 3.926 0 0 0 7.851 0",
                })),
              I ||
                (I = y.createElement("path", {
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeMiterlimit: 10,
                  strokeWidth: 6.7,
                  d: "M70.512 55.879c.721.81 1.047 1.636 1.047 2.805 0 5.902-5.873 6.555-9.318 7.114a2.24 2.24 0 0 0-1.795 1.644c-.754 3.163-3.58 4.27-6.831 4.27h-4.138a7.02 7.02 0 0 1-6.83-5.393l-2.504-11.47c-.656-2.752 1.431-5.12 4.26-5.12H58.54c2.83 0 4.916 2.258 4.26 5.01l-.532 2.318",
                })),
            ),
        ],
        996381,
      ));
    let X = (0, f.svgImage)("/illustrations/procrastination/motiv-procrastination-1.svg", {
      width: 600,
      height: 919,
    });
    function ee() {
      return (ee = Object.assign.bind()).apply(null, arguments);
    }
    (e.s(["IconProcrastinationMotiv1", 0, X], 350015),
      e.s(
        [
          "default",
          0,
          (e) =>
            y.createElement(
              "svg",
              ee({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 81 81" }, e),
              w ||
                (w = y.createElement("path", {
                  stroke: "#2E8BF3",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeMiterlimit: 10,
                  strokeWidth: 6.7,
                  d: "M58.996 62.291h-5.234m5.234-10.469h10.469L65.11 38.757c-.584-1.752-.831-3.584-1.026-5.42C62.5 18.413 48.317 7.191 32.406 10.543c-10.14 2.137-18.224 10.51-20.076 20.705-1.629 8.967 1.353 17.301 6.967 23.07 1.927 1.979 3.058 4.59 3.058 7.352v4.809a5.234 5.234 0 0 0 5.235 5.234h26.172a5.234 5.234 0 0 0 5.234-5.235v-4.187m0 0h-5.234",
                })),
              p ||
                (p = y.createElement("path", {
                  stroke: "#2E8BF3",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeMiterlimit: 10,
                  strokeWidth: 6.7,
                  d: "M40.676 42.138c5.782 0 10.468-4.687 10.468-10.468 0-5.782-4.686-10.47-10.468-10.47s-10.469 4.688-10.469 10.47c0 5.781 4.687 10.468 10.469 10.468m-7.403-3.066-7.18 7.18",
                })),
            ),
        ],
        413554,
      ));
    let es = (0, f.svgImage)("/illustrations/psychological-archetypes/motiv-psych-arch-1.svg", {
        width: 1081,
        height: 805,
      }),
      ei = (0, f.svgImage)("/illustrations/psychological-archetypes/motiv-psych-arch-2.svg", {
        width: 982,
        height: 805,
      }),
      et = (0, f.svgImage)("/illustrations/psychological-archetypes/motiv-psych-arch-3.svg", {
        width: 596,
        height: 773,
      });
    function eo() {
      return (eo = Object.assign.bind()).apply(null, arguments);
    }
    (e.s(
      [
        "IconPsychologicalArchetypesMotiv1",
        0,
        es,
        "IconPsychologicalArchetypesMotiv2",
        0,
        ei,
        "IconPsychologicalArchetypesMotiv3",
        0,
        et,
      ],
      152594,
    ),
      e.s(
        [
          "default",
          0,
          (e) =>
            y.createElement(
              "svg",
              eo({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 81 81" }, e),
              h ||
                (h = y.createElement("path", {
                  stroke: "#2E8BF3",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeMiterlimit: 10,
                  strokeWidth: 6.7,
                  d: "M65.867 25.472a29.36 29.36 0 0 1 4.309 15.358c0 16.293-13.208 29.5-29.5 29.5s-29.5-13.207-29.5-29.5 13.207-29.5 29.5-29.5a29.36 29.36 0 0 1 15.358 4.309",
                })),
              v ||
                (v = y.createElement("path", {
                  stroke: "#2E8BF3",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeMiterlimit: 10,
                  strokeWidth: 6.7,
                  d: "M57.89 40.83c0 9.508-7.707 17.215-17.214 17.215-9.508 0-17.215-7.707-17.215-17.215s7.707-17.214 17.215-17.214m9.834 7.381-9.834 9.833m19.667-29.5-9.833 9.834v9.833h9.833l9.833-9.833h-9.833z",
                })),
            ),
        ],
        482690,
      ));
    let en = (0, f.svgImage)("/illustrations/strengths/motiv-1.svg", { width: 732, height: 944 }),
      er = (0, f.svgImage)("/illustrations/strengths/motiv-2.svg", { width: 1015, height: 897 }),
      ea = (0, f.svgImage)("/illustrations/strengths/motiv-3.svg", { width: 720, height: 1027 });
    function el() {
      return (el = Object.assign.bind()).apply(null, arguments);
    }
    (e.s(["IconStrengthsMotiv1", 0, en, "IconStrengthsMotiv2", 0, er, "IconStrengthsMotiv3", 0, ea], 865917),
      e.s(
        [
          "default",
          0,
          (e) =>
            y.createElement(
              "svg",
              el({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 80 80" }, e),
              x ||
                (x = y.createElement("path", {
                  stroke: "#2E8BF3",
                  strokeMiterlimit: 10,
                  strokeWidth: 6.7,
                  d: "M70.889 19.062v46.586a5.234 5.234 0 0 1-5.235 5.235H14.357a5.234 5.234 0 0 1-5.234-5.235V19.062a5.234 5.234 0 0 1 5.234-5.234h51.297a5.234 5.234 0 0 1 5.235 5.234Z",
                })),
              z ||
                (z = y.createElement("path", {
                  stroke: "#2E8BF3",
                  strokeMiterlimit: 10,
                  strokeWidth: 6.7,
                  d: "M40.006 37.383v7.851h7.851",
                })),
              j ||
                (j = y.createElement("path", {
                  stroke: "#2E8BF3",
                  strokeLinecap: "square",
                  strokeMiterlimit: 10,
                  strokeWidth: 6.7,
                  d: "M55.709 45.234c0 8.673-7.03 15.703-15.703 15.703s-15.703-7.03-15.703-15.703 7.03-15.703 15.703-15.703 15.703 7.03 15.703 15.703Z",
                })),
              q ||
                (q = y.createElement("path", {
                  stroke: "#2E8BF3",
                  strokeMiterlimit: 10,
                  strokeWidth: 6.7,
                  d: "M24.303 6.5v15.18M40.006 6.5v15.18M55.709 6.5v15.18",
                })),
            ),
        ],
        419328,
      ));
    let eu = (0, f.svgImage)("/illustrations/time-management/motiv-time-1.svg", {
        width: 1081,
        height: 1035,
      }),
      ec = (0, f.svgImage)("/illustrations/time-management/motiv-time-2.svg", { width: 982, height: 1017 }),
      e_ = (0, f.svgImage)("/illustrations/time-management/motiv-time-3.svg", { width: 789, height: 862 });
    function em() {
      return (em = Object.assign.bind()).apply(null, arguments);
    }
    (e.s(["IconMotivTime1", 0, eu, "IconMotivTime2", 0, ec, "IconMotivTime3", 0, e_], 657732),
      e.s(
        [
          "default",
          0,
          (e) =>
            y.createElement(
              "svg",
              em({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 95 81" }, e),
              Q ||
                (Q = y.createElement("path", {
                  stroke: "#2E8BF3",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeMiterlimit: 10,
                  strokeWidth: 6.7,
                  d: "M36.57 7.33H3.8v27.31h32.77z",
                })),
              b ||
                (b = y.createElement("path", {
                  stroke: "#2E8BF3",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeMiterlimit: 10,
                  strokeWidth: 6.7,
                  d: "m3.799 7.33 7.283 10.924h18.206L36.571 7.33M20.184 18.254v5.462m68.967-.148a8.196 8.196 0 0 0-11.591 0l-1.344 1.343-1.343-1.343a8.196 8.196 0 0 0-11.592 11.59l1.344 1.344-.02.02 11.592 11.59.02-.019.019.02 11.59-11.591-.019-.02 1.344-1.343a8.197 8.197 0 0 0 0-11.591M32.02 74.33l15.657-20.482m-.183 0L62.117 74.02M3.799 45.564l87.755 16.568M23.645 74.33H71.71",
                })),
            ),
        ],
        782762,
      ));
    let eg = (0, f.svgImage)("/illustrations/work/motiv-work-1.svg", { width: 792, height: 1080 }),
      ed = (0, f.svgImage)("/illustrations/work/motiv-work-2.svg", { width: 991, height: 714 }),
      eI = (0, f.svgImage)("/illustrations/work/motiv-work-3.svg", { width: 902, height: 946 });
    e.s(["IconWorkMotiv1", 0, eg, "IconWorkMotiv2", 0, ed, "IconWorkMotiv3", 0, eI], 392566);
  },
  892515,
  809149,
  (e) => {
    "use strict";
    var s,
      i,
      t = e.i(264267),
      o = e.i(271645);
    function n() {
      return (n = Object.assign.bind()).apply(null, arguments);
    }
    e.s(
      [
        "default",
        0,
        (e) =>
          o.createElement(
            "svg",
            n({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 81 81" }, e),
            s ||
              (s = o.createElement("path", {
                stroke: "#2E8BF3",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeMiterlimit: 10,
                strokeWidth: 6.7,
                d: "M55.35 24.667c-2.856-2.798-7.446-2.717-10.269.116l-1.999 2.006-1.999-2.006c-2.823-2.833-7.412-2.914-10.27-.116-2.905 2.846-3.221 7.508-1.335 11.154.134.26 2.703 4.944 9.852 9.36l3.752 2.335 3.753-2.334c7.148-4.417 9.717-9.101 9.851-9.361 1.887-3.646 1.57-8.308-1.335-11.154",
              })),
            i ||
              (i = o.createElement("path", {
                stroke: "#2E8BF3",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeMiterlimit: 10,
                strokeWidth: 6.7,
                d: "M55.36 59.993c9.378-4.526 15.816-14.178 15.674-25.319-.193-15.181-12.751-27.461-27.936-27.343-13.821.108-25.218 7.092-27.174 20.394 0 0-.298 6.606-.298 7.31l.001.079-4.841 8.646c-1.325 2.366.292 5.3 3 5.445l1.524.08v6.874a8.45 8.45 0 0 0 7.641 8.41c3.514.337 6.92.656 6.94.63v9.131h22.75",
              })),
          ),
      ],
      809149,
    );
    let r = (0, t.svgImage)("/illustrations/emotional/motiv-emotional-1.svg", { width: 951, height: 835 }),
      a = (0, t.svgImage)("/illustrations/emotional/motiv-emotional-2.svg", { width: 1081, height: 1004 }),
      l = (0, t.svgImage)("/illustrations/emotional/motiv-emotional-3.svg", { width: 760, height: 1034 });
    e.s(["IconEmotionalMotiv1", 0, r, "IconEmotionalMotiv2", 0, a, "IconEmotionalMotiv3", 0, l], 892515);
  },
  47252,
  (e) => {
    "use strict";
    let s = new Set(["span", "b", "strong", "em", "i", "u", "br", "sup", "sub", "small", "a"]),
      i = new Set(["br"]),
      t = /^<\s*(\/?)\s*([a-zA-Z][a-zA-Z0-9]*)([^>]*)>$/,
      o = /([^\s"'<>/=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g,
      n = /^[\w\s:.[\]/%#-]*$/,
      r = /^(\/(?![/\\])|#|https?:\/\/|mailto:)[^\s\p{Cc}]*$/iu,
      a = /^[a-z\s]*$/i,
      l = { amp: "&", quot: '"', apos: "'", lt: "<", gt: ">", nbsp: " " },
      u = (e) => e.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;"),
      c = (e, s, i) => {
        let t,
          o,
          u =
            ((t = !0),
            (o = i.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);?/gi, (e, s) => {
              if ("#" === s[0]) {
                let e = "x" === s[1].toLowerCase() ? parseInt(s.slice(2), 16) : parseInt(s.slice(1), 10);
                return Number.isFinite(e) && e <= 1114111 ? String.fromCodePoint(e) : "";
              }
              let i = l[s.toLowerCase()];
              return (void 0 === i && (t = !1), i ?? e);
            })),
            t ? o : null);
        return null === u
          ? null
          : "class" === s
            ? n.test(u)
              ? u
              : null
            : "a" !== e
              ? null
              : "href" === s
                ? r.test(u.trim())
                  ? u.trim()
                  : null
                : "target" === s
                  ? "_blank" === u
                    ? u
                    : null
                  : "rel" === s
                    ? a.test(u)
                      ? u
                      : null
                    : "title" === s
                      ? u
                      : null;
      },
      _ = (e) => {
        let n = t.exec(e);
        if (!n) return e.replace(/</g, "&lt;");
        let [, r, a, l] = n,
          _ = a.toLowerCase();
        if (!s.has(_)) return "";
        if (r) return i.has(_) ? "" : `</${_}>`;
        let m = [];
        for (let [, e, s, i, t] of l.matchAll(o)) {
          let o = e.toLowerCase(),
            n = c(_, o, s ?? i ?? t ?? "");
          null !== n && m.push(`${o}="${u(n)}"`);
        }
        return `<${[_, ...m].join(" ")}>`;
      };
    e.s([
      "sanitizeTranslationHtml",
      0,
      (e) => ("number" == typeof e ? String(e) : "string" != typeof e ? "" : e.replace(/<[^>]*>?/g, _)),
    ]);
  },
]);
