(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  204680,
  (e) => {
    "use strict";
    var i = e.i(843476),
      t = e.i(861745),
      s = e.i(948148),
      a = e.i(266027);
    e.i(382838);
    var r = e.i(342800),
      o = e.i(353527);
    e.i(867107);
    var c = e.i(1693),
      l = e.i(86596);
    e.i(267493);
    var n = e.i(605663);
    e.i(853754);
    var u = e.i(319970);
    e.i(924482);
    var d = e.i(20511);
    e.s([
      "default",
      0,
      (e) => {
        let { pageSlug: m } = e,
          p = (0, s.useTranslations)(),
          b = (0, t.useLocale)(),
          { data: x } = (0, a.useQuery)((0, n.pageQueryOptions)(m, b)),
          T = (0, l.useUserStore)((e) => e.user);
        return (0, i.jsxs)(i.Fragment, {
          children: [
            (0, i.jsx)(d.DemoStaticHeaderComponent, {}),
            (0, i.jsx)("main", {
              className: "flex flex-1 flex-col",
              children: (0, i.jsx)(o.DemoStaticPageLayoutComponent, {
                breadCrumbLabel: p("cookie_breadcrumb_label"),
                subtitle: p("static_page_cookie_subtitle"),
                title: x?.title || "",
                children: x?.sections?.map((e, t) =>
                  e?.blockType !== "textContent"
                    ? null
                    : (0, i.jsx)(
                        "div",
                        {
                          className: T?.subscriptionId ? "mb-20" : "",
                          children:
                            e?.richDescription && e?.descriptionType === "richText"
                              ? (0, i.jsx)(c.RichText, {
                                  data: e?.richDescription,
                                  className: r.DEMO_STATIC_PAGE_PROSE_CLASS,
                                  disableTextAlign: !0,
                                })
                              : (0, i.jsx)("p", {
                                  className: r.DEMO_STATIC_PAGE_PROSE_CLASS,
                                  children: e?.description,
                                }),
                        },
                        t,
                      ),
                ),
              }),
            }),
            (0, i.jsx)(u.DemoFooterComponent, {}),
          ],
        });
      },
    ]);
  },
]);
