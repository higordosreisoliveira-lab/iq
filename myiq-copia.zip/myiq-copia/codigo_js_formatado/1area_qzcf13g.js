(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  377148,
  (e) => {
    "use strict";
    var t = e.i(834738),
      a = e.i(75540),
      n = e.i(273830),
      r = e.i(271645);
    function i() {
      return (i = Object.assign.bind()).apply(null, arguments);
    }
    var l = r.useLayoutEffect,
      s = function (e) {
        var t = r.default.useRef(e);
        return (
          l(function () {
            t.current = e;
          }),
          t
        );
      },
      o = function (e, t) {
        "function" == typeof e ? e(t) : (e.current = t);
      },
      c = function (e, t) {
        var a = r.default.useRef();
        return r.default.useCallback(
          function (n) {
            ((e.current = n), a.current && o(a.current, null), (a.current = t), t && o(t, n));
          },
          [t],
        );
      },
      d = {
        "min-height": "0",
        "max-height": "none",
        height: "0",
        visibility: "hidden",
        overflow: "hidden",
        position: "absolute",
        "z-index": "-1000",
        top: "0",
        right: "0",
        display: "block",
      },
      u = function (e) {
        Object.keys(d).forEach(function (t) {
          e.style.setProperty(t, d[t], "important");
        });
      },
      p = null,
      h = function (e, t) {
        var a = e.scrollHeight;
        return "border-box" === t.sizingStyle.boxSizing ? a + t.borderSize : a - t.paddingSize;
      },
      m = function () {},
      f = [
        "borderBottomWidth",
        "borderLeftWidth",
        "borderRightWidth",
        "borderTopWidth",
        "boxSizing",
        "fontFamily",
        "fontSize",
        "fontStyle",
        "fontWeight",
        "letterSpacing",
        "lineHeight",
        "paddingBottom",
        "paddingLeft",
        "paddingRight",
        "paddingTop",
        "tabSize",
        "textIndent",
        "textRendering",
        "textTransform",
        "width",
        "wordBreak",
        "wordSpacing",
        "scrollbarGutter",
      ],
      x = !!document.documentElement.currentStyle,
      v = function (e) {
        var t = window.getComputedStyle(e);
        if (null === t) return null;
        var a = f.reduce(function (e, a) {
            return ((e[a] = t[a]), e);
          }, {}),
          n = a.boxSizing;
        if ("" === n) return null;
        x &&
          "border-box" === n &&
          (a.width =
            parseFloat(a.width) +
            parseFloat(a.borderRightWidth) +
            parseFloat(a.borderLeftWidth) +
            parseFloat(a.paddingRight) +
            parseFloat(a.paddingLeft) +
            "px");
        var r = parseFloat(a.paddingBottom) + parseFloat(a.paddingTop),
          i = parseFloat(a.borderBottomWidth) + parseFloat(a.borderTopWidth);
        return { sizingStyle: a, paddingSize: r, borderSize: i };
      };
    function _(e, t, a) {
      var n = s(a);
      r.useLayoutEffect(function () {
        var a = function (e) {
          return n.current(e);
        };
        if (e)
          return (
            e.addEventListener(t, a),
            function () {
              return e.removeEventListener(t, a);
            }
          );
      }, []);
    }
    var g = function (e, t) {
        _(document.body, "reset", function (a) {
          e.current.form === a.target && t(a);
        });
      },
      b = function (e) {
        _(window, "resize", e);
      },
      E = function (e) {
        _(document.fonts, "loadingdone", e);
      },
      y = ["cacheMeasurements", "maxRows", "minRows", "onChange", "onHeightChange"],
      C = r.forwardRef(function (e, t) {
        var a = e.cacheMeasurements,
          n = e.maxRows,
          l = e.minRows,
          s = e.onChange,
          o = void 0 === s ? m : s,
          d = e.onHeightChange,
          f = void 0 === d ? m : d,
          x = (function (e, t) {
            if (null == e) return {};
            var a = {};
            for (var n in e)
              if ({}.hasOwnProperty.call(e, n)) {
                if (-1 !== t.indexOf(n)) continue;
                a[n] = e[n];
              }
            return a;
          })(e, y),
          _ = void 0 !== x.value,
          C = r.useRef(null),
          w = c(C, t),
          k = r.useRef(0),
          j = r.useRef(),
          S = function () {
            var e = C.current,
              t = a && j.current ? j.current : v(e);
            if (t) {
              j.current = t;
              var r,
                i,
                s,
                o,
                c,
                d,
                m,
                x,
                _,
                g,
                b,
                E =
                  ((r = e.value || e.placeholder || "x"),
                  void 0 === (i = l) && (i = 1),
                  void 0 === (s = n) && (s = 1 / 0),
                  p ||
                    ((p = document.createElement("textarea")).setAttribute("tabindex", "-1"),
                    p.setAttribute("aria-hidden", "true"),
                    u(p)),
                  null === p.parentNode && document.body.appendChild(p),
                  (o = t.paddingSize),
                  (c = t.borderSize),
                  (m = (d = t.sizingStyle).boxSizing),
                  Object.keys(d).forEach(function (e) {
                    p.style[e] = d[e];
                  }),
                  u(p),
                  (p.value = r),
                  (x = h(p, t)),
                  (p.value = r),
                  (x = h(p, t)),
                  (p.value = "x"),
                  (g = (_ = p.scrollHeight - o) * i),
                  "border-box" === m && (g = g + o + c),
                  (x = Math.max(g, x)),
                  (b = _ * s),
                  "border-box" === m && (b = b + o + c),
                  [(x = Math.min(b, x)), _]),
                y = E[0],
                w = E[1];
              k.current !== y &&
                ((k.current = y),
                e.style.setProperty("height", y + "px", "important"),
                f(y, { rowHeight: w }));
            }
          };
        return (
          r.useLayoutEffect(S),
          g(C, function () {
            if (!_) {
              var e = C.current.value;
              requestAnimationFrame(function () {
                var t = C.current;
                t && e !== t.value && S();
              });
            }
          }),
          b(S),
          E(S),
          r.createElement(
            "textarea",
            i({}, x, {
              onChange: function (e) {
                (_ || S(), o(e));
              },
              ref: w,
            }),
          )
        );
      }),
      w = e.i(619110),
      k = e.i(843476),
      j = (0, n.forwardRef)((e, n) => {
        let {
            style: i,
            minRows: l = 3,
            maxRows: s = 8,
            cacheMeasurements: o = !1,
            disableAutosize: c = !1,
            onHeightChange: d,
            ...u
          } = e,
          {
            Component: p,
            label: h,
            description: m,
            startContent: f,
            endContent: x,
            hasHelper: v,
            shouldLabelBeOutside: _,
            shouldLabelBeInside: g,
            isInvalid: b,
            errorMessage: E,
            getBaseProps: y,
            getLabelProps: j,
            getInputProps: S,
            getInnerWrapperProps: A,
            getInputWrapperProps: L,
            getHelperWrapperProps: D,
            getDescriptionProps: M,
            getErrorMessageProps: R,
            isClearable: F,
            getClearButtonProps: T,
          } = (0, t.useInput)({ ...u, ref: n, isMultiline: !0 }),
          [I, N] = (0, r.useState)(l > 1),
          [O, B] = (0, r.useState)(!1),
          z = h ? (0, k.jsx)("label", { ...j(), children: h }) : null,
          K = S(),
          P = c
            ? (0, k.jsx)("textarea", { ...K, style: (0, a.mergeProps)(K.style, null != i ? i : {}) })
            : (0, k.jsx)(C, {
                ...K,
                cacheMeasurements: o,
                "data-hide-scroll": (0, a.dataAttr)(!O),
                maxRows: s,
                minRows: l,
                style: (0, a.mergeProps)(K.style, null != i ? i : {}),
                onHeightChange: (e, t) => {
                  (1 === l && N(e >= 2 * t.rowHeight),
                    s > l && B(e >= s * t.rowHeight),
                    null == d || d(e, t));
                },
              }),
          H = (0, r.useMemo)(
            () => (F ? (0, k.jsx)("button", { ...T(), children: (0, k.jsx)(w.CloseFilledIcon, {}) }) : null),
            [F, T],
          ),
          W = (0, r.useMemo)(
            () =>
              f || x
                ? (0, k.jsxs)("div", { ...A(), children: [f, P, x] })
                : (0, k.jsx)("div", { ...A(), children: P }),
            [f, K, x, A],
          ),
          U = b && E,
          V = U || m;
        return (0, k.jsxs)(p, {
          ...y(),
          children: [
            _ ? z : null,
            (0, k.jsxs)("div", {
              ...L(),
              "data-has-multiple-rows": (0, a.dataAttr)(I),
              children: [g ? z : null, W, H],
            }),
            v && V
              ? (0, k.jsx)("div", {
                  ...D(),
                  children: U
                    ? (0, k.jsx)("div", { ...R(), children: E })
                    : (0, k.jsx)("div", { ...M(), children: m }),
                })
              : null,
          ],
        });
      });
    ((j.displayName = "HeroUI.Textarea"), e.s(["Textarea", 0, j], 377148));
  },
  727728,
  500926,
  (e) => {
    "use strict";
    var t = e.i(523173);
    (e.s(
      [
        "REPORT_FEEDBACK_MODAL_CONFIG",
        0,
        { SHOW_MODAL_DELAY: 3e4 },
        "getStepEventView",
        0,
        (e) => {
          switch (e) {
            case "initial":
              return t.EAnalyticEvents.FEEDBACK_MODAL_VIEWED;
            case "negative-feedback":
              return t.EAnalyticEvents.HELP_US_FEEDBACK_MODAL_VIEWED;
            case "review":
              return t.EAnalyticEvents.TRUST_PILOT_FEEDBACK_MODAL_VIEWED;
            default:
              return null;
          }
        },
      ],
      500926,
    ),
      e.s([], 727728));
  },
  291261,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(475254);
    let n = (0, a.default)("thumbs-down", [
        ["path", { d: "M17 14V2", key: "8ymqnk" }],
        [
          "path",
          {
            d: "M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22a3.13 3.13 0 0 1-3-3.88Z",
            key: "m61m77",
          },
        ],
      ]),
      r = (0, a.default)("thumbs-up", [
        ["path", { d: "M7 10v12", key: "1qc93n" }],
        [
          "path",
          {
            d: "M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2a3.13 3.13 0 0 1 3 3.88Z",
            key: "emmmcr",
          },
        ],
      ]);
    var i = e.i(948148),
      l = e.i(271645),
      s = e.i(742214),
      o = e.i(377148),
      c = e.i(954616),
      d = e.i(134404);
    e.i(531122);
    var u = e.i(81844);
    let p = async (e) => {
      try {
        let t = await u.httpInstance.post(`${d.EApiRoutes.PRODUCT_FEEDBACK}`, {
          json: e,
          throwHttpErrors: !1,
          headers: { "Content-Type": "application/json" },
        });
        return await t.json();
      } catch {
        return { error: "Failed to save product feedback", success: !1 };
      }
    };
    e.i(727728);
    var h = e.i(500926),
      m = e.i(846932),
      f = e.i(663615);
    let x = (e) => {
      let { onClick: a, disabled: n = !1, className: r = "" } = e;
      return (0, t.jsx)(m.motion.button, {
        onClick: a,
        className: (0, f.cn)(
          "absolute right-4 top-4 text-xl text-gray-400 hover:text-gray-600 rtl:left-4 rtl:right-auto",
          r,
        ),
        disabled: n,
        children: "×",
      });
    };
    var v = e.i(523173),
      _ = e.i(429067),
      g = e.i(382963),
      b = e.i(622963),
      E = e.i(86596);
    e.i(568267);
    var y = e.i(154692);
    e.i(470366);
    var C = e.i(504001),
      w = e.i(202042);
    (e.s([], 933059),
      e.i(933059),
      e.s(
        [
          "ReportFeedbackModalComponent",
          0,
          (e) => {
            let a,
              { review_link: u } = e,
              m = (0, i.useTranslations)(),
              f = (0, w.useRouter)(),
              [k] = (0, l.useState)(_.getIsNativeApp),
              [j, S] = (0, l.useState)(() => (k ? "review" : "initial")),
              [A, L] = (0, l.useState)(""),
              [D, M] = (0, l.useState)(!1),
              R = (0, E.useUserStore)((e) => e.user?.email),
              F = (0, E.useUserStore)((e) => e.user?.id),
              { handleChangeModalStore: T } = (0, b.useModalStore)(),
              { trigger: I } = (0, g.useUpdateUserInDatabaseMutation)(),
              { trigger: N } = {
                ...(a = (0, c.useMutation)({ mutationFn: (e) => p(e) })),
                trigger: a.mutateAsync,
              },
              { data: O } = (0, g.useGetProfileQuery)(R || ""),
              B = O?.data?.user_info,
              z = B?.review_link || u;
            (0, l.useEffect)(() => {
              let e = (0, h.getStepEventView)(j);
              e && (0, C.trackClientEvents)({ event: e, user: B });
            }, [j]);
            let K = async () => {
                B?.email &&
                  (await I({ email: B?.email || R, userInfo: { isProductFeedbackModalShown: !0 } }));
              },
              P = () => {
                T({ isModalVisible: !1 });
              },
              H = async () => {
                (S("negative-feedback"),
                  (0, C.trackClientEvents)({
                    event: v.EAnalyticEvents.FEEDBACK_MODAL_CLICKED,
                    user: B,
                    params: { content_value: "No" },
                  }));
              },
              W = async () => {
                (S("review"),
                  (0, C.trackClientEvents)({
                    event: v.EAnalyticEvents.FEEDBACK_MODAL_CLICKED,
                    user: B,
                    params: { content_value: "Yes" },
                  }));
              },
              U = async () => {
                ((0, C.trackClientEvents)({
                  event: v.EAnalyticEvents.TRUST_PILOT_FEEDBACK_MODAL_SUBMIT_CLICKED,
                  user: B,
                }),
                  await K(),
                  P(),
                  (0, _.requestNativeStoreReview)() || f.push(z || d.EClientRoutes.REPORT));
              },
              V = async () => {
                ((0, C.trackClientEvents)({
                  event: v.EAnalyticEvents.TRUST_PILOT_FEEDBACK_MODAL_SKIP_CLICKED,
                  user: B,
                }),
                  await K(),
                  P());
              },
              q = async () => {
                (await K(),
                  P(),
                  (0, C.trackClientEvents)({
                    event: v.EAnalyticEvents.HELP_US_FEEDBACK_MODAL_SKIP_CLICKED,
                    user: B,
                  }));
              },
              G = async () => {
                if (A.trim() && !D) {
                  (M(!0),
                    (0, C.trackClientEvents)({
                      event: v.EAnalyticEvents.HELP_US_FEEDBACK_MODAL_SUBMIT_CLICKED,
                      user: B,
                    }));
                  try {
                    (await N({
                      userId: F || void 0,
                      email: B?.email || R || void 0,
                      textInput: A.trim(),
                      triggerSource: "report_feedback_modal",
                    }),
                      await K(),
                      S("success"));
                  } finally {
                    M(!1);
                  }
                }
              },
              Y = async () => {
                (await K(), P());
              };
            if ("success" === j)
              return (0, t.jsxs)(s.ModalContent, {
                className:
                  "relative grid max-h-[calc(100*var(--vh,1vh))] w-[calc(100%-24px)] max-w-[430px] gap-4 rounded-xl px-4 py-6 sm:w-[calc(100%-32px)]",
                children: [
                  (0, t.jsx)(x, {
                    onClick: P,
                    className: "right-1 top-0 px-2 text-2xl rtl:left-1 rtl:right-auto",
                  }),
                  (0, t.jsxs)("div", {
                    className: "grid justify-items-center gap-2 py-8 text-center",
                    children: [
                      (0, t.jsx)("h5", {
                        className: "text-lg font-semibold",
                        children: m("report_feedback_modal_success_title"),
                      }),
                      (0, t.jsx)("p", {
                        className: "text-base text-default-600",
                        children: m("report_feedback_modal_success_body"),
                      }),
                    ],
                  }),
                ],
              });
            if ("negative-feedback" === j) {
              let e = 0 === A.trim().length || D;
              return (0, t.jsxs)(s.ModalContent, {
                className:
                  "relative grid max-h-[calc(100*var(--vh,1vh))] w-[calc(100%-24px)] max-w-[430px] gap-4 rounded-xl px-4 py-6 sm:w-[calc(100%-32px)]",
                children: [
                  (0, t.jsx)(x, {
                    onClick: Y,
                    className: "right-1 top-0 px-2 text-2xl rtl:left-1 rtl:right-auto",
                  }),
                  (0, t.jsxs)("div", {
                    className: "grid justify-items-center gap-2 text-center",
                    children: [
                      (0, t.jsx)("h5", {
                        className: "text-lg font-semibold",
                        children: m("report_feedback_modal_negative_feedback_title"),
                      }),
                      (0, t.jsx)("p", {
                        className: "text-base text-default-600",
                        children: m("report_feedback_modal_negative_feedback_description"),
                      }),
                    ],
                  }),
                  (0, t.jsx)(o.Textarea, {
                    value: A,
                    onValueChange: L,
                    placeholder: m("report_feedback_modal_negative_feedback_textarea_placeholder"),
                    maxLength: 3e3,
                    minRows: 3,
                    variant: "bordered",
                    classNames: {
                      base: "w-full",
                      input: "text-base focus:outline-none focus:ring-0",
                      inputWrapper:
                        "!border focus-within:!border-default-400 focus-within:!ring-0 focus-within:!shadow-none",
                    },
                  }),
                  (0, t.jsxs)("div", {
                    className: "mt-2 flex flex-col gap-2",
                    children: [
                      (0, t.jsx)(y.ButtonComponent, {
                        text: m("report_feedback_modal_negative_feedback_send_button_text"),
                        onClick: G,
                        size: "sm",
                        fullWidth: !0,
                        opt: { isDisabled: e, isLoading: D },
                      }),
                      (0, t.jsx)(y.ButtonComponent, {
                        text: m("btn_skip"),
                        onClick: q,
                        size: "sm",
                        variant: "bordered",
                      }),
                    ],
                  }),
                ],
              });
            }
            let Z = "initial" === j,
              Q = m(
                k ? "checkout_promo_page_loving_experience" : "report_feedback_modal_title_great_to_hear",
              ),
              $ = m(k ? "checkout_promo_page_ask_a_review" : "report_feedback_modal_description"),
              J = Z ? m("report_feedback_modal_title") : Q,
              X = Z ? m("report_feedback_modal_subtitle") : $,
              ee = m(Z ? "analyzing_page_modal_1_answer_2" : "checkout_promo_page_leave_a_review"),
              et = m(Z ? "analyzing_page_modal_1_answer_1" : "report_feedback_modal_maybe_later");
            return (0, t.jsxs)(s.ModalContent, {
              className:
                "relative grid max-h-[calc(100*var(--vh,1vh))] w-[calc(100%-24px)] max-w-[430px] gap-4 rounded-xl px-4 py-6 sm:w-[calc(100%-32px)]",
              children: [
                (0, t.jsx)(x, {
                  onClick: Y,
                  className: "right-1 top-0 px-2 text-2xl rtl:left-1 rtl:right-auto",
                }),
                (0, t.jsxs)("div", {
                  className: "grid justify-items-center gap-2 text-center [&_svg]:w-[40px]",
                  children: [
                    (0, t.jsx)("h5", {
                      className: "text-lg font-semibold [@media(max-height:500px)]:text-lg",
                      children: J,
                    }),
                    X && (0, t.jsx)("p", { className: "text-base text-default-600", children: X }),
                  ],
                }),
                (0, t.jsxs)("div", {
                  className: "mt-4 grid grid-cols-2 gap-2 [@media(max-height:600px)]:grid-cols-1",
                  children: [
                    (0, t.jsx)(y.ButtonComponent, {
                      text: et,
                      onClick: Z ? H : V,
                      size: "sm",
                      variant: "default",
                      fullWidth: !0,
                      startContent: Z ? (0, t.jsx)(n, { className: "h-5 w-5" }) : null,
                    }),
                    (0, t.jsx)(y.ButtonComponent, {
                      text: ee,
                      onClick: Z ? W : U,
                      size: "sm",
                      fullWidth: !0,
                      startContent: Z ? (0, t.jsx)(r, { className: "h-5 w-5" }) : null,
                    }),
                  ],
                }),
              ],
            });
          },
        ],
        291261,
      ));
  },
  284533,
  function (e) {
    e.n(e.i(291261));
  },
]);
