(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  584735,
  871363,
  559745,
  856564,
  143674,
  (e) => {
    "use strict";
    var t,
      r = e.i(843476);
    function a(e) {
      let { isSelected: t, disableAnimation: a, ...n } = e;
      return (0, r.jsx)("svg", {
        "aria-hidden": "true",
        fill: "none",
        role: "presentation",
        stroke: "currentColor",
        strokeDasharray: 22,
        strokeDashoffset: t ? 44 : 66,
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 2,
        style: !a && t ? { transition: "stroke-dashoffset 250ms linear 0.2s" } : {},
        viewBox: "0 0 17 18",
        ...n,
        children: (0, r.jsx)("polyline", { points: "1 9 7 14 15 4" }),
      });
    }
    function n(e) {
      let { isSelected: t, disableAnimation: a, ...n } = e;
      return (0, r.jsx)("svg", {
        stroke: "currentColor",
        strokeWidth: 3,
        viewBox: "0 0 24 24",
        ...n,
        children: (0, r.jsx)("line", { x1: "21", x2: "3", y1: "12", y2: "12" }),
      });
    }
    function i(e) {
      let { isIndeterminate: t, ...i } = e;
      return (0, r.jsx)(t ? n : a, { ...i });
    }
    var [o, l] = (0, e.i(526823).createContext)({ name: "CheckboxGroupContext", strict: !1 });
    e.s(["CheckboxGroupProvider", 0, o, "useCheckboxGroupContext", 0, l], 871363);
    var s = e.i(595494),
      d = e.i(271645),
      u = e.i(335190);
    function c() {
      var e;
      let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
        { isReadOnly: r } = t,
        [a, n] = (0, u.useControlledState)(t.isSelected, t.defaultSelected || !1, t.onChange),
        [i] = (0, d.useState)(a);
      return {
        isSelected: a,
        defaultSelected: null != (e = t.defaultSelected) ? e : i,
        setSelected: function (e) {
          r || n(e);
        },
        toggle: function () {
          r || n(!a);
        },
      };
    }
    var f = e.i(984898),
      v = e.i(779754),
      p = (0, f.tv)({
        slots: {
          base: "group relative max-w-fit inline-flex items-center justify-start cursor-pointer tap-highlight-transparent p-2 -m-2 select-none",
          wrapper: [
            "relative",
            "inline-flex",
            "items-center",
            "justify-center",
            "shrink-0",
            "overflow-hidden",
            "before:content-['']",
            "before:absolute",
            "before:inset-0",
            "before:border-solid",
            "before:border-2",
            "before:box-border",
            "before:border-default",
            "after:content-['']",
            "after:absolute",
            "after:inset-0",
            "after:scale-50",
            "after:opacity-0",
            "after:origin-center",
            "group-data-[selected=true]:after:scale-100",
            "group-data-[selected=true]:after:opacity-100",
            "group-data-[hover=true]:before:bg-default-100",
            ...v.groupDataFocusVisibleClasses,
          ],
          hiddenInput: v.hiddenInputClasses,
          icon: "z-10 w-4 h-3 opacity-0 group-data-[selected=true]:opacity-100 pointer-events-none",
          label: "relative text-foreground select-none",
        },
        variants: {
          color: {
            default: { wrapper: "after:bg-default after:text-default-foreground text-default-foreground" },
            primary: { wrapper: "after:bg-primary after:text-primary-foreground text-primary-foreground" },
            secondary: {
              wrapper: "after:bg-secondary after:text-secondary-foreground text-secondary-foreground",
            },
            success: { wrapper: "after:bg-success after:text-success-foreground text-success-foreground" },
            warning: { wrapper: "after:bg-warning after:text-warning-foreground text-warning-foreground" },
            danger: { wrapper: "after:bg-danger after:text-danger-foreground text-danger-foreground" },
          },
          size: {
            sm: {
              wrapper: [
                "w-4 h-4 me-2",
                "rounded-[calc(var(--heroui-radius-medium)*0.5)]",
                "before:rounded-[calc(var(--heroui-radius-medium)*0.5)]",
                "after:rounded-[calc(var(--heroui-radius-medium)*0.5)]",
              ],
              label: "text-small",
              icon: "w-3 h-2",
            },
            md: {
              wrapper: [
                "w-5 h-5 me-2",
                "rounded-[calc(var(--heroui-radius-medium)*0.6)]",
                "before:rounded-[calc(var(--heroui-radius-medium)*0.6)]",
                "after:rounded-[calc(var(--heroui-radius-medium)*0.6)]",
              ],
              label: "text-medium",
              icon: "w-4 h-3",
            },
            lg: {
              wrapper: [
                "w-6 h-6 me-2",
                "rounded-[calc(var(--heroui-radius-medium)*0.7)]",
                "before:rounded-[calc(var(--heroui-radius-medium)*0.7)]",
                "after:rounded-[calc(var(--heroui-radius-medium)*0.7)]",
              ],
              label: "text-large",
              icon: "w-5 h-4",
            },
          },
          radius: {
            none: { wrapper: "rounded-none before:rounded-none after:rounded-none" },
            sm: {
              wrapper: [
                "rounded-[calc(var(--heroui-radius-medium)*0.5)]",
                "before:rounded-[calc(var(--heroui-radius-medium)*0.5)]",
                "after:rounded-[calc(var(--heroui-radius-medium)*0.5)]",
              ],
            },
            md: {
              wrapper: [
                "rounded-[calc(var(--heroui-radius-medium)*0.6)]",
                "before:rounded-[calc(var(--heroui-radius-medium)*0.6)]",
                "after:rounded-[calc(var(--heroui-radius-medium)*0.6)]",
              ],
            },
            lg: {
              wrapper: [
                "rounded-[calc(var(--heroui-radius-medium)*0.7)]",
                "before:rounded-[calc(var(--heroui-radius-medium)*0.7)]",
                "after:rounded-[calc(var(--heroui-radius-medium)*0.7)]",
              ],
            },
            full: { wrapper: "rounded-full before:rounded-full after:rounded-full" },
          },
          lineThrough: {
            true: {
              label: [
                "inline-flex",
                "items-center",
                "justify-center",
                "before:content-['']",
                "before:absolute",
                "before:bg-foreground",
                "before:w-0",
                "before:h-0.5",
                "group-data-[selected=true]:opacity-60",
                "group-data-[selected=true]:before:w-full",
              ],
            },
          },
          isDisabled: { true: { base: "opacity-disabled pointer-events-none" } },
          isInvalid: { true: { wrapper: "before:border-danger", label: "text-danger" } },
          disableAnimation: {
            true: { wrapper: "transition-none", icon: "transition-none", label: "transition-none" },
            false: {
              wrapper: [
                "before:transition-colors",
                "group-data-[pressed=true]:scale-95",
                "transition-transform",
                "after:transition-transform-opacity",
                "after:!ease-linear",
                "after:!duration-200",
                "motion-reduce:transition-none",
              ],
              icon: "transition-opacity motion-reduce:transition-none",
              label: "transition-colors-opacity before:transition-width motion-reduce:transition-none",
            },
          },
        },
        defaultVariants: { color: "primary", size: "md", isDisabled: !1, lineThrough: !1 },
      }),
      m = (0, f.tv)({
        slots: {
          base: "relative flex flex-col gap-2",
          label: "relative text-medium text-foreground-500",
          wrapper: "flex flex-col flex-wrap gap-2 data-[orientation=horizontal]:flex-row",
          description: "text-small text-foreground-400",
          errorMessage: "text-small text-danger",
        },
        variants: {
          isRequired: { true: { label: "after:content-['*'] after:text-danger after:ml-0.5" } },
          isInvalid: { true: { description: "text-danger" } },
          disableAnimation: {
            true: {},
            false: { description: "transition-colors !duration-150 motion-reduce:transition-none" },
          },
        },
        defaultVariants: { isInvalid: !1, isRequired: !1 },
      });
    e.s(["checkbox", 0, p, "checkboxGroup", 0, m], 559745);
    var h = e.i(355483),
      b = e.i(371330),
      g = e.i(429427),
      y = e.i(75540);
    ("u" > typeof document && d.default.useLayoutEffect,
      d.default.useInsertionEffect,
      e.i(454453),
      "u" > typeof window && window.document && window.document.createElement);
    let w = new Map();
    "u" > typeof FinalizationRegistry &&
      new FinalizationRegistry((e) => {
        w.delete(e);
      });
    var x = e.i(207670);
    function C() {
      for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
      let a = { ...t[0] };
      for (let e = 1; e < t.length; e++) {
        let r = t[e];
        for (let e in r) {
          let t = a[e],
            n = r[e];
          "function" == typeof t &&
          "function" == typeof n &&
          "o" === e[0] &&
          "n" === e[1] &&
          e.charCodeAt(2) >= 65 &&
          90 >= e.charCodeAt(2)
            ? (a[e] = (function () {
                for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                return function () {
                  for (var e = arguments.length, r = Array(e), a = 0; a < e; a++) r[a] = arguments[a];
                  for (let e of t) "function" == typeof e && e(...r);
                };
              })(t, n))
            : ("className" === e || "UNSAFE_className" === e) && "string" == typeof t && "string" == typeof n
              ? (a[e] = (0, x.default)(t, n))
              : "id" === e && t && n
                ? (a.id = (function (e, t) {
                    if (e === t) return e;
                    let r = w.get(e);
                    if (r) return (r.forEach((e) => (e.current = t)), t);
                    let a = w.get(t);
                    return a ? (a.forEach((t) => (t.current = e)), e) : t;
                  })(t, n))
                : (a[e] = void 0 !== n ? n : t);
        }
      }
      return a;
    }
    e.s(["mergeProps", 0, C], 856564);
    var S = e.i(475695),
      P = e.i(148774),
      V = e.i(343027);
    let E = "u" > typeof document ? d.default.useLayoutEffect : () => {},
      I = null != (t = d.default.useInsertionEffect) ? t : E;
    "u" > typeof window && window.document && window.document.createElement;
    let k = new Map();
    function A() {
      for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
      let a = { ...t[0] };
      for (let e = 1; e < t.length; e++) {
        let r = t[e];
        for (let e in r) {
          let t = a[e],
            n = r[e];
          "function" == typeof t &&
          "function" == typeof n &&
          "o" === e[0] &&
          "n" === e[1] &&
          e.charCodeAt(2) >= 65 &&
          90 >= e.charCodeAt(2)
            ? (a[e] = (function () {
                for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                return function () {
                  for (var e = arguments.length, r = Array(e), a = 0; a < e; a++) r[a] = arguments[a];
                  for (let e of t) "function" == typeof e && e(...r);
                };
              })(t, n))
            : ("className" === e || "UNSAFE_className" === e) && "string" == typeof t && "string" == typeof n
              ? (a[e] = (0, x.default)(t, n))
              : "id" === e && t && n
                ? (a.id = (function (e, t) {
                    if (e === t) return e;
                    let r = k.get(e);
                    if (r) return (r.forEach((e) => (e.current = t)), t);
                    let a = k.get(t);
                    return a ? (a.forEach((t) => (t.current = e)), e) : t;
                  })(t, n))
                : (a[e] = void 0 !== n ? n : t);
        }
      }
      return a;
    }
    "u" > typeof FinalizationRegistry &&
      new FinalizationRegistry((e) => {
        k.delete(e);
      });
    let R = new Set(["id"]),
      D = new Set(["aria-label", "aria-labelledby", "aria-describedby", "aria-details"]),
      M = new Set(["href", "hrefLang", "target", "rel", "download", "ping", "referrerPolicy"]),
      L = new Set(["dir", "lang", "hidden", "inert", "translate"]),
      O = new Set([
        "onClick",
        "onAuxClick",
        "onContextMenu",
        "onDoubleClick",
        "onMouseDown",
        "onMouseEnter",
        "onMouseLeave",
        "onMouseMove",
        "onMouseOut",
        "onMouseOver",
        "onMouseUp",
        "onTouchCancel",
        "onTouchEnd",
        "onTouchMove",
        "onTouchStart",
        "onPointerDown",
        "onPointerMove",
        "onPointerUp",
        "onPointerCancel",
        "onPointerEnter",
        "onPointerLeave",
        "onPointerOver",
        "onPointerOut",
        "onGotPointerCapture",
        "onLostPointerCapture",
        "onScroll",
        "onWheel",
        "onAnimationStart",
        "onAnimationEnd",
        "onAnimationIteration",
        "onTransitionCancel",
        "onTransitionEnd",
        "onTransitionRun",
        "onTransitionStart",
      ]),
      j = /^(data-.*)$/;
    var F = e.i(849962);
    function T(e, t, r) {
      let a = (0, S.useFormValidationState)({ ...e, value: t.isSelected }),
        { isInvalid: n, validationErrors: i, validationDetails: o } = a.displayValidation,
        {
          labelProps: l,
          inputProps: s,
          isSelected: u,
          isPressed: c,
          isDisabled: f,
          isReadOnly: v,
        } = (function (e, t, r) {
          var a, n, i;
          let o,
            l,
            {
              isDisabled: s = !1,
              isReadOnly: u = !1,
              value: c,
              name: f,
              form: v,
              children: p,
              "aria-label": m,
              "aria-labelledby": h,
              validationState: b = "valid",
              isInvalid: g,
              onPressStart: y,
              onPressEnd: w,
              onPressChange: x,
              onPress: C,
              onPressUp: S,
              onClick: P,
            } = e,
            { pressProps: E, isPressed: k } = (0, V.usePress)({
              onPressStart: y,
              onPressEnd: w,
              onPressChange: x,
              onPress: C,
              onPressUp: S,
              onClick: P,
              isDisabled: s,
            }),
            { pressProps: T, isPressed: U } = (0, V.usePress)({
              onPressStart: y,
              onPressEnd: w,
              onPressChange: x,
              onPressUp: S,
              onClick: P,
              onPress(e) {
                var a;
                (null == C || C(e), t.toggle(), null == (a = r.current) || a.focus());
              },
              isDisabled: s || u,
            }),
            { focusableProps: N } = (0, F.useFocusable)(e, r),
            B = A(E, N),
            _ = (function (e) {
              let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                { labelable: r, isLink: a, global: n, events: i = n, propNames: o } = t,
                l = {};
              for (let t in e)
                Object.prototype.hasOwnProperty.call(e, t) &&
                  (R.has(t) ||
                    (r && D.has(t)) ||
                    (a && M.has(t)) ||
                    (n && L.has(t)) ||
                    (i && O.has(t)) ||
                    (t.endsWith("Capture") && O.has(t.slice(0, -7))) ||
                    (null == o ? void 0 : o.has(t)) ||
                    j.test(t)) &&
                  (l[t] = e[t]);
              return l;
            })(e, { labelable: !0 });
          return (
            (a = t.defaultSelected),
            (n = t.setSelected),
            (i = () => {
              n && n(a);
            }),
            (o = (0, d.useRef)(null)),
            I(() => {
              o.current = i;
            }, [i]),
            (l = (0, d.useCallback)(function () {
              for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
              let a = o.current;
              return null == a ? void 0 : a(...t);
            }, [])),
            (0, d.useEffect)(() => {
              var e;
              let t = null == r || null == (e = r.current) ? void 0 : e.form;
              return (
                null == t || t.addEventListener("reset", l),
                () => {
                  null == t || t.removeEventListener("reset", l);
                }
              );
            }, [r, l]),
            {
              labelProps: A(T, { onClick: (e) => e.preventDefault() }),
              inputProps: A(_, {
                "aria-invalid": g || "invalid" === b || void 0,
                "aria-errormessage": e["aria-errormessage"],
                "aria-controls": e["aria-controls"],
                "aria-readonly": u || void 0,
                onChange: (e) => {
                  (e.stopPropagation(), t.setSelected(e.target.checked));
                },
                disabled: s,
                ...(null == c ? {} : { value: c }),
                name: f,
                form: v,
                type: "checkbox",
                ...B,
              }),
              isSelected: t.isSelected,
              isPressed: k || U,
              isDisabled: s,
              isReadOnly: u,
              isInvalid: g || "invalid" === b,
            }
          );
        })({ ...e, isInvalid: n }, t, r);
      (0, P.useFormValidation)(e, a, r);
      let { isIndeterminate: p, isRequired: m, validationBehavior: h = "aria" } = e;
      (0, d.useEffect)(() => {
        r.current && (r.current.indeterminate = !!p);
      });
      let { pressProps: b } = (0, V.usePress)({
        isDisabled: f || v,
        onPress() {
          let { [S.privateValidationStateProp]: t } = e,
            { commitValidation: r } = t || a;
          r();
        },
      });
      return {
        labelProps: C(
          l,
          b,
          (0, d.useMemo)(() => ({ onMouseDown: (e) => e.preventDefault() }), []),
        ),
        inputProps: {
          ...s,
          checked: u,
          "aria-required": (m && "aria" === h) || void 0,
          required: m && "native" === h,
        },
        isSelected: u,
        isPressed: c,
        isDisabled: f,
        isReadOnly: v,
        isInvalid: n,
        validationErrors: i,
        validationDetails: o,
      };
    }
    let U = new WeakMap();
    e.s(["checkboxGroupData", 0, U], 143674);
    var N = e.i(655483),
      B = e.i(460849),
      _ = e.i(415944),
      G = e.i(713934),
      q = (0, e.i(273830).forwardRef)((e, t) => {
        let {
            Component: a,
            children: n,
            icon: o = (0, r.jsx)(i, {}),
            getBaseProps: u,
            getWrapperProps: f,
            getInputProps: v,
            getIconProps: m,
            getLabelProps: w,
          } = (function () {
            var e, t, r, a, n, i, o, u;
            let f = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
              v = (0, s.useProviderContext)(),
              m = l(),
              { validationBehavior: w } = (0, G.useSlottedContext)(_.FormContext) || {},
              x = !!m,
              {
                as: C,
                ref: P,
                value: V = "",
                children: E,
                icon: I,
                name: k,
                isRequired: A,
                isReadOnly: R = !1,
                autoFocus: D = !1,
                isSelected: M,
                size: L = null != (e = null == m ? void 0 : m.size) ? e : "md",
                color: O = null != (t = null == m ? void 0 : m.color) ? t : "primary",
                radius: j = null == m ? void 0 : m.radius,
                lineThrough: F = null != (r = null == m ? void 0 : m.lineThrough) && r,
                isDisabled: q = null != (a = null == m ? void 0 : m.isDisabled) && a,
                disableAnimation: z = null !=
                  (i =
                    null != (n = null == m ? void 0 : m.disableAnimation)
                      ? n
                      : null == v
                        ? void 0
                        : v.disableAnimation) && i,
                validationState: W,
                isInvalid: $ = W ? "invalid" === W : null != (o = null == m ? void 0 : m.isInvalid) && o,
                isIndeterminate: H = !1,
                validationBehavior: K = x
                  ? m.validationBehavior
                  : null != (u = null != w ? w : null == v ? void 0 : v.validationBehavior)
                    ? u
                    : "native",
                defaultSelected: J,
                classNames: Q,
                className: X,
                onValueChange: Y,
                validate: Z,
                ...ee
              } = f;
            m &&
              y.__DEV__ &&
              (M &&
                (0, y.warn)(
                  "The Checkbox.Group is being used, `isSelected` will be ignored. Use the `value` of the Checkbox.Group instead.",
                  "Checkbox",
                ),
              J &&
                (0, y.warn)(
                  "The Checkbox.Group is being used, `defaultSelected` will be ignored. Use the `defaultValue` of the Checkbox.Group instead.",
                  "Checkbox",
                ));
            let et = (0, d.useRef)(null),
              er = (0, d.useRef)(null),
              ea = f.onChange;
            x &&
              (ea = (0, y.chain)(() => {
                m.groupState.resetValidation();
              }, ea));
            let en = (0, d.useId)(),
              ei = (0, d.useMemo)(
                () => ({
                  name: k,
                  value: V,
                  children: E,
                  autoFocus: D,
                  defaultSelected: J,
                  isIndeterminate: H,
                  isRequired: A,
                  isInvalid: $,
                  isSelected: M,
                  isDisabled: q,
                  isReadOnly: R,
                  "aria-label": (0, y.safeAriaLabel)(ee["aria-label"], E),
                  "aria-labelledby": ee["aria-labelledby"] || en,
                  onChange: Y,
                }),
                [k, V, E, D, J, H, A, $, M, q, R, ee["aria-label"], ee["aria-labelledby"], en, Y],
              ),
              eo = c(ei),
              el = { isInvalid: $, isRequired: A, validate: Z, validationState: W, validationBehavior: K },
              {
                inputProps: es,
                isSelected: ed,
                isDisabled: eu,
                isReadOnly: ec,
                isPressed: ef,
                isInvalid: ev,
              } = x
                ? (function (e, t, r) {
                    var a, n;
                    let i = c({
                        isReadOnly: e.isReadOnly || t.isReadOnly,
                        isSelected: t.isSelected(e.value),
                        defaultSelected: t.defaultValue.includes(e.value),
                        onChange(r) {
                          (r ? t.addValue(e.value) : t.removeValue(e.value), e.onChange && e.onChange(r));
                        },
                      }),
                      {
                        name: o,
                        form: l,
                        descriptionId: s,
                        errorMessageId: u,
                        validationBehavior: f,
                      } = U.get(t);
                    f = null != (a = e.validationBehavior) ? a : f;
                    let { realtimeValidation: v } = (0, S.useFormValidationState)({
                        ...e,
                        value: i.isSelected,
                        name: void 0,
                        validationBehavior: "aria",
                      }),
                      p = (0, d.useRef)(S.DEFAULT_VALIDATION_RESULT),
                      m = () => {
                        t.setInvalid(e.value, v.isInvalid ? v : p.current);
                      };
                    (0, d.useEffect)(m);
                    let h = t.realtimeValidation.isInvalid ? t.realtimeValidation : v,
                      b = "native" === f ? t.displayValidation : h,
                      g = T(
                        {
                          ...e,
                          isReadOnly: e.isReadOnly || t.isReadOnly,
                          isDisabled: e.isDisabled || t.isDisabled,
                          name: e.name || o,
                          form: e.form || l,
                          isRequired: null != (n = e.isRequired) ? n : t.isRequired,
                          validationBehavior: f,
                          [S.privateValidationStateProp]: {
                            realtimeValidation: h,
                            displayValidation: b,
                            resetValidation: t.resetValidation,
                            commitValidation: t.commitValidation,
                            updateValidation(e) {
                              ((p.current = e), m());
                            },
                          },
                        },
                        i,
                        r,
                      );
                    return {
                      ...g,
                      inputProps: {
                        ...g.inputProps,
                        "aria-describedby":
                          [e["aria-describedby"], t.isInvalid ? u : null, s].filter(Boolean).join(" ") ||
                          void 0,
                      },
                    };
                  })({ ...ei, ...el }, m.groupState, er)
                : T({ ...ei, ...el }, eo, er),
              ep = "invalid" === W || $ || ev,
              em = !(eu || ec) && ef,
              { hoverProps: eh, isHovered: eb } = (0, b.useHover)({ isDisabled: es.disabled }),
              {
                focusProps: eg,
                isFocused: ey,
                isFocusVisible: ew,
              } = (0, g.useFocusRing)({ autoFocus: es.autoFocus }),
              ex = (0, d.useMemo)(
                () =>
                  p({
                    color: O,
                    size: L,
                    radius: j,
                    isInvalid: ep,
                    lineThrough: F,
                    isDisabled: eu,
                    disableAnimation: z,
                  }),
                [O, L, j, ep, F, eu, z],
              );
            (0, N.useSafeLayoutEffect)(() => {
              if (!er.current) return;
              let e = !!er.current.checked;
              eo.setSelected(e);
            }, [er.current]);
            let eC = (0, h.useCallbackRef)(ea),
              eS = (0, d.useCallback)(
                (e) => {
                  ec || eu ? e.preventDefault() : null == eC || eC(e);
                },
                [ec, eu, eC],
              ),
              eP = (0, y.clsx)(null == Q ? void 0 : Q.base, X),
              eV = (0, d.useCallback)(
                () => ({
                  ref: et,
                  className: ex.base({ class: eP }),
                  "data-disabled": (0, y.dataAttr)(eu),
                  "data-selected": (0, y.dataAttr)(ed || H),
                  "data-invalid": (0, y.dataAttr)(ep),
                  "data-hover": (0, y.dataAttr)(eb),
                  "data-focus": (0, y.dataAttr)(ey),
                  "data-pressed": (0, y.dataAttr)(em),
                  "data-readonly": (0, y.dataAttr)(es.readOnly),
                  "data-focus-visible": (0, y.dataAttr)(ew),
                  "data-indeterminate": (0, y.dataAttr)(H),
                  ...(0, y.mergeProps)(eh, ee),
                }),
                [ex, eP, eu, ed, H, ep, eb, ey, em, es.readOnly, ew, eh, ee],
              ),
              eE = (0, d.useCallback)(
                function () {
                  let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                  return {
                    ...e,
                    "aria-hidden": !0,
                    className: (0, y.clsx)(
                      ex.wrapper({
                        class: (0, y.clsx)(null == Q ? void 0 : Q.wrapper, null == e ? void 0 : e.className),
                      }),
                    ),
                  };
                },
                [ex, null == Q ? void 0 : Q.wrapper],
              ),
              eI = (0, d.useCallback)(
                () => ({
                  ref: (0, B.mergeRefs)(er, P),
                  ...(0, y.mergeProps)(es, eg),
                  className: ex.hiddenInput({ class: null == Q ? void 0 : Q.hiddenInput }),
                  onChange: (0, y.chain)(es.onChange, eS),
                }),
                [es, eg, eS, null == Q ? void 0 : Q.hiddenInput],
              ),
              ek = (0, d.useCallback)(
                () => ({ id: en, className: ex.label({ class: null == Q ? void 0 : Q.label }) }),
                [ex, null == Q ? void 0 : Q.label, eu, ed, ep],
              ),
              eA = (0, d.useCallback)(
                () => ({
                  isSelected: ed,
                  isIndeterminate: H,
                  disableAnimation: z,
                  className: ex.icon({ class: null == Q ? void 0 : Q.icon }),
                }),
                [ex, null == Q ? void 0 : Q.icon, ed, H, z],
              );
            return {
              Component: C || "label",
              icon: I,
              children: E,
              isSelected: ed,
              isDisabled: eu,
              isInvalid: ep,
              isFocused: ey,
              isHovered: eb,
              isFocusVisible: ew,
              getBaseProps: eV,
              getWrapperProps: eE,
              getInputProps: eI,
              getLabelProps: ek,
              getIconProps: eA,
            };
          })({ ...e, ref: t }),
          x = "function" == typeof o ? o(m()) : (0, d.cloneElement)(o, m());
        return (0, r.jsxs)(a, {
          ...u(),
          children: [
            (0, r.jsx)("input", { ...v() }),
            (0, r.jsx)("span", { ...f(), children: x }),
            n && (0, r.jsx)("span", { ...w(), children: n }),
          ],
        });
      });
    ((q.displayName = "HeroUI.Checkbox"), e.s(["Checkbox", 0, q], 584735));
  },
  415944,
  (e) => {
    "use strict";
    var t = e.i(713934),
      r = e.i(475695),
      a = e.i(271645),
      n = (0, e.i(984898).tv)({ base: "flex flex-col gap-2 items-start" }),
      i = e.i(843476),
      o = (0, a.createContext)(null),
      l = (0, a.forwardRef)(function (e, l) {
        [e, l] = (0, t.useContextProps)(e, l, o);
        let { validationErrors: s, validationBehavior: d = "native", children: u, className: c, ...f } = e,
          v = (0, a.useMemo)(() => n({ className: c }), [c]);
        return (0, i.jsx)("form", {
          noValidate: "native" !== d,
          ...f,
          ref: l,
          className: v,
          children: (0, i.jsx)(o.Provider, {
            value: { ...e, validationBehavior: d },
            children: (0, i.jsx)(r.FormValidationContext.Provider, {
              value: null != s ? s : {},
              children: u,
            }),
          }),
        });
      });
    e.s(["Form", 0, l, "FormContext", 0, o], 415944);
  },
  713934,
  (e) => {
    "use strict";
    var t = e.i(271645),
      r = e.i(75540),
      a = Symbol("default");
    function n(e, r) {
      let n = (0, t.useContext)(e);
      if (null === r) return null;
      if (n && "object" == typeof n && "slots" in n && n.slots) {
        let e = new Intl.ListFormat().format(Object.keys(n.slots).map((e) => `"${e}"`));
        if (!r && !n.slots[a]) throw Error(`A slot prop is required. Valid slot names are ${e}.`);
        let t = r || a;
        if (!n.slots[t]) throw Error(`Invalid slot "${r}". Valid slot names are ${e}.`);
        return n.slots[t];
      }
      return n;
    }
    e.s([
      "useContextProps",
      0,
      function (e, a, i) {
        var o;
        let l,
          s,
          d,
          { ref: u, ...c } = n(i, e.slot) || {},
          f =
            ((o = (0, t.useMemo)(() => (0, r.mergeRefs)(a, u), [a, u])),
            (l = (0, t.useRef)(null)),
            (s = (0, t.useRef)(void 0)),
            (d = (0, t.useCallback)(
              (e) => {
                if ("function" == typeof o) {
                  let t = o(e);
                  return () => {
                    "function" == typeof t ? t() : o(null);
                  };
                }
                if (o)
                  return (
                    (o.current = e),
                    () => {
                      o.current = null;
                    }
                  );
              },
              [o],
            )),
            (0, t.useMemo)(
              () => ({
                get current() {
                  return l.current;
                },
                set current(value) {
                  ((l.current = value),
                    s.current && (s.current(), (s.current = void 0)),
                    null != value && (s.current = d(value)));
                },
              }),
              [d],
            )),
          v = (0, r.mergeProps)(c, e);
        return (
          "style" in c &&
            c.style &&
            "style" in e &&
            e.style &&
            ("function" == typeof c.style || "function" == typeof e.style
              ? (v.style = (t) => {
                  let r = "function" == typeof c.style ? c.style(t) : c.style,
                    a = { ...t.defaultStyle, ...r },
                    n = "function" == typeof e.style ? e.style({ ...t, defaultStyle: a }) : e.style;
                  return { ...a, ...n };
                })
              : (v.style = { ...c.style, ...e.style })),
          [v, f]
        );
      },
      "useSlottedContext",
      0,
      n,
    ]);
  },
  355483,
  (e) => {
    "use strict";
    var t = e.i(271645),
      r = e.i(655483);
    e.s([
      "useCallbackRef",
      0,
      function (e) {
        let a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [],
          n = (0, t.useRef)(e);
        return (
          (0, r.useSafeLayoutEffect)(() => {
            n.current = e;
          }),
          (0, t.useCallback)(function () {
            for (var e, t = arguments.length, r = Array(t), a = 0; a < t; a++) r[a] = arguments[a];
            return null == (e = n.current) ? void 0 : e.call(n, ...r);
          }, a)
        );
      },
    ]);
  },
  148774,
  (e) => {
    "use strict";
    var t,
      r = e.i(346996),
      a = e.i(271645);
    let n = "u" > typeof document ? a.default.useLayoutEffect : () => {},
      i = null != (t = a.default.useInsertionEffect) ? t : n;
    function o(e) {
      let t = (0, a.useRef)(null);
      return (
        i(() => {
          t.current = e;
        }, [e]),
        (0, a.useCallback)(function () {
          for (var e = arguments.length, r = Array(e), a = 0; a < e; a++) r[a] = arguments[a];
          let n = t.current;
          return null == n ? void 0 : n(...r);
        }, [])
      );
    }
    e.s(
      [
        "useFormValidation",
        0,
        function (e, t, i) {
          let { validationBehavior: l, focus: s } = e;
          n(() => {
            if ("native" === l && (null == i ? void 0 : i.current) && !i.current.disabled) {
              var e;
              let r,
                a = t.realtimeValidation.isInvalid
                  ? t.realtimeValidation.validationErrors.join(" ") || "Invalid value."
                  : "";
              (i.current.setCustomValidity(a),
                i.current.hasAttribute("title") || (i.current.title = ""),
                t.realtimeValidation.isInvalid ||
                  t.updateValidation({
                    isInvalid: !(e = i.current).validity.valid,
                    validationDetails: {
                      badInput: (r = e.validity).badInput,
                      customError: r.customError,
                      patternMismatch: r.patternMismatch,
                      rangeOverflow: r.rangeOverflow,
                      rangeUnderflow: r.rangeUnderflow,
                      stepMismatch: r.stepMismatch,
                      tooLong: r.tooLong,
                      tooShort: r.tooShort,
                      typeMismatch: r.typeMismatch,
                      valueMissing: r.valueMissing,
                      valid: r.valid,
                    },
                    validationErrors: e.validationMessage ? [e.validationMessage] : [],
                  }));
            }
          });
          let d = (0, a.useRef)(!1),
            u = o(() => {
              d.current || t.resetValidation();
            }),
            c = o((e) => {
              var a, n;
              t.displayValidation.isInvalid || t.commitValidation();
              let o = null == i || null == (a = i.current) ? void 0 : a.form;
              (!e.defaultPrevented &&
                i &&
                o &&
                (function (e) {
                  for (let t = 0; t < e.elements.length; t++) {
                    let r = e.elements[t];
                    if (!r.validity.valid) return r;
                  }
                  return null;
                })(o) === i.current &&
                (s ? s() : null == (n = i.current) || n.focus(), (0, r.setInteractionModality)("keyboard")),
                e.preventDefault());
            }),
            f = o(() => {
              t.commitValidation();
            });
          (0, a.useEffect)(() => {
            let e = null == i ? void 0 : i.current;
            if (!e) return;
            let t = e.form,
              r = null == t ? void 0 : t.reset;
            return (
              t &&
                (t.reset = () => {
                  ((d.current =
                    !window.event ||
                    ("message" === window.event.type && window.event.target instanceof MessagePort)),
                    null == r || r.call(t),
                    (d.current = !1));
                }),
              e.addEventListener("invalid", c),
              e.addEventListener("change", f),
              null == t || t.addEventListener("reset", u),
              () => {
                (e.removeEventListener("invalid", c),
                  e.removeEventListener("change", f),
                  null == t || t.removeEventListener("reset", u),
                  t && (t.reset = r));
              }
            );
          }, [i, c, f, u, l]);
        },
      ],
      148774,
    );
  },
  475695,
  (e) => {
    "use strict";
    var t = e.i(271645);
    let r = {
        badInput: !1,
        customError: !1,
        patternMismatch: !1,
        rangeOverflow: !1,
        rangeUnderflow: !1,
        stepMismatch: !1,
        tooLong: !1,
        tooShort: !1,
        typeMismatch: !1,
        valueMissing: !1,
        valid: !0,
      },
      a = { ...r, customError: !0, valid: !1 },
      n = { isInvalid: !1, validationDetails: r, validationErrors: [] },
      i = (0, t.createContext)({}),
      o = "__formValidationState" + Date.now();
    function l(e) {
      return e ? (Array.isArray(e) ? e : [e]) : [];
    }
    function s(e) {
      return e.length ? { isInvalid: !0, validationErrors: e, validationDetails: a } : null;
    }
    function d(e, t) {
      return (
        e === t ||
        (!!e &&
          !!t &&
          e.isInvalid === t.isInvalid &&
          e.validationErrors.length === t.validationErrors.length &&
          e.validationErrors.every((e, r) => e === t.validationErrors[r]) &&
          Object.entries(e.validationDetails).every((e) => {
            let [r, a] = e;
            return t.validationDetails[r] === a;
          }))
      );
    }
    e.s([
      "DEFAULT_VALIDATION_RESULT",
      0,
      n,
      "FormValidationContext",
      0,
      i,
      "mergeValidation",
      0,
      function () {
        for (var e = arguments.length, t = Array(e), a = 0; a < e; a++) t[a] = arguments[a];
        let n = new Set(),
          i = !1,
          o = { ...r };
        for (let e of t) {
          for (let t of e.validationErrors) n.add(t);
          for (let t in (i || (i = e.isInvalid), o)) o[t] || (o[t] = e.validationDetails[t]);
        }
        return ((o.valid = !i), { isInvalid: i, validationErrors: [...n], validationDetails: o });
      },
      "privateValidationStateProp",
      0,
      o,
      "useFormValidationState",
      0,
      function (e) {
        if (e[o]) {
          let {
            realtimeValidation: t,
            displayValidation: r,
            updateValidation: a,
            resetValidation: n,
            commitValidation: i,
          } = e[o];
          return {
            realtimeValidation: t,
            displayValidation: r,
            updateValidation: a,
            resetValidation: n,
            commitValidation: i,
          };
        }
        return (function (e) {
          let {
            isInvalid: r,
            validationState: o,
            name: u,
            value: c,
            builtinValidation: f,
            validate: v,
            validationBehavior: p = "aria",
          } = e;
          o && (r || (r = "invalid" === o));
          let m = void 0 !== r ? { isInvalid: r, validationErrors: [], validationDetails: a } : null,
            h = (0, t.useMemo)(
              () =>
                v && null != c
                  ? s(
                      (function (e, t) {
                        if ("function" == typeof e) {
                          let r = e(t);
                          if (r && "boolean" != typeof r) return l(r);
                        }
                        return [];
                      })(v, c),
                    )
                  : null,
              [v, c],
            );
          (null == f ? void 0 : f.validationDetails.valid) && (f = void 0);
          let b = (0, t.useContext)(i),
            g = (0, t.useMemo)(
              () => (u ? (Array.isArray(u) ? u.flatMap((e) => l(b[e])) : l(b[u])) : []),
              [b, u],
            ),
            [y, w] = (0, t.useState)(b),
            [x, C] = (0, t.useState)(!1);
          b !== y && (w(b), C(!1));
          let S = (0, t.useMemo)(() => s(x ? [] : g), [x, g]),
            P = (0, t.useRef)(n),
            [V, E] = (0, t.useState)(n),
            I = (0, t.useRef)(n),
            [k, A] = (0, t.useState)(!1);
          return (
            (0, t.useEffect)(() => {
              if (!k) return;
              A(!1);
              let e = h || f || P.current;
              d(e, I.current) || ((I.current = e), E(e));
            }),
            {
              realtimeValidation: m || S || h || f || n,
              displayValidation: "native" === p ? m || S || V : m || S || h || f || V,
              updateValidation(e) {
                "aria" !== p || d(V, e) ? (P.current = e) : E(e);
              },
              resetValidation() {
                (d(n, I.current) || ((I.current = n), E(n)), "native" === p && A(!1), C(!0));
              },
              commitValidation() {
                ("native" === p && A(!0), C(!0));
              },
            }
          );
        })(e);
      },
    ]);
  },
]);
