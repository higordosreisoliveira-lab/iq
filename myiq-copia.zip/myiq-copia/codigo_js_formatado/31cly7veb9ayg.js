(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  513619,
  (e) => {
    "use strict";
    var i = e.i(843476);
    e.s([
      "default",
      0,
      (e) => {
        let { icon: s, isDisabled: t = !1, isLoading: o = !1, label: n, onClick: r } = e;
        return (0, i.jsxs)("button", {
          className:
            "inline-flex h-12 w-full items-center justify-center gap-2 rounded-full border border-slate-200 bg-white text-hp-body-sm font-medium text-grey-deep transition-colors duration-150 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom disabled:cursor-not-allowed disabled:opacity-50 [@media(hover:hover)]:hover:bg-black-custom/[0.04]",
          disabled: t || o,
          onClick: r,
          type: "button",
          children: [
            o
              ? (0, i.jsx)("span", {
                  "aria-hidden": !0,
                  className:
                    "size-5 shrink-0 animate-spin rounded-full border-2 border-slate-200 border-t-green-custom motion-reduce:animate-none",
                })
              : (0, i.jsx)("span", {
                  "aria-hidden": !0,
                  className: "flex size-5 shrink-0 items-center justify-center",
                  children: s,
                }),
            (0, i.jsx)("span", { children: n }),
          ],
        });
      },
    ]);
  },
  151018,
  function (e) {
    e.n(e.i(513619));
  },
]);
