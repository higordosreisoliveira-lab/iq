(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  665536,
  341327,
  (e) => {
    "use strict";
    let t = (e) =>
      "mouse" === e.pointerType ? "number" != typeof e.button || e.button <= 0 : !1 !== e.isPrimary;
    function i(e) {
      return { point: { x: e.pageX, y: e.pageY } };
    }
    (e.s(["isPrimaryPointer", 0, t], 341327),
      e.s(["addPointerInfo", 0, (e) => (n) => t(n) && e(n, i(n)), "extractEventInfo", 0, i], 665536));
  },
  99642,
  260863,
  (e) => {
    "use strict";
    var t = e.i(142098),
      i = e.i(282774),
      n = e.i(738638);
    class r extends t.Feature {
      constructor() {
        (super(...arguments), (this.isActive = !1));
      }
      onFocus() {
        let e = !1;
        try {
          e = this.node.current.matches(":focus-visible");
        } catch (t) {
          e = !0;
        }
        e &&
          this.node.animationState &&
          (this.node.animationState.setActive("whileFocus", !0), (this.isActive = !0));
      }
      onBlur() {
        this.isActive &&
          this.node.animationState &&
          (this.node.animationState.setActive("whileFocus", !1), (this.isActive = !1));
      }
      mount() {
        this.unmount = (0, n.pipe)(
          (0, i.addDomEvent)(this.node.current, "focus", () => this.onFocus()),
          (0, i.addDomEvent)(this.node.current, "blur", () => this.onBlur()),
        );
      }
      unmount() {}
    }
    e.s(["FocusGesture", 0, r], 99642);
    let s = (e, t) => !!t && (e === t || s(e, t.parentElement));
    e.s(["isNodeOrChild", 0, s], 260863);
  },
  957512,
  (e) => {
    "use strict";
    var t = e.i(142098),
      i = e.i(608648),
      n = e.i(287022),
      r = e.i(665536);
    function s(e, t, i) {
      let { props: s } = e;
      e.animationState && s.whileHover && e.animationState.setActive("whileHover", "Start" === i);
      let a = s["onHover" + i];
      a && n.frame.postRender(() => a(t, (0, r.extractEventInfo)(t)));
    }
    class a extends t.Feature {
      mount() {
        let { current: e } = this.node;
        e &&
          (this.unmount = (0, i.hover)(
            e,
            (e, t) => (s(this.node, t, "Start"), (e) => s(this.node, e, "End")),
          ));
      }
      unmount() {}
    }
    e.s(["HoverGesture", 0, a]);
  },
  223070,
  535384,
  219384,
  876859,
  394562,
  637041,
  (e) => {
    "use strict";
    var t = e.i(142098),
      i = e.i(618812),
      n = e.i(372323);
    function r(e, t, i) {
      let n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
        r = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1,
        s = Array.from(e)
          .sort((e, t) => e.sortNodePosition(t))
          .indexOf(t),
        a = e.size,
        o = (a - 1) * n;
      return "function" == typeof i ? i(s, a) : 1 === r ? s * n : o - s * n;
    }
    function s(e, t) {
      let a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
        o = (0, i.resolveVariant)(e, t, "exit" === a.type ? e.presenceContext?.custom : void 0),
        { transition: l = e.getDefaultTransition() || {} } = o || {};
      a.transitionOverride && (l = a.transitionOverride);
      let u = o ? () => Promise.all((0, n.animateTarget)(e, o, a)) : () => Promise.resolve(),
        h =
          e.variantChildren && e.variantChildren.size
            ? function () {
                let i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                  { delayChildren: n = 0, staggerChildren: o, staggerDirection: u } = l;
                return (function (e, t) {
                  let i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                    n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
                    a = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0,
                    o = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 1,
                    l = arguments.length > 6 ? arguments[6] : void 0,
                    u = [];
                  for (let h of e.variantChildren)
                    (h.notify("AnimationStart", t),
                      u.push(
                        s(h, t, {
                          ...l,
                          delay: i + ("function" == typeof n ? 0 : n) + r(e.variantChildren, h, n, a, o),
                        }).then(() => h.notify("AnimationComplete", t)),
                      ));
                  return Promise.all(u);
                })(e, t, i, n, o, u, a);
              }
            : () => Promise.resolve(),
        { when: c } = l;
      if (!c) return Promise.all([u(), h(a.delay)]);
      {
        let [e, t] = "beforeChildren" === c ? [u, h] : [h, u];
        return e().then(() => t());
      }
    }
    function a(e, t) {
      let r,
        a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
      if ((e.notify("AnimationStart", t), Array.isArray(t))) r = Promise.all(t.map((t) => s(e, t, a)));
      else if ("string" == typeof t) r = s(e, t, a);
      else {
        let s = "function" == typeof t ? (0, i.resolveVariant)(e, t, a.custom) : t;
        r = Promise.all((0, n.animateTarget)(e, s, a));
      }
      return r.then(() => {
        e.notify("AnimationComplete", t);
      });
    }
    (e.s(["calcChildStagger", 0, r], 535384),
      e.s(["animateVariant", 0, s], 219384),
      e.s(["animateVisualElement", 0, a], 876859));
    var o = e.i(732525),
      l = e.i(706840);
    let u = l.variantProps.length;
    function h(e) {
      if (!e) return;
      if (!e.isControllingVariants) {
        let t = (e.parent && h(e.parent)) || {};
        return (void 0 !== e.props.initial && (t.initial = e.props.initial), t);
      }
      let t = {};
      for (let i = 0; i < u; i++) {
        let n = l.variantProps[i],
          r = e.props[n];
        ((0, o.isVariantLabel)(r) || !1 === r) && (t[n] = r);
      }
      return t;
    }
    e.s(["getVariantContext", 0, h], 394562);
    var c = e.i(885983),
      d = e.i(373615);
    function m(e, t) {
      if (!Array.isArray(t)) return !1;
      let i = t.length;
      if (i !== e.length) return !1;
      for (let n = 0; n < i; n++) if (t[n] !== e[n]) return !1;
      return !0;
    }
    let p = [...l.variantPriorityOrder].reverse(),
      f = l.variantPriorityOrder.length;
    function v(e) {
      let t = (t) =>
          Promise.all(
            t.map((t) => {
              let { animation: i, options: n } = t;
              return a(e, i, n);
            }),
          ),
        n = T(),
        s = !0,
        l = !1,
        u = (t) => (n, r) => {
          let s = (0, i.resolveVariant)(e, r, "exit" === t ? e.presenceContext?.custom : void 0);
          if (s) {
            let { transition: e, transitionEnd: t, ...i } = s;
            n = { ...n, ...i, ...t };
          }
          return n;
        };
      function v(a) {
        let { props: v } = e,
          y = h(e.parent) || {},
          T = [],
          b = new Set(),
          x = {},
          w = 1 / 0;
        for (let t = 0; t < f; t++) {
          let h = p[t],
            f = n[h],
            A = void 0 !== v[h] ? v[h] : y[h],
            S = (0, o.isVariantLabel)(A),
            V = h === a ? f.isActive : null;
          !1 === V && (w = t);
          let M = A === y[h] && A !== v[h] && S;
          if (
            (M && (s || l) && e.manuallyAnimateOnMount && (M = !1),
            (f.protectedKeys = { ...x }),
            (!f.isActive && null === V) ||
              (!A && !f.prevProp) ||
              (0, c.isAnimationControls)(A) ||
              "boolean" == typeof A)
          )
            continue;
          if ("exit" === h && f.isActive && !0 !== V) {
            f.prevResolvedValues && (x = { ...x, ...f.prevResolvedValues });
            continue;
          }
          let C = g(f.prevProp, A),
            k = C || (h === a && f.isActive && !M && S) || (t > w && S),
            E = !1,
            P = Array.isArray(A) ? A : [A],
            D = P.reduce(u(h), {});
          !1 === V && (D = {});
          let { prevResolvedValues: O = {} } = f,
            I = { ...O, ...D },
            F = (t) => {
              ((k = !0), b.has(t) && ((E = !0), b.delete(t)), (f.needsAnimating[t] = !0));
              let i = e.getValue(t);
              i && (i.liveStyle = !1);
            };
          for (let e in I) {
            let t = D[e],
              i = O[e];
            if (!x.hasOwnProperty(e))
              ((0, d.isKeyframesTarget)(t) && (0, d.isKeyframesTarget)(i) ? !m(t, i) || C : t !== i)
                ? null != t
                  ? F(e)
                  : b.add(e)
                : void 0 !== t && b.has(e)
                  ? F(e)
                  : (f.protectedKeys[e] = !0);
          }
          ((f.prevProp = A),
            (f.prevResolvedValues = D),
            f.isActive && (x = { ...x, ...D }),
            (s || l) && e.blockInitialAnimation && (k = !1));
          let L = M && C,
            B = !L || E;
          k &&
            B &&
            T.push(
              ...P.map((t) => {
                let n = { type: h };
                if ("string" == typeof t && (s || l) && !L && e.manuallyAnimateOnMount && e.parent) {
                  let { parent: s } = e,
                    a = (0, i.resolveVariant)(s, t);
                  if (s.enteringChildren && a) {
                    let { delayChildren: t } = a.transition || {};
                    n.delay = r(s.enteringChildren, e, t);
                  }
                }
                return { animation: t, options: n };
              }),
            );
        }
        if (b.size) {
          let t = {};
          if ("boolean" != typeof v.initial) {
            let n = (0, i.resolveVariant)(e, Array.isArray(v.initial) ? v.initial[0] : v.initial);
            n && n.transition && (t.transition = n.transition);
          }
          (b.forEach((i) => {
            let n = e.getBaseTarget(i),
              r = e.getValue(i);
            (r && (r.liveStyle = !0), (t[i] = n ?? null));
          }),
            T.push({ animation: t }));
        }
        let A = !!T.length;
        return (
          s && (!1 === v.initial || v.initial === v.animate) && !e.manuallyAnimateOnMount && (A = !1),
          (s = !1),
          (l = !1),
          A ? t(T) : Promise.resolve()
        );
      }
      return {
        animateChanges: v,
        setActive: function (t, i) {
          if (n[t].isActive === i) return Promise.resolve();
          (e.variantChildren?.forEach((e) => e.animationState?.setActive(t, i)), (n[t].isActive = i));
          let r = v(t);
          for (let e in n) n[e].protectedKeys = {};
          return r;
        },
        setAnimateFunction: function (i) {
          t = i(e);
        },
        getState: () => n,
        reset: () => {
          ((n = T()), (l = !0));
        },
      };
    }
    function g(e, t) {
      return "string" == typeof t ? t !== e : !!Array.isArray(t) && !m(t, e);
    }
    function y() {
      let e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
      return { isActive: e, protectedKeys: {}, needsAnimating: {}, prevResolvedValues: {} };
    }
    function T() {
      return {
        animate: y(!0),
        whileInView: y(),
        whileHover: y(),
        whileTap: y(),
        whileDrag: y(),
        whileFocus: y(),
        exit: y(),
      };
    }
    e.s(["checkVariantsDidChange", 0, g, "createAnimationState", 0, v], 637041);
    class b extends t.Feature {
      constructor(e) {
        (super(e), e.animationState || (e.animationState = v(e)));
      }
      updateAnimationControlsSubscription() {
        let { animate: e } = this.node.getProps();
        (0, c.isAnimationControls)(e) && (this.unmountControls = e.subscribe(this.node));
      }
      mount() {
        this.updateAnimationControlsSubscription();
      }
      update() {
        let { animate: e } = this.node.getProps(),
          { animate: t } = this.node.prevProps || {};
        e !== t && this.updateAnimationControlsSubscription();
      }
      unmount() {
        (this.node.animationState.reset(), this.unmountControls?.());
      }
    }
    var x = t;
    let w = 0;
    class A extends x.Feature {
      constructor() {
        (super(...arguments), (this.id = w++), (this.isExitComplete = !1));
      }
      update() {
        if (!this.node.presenceContext) return;
        let { isPresent: e, onExitComplete: t } = this.node.presenceContext,
          { isPresent: n } = this.node.prevPresenceContext || {};
        if (!this.node.animationState || e === n) return;
        if (e && !1 === n) {
          if (this.isExitComplete) {
            let { initial: e, custom: t } = this.node.getProps();
            if ("string" == typeof e || ("object" == typeof e && null !== e && !Array.isArray(e))) {
              let n = (0, i.resolveVariant)(this.node, e, t);
              if (n) {
                let { transition: e, transitionEnd: t, ...i } = n;
                for (let e in i) this.node.getValue(e)?.jump(i[e]);
              }
            }
            (this.node.animationState.reset(), this.node.animationState.animateChanges());
          } else this.node.animationState.setActive("exit", !1);
          this.isExitComplete = !1;
          return;
        }
        let r = this.node.animationState.setActive("exit", !e);
        t &&
          !e &&
          r.then(() => {
            ((this.isExitComplete = !0), t(this.id));
          });
      }
      mount() {
        let { register: e, onExitComplete: t } = this.node.presenceContext || {};
        (t && t(this.id), e && (this.unmount = e(this.id)));
      }
      unmount() {}
    }
    e.s(["animations", 0, { animation: { Feature: b }, exit: { Feature: A } }], 223070);
  },
  708149,
  542269,
  (e) => {
    "use strict";
    var t = e.i(957512),
      i = e.i(99642),
      n = e.i(142098),
      r = e.i(772846),
      s = e.i(439676),
      a = e.i(260863),
      o = e.i(341327),
      l = e.i(973089),
      u = e.i(919880);
    let h = new WeakSet();
    function c(e) {
      return (t) => {
        "Enter" === t.key && e(t);
      };
    }
    function d(e, t) {
      e.dispatchEvent(new PointerEvent("pointer" + t, { isPrimary: !0, bubbles: !0 }));
    }
    function m(e) {
      return (0, o.isPrimaryPointer)(e) && !(0, s.isDragActive)();
    }
    let p = new WeakSet();
    function f(e, t) {
      let i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
        [n, s, o] = (0, l.setupGesture)(e, i),
        f = (e) => {
          let n = e.currentTarget;
          if (!m(e) || p.has(e)) return;
          (h.add(n), i.stopPropagation && p.add(e));
          let r = t(n, e),
            o = { ...s, capture: !0 },
            l = (e, t) => {
              (window.removeEventListener("pointerup", u, o),
                window.removeEventListener("pointercancel", c, o),
                h.has(n) && h.delete(n),
                m(e) && "function" == typeof r && r(e, { success: t }));
            },
            u = (e) => {
              l(e, n === window || n === document || i.useGlobalTarget || (0, a.isNodeOrChild)(n, e.target));
            },
            c = (e) => {
              l(e, !1);
            };
          (window.addEventListener("pointerup", u, o), window.addEventListener("pointercancel", c, o));
        };
      return (
        n.forEach((e) => {
          ((i.useGlobalTarget ? window : e).addEventListener("pointerdown", f, s),
            (0, r.isHTMLElement)(e) &&
              (e.addEventListener("focus", (e) =>
                ((e, t) => {
                  let i = e.currentTarget;
                  if (!i) return;
                  let n = c(() => {
                    if (h.has(i)) return;
                    d(i, "down");
                    let e = c(() => {
                      d(i, "up");
                    });
                    (i.addEventListener("keyup", e, t), i.addEventListener("blur", () => d(i, "cancel"), t));
                  });
                  (i.addEventListener("keydown", n, t),
                    i.addEventListener("blur", () => i.removeEventListener("keydown", n), t));
                })(e, s),
              ),
              (0, u.isElementKeyboardAccessible)(e) || e.hasAttribute("tabindex") || (e.tabIndex = 0)));
        }),
        o
      );
    }
    e.s(["press", 0, f], 542269);
    var v = e.i(287022),
      g = e.i(665536);
    function y(e, t, i) {
      let { props: n } = e;
      if (e.current instanceof HTMLButtonElement && e.current.disabled) return;
      e.animationState && n.whileTap && e.animationState.setActive("whileTap", "Start" === i);
      let r = n["onTap" + ("End" === i ? "" : i)];
      r && v.frame.postRender(() => r(t, (0, g.extractEventInfo)(t)));
    }
    class T extends n.Feature {
      mount() {
        let { current: e } = this.node;
        if (!e) return;
        let { globalTapTarget: t, propagate: i } = this.node.props;
        this.unmount = f(
          e,
          (e, t) => (
            y(this.node, t, "Start"),
            (e, t) => {
              let { success: i } = t;
              return y(this.node, e, i ? "End" : "Cancel");
            }
          ),
          { useGlobalTarget: t, stopPropagation: i?.tap === !1 },
        );
      }
      unmount() {}
    }
    var b = n;
    let x = new WeakMap(),
      w = new WeakMap(),
      A = (e) => {
        let t = x.get(e.target);
        t && t(e);
      },
      S = (e) => {
        e.forEach(A);
      },
      V = { some: 0, all: 1 };
    class M extends b.Feature {
      constructor() {
        (super(...arguments), (this.hasEnteredView = !1), (this.isInView = !1));
      }
      startObserver() {
        var e;
        let t;
        this.stopObserver?.();
        let { viewport: i = {} } = this.node.getProps(),
          { root: n, margin: r, amount: s = "some", once: a } = i,
          o = { root: n ? n.current : void 0, rootMargin: r, threshold: "number" == typeof s ? s : V[s] },
          l = (e) => {
            let { isIntersecting: t } = e;
            if (this.isInView === t || ((this.isInView = t), a && !t && this.hasEnteredView)) return;
            (t && (this.hasEnteredView = !0),
              this.node.animationState && this.node.animationState.setActive("whileInView", t));
            let { onViewportEnter: i, onViewportLeave: n } = this.node.getProps(),
              r = t ? i : n;
            r && r(e);
          };
        this.stopObserver =
          ((e = this.node.current),
          (t = (function (e) {
            let { root: t, ...i } = e,
              n = t || document;
            w.has(n) || w.set(n, {});
            let r = w.get(n),
              s = JSON.stringify(i);
            return (r[s] || (r[s] = new IntersectionObserver(S, { root: t, ...i })), r[s]);
          })(o)),
          x.set(e, l),
          t.observe(e),
          () => {
            (x.delete(e), t.unobserve(e));
          });
      }
      mount() {
        this.startObserver();
      }
      update() {
        if ("u" < typeof IntersectionObserver) return;
        let { props: e, prevProps: t } = this.node;
        ["amount", "margin", "root"].some(
          (function (e) {
            let { viewport: t = {} } = e,
              { viewport: i = {} } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            return (e) => t[e] !== i[e];
          })(e, t),
        ) && this.startObserver();
      }
      unmount() {
        (this.stopObserver?.(), (this.hasEnteredView = !1), (this.isInView = !1));
      }
    }
    let C = {
      inView: { Feature: M },
      tap: { Feature: T },
      focus: { Feature: i.FocusGesture },
      hover: { Feature: t.HoverGesture },
    };
    e.s(["gestureAnimations", 0, C], 708149);
  },
  154505,
  684015,
  646436,
  194978,
  638698,
  449095,
  188826,
  275737,
  27677,
  177777,
  135636,
  153689,
  386783,
  (e) => {
    "use strict";
    var t = e.i(157788),
      i = e.i(203973),
      n = e.i(130162),
      r = e.i(83411),
      s = e.i(864440),
      a = e.i(277942),
      o = e.i(965566),
      l = e.i(172590),
      u = e.i(19928);
    let h = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;
    function c(e) {
      let t = h.exec(e);
      if (!t) return [,];
      let [, i, n, r] = t;
      return [`--${i ?? n}`, r];
    }
    function d(e, t) {
      let i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
      (0, o.invariant)(
        i <= 4,
        `Max CSS variable fallback depth detected in property "${e}". This may indicate a circular fallback dependency.`,
        "max-css-var-depth",
      );
      let [n, r] = c(e);
      if (!n) return;
      let s = window.getComputedStyle(t).getPropertyValue(n);
      if (s) {
        let e = s.trim();
        return (0, l.isNumericalString)(e) ? parseFloat(e) : e;
      }
      return (0, u.isCSSVariableToken)(r) ? d(r, t, i + 1) : r;
    }
    e.s(["getVariableValue", 0, d, "parseCSSVariable", 0, c], 684015);
    var m = e.i(921012),
      p = e.i(547507),
      f = e.i(569577),
      v = e.i(775554);
    let g = new Set(["auto", "none", "0"]);
    var y = e.i(44493);
    class T extends m.KeyframeResolver {
      constructor(e, t, i, n, r) {
        super(e, t, i, n, r, !0);
      }
      readKeyframes() {
        let { unresolvedKeyframes: e, element: t, name: i } = this;
        if (!t || !t.current) return;
        super.readKeyframes();
        for (let i = 0; i < e.length; i++) {
          let n = e[i];
          if ("string" == typeof n && ((n = n.trim()), (0, u.isCSSVariableToken)(n))) {
            let r = d(n, t.current);
            (void 0 !== r && (e[i] = r), i === e.length - 1 && (this.finalKeyframe = n));
          }
        }
        if ((this.resolveNoneKeyframes(), !s.positionalKeys.has(i) || 2 !== e.length)) return;
        let [n, r] = e,
          o = (0, a.findDimensionValueType)(n),
          l = (0, a.findDimensionValueType)(r);
        if ((0, u.containsCSSVariable)(n) !== (0, u.containsCSSVariable)(r) && y.positionalValues[i]) {
          this.needsMeasurement = !0;
          return;
        }
        if (o !== l)
          if ((0, y.isNumOrPxType)(o) && (0, y.isNumOrPxType)(l))
            for (let t = 0; t < e.length; t++) {
              let i = e[t];
              "string" == typeof i && (e[t] = parseFloat(i));
            }
          else y.positionalValues[i] && (this.needsMeasurement = !0);
      }
      resolveNoneKeyframes() {
        let { unresolvedKeyframes: e, name: t } = this,
          i = [];
        for (let t = 0; t < e.length; t++) {
          var n;
          (null === e[t] ||
            ("number" == typeof (n = e[t])
              ? 0 === n
              : null === n || "none" === n || "0" === n || (0, p.isZeroValueString)(n))) &&
            i.push(t);
        }
        i.length &&
          (function (e, t, i) {
            let n,
              r = 0;
            for (; r < e.length && !n;) {
              let t = e[r];
              ("string" == typeof t && !g.has(t) && (0, f.analyseComplexValue)(t).values.length && (n = e[r]),
                r++);
            }
            if (n && i) for (let r of t) e[r] = (0, v.getAnimatableNone)(i, n);
          })(e, i, t);
      }
      measureInitialState() {
        let { element: e, unresolvedKeyframes: t, name: i } = this;
        if (!e || !e.current) return;
        ("height" === i && (this.suspendedScrollY = window.pageYOffset),
          (this.measuredOrigin = y.positionalValues[i](
            e.measureViewportBox(),
            window.getComputedStyle(e.current),
          )),
          (t[0] = this.measuredOrigin));
        let n = t[t.length - 1];
        void 0 !== n && e.getValue(i, n).jump(n, !1);
      }
      measureEndState() {
        let { element: e, name: t, unresolvedKeyframes: i } = this;
        if (!e || !e.current) return;
        let n = e.getValue(t);
        n && n.jump(this.measuredOrigin, !1);
        let r = i.length - 1,
          s = i[r];
        ((i[r] = y.positionalValues[t](e.measureViewportBox(), window.getComputedStyle(e.current))),
          null !== s && void 0 === this.finalKeyframe && (this.finalKeyframe = s),
          this.removedTransforms?.length &&
            this.removedTransforms.forEach((t) => {
              let [i, n] = t;
              e.getValue(i).set(n);
            }),
          this.resolveNoneKeyframes());
      }
    }
    e.s(["DOMKeyframesResolver", 0, T], 646436);
    var b = e.i(617218);
    class x extends b.VisualElement {
      constructor() {
        (super(...arguments), (this.KeyframeResolver = T));
      }
      sortInstanceNodePosition(e, t) {
        return 2 & e.compareDocumentPosition(t) ? 1 : -1;
      }
      getBaseTargetFromProps(e, t) {
        let i = e.style;
        return i ? i[t] : void 0;
      }
      removeValueFromRenderState(e, t) {
        let { vars: i, style: n } = t;
        (delete i[e], delete n[e]);
      }
      handleChildMotionValue() {
        this.childSubscription && (this.childSubscription(), delete this.childSubscription);
        let { children: e } = this.props;
        (0, r.isMotionValue)(e) &&
          (this.childSubscription = e.on("change", (e) => {
            this.current && (this.current.textContent = `${e}`);
          }));
      }
    }
    e.s(["DOMVisualElement", 0, x], 194978);
    var w = e.i(793787),
      A = e.i(181261);
    let S = new Set([
      "baseFrequency",
      "diffuseConstant",
      "kernelMatrix",
      "kernelUnitLength",
      "keySplines",
      "keyTimes",
      "limitingConeAngle",
      "markerHeight",
      "markerWidth",
      "numOctaves",
      "targetX",
      "targetY",
      "surfaceScale",
      "specularConstant",
      "specularExponent",
      "stdDeviation",
      "tableValues",
      "viewBox",
      "gradientTransform",
      "pathLength",
      "startOffset",
      "textLength",
      "lengthAdjust",
    ]);
    e.s(["camelCaseAttributes", 0, S], 638698);
    var V = e.i(399951);
    function M(e, t, i, n) {
      let r,
        { style: s, vars: a } = t,
        o = e.style;
      for (r in s) o[r] = s[r];
      for (r in (n?.applyProjectionStyles(o, i), a)) o.setProperty(r, a[r]);
    }
    function C(e, t, i, n) {
      for (let i in (M(e, t, void 0, n), t.attrs))
        e.setAttribute(S.has(i) ? i : (0, w.camelToDash)(i), t.attrs[i]);
    }
    (e.s(["renderHTML", 0, M], 449095), e.s(["renderSVG", 0, C], 188826));
    var k = e.i(767926);
    class E extends x {
      constructor() {
        (super(...arguments),
          (this.type = "svg"),
          (this.isSVGTag = !1),
          (this.measureInstanceViewportBox = n.createBox));
      }
      getBaseTargetFromProps(e, t) {
        return e[t];
      }
      readValueFromInstance(e, n) {
        if (t.transformProps.has(n)) {
          let e = (0, i.getDefaultValueType)(n);
          return (e && e.default) || 0;
        }
        return ((n = S.has(n) ? n : (0, w.camelToDash)(n)), e.getAttribute(n));
      }
      scrapeMotionValuesFromProps(e, t, i) {
        return (0, k.scrapeMotionValuesFromProps)(e, t, i);
      }
      build(e, t, i) {
        (0, A.buildSVGAttrs)(e, t, this.isSVGTag, i.transformTemplate, i.style);
      }
      renderInstance(e, t, i, n) {
        C(e, t, i, n);
      }
      mount(e) {
        ((this.isSVGTag = (0, V.isSVGTag)(e.tagName)), super.mount(e));
      }
    }
    e.s(["SVGVisualElement", 0, E], 275737);
    var P = e.i(381296);
    function D(e) {
      let { top: t, left: i, right: n, bottom: r } = e;
      return { x: { min: i, max: n }, y: { min: t, max: r } };
    }
    function O(e, t) {
      if (!t) return e;
      let i = t({ x: e.left, y: e.top }),
        n = t({ x: e.right, y: e.bottom });
      return { top: i.y, left: i.x, bottom: n.y, right: n.x };
    }
    e.s(
      [
        "convertBoundingBoxToBox",
        0,
        D,
        "convertBoxToBoundingBox",
        0,
        function (e) {
          let { x: t, y: i } = e;
          return { top: i.min, right: t.max, bottom: i.max, left: t.min };
        },
        "transformBoxPoints",
        0,
        O,
      ],
      27677,
    );
    var I = e.i(100706);
    function F(e) {
      return void 0 === e || 1 === e;
    }
    function L(e) {
      let { scale: t, scaleX: i, scaleY: n } = e;
      return !F(t) || !F(i) || !F(n);
    }
    function B(e) {
      return L(e) || G(e) || e.z || e.rotate || e.rotateX || e.rotateY || e.skewX || e.skewY;
    }
    function G(e) {
      var t, i;
      return ((t = e.x) && "0%" !== t) || ((i = e.y) && "0%" !== i);
    }
    function K(e, t, i) {
      return i + t * (e - i);
    }
    function R(e, t, i, n, r) {
      return (void 0 !== r && (e = K(e, r, n)), K(e, i, n) + t);
    }
    function N(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
        i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
        n = arguments.length > 3 ? arguments[3] : void 0,
        r = arguments.length > 4 ? arguments[4] : void 0;
      ((e.min = R(e.min, t, i, n, r)), (e.max = R(e.max, t, i, n, r)));
    }
    function j(e, t) {
      let { x: i, y: n } = t;
      (N(e.x, i.translate, i.scale, i.originPoint), N(e.y, n.translate, n.scale, n.originPoint));
    }
    function H(e, t) {
      ((e.min += t), (e.max += t));
    }
    function W(e, t, i, n) {
      let r = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0.5,
        s = (0, I.mixNumber)(e.min, e.max, r);
      N(e, t, i, s, n);
    }
    function z(e, t) {
      return "string" == typeof e ? (parseFloat(e) / 100) * (t.max - t.min) : e;
    }
    function q(e, t, i) {
      let n = i ?? e;
      (W(e.x, z(t.x, n.x), t.scaleX, t.scale, t.originX), W(e.y, z(t.y, n.y), t.scaleY, t.scale, t.originY));
    }
    function U(e, t) {
      return D(O(e.getBoundingClientRect(), t));
    }
    (e.s(["has2DTranslate", 0, G, "hasScale", 0, L, "hasTransform", 0, B], 177777),
      e.s(
        [
          "applyAxisDelta",
          0,
          N,
          "applyBoxDelta",
          0,
          j,
          "applyPointDelta",
          0,
          R,
          "applyTreeDeltas",
          0,
          function (e, t, i) {
            let n,
              r,
              s = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
              a = i.length;
            if (a) {
              t.x = t.y = 1;
              for (let o = 0; o < a; o++) {
                r = (n = i[o]).projectionDelta;
                let { visualElement: a } = n.options;
                (!a || !a.props.style || "contents" !== a.props.style.display) &&
                  (s &&
                    n.options.layoutScroll &&
                    n.scroll &&
                    n !== n.root &&
                    (H(e.x, -n.scroll.offset.x), H(e.y, -n.scroll.offset.y)),
                  r && ((t.x *= r.x.scale), (t.y *= r.y.scale), j(e, r)),
                  s && B(n.latestValues) && q(e, n.latestValues, n.layout?.layoutBox));
              }
              (t.x < 1.0000000000001 && t.x > 0.999999999999 && (t.x = 1),
                t.y < 1.0000000000001 && t.y > 0.999999999999 && (t.y = 1));
            }
          },
          "scalePoint",
          0,
          K,
          "transformAxis",
          0,
          W,
          "transformBox",
          0,
          q,
          "translateAxis",
          0,
          H,
        ],
        135636,
      ),
      e.s(
        [
          "measurePageBox",
          0,
          function (e, t, i) {
            let n = U(e, i),
              { scroll: r } = t;
            return (r && (H(n.x, r.offset.x), H(n.y, r.offset.y)), n);
          },
          "measureViewportBox",
          0,
          U,
        ],
        153689,
      ));
    var $ = e.i(544947),
      Y = e.i(984049);
    class _ extends x {
      constructor() {
        (super(...arguments), (this.type = "html"), (this.renderInstance = M));
      }
      mount(e) {
        ((0, o.invariant)(
          !!e.style,
          "motion.create() components must forward their ref to a HTML or SVG element",
          "custom-component-ref",
        ),
          super.mount(e));
      }
      readValueFromInstance(e, i) {
        if (t.transformProps.has(i))
          return this.projection?.isProjecting
            ? (0, P.defaultTransformValue)(i)
            : (0, P.readTransformValue)(e, i);
        {
          let t = window.getComputedStyle(e),
            n = ((0, u.isCSSVariableName)(i) ? t.getPropertyValue(i) : t[i]) || 0;
          return "string" == typeof n ? n.trim() : n;
        }
      }
      measureInstanceViewportBox(e, t) {
        let { transformPagePoint: i } = t;
        return U(e, i);
      }
      build(e, t, i) {
        (0, $.buildHTMLStyles)(e, t, i.transformTemplate);
      }
      scrapeMotionValuesFromProps(e, t, i) {
        return (0, Y.scrapeMotionValuesFromProps)(e, t, i);
      }
    }
    e.s(["HTMLVisualElement", 0, _], 386783);
    var X = e.i(271645),
      J = e.i(944966);
    e.s(
      [
        "createDomVisualElement",
        0,
        (e, t) =>
          (t.isSVG ?? (0, J.isSVGComponent)(e)) ? new E(t) : new _(t, { allowProjection: e !== X.Fragment }),
      ],
      154505,
    );
  },
  42062,
  945704,
  668514,
  83352,
  592464,
  343116,
  78866,
  (e) => {
    "use strict";
    var t = e.i(846791),
      i = e.i(260830),
      n = e.i(496173),
      r = e.i(738638),
      s = e.i(476959),
      a = e.i(763074),
      o = e.i(203163),
      l = e.i(769308),
      u = e.i(29462),
      h = e.i(437025),
      c = e.i(893544),
      d = e.i(532943),
      m = e.i(344230),
      p = e.i(515923);
    function f(e, t) {
      return e.map((e) => e * t);
    }
    function v(e, t) {
      return e.map(() => t || h.easeInOut).splice(0, e.length - 1);
    }
    function g(e) {
      let { duration: t = 300, keyframes: i, times: n, ease: r = "easeInOut" } = e,
        s = (0, c.isEasingArray)(r)
          ? r.map(d.easingDefinitionToFunction)
          : (0, d.easingDefinitionToFunction)(r),
        a = { done: !1, value: i[0] },
        o = f(n && n.length === i.length ? n : (0, p.defaultOffset)(i), t),
        l = (0, m.interpolate)(o, i, { ease: Array.isArray(s) ? s : v(i, s) });
      return { calculatedDuration: t, next: (e) => ((a.value = l(e)), (a.done = e >= t), a) };
    }
    (e.s(["convertOffsetToTimes", 0, f], 945704), e.s(["defaultEasing", 0, v, "keyframes", 0, g], 668514));
    var y = e.i(655529),
      T = e.i(912008),
      b = e.i(414229),
      x = e.i(528409);
    let w = { decay: u.inertia, inertia: u.inertia, tween: g, keyframes: g, spring: x.spring };
    function A(e) {
      "string" == typeof e.type && (e.type = w[e.type]);
    }
    var S = e.i(779294);
    let V = (e) => e / 100;
    class M extends S.WithPromise {
      constructor(e) {
        (super(),
          (this.state = "idle"),
          (this.startTime = null),
          (this.isStopped = !1),
          (this.currentTime = 0),
          (this.holdTime = null),
          (this.playbackSpeed = 1),
          (this.delayState = { done: !1, value: void 0 }),
          (this.stop = () => {
            let { motionValue: e } = this.options;
            (e && e.updatedAt !== n.time.now() && this.tick(n.time.now()),
              (this.isStopped = !0),
              "idle" !== this.state && (this.teardown(), this.options.onStop?.()));
          }),
          (this.options = e),
          this.initAnimation(),
          this.play(),
          !1 === e.autoplay && this.pause());
      }
      initAnimation() {
        let { options: e } = this;
        A(e);
        let { type: t = g, repeat: i = 0, repeatDelay: n = 0, repeatType: s, velocity: a = 0 } = e,
          { keyframes: l } = e,
          u = t || g;
        u !== g &&
          "number" != typeof l[0] &&
          ((this.mixKeyframes = (0, r.pipe)(V, (0, o.mix)(l[0], l[1]))), (l = [0, 100]));
        let h = u({ ...e, keyframes: l });
        ("mirror" === s && (this.mirroredGenerator = u({ ...e, keyframes: [...l].reverse(), velocity: -a })),
          null === h.calculatedDuration && (h.calculatedDuration = (0, y.calcGeneratorDuration)(h)));
        let { calculatedDuration: c } = h;
        ((this.calculatedDuration = c),
          (this.resolvedDuration = c + n),
          (this.totalDuration = this.resolvedDuration * (i + 1) - n),
          (this.generator = h));
      }
      updateTime(e) {
        let t = Math.round(e - this.startTime) * this.playbackSpeed;
        null !== this.holdTime ? (this.currentTime = this.holdTime) : (this.currentTime = t);
      }
      tick(e) {
        let t,
          i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          {
            generator: n,
            totalDuration: r,
            mixKeyframes: a,
            mirroredGenerator: o,
            resolvedDuration: l,
            calculatedDuration: h,
          } = this;
        if (null === this.startTime) return n.next(0);
        let {
          delay: c = 0,
          keyframes: d,
          repeat: m,
          repeatType: p,
          repeatDelay: f,
          type: v,
          onUpdate: g,
          finalKeyframe: y,
        } = this.options;
        (this.speed > 0
          ? (this.startTime = Math.min(this.startTime, e))
          : this.speed < 0 && (this.startTime = Math.min(e - r / this.speed, this.startTime)),
          i ? (this.currentTime = e) : this.updateTime(e));
        let T = this.currentTime - c * (this.playbackSpeed >= 0 ? 1 : -1),
          x = this.playbackSpeed >= 0 ? T < 0 : T > r;
        ((this.currentTime = Math.max(T, 0)),
          "finished" === this.state && null === this.holdTime && (this.currentTime = r));
        let w = this.currentTime,
          A = n;
        if (m) {
          let e = Math.min(this.currentTime, r) / l,
            t = Math.floor(e),
            i = e % 1;
          (!i && e >= 1 && (i = 1),
            1 === i && t--,
            (t = Math.min(t, m + 1)) % 2 &&
              ("reverse" === p ? ((i = 1 - i), f && (i -= f / l)) : "mirror" === p && (A = o)),
            (w = (0, s.clamp)(0, 1, i) * l));
        }
        (x ? ((this.delayState.value = d[0]), (t = this.delayState)) : (t = A.next(w)),
          a && !x && (t.value = a(t.value)));
        let { done: S } = t;
        x || null === h || (S = this.playbackSpeed >= 0 ? this.currentTime >= r : this.currentTime <= 0);
        let V = null === this.holdTime && ("finished" === this.state || ("running" === this.state && S));
        return (
          V && v !== u.inertia && (t.value = (0, b.getFinalKeyframe)(d, this.options, y, this.speed)),
          g && g(t.value),
          V && this.finish(),
          t
        );
      }
      then(e, t) {
        return this.finished.then(e, t);
      }
      get duration() {
        return (0, a.millisecondsToSeconds)(this.calculatedDuration);
      }
      get iterationDuration() {
        let { delay: e = 0 } = this.options || {};
        return this.duration + (0, a.millisecondsToSeconds)(e);
      }
      get time() {
        return (0, a.millisecondsToSeconds)(this.currentTime);
      }
      set time(e) {
        ((e = (0, a.secondsToMilliseconds)(e)),
          (this.currentTime = e),
          null === this.startTime || null !== this.holdTime || 0 === this.playbackSpeed
            ? (this.holdTime = e)
            : this.driver && (this.startTime = this.driver.now() - e / this.playbackSpeed),
          this.driver
            ? this.driver.start(!1)
            : ((this.startTime = 0), (this.state = "paused"), (this.holdTime = e), this.tick(e)));
      }
      getGeneratorVelocity() {
        let e = this.currentTime;
        if (e <= 0) return this.options.velocity || 0;
        if (this.generator.velocity) return this.generator.velocity(e);
        let t = this.generator.next(e).value;
        return (0, T.getGeneratorVelocity)((e) => this.generator.next(e).value, e, t);
      }
      get speed() {
        return this.playbackSpeed;
      }
      set speed(e) {
        let t = this.playbackSpeed !== e;
        (t && this.driver && this.updateTime(n.time.now()),
          (this.playbackSpeed = e),
          t && this.driver && (this.time = (0, a.millisecondsToSeconds)(this.currentTime)));
      }
      play() {
        if (this.isStopped) return;
        let { driver: e = l.frameloopDriver, startTime: t } = this.options;
        (this.driver || (this.driver = e((e) => this.tick(e))), this.options.onPlay?.());
        let i = this.driver.now();
        ("finished" === this.state
          ? (this.updateFinished(), (this.startTime = i))
          : null !== this.holdTime
            ? (this.startTime = i - this.holdTime)
            : this.startTime || (this.startTime = t ?? i),
          "finished" === this.state && this.speed < 0 && (this.startTime += this.calculatedDuration),
          (this.holdTime = null),
          (this.state = "running"),
          this.driver.start());
      }
      pause() {
        ((this.state = "paused"), this.updateTime(n.time.now()), (this.holdTime = this.currentTime));
      }
      complete() {
        ("running" !== this.state && this.play(), (this.state = "finished"), (this.holdTime = null));
      }
      finish() {
        (this.notifyFinished(), this.teardown(), (this.state = "finished"), this.options.onComplete?.());
      }
      cancel() {
        ((this.holdTime = null),
          (this.startTime = 0),
          this.tick(0),
          this.teardown(),
          this.options.onCancel?.());
      }
      teardown() {
        ((this.state = "idle"), this.stopDriver(), (this.startTime = this.holdTime = null));
      }
      stopDriver() {
        this.driver && (this.driver.stop(), (this.driver = void 0));
      }
      sample(e) {
        return ((this.startTime = 0), this.tick(e, !0));
      }
      attachTimeline(e) {
        return (
          this.options.allowFlatten &&
            ((this.options.type = "keyframes"), (this.options.ease = "linear"), this.initAnimation()),
          this.driver?.stop(),
          e.observe(this)
        );
      }
    }
    e.s(
      [
        "JSAnimation",
        0,
        M,
        "animateValue",
        0,
        function (e) {
          return new M(e);
        },
      ],
      83352,
    );
    var C = e.i(921012),
      k = e.i(794581),
      E = e.i(368e3),
      P = e.i(791559),
      D = e.i(641980);
    let O = { anticipate: e.i(878047).anticipate, backInOut: D.backInOut, circInOut: P.circInOut };
    class I extends E.NativeAnimation {
      constructor(e) {
        (!(function (e) {
          "string" == typeof e.ease && e.ease in O && (e.ease = O[e.ease]);
        })(e),
          A(e),
          super(e),
          void 0 !== e.startTime && !1 !== e.autoplay && (this.startTime = e.startTime),
          (this.options = e));
      }
      updateMotionValue(e) {
        let { motionValue: t, onUpdate: i, onComplete: r, element: a, ...o } = this.options;
        if (!t) return;
        if (void 0 !== e) return void t.set(e);
        let l = new M({ ...o, autoplay: !1 }),
          u = Math.max(10, n.time.now() - this.startTime),
          h = (0, s.clamp)(0, 10, u - 10),
          c = l.sample(u).value,
          { name: d } = this.options;
        (a && d && (0, k.setStyle)(a, d, c),
          t.setWithVelocity(l.sample(Math.max(0, u - h)).value, c, h),
          l.stop());
      }
    }
    e.s(["NativeAnimationExtended", 0, I], 592464);
    var F = e.i(965566),
      L = e.i(997307),
      B = e.i(569577);
    let G = (e, t) =>
      "zIndex" !== t &&
      !!(
        "number" == typeof e ||
        Array.isArray(e) ||
        ("string" == typeof e && (B.complex.test(e) || "0" === e) && !e.startsWith("url("))
      );
    function K(e) {
      ((e.duration = 0), (e.type = "keyframes"));
    }
    e.s(["makeAnimationInstant", 0, K], 343116);
    var R = S,
      N = e.i(260900),
      j = e.i(962118);
    let H = /^(?:oklch|oklab|lab|lch|color|color-mix|light-dark)\(/,
      W = new Set([
        "color",
        "backgroundColor",
        "outlineColor",
        "fill",
        "stroke",
        "borderColor",
        "borderTopColor",
        "borderRightColor",
        "borderBottomColor",
        "borderLeftColor",
      ]),
      z = (0, N.memo)(() => Object.hasOwnProperty.call(Element.prototype, "animate"));
    function q(e) {
      let { motionValue: t, name: i, repeatDelay: n, repeatType: r, damping: s, type: a, keyframes: o } = e,
        l = t?.owner?.current;
      if (!(l instanceof HTMLElement) && !(l instanceof SVGElement)) return !1;
      let { onUpdate: u, transformTemplate: h } = t.owner.getProps();
      return (
        z() &&
        i &&
        (j.acceleratedValues.has(i) ||
          (W.has(i) &&
            (function (e) {
              for (let t = 0; t < e.length; t++) if ("string" == typeof e[t] && H.test(e[t])) return !0;
              return !1;
            })(o))) &&
        ("transform" !== i || !h) &&
        !u &&
        !n &&
        "mirror" !== r &&
        0 !== s &&
        "inertia" !== a
      );
    }
    e.s(["supportsBrowserAnimation", 0, q], 78866);
    class U extends R.WithPromise {
      constructor({
        autoplay: e = !0,
        delay: t = 0,
        type: i = "keyframes",
        repeat: r = 0,
        repeatDelay: s = 0,
        repeatType: a = "loop",
        keyframes: o,
        name: l,
        motionValue: u,
        element: h,
        ...c
      }) {
        (super(),
          (this.stop = () => {
            (this._animation && (this._animation.stop(), this.stopTimeline?.()),
              this.keyframeResolver?.cancel());
          }),
          (this.createdAt = n.time.now()));
        const d = {
            autoplay: e,
            delay: t,
            type: i,
            repeat: r,
            repeatDelay: s,
            repeatType: a,
            name: l,
            motionValue: u,
            element: h,
            ...c,
          },
          m = h?.KeyframeResolver || C.KeyframeResolver;
        ((this.keyframeResolver = new m(o, (e, t, i) => this.onKeyframesResolved(e, t, d, !i), l, u, h)),
          this.keyframeResolver?.scheduleResolve());
      }
      onKeyframesResolved(e, r, s, a) {
        let o;
        this.keyframeResolver = void 0;
        let { name: l, type: u, velocity: h, delay: c, isHandoff: d, onUpdate: m } = s;
        this.resolvedAt = n.time.now();
        let p = !0;
        !(function (e, t, i, n) {
          let r = e[0];
          if (null === r) return !1;
          if ("display" === t || "visibility" === t) return !0;
          let s = e[e.length - 1],
            a = G(r, t),
            o = G(s, t);
          return (
            (0, F.warning)(
              a === o,
              `You are trying to animate ${t} from "${r}" to "${s}". "${a ? s : r}" is not an animatable value.`,
              "value-not-animatable",
            ),
            !!a &&
              !!o &&
              ((function (e) {
                let t = e[0];
                if (1 === e.length) return !0;
                for (let i = 0; i < e.length; i++) if (e[i] !== t) return !0;
              })(e) ||
                (("spring" === i || (0, L.isGenerator)(i)) && n))
          );
        })(e, l, u, h) &&
          ((p = !1),
          (t.MotionGlobalConfig.instantAnimations || !c) && m?.((0, b.getFinalKeyframe)(e, s, r)),
          (e[0] = e[e.length - 1]),
          K(s),
          (s.repeat = 0));
        let f = {
            startTime: a
              ? this.resolvedAt && this.resolvedAt - this.createdAt > 40
                ? this.resolvedAt
                : this.createdAt
              : void 0,
            finalKeyframe: r,
            ...s,
            keyframes: e,
          },
          v = p && !d && q(f),
          g = f.motionValue?.owner?.current;
        if (v)
          try {
            o = new I({ ...f, element: g });
          } catch {
            o = new M(f);
          }
        else o = new M(f);
        (o.finished
          .then(() => {
            this.notifyFinished();
          })
          .catch(i.noop),
          this.pendingTimeline &&
            ((this.stopTimeline = o.attachTimeline(this.pendingTimeline)), (this.pendingTimeline = void 0)),
          (this._animation = o));
      }
      get finished() {
        return this._animation ? this.animation.finished : this._finished;
      }
      then(e, t) {
        return this.finished.finally(e).then(() => {});
      }
      get animation() {
        return (
          this._animation || (this.keyframeResolver?.resume(), (0, C.flushKeyframeResolvers)()),
          this._animation
        );
      }
      get duration() {
        return this.animation.duration;
      }
      get iterationDuration() {
        return this.animation.iterationDuration;
      }
      get time() {
        return this.animation.time;
      }
      set time(e) {
        this.animation.time = e;
      }
      get speed() {
        return this.animation.speed;
      }
      get state() {
        return this.animation.state;
      }
      set speed(e) {
        this.animation.speed = e;
      }
      get startTime() {
        return this.animation.startTime;
      }
      attachTimeline(e) {
        return (
          this._animation
            ? (this.stopTimeline = this.animation.attachTimeline(e))
            : (this.pendingTimeline = e),
          () => this.stop()
        );
      }
      play() {
        this.animation.play();
      }
      pause() {
        this.animation.pause();
      }
      complete() {
        this.animation.complete();
      }
      cancel() {
        (this._animation && this.animation.cancel(), this.keyframeResolver?.cancel());
      }
    }
    e.s(["AsyncMotionValueAnimation", 0, U], 42062);
  },
  29462,
  912008,
  440254,
  437025,
  (e) => {
    "use strict";
    var t = e.i(528409),
      i = e.i(325791);
    function n(e, t, n) {
      let r = Math.max(t - 5, 0);
      return (0, i.velocityPerSecond)(n - e(r), t - r);
    }
    (e.s(["getGeneratorVelocity", 0, n], 912008),
      e.s(
        [
          "inertia",
          0,
          function (e) {
            let i,
              r,
              {
                keyframes: s,
                velocity: a = 0,
                power: o = 0.8,
                timeConstant: l = 325,
                bounceDamping: u = 10,
                bounceStiffness: h = 500,
                modifyTarget: c,
                min: d,
                max: m,
                restDelta: p = 0.5,
                restSpeed: f,
              } = e,
              v = s[0],
              g = { done: !1, value: v },
              y = o * a,
              T = v + y,
              b = void 0 === c ? T : c(T);
            b !== T && (y = b - v);
            let x = (e) => -y * Math.exp(-e / l),
              w = (e) => b + x(e),
              A = (e) => {
                let t = x(e),
                  i = w(e);
                ((g.done = Math.abs(t) <= p), (g.value = g.done ? b : i));
              },
              S = (e) => {
                let s;
                if (((s = g.value), (void 0 !== d && s < d) || (void 0 !== m && s > m))) {
                  var a;
                  ((i = e),
                    (r = (0, t.spring)({
                      keyframes: [
                        g.value,
                        ((a = g.value),
                        void 0 === d ? m : void 0 === m || Math.abs(d - a) < Math.abs(m - a) ? d : m),
                      ],
                      velocity: n(w, e, g.value),
                      damping: u,
                      stiffness: h,
                      restDelta: p,
                      restSpeed: f,
                    })));
                }
              };
            return (
              S(0),
              {
                calculatedDuration: null,
                next: (e) => {
                  let t = !1;
                  return (r || void 0 !== i || ((t = !0), A(e), S(e)), void 0 !== i && e >= i)
                    ? r.next(e - i)
                    : (t || A(e), g);
                },
              }
            );
          },
        ],
        29462,
      ));
    var r = e.i(260830);
    let s = (e, t, i) => (((1 - 3 * i + 3 * t) * e + (3 * i - 6 * t)) * e + 3 * t) * e;
    function a(e, t, i, n) {
      return e === t && i === n
        ? r.noop
        : (r) =>
            0 === r || 1 === r
              ? r
              : s(
                  (function (e, t, i, n, r) {
                    let a,
                      o,
                      l = 0;
                    do (a = s((o = t + (i - t) / 2), n, r) - e) > 0 ? (i = o) : (t = o);
                    while (Math.abs(a) > 1e-7 && ++l < 12);
                    return o;
                  })(r, 0, 1, e, i),
                  t,
                  n,
                );
    }
    e.s(["cubicBezier", 0, a], 440254);
    let o = a(0.42, 0, 1, 1),
      l = a(0, 0, 0.58, 1),
      u = a(0.42, 0, 0.58, 1);
    e.s(["easeIn", 0, o, "easeInOut", 0, u, "easeOut", 0, l], 437025);
  },
  528409,
  655529,
  721748,
  (e) => {
    "use strict";
    var t = e.i(763074),
      i = e.i(476959),
      n = e.i(965566),
      r = e.i(756512);
    function s(e) {
      let t = 0,
        i = e.next(t);
      for (; !i.done && t < 2e4;) ((t += 50), (i = e.next(t)));
      return t >= 2e4 ? 1 / 0 : t;
    }
    function a(e) {
      let i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 100,
        n = arguments.length > 2 ? arguments[2] : void 0,
        r = n({ ...e, keyframes: [0, i] }),
        a = Math.min(s(r), 2e4);
      return {
        type: "keyframes",
        ease: (e) => r.next(a * e).value / i,
        duration: (0, t.millisecondsToSeconds)(a),
      };
    }
    (e.s(["calcGeneratorDuration", 0, s, "maxGeneratorDuration", 0, 2e4], 655529),
      e.s(["createGeneratorEasing", 0, a], 721748));
    let o = 0.01,
      l = 2,
      u = 0.005,
      h = 0.5;
    function c(e, t) {
      return e * Math.sqrt(1 - t * t);
    }
    let d = ["duration", "bounce"],
      m = ["stiffness", "damping", "mass"];
    function p(e, t) {
      return t.some((t) => void 0 !== e[t]);
    }
    function f() {
      let e,
        a,
        f,
        v,
        g,
        y,
        T = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0.3,
        b = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0.3,
        x = "object" != typeof T ? { visualDuration: T, keyframes: [0, 1], bounce: b } : T,
        { restSpeed: w, restDelta: A } = x,
        S = x.keyframes[0],
        V = x.keyframes[x.keyframes.length - 1],
        M = { done: !1, value: S },
        {
          stiffness: C,
          damping: k,
          mass: E,
          duration: P,
          velocity: D,
          isResolvedFromDuration: O,
        } = (function (e) {
          let r = { velocity: 0, stiffness: 100, damping: 10, mass: 1, isResolvedFromDuration: !1, ...e };
          if (!p(e, m) && p(e, d))
            if (((r.velocity = 0), e.visualDuration)) {
              let t = (2 * Math.PI) / (1.2 * e.visualDuration),
                n = t * t,
                s = 2 * (0, i.clamp)(0.05, 1, 1 - (e.bounce || 0)) * Math.sqrt(n);
              r = { ...r, mass: 1, stiffness: n, damping: s };
            } else {
              let s = (function (e) {
                let r,
                  s,
                  { duration: a = 800, bounce: o = 0.3, velocity: l = 0, mass: u = 1 } = e;
                (0, n.warning)(
                  a <= (0, t.secondsToMilliseconds)(10),
                  "Spring duration must be 10 seconds or less",
                  "spring-duration-limit",
                );
                let h = 1 - o;
                ((h = (0, i.clamp)(0.05, 1, h)),
                  (a = (0, i.clamp)(0.01, 10, (0, t.millisecondsToSeconds)(a))),
                  h < 1
                    ? ((r = (e) => {
                        let t = e * h,
                          i = t * a;
                        return 0.001 - ((t - l) / c(e, h)) * Math.exp(-i);
                      }),
                      (s = (e) => {
                        let t = e * h * a,
                          i = Math.pow(h, 2) * Math.pow(e, 2) * a,
                          n = Math.exp(-t),
                          s = c(Math.pow(e, 2), h);
                        return ((t * l + l - i) * n * (-r(e) + 0.001 > 0 ? -1 : 1)) / s;
                      }))
                    : ((r = (e) => -0.001 + Math.exp(-e * a) * ((e - l) * a + 1)),
                      (s = (e) => a * a * (l - e) * Math.exp(-e * a))));
                let d = (function (e, t, i) {
                  let n = i;
                  for (let i = 1; i < 12; i++) n -= e(n) / t(n);
                  return n;
                })(r, s, 5 / a);
                if (((a = (0, t.secondsToMilliseconds)(a)), isNaN(d)))
                  return { stiffness: 100, damping: 10, duration: a };
                {
                  let e = Math.pow(d, 2) * u;
                  return { stiffness: e, damping: 2 * h * Math.sqrt(u * e), duration: a };
                }
              })({ ...e, velocity: 0 });
              (r = { ...r, ...s, mass: 1 }).isResolvedFromDuration = !0;
            }
          return r;
        })({ ...x, velocity: -(0, t.millisecondsToSeconds)(x.velocity || 0) }),
        I = D || 0,
        F = k / (2 * Math.sqrt(C * E)),
        L = V - S,
        B = (0, t.millisecondsToSeconds)(Math.sqrt(C / E)),
        G = 5 > Math.abs(L);
      if ((w || (w = G ? o : l), A || (A = G ? u : h), F < 1))
        ((f = c(B, F)),
          (v = (I + F * B * L) / f),
          (e = (e) => V - Math.exp(-F * B * e) * (v * Math.sin(f * e) + L * Math.cos(f * e))),
          (g = F * B * v + L * f),
          (y = F * B * L - v * f),
          (a = (e) => Math.exp(-F * B * e) * (g * Math.sin(f * e) + y * Math.cos(f * e))));
      else if (1 === F) {
        e = (e) => V - Math.exp(-B * e) * (L + (I + B * L) * e);
        let t = I + B * L;
        a = (e) => Math.exp(-B * e) * (B * t * e - I);
      } else {
        let t = B * Math.sqrt(F * F - 1);
        e = (e) => {
          let i = Math.exp(-F * B * e),
            n = Math.min(t * e, 300);
          return V - (i * ((I + F * B * L) * Math.sinh(n) + t * L * Math.cosh(n))) / t;
        };
        let i = (I + F * B * L) / t,
          n = F * B * i - L * t,
          r = F * B * L - i * t;
        a = (e) => {
          let i = Math.exp(-F * B * e),
            s = Math.min(t * e, 300);
          return i * (n * Math.sinh(s) + r * Math.cosh(s));
        };
      }
      let K = {
        calculatedDuration: (O && P) || null,
        velocity: (e) => (0, t.secondsToMilliseconds)(a(e)),
        next: (i) => {
          if (!O && F < 1) {
            let e = Math.exp(-F * B * i),
              n = Math.sin(f * i),
              r = Math.cos(f * i),
              s = V - e * (v * n + L * r);
            return (
              (M.done =
                Math.abs((0, t.secondsToMilliseconds)(e * (g * n + y * r))) <= w && Math.abs(V - s) <= A),
              (M.value = M.done ? V : s),
              M
            );
          }
          let n = e(i);
          return (
            O
              ? (M.done = i >= P)
              : (M.done = Math.abs((0, t.secondsToMilliseconds)(a(i))) <= w && Math.abs(V - n) <= A),
            (M.value = M.done ? V : n),
            M
          );
        },
        toString: () => {
          let e = Math.min(s(K), 2e4),
            t = (0, r.generateLinearEasing)((t) => K.next(e * t).value, e, 30);
          return e + "ms " + t;
        },
        toTransition: () => {},
      };
      return K;
    }
    ((f.applyToOptions = (e) => {
      let i = a(e, 100, f);
      return (
        (e.ease = i.ease),
        (e.duration = (0, t.secondsToMilliseconds)(i.duration)),
        (e.type = "keyframes"),
        e
      );
    }),
      e.s(["spring", 0, f], 528409));
  },
  939011,
  784784,
  779868,
  (e) => {
    "use strict";
    var t = e.i(763074),
      i = e.i(846791),
      n = e.i(42062),
      r = e.i(83352),
      s = e.i(987333),
      a = e.i(343116),
      o = e.i(157788);
    let l = { type: "spring", stiffness: 500, damping: 25, restSpeed: 10 },
      u = { type: "keyframes", duration: 0.8 },
      h = { type: "keyframes", ease: [0.25, 0.1, 0.35, 1], duration: 0.3 },
      c = (e, t) => {
        let { keyframes: i } = t;
        return i.length > 2
          ? u
          : o.transformProps.has(e)
            ? e.startsWith("scale")
              ? {
                  type: "spring",
                  stiffness: 550,
                  damping: 0 === i[1] ? 2 * Math.sqrt(550) : 30,
                  restSpeed: 10,
                }
              : l
            : h;
      };
    e.s(["getDefaultTransition", 0, c], 784784);
    var d = e.i(414229);
    let m = new Set([
      "when",
      "delay",
      "delayChildren",
      "staggerChildren",
      "staggerDirection",
      "repeat",
      "repeatType",
      "repeatDelay",
      "from",
      "elapsed",
    ]);
    function p(e) {
      for (let t in e) if (!m.has(t)) return !0;
      return !1;
    }
    e.s(["isTransitionDefined", 0, p], 779868);
    var f = e.i(287022);
    e.s(
      [
        "animateMotionValue",
        0,
        function (e, o, l) {
          let u = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {},
            h = arguments.length > 4 ? arguments[4] : void 0,
            m = arguments.length > 5 ? arguments[5] : void 0;
          return (v) => {
            let g = (0, s.getValueTransition)(u, e) || {},
              y = g.delay || u.delay || 0,
              { elapsed: T = 0 } = u;
            T -= (0, t.secondsToMilliseconds)(y);
            let b = {
              keyframes: Array.isArray(l) ? l : [null, l],
              ease: "easeOut",
              velocity: o.getVelocity(),
              ...g,
              delay: -T,
              onUpdate: (e) => {
                (o.set(e), g.onUpdate && g.onUpdate(e));
              },
              onComplete: () => {
                (v(), g.onComplete && g.onComplete());
              },
              name: e,
              motionValue: o,
              element: m ? void 0 : h,
            };
            (p(g) || Object.assign(b, c(e, b)),
              b.duration && (b.duration = (0, t.secondsToMilliseconds)(b.duration)),
              b.repeatDelay && (b.repeatDelay = (0, t.secondsToMilliseconds)(b.repeatDelay)),
              void 0 !== b.from && (b.keyframes[0] = b.from));
            let x = !1;
            if (
              ((!1 !== b.type && (0 !== b.duration || b.repeatDelay)) ||
                ((0, a.makeAnimationInstant)(b), 0 === b.delay && (x = !0)),
              (i.MotionGlobalConfig.instantAnimations ||
                i.MotionGlobalConfig.skipAnimations ||
                h?.shouldSkipAnimations ||
                g.skipAnimations) &&
                ((x = !0), (0, a.makeAnimationInstant)(b), (b.delay = 0)),
              (b.allowFlatten = !g.type && !g.ease),
              x && !m && void 0 !== o.get())
            ) {
              let e = (0, d.getFinalKeyframe)(b.keyframes, g);
              if (void 0 !== e)
                return void f.frame.update(() => {
                  (b.onUpdate(e), b.onComplete());
                });
            }
            return g.isSync ? new r.JSAnimation(b) : new n.AsyncMotionValueAnimation(b);
          };
        },
      ],
      939011,
    );
  },
  372323,
  (e) => {
    "use strict";
    var t = e.i(987333),
      i = e.i(753034),
      n = e.i(864440),
      r = e.i(347834),
      s = e.i(980538),
      a = e.i(716896),
      o = e.i(939011),
      l = e.i(287022);
    e.s([
      "animateTarget",
      0,
      function (e, u) {
        let {
            delay: h = 0,
            transitionOverride: c,
            type: d,
          } = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
          { transition: m, transitionEnd: p, ...f } = u,
          v = e.getDefaultTransition();
        m = m ? (0, i.resolveTransition)(m, v) : v;
        let g = m?.reduceMotion,
          y = m?.skipAnimations;
        c && (m = c);
        let T = [],
          b = d && e.animationState && e.animationState.getState()[d],
          x = m?.path;
        for (let i in (x && x.animateVisualElement(e, f, m, h, T), f)) {
          let r = e.getValue(i, e.latestValues[i] ?? null),
            u = f[i];
          if (
            void 0 === u ||
            (b &&
              (function (e, t) {
                let { protectedKeys: i, needsAnimating: n } = e,
                  r = i.hasOwnProperty(t) && !0 !== n[t];
                return ((n[t] = !1), r);
              })(b, i))
          )
            continue;
          let c = { delay: h, ...(0, t.getValueTransition)(m || {}, i) };
          y && (c.skipAnimations = !0);
          let d = r.get();
          if (void 0 !== d && !r.isAnimating() && !Array.isArray(u) && u === d && !c.velocity) {
            l.frame.update(() => r.set(u));
            continue;
          }
          let p = !1;
          if (window.MotionHandoffAnimation) {
            let t = (0, a.getOptimisedAppearId)(e);
            if (t) {
              let e = window.MotionHandoffAnimation(t, i, l.frame);
              null !== e && ((c.startTime = e), (p = !0));
            }
          }
          (0, s.addValueToWillChange)(e, i);
          let v = g ?? e.shouldReduceMotion;
          r.start((0, o.animateMotionValue)(i, r, u, v && n.positionalKeys.has(i) ? { type: !1 } : c, e, p));
          let x = r.animation;
          x && T.push(x);
        }
        if (p) {
          let t = () =>
            l.frame.update(() => {
              p && (0, r.setTarget)(e, p);
            });
          T.length ? Promise.all(T).then(t) : t();
        }
        return T;
      },
    ]);
  },
  515923,
  215932,
  (e) => {
    "use strict";
    var t = e.i(783920),
      i = e.i(100706);
    function n(e, n) {
      let r = e[e.length - 1];
      for (let s = 1; s <= n; s++) {
        let a = (0, t.progress)(0, n, s);
        e.push((0, i.mixNumber)(r, 1, a));
      }
    }
    (e.s(["fillOffset", 0, n], 215932),
      e.s(
        [
          "defaultOffset",
          0,
          function (e) {
            let t = [0];
            return (n(t, e.length - 1), t);
          },
        ],
        515923,
      ));
  },
  987333,
  (e) => {
    "use strict";
    var t = e.i(753034);
    e.s([
      "getValueTransition",
      0,
      function (e, i) {
        let n = e?.[i] ?? e?.default ?? e;
        return n !== e ? (0, t.resolveTransition)(n, e) : n;
      },
    ]);
  },
  753034,
  (e) => {
    "use strict";
    e.s([
      "resolveTransition",
      0,
      function (e, t) {
        if (e?.inherit && t) {
          let { inherit: i, ...n } = e;
          return { ...t, ...n };
        }
        return e;
      },
    ]);
  },
  282774,
  (e) => {
    "use strict";
    e.s([
      "addDomEvent",
      0,
      function (e, t, i) {
        let n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : { passive: !0 };
        return (e.addEventListener(t, i, n), () => e.removeEventListener(t, i, n));
      },
    ]);
  },
  439676,
  (e) => {
    "use strict";
    let t = { x: !1, y: !1 };
    e.s([
      "isDragActive",
      0,
      function () {
        return t.x || t.y;
      },
      "isDragging",
      0,
      t,
    ]);
  },
  608648,
  973089,
  (e) => {
    "use strict";
    var t = e.i(439676),
      i = e.i(749652);
    function n(e, t) {
      let n = (0, i.resolveElements)(e),
        r = new AbortController();
      return [n, { passive: !0, ...t, signal: r.signal }, () => r.abort()];
    }
    (e.s(["setupGesture", 0, n], 973089),
      e.s(
        [
          "hover",
          0,
          function (e, i) {
            let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
              [s, a, o] = n(e, r);
            return (
              s.forEach((e) => {
                let n,
                  r = !1,
                  s = !1,
                  o = (t) => {
                    (n && (n(t), (n = void 0)), e.removeEventListener("pointerleave", u));
                  },
                  l = (e) => {
                    ((r = !1),
                      window.removeEventListener("pointerup", l),
                      window.removeEventListener("pointercancel", l),
                      s && ((s = !1), o(e)));
                  },
                  u = (e) => {
                    if ("touch" !== e.pointerType) {
                      if (r) {
                        s = !0;
                        return;
                      }
                      o(e);
                    }
                  };
                (e.addEventListener(
                  "pointerenter",
                  (r) => {
                    if ("touch" === r.pointerType || (0, t.isDragActive)()) return;
                    s = !1;
                    let o = i(e, r);
                    "function" == typeof o && ((n = o), e.addEventListener("pointerleave", u, a));
                  },
                  a,
                ),
                  e.addEventListener(
                    "pointerdown",
                    () => {
                      ((r = !0),
                        window.addEventListener("pointerup", l, a),
                        window.addEventListener("pointercancel", l, a));
                    },
                    a,
                  ));
              }),
              o
            );
          },
        ],
        608648,
      ));
  },
  919880,
  (e) => {
    "use strict";
    let t = new Set(["BUTTON", "INPUT", "SELECT", "TEXTAREA", "A"]),
      i = new Set(["INPUT", "SELECT", "TEXTAREA"]);
    e.s([
      "isElementKeyboardAccessible",
      0,
      function (e) {
        return t.has(e.tagName) || !0 === e.isContentEditable;
      },
      "isElementTextInput",
      0,
      function (e) {
        return i.has(e.tagName) || !0 === e.isContentEditable;
      },
    ]);
  },
  142098,
  (e) => {
    "use strict";
    e.s([
      "Feature",
      0,
      class {
        constructor(e) {
          ((this.isMounted = !1), (this.node = e));
        }
        update() {}
      },
    ]);
  },
  864440,
  (e) => {
    "use strict";
    let t = new Set(["width", "height", "top", "left", "right", "bottom", ...e.i(157788).transformPropOrder]);
    e.s(["positionalKeys", 0, t]);
  },
  618812,
  (e) => {
    "use strict";
    var t = e.i(386579);
    e.s([
      "resolveVariant",
      0,
      function (e, i, n) {
        let r = e.getProps();
        return (0, t.resolveVariantFromProps)(r, i, void 0 !== n ? n : r.custom, e);
      },
    ]);
  },
  347834,
  373615,
  233421,
  980538,
  716896,
  (e) => {
    "use strict";
    var t = e.i(486427),
      i = e.i(618812);
    let n = (e) => Array.isArray(e);
    (e.s(["isKeyframesTarget", 0, n], 373615),
      e.s(
        [
          "setTarget",
          0,
          function (e, r) {
            let { transitionEnd: s = {}, transition: a = {}, ...o } = (0, i.resolveVariant)(e, r) || {};
            for (let i in (o = { ...o, ...s })) {
              var l;
              let r = n((l = o[i])) ? l[l.length - 1] || 0 : l;
              e.hasValue(i) ? e.getValue(i).set(r) : e.addValue(i, (0, t.motionValue)(r));
            }
          },
        ],
        347834,
      ));
    var r = e.i(846791),
      s = e.i(83411);
    function a(e) {
      return !!((0, s.isMotionValue)(e) && e.add);
    }
    (e.s(["isWillChangeMotionValue", 0, a], 233421),
      e.s(
        [
          "addValueToWillChange",
          0,
          function (e, t) {
            let i = e.getValue("willChange");
            if (a(i)) return i.add(t);
            if (!i && r.MotionGlobalConfig.WillChange) {
              let i = new r.MotionGlobalConfig.WillChange("auto");
              (e.addValue("willChange", i), i.add(t));
            }
          },
        ],
        980538,
      ));
    var o = e.i(535043);
    e.s(
      [
        "getOptimisedAppearId",
        0,
        function (e) {
          return e.props[o.optimizedAppearDataAttribute];
        },
      ],
      716896,
    );
  },
  344230,
  (e) => {
    "use strict";
    var t = e.i(965566),
      i = e.i(476959),
      n = e.i(846791),
      r = e.i(260830),
      s = e.i(738638),
      a = e.i(783920),
      o = e.i(203163);
    e.s([
      "interpolate",
      0,
      function (e, l) {
        let {
            clamp: u = !0,
            ease: h,
            mixer: c,
          } = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
          d = e.length;
        if (
          ((0, t.invariant)(
            d === l.length,
            "Both input and output ranges must be the same length",
            "range-length",
          ),
          1 === d)
        )
          return () => l[0];
        if (2 === d && l[0] === l[1]) return () => l[1];
        let m = e[0] === e[1];
        e[0] > e[d - 1] && ((e = [...e].reverse()), (l = [...l].reverse()));
        let p = (function (e, t, i) {
            let a = [],
              l = i || n.MotionGlobalConfig.mix || o.mix,
              u = e.length - 1;
            for (let i = 0; i < u; i++) {
              let n = l(e[i], e[i + 1]);
              if (t) {
                let e = Array.isArray(t) ? t[i] || r.noop : t;
                n = (0, s.pipe)(e, n);
              }
              a.push(n);
            }
            return a;
          })(l, h, c),
          f = p.length,
          v = (t) => {
            if (m && t < e[0]) return l[0];
            let i = 0;
            if (f > 1) for (; i < e.length - 2 && !(t < e[i + 1]); i++);
            let n = (0, a.progress)(e[i], e[i + 1], t);
            return p[i](n);
          };
        return u ? (t) => v((0, i.clamp)(e[0], e[d - 1], t)) : v;
      },
    ]);
  },
  570165,
  (e) => {
    "use strict";
    e.s(["mirrorEasing", 0, (e) => (t) => (t <= 0.5 ? e(2 * t) / 2 : (2 - e(2 * (1 - t))) / 2)]);
  },
  430151,
  (e) => {
    "use strict";
    e.s(["reverseEasing", 0, (e) => (t) => 1 - e(1 - t)]);
  },
  893544,
  (e) => {
    "use strict";
    e.s(["isEasingArray", 0, (e) => Array.isArray(e) && "number" != typeof e[0]]);
  },
  532943,
  641980,
  878047,
  791559,
  (e) => {
    "use strict";
    var t = e.i(965566),
      i = e.i(260830),
      n = e.i(440254),
      r = e.i(570165),
      s = e.i(430151);
    let a = (0, n.cubicBezier)(0.33, 1.53, 0.69, 0.99),
      o = (0, s.reverseEasing)(a),
      l = (0, r.mirrorEasing)(o);
    e.s(["backIn", 0, o, "backInOut", 0, l, "backOut", 0, a], 641980);
    let u = (e) => (e >= 1 ? 1 : (e *= 2) < 1 ? 0.5 * o(e) : 0.5 * (2 - Math.pow(2, -10 * (e - 1))));
    e.s(["anticipate", 0, u], 878047);
    let h = (e) => 1 - Math.sin(Math.acos(e)),
      c = (0, s.reverseEasing)(h),
      d = (0, r.mirrorEasing)(h);
    e.s(["circIn", 0, h, "circInOut", 0, d, "circOut", 0, c], 791559);
    var m = e.i(437025),
      p = e.i(960855);
    let f = {
      linear: i.noop,
      easeIn: m.easeIn,
      easeInOut: m.easeInOut,
      easeOut: m.easeOut,
      circIn: h,
      circInOut: d,
      circOut: c,
      backIn: o,
      backInOut: l,
      backOut: a,
      anticipate: u,
    };
    e.s(
      [
        "easingDefinitionToFunction",
        0,
        (e) => {
          if ((0, p.isBezierDefinition)(e)) {
            (0, t.invariant)(
              4 === e.length,
              "Cubic bezier arrays must contain four numerical values.",
              "cubic-bezier-length",
            );
            let [i, r, s, a] = e;
            return (0, n.cubicBezier)(i, r, s, a);
          }
          return "string" == typeof e
            ? ((0, t.invariant)(void 0 !== f[e], `Invalid easing type '${e}'`, "invalid-easing-type"), f[e])
            : e;
        },
      ],
      532943,
    );
  },
  738638,
  648393,
  308618,
  870258,
  833002,
  619568,
  203163,
  769308,
  (e) => {
    "use strict";
    let t = function () {
      for (var e = arguments.length, t = Array(e), i = 0; i < e; i++) t[i] = arguments[i];
      return t.reduce((e, t) => (i) => t(e(i)));
    };
    e.s(["pipe", 0, t], 738638);
    var i = e.i(965566),
      n = e.i(19928),
      r = e.i(279444),
      s = e.i(569577),
      a = e.i(463011),
      o = e.i(22660);
    function l(e, t, i) {
      return (i < 0 && (i += 1), i > 1 && (i -= 1), i < 1 / 6)
        ? e + (t - e) * 6 * i
        : i < 0.5
          ? t
          : i < 2 / 3
            ? e + (t - e) * (2 / 3 - i) * 6
            : e;
    }
    function u(e) {
      let { hue: t, saturation: i, lightness: n, alpha: r } = e;
      ((t /= 360), (n /= 100));
      let s = 0,
        a = 0,
        o = 0;
      if ((i /= 100)) {
        let e = n < 0.5 ? n * (1 + i) : n + i - n * i,
          r = 2 * n - e;
        ((s = l(r, e, t + 1 / 3)), (a = l(r, e, t)), (o = l(r, e, t - 1 / 3)));
      } else s = a = o = n;
      return { red: Math.round(255 * s), green: Math.round(255 * a), blue: Math.round(255 * o), alpha: r };
    }
    e.s(["hslaToRgba", 0, u], 648393);
    var h = e.i(766820);
    function c(e, t) {
      return (i) => (i > 0 ? t : e);
    }
    e.s(["mixImmediate", 0, c], 308618);
    var d = e.i(100706);
    let m = (e, t, i) => {
        let n = e * e,
          r = i * (t * t - n) + n;
        return r < 0 ? 0 : Math.sqrt(r);
      },
      p = [a.hex, h.rgba, o.hsla];
    function f(e) {
      let t = p.find((t) => t.test(e));
      if (
        ((0, i.warning)(
          !!t,
          `'${e}' is not an animatable color. Use the equivalent color code instead.`,
          "color-not-animatable",
        ),
        !t)
      )
        return !1;
      let n = t.parse(e);
      return (t === o.hsla && (n = u(n)), n);
    }
    let v = (e, t) => {
      let i = f(e),
        n = f(t);
      if (!i || !n) return c(e, t);
      let r = { ...i };
      return (e) => (
        (r.red = m(i.red, n.red, e)),
        (r.green = m(i.green, n.green, e)),
        (r.blue = m(i.blue, n.blue, e)),
        (r.alpha = (0, d.mixNumber)(i.alpha, n.alpha, e)),
        h.rgba.transform(r)
      );
    };
    e.s(["mixColor", 0, v, "mixLinearColor", 0, m], 870258);
    let g = new Set(["none", "hidden"]);
    function y(e, t) {
      return g.has(e) ? (i) => (i <= 0 ? e : t) : (i) => (i >= 1 ? t : e);
    }
    function T(e, t) {
      return (i) => (0, d.mixNumber)(e, t, i);
    }
    function b(e) {
      return "number" == typeof e
        ? T
        : "string" == typeof e
          ? (0, n.isCSSVariableToken)(e)
            ? c
            : r.color.test(e)
              ? v
              : A
          : Array.isArray(e)
            ? x
            : "object" == typeof e
              ? r.color.test(e)
                ? v
                : w
              : c;
    }
    function x(e, t) {
      let i = [...e],
        n = i.length,
        r = e.map((e, i) => b(e)(e, t[i]));
      return (e) => {
        for (let t = 0; t < n; t++) i[t] = r[t](e);
        return i;
      };
    }
    function w(e, t) {
      let i = { ...e, ...t },
        n = {};
      for (let r in i) void 0 !== e[r] && void 0 !== t[r] && (n[r] = b(e[r])(e[r], t[r]));
      return (e) => {
        for (let t in n) i[t] = n[t](e);
        return i;
      };
    }
    e.s(["invisibleValues", 0, g, "mixVisibility", 0, y], 833002);
    let A = (e, n) => {
      let r = s.complex.createTransformer(n),
        a = (0, s.analyseComplexValue)(e),
        o = (0, s.analyseComplexValue)(n);
      return a.indexes.var.length === o.indexes.var.length &&
        a.indexes.color.length === o.indexes.color.length &&
        a.indexes.number.length >= o.indexes.number.length
        ? (g.has(e) && !o.values.length) || (g.has(n) && !a.values.length)
          ? y(e, n)
          : t(
              x(
                (function (e, t) {
                  let i = [],
                    n = { color: 0, var: 0, number: 0 };
                  for (let r = 0; r < t.values.length; r++) {
                    let s = t.types[r],
                      a = e.indexes[s][n[s]],
                      o = e.values[a] ?? 0;
                    ((i[r] = o), n[s]++);
                  }
                  return i;
                })(a, o),
                o.values,
              ),
              r,
            )
        : ((0, i.warning)(
            !0,
            `Complex values '${e}' and '${n}' too different to mix. Ensure all colors are of the same type, and that each contains the same quantity of number and color values. Falling back to instant transition.`,
            "complex-values-different",
          ),
          c(e, n));
    };
    (e.s(["getMixer", 0, b, "mixArray", 0, x, "mixComplex", 0, A, "mixObject", 0, w], 619568),
      e.s(
        [
          "mix",
          0,
          function (e, t, i) {
            return "number" == typeof e && "number" == typeof t && "number" == typeof i
              ? (0, d.mixNumber)(e, t, i)
              : b(e)(e, t);
          },
        ],
        203163,
      ));
    var S = e.i(496173),
      V = e.i(287022);
    e.s(
      [
        "frameloopDriver",
        0,
        (e) => {
          let t = (t) => {
            let { timestamp: i } = t;
            return e(i);
          };
          return {
            start: function () {
              let e = !(arguments.length > 0) || void 0 === arguments[0] || arguments[0];
              return V.frame.update(t, e);
            },
            stop: () => (0, V.cancelFrame)(t),
            now: () => (V.frameData.isProcessing ? V.frameData.timestamp : S.time.now()),
          };
        },
      ],
      769308,
    );
  },
  783920,
  (e) => {
    "use strict";
    e.s([
      "progress",
      0,
      (e, t, i) => {
        let n = t - e;
        return n ? (i - e) / n : 1;
      },
    ]);
  },
]);
