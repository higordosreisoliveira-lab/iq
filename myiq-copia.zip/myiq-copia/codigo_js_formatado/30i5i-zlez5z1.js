(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  882983,
  (e) => {
    "use strict";
    var t = e.i(265840),
      i = e.i(271645),
      a = e.i(273830),
      s = e.i(620253),
      l = e.i(75540),
      n = e.i(843476),
      r = (0, a.forwardRef)((e, a) => {
        let { as: r, children: o, className: c, ...d } = e,
          { slots: u, classNames: p, bodyId: _, setBodyMounted: m } = (0, t.useModalContext)(),
          f = (0, s.useDOMRef)(a);
        return (
          (0, i.useEffect)(() => (m(!0), () => m(!1)), [m]),
          (0, n.jsx)(r || "div", {
            ref: f,
            className: u.body({ class: (0, l.clsx)(null == p ? void 0 : p.body, c) }),
            id: _,
            ...d,
            children: o,
          })
        );
      });
    ((r.displayName = "HeroUI.ModalBody"), e.s(["ModalBody", 0, r], 882983));
  },
  678745,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("check", [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]]);
    e.s(["default", 0, t]);
  },
  661166,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("link", [
      ["path", { d: "M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71", key: "1cjeqo" }],
      ["path", { d: "M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71", key: "19qd67" }],
    ]);
    e.s(["LinkIcon", 0, t], 661166);
  },
  841977,
  (e) => {
    "use strict";
    e.s([
      "BONUS_POINTS",
      0,
      { under_ten: 5, under_seven: 7, under_five: 10 },
      "CORRECT_ANSWER_MIN_COUNT",
      0,
      15,
      "EASY_QUESTION_POINTS",
      0,
      0.87,
      "FIVE_MINUTES",
      0,
      300,
      "FOUR_MINUTES",
      0,
      240,
      "HARD_QUESTION_POINTS",
      0,
      1.12,
      "MINIMAL_IQ_SCORE",
      0,
      105,
      "MINUTE_SECONDS",
      0,
      60,
      "SEVEN_MINUTES",
      0,
      420,
      "TEN_MINUTES",
      0,
      600,
      "WARNING_THRESHOLD",
      0,
      10,
    ]);
  },
  107440,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(678745),
      i = i,
      a = e.i(661166),
      s = e.i(948148),
      l = e.i(271645),
      n = e.i(663615);
    e.i(317197);
    var r = e.i(231529),
      o = e.i(523173),
      c = e.i(134404),
      d = e.i(4945),
      u = e.i(622963),
      p = e.i(86596);
    e.i(568267);
    var _ = e.i(154692);
    e.i(756503);
    var m = e.i(542516);
    e.i(470366);
    var f = e.i(504001);
    (e.s([], 463372),
      e.i(463372),
      e.s(
        [
          "InAppBrowserDetectedModalComponent",
          0,
          (e) => {
            let { downloadType: y, shareUrl: N, inAppBrowserName: C } = e,
              h = (0, s.useTranslations)(),
              [x, E] = (0, l.useState)(!1),
              I = (0, l.useRef)(null),
              S = (0, p.useUserStore)((e) => e.user);
            ((0, l.useEffect)(() => {
              (0, f.trackClientEvents)({
                event: o.EAnalyticEvents.IN_APP_BROWSER_MODAL_VIEWED,
                user: S,
                params: { download_type: y || "share", in_app_browser: C || "unknown" },
              });
            }, []),
              (0, l.useEffect)(
                () => () => {
                  I.current && clearTimeout(I.current);
                },
                [],
              ));
            let b = (0, u.useModalStore)((e) => e.handleChangeModalStore),
              M = async () => {
                try {
                  let e = S?.mainFunnel || S?.funnel || "myiq",
                    t = `${m.envClient.NEXT_PUBLIC_APP_URL}${c.EClientRoutes.CERTIFICATE}?i=${(0, d.encodeCertificatedUser)({ email: S?.email, username: S?.username, iq_score: S?.results?.userScore?.toString() || null, funnel: e, love_language_type_result: S?.love_language_type_result, personality_type_result: S?.personality_type_result, certificate_id: S?.certificate_id_myiq || S?.test_result?.[e]?.certificate_id })}`;
                  (await navigator.clipboard.writeText(N || t),
                    E(!0),
                    (I.current = setTimeout(() => E(!1), 2e3)));
                } catch {}
              };
            return (0, t.jsx)(r.ModalBodyComponent, {
              title: h("in_app_browser_modal_title"),
              titleClassName: "px-4 text-balance",
              subtitle: h(
                N
                  ? "in_app_browser_modal_subtitle_share"
                  : "certificate" === y
                    ? "in_app_browser_modal_subtitle_certificate"
                    : "in_app_browser_modal_subtitle_report",
              ),
              children: (0, t.jsxs)("div", {
                className: "flex flex-col gap-3",
                children: [
                  (0, t.jsx)(_.ButtonComponent, {
                    size: "sm",
                    fullWidth: !0,
                    onClick: M,
                    startContent: (0, t.jsxs)("span", {
                      className:
                        "relative inline-flex h-[18px] w-[18px] shrink-0 items-center justify-center",
                      children: [
                        (0, t.jsx)(a.LinkIcon, {
                          size: 18,
                          className: (0, n.cn)(
                            "absolute scale-100 opacity-100 transition-transform-opacity",
                            x && "scale-50 opacity-0",
                          ),
                        }),
                        (0, t.jsx)(i.default, {
                          size: 18,
                          className: (0, n.cn)(
                            "absolute scale-50 opacity-0 transition-transform-opacity",
                            x && "scale-100 opacity-100",
                          ),
                        }),
                      ],
                    }),
                    children: (0, t.jsxs)("span", {
                      className: "grid",
                      children: [
                        (0, t.jsx)("span", {
                          className: (0, n.cn)(
                            "col-start-1 row-start-1 transition-opacity",
                            x ? "opacity-0" : "opacity-100",
                          ),
                          children: h("btn_copy_link"),
                        }),
                        (0, t.jsx)("span", {
                          className: (0, n.cn)(
                            "col-start-1 row-start-1 transition-opacity",
                            x ? "opacity-100" : "opacity-0",
                          ),
                          children: h("btn_copied"),
                        }),
                      ],
                    }),
                  }),
                  (0, t.jsx)(_.ButtonComponent, {
                    variant: "bordered",
                    size: "sm",
                    fullWidth: !0,
                    onClick: () => {
                      b({ isModalVisible: !1, modalComponent: null });
                    },
                    children: h("btn_got_it"),
                  }),
                ],
              }),
            });
          },
        ],
        107440,
      ));
  },
  556098,
  function (e) {
    e.n(e.i(107440));
  },
  317197,
  231529,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(882983),
      a = e.i(742214),
      s = e.i(663615);
    e.i(680460);
    var l = e.i(885944);
    (e.s([], 317197),
      e.s(
        [
          "ModalBodyComponent",
          0,
          (e) => {
            let {
              children: n,
              title: r,
              subtitle: o,
              className: c = "",
              bodyClassName: d,
              titleClassName: u,
            } = e;
            return (0, t.jsx)(a.ModalContent, {
              className: c,
              children: (0, t.jsxs)(i.ModalBody, {
                className: (0, s.cn)(
                  "flex h-full w-full flex-col gap-5 p-5 antialiased md:p-6 [@media(max-height:580px)]:gap-3 [@media(max-height:580px)]:p-4",
                  d,
                ),
                children: [
                  (r || o) &&
                    (0, t.jsx)(l.ModalHeaderComponent, { title: r, subtitle: o, titleClassName: u }),
                  n,
                ],
              }),
            });
          },
        ],
        231529,
      ));
  },
  4945,
  (e) => {
    "use strict";
    (e.i(841977),
      e.s([
        "encodeCertificatedUser",
        0,
        (e) =>
          encodeURIComponent(
            btoa(
              encodeURIComponent(JSON.stringify(e)).replace(/%([0-9A-F]{2})/g, (e, t) =>
                String.fromCharCode(parseInt(t, 16)),
              ),
            ),
          ),
      ]));
  },
]);
