(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  42879,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(948148);
    e.i(80460);
    var n = e.i(998198);
    e.i(118046);
    var a = e.i(112015);
    e.i(473189);
    var r = e.i(823933);
    e.s([
      "default",
      0,
      (e) => {
        let { user: c, selectedPlan: o } = e,
          l = (0, i.useTranslations)(),
          s = (0, r.getPlanPickerConfig)(o) ?? a.PLAN_PICKER_CONFIG[0],
          P = (e) =>
            (0, n.getCalculatePriceForView)(
              (0, n.getPaymentPlanPrice)({ paymentPlan: e, user: c }).priceForView,
              c,
            ),
          m = c?.paymentInfo?.paynextAmountToPay || P(s.trialPriceKey),
          u = c?.paymentInfo?.paynextAmountMonth || P(s.renewalPriceKey);
        return (0, t.jsx)("p", {
          className: "mt-4 text-center text-sm text-zinc-700 sm:text-[13px]",
          children: l(s.disclaimerKey, { due: m, recurring: u }),
        });
      },
    ]);
  },
  373432,
  function (e) {
    e.n(e.i(42879));
  },
]);
