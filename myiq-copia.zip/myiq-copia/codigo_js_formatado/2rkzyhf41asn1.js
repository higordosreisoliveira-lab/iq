(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  733986,
  661327,
  61175,
  583662,
  485651,
  107230,
  877397,
  (t) => {
    "use strict";
    let e, i;
    var s = t.i(142098),
      o = t.i(260830),
      n = t.i(130162),
      r = t.i(287022),
      a = t.i(655559),
      l = t.i(153689),
      h = t.i(27677),
      u = t.i(980538),
      c = t.i(939011),
      d = t.i(100706),
      m = t.i(282774),
      p = t.i(137541),
      g = t.i(265091),
      v = t.i(652101),
      y = t.i(889026),
      f = t.i(749652);
    let x = new WeakMap(),
      P = (t, e, i) => (s, o) =>
        o && o[0] ? o[0][t + "Size"] : (0, y.isSVGElement)(s) && "getBBox" in s ? s.getBBox()[e] : s[i],
      D = P("inline", "width", "offsetWidth"),
      T = P("block", "height", "offsetHeight");
    function E(t) {
      let { target: e, borderBoxSize: i } = t;
      x.get(e)?.forEach((t) => {
        t(e, {
          get width() {
            return D(e, i);
          },
          get height() {
            return T(e, i);
          },
        });
      });
    }
    function S(t) {
      t.forEach(E);
    }
    let w = new Set();
    function A(t, s) {
      let o;
      return "function" == typeof t
        ? (w.add(t),
          i ||
            ((i = () => {
              let t = {
                get width() {
                  return window.innerWidth;
                },
                get height() {
                  return window.innerHeight;
                },
              };
              w.forEach((e) => e(t));
            }),
            window.addEventListener("resize", i)),
          () => {
            (w.delete(t),
              w.size || "function" != typeof i || (window.removeEventListener("resize", i), (i = void 0)));
          })
        : (!e && "u" > typeof ResizeObserver && (e = new ResizeObserver(S)),
          (o = (0, f.resolveElements)(t)).forEach((t) => {
            let i = x.get(t);
            (i || ((i = new Set()), x.set(t, i)), i.add(s), e?.observe(t));
          }),
          () => {
            o.forEach((t) => {
              let i = x.get(t);
              (i?.delete(s), i?.size || e?.unobserve(t));
            });
          });
    }
    t.s(["resize", 0, A], 661327);
    var B = t.i(919880),
      R = t.i(965566),
      L = t.i(665536);
    function j(t, e, i, s) {
      return (0, m.addDomEvent)(t, e, (0, L.addPointerInfo)(i), s);
    }
    t.s(["addPointerEvent", 0, j], 61175);
    let V = (t) => {
      let { current: e } = t;
      return e ? e.ownerDocument.defaultView : null;
    };
    var M = t.i(325522),
      b = t.i(341327),
      k = t.i(738638),
      C = t.i(763074);
    let U = (t, e) => Math.abs(t - e);
    function I(t, e) {
      return Math.sqrt(U(t.x, e.x) ** 2 + U(t.y, e.y) ** 2);
    }
    t.s(["distance", 0, U, "distance2D", 0, I], 583662);
    let F = new Set(["auto", "scroll"]);
    class N {
      constructor(
        t,
        e,
        {
          transformPagePoint: i,
          contextWindow: s = window,
          dragSnapToOrigin: o = !1,
          distanceThreshold: n = 3,
          element: a,
        } = {},
      ) {
        if (
          ((this.startEvent = null),
          (this.lastMoveEvent = null),
          (this.lastMoveEventInfo = null),
          (this.lastRawMoveEventInfo = null),
          (this.handlers = {}),
          (this.contextWindow = window),
          (this.scrollPositions = new Map()),
          (this.removeScrollListeners = null),
          (this.onElementScroll = (t) => {
            this.handleScroll(t.target);
          }),
          (this.onWindowScroll = () => {
            this.handleScroll(window);
          }),
          (this.updatePoint = () => {
            if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
            this.lastRawMoveEventInfo &&
              (this.lastMoveEventInfo = O(this.lastRawMoveEventInfo, this.transformPagePoint));
            let t = W(this.lastMoveEventInfo, this.history),
              e = null !== this.startEvent,
              i = I(t.offset, { x: 0, y: 0 }) >= this.distanceThreshold;
            if (!e && !i) return;
            let { point: s } = t,
              { timestamp: o } = r.frameData;
            this.history.push({ ...s, timestamp: o });
            let { onStart: n, onMove: a } = this.handlers;
            (e || (n && n(this.lastMoveEvent, t), (this.startEvent = this.lastMoveEvent)),
              a && a(this.lastMoveEvent, t));
          }),
          (this.handlePointerMove = (t, e) => {
            ((this.lastMoveEvent = t),
              (this.lastRawMoveEventInfo = e),
              (this.lastMoveEventInfo = O(e, this.transformPagePoint)),
              r.frame.update(this.updatePoint, !0));
          }),
          (this.handlePointerUp = (t, e) => {
            this.end();
            let { onEnd: i, onSessionEnd: s, resumeAnimation: o } = this.handlers;
            if (
              ((this.dragSnapToOrigin || !this.startEvent) && o && o(),
              !(this.lastMoveEvent && this.lastMoveEventInfo))
            )
              return;
            let n = W(
              "pointercancel" === t.type ? this.lastMoveEventInfo : O(e, this.transformPagePoint),
              this.history,
            );
            (this.startEvent && i && i(t, n), s && s(t, n));
          }),
          !(0, b.isPrimaryPointer)(t))
        )
          return;
        ((this.dragSnapToOrigin = o),
          (this.handlers = e),
          (this.transformPagePoint = i),
          (this.distanceThreshold = n),
          (this.contextWindow = s || window));
        const l = O((0, L.extractEventInfo)(t), this.transformPagePoint),
          { point: h } = l,
          { timestamp: u } = r.frameData;
        this.history = [{ ...h, timestamp: u }];
        const { onSessionStart: c } = e;
        c && c(t, W(l, this.history));
        const d = { passive: !0, capture: !0 };
        ((this.removeListeners = (0, k.pipe)(
          j(this.contextWindow, "pointermove", this.handlePointerMove, d),
          j(this.contextWindow, "pointerup", this.handlePointerUp, d),
          j(this.contextWindow, "pointercancel", this.handlePointerUp, d),
        )),
          a && this.startScrollTracking(a));
      }
      startScrollTracking(t) {
        let e = t.parentElement;
        for (; e;) {
          let t = getComputedStyle(e);
          ((F.has(t.overflowX) || F.has(t.overflowY)) &&
            this.scrollPositions.set(e, { x: e.scrollLeft, y: e.scrollTop }),
            (e = e.parentElement));
        }
        (this.scrollPositions.set(window, { x: window.scrollX, y: window.scrollY }),
          window.addEventListener("scroll", this.onElementScroll, { capture: !0 }),
          window.addEventListener("scroll", this.onWindowScroll),
          (this.removeScrollListeners = () => {
            (window.removeEventListener("scroll", this.onElementScroll, { capture: !0 }),
              window.removeEventListener("scroll", this.onWindowScroll));
          }));
      }
      handleScroll(t) {
        let e = this.scrollPositions.get(t);
        if (!e) return;
        let i = t === window,
          s = i ? { x: window.scrollX, y: window.scrollY } : { x: t.scrollLeft, y: t.scrollTop },
          o = { x: s.x - e.x, y: s.y - e.y };
        (0 !== o.x || 0 !== o.y) &&
          (i
            ? this.lastMoveEventInfo &&
              ((this.lastMoveEventInfo.point.x += o.x), (this.lastMoveEventInfo.point.y += o.y))
            : this.history.length > 0 && ((this.history[0].x -= o.x), (this.history[0].y -= o.y)),
          this.scrollPositions.set(t, s),
          r.frame.update(this.updatePoint, !0));
      }
      updateHandlers(t) {
        this.handlers = t;
      }
      end() {
        (this.removeListeners && this.removeListeners(),
          this.removeScrollListeners && this.removeScrollListeners(),
          this.scrollPositions.clear(),
          (0, r.cancelFrame)(this.updatePoint));
      }
    }
    function O(t, e) {
      return e ? { point: e(t.point) } : t;
    }
    function z(t, e) {
      return { x: t.x - e.x, y: t.y - e.y };
    }
    function W(t, e) {
      let { point: i } = t;
      return {
        point: i,
        delta: z(i, G(e)),
        offset: z(i, e[0]),
        velocity: (function (t) {
          if (t.length < 2) return { x: 0, y: 0 };
          let e = t.length - 1,
            i = null,
            s = G(t);
          for (; e >= 0 && ((i = t[e]), !(s.timestamp - i.timestamp > (0, C.secondsToMilliseconds)(0.1)));)
            e--;
          if (!i) return { x: 0, y: 0 };
          i === t[0] &&
            t.length > 2 &&
            s.timestamp - i.timestamp > 2 * (0, C.secondsToMilliseconds)(0.1) &&
            (i = t[1]);
          let o = (0, C.millisecondsToSeconds)(s.timestamp - i.timestamp);
          if (0 === o) return { x: 0, y: 0 };
          let n = { x: (s.x - i.x) / o, y: (s.y - i.y) / o };
          return (n.x === 1 / 0 && (n.x = 0), n.y === 1 / 0 && (n.y = 0), n);
        })(e),
      };
    }
    function G(t) {
      return t[t.length - 1];
    }
    var $ = t.i(783920),
      H = t.i(476959);
    function X(t, e, i) {
      return {
        min: void 0 !== e ? t.min + e : void 0,
        max: void 0 !== i ? t.max + i - (t.max - t.min) : void 0,
      };
    }
    function Y(t, e) {
      let i = e.min - t.min,
        s = e.max - t.max;
      return (e.max - e.min < t.max - t.min && ([i, s] = [s, i]), { min: i, max: s });
    }
    function q(t, e, i) {
      return { min: Z(t, e), max: Z(t, i) };
    }
    function Z(t, e) {
      return "number" == typeof t ? t : t[e] || 0;
    }
    let K = new WeakMap();
    class _ {
      constructor(t) {
        ((this.openDragLock = null),
          (this.isDragging = !1),
          (this.currentDirection = null),
          (this.originPoint = { x: 0, y: 0 }),
          (this.constraints = !1),
          (this.hasMutatedConstraints = !1),
          (this.elastic = (0, n.createBox)()),
          (this.latestPointerEvent = null),
          (this.latestPanInfo = null),
          (this.visualElement = t));
      }
      start(t) {
        let { snapToCursor: e = !1, distanceThreshold: i } =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          { presenceContext: s } = this.visualElement;
        if (s && !1 === s.isPresent) return;
        let o = (t) => {
            (e && this.snapToCursor((0, L.extractEventInfo)(t).point), this.stopAnimation());
          },
          n = (t, e) => {
            let { drag: i, dragPropagation: s, onDragStart: o } = this.getProps();
            if (
              i &&
              !s &&
              (this.openDragLock && this.openDragLock(),
              (this.openDragLock = (0, p.setDragLock)(i)),
              !this.openDragLock)
            )
              return;
            ((this.latestPointerEvent = t),
              (this.latestPanInfo = e),
              (this.isDragging = !0),
              (this.currentDirection = null),
              this.resolveConstraints(),
              this.visualElement.projection &&
                ((this.visualElement.projection.isAnimationBlocked = !0),
                (this.visualElement.projection.target = void 0)),
              (0, a.eachAxis)((t) => {
                let e = this.getAxisMotionValue(t).get() || 0;
                if (g.percent.test(e)) {
                  let { projection: i } = this.visualElement;
                  if (i && i.layout) {
                    let s = i.layout.layoutBox[t];
                    s && (e = (0, v.calcLength)(s) * (parseFloat(e) / 100));
                  }
                }
                this.originPoint[t] = e;
              }),
              o && r.frame.update(() => o(t, e), !1, !0),
              (0, u.addValueToWillChange)(this.visualElement, "transform"));
            let { animationState: n } = this.visualElement;
            n && n.setActive("whileDrag", !0);
          },
          l = (t, e) => {
            ((this.latestPointerEvent = t), (this.latestPanInfo = e));
            let { dragPropagation: i, dragDirectionLock: s, onDirectionLock: o, onDrag: n } = this.getProps();
            if (!i && !this.openDragLock) return;
            let { offset: a } = e;
            if (s && null === this.currentDirection) {
              ((this.currentDirection = (function (t) {
                let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 10,
                  i = null;
                return (Math.abs(t.y) > e ? (i = "y") : Math.abs(t.x) > e && (i = "x"), i);
              })(a)),
                null !== this.currentDirection && o && o(this.currentDirection));
              return;
            }
            (this.updateAxis("x", e.point, a),
              this.updateAxis("y", e.point, a),
              this.visualElement.render(),
              n && r.frame.update(() => n(t, e), !1, !0));
          },
          h = (t, e) => {
            ((this.latestPointerEvent = t),
              (this.latestPanInfo = e),
              this.stop(t, e),
              (this.latestPointerEvent = null),
              (this.latestPanInfo = null));
          },
          c = () => {
            let { dragSnapToOrigin: t } = this.getProps();
            (t || this.constraints) && this.startAnimation({ x: 0, y: 0 });
          },
          { dragSnapToOrigin: d } = this.getProps();
        this.panSession = new N(
          t,
          { onSessionStart: o, onStart: n, onMove: l, onSessionEnd: h, resumeAnimation: c },
          {
            transformPagePoint: this.visualElement.getTransformPagePoint(),
            dragSnapToOrigin: d,
            distanceThreshold: i,
            contextWindow: V(this.visualElement),
            element: this.visualElement.current,
          },
        );
      }
      stop(t, e) {
        let i = t || this.latestPointerEvent,
          s = e || this.latestPanInfo,
          o = this.isDragging;
        if ((this.cancel(), !o || !s || !i)) return;
        let { velocity: n } = s;
        this.startAnimation(n);
        let { onDragEnd: a } = this.getProps();
        a && r.frame.postRender(() => a(i, s));
      }
      cancel() {
        this.isDragging = !1;
        let { projection: t, animationState: e } = this.visualElement;
        (t && (t.isAnimationBlocked = !1), this.endPanSession());
        let { dragPropagation: i } = this.getProps();
        (!i && this.openDragLock && (this.openDragLock(), (this.openDragLock = null)),
          e && e.setActive("whileDrag", !1));
      }
      endPanSession() {
        (this.panSession && this.panSession.end(), (this.panSession = void 0));
      }
      updateAxis(t, e, i) {
        let { drag: s } = this.getProps();
        if (!i || !Q(t, s, this.currentDirection)) return;
        let o = this.getAxisMotionValue(t),
          n = this.originPoint[t] + i[t];
        (this.constraints &&
          this.constraints[t] &&
          (n = (function (t, e, i) {
            let { min: s, max: o } = e;
            return (
              void 0 !== s && t < s
                ? (t = i ? (0, d.mixNumber)(s, t, i.min) : Math.max(t, s))
                : void 0 !== o && t > o && (t = i ? (0, d.mixNumber)(o, t, i.max) : Math.min(t, o)),
              t
            );
          })(n, this.constraints[t], this.elastic[t])),
          o.set(n));
      }
      resolveConstraints() {
        let { dragConstraints: t, dragElastic: e } = this.getProps(),
          i =
            this.visualElement.projection && !this.visualElement.projection.layout
              ? this.visualElement.projection.measure(!1)
              : this.visualElement.projection?.layout,
          s = this.constraints;
        (t && (0, M.isRefObject)(t)
          ? this.constraints || (this.constraints = this.resolveRefConstraints())
          : t && i
            ? (this.constraints = (function (t, e) {
                let { top: i, left: s, bottom: o, right: n } = e;
                return { x: X(t.x, s, n), y: X(t.y, i, o) };
              })(i.layoutBox, t))
            : (this.constraints = !1),
          (this.elastic = (function () {
            let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0.35;
            return (
              !1 === t ? (t = 0) : !0 === t && (t = 0.35),
              { x: q(t, "left", "right"), y: q(t, "top", "bottom") }
            );
          })(e)),
          s !== this.constraints &&
            !(0, M.isRefObject)(t) &&
            i &&
            this.constraints &&
            !this.hasMutatedConstraints &&
            (0, a.eachAxis)((t) => {
              var e, s;
              let o;
              !1 !== this.constraints &&
                this.getAxisMotionValue(t) &&
                (this.constraints[t] =
                  ((e = i.layoutBox[t]),
                  (s = this.constraints[t]),
                  (o = {}),
                  void 0 !== s.min && (o.min = s.min - e.min),
                  void 0 !== s.max && (o.max = s.max - e.min),
                  o));
            }));
      }
      resolveRefConstraints() {
        var t;
        let { dragConstraints: e, onMeasureDragConstraints: i } = this.getProps();
        if (!e || !(0, M.isRefObject)(e)) return !1;
        let s = e.current;
        (0, R.invariant)(
          null !== s,
          "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.",
          "drag-constraints-ref",
        );
        let { projection: o } = this.visualElement;
        if (!o || !o.layout) return !1;
        o.root && ((o.root.scroll = void 0), o.root.updateScroll());
        let n = (0, l.measurePageBox)(s, o.root, this.visualElement.getTransformPagePoint()),
          r = ((t = o.layout.layoutBox), { x: Y(t.x, n.x), y: Y(t.y, n.y) });
        if (i) {
          let t = i((0, h.convertBoxToBoundingBox)(r));
          ((this.hasMutatedConstraints = !!t), t && (r = (0, h.convertBoundingBoxToBox)(t)));
        }
        return r;
      }
      startAnimation(t) {
        let {
            drag: e,
            dragMomentum: i,
            dragElastic: s,
            dragTransition: o,
            dragSnapToOrigin: n,
            onDragTransitionEnd: r,
          } = this.getProps(),
          l = this.constraints || {};
        return Promise.all(
          (0, a.eachAxis)((r) => {
            if (!Q(r, e, this.currentDirection)) return;
            let a = (l && l[r]) || {};
            (!0 === n || n === r) && (a = { min: 0, max: 0 });
            let h = {
              type: "inertia",
              velocity: i ? t[r] : 0,
              bounceStiffness: s ? 200 : 1e6,
              bounceDamping: s ? 40 : 1e7,
              timeConstant: 750,
              restDelta: 1,
              restSpeed: 10,
              ...o,
              ...a,
            };
            return this.startAxisValueAnimation(r, h);
          }),
        ).then(r);
      }
      startAxisValueAnimation(t, e) {
        let i = this.getAxisMotionValue(t);
        return (
          (0, u.addValueToWillChange)(this.visualElement, t),
          i.start((0, c.animateMotionValue)(t, i, 0, e, this.visualElement, !1))
        );
      }
      stopAnimation() {
        (0, a.eachAxis)((t) => this.getAxisMotionValue(t).stop());
      }
      getAxisMotionValue(t) {
        let e = `_drag${t.toUpperCase()}`;
        return (
          this.visualElement.getProps()[e] ||
          this.visualElement.getValue(t, this.visualElement.latestValues[t] ?? 0)
        );
      }
      snapToCursor(t) {
        (0, a.eachAxis)((e) => {
          let { drag: i } = this.getProps();
          if (!Q(e, i, this.currentDirection)) return;
          let { projection: s } = this.visualElement,
            o = this.getAxisMotionValue(e);
          if (s && s.layout) {
            let { min: i, max: n } = s.layout.layoutBox[e],
              r = o.get() || 0;
            o.set(t[e] - (0, d.mixNumber)(i, n, 0.5) + r);
          }
        });
      }
      scalePositionWithinConstraints() {
        if (!this.visualElement.current) return;
        let { drag: t, dragConstraints: e } = this.getProps(),
          { projection: i } = this.visualElement;
        if (!(0, M.isRefObject)(e) || !i || !this.constraints) return;
        this.stopAnimation();
        let s = { x: 0, y: 0 };
        (0, a.eachAxis)((t) => {
          let e = this.getAxisMotionValue(t);
          if (e && !1 !== this.constraints) {
            var i, o;
            let n,
              r,
              a,
              l = e.get();
            s[t] =
              ((i = { min: l, max: l }),
              (o = this.constraints[t]),
              (n = 0.5),
              (r = (0, v.calcLength)(i)),
              (a = (0, v.calcLength)(o)) > r
                ? (n = (0, $.progress)(o.min, o.max - r, i.min))
                : r > a && (n = (0, $.progress)(i.min, i.max - a, o.min)),
              (0, H.clamp)(0, 1, n));
          }
        });
        let { transformTemplate: o } = this.visualElement.getProps();
        ((this.visualElement.current.style.transform = o ? o({}, "") : "none"),
          i.root && i.root.updateScroll(),
          i.updateLayout(),
          (this.constraints = !1),
          this.resolveConstraints(),
          (0, a.eachAxis)((e) => {
            if (!Q(e, t, null)) return;
            let i = this.getAxisMotionValue(e),
              { min: o, max: n } = this.constraints[e];
            i.set((0, d.mixNumber)(o, n, s[e]));
          }),
          this.visualElement.render());
      }
      addListeners() {
        let t;
        if (!this.visualElement.current) return;
        K.set(this.visualElement, this);
        let e = this.visualElement.current,
          i = j(e, "pointerdown", (t) => {
            let { drag: i, dragListener: s = !0 } = this.getProps(),
              o = t.target,
              n = o !== e && (0, B.isElementTextInput)(o);
            i && s && !n && this.start(t);
          }),
          s = () => {
            var i, s, o;
            let n,
              r,
              { dragConstraints: a } = this.getProps();
            (0, M.isRefObject)(a) &&
              a.current &&
              ((this.constraints = this.resolveRefConstraints()),
              t ||
                ((i = e),
                (s = a.current),
                (n = A(i, J((o = () => this.scalePositionWithinConstraints())))),
                (r = A(s, J(o))),
                (t = () => {
                  (n(), r());
                })));
          },
          { projection: o } = this.visualElement,
          n = o.addEventListener("measure", s);
        (o && !o.layout && (o.root && o.root.updateScroll(), o.updateLayout()), r.frame.read(s));
        let l = (0, m.addDomEvent)(window, "resize", () => this.scalePositionWithinConstraints()),
          h = o.addEventListener("didUpdate", (t) => {
            let { delta: e, hasLayoutChanged: i } = t;
            this.isDragging &&
              i &&
              ((0, a.eachAxis)((t) => {
                let i = this.getAxisMotionValue(t);
                i && ((this.originPoint[t] += e[t].translate), i.set(i.get() + e[t].translate));
              }),
              this.visualElement.render());
          });
        return () => {
          (l(), i(), n(), h && h(), t && t());
        };
      }
      getProps() {
        let t = this.visualElement.getProps(),
          {
            drag: e = !1,
            dragDirectionLock: i = !1,
            dragPropagation: s = !1,
            dragConstraints: o = !1,
            dragElastic: n = 0.35,
            dragMomentum: r = !0,
          } = t;
        return {
          ...t,
          drag: e,
          dragDirectionLock: i,
          dragPropagation: s,
          dragConstraints: o,
          dragElastic: n,
          dragMomentum: r,
        };
      }
    }
    function J(t) {
      let e = !0;
      return () => {
        if (e) {
          e = !1;
          return;
        }
        t();
      };
    }
    function Q(t, e, i) {
      return (!0 === e || e === t) && (null === i || i === t);
    }
    class tt extends s.Feature {
      constructor(t) {
        (super(t),
          (this.removeGroupControls = o.noop),
          (this.removeListeners = o.noop),
          (this.controls = new _(t)));
      }
      mount() {
        let { dragControls: t } = this.node.getProps();
        (t && (this.removeGroupControls = t.subscribe(this.controls)),
          (this.removeListeners = this.controls.addListeners() || o.noop));
      }
      update() {
        let { dragControls: t } = this.node.getProps(),
          { dragControls: e } = this.node.prevProps || {};
        t !== e && (this.removeGroupControls(), t && (this.removeGroupControls = t.subscribe(this.controls)));
      }
      unmount() {
        (this.removeGroupControls(),
          this.removeListeners(),
          this.controls.isDragging || this.controls.endPanSession());
      }
    }
    t.s(["DragGesture", 0, tt], 733986);
    var te = s;
    let ti = (t) => (e, i) => {
      t && r.frame.update(() => t(e, i), !1, !0);
    };
    class ts extends te.Feature {
      constructor() {
        (super(...arguments), (this.removePointerDownListener = o.noop));
      }
      onPointerDown(t) {
        this.session = new N(t, this.createPanHandlers(), {
          transformPagePoint: this.node.getTransformPagePoint(),
          contextWindow: V(this.node),
        });
      }
      createPanHandlers() {
        let { onPanSessionStart: t, onPanStart: e, onPan: i, onPanEnd: s } = this.node.getProps();
        return {
          onSessionStart: ti(t),
          onStart: ti(e),
          onMove: ti(i),
          onEnd: (t, e) => {
            (delete this.session, s && r.frame.postRender(() => s(t, e)));
          },
        };
      }
      mount() {
        this.removePointerDownListener = j(this.node.current, "pointerdown", (t) => this.onPointerDown(t));
      }
      update() {
        this.session && this.session.updateHandlers(this.createPanHandlers());
      }
      unmount() {
        (this.removePointerDownListener(), this.session && this.session.end());
      }
    }
    t.s(["PanGesture", 0, ts], 485651);
    var to = t.i(843476);
    let tn = { hasAnimatedSinceResize: !0, hasEverUpdated: !1 };
    t.s(["globalProjectionState", 0, tn], 107230);
    var tr = t.i(560140),
      ta = t.i(271645),
      tl = t.i(464978),
      th = t.i(231178),
      tu = t.i(104035);
    let tc = !1;
    class td extends ta.Component {
      componentDidMount() {
        let { visualElement: t, layoutGroup: e, switchLayoutGroup: i, layoutId: s } = this.props,
          { projection: o } = t;
        (o &&
          (e.group && e.group.add(o),
          i && i.register && s && i.register(o),
          tc && o.root.didUpdate(),
          o.addEventListener("animationComplete", () => {
            this.safeToRemove();
          }),
          o.setOptions({
            ...o.options,
            layoutDependency: this.props.layoutDependency,
            onExitComplete: () => this.safeToRemove(),
          })),
          (tn.hasEverUpdated = !0));
      }
      getSnapshotBeforeUpdate(t) {
        let { layoutDependency: e, visualElement: i, drag: s, isPresent: o } = this.props,
          { projection: n } = i;
        return (
          n &&
            ((n.isPresent = o),
            t.layoutDependency !== e && n.setOptions({ ...n.options, layoutDependency: e }),
            (tc = !0),
            s || t.layoutDependency !== e || void 0 === e || t.isPresent !== o
              ? n.willUpdate()
              : this.safeToRemove(),
            t.isPresent !== o &&
              (o
                ? n.promote()
                : n.relegate() ||
                  r.frame.postRender(() => {
                    let t = n.getStack();
                    (t && t.members.length) || this.safeToRemove();
                  }))),
          null
        );
      }
      componentDidUpdate() {
        let { visualElement: t, layoutAnchor: e } = this.props,
          { projection: i } = t;
        i &&
          ((i.options.layoutAnchor = e),
          i.root.didUpdate(),
          tr.microtask.postRender(() => {
            !i.currentAnimation && i.isLead() && this.safeToRemove();
          }));
      }
      componentWillUnmount() {
        let { visualElement: t, layoutGroup: e, switchLayoutGroup: i } = this.props,
          { projection: s } = t;
        ((tc = !0),
          s &&
            (s.scheduleCheckAfterUnmount(),
            e && e.group && e.group.remove(s),
            i && i.deregister && i.deregister(s)));
      }
      safeToRemove() {
        let { safeToRemove: t } = this.props;
        t && t();
      }
      render() {
        return null;
      }
    }
    t.s(
      [
        "MeasureLayout",
        0,
        function (t) {
          let [e, i] = (0, tl.usePresence)(),
            s = (0, ta.useContext)(th.LayoutGroupContext);
          return (0, to.jsx)(td, {
            ...t,
            layoutGroup: s,
            switchLayoutGroup: (0, ta.useContext)(tu.SwitchLayoutGroupContext),
            isPresent: e,
            safeToRemove: i,
          });
        },
      ],
      877397,
    );
  },
  846932,
  767937,
  112919,
  770097,
  48180,
  407547,
  367636,
  937192,
  647539,
  920280,
  71899,
  717871,
  646816,
  454292,
  (t) => {
    "use strict";
    var e = t.i(154505),
      i = t.i(907051),
      s = t.i(223070),
      o = t.i(733986),
      n = t.i(485651),
      r = t.i(877397),
      a = t.i(570596),
      l = t.i(476959),
      h = t.i(260830),
      u = t.i(768705),
      c = t.i(716896),
      d = t.i(987333),
      m = t.i(560140),
      p = t.i(496173),
      g = t.i(924463),
      v = t.i(880248),
      y = t.i(367807),
      f = t.i(889026),
      x = t.i(836331),
      P = t.i(100706),
      D = t.i(486427),
      T = t.i(733871),
      E = t.i(265091),
      S = t.i(783920),
      w = t.i(791559),
      A = t.i(895051);
    let B = A.cornerRadiusProps.length,
      R = (t) => ("string" == typeof t ? parseFloat(t) : t),
      L = (t) => "number" == typeof t || E.px.test(t);
    function j(t, e, i, s, o, n) {
      o
        ? ((t.opacity = (0, P.mixNumber)(0, i.opacity ?? 1, M(s))),
          (t.opacityExit = (0, P.mixNumber)(e.opacity ?? 1, 0, b(s))))
        : n && (t.opacity = (0, P.mixNumber)(e.opacity ?? 1, i.opacity ?? 1, s));
      for (let o = 0; o < B; o++) {
        let n = A.cornerRadiusProps[o],
          r = V(e, n),
          a = V(i, n);
        (void 0 !== r || void 0 !== a) &&
          (r || (r = 0),
          a || (a = 0),
          0 === r || 0 === a || L(r) === L(a)
            ? ((t[n] = Math.max((0, P.mixNumber)(R(r), R(a), s), 0)),
              (E.percent.test(a) || E.percent.test(r)) && (t[n] += "%"))
            : (t[n] = a));
      }
      (e.rotate || i.rotate) && (t.rotate = (0, P.mixNumber)(e.rotate || 0, i.rotate || 0, s));
    }
    function V(t, e) {
      return void 0 !== t[e] ? t[e] : t.borderRadius;
    }
    let M = k(0, 0.5, w.circOut),
      b = k(0.5, 0.95, h.noop);
    function k(t, e, i) {
      return (s) => (s < t ? 0 : s > e ? 1 : i((0, S.progress)(t, e, s)));
    }
    function C(t, e) {
      ((t.min = e.min), (t.max = e.max));
    }
    function U(t, e) {
      (C(t.x, e.x), C(t.y, e.y));
    }
    function I(t, e) {
      ((t.translate = e.translate),
        (t.scale = e.scale),
        (t.originPoint = e.originPoint),
        (t.origin = e.origin));
    }
    (t.s(["mixValues", 0, j], 767937),
      t.s(["copyAxisDeltaInto", 0, I, "copyAxisInto", 0, C, "copyBoxInto", 0, U], 112919));
    var F = t.i(135636),
      N = t.i(652101);
    function O(t, e, i, s, o) {
      return (
        (t -= e),
        (t = (0, F.scalePoint)(t, 1 / i, s)),
        void 0 !== o && (t = (0, F.scalePoint)(t, 1 / o, s)),
        t
      );
    }
    function z(t) {
      let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
        i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
        s = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0.5,
        o = arguments.length > 4 ? arguments[4] : void 0,
        n = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : t,
        r = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : t;
      if (
        (E.percent.test(e) && ((e = parseFloat(e)), (e = (0, P.mixNumber)(r.min, r.max, e / 100) - r.min)),
        "number" != typeof e)
      )
        return;
      let a = (0, P.mixNumber)(n.min, n.max, s);
      (t === n && (a -= e), (t.min = O(t.min, e, i, a, o)), (t.max = O(t.max, e, i, a, o)));
    }
    function W(t, e, i, s, o) {
      let [n, r, a] = i;
      z(t, e[n], e[r], e[a], e.scale, s, o);
    }
    let G = ["x", "scaleX", "originX"],
      $ = ["y", "scaleY", "originY"];
    function H(t, e, i, s) {
      (W(t.x, e, G, i ? i.x : void 0, s ? s.x : void 0), W(t.y, e, $, i ? i.y : void 0, s ? s.y : void 0));
    }
    t.s(
      [
        "removeAxisDelta",
        0,
        z,
        "removeAxisTransforms",
        0,
        W,
        "removeBoxTransforms",
        0,
        H,
        "removePointDelta",
        0,
        O,
      ],
      770097,
    );
    var X = t.i(130162);
    function Y(t) {
      return 0 === t.translate && 1 === t.scale;
    }
    function q(t) {
      return Y(t.x) && Y(t.y);
    }
    function Z(t, e) {
      return t.min === e.min && t.max === e.max;
    }
    function K(t, e) {
      return Z(t.x, e.x) && Z(t.y, e.y);
    }
    function _(t, e) {
      return Math.round(t.min) === Math.round(e.min) && Math.round(t.max) === Math.round(e.max);
    }
    function J(t, e) {
      return _(t.x, e.x) && _(t.y, e.y);
    }
    function Q(t) {
      return (0, N.calcLength)(t.x) / (0, N.calcLength)(t.y);
    }
    function tt(t, e) {
      return t.translate === e.translate && t.scale === e.scale && t.originPoint === e.originPoint;
    }
    t.s(
      [
        "aspectRatio",
        0,
        Q,
        "axisDeltaEquals",
        0,
        tt,
        "axisEquals",
        0,
        Z,
        "axisEqualsRounded",
        0,
        _,
        "boxEquals",
        0,
        K,
        "boxEqualsRounded",
        0,
        J,
        "isDeltaZero",
        0,
        q,
      ],
      48180,
    );
    var te = t.i(133887);
    class ti {
      constructor() {
        this.members = [];
      }
      add(t) {
        (0, te.addUniqueItem)(this.members, t);
        for (let e = this.members.length - 1; e >= 0; e--) {
          let i = this.members[e];
          if (i === t || i === this.lead || i === this.prevLead) continue;
          let s = i.instance;
          (s && !1 !== s.isConnected) || i.snapshot || ((0, te.removeItem)(this.members, i), i.unmount());
        }
        t.scheduleRender();
      }
      remove(t) {
        if (
          ((0, te.removeItem)(this.members, t),
          t === this.prevLead && (this.prevLead = void 0),
          t === this.lead)
        ) {
          let t = this.members[this.members.length - 1];
          t && this.promote(t);
        }
      }
      relegate(t) {
        for (let e = this.members.indexOf(t) - 1; e >= 0; e--) {
          let t = this.members[e];
          if (!1 !== t.isPresent && t.instance?.isConnected !== !1) return (this.promote(t), !0);
        }
        return !1;
      }
      promote(t, e) {
        let i = this.lead;
        if (t !== i && ((this.prevLead = i), (this.lead = t), t.show(), i)) {
          (i.updateSnapshot(), t.scheduleRender());
          let { layoutDependency: s } = i.options,
            { layoutDependency: o } = t.options;
          ((void 0 === s || s !== o) &&
            ((t.resumeFrom = i),
            e && (i.preserveOpacity = !0),
            i.snapshot &&
              ((t.snapshot = i.snapshot), (t.snapshot.latestValues = i.animationValues || i.latestValues)),
            t.root?.isUpdating && (t.isLayoutDirty = !0)),
            !1 === t.options.crossfade && i.hide());
        }
      }
      exitAnimationComplete() {
        this.members.forEach((t) => {
          (t.options.onExitComplete?.(), t.resumingFrom?.options.onExitComplete?.());
        });
      }
      scheduleRender() {
        this.members.forEach((t) => t.instance && t.scheduleRender(!1));
      }
      removeLeadSnapshot() {
        this.lead?.snapshot && (this.lead.snapshot = void 0);
      }
    }
    function ts(t, e, i) {
      let s = "",
        o = t.x.translate / e.x,
        n = t.y.translate / e.y,
        r = i?.z || 0;
      if (
        ((o || n || r) && (s = `translate3d(${o}px, ${n}px, ${r}px) `),
        (1 !== e.x || 1 !== e.y) && (s += `scale(${1 / e.x}, ${1 / e.y}) `),
        i)
      ) {
        let {
          transformPerspective: t,
          rotate: e,
          pathRotation: o,
          rotateX: n,
          rotateY: r,
          skewX: a,
          skewY: l,
        } = i;
        (t && (s = `perspective(${t}px) ${s}`),
          e && (s += `rotate(${e}deg) `),
          o && (s += `rotate(${o}deg) `),
          n && (s += `rotateX(${n}deg) `),
          r && (s += `rotateY(${r}deg) `),
          a && (s += `skewX(${a}deg) `),
          l && (s += `skewY(${l}deg) `));
      }
      let a = t.x.scale * e.x,
        l = t.y.scale * e.y;
      return ((1 !== a || 1 !== l) && (s += `scale(${a}, ${l})`), s || "none");
    }
    (t.s(["NodeStack", 0, ti], 407547), t.s(["buildProjectionTransform", 0, ts], 367636));
    var to = t.i(655559);
    let tn = (t, e) => t.depth - e.depth;
    t.s(["compareByDepth", 0, tn], 937192);
    class tr {
      constructor() {
        ((this.children = []), (this.isDirty = !1));
      }
      add(t) {
        ((0, te.addUniqueItem)(this.children, t), (this.isDirty = !0));
      }
      remove(t) {
        ((0, te.removeItem)(this.children, t), (this.isDirty = !0));
      }
      forEach(t) {
        (this.isDirty && this.children.sort(tn), (this.isDirty = !1), this.children.forEach(t));
      }
    }
    t.s(["FlatTree", 0, tr], 647539);
    var ta = t.i(177777),
      tl = t.i(107230),
      th = t.i(287022);
    let tu = { nodes: 0, calculatedTargetDeltas: 0, calculatedProjections: 0 },
      tc = ["", "X", "Y", "Z"],
      td = 0;
    function tm(t, e, i, s) {
      let { latestValues: o } = e;
      o[t] && ((i[t] = o[t]), e.setStaticValue(t, 0), s && (s[t] = 0));
    }
    function tp(t) {
      let {
        attachResizeListener: e,
        defaultParent: i,
        measureScroll: s,
        checkIsScrollRoot: o,
        resetTransform: n,
      } = t;
      return class {
        constructor(t = {}, e = i?.()) {
          ((this.id = td++),
            (this.animationId = 0),
            (this.animationCommitId = 0),
            (this.children = new Set()),
            (this.options = {}),
            (this.isTreeAnimating = !1),
            (this.isAnimationBlocked = !1),
            (this.isLayoutDirty = !1),
            (this.isProjectionDirty = !1),
            (this.isSharedProjectionDirty = !1),
            (this.isTransformDirty = !1),
            (this.updateManuallyBlocked = !1),
            (this.updateBlockedByResize = !1),
            (this.isUpdating = !1),
            (this.isSVG = !1),
            (this.needsReset = !1),
            (this.shouldResetTransform = !1),
            (this.hasCheckedOptimisedAppear = !1),
            (this.treeScale = { x: 1, y: 1 }),
            (this.eventHandlers = new Map()),
            (this.hasTreeAnimated = !1),
            (this.layoutVersion = 0),
            (this.updateScheduled = !1),
            (this.scheduleUpdate = () => this.update()),
            (this.projectionUpdateScheduled = !1),
            (this.checkUpdateFailed = () => {
              this.isUpdating && ((this.isUpdating = !1), this.clearAllSnapshots());
            }),
            (this.updateProjection = () => {
              ((this.projectionUpdateScheduled = !1),
                v.statsBuffer.value && (tu.nodes = tu.calculatedTargetDeltas = tu.calculatedProjections = 0),
                this.nodes.forEach(ty),
                this.nodes.forEach(tA),
                this.nodes.forEach(tB),
                this.nodes.forEach(tf),
                v.statsBuffer.addProjectionMetrics && v.statsBuffer.addProjectionMetrics(tu));
            }),
            (this.resolvedRelativeTargetAt = 0),
            (this.linkedParentVersion = 0),
            (this.hasProjected = !1),
            (this.isVisible = !0),
            (this.animationProgress = 0),
            (this.sharedNodes = new Map()),
            (this.latestValues = t),
            (this.root = e ? e.root || e : this),
            (this.path = e ? [...e.path, e] : []),
            (this.parent = e),
            (this.depth = e ? e.depth + 1 : 0));
          for (let t = 0; t < this.path.length; t++) this.path[t].shouldResetTransform = !0;
          this.root === this && (this.nodes = new tr());
        }
        addEventListener(t, e) {
          return (
            this.eventHandlers.has(t) || this.eventHandlers.set(t, new a.SubscriptionManager()),
            this.eventHandlers.get(t).add(e)
          );
        }
        notifyListeners(t) {
          for (var e = arguments.length, i = Array(e > 1 ? e - 1 : 0), s = 1; s < e; s++)
            i[s - 1] = arguments[s];
          let o = this.eventHandlers.get(t);
          o && o.notify(...i);
        }
        hasListeners(t) {
          return this.eventHandlers.has(t);
        }
        mount(t) {
          if (this.instance) return;
          ((this.isSVG = (0, f.isSVGElement)(t) && !(0, x.isSVGSVGElement)(t)), (this.instance = t));
          let { layoutId: i, layout: s, visualElement: o } = this.options;
          if (
            (o && !o.current && o.mount(t),
            this.root.nodes.add(this),
            this.parent && this.parent.children.add(this),
            this.root.hasTreeAnimated && (s || i) && (this.isLayoutDirty = !0),
            e)
          ) {
            let i,
              s = 0,
              o = () => (this.root.updateBlockedByResize = !1);
            (th.frame.read(() => {
              s = window.innerWidth;
            }),
              e(t, () => {
                let t = window.innerWidth;
                t !== s &&
                  ((s = t),
                  (this.root.updateBlockedByResize = !0),
                  i && i(),
                  (i = (0, y.delay)(o, 250)),
                  tl.globalProjectionState.hasAnimatedSinceResize &&
                    ((tl.globalProjectionState.hasAnimatedSinceResize = !1), this.nodes.forEach(tw)));
              }));
          }
          (i && this.root.registerSharedNode(i, this),
            !1 !== this.options.animate &&
              o &&
              (i || s) &&
              this.addEventListener("didUpdate", (t) => {
                let { delta: e, hasLayoutChanged: i, hasRelativeLayoutChanged: s, layout: n } = t;
                if (this.isTreeAnimationBlocked()) {
                  ((this.target = void 0), (this.relativeTarget = void 0));
                  return;
                }
                let r = this.options.transition || o.getDefaultTransition() || tb,
                  { onLayoutAnimationStart: a, onLayoutAnimationComplete: l } = o.getProps(),
                  h = !this.targetLayout || !J(this.targetLayout, n),
                  u = !i && s;
                if (this.options.layoutRoot || this.resumeFrom || u || (i && (h || !this.currentAnimation))) {
                  this.resumeFrom &&
                    ((this.resumingFrom = this.resumeFrom), (this.resumingFrom.resumingFrom = void 0));
                  let t = { ...(0, d.getValueTransition)(r, "layout"), onPlay: a, onComplete: l };
                  ((o.shouldReduceMotion || this.options.layoutRoot) && ((t.delay = 0), (t.type = !1)),
                    this.startAnimation(t),
                    this.setAnimationOrigin(e, u, t.path));
                } else
                  (i || tw(this),
                    this.isLead() && this.options.onExitComplete && this.options.onExitComplete());
                this.targetLayout = n;
              }));
        }
        unmount() {
          (this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this));
          let t = this.getStack();
          (t && t.remove(this),
            this.parent && this.parent.children.delete(this),
            (this.instance = void 0),
            this.eventHandlers.clear(),
            (0, th.cancelFrame)(this.updateProjection));
        }
        blockUpdate() {
          this.updateManuallyBlocked = !0;
        }
        unblockUpdate() {
          this.updateManuallyBlocked = !1;
        }
        isUpdateBlocked() {
          return this.updateManuallyBlocked || this.updateBlockedByResize;
        }
        isTreeAnimationBlocked() {
          return this.isAnimationBlocked || (this.parent && this.parent.isTreeAnimationBlocked()) || !1;
        }
        startUpdate() {
          !this.isUpdateBlocked() &&
            ((this.isUpdating = !0), this.nodes && this.nodes.forEach(tR), this.animationId++);
        }
        getTransformTemplate() {
          let { visualElement: t } = this.options;
          return t && t.getProps().transformTemplate;
        }
        willUpdate() {
          let t = !(arguments.length > 0) || void 0 === arguments[0] || arguments[0];
          if (((this.root.hasTreeAnimated = !0), this.root.isUpdateBlocked())) {
            this.options.onExitComplete && this.options.onExitComplete();
            return;
          }
          if (
            (window.MotionCancelOptimisedAnimation &&
              !this.hasCheckedOptimisedAppear &&
              (function t(e) {
                if (((e.hasCheckedOptimisedAppear = !0), e.root === e)) return;
                let { visualElement: i } = e.options;
                if (!i) return;
                let s = (0, c.getOptimisedAppearId)(i);
                if (window.MotionHasOptimisedAnimation(s, "transform")) {
                  let { layout: t, layoutId: i } = e.options;
                  window.MotionCancelOptimisedAnimation(s, "transform", th.frame, !(t || i));
                }
                let { parent: o } = e;
                o && !o.hasCheckedOptimisedAppear && t(o);
              })(this),
            this.root.isUpdating || this.root.startUpdate(),
            this.isLayoutDirty)
          )
            return;
          this.isLayoutDirty = !0;
          for (let t = 0; t < this.path.length; t++) {
            let e = this.path[t];
            ((e.shouldResetTransform = !0),
              ("string" == typeof e.latestValues.x || "string" == typeof e.latestValues.y) &&
                (e.isLayoutDirty = !0),
              e.updateScroll("snapshot"),
              e.options.layoutRoot && e.willUpdate(!1));
          }
          let { layoutId: e, layout: i } = this.options;
          if (void 0 === e && !i) return;
          let s = this.getTransformTemplate();
          ((this.prevTransformTemplateValue = s ? s(this.latestValues, "") : void 0),
            this.updateSnapshot(),
            t && this.notifyListeners("willUpdate"));
        }
        update() {
          if (((this.updateScheduled = !1), this.isUpdateBlocked())) {
            let t = this.updateBlockedByResize;
            (this.unblockUpdate(),
              (this.updateBlockedByResize = !1),
              this.clearAllSnapshots(),
              t && this.nodes.forEach(tD),
              this.nodes.forEach(tP));
            return;
          }
          if (this.animationId <= this.animationCommitId) return void this.nodes.forEach(tT);
          ((this.animationCommitId = this.animationId),
            this.isUpdating
              ? ((this.isUpdating = !1),
                this.nodes.forEach(tE),
                this.nodes.forEach(tS),
                this.nodes.forEach(tg),
                this.nodes.forEach(tv))
              : this.nodes.forEach(tT),
            this.clearAllSnapshots());
          let t = p.time.now();
          ((th.frameData.delta = (0, l.clamp)(0, 1e3 / 60, t - th.frameData.timestamp)),
            (th.frameData.timestamp = t),
            (th.frameData.isProcessing = !0),
            th.frameSteps.update.process(th.frameData),
            th.frameSteps.preRender.process(th.frameData),
            th.frameSteps.render.process(th.frameData),
            (th.frameData.isProcessing = !1));
        }
        didUpdate() {
          this.updateScheduled || ((this.updateScheduled = !0), m.microtask.read(this.scheduleUpdate));
        }
        clearAllSnapshots() {
          (this.nodes.forEach(tx), this.sharedNodes.forEach(tL));
        }
        scheduleUpdateProjection() {
          this.projectionUpdateScheduled ||
            ((this.projectionUpdateScheduled = !0), th.frame.preRender(this.updateProjection, !1, !0));
        }
        scheduleCheckAfterUnmount() {
          th.frame.postRender(() => {
            this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed();
          });
        }
        updateSnapshot() {
          !this.snapshot &&
            this.instance &&
            ((this.snapshot = this.measure()),
            !this.snapshot ||
              (0, N.calcLength)(this.snapshot.measuredBox.x) ||
              (0, N.calcLength)(this.snapshot.measuredBox.y) ||
              (this.snapshot = void 0));
        }
        updateLayout() {
          if (
            !this.instance ||
            (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty)
          )
            return;
          if (this.resumeFrom && !this.resumeFrom.instance)
            for (let t = 0; t < this.path.length; t++) this.path[t].updateScroll();
          let t = this.layout;
          ((this.layout = this.measure(!1)),
            this.layoutVersion++,
            this.layoutCorrected || (this.layoutCorrected = (0, X.createBox)()),
            (this.isLayoutDirty = !1),
            (this.projectionDelta = void 0),
            this.notifyListeners("measure", this.layout.layoutBox));
          let { visualElement: e } = this.options;
          e && e.notify("LayoutMeasure", this.layout.layoutBox, t ? t.layoutBox : void 0);
        }
        updateScroll() {
          let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "measure",
            e = !!(this.options.layoutScroll && this.instance);
          if (
            (this.scroll &&
              this.scroll.animationId === this.root.animationId &&
              this.scroll.phase === t &&
              (e = !1),
            e && this.instance)
          ) {
            let e = o(this.instance);
            this.scroll = {
              animationId: this.root.animationId,
              phase: t,
              isRoot: e,
              offset: s(this.instance),
              wasRoot: this.scroll ? this.scroll.isRoot : e,
            };
          }
        }
        resetTransform() {
          if (!n) return;
          let t = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout,
            e = this.projectionDelta && !q(this.projectionDelta),
            i = this.getTransformTemplate(),
            s = i ? i(this.latestValues, "") : void 0,
            o = s !== this.prevTransformTemplateValue;
          t &&
            this.instance &&
            (e || (0, ta.hasTransform)(this.latestValues) || o) &&
            (n(this.instance, s), (this.shouldResetTransform = !1), this.scheduleRender());
        }
        measure() {
          var t;
          let e = !(arguments.length > 0) || void 0 === arguments[0] || arguments[0],
            i = this.measurePageBox(),
            s = this.removeElementScroll(i);
          return (
            e && (s = this.removeTransform(s)),
            tU((t = s).x),
            tU(t.y),
            {
              animationId: this.root.animationId,
              measuredBox: i,
              layoutBox: s,
              latestValues: {},
              source: this.id,
            }
          );
        }
        measurePageBox() {
          let { visualElement: t } = this.options;
          if (!t) return (0, X.createBox)();
          let e = t.measureViewportBox();
          if (!(this.scroll?.wasRoot || this.path.some(tF))) {
            let { scroll: t } = this.root;
            t && ((0, F.translateAxis)(e.x, t.offset.x), (0, F.translateAxis)(e.y, t.offset.y));
          }
          return e;
        }
        removeElementScroll(t) {
          let e = (0, X.createBox)();
          if ((U(e, t), this.scroll?.wasRoot)) return e;
          for (let i = 0; i < this.path.length; i++) {
            let s = this.path[i],
              { scroll: o, options: n } = s;
            s !== this.root &&
              o &&
              n.layoutScroll &&
              (o.wasRoot && U(e, t),
              (0, F.translateAxis)(e.x, o.offset.x),
              (0, F.translateAxis)(e.y, o.offset.y));
          }
          return e;
        }
        applyTransform(t) {
          let e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
            i = arguments.length > 2 ? arguments[2] : void 0,
            s = i || (0, X.createBox)();
          U(s, t);
          for (let t = 0; t < this.path.length; t++) {
            let i = this.path[t];
            (!e &&
              i.options.layoutScroll &&
              i.scroll &&
              i !== i.root &&
              ((0, F.translateAxis)(s.x, -i.scroll.offset.x), (0, F.translateAxis)(s.y, -i.scroll.offset.y)),
              (0, ta.hasTransform)(i.latestValues) &&
                (0, F.transformBox)(s, i.latestValues, i.layout?.layoutBox));
          }
          return (
            (0, ta.hasTransform)(this.latestValues) &&
              (0, F.transformBox)(s, this.latestValues, this.layout?.layoutBox),
            s
          );
        }
        removeTransform(t) {
          let e = (0, X.createBox)();
          U(e, t);
          for (let t = 0; t < this.path.length; t++) {
            let i,
              s = this.path[t];
            (0, ta.hasTransform)(s.latestValues) &&
              (s.instance &&
                ((0, ta.hasScale)(s.latestValues) && s.updateSnapshot(),
                U((i = (0, X.createBox)()), s.measurePageBox())),
              H(e, s.latestValues, s.snapshot?.layoutBox, i));
          }
          return ((0, ta.hasTransform)(this.latestValues) && H(e, this.latestValues), e);
        }
        setTargetDelta(t) {
          ((this.targetDelta = t), this.root.scheduleUpdateProjection(), (this.isProjectionDirty = !0));
        }
        setOptions(t) {
          this.options = { ...this.options, ...t, crossfade: void 0 === t.crossfade || t.crossfade };
        }
        clearMeasurements() {
          ((this.scroll = void 0),
            (this.layout = void 0),
            (this.snapshot = void 0),
            (this.prevTransformTemplateValue = void 0),
            (this.targetDelta = void 0),
            (this.target = void 0),
            (this.isLayoutDirty = !1));
        }
        forceRelativeParentToResolveTarget() {
          this.relativeParent &&
            this.relativeParent.resolvedRelativeTargetAt !== th.frameData.timestamp &&
            this.relativeParent.resolveTargetDelta(!0);
        }
        resolveTargetDelta() {
          let t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
            e = this.getLead();
          (this.isProjectionDirty || (this.isProjectionDirty = e.isProjectionDirty),
            this.isTransformDirty || (this.isTransformDirty = e.isTransformDirty),
            this.isSharedProjectionDirty || (this.isSharedProjectionDirty = e.isSharedProjectionDirty));
          let i = !!this.resumingFrom || this !== e;
          if (!(
            t ||
            (i && this.isSharedProjectionDirty) ||
            this.isProjectionDirty ||
            this.parent?.isProjectionDirty ||
            this.attemptToResolveRelativeTarget ||
            this.root.updateBlockedByResize
          ))
            return;
          let { layout: s, layoutId: o } = this.options;
          if (!this.layout || !(s || o)) return;
          this.resolvedRelativeTargetAt = th.frameData.timestamp;
          let n = this.getClosestProjectingParent();
          (n &&
            this.linkedParentVersion !== n.layoutVersion &&
            !n.options.layoutRoot &&
            this.removeRelativeTarget(),
            this.targetDelta ||
              this.relativeTarget ||
              (!1 !== this.options.layoutAnchor && n && n.layout
                ? this.createRelativeTarget(n, this.layout.layoutBox, n.layout.layoutBox)
                : this.removeRelativeTarget()),
            (this.relativeTarget || this.targetDelta) &&
              (this.target ||
                ((this.target = (0, X.createBox)()), (this.targetWithTransforms = (0, X.createBox)())),
              this.relativeTarget &&
              this.relativeTargetOrigin &&
              this.relativeParent &&
              this.relativeParent.target
                ? (this.forceRelativeParentToResolveTarget(),
                  (0, N.calcRelativeBox)(
                    this.target,
                    this.relativeTarget,
                    this.relativeParent.target,
                    this.options.layoutAnchor || void 0,
                  ))
                : this.targetDelta
                  ? (this.resumingFrom
                      ? this.applyTransform(this.layout.layoutBox, !1, this.target)
                      : U(this.target, this.layout.layoutBox),
                    (0, F.applyBoxDelta)(this.target, this.targetDelta))
                  : U(this.target, this.layout.layoutBox),
              this.attemptToResolveRelativeTarget &&
                ((this.attemptToResolveRelativeTarget = !1),
                !1 !== this.options.layoutAnchor &&
                n &&
                !!n.resumingFrom == !!this.resumingFrom &&
                !n.options.layoutScroll &&
                n.target &&
                1 !== this.animationProgress
                  ? this.createRelativeTarget(n, this.target, n.target)
                  : (this.relativeParent = this.relativeTarget = void 0)),
              v.statsBuffer.value && tu.calculatedTargetDeltas++));
        }
        getClosestProjectingParent() {
          if (!(
            !this.parent ||
            (0, ta.hasScale)(this.parent.latestValues) ||
            (0, ta.has2DTranslate)(this.parent.latestValues)
          ))
            if (this.parent.isProjecting()) return this.parent;
            else return this.parent.getClosestProjectingParent();
        }
        isProjecting() {
          return !!((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout);
        }
        createRelativeTarget(t, e, i) {
          ((this.relativeParent = t),
            (this.linkedParentVersion = t.layoutVersion),
            this.forceRelativeParentToResolveTarget(),
            (this.relativeTarget = (0, X.createBox)()),
            (this.relativeTargetOrigin = (0, X.createBox)()),
            (0, N.calcRelativePosition)(this.relativeTargetOrigin, e, i, this.options.layoutAnchor || void 0),
            U(this.relativeTarget, this.relativeTargetOrigin));
        }
        removeRelativeTarget() {
          this.relativeParent = this.relativeTarget = void 0;
        }
        calcProjection() {
          let t = this.getLead(),
            e = !!this.resumingFrom || this !== t,
            i = !0;
          if (
            ((this.isProjectionDirty || this.parent?.isProjectionDirty) && (i = !1),
            e && (this.isSharedProjectionDirty || this.isTransformDirty) && (i = !1),
            this.resolvedRelativeTargetAt === th.frameData.timestamp && (i = !1),
            i)
          )
            return;
          let { layout: s, layoutId: o } = this.options;
          if (
            ((this.isTreeAnimating = !!(
              (this.parent && this.parent.isTreeAnimating) ||
              this.currentAnimation ||
              this.pendingAnimation
            )),
            this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0),
            !this.layout || !(s || o))
          )
            return;
          U(this.layoutCorrected, this.layout.layoutBox);
          let n = this.treeScale.x,
            r = this.treeScale.y;
          ((0, F.applyTreeDeltas)(this.layoutCorrected, this.treeScale, this.path, e),
            t.layout &&
              !t.target &&
              (1 !== this.treeScale.x || 1 !== this.treeScale.y) &&
              ((t.target = t.layout.layoutBox), (t.targetWithTransforms = (0, X.createBox)())));
          let { target: a } = t;
          if (!a) {
            this.prevProjectionDelta && (this.createProjectionDeltas(), this.scheduleRender());
            return;
          }
          (this.projectionDelta && this.prevProjectionDelta
            ? (I(this.prevProjectionDelta.x, this.projectionDelta.x),
              I(this.prevProjectionDelta.y, this.projectionDelta.y))
            : this.createProjectionDeltas(),
            (0, N.calcBoxDelta)(this.projectionDelta, this.layoutCorrected, a, this.latestValues),
            (this.treeScale.x === n &&
              this.treeScale.y === r &&
              tt(this.projectionDelta.x, this.prevProjectionDelta.x) &&
              tt(this.projectionDelta.y, this.prevProjectionDelta.y)) ||
              ((this.hasProjected = !0), this.scheduleRender(), this.notifyListeners("projectionUpdate", a)),
            v.statsBuffer.value && tu.calculatedProjections++);
        }
        hide() {
          this.isVisible = !1;
        }
        show() {
          this.isVisible = !0;
        }
        scheduleRender() {
          let t = !(arguments.length > 0) || void 0 === arguments[0] || arguments[0];
          if ((this.options.visualElement?.scheduleRender(), t)) {
            let t = this.getStack();
            t && t.scheduleRender();
          }
          this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0);
        }
        createProjectionDeltas() {
          ((this.prevProjectionDelta = (0, X.createDelta)()),
            (this.projectionDelta = (0, X.createDelta)()),
            (this.projectionDeltaWithTransform = (0, X.createDelta)()));
        }
        setAnimationOrigin(t) {
          let e,
            i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
            s = arguments.length > 2 ? arguments[2] : void 0,
            o = this.snapshot,
            n = o ? o.latestValues : {},
            r = { ...this.latestValues },
            a = (0, X.createDelta)();
          ((this.relativeParent && this.relativeParent.options.layoutRoot) ||
            (this.relativeTarget = this.relativeTargetOrigin = void 0),
            (this.attemptToResolveRelativeTarget = !i));
          let l = (0, X.createBox)(),
            h = (o ? o.source : void 0) !== (this.layout ? this.layout.source : void 0),
            u = this.getStack(),
            c = !u || u.members.length <= 1,
            d = !!(h && !c && !0 === this.options.crossfade && !this.path.some(tM));
          this.animationProgress = 0;
          let m = s?.interpolateProjection(t);
          ((this.mixTargetDelta = (i) => {
            var s, o, u, p;
            let g = i / 1e3,
              v = m?.(g);
            (v
              ? ((a.x.translate = v.x),
                (a.x.scale = (0, P.mixNumber)(t.x.scale, 1, g)),
                (a.x.origin = t.x.origin),
                (a.x.originPoint = t.x.originPoint),
                (a.y.translate = v.y),
                (a.y.scale = (0, P.mixNumber)(t.y.scale, 1, g)),
                (a.y.origin = t.y.origin),
                (a.y.originPoint = t.y.originPoint))
              : (tj(a.x, t.x, g), tj(a.y, t.y, g)),
              this.setTargetDelta(a),
              this.relativeTarget &&
                this.relativeTargetOrigin &&
                this.layout &&
                this.relativeParent &&
                this.relativeParent.layout &&
                ((0, N.calcRelativePosition)(
                  l,
                  this.layout.layoutBox,
                  this.relativeParent.layout.layoutBox,
                  this.options.layoutAnchor || void 0,
                ),
                (s = this.relativeTarget),
                (o = this.relativeTargetOrigin),
                (u = l),
                (p = g),
                tV(s.x, o.x, u.x, p),
                tV(s.y, o.y, u.y, p),
                e && K(this.relativeTarget, e) && (this.isProjectionDirty = !1),
                e || (e = (0, X.createBox)()),
                U(e, this.relativeTarget)),
              h && ((this.animationValues = r), j(r, n, this.latestValues, g, d, c)),
              v &&
                void 0 !== v.rotate &&
                (this.animationValues || (this.animationValues = r),
                (this.animationValues.pathRotation = v.rotate)),
              this.root.scheduleUpdateProjection(),
              this.scheduleRender(),
              (this.animationProgress = g));
          }),
            this.mixTargetDelta(1e3 * !!this.options.layoutRoot));
        }
        startAnimation(t) {
          (this.notifyListeners("animationStart"),
            this.currentAnimation?.stop(),
            this.resumingFrom?.currentAnimation?.stop(),
            this.pendingAnimation &&
              ((0, th.cancelFrame)(this.pendingAnimation), (this.pendingAnimation = void 0)),
            (this.pendingAnimation = th.frame.update(() => {
              ((tl.globalProjectionState.hasAnimatedSinceResize = !0),
                this.motionValue || (this.motionValue = (0, D.motionValue)(0)),
                this.motionValue.jump(0, !1),
                (this.currentAnimation = (0, u.animateSingleValue)(this.motionValue, [0, 1e3], {
                  ...t,
                  velocity: 0,
                  isSync: !0,
                  onUpdate: (e) => {
                    (this.mixTargetDelta(e), t.onUpdate && t.onUpdate(e));
                  },
                  onComplete: () => {
                    (t.onComplete && t.onComplete(), this.completeAnimation());
                  },
                })),
                this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation),
                (this.pendingAnimation = void 0));
            })));
        }
        completeAnimation() {
          this.resumingFrom &&
            ((this.resumingFrom.currentAnimation = void 0), (this.resumingFrom.preserveOpacity = void 0));
          let t = this.getStack();
          (t && t.exitAnimationComplete(),
            (this.resumingFrom = this.currentAnimation = this.animationValues = void 0),
            this.notifyListeners("animationComplete"));
        }
        finishAnimation() {
          (this.currentAnimation &&
            (this.mixTargetDelta && this.mixTargetDelta(1e3), this.currentAnimation.stop()),
            this.completeAnimation());
        }
        applyTransformsToTarget() {
          let t = this.getLead(),
            { targetWithTransforms: e, target: i, layout: s, latestValues: o } = t;
          if (e && i && s) {
            if (
              this !== t &&
              this.layout &&
              s &&
              tI(this.options.animationType, this.layout.layoutBox, s.layoutBox)
            ) {
              i = this.target || (0, X.createBox)();
              let e = (0, N.calcLength)(this.layout.layoutBox.x);
              ((i.x.min = t.target.x.min), (i.x.max = i.x.min + e));
              let s = (0, N.calcLength)(this.layout.layoutBox.y);
              ((i.y.min = t.target.y.min), (i.y.max = i.y.min + s));
            }
            (U(e, i),
              (0, F.transformBox)(e, o),
              (0, N.calcBoxDelta)(this.projectionDeltaWithTransform, this.layoutCorrected, e, o));
          }
        }
        registerSharedNode(t, e) {
          (this.sharedNodes.has(t) || this.sharedNodes.set(t, new ti()), this.sharedNodes.get(t).add(e));
          let i = e.options.initialPromotionConfig;
          e.promote({
            transition: i ? i.transition : void 0,
            preserveFollowOpacity:
              i && i.shouldPreserveFollowOpacity ? i.shouldPreserveFollowOpacity(e) : void 0,
          });
        }
        isLead() {
          let t = this.getStack();
          return !t || t.lead === this;
        }
        getLead() {
          let { layoutId: t } = this.options;
          return (t && this.getStack()?.lead) || this;
        }
        getPrevLead() {
          let { layoutId: t } = this.options;
          return t ? this.getStack()?.prevLead : void 0;
        }
        getStack() {
          let { layoutId: t } = this.options;
          if (t) return this.root.sharedNodes.get(t);
        }
        promote() {
          let {
              needsReset: t,
              transition: e,
              preserveFollowOpacity: i,
            } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
            s = this.getStack();
          (s && s.promote(this, i),
            t && ((this.projectionDelta = void 0), (this.needsReset = !0)),
            e && this.setOptions({ transition: e }));
        }
        relegate() {
          let t = this.getStack();
          return !!t && t.relegate(this);
        }
        resetSkewAndRotation() {
          let { visualElement: t } = this.options;
          if (!t) return;
          let e = !1,
            { latestValues: i } = t;
          if (
            ((i.z || i.rotate || i.rotateX || i.rotateY || i.rotateZ || i.skewX || i.skewY) && (e = !0), !e)
          )
            return;
          let s = {};
          i.z && tm("z", t, s, this.animationValues);
          for (let e = 0; e < tc.length; e++)
            (tm(`rotate${tc[e]}`, t, s, this.animationValues),
              tm(`skew${tc[e]}`, t, s, this.animationValues));
          for (let e in (t.render(), s))
            (t.setStaticValue(e, s[e]), this.animationValues && (this.animationValues[e] = s[e]));
          t.scheduleRender();
        }
        applyProjectionStyles(t, e) {
          if (!this.instance || this.isSVG) return;
          if (!this.isVisible) {
            t.visibility = "hidden";
            return;
          }
          let i = this.getTransformTemplate();
          if (this.needsReset) {
            ((this.needsReset = !1),
              (t.visibility = ""),
              (t.opacity = ""),
              (t.pointerEvents = (0, T.resolveMotionValue)(e?.pointerEvents) || ""),
              (t.transform = i ? i(this.latestValues, "") : "none"));
            return;
          }
          let s = this.getLead();
          if (!this.projectionDelta || !this.layout || !s.target) {
            (this.options.layoutId &&
              ((t.opacity = void 0 !== this.latestValues.opacity ? this.latestValues.opacity : 1),
              (t.pointerEvents = (0, T.resolveMotionValue)(e?.pointerEvents) || "")),
              this.hasProjected &&
                !(0, ta.hasTransform)(this.latestValues) &&
                ((t.transform = i ? i({}, "") : "none"), (this.hasProjected = !1)));
            return;
          }
          t.visibility = "";
          let o = s.animationValues || s.latestValues;
          this.applyTransformsToTarget();
          let n = ts(this.projectionDeltaWithTransform, this.treeScale, o);
          (i && (n = i(o, n)), (t.transform = n));
          let { x: r, y: a } = this.projectionDelta;
          for (let e in ((t.transformOrigin = `${100 * r.origin}% ${100 * a.origin}% 0`),
          s.animationValues
            ? (t.opacity =
                s === this
                  ? (o.opacity ?? this.latestValues.opacity ?? 1)
                  : this.preserveOpacity
                    ? this.latestValues.opacity
                    : o.opacityExit)
            : (t.opacity =
                s === this
                  ? void 0 !== o.opacity
                    ? o.opacity
                    : ""
                  : void 0 !== o.opacityExit
                    ? o.opacityExit
                    : 0),
          g.scaleCorrectors)) {
            if (void 0 === o[e]) continue;
            let { correct: i, applyTo: r, isCSSVariable: a } = g.scaleCorrectors[e],
              l = "none" === n ? o[e] : i(o[e], s);
            if (r) {
              let e = r.length;
              for (let i = 0; i < e; i++) t[r[i]] = l;
            } else a ? (this.options.visualElement.renderState.vars[e] = l) : (t[e] = l);
          }
          this.options.layoutId &&
            (t.pointerEvents = s === this ? (0, T.resolveMotionValue)(e?.pointerEvents) || "" : "none");
        }
        clearSnapshot() {
          this.resumeFrom = this.snapshot = void 0;
        }
        resetTree() {
          (this.root.nodes.forEach((t) => t.currentAnimation?.stop()),
            this.root.nodes.forEach(tP),
            this.root.sharedNodes.clear());
        }
      };
    }
    function tg(t) {
      t.updateLayout();
    }
    function tv(t) {
      let e = t.resumeFrom?.snapshot || t.snapshot;
      if (t.isLead() && t.layout && e && t.hasListeners("didUpdate")) {
        let { layoutBox: i, measuredBox: s } = t.layout,
          { animationType: o } = t.options,
          n = e.source !== t.layout.source;
        if ("size" === o)
          (0, to.eachAxis)((t) => {
            let s = n ? e.measuredBox[t] : e.layoutBox[t],
              o = (0, N.calcLength)(s);
            ((s.min = i[t].min), (s.max = s.min + o));
          });
        else if ("x" === o || "y" === o) {
          let t = "x" === o ? "y" : "x";
          C(n ? e.measuredBox[t] : e.layoutBox[t], i[t]);
        } else
          tI(o, e.layoutBox, i) &&
            (0, to.eachAxis)((s) => {
              let o = n ? e.measuredBox[s] : e.layoutBox[s],
                r = (0, N.calcLength)(i[s]);
              ((o.max = o.min + r),
                t.relativeTarget &&
                  !t.currentAnimation &&
                  ((t.isProjectionDirty = !0), (t.relativeTarget[s].max = t.relativeTarget[s].min + r)));
            });
        let r = (0, X.createDelta)();
        (0, N.calcBoxDelta)(r, i, e.layoutBox);
        let a = (0, X.createDelta)();
        n
          ? (0, N.calcBoxDelta)(a, t.applyTransform(s, !0), e.measuredBox)
          : (0, N.calcBoxDelta)(a, i, e.layoutBox);
        let l = !q(r),
          h = !1;
        if (!t.resumeFrom) {
          let s = t.getClosestProjectingParent();
          if (s && !s.resumeFrom) {
            let { snapshot: o, layout: n } = s;
            if (o && n) {
              let r = t.options.layoutAnchor || void 0,
                a = (0, X.createBox)();
              (0, N.calcRelativePosition)(a, e.layoutBox, o.layoutBox, r);
              let l = (0, X.createBox)();
              ((0, N.calcRelativePosition)(l, i, n.layoutBox, r),
                J(a, l) || (h = !0),
                s.options.layoutRoot &&
                  ((t.relativeTarget = l), (t.relativeTargetOrigin = a), (t.relativeParent = s)));
            }
          }
        }
        t.notifyListeners("didUpdate", {
          layout: i,
          snapshot: e,
          delta: a,
          layoutDelta: r,
          hasLayoutChanged: l,
          hasRelativeLayoutChanged: h,
        });
      } else if (t.isLead()) {
        let { onExitComplete: e } = t.options;
        e && e();
      }
      t.options.transition = void 0;
    }
    function ty(t) {
      (v.statsBuffer.value && tu.nodes++,
        t.parent &&
          (t.isProjecting() || (t.isProjectionDirty = t.parent.isProjectionDirty),
          t.isSharedProjectionDirty ||
            (t.isSharedProjectionDirty = !!(
              t.isProjectionDirty ||
              t.parent.isProjectionDirty ||
              t.parent.isSharedProjectionDirty
            )),
          t.isTransformDirty || (t.isTransformDirty = t.parent.isTransformDirty)));
    }
    function tf(t) {
      t.isProjectionDirty = t.isSharedProjectionDirty = t.isTransformDirty = !1;
    }
    function tx(t) {
      t.clearSnapshot();
    }
    function tP(t) {
      t.clearMeasurements();
    }
    function tD(t) {
      ((t.isLayoutDirty = !0), t.updateLayout());
    }
    function tT(t) {
      t.isLayoutDirty = !1;
    }
    function tE(t) {
      t.isAnimationBlocked &&
        t.layout &&
        !t.isLayoutDirty &&
        ((t.snapshot = t.layout), (t.isLayoutDirty = !0));
    }
    function tS(t) {
      let { visualElement: e } = t.options;
      (e && e.getProps().onBeforeLayoutMeasure && e.notify("BeforeLayoutMeasure"), t.resetTransform());
    }
    function tw(t) {
      (t.finishAnimation(),
        (t.targetDelta = t.relativeTarget = t.target = void 0),
        (t.isProjectionDirty = !0));
    }
    function tA(t) {
      t.resolveTargetDelta();
    }
    function tB(t) {
      t.calcProjection();
    }
    function tR(t) {
      t.resetSkewAndRotation();
    }
    function tL(t) {
      t.removeLeadSnapshot();
    }
    function tj(t, e, i) {
      ((t.translate = (0, P.mixNumber)(e.translate, 0, i)),
        (t.scale = (0, P.mixNumber)(e.scale, 1, i)),
        (t.origin = e.origin),
        (t.originPoint = e.originPoint));
    }
    function tV(t, e, i, s) {
      ((t.min = (0, P.mixNumber)(e.min, i.min, s)), (t.max = (0, P.mixNumber)(e.max, i.max, s)));
    }
    function tM(t) {
      return t.animationValues && void 0 !== t.animationValues.opacityExit;
    }
    let tb = { duration: 0.45, ease: [0.4, 0, 0.1, 1] },
      tk = (t) =>
        "u" > typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().includes(t),
      tC = tk("applewebkit/") && !tk("chrome/") ? Math.round : h.noop;
    function tU(t) {
      ((t.min = tC(t.min)), (t.max = tC(t.max)));
    }
    function tI(t, e, i) {
      return "position" === t || ("preserve-aspect" === t && !(0, N.isNear)(Q(e), Q(i), 0.2));
    }
    function tF(t) {
      return t !== t.root && t.scroll?.wasRoot;
    }
    t.s(["cleanDirtyNodes", 0, tf, "createProjectionNode", 0, tp, "propagateDirtyNodes", 0, ty], 920280);
    var tN = t.i(282774);
    let tO = tp({
      attachResizeListener: (t, e) => (0, tN.addDomEvent)(t, "resize", e),
      measureScroll: () => ({
        x: document.documentElement.scrollLeft || document.body?.scrollLeft || 0,
        y: document.documentElement.scrollTop || document.body?.scrollTop || 0,
      }),
      checkIsScrollRoot: () => !0,
    });
    t.s(["DocumentProjectionNode", 0, tO], 71899);
    let tz = { current: void 0 },
      tW = tp({
        measureScroll: (t) => ({ x: t.scrollLeft, y: t.scrollTop }),
        defaultParent: () => {
          if (!tz.current) {
            let t = new tO({});
            (t.mount(window), t.setOptions({ layoutScroll: !0 }), (tz.current = t));
          }
          return tz.current;
        },
        resetTransform: (t, e) => {
          t.style.transform = void 0 !== e ? e : "none";
        },
        checkIsScrollRoot: (t) => "fixed" === window.getComputedStyle(t).position,
      });
    t.s(["HTMLProjectionNode", 0, tW, "rootProjectionNode", 0, tz], 717871);
    let tG = {
      pan: { Feature: n.PanGesture },
      drag: { Feature: o.DragGesture, ProjectionNode: tW, MeasureLayout: r.MeasureLayout },
    };
    t.s(["drag", 0, tG], 646816);
    var t$ = t.i(708149);
    let tH = { layout: { ProjectionNode: tW, MeasureLayout: r.MeasureLayout } };
    t.s(["layout", 0, tH], 454292);
    let tX = { ...s.animations, ...t$.gestureAnimations, ...tG, ...tH },
      tY = (0, i.createMotionProxy)(tX, e.createDomVisualElement);
    t.s(["motion", 0, tY], 846932);
  },
  768705,
  (t) => {
    "use strict";
    var e = t.i(939011),
      i = t.i(486427),
      s = t.i(83411);
    t.s([
      "animateSingleValue",
      0,
      function (t, o, n) {
        let r = (0, s.isMotionValue)(t) ? t : (0, i.motionValue)(t);
        return (r.start((0, e.animateMotionValue)("", r, o, n)), r.animation);
      },
    ]);
  },
  655559,
  137541,
  652101,
  (t) => {
    "use strict";
    t.s(
      [
        "eachAxis",
        0,
        function (t) {
          return [t("x"), t("y")];
        },
      ],
      655559,
    );
    var e = t.i(439676);
    t.s(
      [
        "setDragLock",
        0,
        function (t) {
          if ("x" === t || "y" === t)
            if (e.isDragging[t]) return null;
            else
              return (
                (e.isDragging[t] = !0),
                () => {
                  e.isDragging[t] = !1;
                }
              );
          return e.isDragging.x || e.isDragging.y
            ? null
            : ((e.isDragging.x = e.isDragging.y = !0),
              () => {
                e.isDragging.x = e.isDragging.y = !1;
              });
        },
      ],
      137541,
    );
    var i = t.i(100706);
    function s(t) {
      return t.max - t.min;
    }
    function o(t, e, o) {
      let n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0.5;
      ((t.origin = n),
        (t.originPoint = (0, i.mixNumber)(e.min, e.max, t.origin)),
        (t.scale = s(o) / s(e)),
        (t.translate = (0, i.mixNumber)(o.min, o.max, t.origin) - t.originPoint),
        ((t.scale >= 0.9999 && t.scale <= 1.0001) || isNaN(t.scale)) && (t.scale = 1),
        ((t.translate >= -0.01 && t.translate <= 0.01) || isNaN(t.translate)) && (t.translate = 0));
    }
    function n(t, e, o) {
      let n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
      ((t.min = (n ? (0, i.mixNumber)(o.min, o.max, n) : o.min) + e.min), (t.max = t.min + s(e)));
    }
    function r(t, e, o) {
      let n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
        r = n ? (0, i.mixNumber)(o.min, o.max, n) : o.min;
      ((t.min = e.min - r), (t.max = t.min + s(e)));
    }
    t.s(
      [
        "calcAxisDelta",
        0,
        o,
        "calcBoxDelta",
        0,
        function (t, e, i, s) {
          (o(t.x, e.x, i.x, s ? s.originX : void 0), o(t.y, e.y, i.y, s ? s.originY : void 0));
        },
        "calcLength",
        0,
        s,
        "calcRelativeAxis",
        0,
        n,
        "calcRelativeAxisPosition",
        0,
        r,
        "calcRelativeBox",
        0,
        function (t, e, i, s) {
          (n(t.x, e.x, i.x, s?.x), n(t.y, e.y, i.y, s?.y));
        },
        "calcRelativePosition",
        0,
        function (t, e, i, s) {
          (r(t.x, e.x, i.x, s?.x), r(t.y, e.y, i.y, s?.y));
        },
        "isNear",
        0,
        function (t, e, i) {
          return Math.abs(t - e) <= i;
        },
      ],
      652101,
    );
  },
  880248,
  367807,
  (t) => {
    "use strict";
    t.s(["statsBuffer", 0, { value: null, addProjectionMetrics: null }], 880248);
    var e = t.i(496173),
      i = t.i(763074),
      s = t.i(287022);
    function o(t, i) {
      let o = e.time.now(),
        n = (e) => {
          let { timestamp: r } = e,
            a = r - o;
          a >= i && ((0, s.cancelFrame)(n), t(a - i));
        };
      return (s.frame.setup(n, !0), () => (0, s.cancelFrame)(n));
    }
    t.s(
      [
        "delay",
        0,
        o,
        "delayInSeconds",
        0,
        function (t, e) {
          return o(t, (0, i.secondsToMilliseconds)(e));
        },
      ],
      367807,
    );
  },
  889026,
  (t) => {
    "use strict";
    var e = t.i(642824);
    t.s([
      "isSVGElement",
      0,
      function (t) {
        return (0, e.isObject)(t) && "ownerSVGElement" in t;
      },
    ]);
  },
  836331,
  (t) => {
    "use strict";
    var e = t.i(889026);
    t.s([
      "isSVGSVGElement",
      0,
      function (t) {
        return (0, e.isSVGElement)(t) && "svg" === t.tagName;
      },
    ]);
  },
]);
