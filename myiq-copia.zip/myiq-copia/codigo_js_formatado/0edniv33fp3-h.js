(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  5898,
  976218,
  701708,
  (e) => {
    "use strict";
    var [t, r] = (0, e.i(526823).createContext)({
      name: "CardContext",
      strict: !0,
      errorMessage:
        "useCardContext: `context` is undefined. Seems you forgot to wrap component within <Card />",
    });
    e.s(["CardProvider", 0, t, "useCardContext", 0, r], 976218);
    var a = e.i(984898),
      s = e.i(779754),
      n = (0, a.tv)({
        slots: {
          base: [
            "flex",
            "flex-col",
            "relative",
            "overflow-hidden",
            "h-auto",
            "outline-solid outline-transparent",
            "text-foreground",
            "box-border",
            "bg-content1",
            ...s.dataFocusVisibleClasses,
          ],
          header: [
            "flex",
            "p-3",
            "z-10",
            "w-full",
            "justify-start",
            "items-center",
            "shrink-0",
            "overflow-inherit",
            "color-inherit",
            "subpixel-antialiased",
          ],
          body: [
            "relative",
            "flex",
            "flex-1",
            "w-full",
            "p-3",
            "flex-auto",
            "flex-col",
            "place-content-inherit",
            "align-items-inherit",
            "h-auto",
            "break-words",
            "text-left",
            "overflow-y-auto",
            "subpixel-antialiased",
          ],
          footer: [
            "p-3",
            "h-auto",
            "flex",
            "w-full",
            "items-center",
            "overflow-hidden",
            "color-inherit",
            "subpixel-antialiased",
          ],
        },
        variants: {
          shadow: {
            none: { base: "shadow-none" },
            sm: { base: "shadow-small" },
            md: { base: "shadow-medium" },
            lg: { base: "shadow-large" },
          },
          radius: {
            none: { base: "rounded-none", header: "rounded-none", footer: "rounded-none" },
            sm: { base: "rounded-small", header: "rounded-t-small", footer: "rounded-b-small" },
            md: { base: "rounded-medium", header: "rounded-t-medium", footer: "rounded-b-medium" },
            lg: { base: "rounded-large", header: "rounded-t-large", footer: "rounded-b-large" },
          },
          fullWidth: { true: { base: "w-full" } },
          isHoverable: { true: { base: "data-[hover=true]:bg-content2 dark:data-[hover=true]:bg-content2" } },
          isPressable: { true: { base: "cursor-pointer" } },
          isBlurred: {
            true: {
              base: [
                "bg-background/80",
                "dark:bg-background/20",
                "backdrop-blur-md",
                "backdrop-saturate-150",
              ],
            },
          },
          isFooterBlurred: {
            true: { footer: ["bg-background/10", "backdrop-blur", "backdrop-saturate-150"] },
          },
          isDisabled: { true: { base: "opacity-disabled cursor-not-allowed" } },
          disableAnimation: {
            true: "",
            false: { base: "transition-transform-background motion-reduce:transition-none" },
          },
        },
        compoundVariants: [
          { isPressable: !0, class: "data-[pressed=true]:scale-[0.97] tap-highlight-transparent" },
        ],
        defaultVariants: {
          radius: "lg",
          shadow: "md",
          fullWidth: !1,
          isHoverable: !1,
          isPressable: !1,
          isDisabled: !1,
          isFooterBlurred: !1,
        },
      }),
      i = e.i(271645),
      o = e.i(429427),
      l = e.i(371330),
      u = e.i(868319),
      c = e.i(273830),
      d = e.i(595494),
      m = e.i(75540),
      p = e.i(919477),
      f = e.i(620253),
      g = e.i(984675);
    function h(e) {
      var t, r, a, s;
      let h = (0, d.useProviderContext)(),
        [_, x] = (0, c.mapPropsVariants)(e, n.variantKeys),
        {
          ref: v,
          as: b,
          children: y,
          onClick: C,
          onPress: w,
          autoFocus: S,
          className: E,
          classNames: j,
          allowTextSelectionOnPress: k = !0,
          ...R
        } = _,
        I = (0, f.useDOMRef)(v),
        U = b || (e.isPressable ? "button" : "div"),
        N = "string" == typeof U,
        P = null != (r = null != (t = e.disableAnimation) ? t : null == h ? void 0 : h.disableAnimation) && r,
        T = null != (s = null != (a = e.disableRipple) ? a : null == h ? void 0 : h.disableRipple) && s,
        A = (0, m.clsx)(null == j ? void 0 : j.base, E),
        { onClear: L, onPress: M, ripples: B } = (0, g.useRipple)(),
        D = (0, i.useCallback)(
          (e) => {
            T || P || (I.current && M(e));
          },
          [T, P, I, M],
        ),
        { buttonProps: O, isPressed: F } = (0, u.useAriaButton)(
          {
            onPress: (0, m.chain)(w, D),
            elementType: b,
            isDisabled: !e.isPressable,
            onClick: C,
            allowTextSelectionOnPress: k,
            ...R,
          },
          I,
        ),
        { hoverProps: G, isHovered: H } = (0, l.useHover)({ isDisabled: !e.isHoverable, ...R }),
        { isFocusVisible: q, isFocused: $, focusProps: K } = (0, o.useFocusRing)({ autoFocus: S }),
        V = (0, i.useMemo)(() => n({ ...x, disableAnimation: P }), [(0, m.objectToDeps)(x), P]),
        z = (0, i.useMemo)(
          () => ({
            slots: V,
            classNames: j,
            disableAnimation: P,
            isDisabled: e.isDisabled,
            isFooterBlurred: e.isFooterBlurred,
            fullWidth: e.fullWidth,
          }),
          [V, j, e.isDisabled, e.isFooterBlurred, P, e.fullWidth],
        ),
        Q = (0, i.useCallback)(
          function () {
            let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return {
              ref: I,
              className: V.base({ class: A }),
              tabIndex: e.isPressable ? 0 : -1,
              "data-hover": (0, m.dataAttr)(H),
              "data-pressed": (0, m.dataAttr)(F),
              "data-focus": (0, m.dataAttr)($),
              "data-focus-visible": (0, m.dataAttr)(q),
              "data-disabled": (0, m.dataAttr)(e.isDisabled),
              ...(0, m.mergeProps)(
                e.isPressable ? { ...O, ...K, role: "button" } : {},
                e.isHoverable ? G : {},
                (0, p.filterDOMProps)(R, { enabled: N }),
                (0, p.filterDOMProps)(t),
              ),
            };
          },
          [I, V, A, N, e.isPressable, e.isHoverable, e.isDisabled, H, F, q, O, K, G, R],
        ),
        Y = (0, i.useCallback)(() => ({ ripples: B, onClear: L }), [B, L]);
      return {
        context: z,
        domRef: I,
        Component: U,
        classNames: j,
        children: y,
        isHovered: H,
        isPressed: F,
        disableAnimation: P,
        isPressable: e.isPressable,
        isHoverable: e.isHoverable,
        disableRipple: T,
        handlePress: D,
        isFocusVisible: q,
        getCardProps: Q,
        getRippleProps: Y,
      };
    }
    e.s(["useCard", 0, h], 701708);
    var _ = e.i(860566),
      x = e.i(843476),
      v = (0, c.forwardRef)((e, r) => {
        let {
          children: a,
          context: s,
          Component: n,
          isPressable: i,
          disableAnimation: o,
          disableRipple: l,
          getCardProps: u,
          getRippleProps: c,
        } = h({ ...e, ref: r });
        return (0, x.jsxs)(n, {
          ...u(),
          children: [
            (0, x.jsx)(t, { value: s, children: a }),
            i && !o && !l && (0, x.jsx)(_.Ripple, { ...c() }),
          ],
        });
      });
    ((v.displayName = "HeroUI.Card"), e.s(["card_default", 0, v], 5898));
  },
  520837,
  (e) => {
    "use strict";
    var t = e.i(5898);
    e.s(["Card", () => t.card_default]);
  },
  641711,
  (e, t, r) => {
    "use strict";
    function a(e) {
      return (a =
        "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
          ? function (e) {
              return typeof e;
            }
          : function (e) {
              return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype
                ? "symbol"
                : typeof e;
            })(e);
    }
    Object.defineProperty(r, "__esModule", { value: !0 });
    var s,
      n = "basil",
      i = "https://js.stripe.com",
      o = "".concat(i, "/").concat(n, "/stripe.js"),
      l = /^https:\/\/js\.stripe\.com\/v3\/?(\?.*)?$/,
      u = /^https:\/\/js\.stripe\.com\/(v3|[a-z]+)\/stripe\.js(\?.*)?$/,
      c =
        "loadStripe.setLoadParameters was called but an existing Stripe.js script already exists in the document; existing script parameters will be used",
      d = function () {
        for (var e = document.querySelectorAll('script[src^="'.concat(i, '"]')), t = 0; t < e.length; t++) {
          var r,
            a = e[t];
          if (((r = a.src), l.test(r) || u.test(r))) return a;
        }
        return null;
      },
      m = function (e) {
        var t = e && !e.advancedFraudSignals ? "?advancedFraudSignals=false" : "",
          r = document.createElement("script");
        r.src = "".concat(o).concat(t);
        var a = document.head || document.body;
        if (!a) throw Error("Expected document.body not to be null. Stripe.js requires a <body> element.");
        return (a.appendChild(r), r);
      },
      p = function (e, t) {
        e && e._registerWrapper && e._registerWrapper({ name: "stripe-js", version: "7.9.0", startTime: t });
      },
      f = null,
      g = null,
      h = null,
      _ = function (e, t, r) {
        if (null === e) return null;
        var a,
          s = t[0].match(/^pk_test/),
          i = 3 === (a = e.version) ? "v3" : a;
        s &&
          i !== n &&
          console.warn(
            "Stripe.js@"
              .concat(i, " was loaded on the page, but @stripe/stripe-js@")
              .concat("7.9.0", " expected Stripe.js@")
              .concat(
                n,
                ". This may result in unexpected behavior. For more information, see https://docs.stripe.com/sdks/stripejs-versioning",
              ),
          );
        var o = e.apply(void 0, t);
        return (p(o, r), o);
      },
      x = function (e) {
        var t =
          "invalid load parameters; expected object of shape\n\n    {advancedFraudSignals: boolean}\n\nbut received\n\n    ".concat(
            JSON.stringify(e),
            "\n",
          );
        if (null === e || "object" !== a(e)) throw Error(t);
        if (1 === Object.keys(e).length && "boolean" == typeof e.advancedFraudSignals) return e;
        throw Error(t);
      },
      v = !1,
      b = function () {
        for (var e, t = arguments.length, r = Array(t), a = 0; a < t; a++) r[a] = arguments[a];
        v = !0;
        var n = Date.now();
        return ((e = s),
        null !== f
          ? f
          : (f = new Promise(function (t, r) {
              if ("u" < typeof window || "u" < typeof document) return void t(null);
              if ((window.Stripe && e && console.warn(c), window.Stripe)) return void t(window.Stripe);
              try {
                var a,
                  s = d();
                (s && e
                  ? console.warn(c)
                  : s
                    ? s &&
                      null !== h &&
                      null !== g &&
                      (s.removeEventListener("load", h),
                      s.removeEventListener("error", g),
                      null == (a = s.parentNode) || a.removeChild(s),
                      (s = m(e)))
                    : (s = m(e)),
                  (h = function () {
                    window.Stripe ? t(window.Stripe) : r(Error("Stripe.js not available"));
                  }),
                  (g = function (e) {
                    r(Error("Failed to load Stripe.js", { cause: e }));
                  }),
                  s.addEventListener("load", h),
                  s.addEventListener("error", g));
              } catch (e) {
                r(e);
                return;
              }
            })).catch(function (e) {
              return ((f = null), Promise.reject(e));
            })).then(function (e) {
          return _(e, r, n);
        });
      };
    ((b.setLoadParameters = function (e) {
      if (!(
        v &&
        s &&
        Object.keys(x(e)).reduce(function (t, r) {
          var a;
          return t && e[r] === (null == (a = s) ? void 0 : a[r]);
        }, !0)
      )) {
        if (v) throw Error("You cannot change load parameters after calling loadStripe");
        s = x(e);
      }
    }),
      (r.loadStripe = b));
  },
  709275,
  (e, t, r) => {
    t.exports = e.r(641711);
  },
  600304,
  (e) => {
    "use strict";
    var t = e.i(933818);
    e.i(471086);
    var r = e.i(887541),
      a = e.i(95187);
    let s = (0, a.createServerReference)(
      "609d70875bf386b20f2ad08b49a5e5dbf9a4e446af",
      a.callServer,
      void 0,
      a.findSourceMapURL,
      "getReviewsContentByLocale",
    );
    var n = e.i(81844);
    let i = async (e, t) => {
      try {
        let a = await n.httpInstance
          .get(`${r.EReviewsApi.API_REVIEWS}/${t}`, {
            signal: e.signal,
            cache: "force-cache",
            next: { revalidate: 3600 },
          })
          .json();
        if (!a) return { data: void 0, success: !1 };
        return { data: a, success: !0 };
      } catch {
        return { data: void 0, success: !1 };
      }
    };
    e.s(
      [
        "reviewsGeneralQueryOptions",
        0,
        (e, a) =>
          (0, t.queryOptions)({
            queryKey: [r.EReviewsKey.REVIEWS_GENERAL_QUERY, e, a],
            queryFn: () => s(e, [a]),
            staleTime: 6e5,
            gcTime: 9e5,
          }),
        "reviewsQueryOptions",
        0,
        (e) =>
          (0, t.queryOptions)({
            queryKey: [r.EReviewsKey.REVIEWS_QUERY, e],
            queryFn: (t) => i(t, e),
            select: (e) => e?.data || null,
            staleTime: 6e5,
            gcTime: 9e5,
          }),
      ],
      600304,
    );
  },
  733344,
  208507,
  (e) => {
    "use strict";
    (e.s([], 733344), e.s(["useCheckout", () => g], 208507));
    var t = e.i(948148),
      r = e.i(271645),
      a = e.i(985272);
    e.i(122612);
    var s = e.i(225352),
      n = e.i(311165),
      i = e.i(86596),
      o = e.i(59857),
      l = e.i(915113);
    e.i(470366);
    var u = e.i(504001),
      c = e.i(202042);
    e.i(756503);
    var d = e.i(542516),
      m = e.i(86497);
    let p = function (e, t) {
      let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
      return {
        ...(e?.sessions || {}),
        app_version: "v2",
        user_id: e?.id || "",
        locale: e?.locale || "en",
        ipAddress: e?.ip || "",
        user_agent: e?.user_agent || "",
        operating_system: e?.operating_system || "",
        device_fingerprint: m.default.peopleGetDistinctId(),
        account_id: e?.email || "",
        email: e?.email || "",
        user_email: e?.email || "",
        supabase_user_id: e?.id || "",
        mixpanel_user_id: e?.id || "",
        sub_order_country: e?.currency?.countryCode || "",
        product_name: "myiq",
        flow_type: "web_onboarding",
        funnel: t,
        subscriptionType: "APP_SUBSCRIPTION",
        application: `${d.envClient.NEXT_PUBLIC_PAYMENT_ENV}`,
        hostname: `${d.envClient.NEXT_PUBLIC_BILLING_HOSTNAME}`,
        ...r,
      };
    };
    var f = e.i(134404);
    let g = (e) => {
      let { variant: d, userToken: m, marketingParams: g, metadata: h, experiments: _ = {} } = e,
        x = (0, t.useTranslations)(),
        v = (0, c.useRouter)(),
        b = (0, i.useUserStore)((e) => e.user),
        y = (0, n.useLoveLanguageQuizStore)((e) => e.love_language_type_result),
        { isUserRestoring: C } = (0, s.useCheckoutUserRestore)(),
        [w, S] = (0, r.useState)(h),
        [E, j] = (0, r.useState)(() => i.useUserStore.persist?.hasHydrated() ?? !1),
        k = (0, l.getIsMarketingSource)(),
        R = b?.paymentInfo?.paymentMethod === a.PaymentMethod.PAYPAL;
      return (
        (0, r.useEffect)(() => i.useUserStore.persist.onFinishHydration(() => j(!0)), []),
        (0, r.useEffect)(() => {
          if (!E || C) return;
          let e = i.useUserStore.getState().user;
          if (
            !m &&
            !(0, o.hasValidMarketingParams)(g || {}) &&
            !e?.email &&
            !e?.paymentInfo?.paynextClientSessionId &&
            !y
          ) {
            let e = ((e) => {
              switch (e) {
                case "personality":
                  return f.EClientRoutes.EMAIL_PERSONALITY;
                case "love_language":
                  return f.EClientRoutes.EMAIL_LOVE;
                case "depression":
                  return f.EClientRoutes.EMAIL_DEPRESSION_FUNNEL;
                case "autism":
                  return f.EClientRoutes.EMAIL_AUTISM;
                case "enneagram":
                  return f.EClientRoutes.EMAIL_ENNEAGRAM;
                default:
                  return f.EClientRoutes.EMAIL;
              }
            })(d);
            v.replace(e);
          }
        }, [E, C, m, g, b?.email, b?.paymentInfo?.paynextClientSessionId, d, y]),
        (0, r.useEffect)(() => {
          b && S(p(b, d));
        }, [d, b]),
        (0, r.useEffect)(() => {
          C ||
            (0, u.setPeopleAnalytic)({
              ...(k && !R && { ab_myiq_trivia_popup_upsell: _.abMyiqTriviaPopupUpsell }),
            });
        }, [C]),
        { t: x, user: b, metadata: w }
      );
    };
  },
  842582,
  76399,
  (e) => {
    "use strict";
    var t = e.i(618566),
      r = e.i(271645);
    e.i(879568);
    var a = e.i(480408),
      s = e.i(866897),
      n = e.i(924254),
      i = e.i(5117);
    (e.s(
      [
        "useCollectParams",
        0,
        () => {
          let e,
            o = (0, t.useSearchParams)(),
            [l, u] = (0, r.useState)(null),
            [c, d] = (0, r.useState)(!1),
            m = () => {
              let e = o ? new URLSearchParams(o.toString()) : void 0,
                t = a.attributionUtil.collectAttributionData(e);
              (0, i.getClientAnalyticsConsent)().allowed && a.attributionUtil.saveAttributionData(t);
              let r = a.attributionUtil.readAttributionData() ?? t;
              return (u(r), d(!0), r);
            },
            p = () => l || a.attributionUtil.readAttributionData();
          return (
            (0, r.useEffect)(() => {
              c || m();
            }, [o, c]),
            {
              attributionData: p(),
              isInitialized: c,
              initializeAttribution: m,
              getAttributionMetadata: () => {
                let e = p();
                return a.attributionUtil.formatForPaymentMetadata(e);
              },
              clearAttribution: () => {
                (n.accessCookie.removeItem(s.ECookieArg.ATTRIBUTION_STORAGE_KEY), u(null));
              },
              hasAttribution: null !== (e = p()) && Object.keys(e).length > 0,
              getAttributionData: p,
            }
          );
        },
      ],
      76399,
    ),
      e.s([], 842582));
  },
  613488,
  (e) => {
    "use strict";
    e.s([
      "pickRealUser",
      0,
      (e) => {
        if (!e || 0 === e.length) return null;
        let t = e[Math.floor(Math.random() * e.length)];
        return { id: Math.random().toString(), surName: "", ...t };
      },
    ]);
  },
  677048,
  576728,
  13126,
  949463,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(88653),
      a = e.i(962607),
      s = e.i(444113),
      n = e.i(824511),
      i = e.i(948148),
      o = e.i(271645),
      l = e.i(663615),
      u = e.i(926654),
      c = e.i(331890);
    e.i(122612);
    var d = e.i(225352);
    e.i(743893);
    var m = e.i(852016),
      p = e.i(171770),
      f = e.i(386847),
      g = e.i(129466),
      h = e.i(458350),
      _ = e.i(869404),
      x = e.i(51653),
      v = e.i(295592),
      b = e.i(263970),
      y = e.i(613488);
    let C = (0, o.memo)((e) => {
      var C;
      let {
          isPersonality: w,
          isSlow: S,
          isEnneagram: E,
          isLove: j,
          isDepression: k,
          isAutism: R,
          userSyncEnabled: I = !1,
          className: U,
          realUsers: N,
          isMyiq: P,
          scrollTarget: T,
        } = e,
        A = (0, i.useTranslations)(),
        { isUserRestoring: L } = (0, d.useCheckoutUserRestore)(),
        { generateUsers: M } = (0, h.useGeneratedUser)(),
        B = (0, o.useCallback)(M, []),
        { users: D } = (0, v.useGeneratedUsersStore)(),
        O = (0, b.useGlobalStore)((e) => e.setAutoScrolling),
        [F, G] = (0, o.useState)(null),
        H = (0, f.getClientCountry)()?.toUpperCase(),
        q = (0, g.getCountryDataFromLocalStorage)(),
        $ = q?.currentCountry?.code?.toUpperCase() === H ? q : null,
        K = $
          ? {
              currentCountry: { code: $?.currentCountry?.code, names: $?.currentCountry?.names },
              neighboringCountries: $?.neighboringCountries,
            }
          : void 0,
        { data: V } = (0, c.useGetNeighborCountriesFromCountryData)(H, !K),
        z = (0, o.useMemo)(
          () => K || V,
          [
            K?.currentCountry?.code,
            K?.neighboringCountries?.length,
            V?.currentCountry?.code,
            V?.neighboringCountries?.length,
          ],
        ),
        Q = (0, o.useMemo)(() => {
          if (!N || !z) return;
          let e = new Set([
            z.currentCountry.code.toUpperCase(),
            ...z.neighboringCountries.map((e) => e.code.toUpperCase()),
          ]);
          return N.filter((t) => e.has(t.country.toUpperCase()));
        }, [N, z]);
      (0, o.useEffect)(() => {
        (0, p.preloadFlags)([
          ...(Q?.map((e) => e.country) ?? []),
          z?.currentCountry?.code,
          ...(z?.neighboringCountries?.map((e) => e.code) ?? []),
        ]);
      }, [Q, z]);
      let Y = (0, o.useRef)(D),
        W = (0, o.useRef)(z),
        X = (0, o.useRef)(B),
        J = (0, o.useRef)(Q);
      return (
        (0, o.useEffect)(() => {
          Y.current = D;
        }, [D]),
        (0, o.useEffect)(() => {
          W.current = z;
        }, [z]),
        (0, o.useEffect)(() => {
          X.current = B;
        }, [B]),
        (0, o.useEffect)(() => {
          J.current = Q;
        }, [Q]),
        (0, o.useEffect)(() => {
          let e = setInterval(
            () => {
              if (N) {
                let e = (0, y.pickRealUser)(J.current);
                if (e) return void G([e]);
              }
              if (I) {
                let e = Y.current;
                e && e.length > 0 && G([e[Math.floor(Math.random() * Math.min(4, e.length))]]);
              } else {
                let e = W.current,
                  t = X.current;
                e && t && G(t(1, e));
              }
            },
            S ? (0, _.getRandomInterval)(8e3, 11e3) : 4e3,
          );
          return () => {
            clearInterval(e);
          };
        }, [I, S, N]),
        (0, o.useEffect)(() => {
          if (Q && Q.length > 0) {
            let e = (0, y.pickRealUser)(Q);
            if (e) return void G([e]);
          }
          I ? D && D.length > 0 && G([D[Math.floor(Math.random() * D.length)]]) : z && G(B(1, z));
        }, [D, I, z, B, Q]),
        (0, t.jsx)(s.LazyMotion, {
          features: a.domAnimation,
          children: (0, t.jsx)("div", {
            onClick: () =>
              P || w || R || E
                ? void (O(!0, 750), (0, x.scrollToBlock)(T ?? "checkout-coupon-disclaimer"))
                : null,
            id: "checkout-top-banner",
            className: (0, l.cn)(
              "fixed left-0 top-0 z-[100] flex h-10 w-full items-center justify-center bg-zinc-100 px-1 text-center text-black shadow-small transition-all duration-300 md:h-[52px]",
              (P || w || R || E) && "cursor-pointer",
              U,
            ),
            children: (0, t.jsx)(r.AnimatePresence, {
              mode: "wait",
              children:
                F && !L
                  ? (0, t.jsxs)(
                      n.m.div,
                      {
                        id: "person-info",
                        initial: { opacity: 0, y: -30 },
                        animate: { opacity: 1, y: 0 },
                        exit: { opacity: 0 },
                        className: (0, l.cn)(
                          "flex flex-wrap items-center justify-center text-xs font-normal",
                          k && "max-w-full flex-nowrap overflow-hidden",
                        ),
                        children: [
                          (0, t.jsxs)("div", {
                            id: "gender",
                            className: (0, l.cn)(k && "flex min-w-0 items-center overflow-hidden"),
                            children: [
                              k &&
                                F[0]?.country !== "" &&
                                (0, t.jsx)("div", {
                                  className:
                                    "mx-1 mt-0 h-[19px] w-[26px] flex-shrink-0 overflow-hidden rounded-[3px] max-[360px]:h-4 max-[360px]:w-5",
                                  children: (0, t.jsx)(m.Flag, {
                                    className: "h-full w-full object-cover",
                                    code: F[0].country,
                                    alt: F[0].country,
                                    loading: "eager",
                                  }),
                                }),
                              (0, t.jsx)("span", {
                                className: (0, l.cn)("mx-1 font-semibold", k && "shrink-0"),
                                children: F[0].name,
                              }),
                              (0, t.jsx)("span", {
                                className: (0, l.cn)(k && "truncate"),
                                children:
                                  ((C = F[0]),
                                  A(
                                    w
                                      ? C?.sex === "male"
                                        ? "checkout_page_just_personality_male"
                                        : "checkout_page_just_personality_female"
                                      : j
                                        ? C?.sex === "male"
                                          ? "checkout_page_just_love_male"
                                          : "checkout_page_just_love_female"
                                        : k
                                          ? C?.sex === "male"
                                            ? "checkout_page_just_depression_male"
                                            : "checkout_page_just_depression_female"
                                          : R
                                            ? C?.sex === "male"
                                              ? "checkout_page_just_autism_male"
                                              : "checkout_page_just_autism_female"
                                            : E
                                              ? C?.sex === "male"
                                                ? "checkout_page_just_enneagram_male"
                                                : "checkout_page_just_enneagram_female"
                                              : C?.sex === "male"
                                                ? "checkout_page_just_bought_male"
                                                : "checkout_page_just_bought_female",
                                  )),
                              }),
                            ],
                          }),
                          (0, t.jsxs)("div", {
                            className: "mx-2 flex items-center gap-1",
                            children: [
                              !k &&
                                F[0]?.country !== "" &&
                                (0, t.jsx)("div", {
                                  className:
                                    "mt-0 h-[19px] w-[26px] flex-shrink-0 overflow-hidden rounded-[3px] max-[360px]:h-4 max-[360px]:w-5",
                                  children: (0, t.jsx)(m.Flag, {
                                    className: "h-full w-full object-cover",
                                    code: F[0].country,
                                    alt: F[0].country,
                                    loading: "eager",
                                  }),
                                }),
                              !j &&
                                !w &&
                                !k &&
                                !R &&
                                !E &&
                                (0, t.jsxs)("div", {
                                  id: "score",
                                  className: "flex gap-1 font-semibold text-[#1e41c7]",
                                  children: [
                                    (0, t.jsx)("span", { className: "uppercase", children: A("iq") }),
                                    " ",
                                    F[0]?.count,
                                  ],
                                }),
                            ],
                          }),
                        ],
                      },
                      `client-${F[0].id}}-${Date.now()}`,
                    )
                  : (0, t.jsx)(u.Skeleton, { className: "h-6 w-full max-w-[348px] rounded-xl" }),
            }),
          }),
        })
      );
    });
    (e.s([], 677048), e.s(["TopBannerComponent", 0, C], 576728));
    var w = e.i(449496);
    e.i(346392);
    var S = e.i(296301);
    let E = (0, e.i(770703).default)(() => e.A(120077), { loadableGenerated: { modules: [314307] } });
    var j = e.i(75540),
      k = e.i(47252);
    e.i(655638);
    var R = e.i(175761),
      I = e.i(523173);
    e.i(568267);
    var U = e.i(154692);
    e.i(470366);
    var N = e.i(504001);
    let P = (e) => {
        let {
            user: r,
            className: a,
            funnel: s,
            scrollTarget: n = "checkout-coupon-disclaimer",
            isBrainTrain: o,
          } = e,
          u = (0, b.useGlobalStore)((e) => e.setAutoScrolling);
        return (0, t.jsx)(U.ButtonComponent, {
          id: "checkout-first-cta-section",
          text: ((e, t) => {
            let r = (0, i.useTranslations)(),
              a = r("btn_checkout_get_my_certificate");
            switch (e) {
              case "personality":
                return r("btn_see_personality_type");
              case "depression":
                return r("btn_checkout_get_my_depression_report");
              case "autism":
                return r("btn_see_autism_profile");
              case "enneagram":
                return r("enneagram_checkout_cta");
              default:
                return t ? r("btn_checkout_get_improvement_plan") : a;
            }
          })(s, o),
          size: "md",
          className: (0, l.cn)("max-w-[406px] lg:w-3/4", a),
          onClick: () => {
            (u(!0, 750),
              (0, x.scrollToBlock)(n),
              (0, N.trackClientEvents)({
                event: I.EAnalyticEvents.PAGE_CLICKED,
                params: {
                  page_name: "getMyIQCertificateButtonClicked",
                  page_title: "Checkout",
                  funnel: s || "myiq",
                },
                user: r,
              }));
          },
        });
      },
      T = (e) => {
        let {
            className: r,
            children: a,
            title: s,
            titleSecond: n,
            funnel: o,
            user: l,
            childrenClassName: u,
            scrollTarget: c,
            isBrainTrain: d,
          } = e,
          m = (0, i.useTranslations)();
        return (0, t.jsxs)("section", {
          className: r,
          children: [
            (0, t.jsxs)("div", {
              className: (0, j.clsx)("flex w-full flex-col gap-4 md:gap-6 lg:order-2"),
              children: [
                (0, t.jsx)("div", {
                  className: (0, j.clsx)(
                    "flex min-h-[300px] w-full max-w-[550px] items-end gap-1.5 max-lg:mx-auto xs-l:gap-2 lg:order-2 lg:ml-[30px] lg:max-w-none lg:gap-6",
                    u,
                  ),
                  children: a,
                }),
                n
                  ? (0, t.jsxs)("h1", {
                      className:
                        "text-center text-2xl font-semibold leading-tight tracking-normal text-gray-900 max-[320px]:text-xl sm:text-3xl lg:hidden lg:w-full",
                      children: [
                        s,
                        (0, t.jsx)("br", {}),
                        (0, t.jsx)("span", { className: "text-primary", children: n }),
                      ],
                    })
                  : (0, t.jsx)("h1", {
                      className:
                        "text-center text-2xl font-semibold leading-tight tracking-normal text-gray-900 max-[320px]:text-xl sm:text-3xl lg:hidden lg:w-full",
                      dangerouslySetInnerHTML: { __html: (0, k.sanitizeTranslationHtml)(s) },
                    }),
              ],
            }),
            (0, t.jsxs)("div", {
              className:
                "grid h-fit justify-items-center gap-8 text-center max-sm:px-4 lg:order-1 lg:max-w-[550px] lg:justify-items-start lg:gap-6 lg:justify-self-start lg:text-left",
              children: [
                n
                  ? (0, t.jsxs)("h1", {
                      className:
                        "text-2xl font-semibold leading-tight tracking-normal text-gray-900 max-lg:hidden max-[320px]:text-xl sm:text-3xl lg:w-full lg:text-[36px]",
                      children: [
                        s,
                        (0, t.jsx)("br", {}),
                        (0, t.jsx)("span", { className: "text-primary", children: n }),
                      ],
                    })
                  : (0, t.jsx)("h1", {
                      className:
                        "text-2xl font-semibold leading-tight tracking-normal text-gray-900 max-lg:hidden max-[320px]:text-xl sm:text-3xl lg:w-full lg:text-[36px]",
                      dangerouslySetInnerHTML: { __html: (0, k.sanitizeTranslationHtml)(s) },
                    }),
                (0, t.jsx)("div", {
                  className: "flex w-full max-w-[400px] flex-col items-center gap-2 lg:max-w-[320px]",
                  children: (0, t.jsx)(P, {
                    className: (0, j.clsx)(
                      "!w-full animate-pulse !text-lg max-[375px]:!text-base max-[320px]:!text-lg",
                      "personality" === o && "text-wrap",
                    ),
                    user: l,
                    funnel: o,
                    scrollTarget: c,
                    isBrainTrain: d,
                  }),
                }),
              ],
            }),
            (0, t.jsxs)("div", {
              className: "absolute bottom-9 order-3 w-full overflow-hidden px-6",
              children: [
                (0, t.jsx)("p", {
                  className: "mb-4 text-center text-sm font-medium text-[#638FB1]",
                  children: m("logo_scroller_featured_in"),
                }),
                (0, t.jsx)(R.LogoScrollerComponent, { funnel: o, isBlue: !0 }),
              ],
            }),
            (0, t.jsx)("span", {
              className:
                "absolute left-[-50vw] top-0 z-[-1] order-4 h-full w-[200vw] bg-gradient-to-tr from-sky-50 via-blue-100 to-slate-50",
            }),
          ],
        });
      };
    var A = e.i(915113);
    (e.s([], 13126),
      e.s(
        [
          "CheckoutIntroComponent",
          0,
          (e) => {
            let {
                user: r,
                variant: a,
                abMyiqPromoPrice: s,
                scrollTarget: n,
                showCertificateHero: o,
                isBrainTrain: u,
                isPaymentAboveFold: c,
                selectedHeroId: d,
              } = e,
              { title: m, titleSecond: p } = ((e) => {
                let { variant: t, isBrainTrain: r } = e,
                  a = (0, i.useTranslations)();
                switch (t) {
                  case "personality":
                    return { title: a.raw("checkout_personality_page_intro_title_second") };
                  case "autism":
                    return { title: a.raw("checkout_autism_page_intro_title") };
                  case "depression":
                    return {
                      title: a.raw("checkout_depression_page_intro_title"),
                      titleSecond: a("checkout_depression_page_intro_subtitle"),
                    };
                  case "enneagram":
                    return { title: a.raw("checkout_enneagram_page_intro_title") };
                  default:
                    if (r)
                      return {
                        title: a("paywall_headline_congratulations_confetti"),
                        titleSecond: a("blured_preview_component_results_ready"),
                      };
                    return {
                      title: a("paywall_headline_congratulations_confetti"),
                      titleSecond: a("paywall_subtitle_your_score_is_ready"),
                    };
                }
              })({ variant: a, isBrainTrain: u }),
              f = (0, A.getIsMarketingSource)(),
              g = (0, b.useGlobalStore)((e) => e.checkoutTimerExpired),
              h = (0, w.isMyiqVariant)(a),
              _ = g && !("promo_price" === s && f) && "personality" !== a;
            return (0, t.jsx)(S.PaywallConfettiComponent, {
              funnel: a,
              children: (0, t.jsx)(T, {
                user: r,
                funnel: a,
                title: m,
                titleSecond: p,
                isBrainTrain: u,
                className: (0, l.cn)(
                  "relative z-0 grid items-center gap-6 pb-[120px] pt-[50px] lg:grid-cols-[1fr_558px]",
                  "lg:justify-items-end lg:gap-8 lg:pb-[115px] lg:pt-[117px]",
                  c && "lg:hidden",
                  !h && (_ ? "lg:!pt-[100px]" : ""),
                  h && (_ ? "pt-0 lg:!pt-[8px]" : "pt-5 xs-sm:pt-[50px] lg:!pt-[90px]"),
                ),
                childrenClassName: (0, l.cn)(h && "lg:!ml-0", o && "scale-[0.9]"),
                scrollTarget: n,
                children: (0, t.jsx)(E, {
                  variant: a,
                  scrollTarget: n,
                  showCertificateHero: o,
                  selectedHeroId: d,
                }),
              }),
            });
          },
        ],
        949463,
      ));
  },
  841826,
  991604,
  (e) => {
    "use strict";
    var t = e.i(690405);
    (e.s([], 841826), e.s(["ReviewsCarouselComponent", () => t.default], 991604));
  },
  690405,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(770703),
      a = e.i(861745),
      s = e.i(869230),
      n = e.i(469637),
      i = e.i(254440),
      o = e.i(600304);
    let l = (0, r.default)(() => e.A(570387).then((e) => e.CarouselNewComponent), {
        loadableGenerated: { modules: [998909] },
      }),
      u = (0, r.default)(() => e.A(136347).then((e) => e.RateStatComponent), {
        loadableGenerated: { modules: [97316] },
      }),
      c = (0, r.default)(() => e.A(772621).then((e) => e.ReviewsTitleComponent), {
        loadableGenerated: { modules: [366126] },
      }),
      d = (0, r.default)(() => e.A(703719).then((e) => e.TrustpilotCarouselComponent), {
        loadableGenerated: { modules: [783491] },
      });
    e.s(
      [
        "default",
        0,
        (e) => {
          var r, m;
          let {
              withTitle: p,
              withoutRatings: f,
              isPersonality: g,
              isLove: h,
              generalReviews: _,
              rating: x,
              ratingForText: v,
              clickableReviews: b,
              whiteCards: y,
            } = e,
            C = (0, a.useLocale)(),
            w = (r = { generalReviews: _, isPersonality: g, isLove: h }).generalReviews
              ? "general"
              : r.isPersonality
                ? "personality_test"
                : r.isLove
                  ? "love_language"
                  : "",
            { data: S } =
              ((m = (0, o.reviewsQueryOptions)(C)),
              (0, n.useBaseQuery)(
                {
                  ...m,
                  enabled: !0,
                  suspense: !0,
                  throwOnError: i.defaultThrowOnError,
                  placeholderData: void 0,
                },
                s.QueryObserver,
                void 0,
              ));
          return (0, t.jsxs)("section", {
            className: "mx-auto grid w-full justify-items-center gap-5",
            children: [
              p ? (0, t.jsx)(c, {}) : null,
              f ? null : (0, t.jsx)(u, { reviews: S, rating: x, ratingForText: v }),
              g || h || _ ? (0, t.jsx)(l, { tag: w }) : (0, t.jsx)(d, { isClickable: b, whiteCards: y }),
            ],
          });
        },
      ],
      690405,
    );
  },
  478272,
  (e) => {
    "use strict";
    let t = (0, e.i(770703).default)(() => e.A(643378), { loadableGenerated: { modules: [608187] } });
    e.s(["CheckoutTimerBannerComponent", 0, t]);
  },
  346392,
  296301,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(271645),
      a = e.i(157273),
      s = e.i(190899),
      n = e.i(449496);
    (e.s([], 346392),
      e.s(
        [
          "PaywallConfettiComponent",
          0,
          (i) => {
            let { children: o, funnel: l, onComplete: u } = i,
              c = (0, r.useRef)(null),
              d = (0, r.useRef)(null),
              m = s.accessSessionStorageUtil.getItem(a.StorageKeys.HAS_TRIGGERED_CONFETTI),
              [p, f] = (0, r.useState)(null);
            (0, r.useEffect)(() => {
              f({ width: window.innerWidth, height: window.innerHeight });
            }, []);
            let g = (0, n.isMyiqVariant)(l);
            return (
              (0, r.useEffect)(() => {
                if (!p) return;
                if (!g || m) return void u?.();
                if (!d.current) return;
                let t = !1,
                  r = null;
                return (
                  e.A(80233).then((e) => {
                    let { default: n } = e;
                    if (t || !d.current) return;
                    let i = n.create(d.current, { resize: !0, useWorker: !1 });
                    r = setTimeout(() => {
                      m ||
                        (s.accessSessionStorageUtil.setItem(a.StorageKeys.HAS_TRIGGERED_CONFETTI, "true"),
                        Promise.all([
                          i({ particleCount: 80, spread: 70, angle: 60, origin: { x: 0, y: 1 } }),
                          i({ particleCount: 80, spread: 70, angle: 120, origin: { x: 1, y: 1 } }),
                        ]).then(() => u?.()));
                    }, 300);
                  }),
                  () => {
                    ((t = !0), r && clearTimeout(r));
                  }
                );
              }, [p, g, m]),
              (0, t.jsxs)(t.Fragment, {
                children: [
                  (0, t.jsx)("div", { ref: c, children: o }),
                  p &&
                    (0, t.jsx)("canvas", {
                      ref: d,
                      className: "pointer-events-none fixed inset-0 z-[999999]",
                      height: p.height,
                      width: p.width,
                      style: { width: "100vw", height: "100vh" },
                    }),
                ],
              })
            );
          },
        ],
        296301,
      ));
  },
  893826,
  798254,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(271645),
      a = e.i(225352);
    (e.s([], 798254),
      e.s(
        [
          "default",
          0,
          (e) => {
            let { isUserRestoring: s, children: n } = e,
              [i, o] = (0, r.useState)(!1),
              l = (0, r.useCallback)(() => o(!0), []),
              u = (0, r.useMemo)(() => ({ isUserRestoring: s && !i, finishUserRestore: l }), [s, i, l]);
            return (0, t.jsx)(a.CheckoutUserRestoreContext.Provider, { value: u, children: n });
          },
        ],
        893826,
      ));
  },
  225352,
  (e) => {
    "use strict";
    var t = e.i(271645);
    let r = (0, t.createContext)({ isUserRestoring: !1, finishUserRestore: () => void 0 });
    e.s(["CheckoutUserRestoreContext", 0, r, "useCheckoutUserRestore", 0, () => (0, t.useContext)(r)]);
  },
  122612,
  (e) => {
    "use strict";
    (e.i(893826), e.i(798254), e.s([]));
  },
  179881,
  (e) => {
    "use strict";
    var t = e.i(271645);
    e.i(842582);
    var r = e.i(76399);
    e.i(122612);
    var a = e.i(225352),
      s = e.i(715413),
      n = e.i(523173),
      i = e.i(134404),
      o = e.i(86596);
    let l = (e) => {
      "requestIdleCallback" in window ? requestIdleCallback(e, { timeout: 2e3 }) : setTimeout(e, 0);
    };
    e.i(238275);
    var u = e.i(712470),
      c = e.i(812384),
      d = e.i(802774),
      m = e.i(495495);
    e.i(470366);
    var p = e.i(504001);
    e.i(491877);
    var f = e.i(178668),
      g = e.i(202042);
    e.s(
      [
        "default",
        0,
        (e) => {
          let {
              userToken: h,
              pushNotificationVersionQuery: _ = "fallback",
              isFreeVersion: x,
              userData: v,
            } = e,
            { changeQuery: b } = (0, m.useQuerySearchParams)(),
            y = (0, g.useRouter)(),
            C = (0, o.useUserStore)((e) => e.user),
            w = (0, o.useUserStore)((e) => e.handleChangeUserStore),
            S = (0, t.useRef)(!1),
            E = (0, t.useRef)(!1),
            j = (0, t.useRef)(!0),
            { trigger: k } = (0, u.useCreateSessionMutation)(),
            { trigger: R } = (0, c.useCreateUserSessionMutation)(),
            { deviceData: I } = (0, s.useBraintreeDataCollector)(),
            { getAttributionData: U } = (0, r.useCollectParams)(),
            { finishUserRestore: N } = (0, a.useCheckoutUserRestore)();
          (0, t.useEffect)(
            () => () => {
              j.current = !1;
            },
            [],
          );
          let P = (e) => ({
              ...v,
              ...e,
              id: v?.id || e?.id,
              email: v?.email?.trim() || e?.email?.trim(),
              currency: e?.currency || v?.currency,
              paymentInfo: { ...v?.paymentInfo, ...e?.paymentInfo, customerId: v?.id || e?.id },
            }),
            T = async () => {
              v && w({ user: P(C || null) });
            };
          return (
            (0, t.useEffect)(() => {
              if (
                C &&
                !S.current &&
                j.current &&
                C &&
                I &&
                (!C || C.currency) &&
                (C &&
                  h &&
                  ((S.current = !0),
                  T(),
                  R({
                    ...(U() || {}),
                    userData: P(C),
                    deviceData: "string" == typeof I ? I : JSON.stringify(I) || "",
                  })
                    .then(async () => {
                      h &&
                        j.current &&
                        ((0, p.setPeopleAnalytic)({
                          email_marketing: "true",
                          push_notification_version: _,
                          ...(x ? { verification_status: "complete" } : {}),
                        }),
                        x
                          ? (await k(P(C)), y.replace(i.EClientRoutes.INTRODUCTION), y.refresh())
                          : (N(), b("user_token", "")));
                    })
                    .catch((e) => {
                      let t = e?.message || "Error creating user session";
                      ((0, p.trackClientEvents)({
                        event: n.EAnalyticEvents.CLIENT_SESSION_CREATE_ERROR,
                        user: C,
                        params: { error_code: t },
                      }),
                        j.current && (S.current = !1));
                    })),
                !C?.sessions?.stripe_session_id && !E.current)
              ) {
                var e;
                ((E.current = !0),
                  (e = () => {
                    (0, f.createSessionsForClient)(d.stripeSessions).then(async (e) => {
                      w({ user: { sessions: { ...e } } });
                    });
                  }),
                  "complete" === document.readyState
                    ? l(e)
                    : window.addEventListener("load", () => l(e), { once: !0 }));
              }
            }, [C, C?.currency, h, x, _, v, I]),
            null
          );
        },
      ],
      179881,
    );
  },
  802774,
  (e) => {
    "use strict";
    e.i(756503);
    var t = e.i(542516);
    let r = [
      { key: `${t.envClient.NEXT_PUBLIC_STRIPE_PUBLIC_KEY}`, name: "stripe_session_id" },
      { key: `${t.envClient.NEXT_PUBLIC_STRIPE_UK_PUBLIC_KEY}`, name: "uk_stripe_session_id" },
      { key: `${t.envClient.NEXT_PUBLIC_STRIPE_CA_PUBLIC_KEY}`, name: "ca_stripe_session_id" },
      { key: `${t.envClient.NEXT_PUBLIC_STRIPE_AU_PUBLIC_KEY}`, name: "au_stripe_session_id" },
      { key: `${t.envClient.NEXT_PUBLIC_STRIPE_EU_PUBLIC_KEY}`, name: "eu_stripe_session_id" },
    ];
    e.s(["stripeSessions", 0, r]);
  },
  458350,
  (e) => {
    "use strict";
    e.s([
      "useGeneratedUser",
      0,
      () => {
        let e = (e) => {
            if (e && e.length) return e[Math.floor(Math.random() * e?.length)];
          },
          t = (e, t) => Math.floor(Math.random() * (t - e + 1)) + e,
          r = (r, a) => {
            let s = a ? [a?.currentCountry, ...a.neighboringCountries] : [],
              n = [];
            for (let a = 1; a <= r; a++) {
              let r = e(s),
                a = Math.random() > 0.5 ? "male" : "female",
                i = e(r?.names[a].firstNames),
                o = e(r?.names[a].surnames),
                l = {
                  id: Math.random().toString(),
                  country: r?.code,
                  name: i,
                  surName: o,
                  count: t(86, 107).toString(),
                  sex: a,
                };
              n.push(l);
            }
            return n;
          };
        return {
          generateUsers: r,
          generateUniqueUsers: (a, s) => {
            let n = s ? [s?.currentCountry, ...s.neighboringCountries] : [];
            if (!n.length) return [];
            let i = [],
              o = new Set(),
              l = 0;
            if (
              (n.forEach((e) => {
                if (e?.names) {
                  let t = (e.names.male?.firstNames?.length || 0) * (e.names.male?.surnames?.length || 0),
                    r = (e.names.female?.firstNames?.length || 0) * (e.names.female?.surnames?.length || 0);
                  l += t + r;
                }
              }),
              l < a)
            )
              return r(Math.min(a, l), s);
            let u = 0,
              c = 10 * a;
            for (; i.length < a && u < c;) {
              u++;
              let r = e(n);
              if (!r?.names) continue;
              let a = Math.random() > 0.5 ? "male" : "female";
              if (!r.names[a]?.firstNames?.length || !r.names[a]?.surnames?.length) continue;
              let s = e(r.names[a].firstNames),
                l = e(r.names[a].surnames),
                c = `${s}-${l}`;
              if (!o.has(c)) {
                o.add(c);
                let e = {
                  id: Math.random().toString(),
                  country: r.code,
                  name: s,
                  surName: l,
                  count: t(86, 107).toString(),
                  sex: a,
                };
                i.push(e);
              }
            }
            return i;
          },
        };
      },
    ]);
  },
  495495,
  (e) => {
    "use strict";
    var t = e.i(618566),
      r = e.i(202042);
    e.s([
      "useQuerySearchParams",
      0,
      () => {
        let { push: e } = (0, r.useRouter)(),
          a = (0, r.usePathname)(),
          s = (0, t.useSearchParams)(),
          n = new URLSearchParams(window.location.hash.slice(1)),
          i = String(new URLSearchParams(s));
        return {
          push: e,
          searchParams: s,
          allQueriesParams: i,
          changeQuery: (t, r) => {
            let n;
            e(
              a +
                "?" +
                ((n = new URLSearchParams(s)).delete("page"), r ? n.set(t, r) : n.delete(t), n.toString()),
            );
          },
          hashParams: n,
        };
      },
    ]);
  },
  869404,
  (e) => {
    "use strict";
    e.s(["getRandomInterval", 0, (e, t) => Math.floor(Math.random() * (t - e + 1)) + e]);
  },
  295592,
  (e) => {
    "use strict";
    var t = e.i(768834),
      r = e.i(579473);
    e.i(756503);
    var a = e.i(542516);
    let s = (0, t.create)()(
      (0, r.devtools)((e) => ({ users: [], updateUsers: (t) => e(() => ({ users: t })) }), {
        enabled: "production" !== a.envClient.NEXT_PUBLIC_NODE_ENV,
      }),
    );
    e.s(["useGeneratedUsersStore", 0, s]);
  },
  311165,
  (e) => {
    "use strict";
    var t = e.i(768834),
      r = e.i(579473);
    e.i(756503);
    var a = e.i(542516);
    let s = (0, t.create)()(
      (0, r.persist)(
        (0, r.devtools)(
          (e) => ({
            love_language_type_result: void 0,
            handleChangeQuizStore: (t) => e((e) => ({ ...e, ...t })),
          }),
          { enabled: "production" !== a.envClient.NEXT_PUBLIC_NODE_ENV },
        ),
        { name: "quiz-love_language", version: 1 },
      ),
    );
    e.s(["useLoveLanguageQuizStore", 0, s]);
  },
  491877,
  758535,
  (e) => {
    "use strict";
    let t = (0, e.i(770703).default)(() => e.A(963075), {
      loadableGenerated: { modules: [149278] },
      ssr: !1,
    });
    (e.s(["CheckoutFormComponent", 0, t], 758535), e.i(56395), e.s([], 491877));
  },
  56395,
  178668,
  (e) => {
    "use strict";
    let t,
      r = "u" > typeof crypto && crypto.randomUUID && crypto.randomUUID.bind(crypto),
      a = new Uint8Array(16),
      s = [];
    for (let e = 0; e < 256; ++e) s.push((e + 256).toString(16).slice(1));
    let n = function (e, n, i) {
      if (r && !n && !e) return r();
      let o =
        (e = e || {}).random ??
        e.rng?.() ??
        (function () {
          if (!t) {
            if ("u" < typeof crypto || !crypto.getRandomValues)
              throw Error(
                "crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported",
              );
            t = crypto.getRandomValues.bind(crypto);
          }
          return t(a);
        })();
      if (o.length < 16) throw Error("Random bytes length must be >= 16");
      if (((o[6] = (15 & o[6]) | 64), (o[8] = (63 & o[8]) | 128), n)) {
        if ((i = i || 0) < 0 || i + 16 > n.length)
          throw RangeError(`UUID byte range ${i}:${i + 15} is out of buffer bounds`);
        for (let e = 0; e < 16; ++e) n[i + e] = o[e];
        return n;
      }
      return (function (e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return (
          s[e[t + 0]] +
          s[e[t + 1]] +
          s[e[t + 2]] +
          s[e[t + 3]] +
          "-" +
          s[e[t + 4]] +
          s[e[t + 5]] +
          "-" +
          s[e[t + 6]] +
          s[e[t + 7]] +
          "-" +
          s[e[t + 8]] +
          s[e[t + 9]] +
          "-" +
          s[e[t + 10]] +
          s[e[t + 11]] +
          s[e[t + 12]] +
          s[e[t + 13]] +
          s[e[t + 14]] +
          s[e[t + 15]]
        ).toLowerCase();
      })(o);
    };
    var i = e.i(709275),
      o = e.i(190899);
    e.i(756503);
    var l = e.i(542516);
    e.i(999126);
    var u = e.i(548248);
    let c = async (e) => {
        try {
          await d();
          let t = [];
          for (let r of e) {
            let e = await (0, i.loadStripe)(r.key),
              a = await e?.createRadarSession();
            a?.radarSession?.id &&
              (t.push({ stripeRadarSessionId: a?.radarSession?.id, name: r.name }),
              o.accessSessionStorageUtil.setItem(r.name, a.radarSession.id));
          }
          let r = Object.assign({}, ...t.map((e) => ({ [e.name]: e.stripeRadarSessionId }))),
            a = m();
          return (
            (0, u.debugUtil)({ text: "createSessionsForClient", value: { ...r, ...a } }),
            { ...r, ...a }
          );
        } catch (t) {
          let e = t?.response?.body?.error?.message || t?.message || "Something went wrong";
          throw ((0, u.debugUtil)({ text: "createSessionsForClient error", value: t }), Error(e));
        }
      },
      d = async () => {
        try {
          return new Promise((e, t) => {
            if (window.Stripe) e();
            else {
              let r = "stripe-js-script",
                a = document.getElementById(r);
              if (a)
                (a.addEventListener("load", () => {
                  window.Stripe ? e() : t(Error("Stripe.js failed to load."));
                }),
                  a.addEventListener("error", () => {
                    t(Error("Stripe.js failed to load."));
                  }));
              else {
                let a = document.createElement("script");
                ((a.id = r),
                  (a.src = "https://js.stripe.com/v3/"),
                  (a.async = !0),
                  (a.onload = () => {
                    window.Stripe ? e() : t(Error("Stripe.js failed to load."));
                  }),
                  (a.onerror = () => t(Error("Stripe.js failed to load."))),
                  document.head.appendChild(a));
              }
            }
          });
        } catch (e) {
          (0, u.debugUtil)({ text: "loadStripeClient error", value: e });
          return;
        }
      },
      m = () => {
        let e = n(),
          t = document.createElement("script");
        ((t.id = "paypal-script"),
          (t.src = `https://c.paypal.com/da/r/fb.js?f=${e}&s=${l.envClient.NEXT_PUBLIC_PAY_PAL_MERCHANT_ID}_checkout-page&sandbox=false`),
          document.body.appendChild(t));
        let r = document.createElement("script");
        ((r.id = "paypal-fraudnet-script"),
          (r.src = "https://c.paypal.com/da/r/fb.js"),
          document.body.appendChild(r));
        let a = { paypal_session_id: e, paypal_client_metadata_id: e };
        return (
          Object.entries(a).forEach((e) => {
            let [t, r] = e;
            o.accessSessionStorageUtil.setItem(t, r);
          }),
          a
        );
      };
    (e.s(["createSessionsForClient", 0, c], 178668), e.s([], 56395));
  },
]);
