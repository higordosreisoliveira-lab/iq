(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  768293,
  (e) => {
    "use strict";
    var a = e.i(265840),
      t = e.i(273830),
      l = e.i(620253),
      s = e.i(75540),
      o = e.i(843476),
      i = (0, t.forwardRef)((e, t) => {
        let { as: i, children: r, className: n, ...d } = e,
          { slots: c, classNames: x } = (0, a.useModalContext)(),
          m = (0, l.useDOMRef)(t);
        return (0, o.jsx)(i || "footer", {
          ref: m,
          className: c.footer({ class: (0, s.clsx)(null == x ? void 0 : x.footer, n) }),
          ...d,
          children: r,
        });
      });
    ((i.displayName = "HeroUI.ModalFooter"), e.s(["ModalFooter", 0, i], 768293));
  },
  114830,
  (e) => {
    "use strict";
    var a = e.i(843476),
      t = e.i(475254);
    let l = (0, t.default)("external-link", [
        ["path", { d: "M15 3h6v6", key: "1q9fwt" }],
        ["path", { d: "M10 14 21 3", key: "gplh6r" }],
        ["path", { d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6", key: "a6xqqp" }],
      ]),
      s = (0, t.default)("shield-alert", [
        [
          "path",
          {
            d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
            key: "oel41y",
          },
        ],
        ["path", { d: "M12 8v4", key: "1got3b" }],
        ["path", { d: "M12 16h.01", key: "1drbdi" }],
      ]);
    var o = e.i(948148),
      i = e.i(335889),
      r = e.i(742214),
      n = e.i(768293),
      d = e.i(622963),
      c = e.i(202042);
    (e.s([], 413085),
      e.i(413085),
      e.s(
        [
          "AdblockWarningModalComponent",
          0,
          (e) => {
            let { isBrave: t } = e,
              x = (0, o.useTranslations)(),
              m = (0, d.useModalStore)((e) => e.handleChangeModalStore);
            return (0, a.jsxs)(r.ModalContent, {
              className:
                "flex min-h-[150px] w-full max-w-[520px] flex-col items-center gap-1 overflow-auto p-6 text-center",
              children: [
                (0, a.jsx)("div", {
                  className: "mb-2 rounded-full bg-warning-100 p-3",
                  children: (0, a.jsx)(s, { className: "text-3xl text-warning-500" }),
                }),
                (0, a.jsx)("h3", {
                  className:
                    "mb-2 text-center text-lg font-semibold xs-sm:text-[24px] [@media(max-height:500px)]:text-lg",
                  children: x(t ? "games_adblock_brave_title" : "games_adblock_title"),
                }),
                (0, a.jsx)("p", {
                  className:
                    "mb-2 text-center text-grey-light xs-sm:text-lg [@media(max-height:500px)]:text-base",
                  children: x(t ? "games_adblock_brave_description" : "games_adblock_description"),
                }),
                (0, a.jsxs)(n.ModalFooter, {
                  className: "flex w-full flex-col gap-2 px-0 !pb-0 sm:flex-row",
                  children: [
                    (0, a.jsx)(i.Button, {
                      color: "primary",
                      variant: "solid",
                      as: c.Link,
                      href: t
                        ? "https://support.brave.app/hc/en-us/articles/360023646212-How-do-I-configure-global-and-site-specific-Shields-settings"
                        : "https://www.wikihow.com/Disable-AdBlock",
                      className: "h-[48px] w-full text-wrap bg-green-custom sm:w-auto",
                      target: "_blank",
                      startContent: (0, a.jsx)(l, { className: "shrink-0" }),
                      children: x(t ? "games_adblock_brave_info" : "games_adblock_info"),
                    }),
                    (0, a.jsx)(i.Button, {
                      color: "default",
                      variant: "flat",
                      className: "h-[48px] w-full sm:w-auto",
                      onPress: () => {
                        m({ modalComponent: void 0, isModalVisible: !1 });
                      },
                      children: x(t ? "games_adblock_brave_continue" : "games_adblock_continue"),
                    }),
                  ],
                }),
              ],
            });
          },
        ],
        114830,
      ));
  },
  223196,
  function (e) {
    e.n(e.i(114830));
  },
]);
