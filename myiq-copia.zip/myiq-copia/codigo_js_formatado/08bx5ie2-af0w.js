(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  882983,
  (e) => {
    "use strict";
    var s = e.i(265840),
      a = e.i(271645),
      t = e.i(273830),
      i = e.i(620253),
      l = e.i(75540),
      r = e.i(843476),
      n = (0, t.forwardRef)((e, t) => {
        let { as: n, children: o, className: c, ...d } = e,
          { slots: u, classNames: m, bodyId: x, setBodyMounted: p } = (0, s.useModalContext)(),
          h = (0, i.useDOMRef)(t);
        return (
          (0, a.useEffect)(() => (p(!0), () => p(!1)), [p]),
          (0, r.jsx)(n || "div", {
            ref: h,
            className: u.body({ class: (0, l.clsx)(null == m ? void 0 : m.body, c) }),
            id: x,
            ...d,
            children: o,
          })
        );
      });
    ((n.displayName = "HeroUI.ModalBody"), e.s(["ModalBody", 0, n], 882983));
  },
  31799,
  (e) => {
    "use strict";
    var s = e.i(768834),
      a = e.i(579473),
      t = e.i(60423);
    let i = "retake-quiz-storage",
      l = {
        currentTestType: null,
        currentQuestionId: null,
        userAnswers: null,
        secondsPassed: 0,
        isTimerPaused: !1,
        _hasHydrated: !1,
        isTestCompleted: !1,
        previousIQScore: null,
        newIQScore: null,
      },
      r = (0, s.create)()(
        (0, a.persist)(
          (e, s) => ({
            ...l,
            handleChangeRetakeQuizStore: (s) => e((e) => ({ ...e, ...s })),
            clearRetakeQuizStore: () => {
              let a = s()._hasHydrated;
              e({ ...l, _hasHydrated: a });
            },
            setHasHydrated: (s) => e({ _hasHydrated: s }),
          }),
          {
            name: i,
            onRehydrateStorage: () => (e) => {
              e?.setHasHydrated(!0);
            },
          },
        ),
      );
    e.s([
      "clearRetakeQuizFromLocalStorage",
      0,
      () => {
        t.accessLocalStorage.removeItem(i);
      },
      "useRetakeQuizStore",
      0,
      r,
    ]);
  },
  616973,
  (e) => {
    "use strict";
    var s = e.i(843476),
      a = e.i(948148),
      t = e.i(271645),
      i = e.i(335889),
      l = e.i(882983),
      r = e.i(742214),
      n = e.i(31799),
      o = e.i(622963);
    e.i(568267);
    var c = e.i(154692);
    (e.s([], 888276),
      e.i(888276),
      e.s(
        [
          "RetakeIQPurchaseModalComponent",
          0,
          (e) => {
            let { modeData: d, onConfirm: u, onClose: m } = e,
              x = (0, a.useTranslations)(),
              { handleChangeModalStore: p } = (0, o.useModalStore)(),
              h = (0, n.useRetakeQuizStore)((e) => e.handleChangeRetakeQuizStore),
              [_, f] = (0, t.useState)(!1),
              b = x.rich("retake_iq_purchase_modal_description_base_pay_before_test", {
                price: d.price,
                span: (e) => (0, s.jsx)("span", { className: "font-bold", children: e }),
              }),
              g = x.rich("retake_iq_purchase_modal_description_advanced_pay_before_test", {
                price: d.price,
                span: (e) => (0, s.jsx)("span", { className: "font-bold", children: e }),
              }),
              y = "retake-iq-base" === d.planId ? b : g;
            return (
              (0, t.useEffect)(
                () => (
                  h({ isTimerPaused: !0 }),
                  () => {
                    h({ isTimerPaused: !1 });
                  }
                ),
                [],
              ),
              (0, s.jsx)(r.ModalContent, {
                className: "!m-0 flex flex-col rounded-b-none sm:rounded-b-lg",
                children: (0, s.jsx)(l.ModalBody, {
                  className: "flex h-full w-full flex-col gap-5 p-6",
                  children: (0, s.jsxs)(s.Fragment, {
                    children: [
                      (0, s.jsx)("div", {
                        className: "flex h-full items-center",
                        children: (0, s.jsxs)("div", {
                          className: "w-full text-center",
                          children: [
                            (0, s.jsx)("h2", {
                              className: "mb-2 text-lg font-semibold text-gray-900",
                              children: x("tests_page_purchase_confirm_title"),
                            }),
                            (0, s.jsxs)("p", {
                              className: "text-sm text-gray-600",
                              children: [
                                y,
                                ". ",
                                x("retake_iq_purchase_modal_subtitle", { btnText: `'${x("btn_confirm")}'` }),
                              ],
                            }),
                          ],
                        }),
                      }),
                      (0, s.jsxs)("div", {
                        className: "flex flex-col gap-2.5",
                        children: [
                          (0, s.jsx)(c.ButtonComponent, {
                            isLoading: _,
                            isDisabled: _,
                            text: x("btn_confirm"),
                            className:
                              "mt-auto h-12 w-full flex-shrink-0 whitespace-normal !rounded-xl px-1 text-center text-base capitalize xs-base:px-6",
                            onClick: async () => {
                              (f(!0), await u());
                            },
                          }),
                          (0, s.jsx)(i.Button, {
                            size: "md",
                            className:
                              "h-12 w-full text-wrap bg-[#EFF2FD] px-1 text-base font-semibold text-gray-900",
                            onPress: () => {
                              (p({ modalComponent: "retake-iq-purchase", isModalVisible: !1 }), m?.());
                            },
                            disableAnimation: !0,
                            isDisabled: _,
                            children: x("btn_cancel"),
                          }),
                        ],
                      }),
                      (0, s.jsxs)("div", {
                        className: "gap-0.5 text-center text-xs italic leading-tight text-default-600",
                        children: [
                          (0, s.jsx)("div", { className: "inline", children: "*" }),
                          x("retake_iq_purchase_modal_info_subtext", {
                            btnText: `'${x("btn_confirm")}'`,
                            price: d.price,
                          }),
                        ],
                      }),
                    ],
                  }),
                }),
              })
            );
          },
        ],
        616973,
      ));
  },
  72575,
  function (e) {
    e.n(e.i(616973));
  },
]);
