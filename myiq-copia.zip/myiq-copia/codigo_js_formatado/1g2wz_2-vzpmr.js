(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  392277,
  (e) => {
    "use strict";
    (e.s([]), e.i(567697));
  },
  567697,
  (e) => {
    "use strict";
    e.s(["getCountryData", () => I, "useCreateMotivationalContent", () => T], 567697);
    var i = e.i(843476),
      n = e.i(948148);
    e.i(26664);
    var s = e.i(865046);
    e.i(381069);
    let o = [
      {
        name: "Ascension Island",
        code: "AC",
        emoji: "🇦🇨",
        unicode: "U+1F1E6 U+1F1E8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/AC.svg",
      },
      {
        name: "Andorra",
        code: "AD",
        emoji: "🇦🇩",
        unicode: "U+1F1E6 U+1F1E9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/AD.svg",
      },
      {
        name: "United Arab Emirates",
        code: "AE",
        emoji: "🇦🇪",
        unicode: "U+1F1E6 U+1F1EA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/AE.svg",
      },
      {
        name: "Afghanistan",
        code: "AF",
        emoji: "🇦🇫",
        unicode: "U+1F1E6 U+1F1EB",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/AF.svg",
      },
      {
        name: "Antigua & Barbuda",
        code: "AG",
        emoji: "🇦🇬",
        unicode: "U+1F1E6 U+1F1EC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/AG.svg",
      },
      {
        name: "Anguilla",
        code: "AI",
        emoji: "🇦🇮",
        unicode: "U+1F1E6 U+1F1EE",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/AI.svg",
      },
      {
        name: "Albania",
        code: "AL",
        emoji: "🇦🇱",
        unicode: "U+1F1E6 U+1F1F1",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/AL.svg",
      },
      {
        name: "Armenia",
        code: "AM",
        emoji: "🇦🇲",
        unicode: "U+1F1E6 U+1F1F2",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/AM.svg",
      },
      {
        name: "Angola",
        code: "AO",
        emoji: "🇦🇴",
        unicode: "U+1F1E6 U+1F1F4",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/AO.svg",
      },
      {
        name: "Antarctica",
        code: "AQ",
        emoji: "🇦🇶",
        unicode: "U+1F1E6 U+1F1F6",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/AQ.svg",
      },
      {
        name: "Argentina",
        code: "AR",
        emoji: "🇦🇷",
        unicode: "U+1F1E6 U+1F1F7",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/AR.svg",
      },
      {
        name: "American Samoa",
        code: "AS",
        emoji: "🇦🇸",
        unicode: "U+1F1E6 U+1F1F8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/AS.svg",
      },
      {
        name: "Austria",
        code: "AT",
        emoji: "🇦🇹",
        unicode: "U+1F1E6 U+1F1F9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/AT.svg",
      },
      {
        name: "Australia",
        code: "AU",
        emoji: "🇦🇺",
        unicode: "U+1F1E6 U+1F1FA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/AU.svg",
      },
      {
        name: "Aruba",
        code: "AW",
        emoji: "🇦🇼",
        unicode: "U+1F1E6 U+1F1FC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/AW.svg",
      },
      {
        name: "Åland Islands",
        code: "AX",
        emoji: "🇦🇽",
        unicode: "U+1F1E6 U+1F1FD",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/AX.svg",
      },
      {
        name: "Azerbaijan",
        code: "AZ",
        emoji: "🇦🇿",
        unicode: "U+1F1E6 U+1F1FF",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/AZ.svg",
      },
      {
        name: "Bosnia & Herzegovina",
        code: "BA",
        emoji: "🇧🇦",
        unicode: "U+1F1E7 U+1F1E6",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BA.svg",
      },
      {
        name: "Barbados",
        code: "BB",
        emoji: "🇧🇧",
        unicode: "U+1F1E7 U+1F1E7",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BB.svg",
      },
      {
        name: "Bangladesh",
        code: "BD",
        emoji: "🇧🇩",
        unicode: "U+1F1E7 U+1F1E9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BD.svg",
      },
      {
        name: "Belgium",
        code: "BE",
        emoji: "🇧🇪",
        unicode: "U+1F1E7 U+1F1EA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BE.svg",
      },
      {
        name: "Burkina Faso",
        code: "BF",
        emoji: "🇧🇫",
        unicode: "U+1F1E7 U+1F1EB",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BF.svg",
      },
      {
        name: "Bulgaria",
        code: "BG",
        emoji: "🇧🇬",
        unicode: "U+1F1E7 U+1F1EC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BG.svg",
      },
      {
        name: "Bahrain",
        code: "BH",
        emoji: "🇧🇭",
        unicode: "U+1F1E7 U+1F1ED",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BH.svg",
      },
      {
        name: "Burundi",
        code: "BI",
        emoji: "🇧🇮",
        unicode: "U+1F1E7 U+1F1EE",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BI.svg",
      },
      {
        name: "Benin",
        code: "BJ",
        emoji: "🇧🇯",
        unicode: "U+1F1E7 U+1F1EF",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BJ.svg",
      },
      {
        name: "St. Barthélemy",
        code: "BL",
        emoji: "🇧🇱",
        unicode: "U+1F1E7 U+1F1F1",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BL.svg",
      },
      {
        name: "Bermuda",
        code: "BM",
        emoji: "🇧🇲",
        unicode: "U+1F1E7 U+1F1F2",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BM.svg",
      },
      {
        name: "Brunei",
        code: "BN",
        emoji: "🇧🇳",
        unicode: "U+1F1E7 U+1F1F3",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BN.svg",
      },
      {
        name: "Bolivia",
        code: "BO",
        emoji: "🇧🇴",
        unicode: "U+1F1E7 U+1F1F4",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BO.svg",
      },
      {
        name: "Caribbean Netherlands",
        code: "BQ",
        emoji: "🇧🇶",
        unicode: "U+1F1E7 U+1F1F6",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BQ.svg",
      },
      {
        name: "Brazil",
        code: "BR",
        emoji: "🇧🇷",
        unicode: "U+1F1E7 U+1F1F7",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BR.svg",
      },
      {
        name: "Bahamas",
        code: "BS",
        emoji: "🇧🇸",
        unicode: "U+1F1E7 U+1F1F8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BS.svg",
      },
      {
        name: "Bhutan",
        code: "BT",
        emoji: "🇧🇹",
        unicode: "U+1F1E7 U+1F1F9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BT.svg",
      },
      {
        name: "Bouvet Island",
        code: "BV",
        emoji: "🇧🇻",
        unicode: "U+1F1E7 U+1F1FB",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BV.svg",
      },
      {
        name: "Botswana",
        code: "BW",
        emoji: "🇧🇼",
        unicode: "U+1F1E7 U+1F1FC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BW.svg",
      },
      {
        name: "Belarus",
        code: "BY",
        emoji: "🇧🇾",
        unicode: "U+1F1E7 U+1F1FE",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BY.svg",
      },
      {
        name: "Belize",
        code: "BZ",
        emoji: "🇧🇿",
        unicode: "U+1F1E7 U+1F1FF",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/BZ.svg",
      },
      {
        name: "Canada",
        code: "CA",
        emoji: "🇨🇦",
        unicode: "U+1F1E8 U+1F1E6",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CA.svg",
      },
      {
        name: "Cocos (Keeling) Islands",
        code: "CC",
        emoji: "🇨🇨",
        unicode: "U+1F1E8 U+1F1E8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CC.svg",
      },
      {
        name: "Congo - Kinshasa",
        code: "CD",
        emoji: "🇨🇩",
        unicode: "U+1F1E8 U+1F1E9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CD.svg",
      },
      {
        name: "Central African Republic",
        code: "CF",
        emoji: "🇨🇫",
        unicode: "U+1F1E8 U+1F1EB",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CF.svg",
      },
      {
        name: "Congo - Brazzaville",
        code: "CG",
        emoji: "🇨🇬",
        unicode: "U+1F1E8 U+1F1EC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CG.svg",
      },
      {
        name: "Switzerland",
        code: "CH",
        emoji: "🇨🇭",
        unicode: "U+1F1E8 U+1F1ED",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CH.svg",
      },
      {
        name: "Côte d'Ivoire",
        code: "CI",
        emoji: "🇨🇮",
        unicode: "U+1F1E8 U+1F1EE",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CI.svg",
      },
      {
        name: "Cook Islands",
        code: "CK",
        emoji: "🇨🇰",
        unicode: "U+1F1E8 U+1F1F0",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CK.svg",
      },
      {
        name: "Chile",
        code: "CL",
        emoji: "🇨🇱",
        unicode: "U+1F1E8 U+1F1F1",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CL.svg",
      },
      {
        name: "Cameroon",
        code: "CM",
        emoji: "🇨🇲",
        unicode: "U+1F1E8 U+1F1F2",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CM.svg",
      },
      {
        name: "China",
        code: "CN",
        emoji: "🇨🇳",
        unicode: "U+1F1E8 U+1F1F3",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CN.svg",
      },
      {
        name: "Colombia",
        code: "CO",
        emoji: "🇨🇴",
        unicode: "U+1F1E8 U+1F1F4",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CO.svg",
      },
      {
        name: "Clipperton Island",
        code: "CP",
        emoji: "🇨🇵",
        unicode: "U+1F1E8 U+1F1F5",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CP.svg",
      },
      {
        name: "Costa Rica",
        code: "CR",
        emoji: "🇨🇷",
        unicode: "U+1F1E8 U+1F1F7",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CR.svg",
      },
      {
        name: "Cuba",
        code: "CU",
        emoji: "🇨🇺",
        unicode: "U+1F1E8 U+1F1FA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CU.svg",
      },
      {
        name: "Cape Verde",
        code: "CV",
        emoji: "🇨🇻",
        unicode: "U+1F1E8 U+1F1FB",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CV.svg",
      },
      {
        name: "Curaçao",
        code: "CW",
        emoji: "🇨🇼",
        unicode: "U+1F1E8 U+1F1FC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CW.svg",
      },
      {
        name: "Christmas Island",
        code: "CX",
        emoji: "🇨🇽",
        unicode: "U+1F1E8 U+1F1FD",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CX.svg",
      },
      {
        name: "Cyprus",
        code: "CY",
        emoji: "🇨🇾",
        unicode: "U+1F1E8 U+1F1FE",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CY.svg",
      },
      {
        name: "Czechia",
        code: "CZ",
        emoji: "🇨🇿",
        unicode: "U+1F1E8 U+1F1FF",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/CZ.svg",
      },
      {
        name: "Germany",
        code: "DE",
        emoji: "🇩🇪",
        unicode: "U+1F1E9 U+1F1EA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/DE.svg",
      },
      {
        name: "Diego Garcia",
        code: "DG",
        emoji: "🇩🇬",
        unicode: "U+1F1E9 U+1F1EC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/DG.svg",
      },
      {
        name: "Djibouti",
        code: "DJ",
        emoji: "🇩🇯",
        unicode: "U+1F1E9 U+1F1EF",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/DJ.svg",
      },
      {
        name: "Denmark",
        code: "DK",
        emoji: "🇩🇰",
        unicode: "U+1F1E9 U+1F1F0",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/DK.svg",
      },
      {
        name: "Dominica",
        code: "DM",
        emoji: "🇩🇲",
        unicode: "U+1F1E9 U+1F1F2",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/DM.svg",
      },
      {
        name: "Dominican Republic",
        code: "DO",
        emoji: "🇩🇴",
        unicode: "U+1F1E9 U+1F1F4",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/DO.svg",
      },
      {
        name: "Algeria",
        code: "DZ",
        emoji: "🇩🇿",
        unicode: "U+1F1E9 U+1F1FF",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/DZ.svg",
      },
      {
        name: "Ceuta & Melilla",
        code: "EA",
        emoji: "🇪🇦",
        unicode: "U+1F1EA U+1F1E6",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/EA.svg",
      },
      {
        name: "Ecuador",
        code: "EC",
        emoji: "🇪🇨",
        unicode: "U+1F1EA U+1F1E8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/EC.svg",
      },
      {
        name: "Estonia",
        code: "EE",
        emoji: "🇪🇪",
        unicode: "U+1F1EA U+1F1EA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/EE.svg",
      },
      {
        name: "Egypt",
        code: "EG",
        emoji: "🇪🇬",
        unicode: "U+1F1EA U+1F1EC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/EG.svg",
      },
      {
        name: "Western Sahara",
        code: "EH",
        emoji: "🇪🇭",
        unicode: "U+1F1EA U+1F1ED",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/EH.svg",
      },
      {
        name: "Eritrea",
        code: "ER",
        emoji: "🇪🇷",
        unicode: "U+1F1EA U+1F1F7",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/ER.svg",
      },
      {
        name: "Spain",
        code: "ES",
        emoji: "🇪🇸",
        unicode: "U+1F1EA U+1F1F8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/ES.svg",
      },
      {
        name: "Ethiopia",
        code: "ET",
        emoji: "🇪🇹",
        unicode: "U+1F1EA U+1F1F9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/ET.svg",
      },
      {
        name: "European Union",
        code: "EU",
        emoji: "🇪🇺",
        unicode: "U+1F1EA U+1F1FA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/EU.svg",
      },
      {
        name: "Finland",
        code: "FI",
        emoji: "🇫🇮",
        unicode: "U+1F1EB U+1F1EE",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/FI.svg",
      },
      {
        name: "Fiji",
        code: "FJ",
        emoji: "🇫🇯",
        unicode: "U+1F1EB U+1F1EF",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/FJ.svg",
      },
      {
        name: "Falkland Islands",
        code: "FK",
        emoji: "🇫🇰",
        unicode: "U+1F1EB U+1F1F0",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/FK.svg",
      },
      {
        name: "Micronesia",
        code: "FM",
        emoji: "🇫🇲",
        unicode: "U+1F1EB U+1F1F2",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/FM.svg",
      },
      {
        name: "Faroe Islands",
        code: "FO",
        emoji: "🇫🇴",
        unicode: "U+1F1EB U+1F1F4",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/FO.svg",
      },
      {
        name: "France",
        code: "FR",
        emoji: "🇫🇷",
        unicode: "U+1F1EB U+1F1F7",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/FR.svg",
      },
      {
        name: "Gabon",
        code: "GA",
        emoji: "🇬🇦",
        unicode: "U+1F1EC U+1F1E6",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/GA.svg",
      },
      {
        name: "United Kingdom",
        code: "GB",
        emoji: "🇬🇧",
        unicode: "U+1F1EC U+1F1E7",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/GB.svg",
      },
      {
        name: "Grenada",
        code: "GD",
        emoji: "🇬🇩",
        unicode: "U+1F1EC U+1F1E9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/GD.svg",
      },
      {
        name: "Georgia",
        code: "GE",
        emoji: "🇬🇪",
        unicode: "U+1F1EC U+1F1EA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/GE.svg",
      },
      {
        name: "French Guiana",
        code: "GF",
        emoji: "🇬🇫",
        unicode: "U+1F1EC U+1F1EB",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/GF.svg",
      },
      {
        name: "Guernsey",
        code: "GG",
        emoji: "🇬🇬",
        unicode: "U+1F1EC U+1F1EC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/GG.svg",
      },
      {
        name: "Ghana",
        code: "GH",
        emoji: "🇬🇭",
        unicode: "U+1F1EC U+1F1ED",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/GH.svg",
      },
      {
        name: "Gibraltar",
        code: "GI",
        emoji: "🇬🇮",
        unicode: "U+1F1EC U+1F1EE",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/GI.svg",
      },
      {
        name: "Greenland",
        code: "GL",
        emoji: "🇬🇱",
        unicode: "U+1F1EC U+1F1F1",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/GL.svg",
      },
      {
        name: "Gambia",
        code: "GM",
        emoji: "🇬🇲",
        unicode: "U+1F1EC U+1F1F2",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/GM.svg",
      },
      {
        name: "Guinea",
        code: "GN",
        emoji: "🇬🇳",
        unicode: "U+1F1EC U+1F1F3",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/GN.svg",
      },
      {
        name: "Guadeloupe",
        code: "GP",
        emoji: "🇬🇵",
        unicode: "U+1F1EC U+1F1F5",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/GP.svg",
      },
      {
        name: "Equatorial Guinea",
        code: "GQ",
        emoji: "🇬🇶",
        unicode: "U+1F1EC U+1F1F6",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/GQ.svg",
      },
      {
        name: "Greece",
        code: "GR",
        emoji: "🇬🇷",
        unicode: "U+1F1EC U+1F1F7",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/GR.svg",
      },
      {
        name: "South Georgia & South Sandwich Islands",
        code: "GS",
        emoji: "🇬🇸",
        unicode: "U+1F1EC U+1F1F8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/GS.svg",
      },
      {
        name: "Guatemala",
        code: "GT",
        emoji: "🇬🇹",
        unicode: "U+1F1EC U+1F1F9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/GT.svg",
      },
      {
        name: "Guam",
        code: "GU",
        emoji: "🇬🇺",
        unicode: "U+1F1EC U+1F1FA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/GU.svg",
      },
      {
        name: "Guinea-Bissau",
        code: "GW",
        emoji: "🇬🇼",
        unicode: "U+1F1EC U+1F1FC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/GW.svg",
      },
      {
        name: "Guyana",
        code: "GY",
        emoji: "🇬🇾",
        unicode: "U+1F1EC U+1F1FE",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/GY.svg",
      },
      {
        name: "Hong Kong SAR China",
        code: "HK",
        emoji: "🇭🇰",
        unicode: "U+1F1ED U+1F1F0",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/HK.svg",
      },
      {
        name: "Heard & McDonald Islands",
        code: "HM",
        emoji: "🇭🇲",
        unicode: "U+1F1ED U+1F1F2",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/HM.svg",
      },
      {
        name: "Honduras",
        code: "HN",
        emoji: "🇭🇳",
        unicode: "U+1F1ED U+1F1F3",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/HN.svg",
      },
      {
        name: "Croatia",
        code: "HR",
        emoji: "🇭🇷",
        unicode: "U+1F1ED U+1F1F7",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/HR.svg",
      },
      {
        name: "Haiti",
        code: "HT",
        emoji: "🇭🇹",
        unicode: "U+1F1ED U+1F1F9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/HT.svg",
      },
      {
        name: "Hungary",
        code: "HU",
        emoji: "🇭🇺",
        unicode: "U+1F1ED U+1F1FA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/HU.svg",
      },
      {
        name: "Canary Islands",
        code: "IC",
        emoji: "🇮🇨",
        unicode: "U+1F1EE U+1F1E8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/IC.svg",
      },
      {
        name: "Indonesia",
        code: "ID",
        emoji: "🇮🇩",
        unicode: "U+1F1EE U+1F1E9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/ID.svg",
      },
      {
        name: "Ireland",
        code: "IE",
        emoji: "🇮🇪",
        unicode: "U+1F1EE U+1F1EA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/IE.svg",
      },
      {
        name: "Israel",
        code: "IL",
        emoji: "🇮🇱",
        unicode: "U+1F1EE U+1F1F1",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/IL.svg",
      },
      {
        name: "Isle of Man",
        code: "IM",
        emoji: "🇮🇲",
        unicode: "U+1F1EE U+1F1F2",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/IM.svg",
      },
      {
        name: "India",
        code: "IN",
        emoji: "🇮🇳",
        unicode: "U+1F1EE U+1F1F3",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/IN.svg",
      },
      {
        name: "British Indian Ocean Territory",
        code: "IO",
        emoji: "🇮🇴",
        unicode: "U+1F1EE U+1F1F4",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/IO.svg",
      },
      {
        name: "Iraq",
        code: "IQ",
        emoji: "🇮🇶",
        unicode: "U+1F1EE U+1F1F6",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/IQ.svg",
      },
      {
        name: "Iran",
        code: "IR",
        emoji: "🇮🇷",
        unicode: "U+1F1EE U+1F1F7",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/IR.svg",
      },
      {
        name: "Iceland",
        code: "IS",
        emoji: "🇮🇸",
        unicode: "U+1F1EE U+1F1F8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/IS.svg",
      },
      {
        name: "Italy",
        code: "IT",
        emoji: "🇮🇹",
        unicode: "U+1F1EE U+1F1F9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/IT.svg",
      },
      {
        name: "Jersey",
        code: "JE",
        emoji: "🇯🇪",
        unicode: "U+1F1EF U+1F1EA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/JE.svg",
      },
      {
        name: "Jamaica",
        code: "JM",
        emoji: "🇯🇲",
        unicode: "U+1F1EF U+1F1F2",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/JM.svg",
      },
      {
        name: "Jordan",
        code: "JO",
        emoji: "🇯🇴",
        unicode: "U+1F1EF U+1F1F4",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/JO.svg",
      },
      {
        name: "Japan",
        code: "JP",
        emoji: "🇯🇵",
        unicode: "U+1F1EF U+1F1F5",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/JP.svg",
      },
      {
        name: "Kenya",
        code: "KE",
        emoji: "🇰🇪",
        unicode: "U+1F1F0 U+1F1EA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/KE.svg",
      },
      {
        name: "Kyrgyzstan",
        code: "KG",
        emoji: "🇰🇬",
        unicode: "U+1F1F0 U+1F1EC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/KG.svg",
      },
      {
        name: "Cambodia",
        code: "KH",
        emoji: "🇰🇭",
        unicode: "U+1F1F0 U+1F1ED",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/KH.svg",
      },
      {
        name: "Kiribati",
        code: "KI",
        emoji: "🇰🇮",
        unicode: "U+1F1F0 U+1F1EE",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/KI.svg",
      },
      {
        name: "Comoros",
        code: "KM",
        emoji: "🇰🇲",
        unicode: "U+1F1F0 U+1F1F2",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/KM.svg",
      },
      {
        name: "St. Kitts & Nevis",
        code: "KN",
        emoji: "🇰🇳",
        unicode: "U+1F1F0 U+1F1F3",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/KN.svg",
      },
      {
        name: "North Korea",
        code: "KP",
        emoji: "🇰🇵",
        unicode: "U+1F1F0 U+1F1F5",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/KP.svg",
      },
      {
        name: "South Korea",
        code: "KR",
        emoji: "🇰🇷",
        unicode: "U+1F1F0 U+1F1F7",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/KR.svg",
      },
      {
        name: "Kuwait",
        code: "KW",
        emoji: "🇰🇼",
        unicode: "U+1F1F0 U+1F1FC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/KW.svg",
      },
      {
        name: "Cayman Islands",
        code: "KY",
        emoji: "🇰🇾",
        unicode: "U+1F1F0 U+1F1FE",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/KY.svg",
      },
      {
        name: "Kazakhstan",
        code: "KZ",
        emoji: "🇰🇿",
        unicode: "U+1F1F0 U+1F1FF",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/KZ.svg",
      },
      {
        name: "Laos",
        code: "LA",
        emoji: "🇱🇦",
        unicode: "U+1F1F1 U+1F1E6",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/LA.svg",
      },
      {
        name: "Lebanon",
        code: "LB",
        emoji: "🇱🇧",
        unicode: "U+1F1F1 U+1F1E7",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/LB.svg",
      },
      {
        name: "St. Lucia",
        code: "LC",
        emoji: "🇱🇨",
        unicode: "U+1F1F1 U+1F1E8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/LC.svg",
      },
      {
        name: "Liechtenstein",
        code: "LI",
        emoji: "🇱🇮",
        unicode: "U+1F1F1 U+1F1EE",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/LI.svg",
      },
      {
        name: "Sri Lanka",
        code: "LK",
        emoji: "🇱🇰",
        unicode: "U+1F1F1 U+1F1F0",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/LK.svg",
      },
      {
        name: "Liberia",
        code: "LR",
        emoji: "🇱🇷",
        unicode: "U+1F1F1 U+1F1F7",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/LR.svg",
      },
      {
        name: "Lesotho",
        code: "LS",
        emoji: "🇱🇸",
        unicode: "U+1F1F1 U+1F1F8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/LS.svg",
      },
      {
        name: "Lithuania",
        code: "LT",
        emoji: "🇱🇹",
        unicode: "U+1F1F1 U+1F1F9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/LT.svg",
      },
      {
        name: "Luxembourg",
        code: "LU",
        emoji: "🇱🇺",
        unicode: "U+1F1F1 U+1F1FA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/LU.svg",
      },
      {
        name: "Latvia",
        code: "LV",
        emoji: "🇱🇻",
        unicode: "U+1F1F1 U+1F1FB",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/LV.svg",
      },
      {
        name: "Libya",
        code: "LY",
        emoji: "🇱🇾",
        unicode: "U+1F1F1 U+1F1FE",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/LY.svg",
      },
      {
        name: "Morocco",
        code: "MA",
        emoji: "🇲🇦",
        unicode: "U+1F1F2 U+1F1E6",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MA.svg",
      },
      {
        name: "Monaco",
        code: "MC",
        emoji: "🇲🇨",
        unicode: "U+1F1F2 U+1F1E8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MC.svg",
      },
      {
        name: "Moldova",
        code: "MD",
        emoji: "🇲🇩",
        unicode: "U+1F1F2 U+1F1E9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MD.svg",
      },
      {
        name: "Montenegro",
        code: "ME",
        emoji: "🇲🇪",
        unicode: "U+1F1F2 U+1F1EA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/ME.svg",
      },
      {
        name: "St. Martin",
        code: "MF",
        emoji: "🇲🇫",
        unicode: "U+1F1F2 U+1F1EB",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MF.svg",
      },
      {
        name: "Madagascar",
        code: "MG",
        emoji: "🇲🇬",
        unicode: "U+1F1F2 U+1F1EC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MG.svg",
      },
      {
        name: "Marshall Islands",
        code: "MH",
        emoji: "🇲🇭",
        unicode: "U+1F1F2 U+1F1ED",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MH.svg",
      },
      {
        name: "North Macedonia",
        code: "MK",
        emoji: "🇲🇰",
        unicode: "U+1F1F2 U+1F1F0",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MK.svg",
      },
      {
        name: "Mali",
        code: "ML",
        emoji: "🇲🇱",
        unicode: "U+1F1F2 U+1F1F1",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/ML.svg",
      },
      {
        name: "Myanmar (Burma)",
        code: "MM",
        emoji: "🇲🇲",
        unicode: "U+1F1F2 U+1F1F2",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MM.svg",
      },
      {
        name: "Mongolia",
        code: "MN",
        emoji: "🇲🇳",
        unicode: "U+1F1F2 U+1F1F3",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MN.svg",
      },
      {
        name: "Macao SAR China",
        code: "MO",
        emoji: "🇲🇴",
        unicode: "U+1F1F2 U+1F1F4",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MO.svg",
      },
      {
        name: "Northern Mariana Islands",
        code: "MP",
        emoji: "🇲🇵",
        unicode: "U+1F1F2 U+1F1F5",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MP.svg",
      },
      {
        name: "Martinique",
        code: "MQ",
        emoji: "🇲🇶",
        unicode: "U+1F1F2 U+1F1F6",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MQ.svg",
      },
      {
        name: "Mauritania",
        code: "MR",
        emoji: "🇲🇷",
        unicode: "U+1F1F2 U+1F1F7",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MR.svg",
      },
      {
        name: "Montserrat",
        code: "MS",
        emoji: "🇲🇸",
        unicode: "U+1F1F2 U+1F1F8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MS.svg",
      },
      {
        name: "Malta",
        code: "MT",
        emoji: "🇲🇹",
        unicode: "U+1F1F2 U+1F1F9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MT.svg",
      },
      {
        name: "Mauritius",
        code: "MU",
        emoji: "🇲🇺",
        unicode: "U+1F1F2 U+1F1FA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MU.svg",
      },
      {
        name: "Maldives",
        code: "MV",
        emoji: "🇲🇻",
        unicode: "U+1F1F2 U+1F1FB",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MV.svg",
      },
      {
        name: "Malawi",
        code: "MW",
        emoji: "🇲🇼",
        unicode: "U+1F1F2 U+1F1FC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MW.svg",
      },
      {
        name: "Mexico",
        code: "MX",
        emoji: "🇲🇽",
        unicode: "U+1F1F2 U+1F1FD",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MX.svg",
      },
      {
        name: "Malaysia",
        code: "MY",
        emoji: "🇲🇾",
        unicode: "U+1F1F2 U+1F1FE",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MY.svg",
      },
      {
        name: "Mozambique",
        code: "MZ",
        emoji: "🇲🇿",
        unicode: "U+1F1F2 U+1F1FF",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/MZ.svg",
      },
      {
        name: "Namibia",
        code: "NA",
        emoji: "🇳🇦",
        unicode: "U+1F1F3 U+1F1E6",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/NA.svg",
      },
      {
        name: "New Caledonia",
        code: "NC",
        emoji: "🇳🇨",
        unicode: "U+1F1F3 U+1F1E8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/NC.svg",
      },
      {
        name: "Niger",
        code: "NE",
        emoji: "🇳🇪",
        unicode: "U+1F1F3 U+1F1EA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/NE.svg",
      },
      {
        name: "Norfolk Island",
        code: "NF",
        emoji: "🇳🇫",
        unicode: "U+1F1F3 U+1F1EB",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/NF.svg",
      },
      {
        name: "Nigeria",
        code: "NG",
        emoji: "🇳🇬",
        unicode: "U+1F1F3 U+1F1EC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/NG.svg",
      },
      {
        name: "Nicaragua",
        code: "NI",
        emoji: "🇳🇮",
        unicode: "U+1F1F3 U+1F1EE",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/NI.svg",
      },
      {
        name: "Netherlands",
        code: "NL",
        emoji: "🇳🇱",
        unicode: "U+1F1F3 U+1F1F1",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/NL.svg",
      },
      {
        name: "Norway",
        code: "NO",
        emoji: "🇳🇴",
        unicode: "U+1F1F3 U+1F1F4",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/NO.svg",
      },
      {
        name: "Nepal",
        code: "NP",
        emoji: "🇳🇵",
        unicode: "U+1F1F3 U+1F1F5",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/NP.svg",
      },
      {
        name: "Nauru",
        code: "NR",
        emoji: "🇳🇷",
        unicode: "U+1F1F3 U+1F1F7",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/NR.svg",
      },
      {
        name: "Niue",
        code: "NU",
        emoji: "🇳🇺",
        unicode: "U+1F1F3 U+1F1FA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/NU.svg",
      },
      {
        name: "New Zealand",
        code: "NZ",
        emoji: "🇳🇿",
        unicode: "U+1F1F3 U+1F1FF",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/NZ.svg",
      },
      {
        name: "Oman",
        code: "OM",
        emoji: "🇴🇲",
        unicode: "U+1F1F4 U+1F1F2",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/OM.svg",
      },
      {
        name: "Panama",
        code: "PA",
        emoji: "🇵🇦",
        unicode: "U+1F1F5 U+1F1E6",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/PA.svg",
      },
      {
        name: "Peru",
        code: "PE",
        emoji: "🇵🇪",
        unicode: "U+1F1F5 U+1F1EA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/PE.svg",
      },
      {
        name: "French Polynesia",
        code: "PF",
        emoji: "🇵🇫",
        unicode: "U+1F1F5 U+1F1EB",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/PF.svg",
      },
      {
        name: "Papua New Guinea",
        code: "PG",
        emoji: "🇵🇬",
        unicode: "U+1F1F5 U+1F1EC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/PG.svg",
      },
      {
        name: "Philippines",
        code: "PH",
        emoji: "🇵🇭",
        unicode: "U+1F1F5 U+1F1ED",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/PH.svg",
      },
      {
        name: "Pakistan",
        code: "PK",
        emoji: "🇵🇰",
        unicode: "U+1F1F5 U+1F1F0",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/PK.svg",
      },
      {
        name: "Poland",
        code: "PL",
        emoji: "🇵🇱",
        unicode: "U+1F1F5 U+1F1F1",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/PL.svg",
      },
      {
        name: "St. Pierre & Miquelon",
        code: "PM",
        emoji: "🇵🇲",
        unicode: "U+1F1F5 U+1F1F2",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/PM.svg",
      },
      {
        name: "Pitcairn Islands",
        code: "PN",
        emoji: "🇵🇳",
        unicode: "U+1F1F5 U+1F1F3",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/PN.svg",
      },
      {
        name: "Puerto Rico",
        code: "PR",
        emoji: "🇵🇷",
        unicode: "U+1F1F5 U+1F1F7",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/PR.svg",
      },
      {
        name: "Palestinian Territories",
        code: "PS",
        emoji: "🇵🇸",
        unicode: "U+1F1F5 U+1F1F8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/PS.svg",
      },
      {
        name: "Portugal",
        code: "PT",
        emoji: "🇵🇹",
        unicode: "U+1F1F5 U+1F1F9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/PT.svg",
      },
      {
        name: "Palau",
        code: "PW",
        emoji: "🇵🇼",
        unicode: "U+1F1F5 U+1F1FC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/PW.svg",
      },
      {
        name: "Paraguay",
        code: "PY",
        emoji: "🇵🇾",
        unicode: "U+1F1F5 U+1F1FE",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/PY.svg",
      },
      {
        name: "Qatar",
        code: "QA",
        emoji: "🇶🇦",
        unicode: "U+1F1F6 U+1F1E6",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/QA.svg",
      },
      {
        name: "Réunion",
        code: "RE",
        emoji: "🇷🇪",
        unicode: "U+1F1F7 U+1F1EA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/RE.svg",
      },
      {
        name: "Romania",
        code: "RO",
        emoji: "🇷🇴",
        unicode: "U+1F1F7 U+1F1F4",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/RO.svg",
      },
      {
        name: "Serbia",
        code: "RS",
        emoji: "🇷🇸",
        unicode: "U+1F1F7 U+1F1F8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/RS.svg",
      },
      {
        name: "Russia",
        code: "RU",
        emoji: "🇷🇺",
        unicode: "U+1F1F7 U+1F1FA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/RU.svg",
      },
      {
        name: "Rwanda",
        code: "RW",
        emoji: "🇷🇼",
        unicode: "U+1F1F7 U+1F1FC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/RW.svg",
      },
      {
        name: "Saudi Arabia",
        code: "SA",
        emoji: "🇸🇦",
        unicode: "U+1F1F8 U+1F1E6",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SA.svg",
      },
      {
        name: "Solomon Islands",
        code: "SB",
        emoji: "🇸🇧",
        unicode: "U+1F1F8 U+1F1E7",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SB.svg",
      },
      {
        name: "Seychelles",
        code: "SC",
        emoji: "🇸🇨",
        unicode: "U+1F1F8 U+1F1E8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SC.svg",
      },
      {
        name: "Sudan",
        code: "SD",
        emoji: "🇸🇩",
        unicode: "U+1F1F8 U+1F1E9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SD.svg",
      },
      {
        name: "Sweden",
        code: "SE",
        emoji: "🇸🇪",
        unicode: "U+1F1F8 U+1F1EA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SE.svg",
      },
      {
        name: "Singapore",
        code: "SG",
        emoji: "🇸🇬",
        unicode: "U+1F1F8 U+1F1EC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SG.svg",
      },
      {
        name: "St. Helena",
        code: "SH",
        emoji: "🇸🇭",
        unicode: "U+1F1F8 U+1F1ED",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SH.svg",
      },
      {
        name: "Slovenia",
        code: "SI",
        emoji: "🇸🇮",
        unicode: "U+1F1F8 U+1F1EE",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SI.svg",
      },
      {
        name: "Svalbard & Jan Mayen",
        code: "SJ",
        emoji: "🇸🇯",
        unicode: "U+1F1F8 U+1F1EF",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SJ.svg",
      },
      {
        name: "Slovakia",
        code: "SK",
        emoji: "🇸🇰",
        unicode: "U+1F1F8 U+1F1F0",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SK.svg",
      },
      {
        name: "Sierra Leone",
        code: "SL",
        emoji: "🇸🇱",
        unicode: "U+1F1F8 U+1F1F1",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SL.svg",
      },
      {
        name: "San Marino",
        code: "SM",
        emoji: "🇸🇲",
        unicode: "U+1F1F8 U+1F1F2",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SM.svg",
      },
      {
        name: "Senegal",
        code: "SN",
        emoji: "🇸🇳",
        unicode: "U+1F1F8 U+1F1F3",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SN.svg",
      },
      {
        name: "Somalia",
        code: "SO",
        emoji: "🇸🇴",
        unicode: "U+1F1F8 U+1F1F4",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SO.svg",
      },
      {
        name: "Suriname",
        code: "SR",
        emoji: "🇸🇷",
        unicode: "U+1F1F8 U+1F1F7",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SR.svg",
      },
      {
        name: "South Sudan",
        code: "SS",
        emoji: "🇸🇸",
        unicode: "U+1F1F8 U+1F1F8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SS.svg",
      },
      {
        name: "São Tomé & Príncipe",
        code: "ST",
        emoji: "🇸🇹",
        unicode: "U+1F1F8 U+1F1F9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/ST.svg",
      },
      {
        name: "El Salvador",
        code: "SV",
        emoji: "🇸🇻",
        unicode: "U+1F1F8 U+1F1FB",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SV.svg",
      },
      {
        name: "Sint Maarten",
        code: "SX",
        emoji: "🇸🇽",
        unicode: "U+1F1F8 U+1F1FD",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SX.svg",
      },
      {
        name: "Syria",
        code: "SY",
        emoji: "🇸🇾",
        unicode: "U+1F1F8 U+1F1FE",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SY.svg",
      },
      {
        name: "Eswatini",
        code: "SZ",
        emoji: "🇸🇿",
        unicode: "U+1F1F8 U+1F1FF",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SZ.svg",
      },
      {
        name: "Tristan da Cunha",
        code: "TA",
        emoji: "🇹🇦",
        unicode: "U+1F1F9 U+1F1E6",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/TA.svg",
      },
      {
        name: "Turks & Caicos Islands",
        code: "TC",
        emoji: "🇹🇨",
        unicode: "U+1F1F9 U+1F1E8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/TC.svg",
      },
      {
        name: "Chad",
        code: "TD",
        emoji: "🇹🇩",
        unicode: "U+1F1F9 U+1F1E9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/TD.svg",
      },
      {
        name: "French Southern Territories",
        code: "TF",
        emoji: "🇹🇫",
        unicode: "U+1F1F9 U+1F1EB",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/TF.svg",
      },
      {
        name: "Togo",
        code: "TG",
        emoji: "🇹🇬",
        unicode: "U+1F1F9 U+1F1EC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/TG.svg",
      },
      {
        name: "Thailand",
        code: "TH",
        emoji: "🇹🇭",
        unicode: "U+1F1F9 U+1F1ED",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/TH.svg",
      },
      {
        name: "Tajikistan",
        code: "TJ",
        emoji: "🇹🇯",
        unicode: "U+1F1F9 U+1F1EF",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/TJ.svg",
      },
      {
        name: "Tokelau",
        code: "TK",
        emoji: "🇹🇰",
        unicode: "U+1F1F9 U+1F1F0",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/TK.svg",
      },
      {
        name: "Timor-Leste",
        code: "TL",
        emoji: "🇹🇱",
        unicode: "U+1F1F9 U+1F1F1",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/TL.svg",
      },
      {
        name: "Turkmenistan",
        code: "TM",
        emoji: "🇹🇲",
        unicode: "U+1F1F9 U+1F1F2",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/TM.svg",
      },
      {
        name: "Tunisia",
        code: "TN",
        emoji: "🇹🇳",
        unicode: "U+1F1F9 U+1F1F3",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/TN.svg",
      },
      {
        name: "Tonga",
        code: "TO",
        emoji: "🇹🇴",
        unicode: "U+1F1F9 U+1F1F4",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/TO.svg",
      },
      {
        name: "Turkey",
        code: "TR",
        emoji: "🇹🇷",
        unicode: "U+1F1F9 U+1F1F7",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/TR.svg",
      },
      {
        name: "Trinidad & Tobago",
        code: "TT",
        emoji: "🇹🇹",
        unicode: "U+1F1F9 U+1F1F9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/TT.svg",
      },
      {
        name: "Tuvalu",
        code: "TV",
        emoji: "🇹🇻",
        unicode: "U+1F1F9 U+1F1FB",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/TV.svg",
      },
      {
        name: "Taiwan",
        code: "TW",
        emoji: "🇹🇼",
        unicode: "U+1F1F9 U+1F1FC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/TW.svg",
      },
      {
        name: "Tanzania",
        code: "TZ",
        emoji: "🇹🇿",
        unicode: "U+1F1F9 U+1F1FF",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/TZ.svg",
      },
      {
        name: "Ukraine",
        code: "UA",
        emoji: "🇺🇦",
        unicode: "U+1F1FA U+1F1E6",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/UA.svg",
      },
      {
        name: "Uganda",
        code: "UG",
        emoji: "🇺🇬",
        unicode: "U+1F1FA U+1F1EC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/UG.svg",
      },
      {
        name: "U.S. Outlying Islands",
        code: "UM",
        emoji: "🇺🇲",
        unicode: "U+1F1FA U+1F1F2",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/UM.svg",
      },
      {
        name: "United Nations",
        code: "UN",
        emoji: "🇺🇳",
        unicode: "U+1F1FA U+1F1F3",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/UN.svg",
      },
      {
        name: "United States",
        code: "US",
        emoji: "🇺🇸",
        unicode: "U+1F1FA U+1F1F8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/US.svg",
      },
      {
        name: "Uruguay",
        code: "UY",
        emoji: "🇺🇾",
        unicode: "U+1F1FA U+1F1FE",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/UY.svg",
      },
      {
        name: "Uzbekistan",
        code: "UZ",
        emoji: "🇺🇿",
        unicode: "U+1F1FA U+1F1FF",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/UZ.svg",
      },
      {
        name: "Vatican City",
        code: "VA",
        emoji: "🇻🇦",
        unicode: "U+1F1FB U+1F1E6",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/VA.svg",
      },
      {
        name: "St. Vincent & Grenadines",
        code: "VC",
        emoji: "🇻🇨",
        unicode: "U+1F1FB U+1F1E8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/VC.svg",
      },
      {
        name: "Venezuela",
        code: "VE",
        emoji: "🇻🇪",
        unicode: "U+1F1FB U+1F1EA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/VE.svg",
      },
      {
        name: "British Virgin Islands",
        code: "VG",
        emoji: "🇻🇬",
        unicode: "U+1F1FB U+1F1EC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/VG.svg",
      },
      {
        name: "U.S. Virgin Islands",
        code: "VI",
        emoji: "🇻🇮",
        unicode: "U+1F1FB U+1F1EE",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/VI.svg",
      },
      {
        name: "Vietnam",
        code: "VN",
        emoji: "🇻🇳",
        unicode: "U+1F1FB U+1F1F3",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/VN.svg",
      },
      {
        name: "Vanuatu",
        code: "VU",
        emoji: "🇻🇺",
        unicode: "U+1F1FB U+1F1FA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/VU.svg",
      },
      {
        name: "Wallis & Futuna",
        code: "WF",
        emoji: "🇼🇫",
        unicode: "U+1F1FC U+1F1EB",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/WF.svg",
      },
      {
        name: "Samoa",
        code: "WS",
        emoji: "🇼🇸",
        unicode: "U+1F1FC U+1F1F8",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/WS.svg",
      },
      {
        name: "Kosovo",
        code: "XK",
        emoji: "🇽🇰",
        unicode: "U+1F1FD U+1F1F0",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/XK.svg",
      },
      {
        name: "Yemen",
        code: "YE",
        emoji: "🇾🇪",
        unicode: "U+1F1FE U+1F1EA",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/YE.svg",
      },
      {
        name: "Mayotte",
        code: "YT",
        emoji: "🇾🇹",
        unicode: "U+1F1FE U+1F1F9",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/YT.svg",
      },
      {
        name: "South Africa",
        code: "ZA",
        emoji: "🇿🇦",
        unicode: "U+1F1FF U+1F1E6",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/ZA.svg",
      },
      {
        name: "Zambia",
        code: "ZM",
        emoji: "🇿🇲",
        unicode: "U+1F1FF U+1F1F2",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/ZM.svg",
      },
      {
        name: "Zimbabwe",
        code: "ZW",
        emoji: "🇿🇼",
        unicode: "U+1F1FF U+1F1FC",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/ZW.svg",
      },
      {
        name: "England",
        code: "ENGLAND",
        emoji: "🏴󠁧󠁢󠁥󠁮󠁧󠁿",
        unicode: "U+1F3F4 U+E0067 U+E0062 U+E0065 U+E006E U+E0067 U+E007F",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/ENGLAND.svg",
      },
      {
        name: "Scotland",
        code: "SCOTLAND",
        emoji: "🏴󠁧󠁢󠁳󠁣󠁴󠁿",
        unicode: "U+1F3F4 U+E0067 U+E0062 U+E0073 U+E0063 U+E0074 U+E007F",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/SCOTLAND.svg",
      },
      {
        name: "Wales",
        code: "WALES",
        emoji: "🏴󠁧󠁢󠁷󠁬󠁳󠁿",
        unicode: "U+1F3F4 U+E0067 U+E0062 U+E0077 U+E006C U+E0073 U+E007F",
        image: "https://cdn.jsdelivr.net/npm/country-flag-emoji-json@2.0.0/dist/images/WALES.svg",
      },
    ];
    e.i(378450);
    var t = e.i(460715),
      a = e.i(264267);
    e.i(271645);
    let m = (0, a.svgImage)("/illustrations/adhd/motiv-adhd-1.svg", { width: 911, height: 1080 }),
      d = (0, a.svgImage)("/illustrations/adhd/motiv-adhd-2.svg", { width: 1033, height: 680 }),
      c = (0, a.svgImage)("/illustrations/adhd/motiv-adhd-3.svg", { width: 1081, height: 1020 });
    var l = e.i(768644);
    let r = (0, a.svgImage)("/illustrations/attachment/motiv-1.svg", { width: 883, height: 830 }),
      g = (0, a.svgImage)("/illustrations/attachment/motiv-2.svg", { width: 905, height: 757 }),
      j = (0, a.svgImage)("/illustrations/attachment/motiv-3.svg", { width: 1081, height: 965 });
    var u = e.i(992767),
      F = e.i(849411),
      p = e.i(807962),
      v = e.i(781697),
      U = e.i(892515),
      h = e.i(757331);
    let y = (0, a.svgImage)("/illustrations/personality/motiv-person-1.svg", { width: 438, height: 212 }),
      f = (0, a.svgImage)("/illustrations/personality/motiv-person-2.svg", { width: 439, height: 212 }),
      E = (0, a.svgImage)("/illustrations/personality/motiv-person-3.svg", { width: 439, height: 212 });
    var _ = e.i(350015),
      A = e.i(152594),
      x = e.i(865917),
      w = e.i(657732),
      M = e.i(392566);
    let N = /^<\/?(span|b|strong|em|i|br)(\s+class=(['"])[\w\s:.[\]/%#-]*\3)?\s*\/?>$/i,
      S = /^motivation_title_\d+$/,
      C = (e) => ({
        honesty: {
          title: e("personality_motivation_honesty_title"),
          description: e("personality_motivation_honesty_description"),
        },
        emotionalV2: {
          title: e("personality_motivation_emotional_title"),
          description: e("personality_motivation_emotional_v2_description"),
        },
        emotionalV3: {
          title: e("personality_motivation_emotional_title"),
          description: e("personality_motivation_emotional_v3_description"),
        },
        halfway: {
          title: e("personality_motivation_halfway_title"),
          description: e("personality_motivation_halfway_description"),
        },
        decision: {
          title: e("personality_motivation_decision_title"),
          description: e("personality_motivation_decision_description"),
        },
        narrowing: {
          title: e("personality_motivation_narrowing_title"),
          description: e("personality_motivation_narrowing_description"),
        },
        almostThere: {
          title: e("personality_motivation_almost_there_title"),
          description: e("personality_motivation_almost_there_description"),
        },
      }),
      I = (e, i) => {
        let n = i?.currency?.countryCode || "US",
          s = o.find((e) => e.code === n);
        return "name" === e ? s?.name || "" : s?.image || "";
      },
      T = (e) => {
        let o,
          {
            user: a,
            variant: T,
            motivationalScore: B,
            personalityVariant: G,
            quizLength: P,
            similarPct: D,
          } = e,
          L =
            (o = e.testData) &&
            Object.fromEntries(
              Object.entries(o).map((e) => {
                let [i, n] = e;
                return [
                  i,
                  S.test(i) && "string" == typeof n
                    ? n.replace(/<[^>]*>?/g, (e) => (N.test(e) ? e : e.replace(/</g, "&lt;")))
                    : n,
                ];
              }),
            ),
          b = (0, n.useTranslations)();
        switch (T) {
          case "personality": {
            let e;
            if (2 === G) {
              let e;
              return (
                (e = C(b)),
                {
                  [s.PERSONALITY_V2_MOTIVATION_STEPS[0]]: {
                    icon: (0, i.jsx)(y, { className: "scale-125 max-xs-sm:scale-100 xs-sm:scale-100" }),
                    ...e.honesty,
                  },
                  [s.PERSONALITY_V2_MOTIVATION_STEPS[1]]: {
                    icon: (0, i.jsx)(f, { className: "scale-125 max-xs-sm:scale-100 xs-sm:scale-100" }),
                    ...e.emotionalV2,
                  },
                  [s.PERSONALITY_V2_MOTIVATION_STEPS[2]]: {
                    icon: (0, i.jsx)(E, { className: "scale-125 max-xs-sm:scale-100 xs-sm:scale-100" }),
                    ...e.halfway,
                  },
                  [s.PERSONALITY_V2_MOTIVATION_STEPS[3]]: {
                    icon: (0, i.jsx)(p.IconConfidenceMotiv1, { className: "h-full w-full md:scale-125" }),
                    ...e.narrowing,
                  },
                  [s.PERSONALITY_V2_MOTIVATION_STEPS[4]]: {
                    icon: (0, i.jsx)(p.IconConfidenceMotiv2, { className: "h-full w-full md:scale-125" }),
                    ...e.almostThere,
                  },
                }
              );
            }
            if (3 === G) {
              let e;
              return (
                (e = C(b)),
                {
                  [s.PERSONALITY_V3_MOTIVATION_STEPS[0]]: {
                    icon: (0, i.jsx)(y, { className: "scale-125 max-xs-sm:scale-100 xs-sm:scale-100" }),
                    ...e.honesty,
                  },
                  [s.PERSONALITY_V3_MOTIVATION_STEPS[1]]: {
                    icon: (0, i.jsx)(f, { className: "scale-125 max-xs-sm:scale-100 xs-sm:scale-100" }),
                    ...e.emotionalV3,
                  },
                  [s.PERSONALITY_V3_MOTIVATION_STEPS[2]]: {
                    icon: (0, i.jsx)(E, { className: "scale-125 max-xs-sm:scale-100 xs-sm:scale-100" }),
                    ...e.decision,
                  },
                  [s.PERSONALITY_V3_MOTIVATION_STEPS[3]]: {
                    icon: (0, i.jsx)(p.IconConfidenceMotiv1, { className: "h-full w-full md:scale-125" }),
                    ...e.narrowing,
                  },
                }
              );
            }
            let n = B?.titlePercentage,
              o = B?.descriptionPercentage,
              t = {
                icon: (0, i.jsx)(y, { className: "scale-125 max-xs-sm:scale-100 xs-sm:scale-100" }),
                title: b.markup("personality_motivation_1", {
                  percentage: n ?? "90",
                  span: (e) => `<span class="text-blue-600">${e}</span>`,
                }),
                description: b("personality_motivation_1_subtitle"),
              },
              m = {
                icon: (0, i.jsx)(f, { className: "scale-125 max-xs-sm:scale-100 xs-sm:scale-100" }),
                title: b.markup("personality_motivation_2", {
                  percentage: n ?? "17",
                  country: (e = I("flag", a))
                    ? `<img src=${e} alt='country flag' class='inline-block w-6 h-6 ml-1 mb-1 ${void 0 ?? ""}'/>`
                    : "your country",
                  span: (e) => `<span class='text-blue-600'>${e}</span>`,
                }),
                description: b("personality_motivation_2_subtitle", { percentage: o ?? "83" }),
              },
              d = {
                icon: (0, i.jsx)(E, { className: "scale-125 max-xs-sm:scale-100 xs-sm:scale-100" }),
                title: b.markup("personality_motivation_3", {
                  percentage: n ?? "7",
                  span: (e) => `<span class='text-blue-600'>${e}</span>`,
                }),
                description: b("personality_motivation_3_subtitle"),
              };
            return { 25: t, 50: m, 75: d, 15: t, 30: m, 45: d, 7: t, 14: m, 21: d };
          }
          case "enneagram": {
            let e = (0, t.getEnneagramMotivationContent)(b),
              n = [
                (0, i.jsx)(y, { className: "scale-125 max-xs-sm:scale-100 xs-sm:scale-100" }, "motiv-1"),
                (0, i.jsx)(f, { className: "scale-125 max-xs-sm:scale-100 xs-sm:scale-100" }, "motiv-2"),
                (0, i.jsx)(E, { className: "scale-125 max-xs-sm:scale-100 xs-sm:scale-100" }, "motiv-3"),
              ];
            return Object.entries(e).reduce((e, i, s) => {
              let [o, t] = i;
              return ((e[Number(o)] = { icon: n[s], title: t.title, description: t.description }), e);
            }, {});
          }
          case "autism":
            return {
              30: {
                icon: (0, i.jsx)(y, { className: "scale-125 max-xs-sm:scale-100 xs-sm:scale-100" }),
                title: b("autism_motivation_title_1"),
                description: b("autism_motivation_description_1"),
              },
              50: {
                icon: (0, i.jsx)(f, { className: "scale-125 max-xs-sm:scale-100 xs-sm:scale-100" }),
                title: b("autism_motivation_title_2"),
                description: b("autism_motivation_description_2"),
              },
              70: {
                icon: (0, i.jsx)(E, { className: "scale-125 max-xs-sm:scale-100 xs-sm:scale-100" }),
                title: b("autism_motivation_title_3"),
                description: b("autism_motivation_description_3"),
              },
            };
          case "procrastination":
            return {
              20: {
                icon: (0, i.jsx)(_.IconProcrastinationMotiv1, { className: "h-full w-full md:scale-125" }),
                title: L?.motivation_title_1 || "20 Questions Down",
                description:
                  L?.motivation_description_1 ||
                  "Keep going — your honest answers are all that matters here.",
              },
              40: {
                icon: (0, i.jsx)(M.IconWorkMotiv2, { className: "h-full w-full md:scale-125" }),
                title: L?.motivation_title_2 || "Halfway There",
                description:
                  L?.motivation_description_2 ||
                  "You've answered 40 questions. Take your time with the rest.",
              },
              60: {
                icon: (0, i.jsx)(M.IconWorkMotiv3, { className: "h-full w-full md:scale-125" }),
                title: L?.motivation_title_3 || "Almost Done — 20 Questions Left",
                description:
                  L?.motivation_description_3 ||
                  "Your summary is almost ready. Answer the last few honestly.",
              },
            };
          case "anxiety":
            return {
              20: {
                icon: (0, i.jsx)(l.IconAnxietyMotiv1, { className: "h-full w-full md:scale-125" }),
                title: L?.motivation_title_1 || "20 Questions Down",
                description:
                  L?.motivation_description_1 ||
                  "Keep going — your honest answers are all that matters here.",
              },
              40: {
                icon: (0, i.jsx)(l.IconAnxietyMotiv2, { className: "h-full w-full md:scale-125" }),
                title: L?.motivation_title_2 || "Halfway There",
                description:
                  L?.motivation_description_2 ||
                  "You've answered 40 questions. Take your time with the rest.",
              },
              70: {
                icon: (0, i.jsx)(l.IconAnxietyMotiv3, { className: "h-full w-full md:scale-125" }),
                title: L?.motivation_title_3 || "Almost Done — 10 Questions Left",
                description:
                  L?.motivation_description_3 ||
                  "Your summary is almost ready. Answer the last few honestly.",
              },
            };
          case "strengths":
            return {
              6: {
                icon: (0, i.jsx)(x.IconStrengthsMotiv1, { className: "h-full w-full md:scale-125" }),
                title: L?.motivation_title_1 || "Discover What Sets You Apart ✨",
                description:
                  L?.motivation_description_1 ||
                  " Every answer you give brings you closer to revealing the strengths you might be overlooking — traits that quietly shape how you lead, connect, and grow.",
              },
              14: {
                icon: (0, i.jsx)(x.IconStrengthsMotiv2, { className: "h-full w-full md:scale-125" }),
                title: L?.motivation_title_2 || "You’re Uncovering Hidden Power 💡",
                description:
                  L?.motivation_description_2 ||
                  "Self-awareness is a superpower. You’re exploring the parts of yourself that don’t always get the spotlight — but that deeply matter.",
              },
              20: {
                icon: (0, i.jsx)(x.IconStrengthsMotiv3, { className: "h-full w-full md:scale-125" }),
                title: L?.motivation_title_3 || '<span class="font-bold">You’re almost done 💫</span>',
                description:
                  L?.motivation_description_3 ||
                  "Just a few more questions! You’re about to discover the inner qualities that fuel your resilience, creativity, and impact.",
              },
            };
          case "confidence":
            return {
              20: {
                icon: (0, i.jsx)(p.IconConfidenceMotiv1, { className: "h-full w-full md:scale-125" }),
                title: L?.motivation_title_1 || "20 Questions Down",
                description:
                  L?.motivation_description_1 ||
                  "Keep going - your honest answers are all that matters here.",
              },
              40: {
                icon: (0, i.jsx)(p.IconConfidenceMotiv2, { className: "h-full w-full md:scale-125" }),
                title: L?.motivation_title_2 || "Halfway There",
                description:
                  L?.motivation_description_2 ||
                  "You've answered 40 questions. Take your time with the rest.",
              },
              60: {
                icon: (0, i.jsx)(p.IconConfidenceMotiv3, { className: "h-full w-full md:scale-125" }),
                title: L?.motivation_title_3 || "Almost Done - 20 Questions Left",
                description:
                  L?.motivation_description_3 ||
                  "Your summary is almost ready. Answer the last few honestly.",
              },
            };
          case "psychological_archetypes":
            return {
              20: {
                icon: (0, i.jsx)(A.IconPsychologicalArchetypesMotiv1, {
                  className: "h-full w-full md:scale-150",
                }),
                title: L?.motivation_title_1 || "20 Questions Down",
                description:
                  L?.motivation_description_1 ||
                  "Keep going - your honest answers are all that matters here.",
              },
              40: {
                icon: (0, i.jsx)(A.IconPsychologicalArchetypesMotiv2, {
                  className: "h-full w-full md:scale-150",
                }),
                title: L?.motivation_title_2 || "Halfway There",
                description:
                  L?.motivation_description_2 ||
                  "You've answered 40 questions. Take your time with the rest.",
              },
              60: {
                icon: (0, i.jsx)(A.IconPsychologicalArchetypesMotiv3, {
                  className: "h-full w-full md:scale-150",
                }),
                title: L?.motivation_title_3 || "Almost Done - 20 Questions Left",
                description:
                  L?.motivation_description_3 ||
                  "Your summary is almost ready. Answer the last few honestly.",
              },
            };
          case "careers":
            return {
              20: {
                icon: (0, i.jsx)(F.IconCareersMotiv1, { className: "h-full w-full md:scale-125" }),
                title: L?.motivation_title_1 || "20 Questions Down",
                description:
                  L?.motivation_description_1 ||
                  "Keep going — your honest answers are all that matters here.",
              },
              40: {
                icon: (0, i.jsx)(F.IconCareersMotiv2, { className: "h-full w-full md:scale-125" }),
                title: L?.motivation_title_2 || "Halfway There",
                description:
                  L?.motivation_description_2 ||
                  "You’ve answered 40 questions. Take your time with the rest.",
              },
              60: {
                icon: (0, i.jsx)(F.IconCareersMotiv3, { className: "h-full w-full md:scale-125" }),
                title: L?.motivation_title_3 || "Almost There! ✨",
                description:
                  L?.motivation_description_3 ||
                  "Your summary is almost ready. Answer the last few honestly.",
              },
            };
          case "imposter_syndrome":
            return {
              20: {
                icon: (0, i.jsx)(h.IconImposterSyndromeMotiv1, { className: "h-full w-full md:scale-150" }),
                title: b("imposter_syndrome_motivation_s1_title"),
                description: b("imposter_syndrome_motivation_s1_description"),
              },
              40: {
                icon: (0, i.jsx)(h.IconImposterSyndromeMotiv2, { className: "h-full w-full md:scale-150" }),
                title: b("imposter_syndrome_motivation_s2_title"),
                description: b("imposter_syndrome_motivation_s2_description"),
              },
              60: {
                icon: (0, i.jsx)(h.IconImposterSyndromeMotiv3, { className: "h-full w-full md:scale-150" }),
                title: b("imposter_syndrome_motivation_s3_title", { count: String((P || 80) - 60) }),
                description: b("imposter_syndrome_motivation_s3_description"),
              },
            };
          case "depression": {
            let e = P || 80,
              n = Math.round((20 / e) * 100);
            return {
              20: {
                icon: (0, i.jsx)(v.IconDeprMotiv1, { className: "h-full w-full md:scale-125" }),
                title:
                  L?.motivation_title_1 || b("depression_motivation_s1_title", { percentage: String(n) }),
                description: L?.motivation_description_1 || b("depression_motivation_s1_description"),
              },
              40: {
                icon: (0, i.jsx)(v.IconDeprMotiv2, { className: "h-full w-full md:scale-125" }),
                title: L?.motivation_title_2 || b("depression_motivation_s2_title"),
                description:
                  L?.motivation_description_2 ||
                  (null != D
                    ? b("depression_motivation_s2_description", { percentage: String(D) })
                    : b("depression_motivation_s2_description_fallback")),
              },
              60: {
                icon: (0, i.jsx)(v.IconDeprMotiv3, { className: "h-full w-full md:scale-125" }),
                title:
                  L?.motivation_title_3 || b("depression_motivation_s3_title", { count: String(e - 60) }),
                description: L?.motivation_description_3 || b("depression_motivation_s3_description"),
              },
            };
          }
          case "work":
            return {
              20: {
                icon: (0, i.jsx)(M.IconWorkMotiv1, { className: "h-full w-full md:scale-125" }),
                title: b("work_motivation_s1_title"),
                description: b("work_motivation_s1_description"),
              },
              40: {
                icon: (0, i.jsx)(M.IconWorkMotiv2, { className: "h-full w-full md:scale-125" }),
                title: b("work_motivation_s2_title"),
                description: b("work_motivation_s2_description"),
              },
              60: {
                icon: (0, i.jsx)(M.IconWorkMotiv3, { className: "h-full w-full md:scale-125" }),
                title: b("work_motivation_s3_title"),
                description: b("work_motivation_s3_description"),
              },
            };
          case "emotional":
            return {
              20: {
                icon: (0, i.jsx)(U.IconEmotionalMotiv1, { className: "h-full w-full md:scale-125" }),
                title: L?.motivation_title_1 || "20 Questions Down",
                description:
                  L?.motivation_description_1 ||
                  "Keep going - your honest answers are all that matters here.",
              },
              40: {
                icon: (0, i.jsx)(U.IconEmotionalMotiv2, { className: "h-full w-full md:scale-125" }),
                title: L?.motivation_title_2 || "Halfway There",
                description:
                  L?.motivation_description_2 ||
                  "You've answered 40 questions. Take your time with the rest.",
              },
              60: {
                icon: (0, i.jsx)(U.IconEmotionalMotiv3, { className: "h-full w-full md:scale-125" }),
                title: L?.motivation_title_3 || "Almost Done - 20 Questions Left",
                description:
                  L?.motivation_description_3 ||
                  "Your summary is almost ready. Answer the last few honestly.",
              },
            };
          case "burnout":
            return {
              20: {
                icon: (0, i.jsx)(u.IconBurnoutMotiv1, { className: "h-full w-full md:scale-125" }),
                title: b("burnout_motivation_s1_title"),
                description: b("burnout_motivation_s1_description"),
              },
              40: {
                icon: (0, i.jsx)(u.IconBurnoutMotiv2, { className: "h-full w-full md:scale-125" }),
                title: b("burnout_motivation_s2_title"),
                description: b("burnout_motivation_s2_description"),
              },
              60: {
                icon: (0, i.jsx)(u.IconBurnoutMotiv3, { className: "h-full w-full md:scale-125" }),
                title: b("burnout_motivation_s3_title", { count: String((P || 80) - 60) }),
                description: b("burnout_motivation_s3_description"),
              },
            };
          case "adhd":
            return {
              7: {
                icon: (0, i.jsx)(m, {
                  className:
                    "h-[180px] w-full scale-125 max-xs-sm:h-[140px] max-xs-sm:scale-100 lg:scale-150",
                }),
                title: L?.motivation_title_1 || "Focus Begins With Understanding 🧠",
                description:
                  L?.motivation_description_1 ||
                  "Every question you answer helps you better recognize how your mind naturally works — and that’s the first step to harnessing your strengths.",
              },
              14: {
                icon: (0, i.jsx)(d, { className: "h-full w-full" }),
                title: L?.motivation_title_2 || "You’re Building Insight 🌟",
                description:
                  L?.motivation_description_2 ||
                  "Taking a moment to explore your focus and energy patterns is an act of self-awareness. You’re creating the foundation for growth.",
              },
              22: {
                icon: (0, i.jsx)(c, {
                  className: "h-full w-full scale-125 max-xs-sm:scale-100 lg:scale-150",
                }),
                title: L?.motivation_title_3 || "You’re almost done 💫",
                description:
                  L?.motivation_description_3 ||
                  "You’re close to unlocking a deeper understanding of your attention, energy, and organization skills. Keep going — the insights are worth it!",
              },
            };
          case "attachment":
            return {
              20: {
                icon: (0, i.jsx)(r, {
                  className: "h-full w-full scale-125 max-xs-sm:scale-100 lg:scale-150",
                }),
                title: L?.motivation_title_1 || "20 Questions Down",
                description:
                  L?.motivation_description_1 ||
                  "Keep going - your honest answers are all that matters here.",
              },
              40: {
                icon: (0, i.jsx)(g, { className: "h-full w-full" }),
                title: L?.motivation_title_2 || "Halfway There",
                description:
                  L?.motivation_description_2 ||
                  "You've answered 40 questions. Take your time with the rest.",
              },
              60: {
                icon: (0, i.jsx)(j, {
                  className: "h-full w-full scale-125 max-xs-sm:scale-100 lg:scale-150",
                }),
                title: L?.motivation_title_3 || "Almost Done - 20 Questions Left",
                description:
                  L?.motivation_description_3 ||
                  "Your summary is almost ready. Answer the last few honestly.",
              },
            };
          case "time_management":
            return {
              20: {
                icon: (0, i.jsx)(w.IconMotivTime1, {
                  className: "h-full w-full scale-125 max-xs-sm:scale-100 lg:scale-150",
                }),
                title: L?.motivation_title_1 || "20 Questions Down",
                description:
                  L?.motivation_description_1 || "Keep going. Your honest answers are all that matters here.",
              },
              40: {
                icon: (0, i.jsx)(w.IconMotivTime2, {
                  className: "h-full w-full scale-125 max-xs-sm:scale-100 lg:scale-150",
                }),
                title: L?.motivation_title_2 || "Halfway There",
                description:
                  L?.motivation_description_2 ||
                  "You've answered 40 questions. Take your time with the rest.",
              },
              60: {
                icon: (0, i.jsx)(w.IconMotivTime3, {
                  className: "h-full w-full scale-125 max-xs-sm:scale-100 lg:scale-150",
                }),
                title: L?.motivation_title_3 || "Almost Done: 20 Questions Left",
                description:
                  L?.motivation_description_3 ||
                  "Your summary is almost ready. Answer the last few honestly.",
              },
            };
          case "political_compass":
            return {
              20: {
                icon: (0, i.jsx)(w.IconMotivTime3, { className: "h-full w-full md:scale-125" }),
                title: "You’re almost done💫",
                description:
                  "You’re just a few questions away from discovering your political orientation. Every answer matters.",
              },
              40: {
                icon: (0, i.jsx)(w.IconMotivTime3, { className: "h-full w-full md:scale-125" }),
                title: "You’re almost done💫",
                description:
                  "You’re just a few questions away from discovering your political orientation. Every answer matters.",
              },
              60: {
                icon: (0, i.jsx)(w.IconMotivTime3, { className: "h-full w-full md:scale-125" }),
                title: "You’re almost done💫",
                description:
                  "You’re just a few questions away from discovering your political orientation. Every answer matters.",
              },
            };
          default:
            return {};
        }
      };
  },
  26664,
  508149,
  (e) => {
    "use strict";
    (e.s([], 26664), e.s(["default", () => d], 508149));
    var i = e.i(843476),
      n = e.i(948148),
      s = e.i(271645);
    e.i(568267);
    var o = e.i(154692),
      t = e.i(47252),
      a = e.i(865046);
    e.i(392277);
    var m = e.i(567697);
    let d = (e) => {
      let {
          currentQuestionId: d,
          handleAnswerClick: c,
          user: l,
          variant: r,
          testData: g,
          motivationalScore: j,
          personalityVariant: u,
          quizLength: F,
        } = e,
        p = (0, n.useTranslations)(),
        v = (0, m.useCreateMotivationalContent)({
          user: l,
          variant: r,
          testData: g,
          motivationalScore: j,
          personalityVariant: u,
          quizLength: F,
          similarPct: null,
        })?.[d],
        U = "personality" === r && 3 === u;
      return (
        (0, s.useEffect)(() => {
          if (!U) return;
          let e = setTimeout(() => c(), a.V3_AUTO_ADVANCE_MS);
          return () => clearTimeout(e);
        }, [U, d]),
        (0, i.jsxs)("div", {
          className: `mx-auto flex h-full min-h-[450px] w-full max-w-[438px] flex-col pb-2 pt-7 max-xs-sm:min-h-[400px] max-xs-sm:pt-4 md:min-h-[500px] ${U ? "cursor-pointer" : ""}`,
          onClick: U ? () => c() : void 0,
          children: [
            (0, i.jsx)("div", {
              className:
                "relative mx-auto mb-8 h-[180px] w-full max-xs-sm:mb-4 max-xs-sm:h-[140px] md:mb-[60px]",
              children: v?.icon,
            }),
            (0, i.jsxs)("div", {
              className: `mb-auto ${25 === d ? "md:mb-0 md:mt-auto" : "md:my-auto"}`,
              children: [
                (0, i.jsx)("h3", {
                  className:
                    "mb-3 select-none text-pretty text-[22px] font-extrabold text-black max-xs-sm:mb-2 max-xs-sm:text-[18px] md:mb-4",
                  dangerouslySetInnerHTML: { __html: (0, t.sanitizeTranslationHtml)(v?.title) },
                }),
                (0, i.jsx)("p", {
                  className: "mb-auto select-none text-love-grey max-xs-sm:text-sm",
                  children: v?.description,
                }),
              ],
            }),
            (0, i.jsx)(o.ButtonComponent, {
              onClick: () => c(),
              className: "mt-7 whitespace-pre-wrap max-xs-sm:mt-4 md:mt-5",
              fullWidth: !0,
              size: "md",
              children: v?.buttonText || p("btn_continue"),
            }),
          ],
        })
      );
    };
  },
  865046,
  (e) => {
    "use strict";
    e.s([
      "PERSONALITY_V2_MOTIVATION_STEPS",
      0,
      [17, 33, 50, 67, 83],
      "PERSONALITY_V3_MOTIVATION_STEPS",
      0,
      [12, 25, 40, 50],
      "V3_AUTO_ADVANCE_MS",
      0,
      2500,
    ]);
  },
]);
