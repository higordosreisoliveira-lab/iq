(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  605500,
  (e, t, r) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "Image", {
        enumerable: !0,
        get: function () {
          return v;
        },
      }));
    let s = e.r(555682),
      i = e.r(190809),
      a = e.r(843476),
      n = i._(e.r(271645)),
      l = s._(e.r(174080)),
      o = s._(e.r(325633)),
      c = e.r(908927),
      d = e.r(987690),
      u = e.r(918556),
      m = e.r(65856),
      p = s._(e.r(1948)),
      f = e.r(818581),
      h = {
        deviceSizes: [640, 1080, 1920],
        imageSizes: [16, 64, 128],
        qualities: [75],
        path: "/_next/image",
        loader: "default",
        dangerouslyAllowSVG: !1,
        unoptimized: !0,
      };
    function g(e, t, r, s, i, a, n) {
      let l = e?.src;
      e &&
        e["data-loaded-src"] !== l &&
        ((e["data-loaded-src"] = l),
        ("decode" in e ? e.decode() : Promise.resolve())
          .catch(() => {})
          .then(() => {
            if (e.parentElement && e.isConnected) {
              if (("empty" !== t && i(!0), r?.current)) {
                let t = new Event("load");
                Object.defineProperty(t, "target", { writable: !1, value: e });
                let s = !1,
                  i = !1;
                r.current({
                  ...t,
                  nativeEvent: t,
                  currentTarget: e,
                  target: e,
                  isDefaultPrevented: () => s,
                  isPropagationStopped: () => i,
                  persist: () => {},
                  preventDefault: () => {
                    ((s = !0), t.preventDefault());
                  },
                  stopPropagation: () => {
                    ((i = !0), t.stopPropagation());
                  },
                });
              }
              s?.current && s.current(e);
            }
          }));
    }
    function E(e) {
      return n.use ? { fetchPriority: e } : { fetchpriority: e };
    }
    "u" < typeof window && (globalThis.__NEXT_IMAGE_IMPORTED = !0);
    let _ = "u" < typeof window ? n.useEffect : n.useLayoutEffect,
      x = (0, n.forwardRef)((e, t) => {
        let {
            src: r,
            srcSet: s,
            sizes: i,
            height: l,
            width: o,
            decoding: c,
            className: d,
            style: u,
            fetchPriority: m,
            placeholder: p,
            loading: h,
            unoptimized: x,
            fill: b,
            onLoadRef: v,
            onLoadingCompleteRef: j,
            setBlurComplete: R,
            setShowAltText: y,
            sizesInput: S,
            onLoad: A,
            onError: N,
            ...w
          } = e,
          I = (0, n.useRef)(!1),
          T = (0, n.useRef)(null);
        _(() => {
          let { current: e } = I,
            { current: t } = T;
          e || null === t || (N && (t.src = t.src), t.complete && g(t, p, v, j, R, x, S), (I.current = !0));
        }, [r, p, v, j, N, x, S]);
        let O = (0, f.useMergedRef)(t, T);
        return (0, a.jsx)("img", {
          ...w,
          ...E(m),
          loading: h,
          width: o,
          height: l,
          decoding: c,
          "data-nimg": b ? "fill" : "1",
          className: d,
          style: u,
          sizes: i,
          srcSet: s,
          src: r,
          ref: O,
          onLoad: (e) => {
            g(e.currentTarget, p, v, j, R, x, S);
          },
          onError: (e) => {
            (y(!0), "empty" !== p && R(!0), N && N(e));
          },
        });
      });
    function b(e) {
      let { isAppRouter: t, imgAttributes: r } = e,
        s = {
          as: "image",
          imageSrcSet: r.srcSet,
          imageSizes: r.sizes,
          crossOrigin: r.crossOrigin,
          referrerPolicy: r.referrerPolicy,
          ...E(r.fetchPriority),
        };
      return t && l.default.preload
        ? (l.default.preload(r.src, s), null)
        : (0, a.jsx)(o.default, {
            children: (0, a.jsx)(
              "link",
              { rel: "preload", href: r.srcSet ? void 0 : r.src, ...s },
              "__nimg-" + r.src + r.srcSet + r.sizes,
            ),
          });
    }
    let v = (0, n.forwardRef)((e, t) => {
      let r = (0, n.useContext)(m.RouterContext),
        s = (0, n.useContext)(u.ImageConfigContext),
        i = (0, n.useMemo)(() => {
          let e = h || s || d.imageConfigDefault,
            t = [...e.deviceSizes, ...e.imageSizes].sort((e, t) => e - t),
            r = e.deviceSizes.sort((e, t) => e - t),
            i = e.qualities?.sort((e, t) => e - t);
          return {
            ...e,
            allSizes: t,
            deviceSizes: r,
            qualities: i,
            localPatterns: "u" < typeof window ? s?.localPatterns : e.localPatterns,
          };
        }, [s]),
        { onLoad: l, onLoadingComplete: o } = e,
        f = (0, n.useRef)(l);
      (0, n.useEffect)(() => {
        f.current = l;
      }, [l]);
      let g = (0, n.useRef)(o);
      (0, n.useEffect)(() => {
        g.current = o;
      }, [o]);
      let [E, _] = (0, n.useState)(!1),
        [v, j] = (0, n.useState)(!1),
        { props: R, meta: y } = (0, c.getImgProps)(e, {
          defaultLoader: p.default,
          imgConf: i,
          blurComplete: E,
          showAltText: v,
        });
      return (0, a.jsxs)(a.Fragment, {
        children: [
          (0, a.jsx)(x, {
            ...R,
            unoptimized: y.unoptimized,
            placeholder: y.placeholder,
            fill: y.fill,
            onLoadRef: f,
            onLoadingCompleteRef: g,
            setBlurComplete: _,
            setShowAltText: j,
            sizesInput: e.sizes,
            ref: t,
          }),
          y.preload ? (0, a.jsx)(b, { isAppRouter: !r, imgAttributes: R }) : null,
        ],
      });
    });
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  670965,
  (e, t, r) => {
    "use strict";
    function s(e, t) {
      let r = e || 75;
      return t?.qualities?.length
        ? t.qualities.reduce((e, t) => (Math.abs(t - r) < Math.abs(e - r) ? t : e), t.qualities[0])
        : r;
    }
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "findClosestQuality", {
        enumerable: !0,
        get: function () {
          return s;
        },
      }));
  },
  908927,
  (e, t, r) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "getImgProps", {
        enumerable: !0,
        get: function () {
          return c;
        },
      }));
    let s = e.r(543369),
      i = e.r(488143),
      a = e.r(987690),
      n = ["-moz-initial", "fill", "none", "scale-down", void 0];
    function l(e) {
      return void 0 !== e.default;
    }
    function o(e) {
      return void 0 === e
        ? e
        : "number" == typeof e
          ? Number.isFinite(e)
            ? e
            : NaN
          : "string" == typeof e && /^[0-9]+$/.test(e)
            ? parseInt(e, 10)
            : NaN;
    }
    function c(e, t) {
      var r;
      let c,
        d,
        u,
        {
          src: m,
          sizes: p,
          unoptimized: f = !1,
          priority: h = !1,
          preload: g = !1,
          loading: E,
          className: _,
          quality: x,
          width: b,
          height: v,
          fill: j = !1,
          style: R,
          overrideSrc: y,
          onLoad: S,
          onLoadingComplete: A,
          placeholder: N = "empty",
          blurDataURL: w,
          fetchPriority: I,
          decoding: T = "async",
          layout: O,
          objectFit: L,
          objectPosition: C,
          lazyBoundary: D,
          lazyRoot: P,
          ...k
        } = e,
        { imgConf: M, showAltText: U, blurComplete: W, defaultLoader: H } = t,
        V = M || a.imageConfigDefault;
      if ("allSizes" in V) c = V;
      else {
        let e = [...V.deviceSizes, ...V.imageSizes].sort((e, t) => e - t),
          t = V.deviceSizes.sort((e, t) => e - t),
          r = V.qualities?.sort((e, t) => e - t);
        c = { ...V, allSizes: e, deviceSizes: t, qualities: r };
      }
      if (void 0 === H)
        throw Object.defineProperty(
          Error(
            "images.loaderFile detected but the file is missing default export.\nRead more: https://nextjs.org/docs/messages/invalid-images-config",
          ),
          "__NEXT_ERROR_CODE",
          { value: "E163", enumerable: !1, configurable: !0 },
        );
      let z = k.loader || H;
      (delete k.loader, delete k.srcSet);
      let F = "__next_img_default" in z;
      if (F) {
        if ("custom" === c.loader)
          throw Object.defineProperty(
            Error(`Image with src "${m}" is missing "loader" prop.
Read more: https://nextjs.org/docs/messages/next-image-missing-loader`),
            "__NEXT_ERROR_CODE",
            { value: "E252", enumerable: !1, configurable: !0 },
          );
      } else {
        let e = z;
        z = (t) => {
          let { config: r, ...s } = t;
          return e(s);
        };
      }
      if (O) {
        "fill" === O && (j = !0);
        let e = {
          intrinsic: { maxWidth: "100%", height: "auto" },
          responsive: { width: "100%", height: "auto" },
        }[O];
        e && (R = { ...R, ...e });
        let t = { responsive: "100vw", fill: "100vw" }[O];
        t && !p && (p = t);
      }
      let B = "",
        $ = o(b),
        G = o(v);
      if ((r = m) && "object" == typeof r && (l(r) || void 0 !== r.src)) {
        let e = l(m) ? m.default : m;
        if (!e.src)
          throw Object.defineProperty(
            Error(
              `An object should only be passed to the image component src parameter if it comes from a static image import. It must include src. Received ${JSON.stringify(e)}`,
            ),
            "__NEXT_ERROR_CODE",
            { value: "E460", enumerable: !1, configurable: !0 },
          );
        if (!e.height || !e.width)
          throw Object.defineProperty(
            Error(
              `An object should only be passed to the image component src parameter if it comes from a static image import. It must include height and width. Received ${JSON.stringify(e)}`,
            ),
            "__NEXT_ERROR_CODE",
            { value: "E48", enumerable: !1, configurable: !0 },
          );
        if (((d = e.blurWidth), (u = e.blurHeight), (w = w || e.blurDataURL), (B = e.src), !j))
          if ($ || G) {
            if ($ && !G) {
              let t = $ / e.width;
              G = Math.round(e.height * t);
            } else if (!$ && G) {
              let t = G / e.height;
              $ = Math.round(e.width * t);
            }
          } else (($ = e.width), (G = e.height));
      }
      let K = !h && !g && ("lazy" === E || void 0 === E);
      ((!(m = "string" == typeof m ? m : B) || m.startsWith("data:") || m.startsWith("blob:")) &&
        ((f = !0), (K = !1)),
        c.unoptimized && (f = !0),
        F && !c.dangerouslyAllowSVG && m.split("?", 1)[0].endsWith(".svg") && (f = !0));
      let q = o(x),
        X = Object.assign(
          j
            ? {
                position: "absolute",
                height: "100%",
                width: "100%",
                left: 0,
                top: 0,
                right: 0,
                bottom: 0,
                objectFit: L,
                objectPosition: C,
              }
            : {},
          U ? {} : { color: "transparent" },
          R,
        ),
        Q =
          W || "empty" === N
            ? null
            : "blur" === N
              ? `url("data:image/svg+xml;charset=utf-8,${(0, i.getImageBlurSvg)({ widthInt: $, heightInt: G, blurWidth: d, blurHeight: u, blurDataURL: w || "", objectFit: X.objectFit })}")`
              : `url("${N}")`,
        Y = n.includes(X.objectFit) ? ("fill" === X.objectFit ? "100% 100%" : "cover") : X.objectFit,
        Z = Q
          ? {
              backgroundSize: Y,
              backgroundPosition: X.objectPosition || "50% 50%",
              backgroundRepeat: "no-repeat",
              backgroundImage: Q,
            }
          : {},
        J = (function (e) {
          let { config: t, src: r, unoptimized: i, width: a, quality: n, sizes: l, loader: o } = e;
          if (i) {
            if (r.startsWith("/") && !r.startsWith("//")) {
              let e = (0, s.getDeploymentId)();
              if (r.includes("/_next/static/immutable") && !(0, s.getAssetToken)()) e = void 0;
              else if (e) {
                let t = r.indexOf("?");
                if (-1 !== t) {
                  let s = new URLSearchParams(r.slice(t + 1));
                  s.get("dpl") || (s.append("dpl", e), (r = r.slice(0, t) + "?" + s.toString()));
                } else r += `?dpl=${e}`;
              }
            }
            return { src: r, srcSet: void 0, sizes: void 0 };
          }
          let { widths: c, kind: d } = (function (e, t, r) {
              let { deviceSizes: s, allSizes: i } = e;
              if (r) {
                let e = /(^|\s)(1?\d?\d)vw/g,
                  t = [];
                for (let s; (s = e.exec(r));) t.push(parseInt(s[2]));
                if (t.length) {
                  let e = 0.01 * Math.min(...t);
                  return { widths: i.filter((t) => t >= s[0] * e), kind: "w" };
                }
                return { widths: i, kind: "w" };
              }
              return "number" != typeof t
                ? { widths: s, kind: "w" }
                : {
                    widths: [...new Set([t, 2 * t].map((e) => i.find((t) => t >= e) || i[i.length - 1]))],
                    kind: "x",
                  };
            })(t, a, l),
            u = c.length - 1;
          return {
            sizes: l || "w" !== d ? l : "100vw",
            srcSet: c
              .map((e, s) => `${o({ config: t, src: r, quality: n, width: e })} ${"w" === d ? e : s + 1}${d}`)
              .join(", "),
            src: o({ config: t, src: r, quality: n, width: c[u] }),
          };
        })({ config: c, src: m, unoptimized: f, width: $, quality: q, sizes: p, loader: z }),
        ee = K ? "lazy" : E;
      return {
        props: {
          ...k,
          loading: ee,
          fetchPriority: I,
          width: $,
          height: G,
          decoding: T,
          className: _,
          style: { ...X, ...Z },
          sizes: J.sizes,
          srcSet: J.srcSet,
          src: y || J.src,
        },
        meta: { unoptimized: f, preload: g || h, placeholder: N, fill: j },
      };
    }
  },
  325633,
  (e, t, r) => {
    "use strict";
    (e.i(247167), Object.defineProperty(r, "__esModule", { value: !0 }));
    var s = {
      default: function () {
        return h;
      },
      defaultHead: function () {
        return u;
      },
    };
    for (var i in s) Object.defineProperty(r, i, { enumerable: !0, get: s[i] });
    let a = e.r(555682),
      n = e.r(190809),
      l = e.r(843476),
      o = n._(e.r(271645)),
      c = a._(e.r(898879)),
      d = e.r(742732);
    function u() {
      return [
        (0, l.jsx)("meta", { charSet: "utf-8" }, "charset"),
        (0, l.jsx)("meta", { name: "viewport", content: "width=device-width" }, "viewport"),
      ];
    }
    function m(e, t) {
      return "string" == typeof t || "number" == typeof t
        ? e
        : t.type === o.default.Fragment
          ? e.concat(
              o.default.Children.toArray(t.props.children).reduce(
                (e, t) => ("string" == typeof t || "number" == typeof t ? e : e.concat(t)),
                [],
              ),
            )
          : e.concat(t);
    }
    let p = ["name", "httpEquiv", "charSet", "itemProp"];
    function f(e) {
      let t, r, s, i;
      return e
        .reduce(m, [])
        .reverse()
        .concat(u().reverse())
        .filter(
          ((t = new Set()),
          (r = new Set()),
          (s = new Set()),
          (i = {}),
          (e) => {
            let a = !0,
              n = !1;
            if (e.key && "number" != typeof e.key && e.key.indexOf("$") > 0) {
              n = !0;
              let r = e.key.slice(e.key.indexOf("$") + 1);
              t.has(r) ? (a = !1) : t.add(r);
            }
            switch (e.type) {
              case "title":
              case "base":
                r.has(e.type) ? (a = !1) : r.add(e.type);
                break;
              case "meta":
                for (let t = 0, r = p.length; t < r; t++) {
                  let r = p[t];
                  if (e.props.hasOwnProperty(r))
                    if ("charSet" === r) s.has(r) ? (a = !1) : s.add(r);
                    else {
                      let t = e.props[r],
                        s = i[r] || new Set();
                      ("name" !== r || !n) && s.has(t) ? (a = !1) : (s.add(t), (i[r] = s));
                    }
                }
            }
            return a;
          }),
        )
        .reverse()
        .map((e, t) => {
          let r = e.key || t;
          return o.default.cloneElement(e, { key: r });
        });
    }
    let h = function (e) {
      let { children: t } = e,
        r = (0, o.useContext)(d.HeadManagerContext);
      return (0, l.jsx)(c.default, { reduceComponentsToState: f, headManager: r, children: t });
    };
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  488143,
  (e, t, r) => {
    "use strict";
    function s(e) {
      let { widthInt: t, heightInt: r, blurWidth: s, blurHeight: i, blurDataURL: a, objectFit: n } = e,
        l = s ? 40 * s : t,
        o = i ? 40 * i : r,
        c = l && o ? `viewBox='0 0 ${l} ${o}'` : "";
      return `%3Csvg xmlns='http://www.w3.org/2000/svg' ${c}%3E%3Cfilter id='b' color-interpolation-filters='sRGB'%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3CfeColorMatrix values='1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 100 -1' result='s'/%3E%3CfeFlood x='0' y='0' width='100%25' height='100%25'/%3E%3CfeComposite operator='out' in='s'/%3E%3CfeComposite in2='SourceGraphic'/%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3C/filter%3E%3Cimage width='100%25' height='100%25' x='0' y='0' preserveAspectRatio='${c ? "none" : "contain" === n ? "xMidYMid" : "cover" === n ? "xMidYMid slice" : "none"}' style='filter: url(%23b);' href='${a}'/%3E%3C/svg%3E`;
    }
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "getImageBlurSvg", {
        enumerable: !0,
        get: function () {
          return s;
        },
      }));
  },
  918556,
  (e, t, r) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "ImageConfigContext", {
        enumerable: !0,
        get: function () {
          return a;
        },
      }));
    let s = e.r(555682)._(e.r(271645)),
      i = e.r(987690),
      a = s.default.createContext(i.imageConfigDefault);
  },
  987690,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var s = {
      VALID_LOADERS: function () {
        return a;
      },
      imageConfigDefault: function () {
        return n;
      },
    };
    for (var i in s) Object.defineProperty(r, i, { enumerable: !0, get: s[i] });
    let a = ["default", "imgix", "cloudinary", "akamai", "custom"],
      n = {
        deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
        imageSizes: [32, 48, 64, 96, 128, 256, 384],
        path: "/_next/image",
        loader: "default",
        loaderFile: "",
        domains: [],
        disableStaticImages: !1,
        minimumCacheTTL: 14400,
        formats: ["image/webp"],
        maximumDiskCacheSize: void 0,
        maximumRedirects: 3,
        maximumResponseBody: 5e7,
        dangerouslyAllowLocalIP: !1,
        dangerouslyAllowSVG: !1,
        contentSecurityPolicy: "script-src 'none'; frame-src 'none'; sandbox;",
        contentDispositionType: "attachment",
        localPatterns: void 0,
        remotePatterns: [],
        qualities: [75],
        unoptimized: !1,
        customCacheHandler: !1,
      };
  },
  794909,
  (e, t, r) => {
    "use strict";
    (e.i(247167), Object.defineProperty(r, "__esModule", { value: !0 }));
    var s = {
      default: function () {
        return d;
      },
      getImageProps: function () {
        return c;
      },
    };
    for (var i in s) Object.defineProperty(r, i, { enumerable: !0, get: s[i] });
    let a = e.r(555682),
      n = e.r(908927),
      l = e.r(605500),
      o = a._(e.r(1948));
    function c(e) {
      let { props: t } = (0, n.getImgProps)(e, {
        defaultLoader: o.default,
        imgConf: {
          deviceSizes: [640, 1080, 1920],
          imageSizes: [16, 64, 128],
          qualities: [75],
          path: "/_next/image",
          loader: "default",
          dangerouslyAllowSVG: !1,
          unoptimized: !0,
        },
      });
      for (let [e, r] of Object.entries(t)) void 0 === r && delete t[e];
      return { props: t };
    }
    let d = l.Image;
  },
  657688,
  (e, t, r) => {
    t.exports = e.r(794909);
  },
  1948,
  (e, t, r) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function () {
          return n;
        },
      }));
    let s = e.r(670965),
      i = e.r(543369);
    function a(e) {
      let { config: t, src: r, width: a, quality: n } = e,
        l = (0, i.getDeploymentId)();
      if (r.startsWith("/") && !r.startsWith("//"))
        if (r.includes("/_next/static/immutable") && !(0, i.getAssetToken)()) l = void 0;
        else {
          let e = r.indexOf("?");
          if (-1 !== e) {
            let t = new URLSearchParams(r.slice(e + 1)),
              s = t.get("dpl");
            if (s) {
              ((l = s), t.delete("dpl"));
              let i = t.toString();
              r = r.slice(0, e) + (i ? "?" + i : "");
            }
          }
        }
      if (
        r.startsWith("/") &&
        r.includes("?") &&
        t.localPatterns?.length === 1 &&
        "**" === t.localPatterns[0].pathname &&
        "" === t.localPatterns[0].search
      )
        throw Object.defineProperty(
          Error(`Image with src "${r}" is using a query string which is not configured in images.localPatterns.
Read more: https://nextjs.org/docs/messages/next-image-unconfigured-localpatterns`),
          "__NEXT_ERROR_CODE",
          { value: "E871", enumerable: !1, configurable: !0 },
        );
      let o = (0, s.findClosestQuality)(n, t);
      return `${t.path}?url=${encodeURIComponent(r)}&w=${a}&q=${o}${r.startsWith("/") && l ? `&dpl=${l}` : ""}`;
    }
    a.__next_img_default = !0;
    let n = a;
  },
  65856,
  (e, t, r) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "RouterContext", {
        enumerable: !0,
        get: function () {
          return s;
        },
      }));
    let s = e.r(555682)._(e.r(271645)).default.createContext(null);
  },
  898879,
  (e, t, r) => {
    "use strict";
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function () {
          return l;
        },
      }));
    let s = e.r(271645),
      i = "u" < typeof window,
      a = i ? () => {} : s.useLayoutEffect,
      n = i ? () => {} : s.useEffect;
    function l(e) {
      let { headManager: t, reduceComponentsToState: r } = e;
      function l() {
        if (t && t.mountedInstances) {
          let e = s.Children.toArray(Array.from(t.mountedInstances).filter(Boolean));
          t.updateHead(r(e));
        }
      }
      return (
        i && (t?.mountedInstances?.add(e.children), l()),
        a(
          () => (
            t?.mountedInstances?.add(e.children),
            () => {
              t?.mountedInstances?.delete(e.children);
            }
          ),
        ),
        a(
          () => (
            t && (t._pendingUpdate = l),
            () => {
              t && (t._pendingUpdate = l);
            }
          ),
        ),
        n(
          () => (
            t && t._pendingUpdate && (t._pendingUpdate(), (t._pendingUpdate = null)),
            () => {
              t && t._pendingUpdate && (t._pendingUpdate(), (t._pendingUpdate = null));
            }
          ),
        ),
        null
      );
    }
  },
  771699,
  68641,
  381907,
  635099,
  901287,
  571365,
  (e) => {
    "use strict";
    var t = e.i(843476);
    e.i(310443);
    var r = e.i(340557),
      s = e.i(204128),
      i = e.i(139989),
      a = e.i(695106),
      n = e.i(245847),
      l = e.i(400657);
    let o =
        "sticky bottom-0 z-10 -mb-6 flex w-full flex-col items-center bg-white pb-[calc(1rem+env(safe-area-inset-bottom))] pt-2 md:static md:mb-0 md:bg-transparent md:pb-0 md:pt-0",
      c =
        "pointer-events-none absolute inset-x-0 bottom-full h-6 bg-gradient-to-t from-white to-transparent md:hidden";
    e.s(["FUNNEL_CTA_STICKY", 0, o, "FUNNEL_CTA_STICKY_FADE", 0, c], 68641);
    let d = "mx-auto flex w-full max-w-lg flex-col gap-5 md:gap-6 lg:max-w-[64rem]",
      u =
        "flex w-full flex-col items-center gap-5 md:gap-6 lg:grid lg:grid-cols-[1fr_1.1fr] lg:items-center lg:gap-12",
      m = "flex w-full flex-col items-center gap-5 md:gap-6 lg:items-start",
      p = "hidden lg:flex lg:items-stretch",
      f = "flex flex-col gap-0.5 text-start",
      h = "mx-6 w-px bg-slate-200",
      g = "text-hp-h3 tabular-nums text-black-custom",
      E = "text-hp-caption text-grey-deep",
      _ = "text-balance text-center text-hp-h2 text-black-custom lg:text-start lg:text-hp-h2-lg",
      x = "flex items-center justify-center gap-1",
      b = "size-4 text-amber-400",
      v = "flex w-full flex-col gap-3 rounded-2xl bg-light-blue p-5 text-center md:p-6",
      j = "text-pretty text-hp-h4 text-black-custom",
      R = "mx-auto max-w-[56ch] text-pretty text-hp-body-sm text-grey-deep",
      y = "text-hp-caption text-grey-light",
      S = "text-black-custom",
      A = "flex flex-col items-center gap-4 lg:hidden",
      N = "w-16 border-t border-slate-200",
      w = "text-center text-hp-body-sm tabular-nums text-grey-deep",
      I = "font-semibold text-black-custom",
      T = "ab_myiq_quiz_redesign_reviews_tests_taken_caption",
      O = " · ",
      L = "80M+",
      C = "ab_myiq_quiz_redesign_reviews_trust_caption",
      D = "ab_myiq_home_redesign_press_label",
      P = "text-center text-hp-eyebrow uppercase text-grey-light",
      k =
        "mt-3 flex flex-col items-center gap-3 md:mt-4 lg:w-[64rem] lg:max-w-[calc(100vw-4rem)] lg:self-center",
      M = "flex flex-wrap items-center justify-center gap-x-6 gap-y-4 grayscale opacity-70 lg:hidden",
      U = "hidden w-full text-grey-light grayscale opacity-70 lg:block [&_svg]:h-5 [&_svg]:w-auto",
      W = "h-4 w-auto md:h-5",
      H = [
        { key: "business-insider", node: (0, t.jsx)(r.IconLogoBusinessWire, { className: W }) },
        { key: "digital-trends", node: (0, t.jsx)(s.IconLogoDigitalTrends, { className: W }) },
        { key: "msn", node: (0, t.jsx)(i.IconLogoNewMsn, { className: W }) },
        { key: "newsweek", node: (0, t.jsx)(a.IconLogoNewsweek, { className: W }) },
        { key: "usa-today", node: (0, t.jsx)(n.IconLogoUSAToday, { className: W }) },
        { key: "yahoo-finance", node: (0, t.jsx)(l.IconLogoYahooFinance, { className: W }) },
      ],
      V = [...H, ...H.map((e) => ({ ...e, key: `${e.key}-2` }))],
      z = `${o} mt-3 md:mt-4`,
      F = "w-full md:w-auto md:min-w-[16rem]";
    e.s(
      [
        "REVIEWS_AUTHOR",
        0,
        y,
        "REVIEWS_AUTHOR_NAME",
        0,
        S,
        "REVIEWS_BODY",
        0,
        R,
        "REVIEWS_COLUMN",
        0,
        d,
        "REVIEWS_CTA",
        0,
        F,
        "REVIEWS_CTA_FADE",
        0,
        c,
        "REVIEWS_CTA_WRAP",
        0,
        z,
        "REVIEWS_DESK_STAT",
        0,
        f,
        "REVIEWS_DESK_STATS",
        0,
        p,
        "REVIEWS_DESK_STAT_CAPTION",
        0,
        E,
        "REVIEWS_DESK_STAT_NUM",
        0,
        g,
        "REVIEWS_DESK_STAT_RULE",
        0,
        h,
        "REVIEWS_FEATURED_LABEL",
        0,
        P,
        "REVIEWS_FEATURED_LABEL_TEXT",
        0,
        D,
        "REVIEWS_HEADLINE",
        0,
        j,
        "REVIEWS_HERO",
        0,
        u,
        "REVIEWS_HERO_LEFT",
        0,
        m,
        "REVIEWS_MARQUEE_LOGOS",
        0,
        V,
        "REVIEWS_PRESS_BLOCK",
        0,
        k,
        "REVIEWS_PRESS_LOGOS",
        0,
        H,
        "REVIEWS_PRESS_MARQUEE",
        0,
        U,
        "REVIEWS_PRESS_ROW",
        0,
        M,
        "REVIEWS_QUOTE_BLOCK",
        0,
        v,
        "REVIEWS_RULE",
        0,
        N,
        "REVIEWS_STAR",
        0,
        b,
        "REVIEWS_STARS",
        0,
        x,
        "REVIEWS_STAR_COUNT",
        0,
        5,
        "REVIEWS_STATS_GROUP",
        0,
        A,
        "REVIEWS_STATS_LINE",
        0,
        w,
        "REVIEWS_STAT_SEPARATOR",
        0,
        O,
        "REVIEWS_STAT_STRONG",
        0,
        I,
        "REVIEWS_STAT_TESTS_TEXT",
        0,
        T,
        "REVIEWS_STAT_TRUST_FIGURE",
        0,
        L,
        "REVIEWS_STAT_TRUST_TEXT",
        0,
        C,
        "REVIEWS_TITLE",
        0,
        _,
      ],
      381907,
    );
    var B = e.i(948148),
      $ = e.i(271645);
    e.i(791371);
    var G = e.i(642448),
      K = e.i(524579);
    e.s([], 635099);
    var q = K;
    e.s(["DemoMarquee", () => q.default], 901287);
    var q = K;
    e.i(900206);
    var X = e.i(669509);
    e.i(922342);
    var Q = e.i(162278);
    let Y = Array.from({ length: 5 }, (e, t) => t);
    (e.s(
      [
        "default",
        0,
        (e) => {
          let { screen: r, onContinue: s } = e,
            i = (0, B.useTranslations)(),
            [a, n] = (0, $.useState)(!1);
          return (0, t.jsxs)("div", {
            className: d,
            children: [
              (0, t.jsxs)("div", {
                className: u,
                children: [
                  (0, t.jsxs)("div", {
                    className: m,
                    children: [
                      (0, t.jsx)("h1", {
                        className: _,
                        children: (0, t.jsx)(Q.FunnelTokensComponent, { tokens: r.titleTokens }),
                      }),
                      (0, t.jsx)("div", {
                        "aria-hidden": !0,
                        className: x,
                        children: Y.map((e) => (0, t.jsx)(X.IconStar, { className: b }, e)),
                      }),
                      (0, t.jsxs)("div", {
                        className: p,
                        children: [
                          (0, t.jsxs)("div", {
                            className: f,
                            children: [
                              (0, t.jsx)("span", { className: g, children: (7869).toLocaleString("en-US") }),
                              (0, t.jsx)("span", { className: E, children: i(T) }),
                            ],
                          }),
                          (0, t.jsx)("span", { "aria-hidden": !0, className: h }),
                          (0, t.jsxs)("div", {
                            className: f,
                            children: [
                              (0, t.jsx)("span", { className: g, children: L }),
                              (0, t.jsx)("span", { className: E, children: i(C) }),
                            ],
                          }),
                        ],
                      }),
                    ],
                  }),
                  (0, t.jsxs)("article", {
                    className: v,
                    children: [
                      (0, t.jsxs)("h2", { className: j, children: ["“", r.reviewHeadline, "”"] }),
                      (0, t.jsx)("p", { className: R, children: r.reviewBody }),
                      (0, t.jsxs)("p", {
                        className: y,
                        children: [
                          (0, t.jsx)("span", { className: S, children: r.reviewAuthor }),
                          " ",
                          r.reviewAuthorSeparator,
                          " ",
                          r.reviewAuthorRole,
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              (0, t.jsxs)("div", {
                className: A,
                children: [
                  (0, t.jsx)("span", { "aria-hidden": !0, className: N }),
                  (0, t.jsxs)("p", {
                    className: w,
                    children: [
                      (0, t.jsx)("span", { className: I, children: (7869).toLocaleString("en-US") }),
                      " ",
                      i(T),
                      O,
                      (0, t.jsx)("span", { className: I, children: L }),
                      " ",
                      i(C),
                    ],
                  }),
                ],
              }),
              (0, t.jsxs)("div", {
                className: k,
                children: [
                  (0, t.jsx)("p", { className: P, children: i(D) }),
                  (0, t.jsx)("div", {
                    "aria-hidden": !0,
                    className: M,
                    children: H.map((e) => (0, t.jsx)("span", { children: e.node }, e.key)),
                  }),
                  (0, t.jsx)(q.default, { items: V, className: U }),
                ],
              }),
              (0, t.jsxs)("div", {
                className: z,
                children: [
                  (0, t.jsx)("span", { "aria-hidden": !0, className: c }),
                  (0, t.jsx)(G.DemoButton, {
                    size: "lg",
                    variant: "primary",
                    className: F,
                    isLoading: a,
                    onClick: () => {
                      a || (n(!0), s());
                    },
                    children: r.cta,
                  }),
                ],
              }),
            ],
          });
        },
      ],
      571365,
    ),
      e.s([], 771699));
  },
  661852,
  (e) => {
    "use strict";
    e.s([
      "ANALYZING_COMPLETE_ANNOUNCEMENT",
      0,
      "Analysis complete.",
      "FUNNEL_BRAND_LABEL",
      0,
      "myIQ — back to home",
      "FUNNEL_CLOCK_LABEL",
      0,
      "Elapsed time",
      "FUNNEL_PROGRESS_LABEL",
      0,
      "Test progress",
      "MEASURE_STATE_TEXT",
      0,
      { pending: " — waiting", active: " — in progress", done: " — scored" },
      "QUIZ_FIGURE_ALT",
      0,
      "",
      "QUIZ_SEQUENCE_LABEL",
      0,
      "Number sequence to memorize",
      "formatMeasureAnnouncement",
      0,
      (e) => `${e} scored.`,
      "formatOptionLabel",
      0,
      (e) => `Option ${e}`,
      "formatProgressValueText",
      0,
      (e, t) => `Question ${e} of ${t}`,
      "formatQuestionAnnouncement",
      0,
      (e) => `${e}.`,
      "splitCountdownTemplate",
      0,
      (e) => {
        let [t = "", r = ""] = e.split("{seconds}");
        return { before: t, after: r };
      },
    ]);
  },
  406953,
  413769,
  (e) => {
    "use strict";
    (e.s(
      [
        "HEADER_BRAND",
        0,
        "flex items-center gap-2 rounded-lg focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom",
        "HEADER_CLOCK_CHIP",
        0,
        "inline-flex h-6 shrink-0 items-center gap-1 rounded-full border border-slate-200 bg-light-blue px-2.5 text-hp-caption tabular-nums text-grey-deep",
        "HEADER_COUNTER",
        0,
        "text-hp-caption tabular-nums text-grey-light",
        "HEADER_COUNTER_VALUE",
        0,
        "text-grey-deep",
        "HEADER_DIVIDER",
        0,
        "h-4 w-px shrink-0 bg-slate-100",
        "HEADER_EMAIL_AVATAR",
        0,
        "flex size-6 shrink-0 items-center justify-center rounded-full bg-slate-100 text-[0.625rem]/[1] font-semibold uppercase text-grey-deep",
        "HEADER_EMAIL_CHIP",
        0,
        "inline-flex h-8 min-w-0 shrink items-center gap-2 rounded-full border border-slate-200 bg-white pl-1 pr-3 text-hp-caption text-grey-deep",
        "HEADER_EMAIL_TEXT",
        0,
        "max-w-[9rem] truncate md:max-w-[16rem]",
        "HEADER_LOGO_VIEW_BOX",
        0,
        "0 0 108 31",
        "HEADER_RAIL_FILL",
        0,
        "block h-0.5 w-full origin-left bg-blue-highlight transition-transform duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] motion-reduce:transition-none",
        "HEADER_RAIL_TRACK",
        0,
        "absolute inset-x-0 bottom-0 h-0.5 bg-blue-custom",
        "HEADER_SHELL",
        0,
        "sticky top-0 z-50 w-full shrink-0 border-b bg-white transition-colors duration-150",
        "HEADER_SHELL_STATIC",
        0,
        "w-full shrink-0 border-b border-transparent bg-white",
      ],
      406953,
    ),
      e.s(["QUIZ_FLOW_TOTAL_COUNTED", 0, 40], 413769));
  },
  361313,
  140830,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(948148),
      s = e.i(256889);
    e.i(872756);
    var i = e.i(987132);
    e.i(379551);
    var a = e.i(90614);
    e.i(83029);
    var n = e.i(40959),
      l = e.i(406953),
      o = e.i(413769),
      c = e.i(20362),
      d = e.i(661852);
    e.i(900206);
    var u = e.i(669509);
    (e.s([], 361313),
      e.s(
        [
          "FunnelHeaderComponent",
          0,
          (e) => {
            let {
                isCounterVisible: m,
                counterCurrent: p,
                counterTotal: f = o.QUIZ_FLOW_TOTAL_COUNTED,
                railCurrent: h,
                railTotal: g = o.QUIZ_FLOW_TOTAL_COUNTED,
                isTimerVisible: E,
                clock: _,
                isClockLive: x,
                isRailVisible: b = !0,
                email: v = null,
                isSticky: j = !0,
                brandHref: R = c.ROUTE_HOME,
              } = e,
              y = (0, r.useTranslations)(),
              S = (0, a.useHeaderScroll)(),
              A = Math.min(100, Math.max(0, (h / g) * 100)),
              N = j && S && !b;
            return (0, t.jsxs)("header", {
              className: (0, s.cn)(
                j ? l.HEADER_SHELL : l.HEADER_SHELL_STATIC,
                j && (N ? "border-slate-200" : "border-transparent"),
              ),
              children: [
                (0, t.jsx)(i.DemoContainer, {
                  children: (0, t.jsxs)("div", {
                    className: "flex h-16 items-center justify-between gap-4",
                    children: [
                      null === R
                        ? (0, t.jsxs)("span", {
                            className: l.HEADER_BRAND,
                            children: [
                              (0, t.jsx)(n.IconLogoDark, {
                                "aria-hidden": !0,
                                viewBox: l.HEADER_LOGO_VIEW_BOX,
                                className: "h-7 w-auto",
                              }),
                              (0, t.jsx)("span", { className: "sr-only", children: d.FUNNEL_BRAND_LABEL }),
                            ],
                          })
                        : (0, t.jsxs)("a", {
                            href: R,
                            className: l.HEADER_BRAND,
                            children: [
                              (0, t.jsx)(n.IconLogoDark, {
                                "aria-hidden": !0,
                                viewBox: l.HEADER_LOGO_VIEW_BOX,
                                className: "h-7 w-auto",
                              }),
                              (0, t.jsx)("span", { className: "sr-only", children: d.FUNNEL_BRAND_LABEL }),
                            ],
                          }),
                      (0, t.jsxs)("div", {
                        className: "flex min-w-0 shrink items-center gap-3",
                        children: [
                          null !== v &&
                            (0, t.jsxs)("span", {
                              "data-email": !0,
                              className: l.HEADER_EMAIL_CHIP,
                              children: [
                                (0, t.jsx)("span", {
                                  "aria-hidden": !0,
                                  className: l.HEADER_EMAIL_AVATAR,
                                  children: v.slice(0, 2),
                                }),
                                (0, t.jsx)("span", { className: l.HEADER_EMAIL_TEXT, children: v }),
                              ],
                            }),
                          m &&
                            (0, t.jsxs)("p", {
                              "data-counter": !0,
                              className: l.HEADER_COUNTER,
                              children: [
                                (0, t.jsx)("span", { className: l.HEADER_COUNTER_VALUE, children: p }),
                                ` ${y("text_of")} `,
                                f,
                              ],
                            }),
                          m && E && (0, t.jsx)("span", { "aria-hidden": !0, className: l.HEADER_DIVIDER }),
                          E &&
                            (0, t.jsxs)("span", {
                              "data-timer": !0,
                              "aria-hidden": x,
                              "aria-label": x ? void 0 : d.FUNNEL_CLOCK_LABEL,
                              className: l.HEADER_CLOCK_CHIP,
                              children: [(0, t.jsx)(u.IconClock, { className: "size-3.5" }), _],
                            }),
                        ],
                      }),
                    ],
                  }),
                }),
                b &&
                  (0, t.jsx)("div", {
                    role: "progressbar",
                    "aria-label": d.FUNNEL_PROGRESS_LABEL,
                    "aria-valuemin": 0,
                    "aria-valuemax": g,
                    "aria-valuenow": h,
                    "aria-valuetext": (0, d.formatProgressValueText)(h, g),
                    className: l.HEADER_RAIL_TRACK,
                    children: (0, t.jsx)("span", {
                      className: l.HEADER_RAIL_FILL,
                      style: { transform: `scaleX(${A / 100})` },
                    }),
                  }),
              ],
            });
          },
        ],
        140830,
      ));
  },
  900206,
  669509,
  (e) => {
    "use strict";
    var t = e.i(843476);
    let r = {
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 1.5,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      "aria-hidden": !0,
    };
    (e.s(
      [
        "IconAward",
        0,
        (e) => {
          let { className: s } = e;
          return (0, t.jsxs)("svg", {
            ...r,
            className: s,
            children: [
              (0, t.jsx)("circle", { cx: "12", cy: "9", r: "5" }),
              (0, t.jsx)("path", { d: "m8.5 13.5-1.5 7 5-2.5 5 2.5-1.5-7" }),
            ],
          });
        },
        "IconBrain",
        0,
        (e) => {
          let { className: s } = e;
          return (0, t.jsxs)("svg", {
            ...r,
            className: s,
            children: [
              (0, t.jsx)("path", {
                d: "M12 4.5a3 3 0 0 0-5.8 1A3.2 3.2 0 0 0 4 8.7a3.4 3.4 0 0 0 .6 5.4A3.2 3.2 0 0 0 9 19.5c1.3 0 2.4-.7 3-1.8",
              }),
              (0, t.jsx)("path", {
                d: "M12 4.5a3 3 0 0 1 5.8 1A3.2 3.2 0 0 1 20 8.7a3.4 3.4 0 0 1-.6 5.4A3.2 3.2 0 0 1 15 19.5c-1.3 0-2.4-.7-3-1.8",
              }),
              (0, t.jsx)("path", { d: "M12 4.5v13.2" }),
            ],
          });
        },
        "IconClock",
        0,
        (e) => {
          let { className: s } = e;
          return (0, t.jsxs)("svg", {
            ...r,
            className: s,
            children: [
              (0, t.jsx)("circle", { cx: "12", cy: "12", r: "9" }),
              (0, t.jsx)("path", { d: "M12 7.5v5l3 2" }),
            ],
          });
        },
        "IconCourses",
        0,
        (e) => {
          let { className: s } = e;
          return (0, t.jsxs)("svg", {
            ...r,
            className: s,
            children: [
              (0, t.jsx)("path", { d: "M12 4 2 9l10 5 10-5z" }),
              (0, t.jsx)("path", { d: "M5 10.7V16c0 1.7 3.1 3 7 3s7-1.3 7-3v-5.3" }),
            ],
          });
        },
        "IconGlobe",
        0,
        (e) => {
          let { className: s } = e;
          return (0, t.jsxs)("svg", {
            ...r,
            className: s,
            children: [
              (0, t.jsx)("circle", { cx: "12", cy: "12", r: "9" }),
              (0, t.jsx)("path", { d: "M3 12h18" }),
              (0, t.jsx)("path", { d: "M12 3a15 15 0 0 1 0 18" }),
              (0, t.jsx)("path", { d: "M12 3a15 15 0 0 0 0 18" }),
            ],
          });
        },
        "IconLock",
        0,
        (e) => {
          let { className: s } = e;
          return (0, t.jsxs)("svg", {
            ...r,
            className: s,
            children: [
              (0, t.jsx)("rect", { x: "4.75", y: "10.5", width: "14.5", height: "9.75", rx: "2" }),
              (0, t.jsx)("path", { d: "M8.25 10.5V7.75a3.75 3.75 0 0 1 7.5 0v2.75" }),
            ],
          });
        },
        "IconReport",
        0,
        (e) => {
          let { className: s } = e;
          return (0, t.jsxs)("svg", {
            ...r,
            className: s,
            children: [
              (0, t.jsx)("path", { d: "M14 2H7a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7z" }),
              (0, t.jsx)("path", { d: "M14 2v5h5" }),
              (0, t.jsx)("path", { d: "M9 13h6" }),
              (0, t.jsx)("path", { d: "M9 17h6" }),
            ],
          });
        },
        "IconStar",
        0,
        (e) => {
          let { className: r } = e;
          return (0, t.jsx)("svg", {
            viewBox: "0 0 24 24",
            fill: "currentColor",
            "aria-hidden": !0,
            className: r,
            children: (0, t.jsx)("path", {
              d: "M12 3.5l2.6 5.27 5.82.85-4.21 4.1.99 5.78L12 16.77l-5.2 2.73.99-5.78-4.21-4.1 5.82-.85z",
            }),
          });
        },
        "IconTag",
        0,
        (e) => {
          let { className: s } = e;
          return (0, t.jsxs)("svg", {
            ...r,
            className: s,
            children: [
              (0, t.jsx)("path", {
                d: "M12.6 2.9 21 11.4a2 2 0 0 1 0 2.8l-6.8 6.8a2 2 0 0 1-2.8 0L2.9 12.6A2 2 0 0 1 2.3 11l.3-5.6a2 2 0 0 1 1.9-1.9L10 3.2a2 2 0 0 1 1.5.5Z",
              }),
              (0, t.jsx)("circle", { cx: "8", cy: "8", r: "1.25" }),
            ],
          });
        },
      ],
      669509,
    ),
      e.s([], 900206));
  },
  922342,
  162278,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(369595);
    (e.s([], 922342),
      e.s(
        [
          "FunnelTokensComponent",
          0,
          (e) => {
            let { tokens: s, values: i, highlightClassName: a = "text-blue-custom" } = e;
            return (0, t.jsx)(t.Fragment, {
              children: s.map((e, s) => {
                if ("text" === e.kind)
                  return (0, t.jsx)("span", { children: (0, r.keepTrailingEmojiInline)(e.text) }, s);
                if ("highlight" === e.kind) return (0, t.jsx)("span", { className: a, children: e.text }, s);
                if ("flag" === e.kind)
                  return (0, t.jsx)(
                    "img",
                    {
                      src: e.src,
                      alt: e.alt,
                      width: e.width,
                      height: e.height,
                      className: "mb-1 inline-block h-5 w-[30px] rounded object-cover align-middle",
                    },
                    s,
                  );
                let n = `${i?.[e.value] ?? ""}${e.suffix ?? ""}`;
                return (0, t.jsx)("span", { className: e.isHighlighted ? a : void 0, children: n }, s);
              }),
            });
          },
        ],
        162278,
      ));
  },
  20362,
  (e) => {
    "use strict";
    e.s([
      "FUNNEL_CLOCK_PLACEHOLDER",
      0,
      "—",
      "FUNNEL_SEQUENCE_TICK_MS",
      0,
      1e3,
      "MEDIA_DESKTOP_UP",
      0,
      "(min-width: 1024px)",
      "MEDIA_REDUCED_MOTION",
      0,
      "(prefers-reduced-motion: reduce)",
      "OPTION_IMAGE_ROWS",
      0,
      3,
      "OPTION_KEYS",
      0,
      ["A", "B", "C", "D", "E", "F"],
      "ROUTE_HOME",
      0,
      "/demo-home",
    ]);
  },
  524579,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(861745),
      s = e.i(19576),
      i = e.i(256889);
    let a = "flex items-center whitespace-nowrap text-hp-body font-medium";
    e.s([
      "default",
      0,
      (e) => {
        let { items: n, className: l } = e,
          o = (0, r.useLocale)(),
          c = "rtl" === (0, s.getLocaleDirection)(o);
        return (0, t.jsx)("div", {
          className: (0, i.cn)(
            "group relative w-full overflow-hidden [--duration:48s] [--gap:64px]",
            "[mask-image:linear-gradient(to_right,transparent,black_96px,black_calc(100%-96px),transparent)]",
            l,
          ),
          children: (0, t.jsxs)("div", {
            className: (0, i.cn)(
              "flex w-max gap-16 group-focus-within:[animation-play-state:paused] group-hover:[animation-play-state:paused]",
              c ? "animate-scrolling-banner-rtl" : "animate-scrolling-banner",
            ),
            children: [
              n.map((e) => (0, t.jsx)("span", { className: a, children: e.node }, e.key)),
              n.map((e) =>
                (0, t.jsx)(
                  "span",
                  { "aria-hidden": "true", className: a, children: e.node },
                  `${e.key}-duplicate`,
                ),
              ),
            ],
          }),
        });
      },
    ]);
  },
  369595,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(271645);
    let s = /\s+(\p{Extended_Pictographic})️?$/u;
    e.s([
      "keepTrailingEmojiInline",
      0,
      (e) => {
        let i = function (e) {
          let i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
          if ("string" != typeof e) return e;
          let a = e.match(s);
          return a && void 0 !== a.index
            ? (0, t.jsxs)(
                r.Fragment,
                {
                  children: [
                    e.slice(0, a.index),
                    " ",
                    (0, t.jsx)("span", { className: "font-emoji", children: `${a[1]}️` }),
                  ],
                },
                `trailing-emoji-${i}`,
              )
            : e;
        };
        return Array.isArray(e) ? e.map(i) : i(e);
      },
    ]);
  },
  493598,
  (e) => {
    "use strict";
    var t = e.i(924254);
    e.i(879568);
    var r = e.i(480408),
      s = e.i(866897);
    e.s(
      [
        "getIsGoogleTraffic",
        0,
        () => {
          let e;
          return (
            "true" === t.accessCookie.getItem(s.ECookieArg.GOOGLE_TRAFFIC) ||
            ("string" == typeof (e = r.attributionUtil.readAttributionData()?.utm_source) &&
              "google" === e.toLowerCase())
          );
        },
      ],
      493598,
    );
  },
]);
