(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  59133,
  (t) => {
    "use strict";
    var e = {};
    !(function t(e, a, n, r) {
      var o,
        i,
        l,
        s,
        c,
        h,
        f,
        u,
        d,
        m,
        g,
        p = !!(
          e.Worker &&
          e.Blob &&
          e.Promise &&
          e.OffscreenCanvas &&
          e.OffscreenCanvasRenderingContext2D &&
          e.HTMLCanvasElement &&
          e.HTMLCanvasElement.prototype.transferControlToOffscreen &&
          e.URL &&
          e.URL.createObjectURL
        ),
        b = "function" == typeof Path2D && "function" == typeof DOMMatrix;
      function M() {}
      function v(t) {
        var n = a.exports.Promise,
          r = void 0 !== n ? n : e.Promise;
        return "function" == typeof r ? new r(t) : (t(M, M), null);
      }
      var y =
          ((o = (function () {
            if (!e.OffscreenCanvas) return !1;
            var t = new OffscreenCanvas(1, 1),
              a = t.getContext("2d");
            a.fillRect(0, 0, 1, 1);
            var n = t.transferToImageBitmap();
            try {
              a.createPattern(n, "no-repeat");
            } catch (t) {
              return !1;
            }
            return !0;
          })()),
          (i = new Map()),
          {
            transform: function (t) {
              if (o) return t;
              if (i.has(t)) return i.get(t);
              var e = new OffscreenCanvas(t.width, t.height);
              return (e.getContext("2d").drawImage(t, 0, 0), i.set(t, e), e);
            },
            clear: function () {
              i.clear();
            },
          }),
        w =
          ((c = Math.floor(1e3 / 60)),
          (h = {}),
          (f = 0),
          "function" == typeof requestAnimationFrame && "function" == typeof cancelAnimationFrame
            ? ((l = function (t) {
                var e = Math.random();
                return (
                  (h[e] = requestAnimationFrame(function a(n) {
                    f === n || f + c - 1 < n
                      ? ((f = n), delete h[e], t())
                      : (h[e] = requestAnimationFrame(a));
                  })),
                  e
                );
              }),
              (s = function (t) {
                h[t] && cancelAnimationFrame(h[t]);
              }))
            : ((l = function (t) {
                return setTimeout(t, c);
              }),
              (s = function (t) {
                return clearTimeout(t);
              })),
          { frame: l, cancel: s }),
        x =
          ((m = {}),
          function () {
            if (u) return u;
            if (!n && p) {
              var e = [
                "var CONFETTI, SIZE = {}, module = {};",
                "(" + t.toString() + ")(this, module, true, SIZE);",
                "onmessage = function(msg) {\n  if (msg.data.options) {\n    CONFETTI(msg.data.options).then(function () {\n      if (msg.data.callback) {\n        postMessage({ callback: msg.data.callback });\n      }\n    });\n  } else if (msg.data.reset) {\n    CONFETTI && CONFETTI.reset();\n  } else if (msg.data.resize) {\n    SIZE.width = msg.data.resize.width;\n    SIZE.height = msg.data.resize.height;\n  } else if (msg.data.canvas) {\n    SIZE.width = msg.data.canvas.width;\n    SIZE.height = msg.data.canvas.height;\n    CONFETTI = module.exports.create(msg.data.canvas);\n  }\n}",
              ].join("\n");
              try {
                u = new Worker(URL.createObjectURL(new Blob([e])));
              } catch (t) {
                return (
                  "function" == typeof console.warn && console.warn("🎊 Could not load worker", t),
                  null
                );
              }
              var a = u;
              function r(t, e) {
                a.postMessage({ options: t || {}, callback: e });
              }
              ((a.init = function (t) {
                var e = t.transferControlToOffscreen();
                a.postMessage({ canvas: e }, [e]);
              }),
                (a.fire = function (t, e, n) {
                  if (d) return (r(t, null), d);
                  var o = Math.random().toString(36).slice(2);
                  return (d = v(function (e) {
                    function i(t) {
                      t.data.callback === o &&
                        (delete m[o], a.removeEventListener("message", i), (d = null), y.clear(), n(), e());
                    }
                    (a.addEventListener("message", i),
                      r(t, o),
                      (m[o] = i.bind(null, { data: { callback: o } })));
                  }));
                }),
                (a.reset = function () {
                  for (var t in (a.postMessage({ reset: !0 }), m)) (m[t](), delete m[t]);
                }));
            }
            return u;
          }),
        C = {
          particleCount: 50,
          angle: 90,
          spread: 45,
          startVelocity: 45,
          decay: 0.9,
          gravity: 1,
          drift: 0,
          ticks: 200,
          x: 0.5,
          y: 0.5,
          shapes: ["square", "circle"],
          zIndex: 100,
          colors: ["#26ccff", "#a25afd", "#ff5e7e", "#88ff5a", "#fcff42", "#ffa62d", "#ff36ff"],
          disableForReducedMotion: !1,
          scalar: 1,
        };
      function T(t, e, a) {
        var n;
        return ((n = t && null != t[e] ? t[e] : C[e]), a ? a(n) : n);
      }
      function I(t) {
        return t < 0 ? 0 : Math.floor(t);
      }
      function P(t) {
        return parseInt(t, 16);
      }
      function S(t) {
        return t.map(E);
      }
      function E(t) {
        var e = String(t).replace(/[^0-9a-f]/gi, "");
        return (
          e.length < 6 && (e = e[0] + e[0] + e[1] + e[1] + e[2] + e[2]),
          { r: P(e.substring(0, 2)), g: P(e.substring(2, 4)), b: P(e.substring(4, 6)) }
        );
      }
      function O(t) {
        ((t.width = document.documentElement.clientWidth),
          (t.height = document.documentElement.clientHeight));
      }
      function B(t) {
        var e = t.getBoundingClientRect();
        ((t.width = e.width), (t.height = e.height));
      }
      function k(t, a) {
        var o,
          i = !t,
          l = !!T(a || {}, "resize"),
          s = !1,
          c = T(a, "disableForReducedMotion", Boolean),
          h = p && T(a || {}, "useWorker") ? x() : null,
          f = i ? O : B,
          u = !!t && !!h && !!t.__confetti_initialized,
          d = "function" == typeof matchMedia && matchMedia("(prefers-reduced-motion)").matches;
        function m(a) {
          var m,
            g = c || T(a, "disableForReducedMotion", Boolean),
            p = T(a, "zIndex", Number);
          if (g && d)
            return v(function (t) {
              t();
            });
          (i && o
            ? (t = o.canvas)
            : i &&
              !t &&
              (((m = document.createElement("canvas")).style.position = "fixed"),
              (m.style.top = "0px"),
              (m.style.left = "0px"),
              (m.style.pointerEvents = "none"),
              (m.style.zIndex = p),
              (t = m),
              document.body.appendChild(t)),
            l && !u && f(t));
          var M = { width: t.width, height: t.height };
          function x() {
            if (h) {
              var e = {
                getBoundingClientRect: function () {
                  if (!i) return t.getBoundingClientRect();
                },
              };
              (f(e), h.postMessage({ resize: { width: e.width, height: e.height } }));
              return;
            }
            M.width = M.height = null;
          }
          function C() {
            ((o = null),
              l && ((s = !1), e.removeEventListener("resize", x)),
              i && t && (document.body.contains(t) && document.body.removeChild(t), (t = null), (u = !1)));
          }
          return (h && !u && h.init(t),
          (u = !0),
          h && (t.__confetti_initialized = !0),
          l && !s && ((s = !0), e.addEventListener("resize", x, !1)),
          h)
            ? h.fire(a, M, C)
            : (function (e, a, i) {
                for (
                  var l,
                    s,
                    c,
                    h,
                    u,
                    d,
                    m,
                    g = T(e, "particleCount", I),
                    p = T(e, "angle", Number),
                    M = T(e, "spread", Number),
                    x = T(e, "startVelocity", Number),
                    C = T(e, "decay", Number),
                    P = T(e, "gravity", Number),
                    E = T(e, "drift", Number),
                    O = T(e, "colors", S),
                    B = T(e, "ticks", Number),
                    k = T(e, "shapes"),
                    A = T(e, "scalar"),
                    F = !!T(e, "flat"),
                    R = (((l = T(e, "origin", Object)).x = T(l, "x", Number)), (l.y = T(l, "y", Number)), l),
                    N = g,
                    z = [],
                    D = t.width * R.x,
                    L = t.height * R.y;
                  N--;
                )
                  z.push(
                    (function (t) {
                      var e = t.angle * (Math.PI / 180),
                        a = t.spread * (Math.PI / 180);
                      return {
                        x: t.x,
                        y: t.y,
                        wobble: 10 * Math.random(),
                        wobbleSpeed: Math.min(0.11, 0.1 * Math.random() + 0.05),
                        velocity: 0.5 * t.startVelocity + Math.random() * t.startVelocity,
                        angle2D: -e + (0.5 * a - Math.random() * a),
                        tiltAngle: (0.5 * Math.random() + 0.25) * Math.PI,
                        color: t.color,
                        shape: t.shape,
                        tick: 0,
                        totalTicks: t.ticks,
                        decay: t.decay,
                        drift: t.drift,
                        random: Math.random() + 2,
                        tiltSin: 0,
                        tiltCos: 0,
                        wobbleX: 0,
                        wobbleY: 0,
                        gravity: 3 * t.gravity,
                        ovalScalar: 0.6,
                        scalar: t.scalar,
                        flat: t.flat,
                      };
                    })({
                      x: D,
                      y: L,
                      angle: p,
                      spread: M,
                      startVelocity: x,
                      color: O[N % O.length],
                      shape: k[Math.floor(Math.random() * (k.length - 0)) + 0],
                      ticks: B,
                      decay: C,
                      gravity: P,
                      drift: E,
                      scalar: A,
                      flat: F,
                    }),
                  );
                return o
                  ? o.addFettis(z)
                  : ((s = t),
                    (u = z.slice()),
                    (d = s.getContext("2d")),
                    (m = v(function (t) {
                      function e() {
                        ((c = h = null), d.clearRect(0, 0, a.width, a.height), y.clear(), i(), t());
                      }
                      ((c = w.frame(function t() {
                        (n &&
                          (a.width !== r.width || a.height !== r.height) &&
                          ((a.width = s.width = r.width), (a.height = s.height = r.height)),
                          a.width || a.height || (f(s), (a.width = s.width), (a.height = s.height)),
                          d.clearRect(0, 0, a.width, a.height),
                          (u = u.filter(function (t) {
                            return (function (t, e) {
                              ((e.x += Math.cos(e.angle2D) * e.velocity + e.drift),
                                (e.y += Math.sin(e.angle2D) * e.velocity + e.gravity),
                                (e.velocity *= e.decay),
                                e.flat
                                  ? ((e.wobble = 0),
                                    (e.wobbleX = e.x + 10 * e.scalar),
                                    (e.wobbleY = e.y + 10 * e.scalar),
                                    (e.tiltSin = 0),
                                    (e.tiltCos = 0),
                                    (e.random = 1))
                                  : ((e.wobble += e.wobbleSpeed),
                                    (e.wobbleX = e.x + 10 * e.scalar * Math.cos(e.wobble)),
                                    (e.wobbleY = e.y + 10 * e.scalar * Math.sin(e.wobble)),
                                    (e.tiltAngle += 0.1),
                                    (e.tiltSin = Math.sin(e.tiltAngle)),
                                    (e.tiltCos = Math.cos(e.tiltAngle)),
                                    (e.random = Math.random() + 2)));
                              var a,
                                n,
                                r,
                                o,
                                i,
                                l,
                                s,
                                c,
                                h,
                                f,
                                u,
                                d,
                                m,
                                g,
                                p,
                                M,
                                v = e.tick++ / e.totalTicks,
                                w = e.x + e.random * e.tiltCos,
                                x = e.y + e.random * e.tiltSin,
                                C = e.wobbleX + e.random * e.tiltCos,
                                T = e.wobbleY + e.random * e.tiltSin;
                              if (
                                ((t.fillStyle =
                                  "rgba(" +
                                  e.color.r +
                                  ", " +
                                  e.color.g +
                                  ", " +
                                  e.color.b +
                                  ", " +
                                  (1 - v) +
                                  ")"),
                                t.beginPath(),
                                b &&
                                  "path" === e.shape.type &&
                                  "string" == typeof e.shape.path &&
                                  Array.isArray(e.shape.matrix))
                              ) {
                                t.fill(
                                  ((a = e.shape.path),
                                  (n = e.shape.matrix),
                                  (r = e.x),
                                  (o = e.y),
                                  (i = 0.1 * Math.abs(C - w)),
                                  (l = 0.1 * Math.abs(T - x)),
                                  (s = (Math.PI / 10) * e.wobble),
                                  (c = new Path2D(a)),
                                  (h = new Path2D()).addPath(c, new DOMMatrix(n)),
                                  (f = new Path2D()).addPath(
                                    h,
                                    new DOMMatrix([
                                      Math.cos(s) * i,
                                      Math.sin(s) * i,
                                      -Math.sin(s) * l,
                                      Math.cos(s) * l,
                                      r,
                                      o,
                                    ]),
                                  ),
                                  f),
                                );
                              } else if ("bitmap" === e.shape.type) {
                                var I = (Math.PI / 10) * e.wobble,
                                  P = 0.1 * Math.abs(C - w),
                                  S = 0.1 * Math.abs(T - x),
                                  E = e.shape.bitmap.width * e.scalar,
                                  O = e.shape.bitmap.height * e.scalar,
                                  B = new DOMMatrix([
                                    Math.cos(I) * P,
                                    Math.sin(I) * P,
                                    -Math.sin(I) * S,
                                    Math.cos(I) * S,
                                    e.x,
                                    e.y,
                                  ]);
                                B.multiplySelf(new DOMMatrix(e.shape.matrix));
                                var k = t.createPattern(y.transform(e.shape.bitmap), "no-repeat");
                                (k.setTransform(B),
                                  (t.globalAlpha = 1 - v),
                                  (t.fillStyle = k),
                                  t.fillRect(e.x - E / 2, e.y - O / 2, E, O),
                                  (t.globalAlpha = 1));
                              } else if ("circle" === e.shape)
                                t.ellipse
                                  ? t.ellipse(
                                      e.x,
                                      e.y,
                                      Math.abs(C - w) * e.ovalScalar,
                                      Math.abs(T - x) * e.ovalScalar,
                                      (Math.PI / 10) * e.wobble,
                                      0,
                                      2 * Math.PI,
                                    )
                                  : ((u = e.x),
                                    (d = e.y),
                                    (m = Math.abs(C - w) * e.ovalScalar),
                                    (g = Math.abs(T - x) * e.ovalScalar),
                                    (p = (Math.PI / 10) * e.wobble),
                                    (M = 2 * Math.PI),
                                    t.save(),
                                    t.translate(u, d),
                                    t.rotate(p),
                                    t.scale(m, g),
                                    t.arc(0, 0, 1, 0, M, void 0),
                                    t.restore());
                              else if ("star" === e.shape)
                                for (
                                  var A = (Math.PI / 2) * 3,
                                    F = 4 * e.scalar,
                                    R = 8 * e.scalar,
                                    N = e.x,
                                    z = e.y,
                                    D = 5,
                                    L = Math.PI / 5;
                                  D--;
                                )
                                  ((N = e.x + Math.cos(A) * R),
                                    (z = e.y + Math.sin(A) * R),
                                    t.lineTo(N, z),
                                    (A += L),
                                    (N = e.x + Math.cos(A) * F),
                                    (z = e.y + Math.sin(A) * F),
                                    t.lineTo(N, z),
                                    (A += L));
                              else
                                (t.moveTo(Math.floor(e.x), Math.floor(e.y)),
                                  t.lineTo(Math.floor(e.wobbleX), Math.floor(x)),
                                  t.lineTo(Math.floor(C), Math.floor(T)),
                                  t.lineTo(Math.floor(w), Math.floor(e.wobbleY)));
                              return (t.closePath(), t.fill(), e.tick < e.totalTicks);
                            })(d, t);
                          })).length
                            ? (c = w.frame(t))
                            : e());
                      })),
                        (h = e));
                    })),
                    (o = {
                      addFettis: function (t) {
                        return ((u = u.concat(t)), m);
                      },
                      canvas: s,
                      promise: m,
                      reset: function () {
                        (c && w.cancel(c), h && h());
                      },
                    }).promise);
              })(a, M, C);
        }
        return (
          (m.reset = function () {
            (h && h.reset(), o && o.reset());
          }),
          m
        );
      }
      function A() {
        return (g || (g = k(null, { useWorker: !0, resize: !0 })), g);
      }
      ((a.exports = function () {
        return A().apply(this, arguments);
      }),
        (a.exports.reset = function () {
          A().reset();
        }),
        (a.exports.create = k),
        (a.exports.shapeFromPath = function (t) {
          if (!b) throw Error("path confetti are not supported in this browser");
          "string" == typeof t ? (n = t) : ((n = t.path), (r = t.matrix));
          var e = new Path2D(n),
            a = document.createElement("canvas").getContext("2d");
          if (!r) {
            for (var n, r, o, i, l = 1e3, s = 1e3, c = 0, h = 0, f = 0; f < 1e3; f += 2)
              for (var u = 0; u < 1e3; u += 2)
                a.isPointInPath(e, f, u, "nonzero") &&
                  ((l = Math.min(l, f)), (s = Math.min(s, u)), (c = Math.max(c, f)), (h = Math.max(h, u)));
            o = c - l;
            var d = Math.min(10 / o, 10 / (i = h - s));
            r = [d, 0, 0, d, -Math.round(o / 2 + l) * d, -Math.round(i / 2 + s) * d];
          }
          return { type: "path", path: n, matrix: r };
        }),
        (a.exports.shapeFromText = function (t) {
          var e,
            a = 1,
            n = "#000000",
            r =
              '"Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji", "EmojiOne Color", "Android Emoji", "Twemoji Mozilla", "system emoji", sans-serif';
          "string" == typeof t
            ? (e = t)
            : ((e = t.text),
              (a = "scalar" in t ? t.scalar : a),
              (r = "fontFamily" in t ? t.fontFamily : r),
              (n = "color" in t ? t.color : n));
          var o = 10 * a,
            i = "" + o + "px " + r,
            l = new OffscreenCanvas(o, o),
            s = l.getContext("2d");
          s.font = i;
          var c = s.measureText(e),
            h = Math.ceil(c.actualBoundingBoxRight + c.actualBoundingBoxLeft),
            f = Math.ceil(c.actualBoundingBoxAscent + c.actualBoundingBoxDescent),
            u = c.actualBoundingBoxLeft + 2,
            d = c.actualBoundingBoxAscent + 2;
          ((h += 4),
            (f += 4),
            ((s = (l = new OffscreenCanvas(h, f)).getContext("2d")).font = i),
            (s.fillStyle = n),
            s.fillText(e, u, d));
          var m = 1 / a;
          return {
            type: "bitmap",
            bitmap: l.transferToImageBitmap(),
            matrix: [m, 0, 0, m, (-h * m) / 2, (-f * m) / 2],
          };
        }));
    })(
      (function () {
        return "u" > typeof window ? window : "u" > typeof self ? self : this || {};
      })(),
      e,
      !1,
    );
    let a = e.exports;
    var n = e.exports.create;
    t.s(["create", 0, n, "default", 0, a]);
  },
]);
