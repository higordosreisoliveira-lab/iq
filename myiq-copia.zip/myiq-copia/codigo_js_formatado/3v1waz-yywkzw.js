(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  712645,
  (e) => {
    "use strict";
    let t = (0, e.i(770703).default)(() => e.A(203545), { loadableGenerated: { modules: [617740] } });
    e.s(["TriviaXPBonusModalComponent", 0, t]);
  },
  734280,
  function (e) {
    e.n(e.i(712645));
  },
  203545,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/39q2gkrj_j4r-.js"].map((t) => e.l(t))).then(() => t(617740)));
  },
]);
