/* myIQ clone — Express server
 * Serves a faithful reconstruction of myiq.com (home + full funnel + legal pages),
 * in English (default) and Portuguese (/pt-BR prefix).
 * Static assets + client logic live in /public (css, js modules).
 */
const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, 'public')));

/* ----------------------------------------------------------------------------
 * Real captured pages (pixel-identical to myiq.com).
 * We serve the real server/browser-rendered HTML + the real CSS chunks
 * (mirrored under public/_next/static/chunks). The original myIQ scripts are
 * stripped (they need myIQ's backend); public/js/boot.js restores image
 * fallbacks since media (logos, figure photos, fonts) was not captured.
 * -------------------------------------------------------------------------- */
const CAP = {
  home: 'capturas/home_renderizada.html',
  homePt: 'paginas/pt-BR.html',
  pricing: 'paginas/pricing.html',
  terms: 'paginas/terms.html',
  privacy: 'paginas/privacy.html',
  cookie: 'paginas/cookie.html',
  help: 'paginas/help.html',
  contact: 'paginas/help_contact-myiq-support.html',
  signin: 'paginas/sign-in.html',
  cancelAuth: 'paginas/cancellation_auth.html',
};

const INJECT_HEAD =
  '<link rel="preconnect" href="https://fonts.googleapis.com"/>' +
  '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>' +
  '<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet"/>' +
  '<style>:root{--font-primary:"Inter",system-ui,sans-serif}body,button,input,textarea,select{font-family:"Inter",ui-sans-serif,system-ui,sans-serif}</style>';

const _cache = {};
function serveReal(res, file, lang) {
  try {
    let html = _cache[file];
    if (!html) {
      html = fs.readFileSync(path.join(__dirname, file), 'utf8');
      // remove original scripts (backend-bound + tracking) but keep content
      html = html.replace(/<script[\s\S]*?<\/script>/gi, '');
      // inject fonts + our boot script
      html = html.replace(/<\/head>/i, INJECT_HEAD + '</head>');
      html = html.replace(/<\/body>/i, '<script src="/js/i18n-auto.js"></script><script src="/js/boot.js"></script></body>');
      _cache[file] = html;
    }
    res.set('Content-Type', 'text/html; charset=utf-8').send(html);
  } catch (e) {
    res.status(500).send('capture missing: ' + file);
  }
}
function real(file) {
  return (req, res) => serveReal(res, file, req.path.startsWith('/pt-BR') ? 'pt' : 'en');
}

/* Serve a captured page file as-is (user-authorized: run the real myIQ app
   locally from the mirrored chunks for an identical look and behaviour). */
const _appCache = {};
function serveRealApp(res, file) {
  try {
    let html = _appCache[file];
    if (!html) { html = fs.readFileSync(path.join(__dirname, file), 'utf8'); _appCache[file] = html; }
    res.set('Content-Type', 'text/html; charset=utf-8').send(html);
  } catch (e) { res.status(500).send('capture missing: ' + file); }
}
function app_(file) { return (req, res) => serveRealApp(res, file); }

const RAW = { home: 'capturas/home_renderizada.html', homeraw: 'paginas/home.html', quiz: 'paginas/quiz.html', checkout: 'paginas/checkout.html', pricing: 'paginas/pricing.html', start: 'paginas/start.html' };
app.get('/_raw/:name', (req, res) => {
  const f = RAW[req.params.name];
  if (!f) return res.status(404).send('no');
  serveRealApp(res, f);
});

/* ----------------------------------------------------------------------------
 * FUNNEL pages (quiz / analyzing / checkout / dashboard), reconstructed from
 * the live capture of myiq.com using the REAL CSS chunks + real /quiz-images.
 * -------------------------------------------------------------------------- */
const REAL_CSS = ['2rj6rej590pre', '3tg587kdpj6hd', '270s0cx0aj93v']
  .map((c) => `<link rel="stylesheet" href="/_next/static/chunks/${c}.css"/>`).join('');

/* inline line icons (replace emojis) — Lucide-style, stroke = currentColor */
const ICON = {
  award: '<circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/>',
  doc: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M16 13H8"/><path d="M16 17H8"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
  brain: '<path d="M12 5a3 3 0 1 0-5.997.142 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"/><path d="M12 5a3 3 0 1 1 5.997.142 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z"/>',
  cap: '<path d="M22 10 12 5 2 10l10 5z"/><path d="M6 12v5c0 1 2 3 6 3s6-2 6-3v-5"/>',
  tag: '<path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"/><circle cx="7.5" cy="7.5" r=".6"/>',
  lock: '<rect width="18" height="11" x="3" y="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  mail: '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  plus: '<path d="M5 12h14"/><path d="M12 5v14"/>',
  instagram: '<rect width="20" height="20" x="2" y="2" rx="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>',
  facebook: '<path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>',
  reddit: '<circle cx="12" cy="12" r="9"/><circle cx="8.5" cy="12.5" r="1" fill="currentColor" stroke="none"/><circle cx="15.5" cy="12.5" r="1" fill="currentColor" stroke="none"/><path d="M8.5 15.5c1 1 5.5 1 7 0"/><path d="M15.5 8.5 17 5l3 1"/><circle cx="20" cy="6" r="1"/>',
};
function icon(name, cls) {
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="${cls || 'h-5 w-5'}">${ICON[name] || ''}</svg>`;
}

/* simple SVG country flags (emoji flags don't render on Windows) */
const FLAG = {
  br: '<rect width="60" height="40" fill="#009b3a"/><path d="M30 5 55 20 30 35 5 20z" fill="#fedf00"/><circle cx="30" cy="20" r="8" fill="#002776"/>',
  us: '<rect width="60" height="40" fill="#fff"/>' + [0, 2, 4, 6].map((n) => `<rect y="${n * 5.7}" width="60" height="3" fill="#b22234"/>`).join('') + [1, 3, 5].map((n) => `<rect y="${n * 5.7 + 2.9}" width="60" height="3" fill="#b22234"/>`).join('') + '<rect width="26" height="22" fill="#3c3b6e"/>',
  nl: '<rect width="60" height="40" fill="#fff"/><rect width="60" height="13.3" fill="#ae1c28"/><rect y="26.7" width="60" height="13.3" fill="#21468b"/>',
  de: '<rect width="60" height="13.3" fill="#000"/><rect y="13.3" width="60" height="13.3" fill="#d00"/><rect y="26.7" width="60" height="13.3" fill="#ffce00"/>',
  fr: '<rect width="60" height="40" fill="#fff"/><rect width="20" height="40" fill="#0055a4"/><rect x="40" width="20" height="40" fill="#ef4135"/>',
  it: '<rect width="60" height="40" fill="#fff"/><rect width="20" height="40" fill="#009246"/><rect x="40" width="20" height="40" fill="#ce2b37"/>',
  jp: '<rect width="60" height="40" fill="#fff"/><circle cx="30" cy="20" r="10" fill="#bc002d"/>',
  mx: '<rect width="60" height="40" fill="#fff"/><rect width="20" height="40" fill="#006847"/><rect x="40" width="20" height="40" fill="#ce1126"/>',
};
function flag(code) {
  return `<svg viewBox="0 0 60 40" preserveAspectRatio="none" class="inline-block h-3.5 w-5 shrink-0 rounded-[2px] align-[-2px] ring-1 ring-black/10">${FLAG[code] || ''}</svg>`;
}

function myiqMark(lang) {
  return `<a href="${L(lang, '/')}" class="flex items-center gap-2 no-underline text-black-custom">
    <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-8.5 8.5 8.5 8.5 0 0 1-3.8-.9L3 21l1.9-5.7A8.38 8.38 0 0 1 4 11.5 8.5 8.5 0 0 1 12.5 3 8.38 8.38 0 0 1 21 11.5z"/></svg>
    <span class="text-hp-h3 font-semibold tracking-tight">my<span class="text-blue-custom">IQ</span></span>
  </a>`;
}

function funnelDoc(main, { title, lang, scripts }) {
  const l = lang === 'pt' ? 'pt-BR' : 'en';
  return `<!doctype html>
<html lang="${l}" class="scroll-smooth"><head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>${title}</title>
<link rel="icon" href="/favicon.svg"/>
<link rel="preconnect" href="https://fonts.googleapis.com"/><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet"/>
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config = { theme: { extend: {
  fontFamily: { sans: ['Inter','ui-sans-serif','system-ui','sans-serif'] },
  colors: { 'green-custom':'#00b67a','green-dark':'#0b635c','blue-custom':'#006fee','blue-highlight':'#005bc4','light-blue':'#f0f6fe','black-custom':'#111827','grey-deep':'#4b5563','grey-custom':'#9ca3af' },
  fontSize: {
    'hp-hero-lg': ['3.5rem', { lineHeight: '1.05', letterSpacing: '-0.03em', fontWeight: '600' }],
    'hp-display-lg': ['3rem', { lineHeight: '1.08', letterSpacing: '-0.028em', fontWeight: '600' }],
    'hp-stat-lg': ['2.25rem', { lineHeight: '2.5rem', letterSpacing: '-0.021em', fontWeight: '600' }],
    'hp-h2-lg': ['2rem', { lineHeight: '1.15', letterSpacing: '-0.02em', fontWeight: '600' }],
    'hp-h2': ['1.75rem', { lineHeight: '1.2', letterSpacing: '-0.02em', fontWeight: '600' }],
    'hp-h3': ['1.25rem', { lineHeight: '1.3', letterSpacing: '-0.01em', fontWeight: '600' }],
    'hp-lede': ['1.125rem', { lineHeight: '1.5' }],
    'hp-body': ['1rem', { lineHeight: '1.5' }],
    'hp-body-sm': ['0.875rem', { lineHeight: '1.45' }],
    'hp-caption': ['0.8125rem', { lineHeight: '1.4' }],
  },
} } };
</script>
<link rel="stylesheet" href="/css/custom.css"/>
<style>body{font-family:"Inter",ui-sans-serif,system-ui,sans-serif}</style>
</head>
<body class="bg-white text-black-custom min-h-dvh">
${main}
${(scripts || []).map((s) => `<script src="${s}"></script>`).join('')}
<script src="/js/i18n-auto.js"></script><script src="/js/boot.js"></script>
</body></html>`;
}

function quizPage(lang) {
  const main = `
<div class="flex min-h-dvh flex-col">
  <header class="sticky top-0 z-30 border-b border-slate-100 bg-white/90 backdrop-blur">
    <div class="mx-auto flex h-14 max-w-7xl items-center justify-between px-4 md:px-6">
      ${myiqMark(lang)}
      <div class="flex items-center gap-4 text-hp-caption text-grey-deep">
        <span class="tabular-nums">⏱ <span id="quiz-timer-display" class="font-medium text-black-custom">20:00</span></span>
        <a href="${L(lang, '/')}" class="rounded-full border border-slate-200 px-3 py-1.5 no-underline text-grey-deep hover:text-black-custom">${lang === 'pt' ? 'Sair' : 'Quit'}</a>
      </div>
    </div>
    <div class="h-1 w-full bg-slate-100"><div id="quiz-progress-bar" class="h-1 bg-green-custom transition-all duration-300" style="width:2%"></div></div>
  </header>
  <div class="mx-auto flex w-full max-w-7xl items-center justify-between px-4 pt-4 text-hp-caption text-grey-deep md:px-6">
    <span><span id="quiz-current-num">1</span> ${lang === 'pt' ? 'de' : 'of'} <span id="quiz-total-num">40</span></span>
  </div>
  <main id="quiz-root" class="flex min-h-0 flex-1 flex-col"></main>
</div>`;
  return funnelDoc(main, { title: lang === 'pt' ? 'Quiz de QI online | Confira sua pontuação de QI' : 'IQ Quiz Online | Check Your IQ Score', lang, scripts: ['/js/myiq-quiz.js'] });
}

function analyzingPage(lang) {
  const pt = lang === 'pt';
  const measures = pt
    ? ['Memória', 'Velocidade', 'Reação', 'Concentração', 'Lógica']
    : ['Memory', 'Speed', 'Reaction', 'Focus', 'Logic'];
  const main = `
<div class="flex min-h-dvh flex-col">
  <header class="border-b border-slate-100"><div class="mx-auto flex h-14 max-w-7xl items-center px-4 md:px-6">${myiqMark(lang)}</div></header>
  <main class="flex min-h-0 flex-1 flex-col">
    <div class="mx-auto w-full max-w-7xl px-4 md:px-6 lg:px-8 mb-auto md:my-auto">
      <div class="w-full py-10">
        <div class="mx-auto flex w-full max-w-xl flex-col gap-6 lg:max-w-3xl">
          <div class="md:rounded-3xl md:bg-light-blue md:p-10">
            <div class="flex flex-col gap-6 md:flex-row md:items-center md:gap-8">
              <div class="flex min-w-0 flex-1 flex-col gap-2">
                <h1 class="text-hp-stat-lg text-black-custom">${pt ? 'Calculando seu ' : 'Calculating your '}<span class="text-blue-custom">${pt ? 'QI...' : 'IQ...'}</span></h1>
                <p class="max-w-md text-pretty text-hp-lede text-grey-deep">${pt ? 'Espere um instante enquanto nossa IA analisa suas respostas com base nas 5 principais medidas de inteligência...' : 'Hold on while our AI analyzes your answers across the 5 core measures of intelligence...'}</p>
              </div>
              <div class="shrink-0">
                <div class="relative mx-auto size-24 shrink-0 lg:size-28">
                  <svg viewBox="0 0 100 100" class="size-full -rotate-90"><circle cx="50" cy="50" r="44" fill="none" stroke="#E2E8F0" stroke-width="2.5"/><circle id="ana-ring" cx="50" cy="50" r="44" fill="none" stroke="#006FEE" stroke-width="2.5" stroke-linecap="round" stroke-dasharray="276.46" style="stroke-dashoffset:276.46;transition:stroke-dashoffset .3s linear"/></svg>
                  <p class="pointer-events-none absolute inset-0 flex items-center justify-center"><span id="ana-pct" class="text-hp-h3 tabular-nums text-black-custom">0%</span></p>
                </div>
              </div>
            </div>
            <div class="mt-6 flex flex-col gap-2">
              ${measures.map((m, i) => `<div class="flex items-center justify-between rounded-xl bg-white/70 px-4 py-2.5"><span class="text-hp-body text-black-custom">${m}</span><span id="ana-m${i}" class="text-hp-caption text-grey-custom">${pt ? 'aguardando' : 'waiting'}</span></div>`).join('')}
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
</div>
<script>
(function(){
  var next=${JSON.stringify(L(lang, '/email'))};
  var pt=${pt?'true':'false'};
  var ring=document.getElementById('ana-ring'), pctEl=document.getElementById('ana-pct');
  var done=pt?'concluído':'scored', prog=pt?'em andamento':'in progress';
  var p=0, N=5, C=276.46;
  var t=setInterval(function(){
    p+=2; if(p>100)p=100;
    ring.style.strokeDashoffset=String(C*(1-p/100));
    pctEl.textContent=p+'%';
    for(var i=0;i<N;i++){ var e=document.getElementById('ana-m'+i); if(!e)continue;
      var thr=(i+1)/N*100;
      if(p>=thr){ e.textContent=done; e.className='text-hp-caption text-green-custom'; }
      else if(p>=thr-100/N){ e.textContent=prog; e.className='text-hp-caption text-blue-custom'; }
    }
    if(p>=100){ clearInterval(t); setTimeout(function(){location.href=next;}, 600); }
  }, 90);
})();
</script>`;
  return funnelDoc(main, { title: pt ? 'Teste de QI Online | myIQ' : 'Analyzing… | myIQ', lang });
}

function checkoutPage(lang) {
  const pt = lang === 'pt';
  // Always USD (no BRL): the product bills in dollars even for pt-BR.
  const price = { trial: '$1.00', full: '$6.99', renew: '$29.99', cycle: pt ? '28 dias' : '28 days' };
  const summary = pt
    ? [['Sua pontuação de QI e seu certificado', price.trial, 'award'], ['Relatório cognitivo detalhado', 'Incluído', 'doc'], ['Ranking global e por país', 'Incluído', 'globe'], ['Mais de 150 exercícios de treino cerebral', 'Incluído', 'brain'], ['17 cursos com especialistas', 'Incluído', 'cap']]
    : [['Your IQ score & certificate', price.trial, 'award'], ['Detailed cognitive report', 'Included', 'doc'], ['Global & country ranking', 'Included', 'globe'], ['150+ brain training exercises', 'Included', 'brain'], ['17 courses with specialists', 'Included', 'cap']];
  const reviews = [
    ['Coincidence? I don’t think so!', 'Your test is accurate — the IQ I got matches my real one within 3%.', 'Mirekiq', pt ? 'Tchéquia' : 'Czechia'],
    ['Fun and interesting', 'Fun, quick and easy. Although I really wonder how accurate this is.', 'Mbdaking', pt ? 'Estados Unidos' : 'United States'],
    ['Short but challenging', 'It was short but challenging. Really enjoyed it.', 'E.B.', pt ? 'Grécia' : 'Greece'],
  ];
  const press = ['digitaltrends', 'MSN', 'Newsweek', 'USA Today', 'yahoo!finance', 'BUSINESS INSIDER'];
  const pay = [
    { label: 'PayPal', bg: '#ffc439', fg: '#003087', bold: true },
    { label: '$ Cash App Pay', bg: '#000000', fg: '#ffffff' },
    { label: 'venmo', bg: '#3d95ce', fg: '#ffffff', bold: true },
    { label: 'G Pay', bg: '#000000', fg: '#ffffff' },
    { label: pt ? 'Cartão de crédito ou débito' : 'Credit or debit card', bg: '#0b635c', fg: '#ffffff' },
  ];
  const main = `
<div class="flex min-h-dvh flex-col" id="checkout-view">
  <!-- live social-proof bar -->
  <div id="sale-bar" class="w-full bg-slate-50 py-2 text-center text-hp-caption text-black-custom"><span class="inline-flex items-center gap-1.5"><span class="inline-block size-2 rounded-full bg-green-custom"></span><span id="sale-text">Jos*** just bought their IQ Score!</span> <span id="sale-flag">${flag('br')}</span> <span class="font-semibold text-blue-custom" id="sale-iq">IQ 126</span></span></div>
  <header class="border-b border-slate-100"><div class="mx-auto flex h-14 max-w-6xl items-center justify-between px-4 md:px-6">${myiqMark(lang)}
    <span class="inline-flex items-center gap-2 rounded-full border border-slate-200 px-2 py-1"><span class="grid size-6 place-items-center rounded-full bg-light-blue text-[11px] font-bold text-blue-custom">RY</span><span id="acct-email" class="text-hp-caption text-grey-deep">you@email.com</span></span>
  </div></header>
  <div class="w-full border-b border-slate-100 bg-white py-2 text-center text-hp-caption text-black-custom">${pt ? 'Pontuação de QI por só ' + price.trial + '!' : 'IQ Score only ' + price.trial + '!'} <span class="text-grey-deep">${pt ? 'A oferta acaba em' : 'Offer ends in'}</span> <span id="checkout-timer" class="ml-1 rounded bg-light-blue px-1.5 py-0.5 font-semibold tabular-nums text-blue-custom">07:12</span></div>

  <main class="flex-1">
    <div class="mx-auto w-full max-w-6xl px-4 py-10 md:px-6">
      <h1 class="text-center text-hp-stat-lg font-semibold text-black-custom">${pt ? 'Parabéns! Sua pontuação está pronta!' : 'Congratulations! Your Score Is Ready!'}</h1>

      <div class="mt-8 grid gap-10 lg:grid-cols-[1fr_1fr] lg:items-start">
        <!-- LEFT: score teaser -->
        <div>
          <div class="rounded-3xl bg-light-blue p-5 md:p-6">
            <div class="grid grid-cols-3 items-end gap-3 md:gap-4">
              <div class="text-center"><div class="mb-2 text-hp-caption text-grey-deep">IQ 113</div><div class="overflow-hidden rounded-2xl border border-slate-200 bg-white"><img src="/images/coco-chanelV21.webp" alt="" class="h-36 w-full object-cover object-top"/></div></div>
              <div class="text-center"><div class="mb-2 text-hp-caption font-semibold text-blue-custom">${pt ? 'VOCÊ' : 'YOU'}</div><div class="relative flex h-52 flex-col items-center justify-end overflow-hidden rounded-2xl bg-blue-custom"><span class="absolute top-4 text-hp-h2 font-bold text-white">???</span><img src="/images/youIq1.webp" alt="" class="h-40 w-full object-contain object-bottom"/></div></div>
              <div class="text-center"><div class="mb-2 text-hp-caption text-grey-deep">IQ 160</div><div class="overflow-hidden rounded-2xl border border-slate-200 bg-white"><img src="/images/sj.webp" alt="" class="h-44 w-full object-cover object-top"/></div></div>
            </div>
            <div class="mt-5 grid grid-cols-3 gap-6 border-t border-black/5 pt-5 text-center">
              <div><div class="text-hp-h2 font-bold text-black-custom">107</div><div class="text-[12px] text-grey-deep">${pt ? 'QI médio hoje' : 'Average IQ today'}</div></div>
              <div><div class="text-hp-h2 font-bold text-black-custom">9.964</div><div class="text-[12px] text-grey-deep">${pt ? 'Testes feitos hoje' : 'Tests taken today'}</div></div>
              <div><div class="text-hp-h2 font-bold text-black-custom">4.1 / 5</div><div class="text-[12px] text-grey-deep"><span class="text-green-custom">★</span> 151.263 ${pt ? 'avaliações' : 'reviews'}</div></div>
            </div>
          </div>
        </div>

        <!-- RIGHT: summary + payment -->
        <div>
          <div class="text-hp-caption font-semibold uppercase tracking-wide text-grey-custom">${pt ? 'Seu resumo' : 'Your summary'}</div>
          <div class="mt-4 flex flex-col">
            ${summary.map(([k, v, ikey]) => `<div class="flex items-center justify-between gap-4 border-b border-slate-100 py-3"><span class="flex items-center gap-2.5 text-hp-body text-grey-deep"><span class="text-grey-custom">${icon(ikey, 'h-5 w-5')}</span>${k}</span><span class="shrink-0 text-hp-body ${v === 'Included' || v === 'Incluído' ? 'text-blue-custom' : 'font-medium text-black-custom'}">${v}</span></div>`).join('')}
          </div>
          <div class="mt-4 flex items-center justify-between gap-4 rounded-xl bg-light-blue px-4 py-3"><span class="flex items-center gap-2 text-hp-caption text-blue-highlight"><span class="text-blue-custom">${icon('tag', 'h-4 w-4')}</span><span><span class="font-semibold">${pt ? 'Código MYIQ-85 aplicado' : 'Promo Code MYIQ-85 Applied'}</span><br/><span class="text-grey-deep">${pt ? 'Você economiza 85%' : 'You save 85%'}</span></span></span><span class="rounded-full bg-blue-custom px-2 py-0.5 text-hp-caption font-bold text-white">-85%</span></div>

          <div class="mt-5 rounded-2xl border border-slate-200 p-4">
            <div class="flex items-center justify-between"><span class="text-hp-body text-grey-deep">${pt ? 'Total a pagar:' : 'Total due:'}</span><span><span class="mr-2 text-hp-body text-grey-custom line-through">${price.full}</span><span class="text-hp-h2 font-bold text-black-custom">${price.trial}</span></span></div>
            <label class="mt-3 flex items-start gap-2 text-[12px] leading-relaxed text-grey-deep"><input id="consent" type="checkbox" checked class="mt-0.5 size-4 shrink-0 accent-blue-custom"/><span>${pt
              ? `Entendo que, ao marcar esta caixa e me inscrever, serei cobrado ${price.trial} por um teste de 7 dias, após o qual <b class="font-semibold text-black-custom">minha assinatura renova automaticamente por ${price.renew} a cada ${price.cycle}, a menos que eu cancele antes do fim do teste em <span id="trial-end"></span></b>. Posso cancelar quando quiser nas configurações. Preço sem impostos.`
              : `I understand that by checking this box and signing up, I will be charged ${price.trial} for a 7-day trial, after which <b class="font-semibold text-black-custom">my subscription will automatically renew at ${price.renew} every ${price.cycle} unless I cancel before the trial ends on <span id="trial-end"></span></b>. I can cancel anytime through my account settings. Price excludes tax.`}</span></label>
            <div class="mt-4 flex flex-col gap-2.5">
              ${pay.map((p) => `<button class="btn-unlock flex h-12 w-full items-center justify-center rounded-lg text-[15px] ${p.bold ? 'font-bold' : 'font-semibold'}" style="background:${p.bg};color:${p.fg}">${p.label}</button>`).join('')}
            </div>
          </div>
        </div>
      </div>

      <!-- press -->
      <p class="mt-14 text-center text-hp-caption font-semibold uppercase tracking-widest text-grey-custom">${pt ? 'O myIQ foi destaque em' : 'myIQ has been featured on'}</p>
      <div class="relative mt-5 overflow-hidden [mask-image:linear-gradient(90deg,transparent,#000_8%,#000_92%,transparent)]">
        <div class="animate-scrolling-banner items-center gap-14 opacity-60">
          ${[...press, ...press, ...press].map((p) => `<span class="shrink-0 whitespace-nowrap text-hp-body font-semibold text-grey-custom">${p}</span>`).join('')}
        </div>
      </div>

      <!-- reviews -->
      <h2 class="mt-14 text-center text-hp-h2 font-bold text-black-custom">${pt ? 'O que dizem os participantes.' : 'What test takers say.'}</h2>
      <div class="mt-6 grid gap-5 sm:grid-cols-3">
        ${reviews.map(([t, b, n, c]) => `<div class="rounded-2xl border border-slate-100 bg-white p-6"><div class="text-green-custom">★★★★★</div><h4 class="mt-2 font-semibold text-black-custom">${t}</h4><p class="mt-2 text-hp-body text-grey-deep">${b}</p><div class="mt-3 text-hp-caption text-grey-custom">${n} · ${c}</div></div>`).join('')}
      </div>
      <p class="mt-6 text-center text-hp-caption text-grey-deep">${pt ? 'Nota' : 'Rated'} <b class="text-black-custom">4.1 / 5</b> ${pt ? 'com base em' : 'based on'} <b class="text-black-custom">151.263 ${pt ? 'avaliações' : 'reviews'}</b>. <span class="text-green-custom">★ Trustpilot</span></p>

      <!-- Reveal your IQ / cognitive report preview -->
      <div class="mt-16 grid items-center gap-10 lg:grid-cols-2">
        <div>
          <h2 class="text-hp-stat-lg font-semibold text-black-custom">${pt ? 'Revele seu QI. Veja o panorama completo.' : 'Reveal your IQ. See the full picture.'}</h2>
          <p class="mt-3 text-hp-lede text-grey-deep">${pt ? 'Você concluiu o desafio. Libere seu relatório pessoal para entender seus resultados e ver como você se compara aos outros.' : "You've completed the challenge. Unlock your personal report to understand your results and discover how you compare."}</p>
          <ul class="mt-5 flex flex-col gap-3 text-hp-body text-grey-deep">
            ${(pt
              ? ['Sua pontuação de QI, com uma explicação clara', 'Sua posição entre quem fez o teste myIQ', 'Uma análise detalhada de todas as 40 respostas']
              : ['Your IQ score, with a clear explanation', 'Your ranking among other myIQ test takers', 'A detailed breakdown of all 40 answers']
            ).map((i) => `<li class="flex items-start gap-2"><span class="mt-0.5 text-blue-custom">${icon('check', 'h-4 w-4')}</span>${i}</li>`).join('')}
          </ul>
        </div>
        <div class="rounded-3xl border border-slate-100 bg-light-blue p-5 md:p-6">
          <div class="rounded-2xl border border-slate-100 bg-white p-5">
            <div class="text-hp-caption text-grey-deep">${pt ? 'Seu relatório cognitivo' : 'Your cognitive report'}</div>
            <svg viewBox="0 0 320 140" class="mt-3 w-full">
              <path d="M10 120 C 80 120, 100 24, 160 24 S 240 120, 310 120" fill="#eff6ff" stroke="#006fee" stroke-width="2.5"/>
              <line x1="222" y1="24" x2="222" y2="120" stroke="#006fee" stroke-width="1.5" stroke-dasharray="4 4"/>
              <g transform="translate(222,18)"><rect x="-18" y="-13" width="36" height="20" rx="10" fill="#006fee"/><text x="0" y="1" text-anchor="middle" dominant-baseline="middle" font-size="11" fill="#fff" font-weight="700">${pt ? 'Você' : 'You'}</text></g>
            </svg>
            <div class="mt-4 grid grid-cols-3 gap-2 text-center">
              ${[[pt ? 'Melhor que' : 'Better than'], [pt ? 'Sua pontuação' : 'Your IQ score'], [pt ? 'Acima da média' : 'Above average']].map(([lbl]) => `<div class="rounded-xl bg-light-blue p-3"><div class="text-[11px] text-grey-deep">${lbl}</div><div class="mx-auto mt-2 h-4 w-12 rounded bg-slate-300/70 blur-[3px]"></div></div>`).join('')}
            </div>
            <div class="mt-4 flex items-center justify-center gap-1.5 text-hp-caption font-medium text-green-dark">${icon('lock', 'h-4 w-4')} ${pt ? 'Disponível com o acesso completo' : 'Unlocks with full access'}</div>
          </div>
        </div>
      </div>

      <!-- FAQ -->
      <h2 class="mt-20 text-center text-hp-stat-lg font-semibold text-black-custom">${pt ? 'Dúvidas, respondidas.' : 'Questions, answered.'}</h2>
      <div class="mx-auto mt-8 grid max-w-4xl gap-x-12 md:grid-cols-2">
        ${(() => {
          const faqs = pt
            ? [['O que está incluído na minha assinatura?', 'Sua assinatura inclui um relatório de QI personalizado e certificado, acesso completo a todos os testes, jogos de treino cerebral, cursos e acompanhamento de progresso. Seus resultados sincronizam em todos os dispositivos ao fazer login.'], ['Como cancelo minha assinatura?', 'Cancele a qualquer momento no seu perfil ou em myiq.com/cancellation. Informe seu e-mail, confirme o código de seis dígitos e pronto. Você mantém acesso até o fim do período pago.'], ['Meus resultados são privados?', 'Sim. Seus resultados ficam visíveis só para você, a menos que escolha compartilhar. Os rankings são anônimos e você pode apagar sua conta e dados a qualquer momento.'], ['O que é uma boa pontuação de QI?', 'A média é 100, e a maioria das pessoas fica entre 85 e 115. Acima de 100 é acima da média; 130 ou mais está entre os ~2% melhores.'], ['Dá para aumentar sua pontuação de QI?', 'Sua pontuação pode melhorar com educação, prática mental regular, bom sono e saúde. O treino também fortalece memória, foco e reconhecimento de padrões.'], ['Onde encontro meus resultados?', 'Sua pontuação, relatório completo e certificado ficam no seu perfil. Você pode baixar o relatório em PDF e o certificado como imagem.'], ['O QI muda com a idade?', 'O QI costuma ser estável, mas pode mudar ao longo do tempo. A velocidade de processamento pode cair com a idade, enquanto vocabulário e conhecimento acumulado podem crescer.'], ['O QI é herdado dos pais?', 'A genética tem um papel, mas o QI não é determinado só pelos genes. Educação, saúde, ambiente e experiências de vida também influenciam.']]
            : [['What does my subscription include?', 'Your subscription includes a personalized IQ report and certificate, full access to all tests, brain training games, educational courses and progress tracking. Your results sync across all devices when you log in.'], ['How do I cancel my subscription?', 'Cancel anytime from your profile or at myiq.com/cancellation. Enter your email, verify the six digit code and confirm. You will keep access until the end of your current paid period.'], ['Are my results private?', 'Yes. Your results are visible only to you unless you choose to share them. Rankings are anonymous, and you can delete your account and personal data at any time.'], ['What is a good IQ score?', 'The average IQ score is 100, and most people score between 85 and 115. A score above 100 is above average, while 130 or higher is within approximately the top 2%.'], ['Can you increase your IQ score?', 'Your score can improve with education, regular mental practice, quality sleep and good health. Training can also strengthen skills such as memory, focus and pattern recognition.'], ['Where do I find my results?', 'Your IQ score, full report and certificate are available in your profile. You can download your report as a PDF and your certificate as an image.'], ['Does IQ change with age?', 'IQ is generally stable, but it can change over time. Processing speed may decline with age, while vocabulary and accumulated knowledge can continue to grow.'], ['Do you inherit your IQ from your parents?', 'Genetics play a role, but IQ is not determined by genes alone. Education, health, environment and life experiences also influence cognitive development.']];
          const cols = [faqs.slice(0, 4), faqs.slice(4)];
          return cols.map((col) => `<div>${col.map((f, i) => `<details class="group border-b border-slate-200" ${i === 0 && col === cols[0] ? 'open' : ''}><summary class="flex cursor-pointer list-none items-center justify-between gap-4 py-5 text-hp-body font-semibold text-black-custom">${f[0]}<span class="shrink-0 text-grey-custom transition-transform group-open:rotate-45">${icon('plus', 'h-5 w-5')}</span></summary><p class="pb-5 text-hp-body leading-relaxed text-grey-deep">${f[1]}</p></details>`).join('')}</div>`).join('');
        })()}
      </div>

      <!-- final CTA -->
      <div class="mt-16 grid items-center gap-6 rounded-3xl bg-slate-50 p-8 md:grid-cols-[1.4fr_auto] md:p-12">
        <div>
          <h2 class="text-hp-stat-lg font-semibold text-black-custom">${pt ? 'Pronto para descobrir seu QI?' : 'Ready to find out your IQ?'}</h2>
          <p class="mt-2 text-hp-lede text-grey-deep">${pt ? 'Seu resultado está pronto. Descubra seu QI agora!' : 'Your results are ready. Discover your IQ now!'}</p>
        </div>
        <button onclick="window.scrollTo({top:0,behavior:'smooth'})" class="justify-self-start rounded-full bg-green-custom px-7 py-4 text-hp-body font-semibold text-white transition-colors [@media(hover:hover)]:hover:bg-green-dark md:justify-self-end">${pt ? 'Ver minha pontuação' : 'Get My IQ Score'}</button>
      </div>
    </div>
  </main>

  <!-- footer -->
  <footer class="mt-10 border-t border-slate-100">
    <div class="mx-auto grid max-w-6xl gap-10 px-4 py-14 md:grid-cols-[1.4fr_1fr_1fr_1fr] md:px-6">
      <div>
        ${myiqMark(lang)}
        <div class="mt-4 flex gap-3 text-grey-custom">
          <span class="grid size-9 place-items-center rounded-full border border-slate-200">${icon('instagram', 'h-4 w-4')}</span>
          <span class="grid size-9 place-items-center rounded-full border border-slate-200">${icon('facebook', 'h-4 w-4')}</span>
          <span class="grid size-9 place-items-center rounded-full border border-slate-200">${icon('reddit', 'h-4 w-4')}</span>
        </div>
      </div>
      ${[
        [pt ? 'PRODUTO' : 'PRODUCT', [[pt ? 'Como funciona' : 'How it works', L(lang, '/')], [pt ? 'Cursos' : 'Courses', L(lang, '/')], [pt ? 'Avaliações' : 'Reviews', L(lang, '/')], [pt ? 'Preços' : 'Pricing', L(lang, '/pricing')], ['FAQ', L(lang, '/')]]],
        [pt ? 'SUPORTE' : 'SUPPORT', [[pt ? 'Ajuda' : 'Help', L(lang, '/help')], [pt ? 'Contato' : 'Contact', L(lang, '/help/contact-myiq-support')]]],
        [pt ? 'JURÍDICO' : 'LEGAL', [['Privacy Policy', L(lang, '/privacy')], ['Terms of Service', L(lang, '/terms')], ['Cookie Policy', L(lang, '/cookie')], ['Refund Policy', L(lang, '/terms')]]],
      ].map(([title, links]) => `<div><h4 class="text-hp-caption font-semibold uppercase tracking-wide text-grey-custom">${title}</h4><ul class="mt-3 flex flex-col gap-2.5 text-hp-body text-grey-deep">${links.map(([t, href]) => `<li><a href="${href}" class="no-underline hover:text-black-custom">${t}</a></li>`).join('')}</ul></div>`).join('')}
    </div>
    <div class="border-t border-slate-100"><div class="mx-auto max-w-6xl px-4 py-6 text-[12px] leading-relaxed text-grey-custom md:px-6">Copyright © 2024-2026 myIQ™. Envest Research Inc. 2093 Philadelphia Pike #3129, Claymont, DE 19703, United States.<br/>${pt ? 'O teste tem fins apenas de entretenimento ou educação e não substitui uma avaliação profissional.' : 'The test is for entertainment or educational purposes only and is not a substitute for professional evaluation.'}</div></div>
  </footer>
</div>
<script>
(function(){
  // offer timer
  var t=7*60+12, el=document.getElementById('checkout-timer');
  setInterval(function(){ if(t>0){t--; var m=Math.floor(t/60),s=t%60; if(el) el.textContent=(m<10?'0':'')+m+':'+(s<10?'0':'')+s;} },1000);
  // trial end date = today + 7
  try{ var d=new Date(); d.setDate(d.getDate()+7); var opt={year:'numeric',month:'long',day:'numeric'}; var te=document.getElementById('trial-end'); if(te) te.textContent=d.toLocaleDateString(${pt ? "'pt-BR'" : "'en-US'"},opt); }catch(e){}
  // account email from stored session
  try{ var s=JSON.parse(localStorage.getItem('myiq_user_session')||'{}'); if(s.email){ var ae=document.getElementById('acct-email'); if(ae) ae.textContent=s.email; } }catch(e){}
  // rotating live sales (name + flag + IQ)
  var names=['Kar***','Mar***','Ana***','Luc***','Dav***','Sof***','Ped***','Emi***'];
  var iqs=[132,118,131,109,140,122,115,134];
  var flags=[${['nl', 'us', 'br', 'de', 'fr', 'it', 'jp', 'mx'].map((c) => JSON.stringify(flag(c))).join(',')}];
  var saleMsg=${pt ? "' acabou de comprar o QI!'" : "' just bought their IQ Score!'"};
  function renderSale(i){ var st=document.getElementById('sale-text'), si=document.getElementById('sale-iq'), sf=document.getElementById('sale-flag'); if(st) st.textContent=names[i]+saleMsg; if(si) si.textContent='IQ '+iqs[i]; if(sf) sf.innerHTML=flags[i]; }
  renderSale(0);
  setInterval(function(){ renderSale(Math.floor(Math.random()*names.length)); },3500);
  // checkout is the last page (the member platform is not needed): a payment
  // button just shows a processing state, as the real site would while handing
  // off to the payment processor.
  document.querySelectorAll('.btn-unlock').forEach(function(b){
    var original=b.innerHTML;
    b.addEventListener('click', function(){
      var c=document.getElementById('consent'); if(c&&!c.checked){ c.focus(); return; }
      document.querySelectorAll('.btn-unlock').forEach(function(x){ x.disabled=true; x.style.opacity='.6'; });
      b.innerHTML='<span class="inline-flex items-center gap-2"><svg class="animate-spin" width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-opacity=".25" stroke-width="4"/><path d="M22 12a10 10 0 0 1-10 10" stroke="currentColor" stroke-width="4" stroke-linecap="round"/></svg>'+(${pt ? "'Processando\\u2026'" : "'Processing\\u2026'"})+'</span>';
    });
  });
})();
</script>`;
  return funnelDoc(main, { title: pt ? 'myIQ: Experimente por 7 dias | myIQ' : 'myIQ: Try for 7 Days | myIQ', lang });
}

function emailPage(lang) {
  const pt = lang === 'pt';
  const main = `
<div class="flex min-h-dvh flex-col">
  <header class="border-b border-slate-100"><div class="mx-auto flex h-14 max-w-6xl items-center px-4 md:px-6">${myiqMark(lang)}</div></header>
  <main class="grid flex-1 place-items-center px-4 py-10">
    <div class="w-full max-w-md text-center">
      <div class="mx-auto mb-5 grid size-14 place-items-center rounded-full bg-light-blue text-blue-custom">${icon('mail', 'h-7 w-7')}</div>
      <h1 class="text-hp-stat-lg font-semibold text-black-custom">${pt ? 'Para onde enviamos seu resultado?' : 'Where should we send your results?'}</h1>
      <p class="mt-3 text-hp-lede text-grey-deep">${pt ? 'Seu relatório de QI e o certificado vão para este e-mail.' : 'Your IQ report and certificate will be sent to this email.'}</p>
      <input id="email-input" type="email" inputmode="email" autocomplete="email" placeholder="you@email.com" class="mt-6 w-full rounded-xl border border-slate-300 px-4 py-3.5 text-hp-body text-black-custom outline-none transition-colors focus:border-green-custom"/>
      <button id="email-continue" class="mt-4 w-full rounded-full bg-green-custom px-6 py-4 text-hp-body font-semibold text-white transition-colors [@media(hover:hover)]:hover:bg-green-dark">${pt ? 'Continuar' : 'Continue'}</button>
      <p class="mt-4 flex items-center justify-center gap-1.5 text-hp-caption text-grey-custom">${icon('lock', 'h-4 w-4')} ${pt ? 'Nunca compartilhamos seu e-mail.' : 'We never share your email.'}</p>
    </div>
  </main>
</div>
<script>
(function(){
  var next=${JSON.stringify(L(lang, '/checkout'))};
  var inp=document.getElementById('email-input'), btn=document.getElementById('email-continue');
  try{ var s=JSON.parse(localStorage.getItem('myiq_user_session')||'{}'); if(s.email) inp.value=s.email; }catch(e){}
  function go(){ var v=(inp.value||'').trim(); if(v.indexOf('@')<1||v.indexOf('.')<0){ inp.focus(); inp.style.borderColor='#ef4444'; return; }
    try{ var s=JSON.parse(localStorage.getItem('myiq_user_session')||'{}'); s.email=v; localStorage.setItem('myiq_user_session', JSON.stringify(s)); }catch(e){}
    location.href=next; }
  btn.addEventListener('click', go);
  inp.addEventListener('keydown', function(e){ if(e.key==='Enter') go(); });
  inp.focus();
})();
</script>`;
  return funnelDoc(main, { title: pt ? 'Seu e-mail | myIQ' : 'Your email | myIQ', lang });
}

function dashboardPage(lang) {
  const pt = lang === 'pt';
  const domains = pt
    ? [['fluid', 'Raciocínio fluido'], ['visual', 'Processamento visual'], ['memory', 'Memória de trabalho'], ['pattern', 'Reconhecimento de padrões'], ['logic', 'Lógica']]
    : [['fluid', 'Fluid reasoning'], ['visual', 'Visual processing'], ['memory', 'Working memory'], ['pattern', 'Pattern recognition'], ['logic', 'Logic']];
  const main = `
<div id="dashboard-view" class="flex min-h-dvh flex-col">
  <header class="border-b border-slate-100"><div class="mx-auto flex h-14 max-w-7xl items-center justify-between px-4 md:px-6">${myiqMark(lang)}<a href="${L(lang, '/cancellation/auth')}" class="text-hp-caption text-grey-deep no-underline hover:text-black-custom">${pt ? 'Assinatura' : 'Subscription'}</a></div></header>
  <main class="flex-1">
    <div class="mx-auto w-full max-w-5xl px-4 py-10 md:px-6">
      <h1 class="text-hp-stat-lg text-black-custom">${pt ? 'Relatório oficial de inteligência' : 'Official intelligence report'}</h1>
      <div class="mt-6 grid gap-6 lg:grid-cols-[1fr_1.3fr]">
        <div class="rounded-3xl border border-slate-200 bg-light-blue p-8 text-center">
          <div class="text-hp-body text-grey-deep">${pt ? 'Sua pontuação de QI' : 'Your IQ score'}</div>
          <div id="report-main-score" class="my-1 text-hp-hero-lg font-extrabold text-black-custom">128</div>
          <div id="report-classification" class="inline-block rounded-full bg-green-custom/15 px-4 py-1.5 text-hp-caption font-semibold text-green-dark">${pt ? 'Inteligência superior' : 'Superior intelligence'}</div>
          <div class="mt-6 grid grid-cols-2 gap-3">
            <div class="rounded-xl bg-white p-4"><div class="text-[11px] text-grey-deep">${pt ? 'Percentil' : 'Percentile'}</div><div id="report-percentile" class="text-hp-h3 font-bold text-black-custom">96.8%</div></div>
            <div class="rounded-xl bg-white p-4"><div class="text-[11px] text-grey-deep">${pt ? 'Acertos' : 'Accuracy'}</div><div id="report-accuracy" class="text-hp-h3 font-bold text-black-custom">—</div></div>
          </div>
        </div>
        <div class="rounded-3xl border border-slate-200 bg-white p-8">
          <h3 class="text-hp-h3 font-bold text-black-custom">${pt ? 'Perfil cognitivo' : 'Cognitive profile'}</h3>
          <div class="mt-5 flex flex-col gap-5">
            ${domains.map(([id, label]) => `<div><div class="flex justify-between text-hp-body"><span class="text-grey-deep">${label}</span><span id="val-${id}" class="font-semibold text-black-custom">—</span></div><div class="mt-1 h-2.5 rounded-full bg-slate-100"><div id="bar-${id}" class="h-2.5 rounded-full bg-blue-custom transition-all" style="width:0%"></div></div></div>`).join('')}
          </div>
        </div>
      </div>

      <div class="mt-8 rounded-3xl border border-slate-200 bg-white p-8">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <h3 class="text-hp-h3 font-bold text-black-custom">${pt ? 'Certificado de avaliação' : 'Certificate of assessment'}</h3>
          <button id="btn-print-certificate" class="rounded-full bg-black-custom px-5 py-2.5 text-hp-caption font-semibold text-white">${pt ? 'Imprimir / Salvar PDF' : 'Print / Save PDF'}</button>
        </div>
        <input id="cert-name-input" placeholder="${pt ? 'Digite seu nome completo' : 'Type your full name'}" class="mt-4 w-full max-w-sm rounded-xl border border-slate-300 px-4 py-3 text-hp-body outline-none focus:border-green-custom"/>
        <div id="certificate-print-area" class="mt-6"><div class="certificate-frame mx-auto max-w-2xl rounded-2xl p-10 text-center">
          <div class="text-hp-caption font-semibold uppercase tracking-widest text-amber-700">General Intelligence Quotient</div>
          <div class="mt-1 font-serif text-hp-h2 font-bold text-black-custom">${pt ? 'Certificado' : 'Certificate'}</div>
          <div class="mt-4 text-hp-caption text-grey-deep">${pt ? 'concedido a' : 'awarded to'}</div>
          <div id="cert-display-name" class="mt-1 font-serif text-hp-h2 font-bold text-black-custom">John Doe</div>
          <div id="cert-display-score" class="my-2 text-hp-hero-lg font-extrabold text-blue-custom">128</div>
          <div class="text-hp-caption text-grey-deep"><span id="cert-display-date">—</span> · ID <span id="cert-display-code">IQ-000000</span></div>
        </div></div>
      </div>
    </div>
  </main>
</div>`;
  return funnelDoc(main, { title: pt ? 'Seu relatório | myIQ' : 'Your report | myIQ', lang, scripts: ['/js/dashboard.js'] });
}

/* ----------------------------------------------------------------------------
 * Shared layout
 * -------------------------------------------------------------------------- */
const MODULES = [
  'translations.js',
  'questions-data.js',
  'svg-generator.js',
  'quiz-engine.js',
  'checkout.js',
  'dashboard.js',
  'cancellation.js',
];

function layout(body, { title, lang, bodyScript } = {}) {
  const l = lang === 'pt' ? 'pt-BR' : 'en';
  return `<!doctype html>
<html lang="${l}" class="scroll-smooth">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>${title || 'IQ Test Online | myIQ'}</title>
<meta name="description" content="myIQ offers a comprehensive online IQ test to measure cognitive abilities accurately. 40 questions, 20 minutes, instant certified report."/>
<link rel="icon" href="/favicon.svg"/>
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config = {
  theme: { extend: {
    fontFamily: { sans: ['Inter','system-ui','sans-serif'], mono: ['"Source Code Pro"','monospace'] },
    colors: {
      'green-custom':'#00b67a','green-dark':'#0b635c','blue-custom':'#006fee',
      'blue-highlight':'#005bc4','light-blue':'#f0f6fe','ink':'#111827',
    },
    maxWidth: { 'content':'1160px' },
  } }
};
</script>
<link rel="stylesheet" href="/css/custom.css"/>
</head>
<body class="bg-white text-ink antialiased">
${body}
${MODULES.map((m) => `<script src="/js/${m}"></script>`).join('\n')}
<script>
/* ---- client i18n + locale-aware links ---- */
(function(){
  function apply(){
    if (typeof window.t !== 'function') return;
    document.querySelectorAll('[data-i18n]').forEach(function(el){
      var v = window.t(el.getAttribute('data-i18n'));
      if (v) el.textContent = v;
    });
    document.querySelectorAll('[data-i18n-html]').forEach(function(el){
      var v = window.t(el.getAttribute('data-i18n-html'));
      if (v) el.innerHTML = v;
    });
  }
  apply();
  document.addEventListener('DOMContentLoaded', apply);
})();
</script>
${bodyScript || ''}
</body>
</html>`;
}

/* locale helpers used inside templates */
function L(lang, p) {
  if (p === '/') return lang === 'pt' ? '/pt-BR' : '/';
  return (lang === 'pt' ? '/pt-BR' : '') + p;
}
function altHref(lang, currentPath) {
  // link to the other language version of the current page
  if (lang === 'pt') return currentPath.replace(/^\/pt-BR/, '') || '/';
  return '/pt-BR' + (currentPath === '/' ? '' : currentPath);
}

/* ----------------------------------------------------------------------------
 * Reusable chrome
 * -------------------------------------------------------------------------- */
function logo(lang) {
  return `<a href="${L(lang, '/')}" class="flex items-center gap-2 no-underline">
    <span class="grid h-8 w-8 place-items-center rounded-lg bg-blue-custom text-white font-black text-lg">i</span>
    <span class="text-xl font-extrabold tracking-tight text-ink">my<span class="text-blue-custom">IQ</span></span>
  </a>`;
}

function langSwitch(lang, currentPath) {
  const other = altHref(lang, currentPath);
  const label = lang === 'pt' ? 'EN' : 'PT';
  return `<a href="${other}" class="rounded-full border border-slate-200 px-2.5 py-1.5 text-xs font-semibold text-slate-600 no-underline hover:border-blue-custom hover:text-blue-custom">${label}</a>`;
}

function header(lang, currentPath) {
  return `<header class="sticky top-0 z-40 border-b border-slate-100 bg-white/90 backdrop-blur">
  <div class="mx-auto flex h-16 max-w-content items-center justify-between gap-3 px-4 sm:px-6">
    ${logo(lang)}
    <nav class="hidden items-center gap-8 text-sm font-medium text-slate-600 md:flex">
      <a href="${L(lang, '/')}#how" class="no-underline hover:text-ink" data-i18n="nav_how_it_works">How it works</a>
      <a href="${L(lang, '/')}#reviews" class="no-underline hover:text-ink" data-i18n="nav_reviews">Reviews</a>
      <a href="${L(lang, '/pricing')}" class="no-underline hover:text-ink" data-i18n="nav_pricing">Pricing</a>
    </nav>
    <div class="flex items-center gap-2">
      ${langSwitch(lang, currentPath)}
      <a href="${L(lang, '/sign-in')}" class="hidden rounded-full px-3 py-2 text-sm font-medium text-slate-600 no-underline hover:text-ink sm:block" data-i18n="nav_login">Log in</a>
      <a href="${L(lang, '/quiz')}" class="rounded-full bg-ink px-4 py-2 text-sm font-semibold text-white no-underline shadow-sm transition hover:bg-black" data-i18n="nav_start_test">Start Test</a>
    </div>
  </div>
</header>`;
}

function footer(lang) {
  return `<footer class="border-t border-slate-100 bg-slate-50">
  <div class="mx-auto max-w-content px-4 py-14 sm:px-6">
    <div class="grid gap-10 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
      <div>
        ${logo(lang)}
        <p class="mt-4 max-w-xs text-sm text-slate-500">Know your IQ. Know yourself better. A 40-question assessment based on Raven's Progressive Matrices.</p>
      </div>
      <div>
        <h4 class="mb-3 text-sm font-semibold text-ink">Product</h4>
        <ul class="space-y-2 text-sm text-slate-500">
          <li><a class="no-underline hover:text-ink" href="${L(lang, '/quiz')}">IQ Test</a></li>
          <li><a class="no-underline hover:text-ink" href="${L(lang, '/pricing')}">Pricing</a></li>
          <li><a class="no-underline hover:text-ink" href="${L(lang, '/')}#courses">Courses</a></li>
          <li><a class="no-underline hover:text-ink" href="${L(lang, '/')}#faq">FAQ</a></li>
        </ul>
      </div>
      <div>
        <h4 class="mb-3 text-sm font-semibold text-ink">Support</h4>
        <ul class="space-y-2 text-sm text-slate-500">
          <li><a class="no-underline hover:text-ink" href="${L(lang, '/help')}">Help</a></li>
          <li><a class="no-underline hover:text-ink" href="${L(lang, '/cancellation')}">How to cancel</a></li>
          <li><a class="no-underline hover:text-ink" href="${L(lang, '/contact')}">Contact</a></li>
        </ul>
      </div>
      <div>
        <h4 class="mb-3 text-sm font-semibold text-ink">Legal</h4>
        <ul class="space-y-2 text-sm text-slate-500">
          <li><a class="no-underline hover:text-ink" href="${L(lang, '/privacy')}">Privacy Policy</a></li>
          <li><a class="no-underline hover:text-ink" href="${L(lang, '/terms')}">Terms of Service</a></li>
          <li><a class="no-underline hover:text-ink" href="${L(lang, '/cookie')}">Cookie Policy</a></li>
          <li><a class="no-underline hover:text-ink" href="${L(lang, '/terms')}#refund">Refund Policy</a></li>
        </ul>
      </div>
    </div>
    <div class="mt-12 border-t border-slate-200 pt-6 text-xs leading-relaxed text-slate-400">
      <p data-i18n="footer_copy">Copyright © 2024-2026 myIQ™. Envest Research Inc. 2093 Philadelphia Pike #3129, Claymont, DE 19703, United States.</p>
      <p class="mt-2">The test is for entertainment or educational purposes only and is not a substitute for professional evaluation.</p>
    </div>
  </div>
</footer>`;
}

/* small helpers */
const star = `<svg viewBox="0 0 24 24" class="h-4 w-4 fill-current"><path d="M12 2l2.9 6.3 6.9.6-5.2 4.5 1.6 6.7L12 17.3 5.8 20.6l1.6-6.7L2.2 8.9l6.9-.6z"/></svg>`;
function stars(n = 5, cls = 'text-green-custom') {
  return `<div class="flex ${cls}">${Array.from({ length: n }).map(() => star).join('')}</div>`;
}

/* ----------------------------------------------------------------------------
 * HOME
 * -------------------------------------------------------------------------- */
function homeBody(lang) {
  const press = ['Forbes', 'TechCrunch', 'The Guardian', 'Business Insider', 'WIRED', 'Mashable', 'The Verge', 'Psychology Today'];
  const reviews = [
    ['Coincidence? I don’t think so!', 'Your test is accurate — the IQ I got matches my real one within 3%.', 'Mirekiq', 'Czechia'],
    ['Fun and interesting', 'Fun, quick and easy. Although I really wonder how accurate this is.', 'Mbdaking', 'United States'],
    ['Short but challenging', 'It was short but challenging. Really enjoyed it.', 'E.B.', 'Greece'],
    ['Easy check of cognitive ability', 'Questions were a variety of styles, clear and challenging.', 'Col Done', 'Australia'],
    ['Fast results', 'A quick, simple test that helps me keep an eye on my brain health.', 'D Horton', 'United Kingdom'],
    ['Nice experience to undergo', 'I didn’t dislike anything. Nice, quite precise and handy.', 'King Piper', 'Nigeria'],
    ['Smart questions', 'Very smart questions and generally quality work.', 'Stella', 'Cyprus'],
    ['Stimulating variety', 'I found the variety stimulating and it kept my interest from lagging.', 'Cathy', 'New Zealand'],
  ];
  const figures = [['Abraham Lincoln', 123], ['Napoleon Bonaparte', 118], ['George Washington', 113]];
  const faqs = [
    ['What does my subscription include?', 'Your subscription includes a personalized IQ report and certificate, full access to all tests, brain training games, educational courses and progress tracking. Your results sync across all devices when you log in.'],
    ['How do I cancel my subscription?', 'Cancel anytime from your profile or at myiq.com/cancellation. Enter your email, verify the six digit code and confirm. You will keep access until the end of your current paid period.'],
    ['Are my results private?', 'Yes. Your results are visible only to you unless you choose to share them. Rankings are anonymous, and you can delete your account and personal data at any time.'],
    ['What is a good IQ score?', 'The average IQ score is 100, and most people score between 85 and 115. A score above 100 is above average, while 130 or higher is within approximately the top 2%.'],
    ['Can you increase your IQ score?', 'Your score can improve with education, regular mental practice, quality sleep and good health. Training can also strengthen skills such as memory, focus and pattern recognition.'],
    ['Where do I find my results?', 'Your IQ score, full report and certificate are available in your profile. You can download your report as a PDF and your certificate as an image.'],
    ['Does IQ change with age?', 'IQ is generally stable, but it can change over time. Processing speed may decline with age, while vocabulary and accumulated knowledge can continue to grow.'],
    ['Do you inherit your IQ from your parents?', 'Genetics play a role, but IQ is not determined by genes alone. Education, health, environment and life experiences also influence cognitive development.'],
  ];

  return `
${header(lang, L(lang, '/'))}

<!-- HERO -->
<section class="relative overflow-hidden">
  <div class="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(60%_60%_at_50%_0%,#eef5ff_0%,#ffffff_70%)]"></div>
  <div class="mx-auto grid max-w-content items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-[1.05fr_1fr] lg:py-24">
    <div>
      <div class="mb-5 inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-600">
        ${stars(5)}<span data-i18n="hero_reviews">Rated 4.1 / 5 from 137,117 reviews on Trustpilot</span>
      </div>
      <h1 class="text-4xl font-extrabold leading-[1.08] tracking-tight text-ink sm:text-5xl lg:text-6xl" data-i18n="hero_title">Know your IQ. Know yourself better.</h1>
      <p class="mt-5 max-w-xl text-lg text-slate-600" data-i18n="hero_subtitle">Complete 40 questions on patterns, numbers, logic, and memory to get your IQ score and cognitive profile.</p>
      <div class="mt-8 flex flex-wrap items-center gap-4">
        <a href="${L(lang, '/quiz')}" class="rounded-full bg-blue-custom px-7 py-4 text-base font-semibold text-white no-underline shadow-lg shadow-blue-custom/25 transition hover:bg-blue-highlight" data-i18n="hero_start_btn">Start My IQ Test</a>
        <div class="text-sm text-slate-500">40 questions · 20 min · <span class="font-semibold text-ink">Precise results</span></div>
      </div>
    </div>

    <!-- result preview card -->
    <div class="animate-hero-float rounded-3xl border border-slate-100 bg-white p-6 shadow-rd-card">
      <div class="flex items-center justify-between">
        <span class="text-sm font-medium text-slate-500" data-i18n="your_result">Your result</span>
        <span class="rounded-full bg-light-blue px-2.5 py-1 text-xs font-semibold text-blue-custom">40 questions · 20 min</span>
      </div>
      <div class="mt-4 flex items-end gap-4">
        <div>
          <div class="text-6xl font-extrabold tracking-tight text-ink">120</div>
          <div class="text-sm text-slate-500" data-i18n="iq_score">IQ score</div>
        </div>
        <div class="ml-auto text-right">
          <div class="text-3xl font-bold text-green-custom">91st</div>
          <div class="text-xs text-slate-500" data-i18n="of_all_test_takers">of all test takers</div>
        </div>
      </div>
      <div class="mt-6 space-y-3">
        <div class="mb-1 text-xs font-semibold uppercase tracking-wide text-slate-400" data-i18n="cognitive_profile">Cognitive profile</div>
        ${[['fluid_reasoning', 'Fluid reasoning', 72], ['visual_processing', 'Visual processing', 84], ['working_memory', 'Working memory', 90], ['pattern_recognition', 'Pattern recognition', 61]].map(([k, label, v]) => `
        <div>
          <div class="flex justify-between text-sm"><span class="text-slate-600" data-i18n="${k}">${label}</span><span class="font-semibold text-ink">${v}</span></div>
          <div class="mt-1 h-2 rounded-full bg-slate-100"><div class="h-2 rounded-full bg-blue-custom" style="width:${v}%"></div></div>
        </div>`).join('')}
      </div>
    </div>
  </div>
</section>

<!-- PRESS marquee -->
<section class="border-y border-slate-100 bg-white py-8">
  <p class="mb-5 text-center text-xs font-semibold uppercase tracking-widest text-slate-400" data-i18n="featured_on">myIQ has been featured on</p>
  <div class="relative overflow-hidden">
    <div class="animate-scrolling-banner gap-14 px-7">
      ${[...press, ...press].map((p) => `<span class="shrink-0 text-xl font-semibold text-slate-400">${p}</span>`).join('')}
    </div>
  </div>
</section>

<!-- STATS -->
<section class="mx-auto max-w-content px-4 py-16 sm:px-6">
  <h2 class="text-center text-2xl font-bold text-ink sm:text-3xl">Join millions discovering what their minds can do.</h2>
  <div class="mt-10 grid gap-6 sm:grid-cols-3">
    ${[['80M+', 'Test takers worldwide'], ['107', 'Average IQ score today'], ['150+', 'Cognitive training exercises']].map(([n, l]) => `
    <div class="rounded-2xl border border-slate-100 bg-white p-8 text-center shadow-rd-card">
      <div class="text-4xl font-extrabold text-blue-custom">${n}</div>
      <div class="mt-2 text-sm text-slate-500">${l}</div>
    </div>`).join('')}
  </div>
</section>

<!-- HOW IT WORKS -->
<section id="how" class="bg-slate-50 py-20">
  <div class="mx-auto max-w-content px-4 sm:px-6">
    <h2 class="text-center text-3xl font-bold tracking-tight text-ink">Discover your IQ score in three simple steps.</h2>
    <p class="mx-auto mt-3 max-w-2xl text-center text-slate-500">Complete the test, get your results, and understand your strengths.</p>
    <div class="mt-12 grid gap-6 md:grid-cols-3">
      ${[
        ['01', 'Complete the test', 'Answer 40 progressively challenging questions inspired by Raven’s Progressive Matrices in 20 minutes or less.'],
        ['02', 'Get your IQ score', 'See your estimated IQ score, percentile rank, and a detailed breakdown of your answers.'],
        ['03', 'Understand your strengths', 'Explore your cognitive profile, download your certificate, and improve with over 150 training exercises.'],
      ].map(([n, t, d]) => `
      <div class="rounded-2xl border border-slate-100 bg-white p-7 shadow-rd-card">
        <div class="mb-4 grid h-11 w-11 place-items-center rounded-xl bg-light-blue text-sm font-bold text-blue-custom">${n}</div>
        <h3 class="text-lg font-semibold text-ink">${t}</h3>
        <p class="mt-2 text-sm leading-relaxed text-slate-500">${d}</p>
      </div>`).join('')}
    </div>
  </div>
</section>

<!-- SCORE MEANING / curve -->
<section class="mx-auto max-w-content px-4 py-20 sm:px-6">
  <div class="grid items-center gap-12 lg:grid-cols-2">
    <div>
      <h2 class="text-3xl font-bold tracking-tight text-ink">See what your score really means.</h2>
      <p class="mt-3 text-slate-500">Discover where you stand, how you compare, and what your score means.</p>
      <ul class="mt-6 space-y-3 text-sm text-slate-600">
        ${['Your IQ score on the distribution curve', 'Your percentile among other test takers', 'A plain-English explanation of your result', 'A detailed review of all 40 answers'].map((i) => `<li class="flex items-start gap-3"><span class="mt-0.5 text-green-custom">${star}</span>${i}</li>`).join('')}
      </ul>
    </div>
    <div class="rounded-3xl border border-slate-100 bg-white p-8 shadow-rd-card">
      <div class="mb-2 text-sm font-semibold text-slate-500">Your IQ score on the distribution curve</div>
      <svg viewBox="0 0 320 150" class="w-full">
        <defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#006fee" stop-opacity=".25"/><stop offset="1" stop-color="#006fee" stop-opacity="0"/></linearGradient></defs>
        <path d="M10 130 C 80 130, 100 20, 160 20 S 240 130, 310 130" fill="url(#g)" stroke="#006fee" stroke-width="2.5"/>
        <line x1="210" y1="20" x2="210" y2="130" stroke="#00b67a" stroke-width="2" stroke-dasharray="4 4"/>
        <circle cx="210" cy="56" r="5" fill="#00b67a"/>
        <text x="210" y="146" text-anchor="middle" font-size="11" fill="#0b635c" font-weight="700">You</text>
        <text x="30" y="146" font-size="10" fill="#94a3b8">70</text>
        <text x="150" y="146" font-size="10" fill="#94a3b8">100</text>
        <text x="285" y="146" font-size="10" fill="#94a3b8">130</text>
      </svg>
      <div class="mt-4 flex items-center justify-between rounded-xl bg-slate-50 p-4">
        <div><div class="text-xs text-slate-500">Better than</div><div class="text-2xl font-bold text-ink">91%</div></div>
        <div class="text-right"><div class="text-xs text-slate-500">Points above average</div><div class="text-2xl font-bold text-green-custom">+20</div></div>
      </div>
      <p class="mt-3 text-xs text-slate-400">Scores follow a normal distribution: average 100, standard deviation 15.</p>
    </div>
  </div>
</section>

<!-- RANKING + figures -->
<section class="bg-slate-50 py-20">
  <div class="mx-auto grid max-w-content gap-10 px-4 sm:px-6 lg:grid-cols-2">
    <div class="rounded-3xl border border-slate-100 bg-white p-8 shadow-rd-card">
      <h3 class="text-xl font-bold text-ink">Where you stand.</h3>
      <p class="mt-2 text-sm text-slate-500">See how you rank among millions of test takers.</p>
      <div class="mt-6 space-y-4">
        <div class="flex items-center justify-between rounded-xl bg-slate-50 px-4 py-3"><span class="text-sm text-slate-600">Worldwide</span><span class="font-bold text-blue-custom">Top 9%</span></div>
        <div class="flex items-center justify-between rounded-xl bg-slate-50 px-4 py-3"><span class="text-sm text-slate-600">Your country</span><span class="font-bold text-blue-custom">Top 10%</span></div>
      </div>
      <p class="mt-4 text-xs text-slate-400">You scored higher than 91% of myIQ test takers. Based on myIQ test takers, not the general population.</p>
    </div>
    <div class="rounded-3xl border border-slate-100 bg-white p-8 shadow-rd-card">
      <h3 class="text-xl font-bold text-ink">Historical figures with similar scores.</h3>
      <p class="mt-2 text-sm text-slate-500">Thinkers, innovators and leaders whose estimated scores land near yours.</p>
      <div class="mt-6 space-y-3">
        ${figures.map(([n, s]) => `<div class="flex items-center justify-between rounded-xl border border-slate-100 px-4 py-3"><span class="text-sm font-medium text-ink">${n}</span><span class="rounded-full bg-light-blue px-2.5 py-1 text-xs font-bold text-blue-custom">${s}</span></div>`).join('')}
      </div>
      <p class="mt-4 text-xs text-slate-400">Estimated from Cox (1926) — retrospective approximations, not actual measurements.</p>
    </div>
  </div>
</section>

<!-- CERTIFICATE -->
<section class="mx-auto max-w-content px-4 py-20 sm:px-6">
  <div class="grid items-center gap-12 lg:grid-cols-2">
    <div>
      <span class="text-xs font-semibold uppercase tracking-widest text-blue-custom">Verifiable credential</span>
      <h2 class="mt-2 text-3xl font-bold tracking-tight text-ink">Your verified certificate, ready to share.</h2>
      <p class="mt-3 text-slate-500">Download, verify, and share your achievement at any time.</p>
      <ul class="mt-6 space-y-3 text-sm text-slate-600">
        ${['A personalized certificate with your name, score, and completion date', 'A permanent certificate ID and scannable verification code', 'Downloadable certificate image and full PDF report', 'Easy to add to LinkedIn or share online'].map((i) => `<li class="flex items-start gap-3"><span class="mt-0.5 text-green-custom">${star}</span>${i}</li>`).join('')}
      </ul>
    </div>
    <div class="certificate-frame rounded-2xl p-8 text-center">
      <div class="text-xs font-semibold uppercase tracking-widest text-amber-700">General Intelligence Quotient</div>
      <div class="mt-1 font-serif text-2xl font-bold text-ink">Certificate</div>
      <div class="mt-4 text-xs text-slate-500">awarded to</div>
      <div class="mt-1 font-serif text-2xl font-bold text-ink">James Anderson</div>
      <div class="mt-4 text-xs text-slate-500">with the following score</div>
      <div class="my-2 text-5xl font-extrabold text-blue-custom">120</div>
      <div class="text-xs text-slate-500">June 1, 2026 · Certificate ID 728 415</div>
    </div>
  </div>
</section>

<!-- TRAINING + COURSES -->
<section id="courses" class="bg-slate-50 py-20">
  <div class="mx-auto grid max-w-content gap-10 px-4 sm:px-6 lg:grid-cols-2">
    <div class="rounded-3xl border border-slate-100 bg-white p-8 shadow-rd-card">
      <h3 class="text-xl font-bold text-ink">Training built on your results.</h3>
      <p class="mt-2 text-sm text-slate-500">Short exercises for reasoning, memory and processing speed, matched to your cognitive profile.</p>
      <div class="mt-6 space-y-3">
        ${[['Pattern Logic', '4 min'], ['Memory Grid', '3 min'], ['Focus Sprint', 'Processing speed']].map(([n, d]) => `<div class="flex items-center justify-between rounded-xl bg-slate-50 px-4 py-3"><span class="text-sm font-medium text-ink">${n}</span><span class="text-xs text-slate-500">${d}</span></div>`).join('')}
      </div>
      <p class="mt-4 text-xs text-slate-400">3 exercises a day, 10 minutes total. Retakes whenever you want.</p>
    </div>
    <div class="rounded-3xl border border-slate-100 bg-white p-8 shadow-rd-card">
      <h3 class="text-xl font-bold text-ink">Build on your results.</h3>
      <p class="mt-2 text-sm text-slate-500">Explore 17 practical courses designed to strengthen how you think, solve problems, create, and connect. All courses are included with your membership.</p>
      <div class="mt-6 flex gap-6">
        ${[['17', 'courses'], ['499', 'lessons'], ['35+', 'hours']].map(([n, l]) => `<div><div class="text-2xl font-extrabold text-blue-custom">${n}</div><div class="text-xs text-slate-500">${l}</div></div>`).join('')}
      </div>
      <div class="mt-6 space-y-2">
        ${['Emotional Intelligence Mastery · 106 lessons', 'Strategic Problem Solving · 92 lessons', 'Creative Innovation Pathway · 41 lessons'].map((c) => `<div class="rounded-xl border border-slate-100 px-4 py-3 text-sm text-slate-600">${c}</div>`).join('')}
      </div>
    </div>
  </div>
</section>

<!-- REVIEWS -->
<section id="reviews" class="mx-auto max-w-content px-4 py-20 sm:px-6">
  <div class="text-center">
    <h2 class="text-3xl font-bold tracking-tight text-ink">What test takers say.</h2>
    <p class="mt-3 text-slate-500">Verified reviews collected by Trustpilot from people who took the test.</p>
    <div class="mt-5 inline-flex items-center gap-2 rounded-full bg-green-custom/10 px-4 py-2 text-sm font-semibold text-green-dark">${stars(5)} 4.1 / 5 · 137,117 reviews on Trustpilot</div>
  </div>
  <div class="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
    ${reviews.map(([t, b, n, c]) => `
    <div class="rounded-2xl border border-slate-100 bg-white p-6 shadow-rd-card shadow-rd-card-hover">
      ${stars(5)}
      <h4 class="mt-3 font-semibold text-ink">${t}</h4>
      <p class="mt-2 text-sm leading-relaxed text-slate-500">${b}</p>
      <div class="mt-4 text-xs text-slate-400">${n} · ${c}</div>
    </div>`).join('')}
  </div>
</section>

<!-- PRICING -->
<section id="pricing" class="bg-slate-50 py-20">
  <div class="mx-auto max-w-xl px-4 sm:px-6">
    <h2 class="text-center text-3xl font-bold tracking-tight text-ink">Everything you need in one plan.</h2>
    <p class="mt-3 text-center text-slate-500">Start with a 7-day trial and get full access. Cancel anytime.</p>
    <div class="mt-10 overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-rd-card">
      <div class="bg-ink px-8 py-6 text-white">
        <div class="text-sm font-medium text-white/70">Membership</div>
        <div class="mt-1 flex items-end gap-2">
          <span class="text-sm text-white/70">Today</span>
          <span class="text-4xl font-extrabold">$1.00</span>
          <span class="text-sm text-white/70">7-day trial</span>
        </div>
        <div class="mt-1 text-sm text-white/70">Then <span class="font-semibold text-white">$29.99</span> every 28 days</div>
      </div>
      <div class="px-8 py-7">
        <ul class="space-y-3 text-sm text-slate-600">
          ${['Detailed IQ score and results breakdown', 'Complete cognitive profile', 'Additional assessments for deeper personal insights', '17 courses with 35+ hours of lessons', 'Brain training games with 150+ exercises', 'Shareable certificate'].map((i) => `<li class="flex items-start gap-3"><span class="mt-0.5 text-green-custom">${star}</span>${i}</li>`).join('')}
        </ul>
        <a href="${L(lang, '/quiz')}" class="mt-7 block rounded-full bg-blue-custom px-6 py-4 text-center text-base font-semibold text-white no-underline transition hover:bg-blue-highlight" data-i18n="hero_start_btn">Start My IQ Test</a>
        <p class="mt-4 text-xs leading-relaxed text-slate-400">Your $1.00 trial lasts 7 days. Unless you cancel before it ends, your subscription renews automatically at $29.99 every 28 days. You can cancel anytime in Account settings under Manage Subscription, or by emailing help@myiq.com.</p>
      </div>
    </div>
  </div>
</section>

<!-- FAQ -->
<section id="faq" class="mx-auto max-w-3xl px-4 py-20 sm:px-6">
  <h2 class="text-center text-3xl font-bold tracking-tight text-ink">Questions, answered.</h2>
  <div class="mt-10 divide-y divide-slate-100 overflow-hidden rounded-2xl border border-slate-100 bg-white">
    ${faqs.map(([q, a], i) => `
    <details class="group" ${i === 0 ? 'open' : ''}>
      <summary class="flex cursor-pointer list-none items-center justify-between gap-4 px-6 py-5 text-left font-semibold text-ink">
        ${q}
        <span class="text-blue-custom transition group-open:rotate-45">+</span>
      </summary>
      <p class="px-6 pb-5 text-sm leading-relaxed text-slate-500">${a}</p>
    </details>`).join('')}
  </div>
</section>

<!-- FINAL CTA -->
<section class="bg-ink py-20 text-center text-white">
  <div class="mx-auto max-w-content px-4 sm:px-6">
    <h2 class="text-3xl font-bold tracking-tight sm:text-4xl">Ready to find your IQ Score?</h2>
    <p class="mt-3 text-white/70">40 questions. Up to 20 minutes. Your full profile at the end.</p>
    <a href="${L(lang, '/quiz')}" class="mt-8 inline-block rounded-full bg-blue-custom px-8 py-4 text-base font-semibold text-white no-underline transition hover:bg-blue-highlight" data-i18n="hero_start_btn">Start My IQ Test</a>
    <p class="mt-4 text-xs text-white/50">Auto-renewing subscription. Cancel anytime.</p>
  </div>
</section>

${footer(lang)}`;
}

/* ----------------------------------------------------------------------------
 * QUIZ
 * -------------------------------------------------------------------------- */
function quizBody(lang) {
  return `
<div id="quiz-app" class="min-h-screen bg-slate-50">
  <!-- quiz top bar -->
  <div class="sticky top-0 z-30 border-b border-slate-100 bg-white">
    <div class="mx-auto flex max-w-3xl items-center justify-between gap-4 px-4 py-4 sm:px-6">
      ${logo(lang)}
      <div class="flex items-center gap-4">
        <div class="hidden text-sm text-slate-500 sm:block"><span data-i18n="quiz_time_left">Time Left</span>: <span id="quiz-timer-display" class="font-mono font-semibold text-ink">20:00</span></div>
        <a href="${L(lang, '/')}" class="rounded-full border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-500 no-underline hover:text-ink" data-i18n="quiz_quit">Quit Test</a>
      </div>
    </div>
    <div class="h-1.5 w-full bg-slate-100"><div id="quiz-progress-bar" class="h-1.5 bg-blue-custom transition-all" style="width:2.5%"></div></div>
  </div>

  <div class="mx-auto max-w-3xl px-4 py-8 sm:px-6">
    <div class="mb-6 flex items-center justify-between text-sm">
      <div class="font-semibold text-ink"><span data-i18n="quiz_question">Question</span> <span id="quiz-current-num">1</span> <span data-i18n="quiz_of">of</span> 40</div>
      <div class="font-mono text-slate-400"><span id="quiz-progress-percent">2%</span></div>
    </div>

    <div class="rounded-3xl border border-slate-100 bg-white p-6 shadow-rd-card sm:p-8">
      <p class="mb-5 text-center text-sm font-medium text-slate-600" data-i18n="quiz_select_option">Select the shape that logically fits in the missing spot (?):</p>
      <div id="question-graphic-container" class="mx-auto max-w-[420px]"></div>
    </div>

    <div class="mt-8">
      <div id="options-grid-container" class="option-grid"></div>
    </div>

    <p class="mt-6 text-center text-xs text-slate-400">Tip: press 1–6 or A–F on your keyboard to answer.</p>
  </div>

  <!-- milestone modal -->
  <div id="milestone-modal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/40 p-4">
    <div class="w-full max-w-sm rounded-2xl bg-white p-7 text-center shadow-2xl">
      <div class="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-full bg-green-custom/10 text-green-custom">${star}</div>
      <h3 id="milestone-title" class="text-xl font-bold text-ink"></h3>
      <p id="milestone-desc" class="mt-2 text-sm text-slate-500"></p>
      <button id="milestone-btn" class="mt-6 w-full rounded-full bg-blue-custom px-6 py-3 text-sm font-semibold text-white" data-i18n="quiz_continue">Continue Assessment</button>
    </div>
  </div>
</div>`;
}

/* ----------------------------------------------------------------------------
 * ANALYZING (calculating)
 * -------------------------------------------------------------------------- */
function analyzingBody(lang) {
  const steps = ['calculating_step1', 'calculating_step2', 'calculating_step3', 'calculating_step4'];
  const script = `<script>
(function(){
  var next = ${JSON.stringify(L(lang, '/checkout'))};
  var items = Array.prototype.slice.call(document.querySelectorAll('[data-step]'));
  var i = 0;
  function tick(){
    if (i < items.length){
      var el = items[i];
      el.querySelector('[data-spin]').classList.add('hidden');
      el.querySelector('[data-check]').classList.remove('hidden');
      el.classList.remove('opacity-40'); el.classList.add('opacity-100');
      i++;
      if (i < items.length){ items[i].classList.remove('opacity-40'); }
      setTimeout(tick, 1100);
    } else {
      setTimeout(function(){ window.location.href = next; }, 700);
    }
  }
  setTimeout(tick, 600);
})();
</script>`;
  return {
    body: `
<div class="grid min-h-screen place-items-center bg-slate-50 px-4">
  <div class="w-full max-w-md rounded-3xl border border-slate-100 bg-white p-8 text-center shadow-rd-card">
    <div class="mx-auto mb-5 h-14 w-14 animate-spinner-ease-spin rounded-full border-4 border-slate-200 border-t-blue-custom"></div>
    <h1 class="text-xl font-bold text-ink" data-i18n="calculating_title">Calculating Your Cognitive Profile...</h1>
    <div class="mt-7 space-y-4 text-left">
      ${steps.map((k, idx) => `
      <div data-step class="flex items-center gap-3 ${idx === 0 ? 'opacity-100' : 'opacity-40'} transition-opacity">
        <span data-spin class="h-5 w-5 shrink-0 animate-spinner-ease-spin rounded-full border-2 border-slate-200 border-t-blue-custom"></span>
        <span data-check class="hidden grid h-5 w-5 shrink-0 place-items-center rounded-full bg-green-custom text-[11px] text-white">✓</span>
        <span class="text-sm text-slate-600" data-i18n="${k}"></span>
      </div>`).join('')}
    </div>
  </div>
</div>`,
    script,
  };
}

/* ----------------------------------------------------------------------------
 * CHECKOUT (paywall)
 * -------------------------------------------------------------------------- */
function checkoutBody(lang) {
  const field = (id, label, ph, type = 'text') =>
    `<label class="block"><span class="mb-1 block text-xs font-medium text-slate-500">${label}</span><input id="${id}" type="${type}" placeholder="${ph}" class="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-blue-custom"/></label>`;
  return `
<div id="checkout-view" class="min-h-screen bg-slate-50">
  <div class="border-b border-slate-100 bg-white"><div class="mx-auto flex max-w-content items-center justify-between px-4 py-4 sm:px-6">${logo(lang)}<div class="flex items-center gap-1 text-xs font-medium text-green-dark"><span>🔒</span> Secure checkout</div></div></div>

  <!-- offer banner -->
  <div class="bg-ink py-2.5 text-center text-sm font-semibold text-white">
    <span data-i18n="checkout_banner">Special Offer: 85% OFF — Offer ends in</span>
    <span id="checkout-timer" class="ml-1 font-mono text-green-custom">14:59</span>
  </div>

  <div class="mx-auto grid max-w-content gap-8 px-4 py-10 sm:px-6 lg:grid-cols-[1fr_1.1fr]">
    <!-- left: score teaser -->
    <div>
      <div class="rounded-3xl border border-slate-100 bg-white p-8 text-center shadow-rd-card">
        <h1 class="text-2xl font-bold text-ink" data-i18n="checkout_title">Congratulations! Your Score Is Ready!</h1>
        <div class="relative mt-6">
          <div class="text-6xl font-extrabold tracking-tight text-ink blur-md select-none" id="checkout-preview-score">IQ 128</div>
          <div class="absolute inset-0 grid place-items-center"><span class="rounded-full bg-ink/80 px-4 py-1.5 text-xs font-semibold text-white">Unlock to reveal</span></div>
        </div>
        <ul class="mt-7 space-y-3 text-left text-sm text-slate-600">
          ${['Your full IQ score & percentile rank', '5 cognitive domain breakdowns', 'Official verified PDF certificate', '150+ brain training exercises & 17 courses'].map((i) => `<li class="flex items-start gap-3"><span class="mt-0.5 text-green-custom">${star}</span>${i}</li>`).join('')}
        </ul>
      </div>
      <div class="mt-5 flex items-center justify-center gap-2 text-xs text-slate-400">${stars(5)} 4.1/5 · 137,117 Trustpilot reviews</div>
    </div>

    <!-- right: payment -->
    <div class="rounded-3xl border border-slate-100 bg-white p-7 shadow-rd-card">
      <div class="rounded-2xl bg-light-blue p-4 text-sm text-blue-highlight" data-i18n="checkout_trial_text">7-day full access trial for just $0.99. Then $29.99 every 30 days. Cancel anytime with 1 click.</div>

      <div class="mt-5 grid grid-cols-3 gap-2">
        <button id="tab-card" class="rounded-xl border border-blue-custom bg-blue-50 px-3 py-2.5 text-xs font-semibold text-blue-custom" data-i18n="checkout_card_option">Credit Card</button>
        <button id="tab-pix" class="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-xs text-slate-600" data-i18n="checkout_pix_option">PIX (Instant QR Code)</button>
        <button id="tab-paypal" class="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-xs text-slate-600" data-i18n="checkout_paypal_option">PayPal</button>
      </div>

      <div class="mt-5">
        ${field('checkout-email', '<span data-i18n="checkout_email_label">Your Email Address (where report is sent)</span>', 'you@example.com', 'email')}
      </div>

      <div id="payment-form-card" class="mt-4 space-y-4">
        ${field('card-number', '<span data-i18n="checkout_card_num">Card Number</span>', '4242 4242 4242 4242')}
        <div class="grid grid-cols-2 gap-4">
          ${field('card-exp', 'MM/YY', 'MM/YY')}
          ${field('card-cvc', 'CVC', '123')}
        </div>
        ${field('card-name', '<span data-i18n="checkout_name">Name on Card</span>', 'John Doe')}
        <button class="btn-submit-order w-full rounded-full bg-blue-custom px-6 py-4 text-base font-semibold text-white transition hover:bg-blue-highlight" data-i18n="checkout_btn">Unlock My Verified Results ($0.99)</button>
      </div>

      <div id="payment-form-pix" class="mt-4 hidden text-center">
        <div class="mx-auto grid h-44 w-44 place-items-center rounded-2xl border-2 border-dashed border-slate-200 text-xs text-slate-400">QR Code</div>
        <button class="btn-submit-order mt-5 w-full rounded-full bg-green-custom px-6 py-4 text-base font-semibold text-white">Pay with PIX</button>
      </div>

      <div id="payment-form-paypal" class="mt-4 hidden text-center">
        <button class="btn-submit-order w-full rounded-full bg-[#ffc439] px-6 py-4 text-base font-bold text-[#003087]">Pay with PayPal</button>
      </div>

      <p class="mt-4 text-center text-xs text-slate-400">🔒 256-bit SSL encrypted. Cancel anytime from your account.</p>
    </div>
  </div>
</div>`;
}

/* ----------------------------------------------------------------------------
 * DASHBOARD (member report)
 * -------------------------------------------------------------------------- */
function dashboardBody(lang) {
  const domain = (id, label) => `
    <div>
      <div class="flex justify-between text-sm"><span class="text-slate-600">${label}</span><span id="val-${id}" class="font-semibold text-ink">—</span></div>
      <div class="mt-1 h-2.5 rounded-full bg-slate-100"><div id="bar-${id}" class="h-2.5 rounded-full bg-blue-custom transition-all" style="width:0%"></div></div>
    </div>`;
  return `
<div id="dashboard-view" class="min-h-screen bg-slate-50">
  ${header(lang, L(lang, '/dashboard'))}
  <div class="mx-auto max-w-content px-4 py-10 sm:px-6">
    <h1 class="text-2xl font-bold text-ink" data-i18n="dashboard_title">Official Cognitive & Intelligence Report</h1>

    <div class="mt-6 grid gap-6 lg:grid-cols-[1fr_1.3fr]">
      <!-- score -->
      <div class="rounded-3xl border border-slate-100 bg-white p-8 text-center shadow-rd-card">
        <div class="text-sm font-medium text-slate-500" data-i18n="dashboard_score_label">Your IQ Score</div>
        <div id="report-main-score" class="my-2 text-7xl font-extrabold tracking-tight text-ink">128</div>
        <div id="report-classification" class="inline-block rounded-full bg-green-custom/10 px-4 py-1.5 text-sm font-semibold text-green-dark">Superior Intelligence</div>
        <div class="mt-6 grid grid-cols-2 gap-4 text-center">
          <div class="rounded-xl bg-slate-50 p-4"><div class="text-xs text-slate-500" data-i18n="percentile">Percentile</div><div id="report-percentile" class="text-xl font-bold text-ink">96.8%</div></div>
          <div class="rounded-xl bg-slate-50 p-4"><div class="text-xs text-slate-500">Accuracy</div><div id="report-accuracy" class="text-xl font-bold text-ink">34/40</div></div>
        </div>
      </div>

      <!-- domains -->
      <div class="rounded-3xl border border-slate-100 bg-white p-8 shadow-rd-card">
        <h3 class="text-lg font-bold text-ink" data-i18n="cognitive_profile">Cognitive profile</h3>
        <div class="mt-5 space-y-5">
          ${domain('fluid', 'Fluid reasoning')}
          ${domain('visual', 'Visual processing')}
          ${domain('memory', 'Working memory')}
          ${domain('pattern', 'Pattern recognition')}
          ${domain('logic', 'Logic')}
        </div>
      </div>
    </div>

    <!-- certificate -->
    <div class="mt-8 rounded-3xl border border-slate-100 bg-white p-8 shadow-rd-card">
      <div class="flex flex-wrap items-center justify-between gap-4">
        <h3 class="text-lg font-bold text-ink" data-i18n="dashboard_cert_title">Certificate of Intelligence Assessment</h3>
        <button id="btn-print-certificate" class="rounded-full bg-ink px-5 py-2.5 text-sm font-semibold text-white" data-i18n="dashboard_cert_btn">Print / Save PDF Certificate</button>
      </div>
      <div class="mt-4 max-w-sm">
        <input id="cert-name-input" placeholder="Type your full name" class="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-blue-custom"/>
      </div>
      <div id="certificate-print-area" class="mt-6">
        <div class="certificate-frame mx-auto max-w-2xl rounded-2xl p-10 text-center">
          <div class="text-xs font-semibold uppercase tracking-widest text-amber-700">General Intelligence Quotient</div>
          <div class="mt-1 font-serif text-3xl font-bold text-ink">Certificate</div>
          <div class="mt-5 text-sm text-slate-500">awarded to</div>
          <div id="cert-display-name" class="mt-1 font-serif text-3xl font-bold text-ink">John Doe</div>
          <div class="mt-5 text-sm text-slate-500">myIQ Test score</div>
          <div id="cert-display-score" class="my-2 text-5xl font-extrabold text-blue-custom">128</div>
          <div class="mt-4 flex items-center justify-center gap-6 text-xs text-slate-500">
            <span id="cert-display-date">—</span>
            <span>Certificate ID <span id="cert-display-code">IQ-000000</span></span>
          </div>
          <div class="mt-6 text-xs text-slate-400">Director of Assessments · Envest Research Inc.</div>
        </div>
      </div>
    </div>

    <!-- brain game -->
    <div class="mt-8 rounded-3xl border border-slate-100 bg-white p-8 shadow-rd-card">
      <div class="flex flex-wrap items-center justify-between gap-4">
        <h3 class="text-lg font-bold text-ink" data-i18n="dashboard_games_title">Cognitive Training Exercises Included with Your Membership</h3>
        <div class="flex items-center gap-3">
          <span id="brain-game-score" class="text-sm font-semibold text-slate-500">Score: 0</span>
          <button id="start-brain-game" class="rounded-full bg-blue-custom px-5 py-2.5 text-sm font-semibold text-white">Start Memory Drill</button>
        </div>
      </div>
      <p class="mt-2 text-sm text-slate-500">Memory Matrix — memorize the highlighted tiles, then tap them.</p>
      <div id="brain-game-grid" class="mx-auto mt-6 grid max-w-xs grid-cols-3 gap-3"></div>
    </div>

    <div class="mt-8 text-center">
      <a href="${L(lang, '/cancellation')}" class="text-sm text-slate-400 underline">Manage or cancel subscription</a>
    </div>
  </div>
</div>`;
}

/* ----------------------------------------------------------------------------
 * CANCELLATION
 * -------------------------------------------------------------------------- */
function cancellationBody(lang) {
  return `
<div id="cancellation-portal-view" class="min-h-screen bg-slate-50">
  ${header(lang, L(lang, '/cancellation'))}
  <div class="mx-auto max-w-md px-4 py-16 sm:px-6">

    <div id="cancel-auth-section" class="rounded-3xl border border-slate-100 bg-white p-8 shadow-rd-card">
      <h1 class="text-xl font-bold text-ink" data-i18n="cancellation_title">Manage & Cancel Subscription</h1>
      <p class="mt-2 text-sm text-slate-500" data-i18n="cancellation_subtitle">Enter the email address associated with your myIQ subscription</p>
      <input id="cancel-email-input" type="email" placeholder="you@example.com" class="mt-5 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-blue-custom"/>
      <button id="btn-lookup-subscription" class="mt-4 w-full rounded-full bg-ink px-6 py-3.5 text-sm font-semibold text-white" data-i18n="cancellation_search_btn">Find My Subscription</button>
    </div>

    <div id="cancel-manage-section" class="hidden rounded-3xl border border-slate-100 bg-white p-8 shadow-rd-card">
      <div class="inline-flex items-center gap-2 rounded-full bg-green-custom/10 px-3 py-1 text-xs font-semibold text-green-dark"><span>●</span> <span data-i18n="cancellation_active_found">Active Subscription Found</span></div>
      <div class="mt-5 space-y-3 rounded-2xl bg-slate-50 p-5 text-sm">
        <div class="flex justify-between"><span class="text-slate-500">Plan</span><span class="font-semibold text-ink" data-i18n="cancellation_plan_price">$29.99 / 30 days</span></div>
        <div class="flex justify-between"><span class="text-slate-500" data-i18n="cancellation_next_bill">Next Billing Date: 28 days from now</span></div>
      </div>
      <button id="btn-confirm-cancel" class="mt-6 w-full rounded-full border border-red-200 bg-white px-6 py-3.5 text-sm font-semibold text-red-600 hover:bg-red-50" data-i18n="cancellation_cancel_btn">Confirm 1-Click Cancellation</button>
      <button id="btn-keep-discount" class="mt-3 w-full rounded-full bg-green-custom px-6 py-3.5 text-sm font-semibold text-white" data-i18n="cancellation_keep_btn">Keep My 50% Discount ($14.99/mo)</button>
    </div>

    <div id="cancel-success-section" class="hidden rounded-3xl border border-slate-100 bg-white p-8 text-center shadow-rd-card">
      <div class="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-full bg-green-custom/10 text-2xl text-green-custom">✓</div>
      <p class="text-sm text-slate-600" data-i18n="cancellation_success">Your subscription has been successfully cancelled. You will not be charged again.</p>
      <a href="${L(lang, '/')}" class="mt-6 inline-block rounded-full bg-ink px-6 py-3 text-sm font-semibold text-white no-underline">Back to home</a>
    </div>
  </div>
</div>`;
}

/* ----------------------------------------------------------------------------
 * SIGN-IN
 * -------------------------------------------------------------------------- */
function signInBody(lang) {
  return `
${header(lang, L(lang, '/sign-in'))}
<div class="grid min-h-[70vh] place-items-center px-4 py-14">
  <div class="w-full max-w-sm rounded-3xl border border-slate-100 bg-white p-8 shadow-rd-card">
    <h1 class="text-xl font-bold text-ink">Welcome back</h1>
    <p class="mt-1 text-sm text-slate-500">Log in to view your IQ report and certificate.</p>
    <label class="mt-6 block"><span class="mb-1 block text-xs font-medium text-slate-500">Email</span><input type="email" placeholder="you@example.com" class="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-blue-custom"/></label>
    <label class="mt-4 block"><span class="mb-1 block text-xs font-medium text-slate-500">Password</span><input type="password" placeholder="••••••••" class="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-blue-custom"/></label>
    <a href="${L(lang, '/dashboard')}" class="mt-6 block rounded-full bg-ink px-6 py-3.5 text-center text-sm font-semibold text-white no-underline">Log in</a>
    <p class="mt-4 text-center text-xs text-slate-400">No account yet? <a href="${L(lang, '/quiz')}" class="text-blue-custom">Take the test</a></p>
  </div>
</div>
${footer(lang)}`;
}

/* ----------------------------------------------------------------------------
 * Simple content pages (pricing/help/contact/legal)
 * -------------------------------------------------------------------------- */
function pricingBody(lang) {
  return `
${header(lang, L(lang, '/pricing'))}
<section class="mx-auto max-w-xl px-4 py-16 sm:px-6">
  <h1 class="text-center text-3xl font-bold tracking-tight text-ink">Everything you need in one plan.</h1>
  <p class="mt-3 text-center text-slate-500">Start with a 7-day trial and get full access. Cancel anytime.</p>
  <div class="mt-10 overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-rd-card">
    <div class="bg-ink px-8 py-6 text-white">
      <div class="text-sm font-medium text-white/70">Membership</div>
      <div class="mt-1 flex items-end gap-2"><span class="text-sm text-white/70">Today</span><span class="text-4xl font-extrabold">$1.00</span><span class="text-sm text-white/70">7-day trial</span></div>
      <div class="mt-1 text-sm text-white/70">Then <span class="font-semibold text-white">$29.99</span> every 28 days</div>
    </div>
    <div class="px-8 py-7">
      <ul class="space-y-3 text-sm text-slate-600">
        ${['Detailed IQ score and results breakdown', 'Complete cognitive profile', 'Additional assessments for deeper personal insights', '17 courses with 35+ hours of lessons', 'Brain training games with 150+ exercises', 'Shareable certificate'].map((i) => `<li class="flex items-start gap-3"><span class="mt-0.5 text-green-custom">${star}</span>${i}</li>`).join('')}
      </ul>
      <a href="${L(lang, '/quiz')}" class="mt-7 block rounded-full bg-blue-custom px-6 py-4 text-center text-base font-semibold text-white no-underline hover:bg-blue-highlight">Start My IQ Test</a>
      <p class="mt-4 text-xs leading-relaxed text-slate-400">Your $1.00 trial lasts 7 days. Unless you cancel before it ends, your subscription renews automatically at $29.99 every 28 days. Cancel anytime in Account settings under Manage Subscription, or by emailing help@myiq.com.</p>
    </div>
  </div>
</section>
${footer(lang)}`;
}

function helpBody(lang) {
  const arts = [
    ['How do I cancel my subscription?', 'Go to Account Settings → Manage Subscription → Cancel, or visit the cancellation page, enter your email, verify the six-digit code and confirm. You keep access until the end of your current billing period.'],
    ['How is my IQ score calculated?', 'Your score is based on the number and difficulty of questions answered correctly, calibrated against a large sample of test-takers using the Raven’s Progressive Matrices standard (mean 100, standard deviation 15).'],
    ['Where is my certificate?', 'Your certificate is available in your profile after completing the test and subscribing. You can personalize it with your name, then print or save it as a PDF.'],
    ['I want a refund', 'Refunds are available within 7 days of a charge. Email help@myiq.com with your account email and we’ll process it.'],
  ];
  return `
${header(lang, L(lang, '/help'))}
<section class="mx-auto max-w-3xl px-4 py-16 sm:px-6">
  <h1 class="text-3xl font-bold tracking-tight text-ink">Help Center</h1>
  <p class="mt-3 text-slate-500">Answers to the most common questions. Still stuck? <a href="${L(lang, '/contact')}" class="text-blue-custom">Contact support</a>.</p>
  <div class="mt-8 divide-y divide-slate-100 overflow-hidden rounded-2xl border border-slate-100 bg-white">
    ${arts.map(([q, a], i) => `<details class="group" ${i === 0 ? 'open' : ''}><summary class="flex cursor-pointer list-none items-center justify-between gap-4 px-6 py-5 font-semibold text-ink">${q}<span class="text-blue-custom group-open:rotate-45">+</span></summary><p class="px-6 pb-5 text-sm leading-relaxed text-slate-500">${a}</p></details>`).join('')}
  </div>
</section>
${footer(lang)}`;
}

function contactBody(lang) {
  return `
${header(lang, L(lang, '/contact'))}
<section class="mx-auto max-w-lg px-4 py-16 sm:px-6">
  <h1 class="text-3xl font-bold tracking-tight text-ink">Contact myIQ support</h1>
  <p class="mt-3 text-slate-500">We usually reply within 24 hours. You can also email <a href="mailto:help@myiq.com" class="text-blue-custom">help@myiq.com</a>.</p>
  <div class="mt-8 space-y-4 rounded-3xl border border-slate-100 bg-white p-7 shadow-rd-card">
    <label class="block"><span class="mb-1 block text-xs font-medium text-slate-500">Your email</span><input type="email" class="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-blue-custom"/></label>
    <label class="block"><span class="mb-1 block text-xs font-medium text-slate-500">Message</span><textarea rows="5" class="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-blue-custom"></textarea></label>
    <button class="w-full rounded-full bg-ink px-6 py-3.5 text-sm font-semibold text-white" onclick="alert('Thanks! Our team will reply to your email shortly.')">Send message</button>
  </div>
  <p class="mt-6 text-xs text-slate-400">Envest Research Inc. 2093 Philadelphia Pike #3129, Claymont, DE 19703, United States.</p>
</section>
${footer(lang)}`;
}

function legalBody(lang, kind) {
  const titles = { terms: 'Terms of Service', privacy: 'Privacy Policy', cookie: 'Cookie Policy' };
  const common = `<p>Copyright © 2024-2026 myIQ™. Envest Research Inc. 2093 Philadelphia Pike #3129, Claymont, DE 19703, United States.</p>`;
  const bodies = {
    terms: `
      <h2>1. The service</h2><p>myIQ provides an online cognitive assessment based on Raven’s Progressive Matrices, together with a report, certificate, brain-training games and educational courses. The test is for entertainment and educational purposes only and is not a substitute for professional evaluation.</p>
      <h2>2. Trial and subscription</h2><p>Your $1.00 trial lasts 7 days. Unless you cancel before it ends, your subscription renews automatically at $29.99 every 28 days. You can cancel anytime in Account Settings under Manage Subscription or at the cancellation page.</p>
      <h2 id="refund">6. Refund policy</h2><p>Refunds are available within 7 days of any charge. After 7 days, charges are non-refundable. To request a refund, email help@myiq.com from your account email.</p>
      <h2>7. Cancellation</h2><p>You may cancel at any time; you keep access until the end of the current paid period and will not be charged again.</p>`,
    privacy: `
      <h2>Information we collect</h2><p>We collect the answers you provide, your email address, and basic usage and device data to deliver your results and improve the service.</p>
      <h2>How we use it</h2><p>We use your data to calculate your score, deliver your report and certificate, process payments, and provide support. Rankings are anonymous.</p>
      <h2>Your rights</h2><p>Your results are visible only to you unless you choose to share them. You can delete your account and personal data at any time.</p>`,
    cookie: `
      <h2>What cookies we use</h2><p>We use essential cookies for security and functionality, and analytics cookies to understand how the service is used. In regions that require it, non-essential cookies are only set with your consent.</p>
      <h2>Managing cookies</h2><p>You can manage or decline non-essential cookies in your browser settings at any time.</p>`,
  };
  return `
${header(lang, L(lang, '/' + kind))}
<section class="mx-auto max-w-3xl px-4 py-16 sm:px-6">
  <h1 class="text-3xl font-bold tracking-tight text-ink">${titles[kind]}</h1>
  <div class="prose prose-slate mt-6 max-w-none text-sm leading-relaxed text-slate-600 [&_h2]:mt-8 [&_h2]:mb-2 [&_h2]:text-base [&_h2]:font-bold [&_h2]:text-ink [&_p]:mt-2">
    ${bodies[kind]}
    <hr class="my-8 border-slate-100"/>
    ${common}
  </div>
</section>
${footer(lang)}`;
}

/* ----------------------------------------------------------------------------
 * Routing
 * -------------------------------------------------------------------------- */
function register(route, handler, title) {
  app.get(route, (req, res) => {
    const lang = req.path.startsWith('/pt-BR') ? 'pt' : 'en';
    const out = handler(lang);
    if (out && typeof out === 'object' && 'body' in out) {
      res.send(layout(out.body, { title, lang, bodyScript: out.script }));
    } else {
      res.send(layout(out, { title, lang }));
    }
  });
}

/* ----------------------------------------------------------------------------
 * Serve the REAL myIQ app (user-authorized) for every route. Each captured
 * page boots the real Next.js app from the mirrored chunks; unknown routes get
 * the app shell so the client router can resolve them.
 * -------------------------------------------------------------------------- */
const APP_PAGES = {
  '/': 'capturas/home_renderizada.html',
  '/quiz': 'paginas/quiz.html',
  '/start': 'paginas/start.html',
  '/checkout': 'paginas/checkout.html',
  '/pricing': 'paginas/pricing.html',
  '/terms': 'paginas/terms.html',
  '/privacy': 'paginas/privacy.html',
  '/cookie': 'paginas/cookie.html',
  '/help': 'paginas/help.html',
  '/help/contact-myiq-support': 'paginas/help_contact-myiq-support.html',
};
const APP_PAGES_PT = { '/': 'paginas/pt-BR.html', '/quiz': 'paginas/pt-BR_quiz.html' };

function servePath(req, res) {
  let p = (req.path || '/').replace(/\/+$/, '') || '/';
  let pt = false;
  if (p === '/pt-BR' || p.indexOf('/pt-BR/') === 0) { pt = true; p = p.slice(6) || '/'; }
  else if (p === '/en' || p.indexOf('/en/') === 0) { p = p.slice(3) || '/'; }
  let file = (pt && APP_PAGES_PT[p]) || APP_PAGES[p] || (pt ? APP_PAGES_PT['/'] : APP_PAGES['/']);
  serveRealApp(res, file);
}

/* The real app runs offline for the home + quiz, but its post-quiz monetisation
   flow (analyzing -> email -> checkout -> payment) depends on myIQ's backend and
   bounces to client-only routes we have no capture for. We bridge that tail with
   our own screens so the funnel completes. Registered before the catch-all. */
function tailLang(req) { return req.path.indexOf('/pt-BR') === 0 ? 'pt' : 'en'; }
/* The REAL quiz submits answers to myIQ's backend at the end (absolute
   https://myiq.com/api), which hangs offline on the final "Continue". So the
   quiz uses our reconstruction, which is built from the real captured screens
   (real matrix SVGs, real question text, real CSS classes) and completes. */
app.get(['/quiz', '/pt-BR/quiz', '/en/quiz'], (req, res) => res.send(quizPage(tailLang(req))));
app.get(['/analyzing', '/pt-BR/analyzing', '/en/analyzing'], (req, res) => res.send(analyzingPage(tailLang(req))));
app.get(['/checkout', '/pt-BR/checkout', '/en/checkout'], (req, res) => res.send(checkoutPage(tailLang(req))));
// Platform (member area) removed — this copy covers home -> checkout only.
// Any leftover platform URL redirects back to the funnel/home.
app.get(['/dashboard', '/pt-BR/dashboard', '/en/dashboard',
         '/sign-in', '/en/sign-in', '/pt-BR/sign-in',
         '/cancellation', '/cancellation/auth', '/en/cancellation', '/pt-BR/cancellation', '/pt-BR/cancellation/auth',
         '/results', '/en/results', '/pt-BR/results'],
  (req, res) => res.redirect(req.path.indexOf('/pt-BR') === 0 ? '/pt-BR' : '/'));
app.get(['/email', '/pt-BR/email', '/en/email'], (req, res) => res.send(emailPage(tailLang(req))));

app.get('*', servePath);

app.listen(PORT, () => {
  console.log(`myIQ clone running at http://localhost:${PORT}`);
});
