(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  327445,
  (e) => {
    "use strict";
    var t = e.i(415944),
      r = e.i(595494),
      a = e.i(271645),
      n = e.i(843476),
      o = (0, a.forwardRef)(function (e, a) {
        var o, i;
        let s = (0, r.useProviderContext)(),
          l =
            null != (i = null != (o = e.validationBehavior) ? o : null == s ? void 0 : s.validationBehavior)
              ? i
              : "native";
        return (0, n.jsx)(t.Form, { ...e, ref: a, validationBehavior: l });
      });
    e.s(["Form", 0, o]);
  },
  398437,
  (e, t, r) => {
    "use strict";
    var a = e.r(179684),
      n = {
        childContextTypes: !0,
        contextType: !0,
        contextTypes: !0,
        defaultProps: !0,
        displayName: !0,
        getDefaultProps: !0,
        getDerivedStateFromError: !0,
        getDerivedStateFromProps: !0,
        mixins: !0,
        propTypes: !0,
        type: !0,
      },
      o = { name: !0, length: !0, prototype: !0, caller: !0, callee: !0, arguments: !0, arity: !0 },
      i = { $$typeof: !0, compare: !0, defaultProps: !0, displayName: !0, propTypes: !0, type: !0 },
      s = {};
    function l(e) {
      return a.isMemo(e) ? i : s[e.$$typeof] || n;
    }
    ((s[a.ForwardRef] = { $$typeof: !0, render: !0, defaultProps: !0, displayName: !0, propTypes: !0 }),
      (s[a.Memo] = i));
    var c = Object.defineProperty,
      d = Object.getOwnPropertyNames,
      u = Object.getOwnPropertySymbols,
      p = Object.getOwnPropertyDescriptor,
      h = Object.getPrototypeOf,
      m = Object.prototype;
    t.exports = function e(t, r, a) {
      if ("string" != typeof r) {
        if (m) {
          var n = h(r);
          n && n !== m && e(t, n, a);
        }
        var i = d(r);
        u && (i = i.concat(u(r)));
        for (var s = l(t), f = l(r), g = 0; g < i.length; ++g) {
          var v = i[g];
          if (!o[v] && !(a && a[v]) && !(f && f[v]) && !(s && s[v])) {
            var b = p(r, v);
            try {
              c(t, v, b);
            } catch (e) {}
          }
        }
      }
      return t;
    };
  },
  455263,
  (e) => {
    "use strict";
    var t,
      r,
      a = e.i(271645),
      n = e.i(745009),
      o = [
        "sitekey",
        "onChange",
        "theme",
        "type",
        "tabindex",
        "onExpired",
        "onErrored",
        "size",
        "stoken",
        "grecaptcha",
        "badge",
        "hl",
        "isolated",
      ];
    function i() {
      return (i = Object.assign.bind()).apply(this, arguments);
    }
    function s(e) {
      if (void 0 === e) throw ReferenceError("this hasn't been initialised - super() hasn't been called");
      return e;
    }
    function l(e, t) {
      return (l = Object.setPrototypeOf
        ? Object.setPrototypeOf.bind()
        : function (e, t) {
            return ((e.__proto__ = t), e);
          })(e, t);
    }
    var c = (function (e) {
      function t() {
        var t;
        return (
          ((t = e.call(this) || this).handleExpired = t.handleExpired.bind(s(t))),
          (t.handleErrored = t.handleErrored.bind(s(t))),
          (t.handleChange = t.handleChange.bind(s(t))),
          (t.handleRecaptchaRef = t.handleRecaptchaRef.bind(s(t))),
          t
        );
      }
      ((t.prototype = Object.create(e.prototype)), (t.prototype.constructor = t), l(t, e));
      var r = t.prototype;
      return (
        (r.getCaptchaFunction = function (e) {
          return this.props.grecaptcha
            ? this.props.grecaptcha.enterprise
              ? this.props.grecaptcha.enterprise[e]
              : this.props.grecaptcha[e]
            : null;
        }),
        (r.getValue = function () {
          var e = this.getCaptchaFunction("getResponse");
          return e && void 0 !== this._widgetId ? e(this._widgetId) : null;
        }),
        (r.getWidgetId = function () {
          return this.props.grecaptcha && void 0 !== this._widgetId ? this._widgetId : null;
        }),
        (r.execute = function () {
          var e = this.getCaptchaFunction("execute");
          if (e && void 0 !== this._widgetId) return e(this._widgetId);
          this._executeRequested = !0;
        }),
        (r.executeAsync = function () {
          var e = this;
          return new Promise(function (t, r) {
            ((e.executionResolve = t), (e.executionReject = r), e.execute());
          });
        }),
        (r.reset = function () {
          var e = this.getCaptchaFunction("reset");
          e && void 0 !== this._widgetId && e(this._widgetId);
        }),
        (r.forceReset = function () {
          var e = this.getCaptchaFunction("reset");
          e && e();
        }),
        (r.handleExpired = function () {
          this.props.onExpired ? this.props.onExpired() : this.handleChange(null);
        }),
        (r.handleErrored = function () {
          (this.props.onErrored && this.props.onErrored(),
            this.executionReject &&
              (this.executionReject(), delete this.executionResolve, delete this.executionReject));
        }),
        (r.handleChange = function (e) {
          (this.props.onChange && this.props.onChange(e),
            this.executionResolve &&
              (this.executionResolve(e), delete this.executionReject, delete this.executionResolve));
        }),
        (r.explicitRender = function () {
          var e = this.getCaptchaFunction("render");
          if (e && void 0 === this._widgetId) {
            var t = document.createElement("div");
            ((this._widgetId = e(t, {
              sitekey: this.props.sitekey,
              callback: this.handleChange,
              theme: this.props.theme,
              type: this.props.type,
              tabindex: this.props.tabindex,
              "expired-callback": this.handleExpired,
              "error-callback": this.handleErrored,
              size: this.props.size,
              stoken: this.props.stoken,
              hl: this.props.hl,
              badge: this.props.badge,
              isolated: this.props.isolated,
            })),
              this.captcha.appendChild(t));
          }
          this._executeRequested &&
            this.props.grecaptcha &&
            void 0 !== this._widgetId &&
            ((this._executeRequested = !1), this.execute());
        }),
        (r.componentDidMount = function () {
          this.explicitRender();
        }),
        (r.componentDidUpdate = function () {
          this.explicitRender();
        }),
        (r.handleRecaptchaRef = function (e) {
          this.captcha = e;
        }),
        (r.render = function () {
          var e = this.props,
            t =
              (e.sitekey,
              e.onChange,
              e.theme,
              e.type,
              e.tabindex,
              e.onExpired,
              e.onErrored,
              e.size,
              e.stoken,
              e.grecaptcha,
              e.badge,
              e.hl,
              e.isolated,
              (function (e, t) {
                if (null == e) return {};
                var r,
                  a,
                  n = {},
                  o = Object.keys(e);
                for (a = 0; a < o.length; a++) ((r = o[a]), t.indexOf(r) >= 0 || (n[r] = e[r]));
                return n;
              })(e, o));
          return a.createElement("div", i({}, t, { ref: this.handleRecaptchaRef }));
        }),
        t
      );
    })(a.Component);
    ((c.displayName = "ReCAPTCHA"),
      (c.propTypes = {
        sitekey: n.default.string.isRequired,
        onChange: n.default.func,
        grecaptcha: n.default.object,
        theme: n.default.oneOf(["dark", "light"]),
        type: n.default.oneOf(["image", "audio"]),
        tabindex: n.default.number,
        onExpired: n.default.func,
        onErrored: n.default.func,
        size: n.default.oneOf(["compact", "normal", "invisible"]),
        stoken: n.default.string,
        hl: n.default.string,
        badge: n.default.oneOf(["bottomright", "bottomleft", "inline"]),
        isolated: n.default.bool,
      }),
      (c.defaultProps = {
        onChange: function () {},
        theme: "light",
        type: "image",
        tabindex: 0,
        size: "normal",
        badge: "bottomright",
      }));
    var d = e.i(398437);
    function u() {
      return (u =
        Object.assign ||
        function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = arguments[t];
            for (var a in r) Object.prototype.hasOwnProperty.call(r, a) && (e[a] = r[a]);
          }
          return e;
        }).apply(this, arguments);
    }
    var p = {},
      h = 0,
      m = "onloadcallback";
    function f() {
      return ("u" > typeof window && window.recaptchaOptions) || {};
    }
    let g = ((t = function () {
      var e = f(),
        t = e.useRecaptchaNet ? "recaptcha.net" : "www.google.com";
      return e.enterprise
        ? "https://" + t + "/recaptcha/enterprise.js?onload=" + m + "&render=explicit"
        : "https://" + t + "/recaptcha/api.js?onload=" + m + "&render=explicit";
    }),
    (r = r =
      { callbackName: m, globalName: "grecaptcha", attributes: f().nonce ? { nonce: f().nonce } : {} }),
    function (e) {
      var o = e.displayName || e.name || "Component",
        i = (function (n) {
          function o(e, t) {
            var r;
            return (((r = n.call(this, e, t) || this).state = {}), (r.__scriptURL = ""), r);
          }
          ((o.prototype = Object.create(n.prototype)), (o.prototype.constructor = o), (o.__proto__ = n));
          var i = o.prototype;
          return (
            (i.asyncScriptLoaderGetScriptLoaderID = function () {
              return (
                this.__scriptLoaderID || (this.__scriptLoaderID = "async-script-loader-" + h++),
                this.__scriptLoaderID
              );
            }),
            (i.setupScriptURL = function () {
              return ((this.__scriptURL = "function" == typeof t ? t() : t), this.__scriptURL);
            }),
            (i.asyncScriptLoaderHandleLoad = function (e) {
              var t = this;
              this.setState(e, function () {
                return t.props.asyncScriptOnLoad && t.props.asyncScriptOnLoad(t.state);
              });
            }),
            (i.asyncScriptLoaderTriggerOnScriptLoaded = function () {
              var e = p[this.__scriptURL];
              if (!e || !e.loaded) throw Error("Script is not loaded.");
              for (var t in e.observers) e.observers[t](e);
              delete window[r.callbackName];
            }),
            (i.componentDidMount = function () {
              var e = this,
                t = this.setupScriptURL(),
                a = this.asyncScriptLoaderGetScriptLoaderID(),
                n = r,
                o = n.globalName,
                i = n.callbackName,
                s = n.scriptId;
              if ((o && void 0 !== window[o] && (p[t] = { loaded: !0, observers: {} }), p[t])) {
                var l = p[t];
                return l && (l.loaded || l.errored)
                  ? void this.asyncScriptLoaderHandleLoad(l)
                  : void (l.observers[a] = function (t) {
                      return e.asyncScriptLoaderHandleLoad(t);
                    });
              }
              var c = {};
              ((c[a] = function (t) {
                return e.asyncScriptLoaderHandleLoad(t);
              }),
                (p[t] = { loaded: !1, observers: c }));
              var d = document.createElement("script");
              for (var u in ((d.src = t), (d.async = !0), r.attributes)) d.setAttribute(u, r.attributes[u]);
              s && (d.id = s);
              var h = function (e) {
                if (p[t]) {
                  var r = p[t].observers;
                  for (var a in r) e(r[a]) && delete r[a];
                }
              };
              (i &&
                "u" > typeof window &&
                (window[i] = function () {
                  return e.asyncScriptLoaderTriggerOnScriptLoaded();
                }),
                (d.onload = function () {
                  var e = p[t];
                  e &&
                    ((e.loaded = !0),
                    h(function (t) {
                      return !i && (t(e), !0);
                    }));
                }),
                (d.onerror = function () {
                  var e = p[t];
                  e &&
                    ((e.errored = !0),
                    h(function (t) {
                      return (t(e), !0);
                    }));
                }),
                document.body.appendChild(d));
            }),
            (i.componentWillUnmount = function () {
              var e = this.__scriptURL;
              if (!0 === r.removeOnUnmount)
                for (var t = document.getElementsByTagName("script"), a = 0; a < t.length; a += 1)
                  t[a].src.indexOf(e) > -1 && t[a].parentNode && t[a].parentNode.removeChild(t[a]);
              var n = p[e];
              n &&
                (delete n.observers[this.asyncScriptLoaderGetScriptLoaderID()],
                !0 === r.removeOnUnmount && delete p[e]);
            }),
            (i.render = function () {
              var t = r.globalName,
                n = this.props,
                o = (n.asyncScriptOnLoad, n.forwardedRef),
                i = (function (e, t) {
                  if (null == e) return {};
                  var r,
                    a,
                    n = {},
                    o = Object.keys(e);
                  for (a = 0; a < o.length; a++) t.indexOf((r = o[a])) >= 0 || (n[r] = e[r]);
                  return n;
                })(n, ["asyncScriptOnLoad", "forwardedRef"]);
              return (
                t && "u" > typeof window && (i[t] = void 0 !== window[t] ? window[t] : void 0),
                (i.ref = o),
                (0, a.createElement)(e, i)
              );
            }),
            o
          );
        })(a.Component),
        s = (0, a.forwardRef)(function (e, t) {
          return (0, a.createElement)(i, u({}, e, { forwardedRef: t }));
        });
      return (
        (s.displayName = "AsyncScriptLoader(" + o + ")"),
        (s.propTypes = { asyncScriptOnLoad: n.default.func }),
        (0, d.default)(s, e)
      );
    })(c);
    e.s(["default", 0, g], 455263);
  },
  788699,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("pencil", [
      [
        "path",
        {
          d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
          key: "1a8usu",
        },
      ],
      ["path", { d: "m15 5 4 4", key: "1mk7zo" }],
    ]);
    e.s(["Pencil", 0, t], 788699);
  },
  232189,
  (e, t, r) => {
    "use strict";
    t.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
  },
  865156,
  (e, t, r) => {
    "use strict";
    var a = e.r(232189);
    function n() {}
    function o() {}
    ((o.resetWarningCache = n),
      (t.exports = function () {
        function e(e, t, r, n, o, i) {
          if (i !== a) {
            var s = Error(
              "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types",
            );
            throw ((s.name = "Invariant Violation"), s);
          }
        }
        function t() {
          return e;
        }
        e.isRequired = e;
        var r = {
          array: e,
          bigint: e,
          bool: e,
          func: e,
          number: e,
          object: e,
          string: e,
          symbol: e,
          any: e,
          arrayOf: t,
          element: e,
          elementType: e,
          instanceOf: t,
          node: e,
          objectOf: t,
          oneOf: t,
          oneOfType: t,
          shape: t,
          exact: t,
          checkPropTypes: o,
          resetWarningCache: n,
        };
        return ((r.PropTypes = r), r);
      }));
  },
  745009,
  (e, t, r) => {
    (e.i(247167), (t.exports = e.r(865156)()));
  },
  552210,
  (e, t, r) => {
    "use strict";
    var a = "function" == typeof Symbol && Symbol.for,
      n = a ? Symbol.for("react.element") : 60103,
      o = a ? Symbol.for("react.portal") : 60106,
      i = a ? Symbol.for("react.fragment") : 60107,
      s = a ? Symbol.for("react.strict_mode") : 60108,
      l = a ? Symbol.for("react.profiler") : 60114,
      c = a ? Symbol.for("react.provider") : 60109,
      d = a ? Symbol.for("react.context") : 60110,
      u = a ? Symbol.for("react.async_mode") : 60111,
      p = a ? Symbol.for("react.concurrent_mode") : 60111,
      h = a ? Symbol.for("react.forward_ref") : 60112,
      m = a ? Symbol.for("react.suspense") : 60113,
      f = a ? Symbol.for("react.suspense_list") : 60120,
      g = a ? Symbol.for("react.memo") : 60115,
      v = a ? Symbol.for("react.lazy") : 60116,
      b = a ? Symbol.for("react.block") : 60121,
      y = a ? Symbol.for("react.fundamental") : 60117,
      _ = a ? Symbol.for("react.responder") : 60118,
      x = a ? Symbol.for("react.scope") : 60119;
    function w(e) {
      if ("object" == typeof e && null !== e) {
        var t = e.$$typeof;
        switch (t) {
          case n:
            switch ((e = e.type)) {
              case u:
              case p:
              case i:
              case l:
              case s:
              case m:
                return e;
              default:
                switch ((e = e && e.$$typeof)) {
                  case d:
                  case h:
                  case v:
                  case g:
                  case c:
                    return e;
                  default:
                    return t;
                }
            }
          case o:
            return t;
        }
      }
    }
    function k(e) {
      return w(e) === p;
    }
    ((r.AsyncMode = u),
      (r.ConcurrentMode = p),
      (r.ContextConsumer = d),
      (r.ContextProvider = c),
      (r.Element = n),
      (r.ForwardRef = h),
      (r.Fragment = i),
      (r.Lazy = v),
      (r.Memo = g),
      (r.Portal = o),
      (r.Profiler = l),
      (r.StrictMode = s),
      (r.Suspense = m),
      (r.isAsyncMode = function (e) {
        return k(e) || w(e) === u;
      }),
      (r.isConcurrentMode = k),
      (r.isContextConsumer = function (e) {
        return w(e) === d;
      }),
      (r.isContextProvider = function (e) {
        return w(e) === c;
      }),
      (r.isElement = function (e) {
        return "object" == typeof e && null !== e && e.$$typeof === n;
      }),
      (r.isForwardRef = function (e) {
        return w(e) === h;
      }),
      (r.isFragment = function (e) {
        return w(e) === i;
      }),
      (r.isLazy = function (e) {
        return w(e) === v;
      }),
      (r.isMemo = function (e) {
        return w(e) === g;
      }),
      (r.isPortal = function (e) {
        return w(e) === o;
      }),
      (r.isProfiler = function (e) {
        return w(e) === l;
      }),
      (r.isStrictMode = function (e) {
        return w(e) === s;
      }),
      (r.isSuspense = function (e) {
        return w(e) === m;
      }),
      (r.isValidElementType = function (e) {
        return (
          "string" == typeof e ||
          "function" == typeof e ||
          e === i ||
          e === p ||
          e === l ||
          e === s ||
          e === m ||
          e === f ||
          ("object" == typeof e &&
            null !== e &&
            (e.$$typeof === v ||
              e.$$typeof === g ||
              e.$$typeof === c ||
              e.$$typeof === d ||
              e.$$typeof === h ||
              e.$$typeof === y ||
              e.$$typeof === _ ||
              e.$$typeof === x ||
              e.$$typeof === b))
        );
      }),
      (r.typeOf = w));
  },
  179684,
  (e, t, r) => {
    "use strict";
    (e.i(247167), (t.exports = e.r(552210)));
  },
  436992,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(948148);
    e.i(273998);
    var a = e.i(38256),
      n = e.i(523615),
      o = e.i(105278);
    e.i(872721);
    var i = e.i(652050);
    e.i(872756);
    var s = e.i(987132);
    e.i(83029);
    var l = e.i(40959);
    e.i(203068);
    var c = e.i(532262),
      d = e.i(202042);
    let u = [
        {
          titleKey: "ab_myiq_home_redesign_footer_col_product_title",
          links: [
            {
              labelKey: "ab_myiq_home_redesign_footer_link_how_it_works",
              href: "/#how-it-works",
              trackingName: "How it works",
            },
            {
              labelKey: "ab_myiq_home_redesign_footer_link_courses",
              href: "/#courses",
              trackingName: "Courses",
            },
            { labelKey: "nav_reviews", href: "/#reviews", trackingName: "Reviews" },
            { labelKey: "nav_pricing", href: "/#pricing", trackingName: "Pricing" },
            { labelKey: "ab_myiq_home_redesign_footer_link_faq", href: "/#faq", trackingName: "FAQ" },
          ],
        },
        {
          titleKey: "ab_myiq_home_redesign_footer_col_support_title",
          links: [
            { labelKey: "nav_help", href: "/help", trackingName: "Help" },
            {
              labelKey: "ab_myiq_home_redesign_footer_link_how_to_cancel",
              href: "/cancellation/auth",
              trackingName: "How to cancel",
              event: "how-to-cancel",
            },
            {
              labelKey: "ab_myiq_home_redesign_footer_link_contact",
              href: e.i(134404).EClientRoutes.CONTACT_SUPPORT,
              trackingName: "Contact",
              event: "contact-support",
            },
          ],
        },
        {
          titleKey: "nav_title_legal",
          links: [
            { labelKey: "nav_privacy_policy", href: "/privacy", trackingName: "Privacy Policy" },
            {
              labelKey: "ab_myiq_home_redesign_footer_link_terms",
              href: "/terms",
              trackingName: "Terms of Service",
            },
            { labelKey: "nav_cookie_policy", href: "/cookie", trackingName: "Cookie Policy" },
            { labelKey: "nav_refund", href: "/terms#refund-policy", trackingName: "Refund Policy" },
          ],
        },
      ],
      p = ["ab_myiq_home_redesign_footer_legal_copyright", "ab_myiq_home_redesign_footer_legal_disclaimer"],
      h = [
        { id: "instagram", label: "Instagram", href: "https://www.instagram.com/myiq_com" },
        { id: "facebook", label: "Facebook", href: "https://www.facebook.com/MyIQapp" },
        { id: "reddit", label: "Reddit", href: "https://www.reddit.com/r/MyIQ_Official/" },
      ],
      m = {
        instagram: (0, t.jsx)(n.InstagramIcon, {
          "aria-hidden": !0,
          viewBox: "0 0 28 29",
          className: "size-4",
        }),
        facebook: (0, t.jsx)(a.FacebookIcon, {
          "aria-hidden": !0,
          viewBox: "0 0 28 29",
          className: "size-4",
        }),
        reddit: (0, t.jsx)(o.RedditIcon, { "aria-hidden": !0, viewBox: "0 0 16 16", className: "size-4" }),
      },
      f = () =>
        (0, t.jsxs)("svg", {
          "aria-hidden": !0,
          viewBox: "0 0 16 16",
          fill: "none",
          focusable: "false",
          className: "size-4 shrink-0",
          children: [
            (0, t.jsx)("circle", {
              cx: "8",
              cy: "8",
              r: "6.25",
              stroke: "currentColor",
              strokeWidth: "1.25",
            }),
            (0, t.jsx)("path", {
              d: "M1.75 8h12.5M8 1.75c1.8 1.7 2.75 3.9 2.75 6.25S9.8 12.55 8 14.25M8 1.75c-1.8 1.7-2.75 3.9-2.75 6.25s.95 4.55 2.75 6.25",
              stroke: "currentColor",
              strokeWidth: "1.25",
            }),
          ],
        });
    e.s(
      [
        "default",
        0,
        (e) => {
          let { translatedByKey: a, preserveSearchParams: n } = e,
            o = (0, r.useTranslations)(),
            g = (e) => a?.[e] ?? o(e),
            {
              trackFooterLink: v,
              trackHowToCancel: b,
              trackContactSupport: y,
            } = (0, i.useDemoHomeTracking)();
          return (0, t.jsx)("footer", {
            id: "footer",
            className: "w-full border-t border-slate-200 bg-white pb-12 pt-8 sm:pt-16 lg:pb-16 lg:pt-24",
            children: (0, t.jsx)(s.DemoContainer, {
              children: (0, t.jsxs)("div", {
                className: "flex flex-col gap-12",
                children: [
                  (0, t.jsx)("h2", {
                    className: "sr-only",
                    children: g("ab_myiq_home_redesign_footer_heading"),
                  }),
                  (0, t.jsxs)("div", {
                    className: "grid grid-cols-2 gap-10 md:grid-cols-[1.5fr_1fr_1fr_1fr] lg:gap-12",
                    children: [
                      (0, t.jsxs)("div", {
                        className: "col-span-2 flex flex-col gap-4 md:col-span-1",
                        children: [
                          (0, t.jsxs)(d.Link, {
                            href: "/#demo-top",
                            className: "flex items-center gap-2",
                            children: [
                              (0, t.jsx)(l.IconLogoDark, {
                                "aria-hidden": !0,
                                viewBox: "0 0 108 31",
                                className: "h-7 w-auto",
                              }),
                              (0, t.jsx)("span", { className: "sr-only", children: "MyIQ" }),
                            ],
                          }),
                          (0, t.jsx)("ul", {
                            className: "mt-1 flex items-center gap-3",
                            children: h.map((e) =>
                              (0, t.jsx)(
                                "li",
                                {
                                  children: (0, t.jsx)("a", {
                                    href: e.href,
                                    target: "_blank",
                                    rel: "noreferrer",
                                    "aria-label": e.label,
                                    className:
                                      "flex size-9 items-center justify-center rounded-full border border-slate-200 text-grey-deep transition-colors duration-150 [@media(hover:hover)]:hover:border-slate-300 [@media(hover:hover)]:hover:text-black-custom",
                                    children: m[e.id],
                                  }),
                                },
                                e.id,
                              ),
                            ),
                          }),
                        ],
                      }),
                      u.map((e) =>
                        (0, t.jsxs)(
                          "div",
                          {
                            children: [
                              (0, t.jsx)("h3", {
                                className: "text-hp-eyebrow uppercase text-grey-light",
                                children: g(e.titleKey),
                              }),
                              (0, t.jsx)("ul", {
                                className: "mt-4 flex flex-col gap-3",
                                children: e.links.map((e) =>
                                  (0, t.jsx)(
                                    "li",
                                    {
                                      children: (0, t.jsx)("a", {
                                        href: e.href,
                                        onClick: () =>
                                          "how-to-cancel" === e.event
                                            ? b()
                                            : "contact-support" === e.event
                                              ? y()
                                              : void v(e.trackingName),
                                        className:
                                          "text-hp-body-sm text-grey-deep transition-colors duration-150 [@media(hover:hover)]:hover:text-black-custom",
                                        children: g(e.labelKey),
                                      }),
                                    },
                                    e.labelKey,
                                  ),
                                ),
                              }),
                            ],
                          },
                          e.titleKey,
                        ),
                      ),
                    ],
                  }),
                  (0, t.jsxs)("div", {
                    className:
                      "flex flex-col gap-6 border-t border-slate-200 pt-8 md:flex-row md:items-start md:justify-between md:gap-10",
                    children: [
                      (0, t.jsx)("div", {
                        className: "flex flex-col gap-3",
                        children: p.map((e) =>
                          (0, t.jsx)(
                            "p",
                            {
                              className: "max-w-3xl text-pretty text-hp-caption text-grey-light",
                              children: g(e),
                            },
                            e,
                          ),
                        ),
                      }),
                      (0, t.jsx)(c.LangComponent, {
                        placement: "top",
                        className:
                          "h-9 !min-w-0 shrink-0 gap-2 self-start rounded-full border border-slate-200 bg-transparent px-4 text-hp-body-sm text-grey-deep data-[hover=true]:border-slate-300 data-[hover=true]:bg-transparent",
                        arrowClassName: "size-4 !text-grey-light",
                        triggerIcon: (0, t.jsx)(f, {}),
                        shouldBlockScroll: !1,
                        preserveSearchParams: n,
                      }),
                    ],
                  }),
                ],
              }),
            }),
          });
        },
      ],
      436992,
    );
  },
  853754,
  319970,
  (e) => {
    "use strict";
    var t = e.i(436992);
    (e.s([], 853754), e.s(["DemoFooterComponent", () => t.default], 319970));
  },
  256889,
  (e) => {
    "use strict";
    e.s([
      "cn",
      0,
      function () {
        for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
        return t.filter(Boolean).join(" ");
      },
    ]);
  },
  872721,
  652050,
  (e) => {
    "use strict";
    var t = e.i(271645),
      r = e.i(866897),
      a = e.i(157273),
      n = e.i(86596),
      o = e.i(924254),
      i = e.i(60423),
      s = e.i(523173),
      l = e.i(134404);
    e.i(470366);
    var c = e.i(504001),
      d = e.i(202042);
    (e.s(
      [
        "useDemoHomeTracking",
        0,
        () => {
          let e = (0, d.useRouter)(),
            u = (0, n.useUserStore)((e) => e.user),
            p = (0, n.useUserStore)((e) => e.handleChangeUserStore),
            h = (0, t.useCallback)(
              (e) => {
                (0, c.trackClientEvents)({
                  event: s.EAnalyticEvents.PAGE_CLICKED,
                  params: e,
                  sessionId: u?.id,
                  user: u,
                });
              },
              [u],
            ),
            m = (0, t.useCallback)(
              (t) => {
                (h({
                  page_name: "startCertifiedTestButtonClicked",
                  page_title: "Start",
                  ...(t && { gender: t }),
                }),
                  (0, c.trackClientEvents)({
                    event: s.EAnalyticEvents.FUNNEL_START_VIEW,
                    sessionId: u?.id,
                    user: u,
                  }),
                  (0, c.setPeopleAnalytic)({ funnel: "myiq", ...(t && { gender: t }) }),
                  i.accessLocalStorage.removeItem(a.StorageKeys.LOVE_LANGUAGE_QUIZ_ANSWERS),
                  i.accessLocalStorage.removeItem(a.StorageKeys.PERSONALITY_QUIZ_ANSWERS),
                  i.accessLocalStorage.removeItem(a.StorageKeys.QUIZ_ANSWERS),
                  o.accessCookie.removeItem(r.ECookieArg.LEGACY_FUNNEL),
                  p({
                    user: {
                      nextBillingDate: void 0,
                      billingSubscriptionData: void 0,
                      paynextSubscription: void 0,
                      paymentInfo: void 0,
                      isPaynextSubscribed: void 0,
                      ...(t && { gender: t }),
                    },
                  }),
                  e.push(l.EClientRoutes.QUIZ));
              },
              [h, u, p, e],
            ),
            f = (0, t.useCallback)(() => h({ page_name: "loginButtonClicked" }), [h]),
            g = (0, t.useCallback)((e) => h({ page_name: `${e}LinkClicked` }), [h]);
          return {
            startFunnel: m,
            trackLogin: f,
            trackFooterLink: g,
            trackHowToCancel: (0, t.useCallback)(() => {
              (0, c.trackClientEvents)({
                event: s.EAnalyticEvents.CANCEL_FLOW_HOW_TO_CANCEL_BUTTON_CLICKED,
                sessionId: u?.id,
              });
            }, [u]),
            trackContactSupport: (0, t.useCallback)(() => {
              (0, c.trackClientEvents)({
                event: s.EAnalyticEvents.CANCEL_FLOW_CONTACT_SUPPORT_BUTTON_CLICKED,
                sessionId: u?.id,
              });
            }, [u]),
          };
        },
      ],
      652050,
    ),
      e.s([], 872721));
  },
  791371,
  642448,
  (e) => {
    "use strict";
    var t = e.i(843476);
    e.i(340609);
    var r = e.i(90147),
      a = e.i(256889);
    let n = { sm: "h-9 px-3 text-hp-body-sm", md: "h-11 px-5 text-hp-body-sm", lg: "h-12 px-6 text-hp-body" },
      o = {
        primary:
          "bg-green-custom text-white border-transparent [@media(hover:hover)]:hover:bg-[#0B635C] active:bg-[#094F4A]",
        secondary:
          "bg-white text-green-custom border-green-custom [@media(hover:hover)]:hover:bg-green-custom/[0.06] active:bg-green-custom/[0.10]",
        ghost:
          "bg-transparent text-grey-deep border-transparent [@media(hover:hover)]:hover:bg-black-custom/[0.04] [@media(hover:hover)]:hover:text-black-custom active:bg-black-custom/[0.06]",
        danger:
          "bg-danger-custom text-white border-transparent [@media(hover:hover)]:hover:bg-danger-custom/90 active:bg-danger-custom/80",
      },
      i = (0, t.jsx)(r.Spinner, { size: "sm", color: "current", "aria-hidden": "true" });
    (e.s([], 791371),
      e.s(
        [
          "DemoButton",
          0,
          (e) => {
            let {
                size: r = "md",
                variant: s = "primary",
                href: l,
                type: c,
                disabled: d,
                isLoading: u,
                dataNr: p,
                className: h,
                onClick: m,
                children: f,
              } = e,
              g = (0, a.cn)(
                "inline-flex items-center justify-center gap-2 shrink-0 select-none rounded-full border border-transparent font-medium whitespace-nowrap transition-colors duration-150 ease-[cubic-bezier(0.4,0,0.2,1)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom disabled:cursor-not-allowed disabled:opacity-50 [&_svg]:size-4 [&_svg]:shrink-0",
                n[r],
                o[s],
                h,
              );
            return l
              ? (0, t.jsx)("a", { href: l, className: g, onClick: m, "data-nr": p, children: f })
              : (0, t.jsxs)("button", {
                  type: c ?? "button",
                  disabled: d,
                  className: g,
                  onClick: m,
                  "data-nr": p,
                  "data-loading": u || void 0,
                  children: [u && i, f],
                });
          },
        ],
        642448,
      ));
  },
  872756,
  987132,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(256889);
    (e.s([], 872756),
      e.s(
        [
          "DemoContainer",
          0,
          (e) => {
            let { className: a, children: n } = e;
            return (0, t.jsx)("div", {
              className: (0, r.cn)("mx-auto w-full max-w-7xl px-4 md:px-6 lg:px-8", a),
              children: n,
            });
          },
        ],
        987132,
      ));
  },
  812857,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(134404);
    e.i(872721);
    var a = e.i(652050);
    e.i(791371);
    var n = e.i(642448);
    e.s([
      "default",
      0,
      (e) => {
        let { size: o = "lg", variant: i = "primary", gender: s, className: l, children: c } = e,
          { startFunnel: d } = (0, a.useDemoHomeTracking)();
        return (0, t.jsx)(n.DemoButton, {
          size: o,
          variant: i,
          href: r.EClientRoutes.QUIZ,
          onClick: (e) => {
            e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || 0 !== e.button || (e.preventDefault(), d(s));
          },
          className: l,
          children: c,
        });
      },
    ]);
  },
  331955,
  957397,
  (e) => {
    "use strict";
    var t = e.i(812857);
    (e.s([], 331955), e.s(["DemoStartCta", () => t.default], 957397));
  },
  116904,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(948148);
    e.i(140962);
    var a = e.i(171566);
    e.i(83029);
    var n = e.i(40959),
      o = e.i(134404),
      i = e.i(202042),
      s = e.i(256889);
    e.i(872721);
    var l = e.i(652050);
    e.i(872756);
    var c = e.i(987132);
    e.i(331955);
    var d = e.i(957397);
    e.i(379551);
    var u = e.i(90614);
    e.s([
      "default",
      0,
      (e) => {
        let { brandHref: p = o.EClientRoutes.BASE, startCta: h } = e,
          m = (0, r.useTranslations)(),
          { trackLogin: f } = (0, l.useDemoHomeTracking)(),
          g = (0, u.useHeaderScroll)(),
          v = (0, a.useIsRedesignAuthenticated)();
        return (0, t.jsx)("header", {
          className: (0, s.cn)(
            "sticky top-0 z-50 w-full border-b bg-white transition-colors duration-150",
            g ? "border-slate-200" : "border-transparent",
          ),
          children: (0, t.jsx)(c.DemoContainer, {
            children: (0, t.jsxs)("div", {
              className: "flex h-16 items-center justify-between gap-4",
              children: [
                (0, t.jsxs)(i.Link, {
                  href: p,
                  className:
                    "flex items-center gap-2 rounded-lg focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom",
                  children: [
                    (0, t.jsx)(n.IconLogoDark, {
                      "aria-hidden": !0,
                      viewBox: "0 0 108 31",
                      className: "h-7 w-auto",
                    }),
                    (0, t.jsx)("span", {
                      className: "sr-only",
                      children: m("ab_myiq_home_redesign_header_brand_label"),
                    }),
                  ],
                }),
                (0, t.jsxs)("div", {
                  className: "flex items-center gap-3",
                  children: [
                    !v &&
                      (0, t.jsxs)("div", {
                        className: "hidden items-center gap-3 lg:flex",
                        children: [
                          (0, t.jsx)(i.Link, {
                            href: o.EClientRoutes.SIGN_IN,
                            onClick: f,
                            className:
                              "whitespace-nowrap text-hp-body-sm text-grey-deep transition-colors duration-150 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom [@media(hover:hover)]:hover:text-black-custom",
                            children: m("ab_myiq_home_redesign_header_sign_in_label"),
                          }),
                          !h &&
                            (0, t.jsx)(d.DemoStartCta, {
                              size: "sm",
                              variant: "primary",
                              children: m("btn_start_test"),
                            }),
                        ],
                      }),
                    h,
                  ],
                }),
              ],
            }),
          }),
        });
      },
    ]);
  },
  924482,
  20511,
  (e) => {
    "use strict";
    var t = e.i(116904);
    (e.s([], 924482), e.s(["DemoStaticHeaderComponent", () => t.default], 20511));
  },
  379551,
  90614,
  (e) => {
    "use strict";
    var t = e.i(271645);
    (e.s(
      [
        "useHeaderScroll",
        0,
        function () {
          let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 8,
            [r, a] = (0, t.useState)(!1);
          return (
            (0, t.useEffect)(() => {
              let t = () => {
                  a(window.scrollY > e);
                },
                r = requestAnimationFrame(t);
              return (
                window.addEventListener("scroll", t, { passive: !0 }),
                () => {
                  (cancelAnimationFrame(r), window.removeEventListener("scroll", t));
                }
              );
            }, [e]),
            r
          );
        },
      ],
      90614,
    ),
      e.s([], 379551));
  },
  497799,
  110910,
  451916,
  250737,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(788699),
      a = e.i(948148);
    (e.s([], 497799),
      e.s(
        [
          "AuthCodeSentToComponent",
          0,
          (e) => {
            let { email: n, onChange: o } = e,
              i = (0, a.useTranslations)();
            return (0, t.jsxs)("div", {
              className: "flex flex-col items-center gap-2",
              children: [
                (0, t.jsx)("p", {
                  className: "text-hp-body-sm text-grey-deep",
                  children: i("otp_confirmation_code_sent_to"),
                }),
                (0, t.jsxs)("button", {
                  type: "button",
                  onClick: o,
                  className:
                    "inline-flex h-8 max-w-full items-center gap-2 rounded-full border border-slate-200 bg-white px-3 text-hp-body-sm font-medium text-black-custom transition-colors duration-150 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-custom [@media(hover:hover)]:hover:border-slate-400",
                  children: [
                    (0, t.jsx)("span", { className: "truncate", dir: "ltr", children: n }),
                    (0, t.jsx)(r.Pencil, {
                      "aria-hidden": !0,
                      className: "size-4 shrink-0 text-grey-light",
                      strokeWidth: 1.5,
                    }),
                    (0, t.jsx)("span", {
                      className: "sr-only",
                      children: i("otp_confirmation_change_email"),
                    }),
                  ],
                }),
              ],
            });
          },
        ],
        110910,
      ));
    var n = e.i(982363),
      o = e.i(202042);
    let i = "help@myiq.com";
    (e.s([], 451916),
      e.s(
        [
          "AuthSupportNoteComponent",
          0,
          () => {
            let e = (0, a.useTranslations)();
            return (0, t.jsxs)("p", {
              className: "text-center text-hp-body-sm text-grey-light",
              children: [
                e("otp_confirmation_need_help"),
                " ",
                (0, t.jsx)(o.Link, {
                  href: (0, n.createSupportMailtoLink)({ supportEmail: i }),
                  prefetch: !1,
                  className: "text-green-custom transition-opacity hover:opacity-80 active:opacity-60",
                  children: i,
                }),
              ],
            });
          },
        ],
        250737,
      ));
  },
  341980,
  (e) => {
    "use strict";
    e.s([
      "FIELD_INPUT_BASE",
      0,
      "peer h-[3.25rem] w-full rounded-full border px-5 text-hp-body text-black-custom outline-none transition-colors duration-150 motion-reduce:transition-none",
      "FIELD_INPUT_ERROR",
      0,
      "border-danger-custom bg-white",
      "FIELD_INPUT_REST",
      0,
      "border-slate-200 bg-white focus:border-black-custom",
      "FIELD_LABEL_BASE",
      0,
      "pointer-events-none absolute left-4 origin-left px-1 transition-all duration-150 ease-[cubic-bezier(0.4,0,0.2,1)] motion-reduce:transition-none",
      "FIELD_LABEL_FLOAT",
      0,
      "peer-focus:top-0 peer-focus:-translate-y-1/2 peer-focus:bg-white peer-focus:text-hp-caption peer-focus:text-grey-custom peer-[:not(:placeholder-shown)]:top-0 peer-[:not(:placeholder-shown)]:-translate-y-1/2 peer-[:not(:placeholder-shown)]:bg-white peer-[:not(:placeholder-shown)]:text-hp-caption peer-[:not(:placeholder-shown)]:text-grey-custom",
      "FIELD_LABEL_REST",
      0,
      "top-1/2 -translate-y-1/2 bg-transparent text-hp-body text-grey-light",
      "FIELD_WRAPPER",
      0,
      "relative",
    ]);
  },
  494491,
  532153,
  (e) => {
    "use strict";
    var t = e.i(954616);
    (e.i(682770), e.i(934952));
    var r = e.i(134404);
    e.i(957215);
    var a = e.i(81844);
    let n = async (e) => {
        let t;
        try {
          let n = await a.httpInstance.post(`${r.EApiRoutes.OTP_CODE}/send`, {
            json: e,
            throwHttpErrors: !1,
          });
          return ((t = n.status), await n.json());
        } catch (e) {
          return {
            success: !1,
            error: "Failed to send OTP code",
            detailedMessage: `${e?.name || "UnknownError"}: ${e?.message || ""} (status: ${t ?? "none"})`,
          };
        }
      },
      o = async (e) => {
        try {
          let t = await a.httpInstance.post(`${r.EApiRoutes.OTP_CODE}/verify`, {
            json: e,
            throwHttpErrors: !1,
          });
          return await t.json();
        } catch (e) {
          return { success: !1, error: e?.message || "Failed to verify OTP code" };
        }
      },
      i = async (e) => {
        try {
          let t = await a.httpInstance.post(`${r.EApiRoutes.OTP_CODE}/verify-url-token`, {
            json: e,
            throwHttpErrors: !1,
          });
          return await t.json();
        } catch (e) {
          return { success: !1, error: e?.message || "Failed to verify URL token" };
        }
      },
      s = async (e) => {
        try {
          let t = await a.apiInstance.post("cancellation/establish-session", {
            json: e,
            throwHttpErrors: !1,
          });
          return await t.json();
        } catch (e) {
          return { success: !1, error: e?.message || "Failed to establish session" };
        }
      };
    (e.s(
      [
        "establishCancellationSessionFetcher",
        0,
        s,
        "sendOtpCodeFetcher",
        0,
        n,
        "verifyOtpCodeFetcher",
        0,
        o,
        "verifyOtpUrlTokenFetcher",
        0,
        i,
      ],
      532153,
    ),
      e.s(
        [
          "useSendOtpCodeQuery",
          0,
          () => {
            let e = (0, t.useMutation)({ mutationFn: n });
            return { ...e, trigger: e.mutateAsync };
          },
        ],
        494491,
      ));
  },
  83029,
  494967,
  676258,
  229742,
  40959,
  (e) => {
    "use strict";
    var t,
      r,
      a,
      n,
      o,
      i,
      s,
      l,
      c,
      d,
      u,
      p,
      h,
      m,
      f,
      g,
      v,
      b,
      y,
      _,
      x,
      w,
      k,
      E,
      C,
      L,
      S,
      j,
      N,
      I,
      R = e.i(271645);
    function O() {
      return (O = Object.assign.bind()).apply(null, arguments);
    }
    function A() {
      return (A = Object.assign.bind()).apply(null, arguments);
    }
    function T() {
      return (T = Object.assign.bind()).apply(null, arguments);
    }
    function P() {
      return (P = Object.assign.bind()).apply(null, arguments);
    }
    (e.s(
      [
        "default",
        0,
        (e) =>
          R.createElement(
            "svg",
            O({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 357 379" }, e),
            R.createElement(
              "g",
              { clipPath: "url(#a-1_svg__a)" },
              t ||
                (t = R.createElement("path", {
                  fill: "#FE0D0B",
                  d: "M304.015 127.868c-35.775-17.449-85.258-6.795-121.034-24.244l9.519-19.516c35.776 17.449 85.259 6.794 121.034 24.243z",
                })),
              r ||
                (r = R.createElement("path", {
                  fill: "#F80",
                  d: "M294.5 147.387c-35.776-17.449-85.259-6.794-121.035-24.243l9.519-19.517c35.776 17.449 85.259 6.794 121.035 24.243z",
                })),
              a ||
                (a = R.createElement("path", {
                  fill: "#FFD800",
                  d: "M284.98 166.903c-35.775-17.449-85.258-6.794-121.034-24.243l9.519-19.517c35.775 17.449 85.258 6.794 121.034 24.243z",
                })),
              n ||
                (n = R.createElement("path", {
                  fill: "#49B109",
                  d: "M275.461 186.418c-35.776-17.449-85.259-6.794-121.035-24.243l9.519-19.516c35.776 17.449 85.259 6.794 121.035 24.243z",
                })),
              o ||
                (o = R.createElement("path", {
                  fill: "#046EDE",
                  d: "M265.941 205.934c-35.776-17.449-85.259-6.794-121.034-24.243l9.519-19.517c35.775 17.449 85.258 6.794 121.034 24.243z",
                })),
              i ||
                (i = R.createElement("path", {
                  fill: "#800BBA",
                  d: "M256.422 225.453c-29.836-14.551-69.205-9.557-102.206-17.618-10.73-2.621-14.903-14.673-10.061-24.601l.751-1.54c35.776 17.449 85.259 6.794 121.035 24.243z",
                })),
              R.createElement(
                "mask",
                {
                  id: "a-1_svg__b",
                  width: 124,
                  height: 45,
                  x: 142,
                  y: 181,
                  maskUnits: "userSpaceOnUse",
                  style: { maskType: "alpha" },
                },
                s ||
                  (s = R.createElement("path", {
                    fill: "#800BBA",
                    d: "M256.426 225.453c-29.836-14.551-69.205-9.557-102.206-17.618-10.73-2.621-14.904-14.673-10.061-24.601l.751-1.54c35.776 17.449 85.259 6.794 121.035 24.243z",
                  })),
              ),
              l ||
                (l = R.createElement(
                  "g",
                  { mask: "url(#a-1_svg__b)" },
                  R.createElement("path", { fill: "#000", d: "m169.022 194.905-33.64 6.303 17.47-35.817z" }),
                )),
              c ||
                (c = R.createElement("path", {
                  fill: "#FE0D0B",
                  d: "M216.617 97.317c-35.776-17.45-85.259-6.794-121.034-24.243l.751-1.541c4.842-9.928 16.866-13.972 27.596-11.351 26.431 6.456 56.946 4.538 83.377 10.994 10.73 2.62 14.904 14.672 10.061 24.6z",
                })),
              d ||
                (d = R.createElement("path", {
                  fill: "#F80",
                  d: "M207.101 116.836c-35.775-17.449-85.258-6.794-121.034-24.243l9.519-19.516c35.776 17.449 85.259 6.794 121.034 24.243z",
                })),
              u ||
                (u = R.createElement("path", {
                  fill: "#FFD800",
                  d: "M197.582 136.352c-35.776-17.449-85.259-6.794-121.035-24.243l9.52-19.517c35.775 17.449 85.258 6.794 121.034 24.243z",
                })),
              p ||
                (p = R.createElement("path", {
                  fill: "#49B109",
                  d: "M188.062 155.868c-35.775-17.449-85.258-6.795-121.034-24.244l9.519-19.516c35.775 17.449 85.258 6.794 121.034 24.243z",
                })),
              h ||
                (h = R.createElement("path", {
                  fill: "#046EDE",
                  d: "M178.543 175.383c-35.776-17.449-85.259-6.794-121.035-24.243l9.52-19.517c35.775 17.449 85.258 6.795 121.034 24.244z",
                })),
              m ||
                (m = R.createElement("path", {
                  fill: "#800BBA",
                  d: "M169.023 194.903c-29.835-14.552-69.204-9.558-102.205-17.619-10.73-2.621-14.904-14.672-10.062-24.6l.752-1.541c35.775 17.449 85.258 6.794 121.034 24.243z",
                })),
              f ||
                (f = R.createElement("path", {
                  stroke: "#000",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 3.572,
                  d: "M223.704 328.086c-8.002 1.949-20.172 3.458-36.226 1.326-8.067-1.001-8.865-2.371-13.581-2.224s-19.994 14.935-19.994 14.935",
                })),
              g ||
                (g = R.createElement("path", {
                  stroke: "#000",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 14.29,
                  d: "M318.055 99.074 215.367 309.616M215.668 308.996l-20.335 41.693",
                })),
              v ||
                (v = R.createElement("path", {
                  fill: "#fff",
                  d: "m235.282 310.191-21.79-10.628a7.523 7.523 0 0 0-10.059 3.464 7.52 7.52 0 0 0 3.463 10.058l21.791 10.628a7.523 7.523 0 0 0 6.595-13.522",
                })),
              b ||
                (b = R.createElement("path", {
                  fill: "#fff",
                  stroke: "#000",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 3.572,
                  d: "m268 258.16-15.522-7.571c-4.984-2.431-10.996-.361-13.426 4.623h0c-2.431 4.984-.362 10.995 4.623 13.426l15.522 7.571c4.984 2.431 10.995.361 13.426-4.623s.361-10.995-4.623-13.426",
                })),
              y ||
                (y = R.createElement("path", {
                  fill: "#fff",
                  stroke: "#000",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 3.572,
                  d: "m261.472 277.317-24.533-11.966c-4.985-2.431-10.996-.361-13.426 4.623h0c-2.431 4.984-.362 10.995 4.622 13.426l24.534 11.966c4.984 2.43 10.995.361 13.426-4.623s.361-10.996-4.623-13.426",
                })),
              _ ||
                (_ = R.createElement("path", {
                  fill: "#fff",
                  stroke: "#000",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 3.572,
                  d: "m247.792 292.985-22.853-11.146c-4.985-2.431-10.996-.361-13.426 4.623h0c-2.431 4.984-.362 10.995 4.622 13.426l22.854 11.146c4.984 2.431 10.995.362 13.426-4.623 2.431-4.984.361-10.995-4.623-13.426",
                })),
              x ||
                (x = R.createElement("path", {
                  stroke: "#000",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 3.572,
                  d: "m221.497 321.143-14.203-6.927a8.375 8.375 0 0 1-3.856-11.2 8.375 8.375 0 0 1 11.199-3.856l20.286 9.894a8.375 8.375 0 0 1 3.856 11.199 8.34 8.34 0 0 1-3.793 3.826",
                })),
              w ||
                (w = R.createElement("path", {
                  stroke: "#000",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 3.572,
                  d: "M234.986 324.077s-3.836 2.195-11.28 4.008",
                })),
              k ||
                (k = R.createElement("path", {
                  fill: "#fff",
                  d: "M125.97 283.169c8.435-5.023 19.86-11.589 27.995-16.543 8.615-7.071 29.417-26.98 42.559-34.951 1.41-.848 2.834-1.564 4.355-2.031 4.119-1.15 7.875-.824 12.602-.498 6.189.539 12.944 1.62 19.077 2.892a120 120 0 0 1 7.129 1.686c3.02.795 6.303 1.977 8.04 4.1 6.249 7.192 5.736 21.119 5.775 30.389-.03 3.04.05 6.988-.057 9.546-.038.444-.105.742-.312 1.072-.421.6-1.103.985-1.755 1.328-1.735.956-4.406 1.214-6.536.522-7.328-2.08-12.136-12.831-13.571-19.763-.426-1.855-.406-3.02-.973-3.905-.491-.562-1.315-.288-2.003-.219a43 43 0 0 1-5.814.625c-1.39.069-2.595.098-3.45.273-1.422.255-1.88 1.115-2.326 2.345-4.457 13.467-14.528 26.734-33.859 30.394",
                })),
              E ||
                (E = R.createElement("path", {
                  stroke: "#000",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 3.572,
                  d: "M125.97 283.169c8.435-5.023 19.86-11.589 27.995-16.543 8.615-7.071 29.417-26.98 42.559-34.951 1.41-.848 2.834-1.564 4.355-2.031 4.119-1.15 7.875-.824 12.602-.498 6.189.539 12.944 1.62 19.078 2.892a120 120 0 0 1 7.128 1.686c3.02.795 6.303 1.977 8.04 4.1 6.249 7.192 5.736 21.119 5.775 30.389-.03 3.04.05 6.988-.057 9.546-.038.444-.105.742-.312 1.072-.421.6-1.103.985-1.755 1.328-1.735.956-4.406 1.214-6.536.522-7.328-2.08-12.136-12.831-13.571-19.763-.426-1.855-.406-3.02-.973-3.905-.491-.562-1.315-.288-2.003-.219a43 43 0 0 1-5.814.625c-1.39.069-2.595.098-3.45.273-1.422.255-1.88 1.115-2.326 2.345-4.457 13.467-14.528 26.734-33.859 30.394",
                })),
            ),
            C ||
              (C = R.createElement(
                "defs",
                null,
                R.createElement(
                  "clipPath",
                  { id: "a-1_svg__a" },
                  R.createElement("path", {
                    fill: "#fff",
                    d: "m131.223 0 225.114 109.795-131.223 269.046L.001 269.046z",
                  }),
                ),
              )),
          ),
      ],
      494967,
    ),
      e.s(
        [
          "default",
          0,
          (e) =>
            R.createElement(
              "svg",
              T({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 34 31" }, e),
              j ||
                (j = R.createElement("path", {
                  fill: "#E63942",
                  d: "m20.978 7.584 1.524 1.51a1.897 1.897 0 0 1-.001 2.696 1.935 1.935 0 0 1-2.722-.001l-1.666-1.651L14.11 6.17a6.24 6.24 0 0 0-4.274-1.496A6.23 6.23 0 0 0 5.67 6.466a6.1 6.1 0 0 0-1.814 4.124 6.1 6.1 0 0 0 1.507 4.234l10.506 10.42.316.314a.513.513 0 0 0 .726 0l10.822-10.734a6.1 6.1 0 0 0 1.507-4.233 6.1 6.1 0 0 0-1.812-4.124 6.23 6.23 0 0 0-5.176-1.747L19.14 1.639c1.31-.548 2.734-.82 4.18-.78a10.1 10.1 0 0 1 6.827 2.903 9.9 9.9 0 0 1 2.946 6.755 9.9 9.9 0 0 1-2.546 6.91l-.012.013-13.2 13.092a1.1 1.1 0 0 1-.787.323 1.12 1.12 0 0 1-.788-.323L2.548 17.428a9.9 9.9 0 0 1-2.544-6.907 9.9 9.9 0 0 1 2.94-6.75A10.1 10.1 0 0 1 9.767.86a10.1 10.1 0 0 1 6.777 2.36l.005-.005 4.42 4.376z",
                })),
            ),
        ],
        676258,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            R.createElement(
              "svg",
              P({ xmlns: "http://www.w3.org/2000/svg", width: 105, height: 30, fill: "none" }, e),
              N ||
                (N = R.createElement("path", {
                  fill: "#fff",
                  fillRule: "evenodd",
                  d: "m14.29 22.788-.082-.048zm-8.865-12.77-.373-.148a.7.7 0 0 1-.338.41l-.286.148a4.04 4.04 0 0 0-1.62 1.517 4.25 4.25 0 0 0 .068 4.469l.301.476.002.003c.4.619 1.006 1.07 1.707 1.264a2.9 2.9 0 0 0 2.098-.215l.004-.002a.65.65 0 0 1 .513-.04c.17.056.314.183.399.354.084.173.1.374.041.56a.7.7 0 0 1-.344.417l-.376.197.22.364a3.3 3.3 0 0 0 1.082 1.101l.01.007a3.2 3.2 0 0 0 2.471.323l.008-.002 6.186-1.85h.001a.65.65 0 0 1 .51.058c.157.09.277.241.33.426a.77.77 0 0 1-.063.555.7.7 0 0 1-.405.344l-1.54.461-.702.211.557.477c.358.306.688.563.991.8v.001c.957.749 1.659 1.297 2.19 2.528l.003.009.005.009a1 1 0 0 0 .929.567 1 1 0 0 0 .729-.314 1.06 1.06 0 0 0 .298-.743v-1.698a.76.76 0 0 1 .151-.45.7.7 0 0 1 .372-.254h.002l3.928-1.012c.398-.093.749-.326.993-.656s.367-.734.35-1.145a1.8 1.8 0 0 0-.5-1.237l-.005-.004-.634-.641-.207-.21-.261.136-.255.132a.66.66 0 0 1-.664-.025.7.7 0 0 1-.254-.286v-.001a.73.73 0 0 1 .091-.792.7.7 0 0 1 .208-.167h.001l.433-.224.008-.004.008-.005a3.83 3.83 0 0 0 1.412-1.427 4 4 0 0 0 .519-1.962c0-.42-.08-.835-.235-1.223a3.2 3.2 0 0 0-.67-1.04h-.001l-.328-.339-.002-.001a.8.8 0 0 1-.17-.283l-.07-.22a5.5 5.5 0 0 0-1.784-2.606 5.24 5.24 0 0 0-2.893-1.146l-.14-.01-.115.078a2.62 2.62 0 0 0-1.054 1.499 2.7 2.7 0 0 0 .168 1.837l.003.006a.73.73 0 0 1-.092.792.7.7 0 0 1-.204.165.65.65 0 0 1-.664-.025.7.7 0 0 1-.254-.285 4.2 4.2 0 0 1-.384-2.288 4.15 4.15 0 0 1 .884-2.134l.311-.388-.445-.22a4.85 4.85 0 0 0-3.834-.211l-.485.177.294.425q.203.293.357.616l.001.002.188.388v.002a.75.75 0 0 1-.092.805.656.656 0 0 1-.954.078.7.7 0 0 1-.166-.218l-.184-.396a3.02 3.02 0 0 0-1.334-1.434 2.9 2.9 0 0 0-1.92-.284h-.002A7.1 7.1 0 0 0 7.11 6.66a7.43 7.43 0 0 0-2.058 3.21zm21.38 6.333-.22.25.206.262.375.478.013.017.015.015c.382.392.66.88.807 1.42.146.539.155 1.108.025 1.652a3.26 3.26 0 0 1-.763 1.446 3.1 3.1 0 0 1-1.336.86l-3.104.802-.3.078v1.13c0 .665-.255 1.3-.706 1.768a2.35 2.35 0 0 1-1.69.725h-.005c-.454.005-.9-.126-1.285-.38a2.4 2.4 0 0 1-.882-1.05c-.775-1.796-2.034-2.538-3.47-3.386q-.322-.189-.654-.39l-.152-.093-.17.05-2.002.597h-.001c-.43.125-.876.184-1.323.178h-.01a4.4 4.4 0 0 1-2.339-.657l-.006-.004a4.53 4.53 0 0 1-1.88-2.193l-.101-.246-.266-.003a4.2 4.2 0 0 1-1.99-.532 4.36 4.36 0 0 1-1.529-1.434l-.002-.003-.316-.476a5.7 5.7 0 0 1-.835-2.16 5.8 5.8 0 0 1 .09-2.33 5.65 5.65 0 0 1 1.002-2.084 5.4 5.4 0 0 1 1.732-1.476l.131-.07.053-.14a8.9 8.9 0 0 1 2.499-3.566 8.44 8.44 0 0 1 3.836-1.881 4.3 4.3 0 0 1 2.636.355l.192.092.184-.108a6.2 6.2 0 0 1 3.363-.86 6.24 6.24 0 0 1 3.302 1.084l.431.298.094.064.114.006a6.54 6.54 0 0 1 3.704 1.388 6.9 6.9 0 0 1 2.309 3.318l.028.088.064.067.145.149a4.76 4.76 0 0 1 1.33 3.29 5.38 5.38 0 0 1-1.342 3.595",
                  clipRule: "evenodd",
                })),
              I ||
                (I = R.createElement("path", {
                  fill: "#fff",
                  d: "m36.63 24 2.182-13.09h2.447l-.358 2.13h.161a4.37 4.37 0 0 1 1.62-1.688q1.031-.613 2.335-.613 1.296 0 2.088.613.802.614 1.048 1.688h.137a4.56 4.56 0 0 1 1.764-1.68q1.134-.621 2.548-.621 1.764 0 2.71 1.125.955 1.116.58 3.358L54.426 24H51.87l1.432-8.54q.213-1.338-.409-1.926-.622-.597-1.628-.597-1.245 0-2.062.768-.819.758-1.006 1.951L46.79 24h-2.532l1.458-8.702q.17-1.074-.392-1.713-.555-.648-1.62-.648-.723 0-1.406.384a3.6 3.6 0 0 0-1.15 1.057 3.7 3.7 0 0 0-.622 1.551L39.179 24zm21.544 4.91q-.58 0-1.031-.095a3 3 0 0 1-.674-.187l.972-2.088q.674.187 1.202.145.537-.043 1.005-.444.47-.4.955-1.26l.477-.862-2.565-13.21h2.625l1.62 10.185h.136l5.011-10.185h2.838l-7.85 14.821q-.554 1.057-1.26 1.756a4.7 4.7 0 0 1-1.569 1.065 4.9 4.9 0 0 1-1.892.358M77.641 5.09V24h-3.998V5.09zm10.427 12.336h3.397l1.709 2.198 1.68 1.957 3.167 3.97h-3.73l-2.18-2.677-1.117-1.588zm10.239-2.88q0 3.093-1.173 5.262-1.163 2.17-3.176 3.315-2.003 1.136-4.505 1.136-2.52 0-4.525-1.145-2.002-1.146-3.166-3.315t-1.164-5.253q0-3.094 1.163-5.263t3.167-3.306q2.004-1.145 4.525-1.145 2.502 0 4.505 1.145 2.013 1.136 3.176 3.306 1.173 2.169 1.173 5.263m-4.053 0q0-2.004-.6-3.38-.59-1.376-1.672-2.086-1.08-.711-2.53-.711t-2.53.71-1.68 2.087q-.59 1.376-.59 3.38t.59 3.379q.6 1.375 1.68 2.086t2.53.711 2.53-.71q1.08-.712 1.672-2.087.6-1.376.6-3.38",
                })),
            ),
        ],
        229742,
      ),
      e.s([], 83029),
      e.s(
        [
          "IconLogoDark",
          0,
          (e) =>
            R.createElement(
              "svg",
              A({ xmlns: "http://www.w3.org/2000/svg", width: 108, height: 31, fill: "none" }, e),
              L ||
                (L = R.createElement("path", {
                  fill: "#2C3345",
                  fillRule: "evenodd",
                  d: "m14.29 23.288-.082-.048zm-8.865-12.77-.373-.148a.7.7 0 0 1-.338.41l-.286.148a4.04 4.04 0 0 0-1.62 1.517 4.25 4.25 0 0 0 .068 4.469l.301.476.002.003a3 3 0 0 0 1.707 1.263 2.9 2.9 0 0 0 2.098-.214l.004-.002a.65.65 0 0 1 .513-.041c.17.057.314.183.399.355.084.173.1.374.041.559a.7.7 0 0 1-.344.418l-.376.197.22.364a3.3 3.3 0 0 0 1.082 1.101l.01.007a3.2 3.2 0 0 0 2.471.323l.008-.002 6.186-1.85h.001a.65.65 0 0 1 .51.058.7.7 0 0 1 .33.426.77.77 0 0 1-.063.555.7.7 0 0 1-.405.344l-1.54.461-.702.21.557.477c.358.306.688.564.991.802.957.749 1.659 1.297 2.19 2.528l.003.009.005.008a1 1 0 0 0 .929.568 1.02 1.02 0 0 0 .729-.315 1.06 1.06 0 0 0 .298-.742v-1.698a.76.76 0 0 1 .151-.45.7.7 0 0 1 .372-.254h.002l3.928-1.012c.398-.093.749-.326.993-.656s.367-.734.35-1.145a1.8 1.8 0 0 0-.5-1.237l-.005-.004-.634-.641-.207-.21-.261.136-.255.132a.66.66 0 0 1-.664-.026.732.732 0 0 1-.163-1.078.7.7 0 0 1 .208-.167h.001l.433-.224.008-.005.008-.004a3.83 3.83 0 0 0 1.412-1.427 4 4 0 0 0 .519-1.962c0-.42-.08-.835-.235-1.223a3.2 3.2 0 0 0-.67-1.04h-.001l-.328-.339-.002-.002a.8.8 0 0 1-.17-.282l-.07-.22a5.5 5.5 0 0 0-1.784-2.606 5.24 5.24 0 0 0-2.893-1.146l-.14-.01-.115.078a2.62 2.62 0 0 0-1.054 1.499 2.7 2.7 0 0 0 .168 1.837l.003.006a.73.73 0 0 1-.092.792.7.7 0 0 1-.204.165.66.66 0 0 1-.664-.025.7.7 0 0 1-.254-.285 4.2 4.2 0 0 1-.384-2.288 4.15 4.15 0 0 1 .884-2.134l.311-.388-.445-.221a4.85 4.85 0 0 0-3.834-.211l-.485.178.294.425q.203.292.357.616l.001.002.188.387v.003a.75.75 0 0 1-.092.805.656.656 0 0 1-.954.078.7.7 0 0 1-.166-.218l-.184-.396a3.02 3.02 0 0 0-1.334-1.434 2.9 2.9 0 0 0-1.92-.284h-.002A7.1 7.1 0 0 0 7.11 7.16a7.43 7.43 0 0 0-2.058 3.21zm21.38 6.333-.22.25.206.262.375.478.013.017.015.015c.382.392.66.88.807 1.42.146.539.155 1.108.025 1.652a3.26 3.26 0 0 1-.763 1.446 3.1 3.1 0 0 1-1.336.86l-3.104.802-.3.078v1.13c0 .665-.255 1.3-.706 1.768a2.35 2.35 0 0 1-1.69.725h-.005c-.454.005-.9-.126-1.285-.38a2.4 2.4 0 0 1-.882-1.05c-.775-1.796-2.034-2.538-3.47-3.386q-.322-.189-.654-.39l-.152-.093-.17.05-2.002.597h-.001c-.43.125-.876.184-1.323.178h-.01a4.4 4.4 0 0 1-2.339-.657l-.006-.004a4.53 4.53 0 0 1-1.88-2.193l-.101-.246-.266-.003a4.2 4.2 0 0 1-1.99-.532 4.36 4.36 0 0 1-1.529-1.434l-.002-.003-.316-.476a5.7 5.7 0 0 1-.835-2.16 5.8 5.8 0 0 1 .09-2.33 5.65 5.65 0 0 1 1.002-2.084 5.4 5.4 0 0 1 1.732-1.476l.131-.07.053-.14a8.9 8.9 0 0 1 2.499-3.566 8.44 8.44 0 0 1 3.836-1.882 4.3 4.3 0 0 1 2.636.356l.192.092.184-.108a6.2 6.2 0 0 1 3.363-.86 6.24 6.24 0 0 1 3.302 1.084l.431.298.094.064.114.006a6.54 6.54 0 0 1 3.704 1.388 6.9 6.9 0 0 1 2.309 3.318l.028.088.064.067.145.149a4.76 4.76 0 0 1 1.33 3.289 5.38 5.38 0 0 1-1.342 3.596",
                  clipRule: "evenodd",
                })),
              S ||
                (S = R.createElement("path", {
                  fill: "#2C3345",
                  d: "m36.63 24.5 2.182-13.09h2.447l-.358 2.13h.161a4.37 4.37 0 0 1 1.62-1.688q1.031-.613 2.335-.613 1.296 0 2.088.613.802.614 1.048 1.688h.137a4.56 4.56 0 0 1 1.764-1.68q1.134-.621 2.548-.621 1.764 0 2.71 1.125.955 1.116.58 3.358L54.426 24.5H51.87l1.432-8.54q.213-1.338-.409-1.926-.622-.597-1.628-.597-1.245 0-2.062.768-.819.758-1.006 1.951L46.79 24.5h-2.532l1.458-8.702q.17-1.074-.392-1.713-.555-.648-1.62-.648-.723 0-1.406.384a3.6 3.6 0 0 0-1.15 1.057 3.7 3.7 0 0 0-.622 1.551L39.179 24.5zm21.544 4.91q-.58 0-1.031-.095a3 3 0 0 1-.674-.187l.972-2.088q.674.187 1.202.145.537-.043 1.005-.444.47-.4.955-1.26l.477-.862-2.565-13.21h2.625l1.62 10.185h.136l5.011-10.185h2.838l-7.85 14.821q-.554 1.057-1.26 1.756a4.7 4.7 0 0 1-1.569 1.065 4.9 4.9 0 0 1-1.892.358M77.641 5.59V24.5h-3.998V5.59zm10.427 12.336h3.397l1.709 2.198 1.68 1.957 3.167 3.97h-3.73l-2.18-2.677-1.117-1.588zm10.239-2.88q0 3.093-1.173 5.262-1.163 2.17-3.176 3.315-2.003 1.136-4.505 1.136-2.52 0-4.525-1.145-2.002-1.146-3.166-3.315t-1.164-5.253q0-3.094 1.163-5.263t3.167-3.306q2.004-1.145 4.525-1.145 2.502 0 4.505 1.145 2.013 1.136 3.176 3.306 1.173 2.169 1.173 5.263m-4.053 0q0-2.004-.6-3.38-.59-1.376-1.672-2.086-1.08-.711-2.53-.711t-2.53.71-1.68 2.087q-.59 1.376-.59 3.38t.59 3.379q.6 1.375 1.68 2.086t2.53.711 2.53-.71q1.08-.712 1.672-2.087.6-1.376.6-3.38",
                })),
            ),
        ],
        40959,
      ));
  },
  273998,
  38256,
  523615,
  105278,
  (e) => {
    "use strict";
    var t,
      r,
      a,
      n,
      o = e.i(271645);
    function i() {
      return (i = Object.assign.bind()).apply(null, arguments);
    }
    function s() {
      return (s = Object.assign.bind()).apply(null, arguments);
    }
    function l() {
      return (l = Object.assign.bind()).apply(null, arguments);
    }
    (e.s([], 273998),
      e.s(
        [
          "FacebookIcon",
          0,
          (e) =>
            o.createElement(
              "svg",
              i({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 28 29" }, e),
              t ||
                (t = o.createElement("path", {
                  fill: "currentColor",
                  d: "M14 .67c-7.732 0-14 6.268-14 14 0 6.566 4.52 12.075 10.618 13.588v-9.31H7.731V14.67h2.887v-1.843c0-4.765 2.156-6.974 6.835-6.974.887 0 2.417.174 3.043.348v3.878c-.33-.035-.904-.052-1.617-.052-2.296 0-3.183.87-3.183 3.13v1.513h4.573l-.786 4.278h-3.787v9.619C22.628 27.73 28 21.827 28 14.67c0-7.732-6.268-14-14-14",
                })),
            ),
        ],
        38256,
      ),
      e.s(
        [
          "InstagramIcon",
          0,
          (e) =>
            o.createElement(
              "svg",
              s({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 28 29" }, e),
              r ||
                (r = o.createElement("path", {
                  fill: "currentColor",
                  d: "M8.202.768c-1.49.07-2.507.308-3.396.657-.92.359-1.7.84-2.477 1.619a6.9 6.9 0 0 0-1.61 2.48c-.345.892-.578 1.91-.644 3.4s-.08 1.97-.073 5.772c.007 3.8.024 4.278.096 5.772.07 1.489.308 2.506.657 3.396.359.92.84 1.7 1.619 2.477a6.9 6.9 0 0 0 2.483 1.61c.89.344 1.909.579 3.399.644s1.97.08 5.77.073c3.802-.007 4.28-.024 5.774-.095s2.505-.31 3.395-.657c.92-.36 1.7-.84 2.477-1.62a6.85 6.85 0 0 0 1.609-2.483c.345-.89.579-1.91.644-3.398.065-1.494.08-1.971.073-5.773s-.024-4.278-.095-5.771-.308-2.507-.657-3.397a6.9 6.9 0 0 0-1.62-2.477 6.8 6.8 0 0 0-2.482-1.61c-.891-.344-1.91-.58-3.4-.643S17.775.663 13.974.67 9.695.694 8.202.766m.164 25.309c-1.365-.06-2.106-.286-2.6-.476a4.4 4.4 0 0 1-1.612-1.044 4.3 4.3 0 0 1-1.05-1.608c-.192-.494-.423-1.234-.487-2.6-.07-1.474-.084-1.917-.092-5.655s.006-4.18.07-5.656c.059-1.364.287-2.106.477-2.6a4.34 4.34 0 0 1 1.044-1.612 4.3 4.3 0 0 1 1.608-1.05c.493-.193 1.234-.422 2.598-.487 1.476-.07 1.919-.084 5.656-.092s4.18.006 5.658.07c1.364.06 2.106.286 2.599.477.654.252 1.12.555 1.612 1.044s.795.954 1.05 1.609c.194.492.423 1.232.487 2.597.07 1.476.086 1.919.093 5.656s-.006 4.18-.071 5.656c-.06 1.365-.286 2.106-.476 2.6a4.34 4.34 0 0 1-1.045 1.613 4.3 4.3 0 0 1-1.608 1.05c-.493.192-1.234.422-2.597.487-1.476.069-1.92.084-5.657.092s-4.181-.007-5.657-.071M19.779 7.187a1.68 1.68 0 1 0 3.36-.006 1.68 1.68 0 0 0-3.36.006M6.812 14.683a7.19 7.19 0 0 0 14.378-.028 7.19 7.19 0 0 0-14.378.028m2.523-.005a4.667 4.667 0 1 1 9.334-.022 4.667 4.667 0 0 1-9.334.024",
                })),
            ),
        ],
        523615,
      ),
      e.s(
        [
          "RedditIcon",
          0,
          (e) =>
            o.createElement(
              "svg",
              l(
                {
                  xmlns: "http://www.w3.org/2000/svg",
                  fill: "currentColor",
                  className: "RedditIcon_svg__bi RedditIcon_svg__bi-reddit",
                  viewBox: "0 0 16 16",
                },
                e,
              ),
              a ||
                (a = o.createElement("path", {
                  d: "M6.167 8a.83.83 0 0 0-.83.83c0 .459.372.84.83.831a.831.831 0 0 0 0-1.661m1.843 3.647c.315 0 1.403-.038 1.976-.611a.23.23 0 0 0 0-.306.213.213 0 0 0-.306 0c-.353.363-1.126.487-1.67.487-.545 0-1.308-.124-1.671-.487a.213.213 0 0 0-.306 0 .213.213 0 0 0 0 .306c.564.563 1.652.61 1.977.61zm.992-2.807c0 .458.373.83.831.83s.83-.381.83-.83a.831.831 0 0 0-1.66 0z",
                })),
              n ||
                (n = o.createElement("path", {
                  d: "M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.828-1.165c-.315 0-.602.124-.812.325-.801-.573-1.9-.945-3.121-.993l.534-2.501 1.738.372a.83.83 0 1 0 .83-.869.83.83 0 0 0-.744.468l-1.938-.41a.2.2 0 0 0-.153.028.2.2 0 0 0-.086.134l-.592 2.788c-1.24.038-2.358.41-3.17.992-.21-.2-.496-.324-.81-.324a1.163 1.163 0 0 0-.478 2.224q-.03.17-.029.353c0 1.795 2.091 3.256 4.669 3.256s4.668-1.451 4.668-3.256c0-.114-.01-.238-.029-.353.401-.181.688-.592.688-1.069 0-.65-.525-1.165-1.165-1.165",
                })),
            ),
        ],
        105278,
      ));
  },
  976743,
  713008,
  (e) => {
    "use strict";
    var t = e.i(843476);
    (e.s([], 976743),
      e.s(
        [
          "GradientBgComponent",
          0,
          (e) => {
            let { className: r, withoutBlur: a } = e,
              n = a ? "bg-gradient-radial-soft" : "bg-gradient-radial blur-2xl";
            return (0, t.jsxs)("div", {
              className: `fixed inset-0 left-0 top-0 z-[-10] h-full overflow-hidden xs-m:h-dvh ${r || ""}`,
              children: [
                (0, t.jsx)("div", {
                  className: `absolute -right-[37rem] top-[-21rem] -z-10 h-[60rem] w-[60rem] from-green-50/80 ${n}`,
                }),
                (0, t.jsx)("div", {
                  className: `absolute right-[24rem] top-[-10rem] -z-10 h-[94rem] w-[109rem] from-blue-100 ${n}`,
                }),
                (0, t.jsx)("div", {
                  className: `absolute right-[-18rem] top-[20rem] -z-10 h-[40rem] w-[66rem] from-sky-100 ${n}`,
                }),
              ],
            });
          },
        ],
        713008,
      ));
  },
  532262,
  (e) => {
    "use strict";
    var t = e.i(797982);
    e.s(["LangComponent", () => t.default]);
  },
  982363,
  (e) => {
    "use strict";
    var t = e.i(322062);
    e.s([
      "createSupportMailtoLink",
      0,
      (e) => {
        let {
            userEmail: r,
            userId: a,
            subscriptionId: n,
            supportEmail: o = "help@myiq.com",
            subject: i = "Support Request",
          } = e,
          s = { ...e };
        if (!a || !r || !n) {
          let o = t.useUserSupportContextStore.getState();
          s = {
            ...e,
            userId: a || o.userId || void 0,
            userEmail: r || o.email || void 0,
            subscriptionId: n || o.subscriptionId || void 0,
          };
        }
        let l = ((e) => {
            let { userId: t, subscriptionId: r, userEmail: a } = e,
              n = [];
            return (t && n.push(`User ID: ${t}`),
            r && n.push(`Subscription ID: ${r}`),
            a && n.push(`Email: ${a}`),
            0 === n.length)
              ? ""
              : [
                  "=== Please keep this information for faster support ===",
                  ...n,
                  "====================================================",
                ].join("\n");
          })(s),
          c = encodeURIComponent(i),
          d = encodeURIComponent(l);
        return `mailto:${o}?subject=${c}&body=${d}`;
      },
    ]);
  },
  322062,
  (e) => {
    "use strict";
    var t = e.i(768834),
      r = e.i(579473);
    let a = { email: null, userId: null, subscriptionId: null },
      n = (0, t.create)()(
        (0, r.persist)(
          (e) => ({
            ...a,
            handleChangeUserSupportContext: (t) =>
              e((e) => ({
                email: t.email ?? e.email,
                userId: t.userId ?? e.userId,
                subscriptionId: t.subscriptionId ?? e.subscriptionId,
              })),
            clearUserSupportContext: () => e(a),
          }),
          { name: "user_support_context", version: 1 },
        ),
      );
    e.s(["useUserSupportContextStore", 0, n]);
  },
  340609,
  90147,
  (e) => {
    "use strict";
    var t = e.i(23877);
    (e.s([], 340609), e.s(["Spinner", () => t.default], 90147));
  },
  23877,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(112041);
    e.s(["default", 0, (e) => (0, t.jsx)(r.Spinner, { ...e })]);
  },
  38691,
  (e) => {
    "use strict";
    let t = async function (e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 5e3;
      if (!e) return null;
      try {
        return (
          e.reset(),
          await Promise.race([e.executeAsync(), new Promise((e) => setTimeout(() => e(null), t))])
        );
      } catch {
        return null;
      }
    };
    e.s(["executeInvisibleCaptcha", 0, t]);
  },
  360067,
  (e) => {
    "use strict";
    let t = { value: /^[\p{L}\p{M}\s'][\p{L}\p{M}\s'-]*$/u, message: "error_name_format" },
      r = (e) => e.replace(/[\u200E\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g, "");
    e.s([
      "NAME_MAX_LENGTH",
      0,
      35,
      "emailPattern",
      0,
      {
        value:
          /^(?=.{1,311}$)([a-zA-Z0-9_](?:[a-zA-Z0-9_.+-]*(?:\.[a-zA-Z0-9_.+-]+)*[a-zA-Z0-9_])?@[a-zA-Z0-9]+(?:[.-][a-zA-Z0-9]+)*\.[a-zA-Z]{2,})$/,
        message: "error_email_format",
      },
      "getRequiredMessage",
      0,
      (e) => e("error_required_field"),
      "maxLengthPattern",
      0,
      (e, t) => ({ value: RegExp(`^.{2,${e}}$`), message: t("error_max_characters", { count: `${e}` }) }),
      "minLength2Pattern",
      0,
      { value: /^.{2,}$/, message: "error_min_2_characters" },
      "namePattern",
      0,
      t,
      "sanitizeNameInput",
      0,
      r,
      "validateName",
      0,
      (e, a) => {
        let n = r(e);
        return n && n.trim().length > 0 && !t.value.test(n)
          ? a("error_name_format")
          : n.length > 35
            ? a("error_max_characters", { count: "35" })
            : null;
      },
    ]);
  },
]);
