(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  842976,
  835577,
  246399,
  (e) => {
    "use strict";
    var [t, r] = (0, e.i(526823).createContext)({
        name: "PopoverContext",
        errorMessage:
          "usePopoverContext: `context` is undefined. Seems you forgot to wrap all popover components within `<Popover />`",
      }),
      o = e.i(525098),
      n = e.i(271645),
      s = e.i(273830),
      i = e.i(158825),
      a = e.i(88653),
      l = e.i(843476),
      c = (0, s.forwardRef)((e, r) => {
        let { children: s, ...c } = e,
          u = (0, o.usePopover)({ ...c, ref: r }),
          [d, p] = n.Children.toArray(s),
          m = (0, l.jsx)(i.Overlay, { portalContainer: u.portalContainer, children: p });
        return (0, l.jsxs)(t, {
          value: u,
          children: [
            d,
            u.disableAnimation && u.isOpen
              ? m
              : (0, l.jsx)(a.AnimatePresence, { children: u.isOpen ? m : null }),
          ],
        });
      });
    ((c.displayName = "HeroUI.Popover"), e.s(["Popover", 0, c], 842976));
    var u = e.i(560623),
      d = e.i(520947),
      p = e.i(824511),
      m = e.i(444113),
      h = e.i(366784),
      g = e.i(482008),
      v = () => e.A(475977).then((e) => e.default),
      f = (e) => {
        let { as: t, children: o, className: s, ...i } = e,
          {
            Component: a,
            placement: c,
            backdrop: f,
            motionProps: y,
            disableAnimation: b,
            getPopoverProps: x,
            getDialogProps: k,
            getBackdropProps: _,
            getContentProps: S,
            isNonModal: C,
            onClose: E,
          } = r(),
          w = (0, n.useRef)(null),
          { dialogProps: T, titleProps: P } = (0, g.useDialog)({}, w),
          N = k({ ref: w, ...T, ...i }),
          I =
            o &&
            (0, l.jsxs)(l.Fragment, {
              children: [
                !C && (0, l.jsx)(u.DismissButton, { onDismiss: E }),
                (0, l.jsx)(t || a || "div", {
                  ...N,
                  children: (0, l.jsx)("div", {
                    ...S({ className: s }),
                    children: "function" == typeof o ? o(P) : o,
                  }),
                }),
                (0, l.jsx)(u.DismissButton, { onDismiss: E }),
              ],
            }),
          L = (0, n.useMemo)(
            () =>
              "transparent" === f
                ? null
                : b
                  ? (0, l.jsx)("div", { ..._() })
                  : (0, l.jsx)(m.LazyMotion, {
                      features: v,
                      children: (0, l.jsx)(p.m.div, {
                        animate: "enter",
                        exit: "exit",
                        initial: "exit",
                        variants: d.TRANSITION_VARIANTS.fade,
                        ..._(),
                      }),
                    }),
            [f, b, _],
          ),
          j = c ? (0, h.getTransformOrigins)("center" === c ? "top" : c) : void 0,
          R = (0, l.jsx)(l.Fragment, {
            children: b
              ? I
              : (0, l.jsx)(m.LazyMotion, {
                  features: v,
                  children: (0, l.jsx)(p.m.div, {
                    animate: "enter",
                    exit: "exit",
                    initial: "initial",
                    style: j,
                    variants: d.TRANSITION_VARIANTS.scaleSpringOpacity,
                    ...y,
                    children: I,
                  }),
                }),
          });
        return (0, l.jsxs)("div", { ...x(), children: [L, R] });
      };
    ((f.displayName = "HeroUI.PopoverContent"), e.s(["PopoverContent", 0, f], 835577));
    var y = e.i(868319),
      b = e.i(335889),
      x = e.i(75540),
      k = (e) => {
        var t, o, s;
        let i,
          { triggerRef: a, getTriggerProps: c } = r(),
          { children: u, ...d } = e,
          p = (0, n.useMemo)(
            () => ("string" == typeof u ? (0, l.jsx)("p", { children: u }) : n.Children.only(u)),
            [u],
          ),
          m = null != (t = p.props.ref) ? t : p.ref,
          {
            onPress: h,
            isDisabled: g,
            ...v
          } = (0, n.useMemo)(() => c((0, x.mergeProps)(d, p.props), m), [c, p.props, d, m]),
          [, f] =
            ((o = b.Button),
            (i = []),
            [
              null ==
              (s = n.Children.map(u, (e) =>
                (0, n.isValidElement)(e) && e.type === o ? (i.push(e), null) : e,
              ))
                ? void 0
                : s.filter(Boolean),
              i.length >= 0 ? i : void 0,
            ]),
          { buttonProps: k } = (0, y.useAriaButton)({ onPress: h, isDisabled: g }, a),
          _ = (0, n.useMemo)(() => (null == f ? void 0 : f[0]) !== void 0, [f]);
        return (
          _ || delete v.preventFocusOnPress,
          (0, n.cloneElement)(p, (0, x.mergeProps)(v, _ ? { onPress: h, isDisabled: g } : k))
        );
      };
    ((k.displayName = "HeroUI.PopoverTrigger"), e.s(["PopoverTrigger", 0, k], 246399));
  },
  484656,
  692784,
  (e) => {
    "use strict";
    var t = e.i(278242),
      r = e.i(68334),
      o = e.i(847411),
      n = e.i(341240),
      s = e.i(596299),
      i = e.i(977188),
      a = e.i(700864),
      l = e.i(343027),
      c = e.i(548121),
      u = e.i(934203),
      d = e.i(514480),
      p = e.i(116914),
      m = e.i(271645);
    let h = 0,
      g = new Map();
    var v = e.i(47682);
    function f(e) {
      let {
          isDisabled: t,
          onLongPressStart: r,
          onLongPressEnd: o,
          onLongPress: n,
          threshold: s = 500,
          accessibilityDescription: i,
        } = e,
        a = (0, m.useRef)(void 0),
        { addGlobalListener: f, removeGlobalListener: y } = (0, c.useGlobalListeners)(),
        { pressProps: b } = (0, l.usePress)({
          isDisabled: t,
          onPressStart(e) {
            if (
              (e.continuePropagation(),
              ("mouse" === e.pointerType || "touch" === e.pointerType) &&
                (r && r({ ...e, type: "longpressstart" }),
                (a.current = setTimeout(() => {
                  (e.target.dispatchEvent(new PointerEvent("pointercancel", { bubbles: !0 })),
                    (0, u.getOwnerDocument)(e.target).activeElement !== e.target &&
                      (0, d.focusWithoutScrolling)(e.target),
                    n && n({ ...e, type: "longpress" }),
                    (a.current = void 0));
                }, s)),
                "touch" === e.pointerType))
            ) {
              let t = (e) => {
                e.preventDefault();
              };
              (f(e.target, "contextmenu", t, { once: !0 }),
                f(
                  window,
                  "pointerup",
                  () => {
                    setTimeout(() => {
                      y(e.target, "contextmenu", t);
                    }, 30);
                  },
                  { once: !0 },
                ));
            }
          },
          onPressEnd(e) {
            (a.current && clearTimeout(a.current),
              o &&
                ("mouse" === e.pointerType || "touch" === e.pointerType) &&
                o({ ...e, type: "longpressend" }));
          },
        }),
        x = (function (e) {
          let [t, r] = (0, m.useState)();
          return (
            (0, p.useLayoutEffect)(() => {
              if (!e) return;
              let t = g.get(e);
              if (t) r(t.element.id);
              else {
                let o = `react-aria-description-${h++}`;
                r(o);
                let n = document.createElement("div");
                ((n.id = o),
                  (n.style.display = "none"),
                  (n.textContent = e),
                  document.body.appendChild(n),
                  (t = { refCount: 0, element: n }),
                  g.set(e, t));
              }
              return (
                t.refCount++,
                () => {
                  t && 0 == --t.refCount && (t.element.remove(), g.delete(e));
                }
              );
            }, [e]),
            { "aria-describedby": e ? t : void 0 }
          );
        })(n && !t ? i : void 0);
      return { longPressProps: (0, v.mergeProps)(b, x) };
    }
    e.s(["useLongPress", 0, f], 692784);
    var y = e.i(520111);
    function b() {
      let e = window.event;
      return (null == e ? void 0 : e.key) === "Enter";
    }
    function x() {
      let e = window.event;
      return (null == e ? void 0 : e.key) === " " || (null == e ? void 0 : e.code) === "Space";
    }
    e.s(
      [
        "useSelectableItem",
        0,
        function (e) {
          let {
              id: c,
              selectionManager: u,
              key: d,
              ref: p,
              shouldSelectOnPressUp: h,
              shouldUseVirtualFocus: g,
              focus: v,
              isDisabled: k,
              onAction: _,
              allowsDifferentPressOrigin: S,
              linkBehavior: C = "action",
            } = e,
            E = (0, r.useRouter)();
          c = (0, o.useId)(c);
          let w = (e) => {
            if ("keyboard" === e.pointerType && (0, t.isNonContiguousSelectionModifier)(e))
              u.toggleSelection(d);
            else {
              if ("none" === u.selectionMode) return;
              if (u.isLink(d)) {
                if ("selection" === C && p.current) {
                  let t = u.getItemProps(d);
                  (E.open(p.current, e, t.href, t.routerOptions), u.setSelectedKeys(u.selectedKeys));
                  return;
                } else if ("override" === C || "none" === C) return;
              }
              "single" === u.selectionMode
                ? u.isSelected(d) && !u.disallowEmptySelection
                  ? u.toggleSelection(d)
                  : u.replaceSelection(d)
                : e && e.shiftKey
                  ? u.extendSelection(d)
                  : "toggle" === u.selectionBehavior ||
                      (e &&
                        ((0, n.isCtrlKeyPressed)(e) ||
                          "touch" === e.pointerType ||
                          "virtual" === e.pointerType))
                    ? u.toggleSelection(d)
                    : u.replaceSelection(d);
            }
          };
          ((0, m.useEffect)(() => {
            d === u.focusedKey &&
              u.isFocused &&
              (g
                ? (0, y.moveVirtualFocus)(p.current)
                : v
                  ? v()
                  : document.activeElement !== p.current && p.current && (0, a.focusSafely)(p.current));
          }, [p, d, u.focusedKey, u.childFocusStrategy, u.isFocused, g]),
            (k = k || u.isDisabled(d)));
          let T = {};
          g || k
            ? k &&
              (T.onMouseDown = (e) => {
                e.preventDefault();
              })
            : (T = {
                tabIndex: d === u.focusedKey ? 0 : -1,
                onFocus(e) {
                  e.target === p.current && u.setFocusedKey(d);
                },
              });
          let P = u.isLink(d) && "override" === C,
            N = _ && "action" === e.UNSTABLE_itemBehavior,
            I = u.isLink(d) && "selection" !== C && "none" !== C,
            L = !k && u.canSelectItem(d) && !P && !N,
            j = (_ || I) && !k,
            R = j && ("replace" === u.selectionBehavior ? !L : !L || u.isEmpty),
            A = j && L && "replace" === u.selectionBehavior,
            D = R || A,
            K = (0, m.useRef)(null),
            M = D && L,
            U = (0, m.useRef)(!1),
            O = (0, m.useRef)(!1),
            B = u.getItemProps(d),
            F = (e) => {
              if (_) {
                var t;
                (_(),
                  null == (t = p.current) ||
                    t.dispatchEvent(new CustomEvent("react-aria-item-action", { bubbles: !0 })));
              }
              I && p.current && E.open(p.current, e, B.href, B.routerOptions);
            },
            H = { ref: p };
          if (
            (h
              ? ((H.onPressStart = (e) => {
                  ((K.current = e.pointerType),
                    (U.current = M),
                    "keyboard" === e.pointerType && (!D || x()) && w(e));
                }),
                S
                  ? ((H.onPressUp = R
                      ? void 0
                      : (e) => {
                          "mouse" === e.pointerType && L && w(e);
                        }),
                    (H.onPress = R
                      ? F
                      : (e) => {
                          "keyboard" !== e.pointerType && "mouse" !== e.pointerType && L && w(e);
                        }))
                  : (H.onPress = (e) => {
                      R || (A && "mouse" !== e.pointerType)
                        ? ("keyboard" !== e.pointerType || b()) && F(e)
                        : "keyboard" !== e.pointerType && L && w(e);
                    }))
              : ((H.onPressStart = (e) => {
                  ((K.current = e.pointerType),
                    (U.current = M),
                    (O.current = R),
                    L &&
                      (("mouse" === e.pointerType && !R) || ("keyboard" === e.pointerType && (!j || x()))) &&
                      w(e));
                }),
                (H.onPress = (e) => {
                  ("touch" === e.pointerType ||
                    "pen" === e.pointerType ||
                    "virtual" === e.pointerType ||
                    ("keyboard" === e.pointerType && D && b()) ||
                    ("mouse" === e.pointerType && O.current)) &&
                    (D ? F(e) : L && w(e));
                })),
            (T["data-collection"] = (0, t.getCollectionId)(u.collection)),
            (T["data-key"] = d),
            (H.preventFocusOnPress = g),
            g &&
              (H = (0, s.mergeProps)(H, {
                onPressStart(e) {
                  "touch" !== e.pointerType && (u.setFocused(!0), u.setFocusedKey(d));
                },
                onPress(e) {
                  "touch" === e.pointerType && (u.setFocused(!0), u.setFocusedKey(d));
                },
              })),
            B)
          )
            for (let e of ["onPressStart", "onPressEnd", "onPressChange", "onPress", "onPressUp", "onClick"])
              B[e] && (H[e] = (0, i.chain)(H[e], B[e]));
          let { pressProps: q, isPressed: z } = (0, l.usePress)(H),
            W = A
              ? (e) => {
                  "mouse" === K.current && (e.stopPropagation(), e.preventDefault(), F(e));
                }
              : void 0,
            { longPressProps: G } = f({
              isDisabled: !M,
              onLongPress(e) {
                "touch" === e.pointerType && (w(e), u.setSelectionBehavior("toggle"));
              },
            }),
            V =
              "none" !== C && u.isLink(d)
                ? (e) => {
                    r.openLink.isOpening || e.preventDefault();
                  }
                : void 0;
          return {
            itemProps: (0, s.mergeProps)(
              T,
              L || R || (g && !k) ? q : {},
              M ? G : {},
              {
                onDoubleClick: W,
                onDragStartCapture: (e) => {
                  "touch" === K.current && U.current && e.preventDefault();
                },
                onClick: V,
                id: c,
              },
              g ? { onMouseDown: (e) => e.preventDefault() } : void 0,
            ),
            isPressed: z,
            isSelected: u.isSelected(d),
            isFocused: u.isFocused && u.focusedKey === d,
            isDisabled: k,
            allowsSelection: L,
            hasAction: D,
          };
        },
      ],
      484656,
    );
  },
  664659,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("chevron-down", [["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]]);
    e.s(["ChevronDown", 0, t], 664659);
  },
  436992,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(948148);
    e.i(273998);
    var o = e.i(38256),
      n = e.i(523615),
      s = e.i(105278);
    e.i(872721);
    var i = e.i(652050);
    e.i(872756);
    var a = e.i(987132);
    e.i(83029);
    var l = e.i(40959);
    e.i(203068);
    var c = e.i(532262),
      u = e.i(202042);
    let d = [
        {
          titleKey: "ab_myiq_home_redesign_footer_col_product_title",
          links: [
            {
              labelKey: "ab_myiq_home_redesign_footer_link_how_it_works",
              href: "/#how-it-works",
              trackingName: "How it works",
            },
            {
              labelKey: "ab_myiq_home_redesign_footer_link_courses",
              href: "/#courses",
              trackingName: "Courses",
            },
            { labelKey: "nav_reviews", href: "/#reviews", trackingName: "Reviews" },
            { labelKey: "nav_pricing", href: "/#pricing", trackingName: "Pricing" },
            { labelKey: "ab_myiq_home_redesign_footer_link_faq", href: "/#faq", trackingName: "FAQ" },
          ],
        },
        {
          titleKey: "ab_myiq_home_redesign_footer_col_support_title",
          links: [
            { labelKey: "nav_help", href: "/help", trackingName: "Help" },
            {
              labelKey: "ab_myiq_home_redesign_footer_link_how_to_cancel",
              href: "/cancellation/auth",
              trackingName: "How to cancel",
              event: "how-to-cancel",
            },
            {
              labelKey: "ab_myiq_home_redesign_footer_link_contact",
              href: e.i(134404).EClientRoutes.CONTACT_SUPPORT,
              trackingName: "Contact",
              event: "contact-support",
            },
          ],
        },
        {
          titleKey: "nav_title_legal",
          links: [
            { labelKey: "nav_privacy_policy", href: "/privacy", trackingName: "Privacy Policy" },
            {
              labelKey: "ab_myiq_home_redesign_footer_link_terms",
              href: "/terms",
              trackingName: "Terms of Service",
            },
            { labelKey: "nav_cookie_policy", href: "/cookie", trackingName: "Cookie Policy" },
            { labelKey: "nav_refund", href: "/terms#refund-policy", trackingName: "Refund Policy" },
          ],
        },
      ],
      p = ["ab_myiq_home_redesign_footer_legal_copyright", "ab_myiq_home_redesign_footer_legal_disclaimer"],
      m = [
        { id: "instagram", label: "Instagram", href: "https://www.instagram.com/myiq_com" },
        { id: "facebook", label: "Facebook", href: "https://www.facebook.com/MyIQapp" },
        { id: "reddit", label: "Reddit", href: "https://www.reddit.com/r/MyIQ_Official/" },
      ],
      h = {
        instagram: (0, t.jsx)(n.InstagramIcon, {
          "aria-hidden": !0,
          viewBox: "0 0 28 29",
          className: "size-4",
        }),
        facebook: (0, t.jsx)(o.FacebookIcon, {
          "aria-hidden": !0,
          viewBox: "0 0 28 29",
          className: "size-4",
        }),
        reddit: (0, t.jsx)(s.RedditIcon, { "aria-hidden": !0, viewBox: "0 0 16 16", className: "size-4" }),
      },
      g = () =>
        (0, t.jsxs)("svg", {
          "aria-hidden": !0,
          viewBox: "0 0 16 16",
          fill: "none",
          focusable: "false",
          className: "size-4 shrink-0",
          children: [
            (0, t.jsx)("circle", {
              cx: "8",
              cy: "8",
              r: "6.25",
              stroke: "currentColor",
              strokeWidth: "1.25",
            }),
            (0, t.jsx)("path", {
              d: "M1.75 8h12.5M8 1.75c1.8 1.7 2.75 3.9 2.75 6.25S9.8 12.55 8 14.25M8 1.75c-1.8 1.7-2.75 3.9-2.75 6.25s.95 4.55 2.75 6.25",
              stroke: "currentColor",
              strokeWidth: "1.25",
            }),
          ],
        });
    e.s(
      [
        "default",
        0,
        (e) => {
          let { translatedByKey: o, preserveSearchParams: n } = e,
            s = (0, r.useTranslations)(),
            v = (e) => o?.[e] ?? s(e),
            {
              trackFooterLink: f,
              trackHowToCancel: y,
              trackContactSupport: b,
            } = (0, i.useDemoHomeTracking)();
          return (0, t.jsx)("footer", {
            id: "footer",
            className: "w-full border-t border-slate-200 bg-white pb-12 pt-8 sm:pt-16 lg:pb-16 lg:pt-24",
            children: (0, t.jsx)(a.DemoContainer, {
              children: (0, t.jsxs)("div", {
                className: "flex flex-col gap-12",
                children: [
                  (0, t.jsx)("h2", {
                    className: "sr-only",
                    children: v("ab_myiq_home_redesign_footer_heading"),
                  }),
                  (0, t.jsxs)("div", {
                    className: "grid grid-cols-2 gap-10 md:grid-cols-[1.5fr_1fr_1fr_1fr] lg:gap-12",
                    children: [
                      (0, t.jsxs)("div", {
                        className: "col-span-2 flex flex-col gap-4 md:col-span-1",
                        children: [
                          (0, t.jsxs)(u.Link, {
                            href: "/#demo-top",
                            className: "flex items-center gap-2",
                            children: [
                              (0, t.jsx)(l.IconLogoDark, {
                                "aria-hidden": !0,
                                viewBox: "0 0 108 31",
                                className: "h-7 w-auto",
                              }),
                              (0, t.jsx)("span", { className: "sr-only", children: "MyIQ" }),
                            ],
                          }),
                          (0, t.jsx)("ul", {
                            className: "mt-1 flex items-center gap-3",
                            children: m.map((e) =>
                              (0, t.jsx)(
                                "li",
                                {
                                  children: (0, t.jsx)("a", {
                                    href: e.href,
                                    target: "_blank",
                                    rel: "noreferrer",
                                    "aria-label": e.label,
                                    className:
                                      "flex size-9 items-center justify-center rounded-full border border-slate-200 text-grey-deep transition-colors duration-150 [@media(hover:hover)]:hover:border-slate-300 [@media(hover:hover)]:hover:text-black-custom",
                                    children: h[e.id],
                                  }),
                                },
                                e.id,
                              ),
                            ),
                          }),
                        ],
                      }),
                      d.map((e) =>
                        (0, t.jsxs)(
                          "div",
                          {
                            children: [
                              (0, t.jsx)("h3", {
                                className: "text-hp-eyebrow uppercase text-grey-light",
                                children: v(e.titleKey),
                              }),
                              (0, t.jsx)("ul", {
                                className: "mt-4 flex flex-col gap-3",
                                children: e.links.map((e) =>
                                  (0, t.jsx)(
                                    "li",
                                    {
                                      children: (0, t.jsx)("a", {
                                        href: e.href,
                                        onClick: () =>
                                          "how-to-cancel" === e.event
                                            ? y()
                                            : "contact-support" === e.event
                                              ? b()
                                              : void f(e.trackingName),
                                        className:
                                          "text-hp-body-sm text-grey-deep transition-colors duration-150 [@media(hover:hover)]:hover:text-black-custom",
                                        children: v(e.labelKey),
                                      }),
                                    },
                                    e.labelKey,
                                  ),
                                ),
                              }),
                            ],
                          },
                          e.titleKey,
                        ),
                      ),
                    ],
                  }),
                  (0, t.jsxs)("div", {
                    className:
                      "flex flex-col gap-6 border-t border-slate-200 pt-8 md:flex-row md:items-start md:justify-between md:gap-10",
                    children: [
                      (0, t.jsx)("div", {
                        className: "flex flex-col gap-3",
                        children: p.map((e) =>
                          (0, t.jsx)(
                            "p",
                            {
                              className: "max-w-3xl text-pretty text-hp-caption text-grey-light",
                              children: v(e),
                            },
                            e,
                          ),
                        ),
                      }),
                      (0, t.jsx)(c.LangComponent, {
                        placement: "top",
                        className:
                          "h-9 !min-w-0 shrink-0 gap-2 self-start rounded-full border border-slate-200 bg-transparent px-4 text-hp-body-sm text-grey-deep data-[hover=true]:border-slate-300 data-[hover=true]:bg-transparent",
                        arrowClassName: "size-4 !text-grey-light",
                        triggerIcon: (0, t.jsx)(g, {}),
                        shouldBlockScroll: !1,
                        preserveSearchParams: n,
                      }),
                    ],
                  }),
                ],
              }),
            }),
          });
        },
      ],
      436992,
    );
  },
  872721,
  652050,
  (e) => {
    "use strict";
    var t = e.i(271645),
      r = e.i(866897),
      o = e.i(157273),
      n = e.i(86596),
      s = e.i(924254),
      i = e.i(60423),
      a = e.i(523173),
      l = e.i(134404);
    e.i(470366);
    var c = e.i(504001),
      u = e.i(202042);
    (e.s(
      [
        "useDemoHomeTracking",
        0,
        () => {
          let e = (0, u.useRouter)(),
            d = (0, n.useUserStore)((e) => e.user),
            p = (0, n.useUserStore)((e) => e.handleChangeUserStore),
            m = (0, t.useCallback)(
              (e) => {
                (0, c.trackClientEvents)({
                  event: a.EAnalyticEvents.PAGE_CLICKED,
                  params: e,
                  sessionId: d?.id,
                  user: d,
                });
              },
              [d],
            ),
            h = (0, t.useCallback)(
              (t) => {
                (m({
                  page_name: "startCertifiedTestButtonClicked",
                  page_title: "Start",
                  ...(t && { gender: t }),
                }),
                  (0, c.trackClientEvents)({
                    event: a.EAnalyticEvents.FUNNEL_START_VIEW,
                    sessionId: d?.id,
                    user: d,
                  }),
                  (0, c.setPeopleAnalytic)({ funnel: "myiq", ...(t && { gender: t }) }),
                  i.accessLocalStorage.removeItem(o.StorageKeys.LOVE_LANGUAGE_QUIZ_ANSWERS),
                  i.accessLocalStorage.removeItem(o.StorageKeys.PERSONALITY_QUIZ_ANSWERS),
                  i.accessLocalStorage.removeItem(o.StorageKeys.QUIZ_ANSWERS),
                  s.accessCookie.removeItem(r.ECookieArg.LEGACY_FUNNEL),
                  p({
                    user: {
                      nextBillingDate: void 0,
                      billingSubscriptionData: void 0,
                      paynextSubscription: void 0,
                      paymentInfo: void 0,
                      isPaynextSubscribed: void 0,
                      ...(t && { gender: t }),
                    },
                  }),
                  e.push(l.EClientRoutes.QUIZ));
              },
              [m, d, p, e],
            ),
            g = (0, t.useCallback)(() => m({ page_name: "loginButtonClicked" }), [m]),
            v = (0, t.useCallback)((e) => m({ page_name: `${e}LinkClicked` }), [m]);
          return {
            startFunnel: h,
            trackLogin: g,
            trackFooterLink: v,
            trackHowToCancel: (0, t.useCallback)(() => {
              (0, c.trackClientEvents)({
                event: a.EAnalyticEvents.CANCEL_FLOW_HOW_TO_CANCEL_BUTTON_CLICKED,
                sessionId: d?.id,
              });
            }, [d]),
            trackContactSupport: (0, t.useCallback)(() => {
              (0, c.trackClientEvents)({
                event: a.EAnalyticEvents.CANCEL_FLOW_CONTACT_SUPPORT_BUTTON_CLICKED,
                sessionId: d?.id,
              });
            }, [d]),
          };
        },
      ],
      652050,
    ),
      e.s([], 872721));
  },
  273998,
  38256,
  523615,
  105278,
  (e) => {
    "use strict";
    var t,
      r,
      o,
      n,
      s = e.i(271645);
    function i() {
      return (i = Object.assign.bind()).apply(null, arguments);
    }
    function a() {
      return (a = Object.assign.bind()).apply(null, arguments);
    }
    function l() {
      return (l = Object.assign.bind()).apply(null, arguments);
    }
    (e.s([], 273998),
      e.s(
        [
          "FacebookIcon",
          0,
          (e) =>
            s.createElement(
              "svg",
              i({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 28 29" }, e),
              t ||
                (t = s.createElement("path", {
                  fill: "currentColor",
                  d: "M14 .67c-7.732 0-14 6.268-14 14 0 6.566 4.52 12.075 10.618 13.588v-9.31H7.731V14.67h2.887v-1.843c0-4.765 2.156-6.974 6.835-6.974.887 0 2.417.174 3.043.348v3.878c-.33-.035-.904-.052-1.617-.052-2.296 0-3.183.87-3.183 3.13v1.513h4.573l-.786 4.278h-3.787v9.619C22.628 27.73 28 21.827 28 14.67c0-7.732-6.268-14-14-14",
                })),
            ),
        ],
        38256,
      ),
      e.s(
        [
          "InstagramIcon",
          0,
          (e) =>
            s.createElement(
              "svg",
              a({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 28 29" }, e),
              r ||
                (r = s.createElement("path", {
                  fill: "currentColor",
                  d: "M8.202.768c-1.49.07-2.507.308-3.396.657-.92.359-1.7.84-2.477 1.619a6.9 6.9 0 0 0-1.61 2.48c-.345.892-.578 1.91-.644 3.4s-.08 1.97-.073 5.772c.007 3.8.024 4.278.096 5.772.07 1.489.308 2.506.657 3.396.359.92.84 1.7 1.619 2.477a6.9 6.9 0 0 0 2.483 1.61c.89.344 1.909.579 3.399.644s1.97.08 5.77.073c3.802-.007 4.28-.024 5.774-.095s2.505-.31 3.395-.657c.92-.36 1.7-.84 2.477-1.62a6.85 6.85 0 0 0 1.609-2.483c.345-.89.579-1.91.644-3.398.065-1.494.08-1.971.073-5.773s-.024-4.278-.095-5.771-.308-2.507-.657-3.397a6.9 6.9 0 0 0-1.62-2.477 6.8 6.8 0 0 0-2.482-1.61c-.891-.344-1.91-.58-3.4-.643S17.775.663 13.974.67 9.695.694 8.202.766m.164 25.309c-1.365-.06-2.106-.286-2.6-.476a4.4 4.4 0 0 1-1.612-1.044 4.3 4.3 0 0 1-1.05-1.608c-.192-.494-.423-1.234-.487-2.6-.07-1.474-.084-1.917-.092-5.655s.006-4.18.07-5.656c.059-1.364.287-2.106.477-2.6a4.34 4.34 0 0 1 1.044-1.612 4.3 4.3 0 0 1 1.608-1.05c.493-.193 1.234-.422 2.598-.487 1.476-.07 1.919-.084 5.656-.092s4.18.006 5.658.07c1.364.06 2.106.286 2.599.477.654.252 1.12.555 1.612 1.044s.795.954 1.05 1.609c.194.492.423 1.232.487 2.597.07 1.476.086 1.919.093 5.656s-.006 4.18-.071 5.656c-.06 1.365-.286 2.106-.476 2.6a4.34 4.34 0 0 1-1.045 1.613 4.3 4.3 0 0 1-1.608 1.05c-.493.192-1.234.422-2.597.487-1.476.069-1.92.084-5.657.092s-4.181-.007-5.657-.071M19.779 7.187a1.68 1.68 0 1 0 3.36-.006 1.68 1.68 0 0 0-3.36.006M6.812 14.683a7.19 7.19 0 0 0 14.378-.028 7.19 7.19 0 0 0-14.378.028m2.523-.005a4.667 4.667 0 1 1 9.334-.022 4.667 4.667 0 0 1-9.334.024",
                })),
            ),
        ],
        523615,
      ),
      e.s(
        [
          "RedditIcon",
          0,
          (e) =>
            s.createElement(
              "svg",
              l(
                {
                  xmlns: "http://www.w3.org/2000/svg",
                  fill: "currentColor",
                  className: "RedditIcon_svg__bi RedditIcon_svg__bi-reddit",
                  viewBox: "0 0 16 16",
                },
                e,
              ),
              o ||
                (o = s.createElement("path", {
                  d: "M6.167 8a.83.83 0 0 0-.83.83c0 .459.372.84.83.831a.831.831 0 0 0 0-1.661m1.843 3.647c.315 0 1.403-.038 1.976-.611a.23.23 0 0 0 0-.306.213.213 0 0 0-.306 0c-.353.363-1.126.487-1.67.487-.545 0-1.308-.124-1.671-.487a.213.213 0 0 0-.306 0 .213.213 0 0 0 0 .306c.564.563 1.652.61 1.977.61zm.992-2.807c0 .458.373.83.831.83s.83-.381.83-.83a.831.831 0 0 0-1.66 0z",
                })),
              n ||
                (n = s.createElement("path", {
                  d: "M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.828-1.165c-.315 0-.602.124-.812.325-.801-.573-1.9-.945-3.121-.993l.534-2.501 1.738.372a.83.83 0 1 0 .83-.869.83.83 0 0 0-.744.468l-1.938-.41a.2.2 0 0 0-.153.028.2.2 0 0 0-.086.134l-.592 2.788c-1.24.038-2.358.41-3.17.992-.21-.2-.496-.324-.81-.324a1.163 1.163 0 0 0-.478 2.224q-.03.17-.029.353c0 1.795 2.091 3.256 4.669 3.256s4.668-1.451 4.668-3.256c0-.114-.01-.238-.029-.353.401-.181.688-.592.688-1.069 0-.65-.525-1.165-1.165-1.165",
                })),
            ),
        ],
        105278,
      ));
  },
  203068,
  797982,
  (e) => {
    "use strict";
    var t = e.i(843476),
      r = e.i(664659),
      o = e.i(861745),
      n = e.i(271645),
      s = e.i(335889),
      i = e.i(133716),
      a = e.i(272412),
      l = e.i(276331),
      c = e.i(372853);
    e.i(743893);
    var u = e.i(852016),
      d = e.i(382963),
      p = e.i(275711),
      m = e.i(622963),
      h = e.i(785023),
      g = e.i(202042),
      v = e.i(19576);
    (e.s(
      [
        "default",
        0,
        (e) => {
          let {
              className: f,
              startContent: y,
              theme: b,
              baseClassName: x,
              menuClassName: k,
              arrowClassName: _,
              userEmail: S,
              placement: C = "top",
              onLanguageDropdownOpened: E,
              triggerScaleOnOpen: w = !0,
              compact: T,
              triggerIcon: P,
              shouldBlockScroll: N = !0,
              preserveSearchParams: I = !1,
              matchTriggerWidth: L = !1,
            } = e,
            j = (0, o.useLocale)(),
            R = (0, g.useRouter)(),
            A = (0, g.usePathname)(),
            D = (0, n.useRef)(null),
            [K, M] = (0, n.useState)(!1),
            [U, O] = (0, n.useState)(void 0),
            B = "u" > typeof navigator && navigator.userAgent.toLowerCase().includes("firefox"),
            { trigger: F } = (0, d.useUpdateUserInDatabaseMutation)(),
            { showBackdrop: H, hideBackdrop: q, setPendingLocale: z, pendingLocale: W } = (0, h.useUiStore)(),
            G = (0, m.useModalStore)((e) => e.isModalVisible);
          (0, n.useEffect)(() => {
            W && W === j && (q(), z(null));
          }, [j, W, q, z]);
          let V = async (e) => {
              if (e === j) return;
              (z(e), H(), sessionStorage.setItem("quiz-language-change", "true"));
              try {
                (document.documentElement.setAttribute("lang", e),
                  document.documentElement.setAttribute("dir", (0, v.getLocaleDirection)(e)));
              } catch {
                return;
              }
              let t = I
                ? { pathname: A, query: Object.fromEntries(new URLSearchParams(window.location.search)) }
                : { pathname: A };
              try {
                R.prefetch(t, { locale: e });
              } catch {
                return;
              }
              ((0, n.startTransition)(() => {
                R.replace(t, { locale: e, scroll: !1 });
              }),
                setTimeout(() => {
                  let { pendingLocale: t } = h.useUiStore.getState();
                  t === e &&
                    (h.useUiStore.getState().setPendingLocale(null), h.useUiStore.getState().hideBackdrop());
                }, 4e3),
                S && F({ email: S, userInfo: { locale: e } }).catch(() => {}));
            },
            $ = (0, n.useCallback)(
              (e) => {
                (V(e.currentKey), M(!1));
              },
              [j, A, V],
            );
          return (
            (0, n.useEffect)(() => {
              let e = document.body,
                t = document.documentElement;
              if (K && G) {
                ((e.style.overflow = "hidden"),
                  (e.style.touchAction = "none"),
                  (t.style.overflow = "hidden"));
                let r = (e) => {
                  e.preventDefault();
                };
                return (
                  document.addEventListener("touchmove", r, !1),
                  document.addEventListener("touchstart", r, !1),
                  () => {
                    (document.removeEventListener("touchmove", r),
                      document.removeEventListener("touchstart", r));
                  }
                );
              }
            }, [K, G]),
            (0, t.jsxs)(i.Dropdown, {
              classNames: { base: `rounded-large ${x || ""}`, content: "!min-w-fit xs-base:!min-w-[200px]" },
              placement: C,
              isOpen: K,
              onOpenChange: (e) => {
                (M(e), e && L && D.current && O(D.current.offsetWidth - 8), e && E?.());
              },
              closeOnSelect: !0,
              shouldBlockScroll: N && !B,
              triggerScaleOnOpen: w,
              children: [
                (0, t.jsx)(c.DropdownTrigger, {
                  children: (0, t.jsx)(s.Button, {
                    ref: D,
                    variant: "bordered",
                    className: `group h-[50px] border-1 !border-default-300 ${T ? "h-[40px] min-w-10 gap-1 px-2" : "min-w-32"} ${T && "rtl" === (0, v.getLocaleDirection)(j) ? "ml-4" : ""} w-auto justify-between text-white ${f || ""}`,
                    startContent: y,
                    disableRipple: !0,
                    disableAnimation: !0,
                    endContent: (0, t.jsx)(r.ChevronDown, {
                      size: 20,
                      strokeWidth: 1.25,
                      className: `shrink-0 transform cursor-pointer ${_} ${"light" === b ? "text-black" : "text-white"} outline-none transition-transform duration-300 ease-in-out ${K ? "rotate-180" : ""} ${"rtl" === (0, v.getLocaleDirection)(j) ? "mr-auto" : "ml-auto"}`,
                    }),
                    children: (0, t.jsxs)("span", {
                      className: "flex max-w-full items-center gap-1.5 overflow-hidden truncate",
                      children: [
                        P ??
                          (0, t.jsx)(u.Flag, {
                            className: "inline-block h-3 w-[20px] shrink-0 rounded-sm object-cover",
                            code: p.langToCountryCodeMap[j] || "USA",
                            alt: p.langToCountryCodeMap[j] || "USA",
                          }),
                        (0, t.jsx)("span", {
                          className: "truncate",
                          children: T ? p.twoSymbolLangMap[j] : p.languageName[j],
                        }),
                      ],
                    }),
                  }),
                }),
                (0, t.jsx)(l.DropdownMenu, {
                  "aria-label": "Select Language",
                  selectionMode: "single",
                  selectedKeys: [j],
                  className: `${k} max-h-[50vh] overflow-y-auto overflow-x-hidden`,
                  style: U ? { width: U } : void 0,
                  onSelectionChange: $,
                  closeOnSelect: !0,
                  autoFocus: !1,
                  children: Object.entries(p.languageName).map((e) => {
                    let [r, o] = e;
                    return (0, t.jsxs)(
                      a.DropdownItem,
                      {
                        children: [
                          (0, t.jsx)(u.Flag, {
                            className: `mr-2 inline-block h-3 w-[20px] rounded-sm object-cover ${"rtl" === (0, v.getLocaleDirection)(j) && "ml-2"}`,
                            code: p.langToCountryCodeMap[r] || "USA",
                            alt: p.langToCountryCodeMap[r] || "USA",
                          }),
                          o,
                        ],
                      },
                      r,
                    );
                  }),
                }),
              ],
            })
          );
        },
      ],
      797982,
    ),
      e.s([], 203068));
  },
  532262,
  (e) => {
    "use strict";
    var t = e.i(797982);
    e.s(["LangComponent", () => t.default]);
  },
  275711,
  (e) => {
    "use strict";
    e.s([
      "customerIoLanguage",
      0,
      {
        en: "en",
        fr: "fr-FR",
        de: "de-DE",
        no: "nn-NO",
        es: "es-ES",
        pt: "pt-PT",
        pl: "pl-PL",
        "da-DK": "da-DK",
        cs: "cs-CZ",
        it: "it-IT",
        ro: "ro-RO",
        sv: "sv-SE",
        el: "el-GR",
        lt: "lt-LT",
        "et-EE": "et-EE",
        bg: "bg-BG",
        fi: "fi-FI",
        hr: "hr-HR",
        hu: "hu-HU",
        lv: "lv-LV",
        nl: "nl-NL",
        "pt-BR": "pt-BR",
        sk: "sk-SK",
        sl: "sl-SI",
        "es-MX": "es-MX",
        tr: "tr",
        ar: "ar",
        "fa-IR": "fa-IR",
        "uk-UA": "uk-UA",
        ku: "ar-KW",
        ru: "ru-RU",
        zh: "zh-CN",
        ko: "ko-KR",
        th: "th-TH",
        ja: "ja-JP",
        he: "he-IL",
        is: "is-IS",
      },
      "langToCountryCodeMap",
      0,
      {
        en: "US",
        fr: "FR",
        de: "DE",
        no: "NO",
        es: "ES",
        pt: "PT",
        pl: "PL",
        "da-DK": "DK",
        cs: "CZ",
        it: "IT",
        ro: "RO",
        sv: "SE",
        el: "GR",
        lv: "LV",
        lt: "LT",
        "mt-MT": "MT",
        sk: "SK",
        sl: "SI",
        "es-MX": "MX",
        tr: "TR",
        ar: "SA",
        "fa-IR": "IR",
        ku: "KW",
        ru: "RU",
        ko: "KR",
        zh: "CN",
        th: "TH",
        ja: "JP",
        "uk-UA": "UA",
        hu: "HU",
        hr: "HR",
        fi: "FI",
        "et-EE": "EE",
        bg: "BG",
        "pt-BR": "BR",
        nl: "NL",
        "ga-IE": "IE",
        he: "IL",
        is: "IS",
      },
      "languageName",
      0,
      {
        en: "English",
        fr: "Français",
        de: "Deutsch",
        no: "Norsk",
        es: "Español",
        pt: "Português",
        pl: "Polski",
        "da-DK": "Dansk",
        cs: "Čeština",
        it: "Italiano",
        ro: "Română",
        sv: "Svenska",
        el: "Ελληνικά",
        lv: "Latviešu",
        sl: "Slovenščina",
        hu: "Magyar",
        hr: "Hrvatski",
        fi: "Suomi",
        "et-EE": "Eesti",
        sk: "Slovenčina",
        lt: "Lietuvių",
        nl: "Nederlands",
        "pt-BR": "Português (Brasil)",
        bg: "Български",
        "mt-MT": "Malti",
        "es-MX": "Español (México)",
        "ga-IE": "Gaeilge",
        tr: "Türkçe",
        ar: "العربية",
        "fa-IR": "فارسی",
        ku: "کوردی",
        ru: "Русский",
        ko: "한국어",
        zh: "中文",
        th: "ไทย",
        ja: "日本語",
        "uk-UA": "Українська",
        he: "עברית",
        is: "Íslenska",
      },
      "twoSymbolLangMap",
      0,
      {
        en: "EN",
        fr: "FR",
        de: "DE",
        no: "NO",
        es: "ES",
        pt: "PT",
        pl: "PL",
        "da-DK": "DA",
        cs: "CZ",
        it: "IT",
        ro: "RO",
        sv: "SE",
        el: "GR",
        lv: "LV",
        lt: "LT",
        "mt-MT": "MT",
        sk: "SK",
        sl: "SI",
        "es-MX": "MX",
        tr: "TR",
        ar: "SA",
        "fa-IR": "IR",
        ku: "KW",
        ru: "RU",
        ko: "KR",
        zh: "CN",
        th: "TH",
        ja: "JP",
        "uk-UA": "UA",
        hu: "HU",
        hr: "HR",
        fi: "FI",
        "et-EE": "EE",
        bg: "BG",
        "pt-BR": "BR",
        nl: "NL",
        "ga-IE": "IE",
        he: "HE",
        is: "IS",
      },
    ]);
  },
]);
