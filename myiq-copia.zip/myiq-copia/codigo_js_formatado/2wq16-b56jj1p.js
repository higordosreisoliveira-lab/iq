(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  236459,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(117595),
      n = e.i(770703),
      i = e.i(861745),
      s = e.i(948148),
      r = e.i(271645),
      l = e.i(663615),
      o = e.i(926654);
    e.i(122612);
    var c = e.i(225352),
      u = e.i(891133),
      m = e.i(386847),
      d = e.i(725397),
      x = e.i(449496),
      p = e.i(866897),
      f = e.i(51653),
      h = e.i(263970),
      y = e.i(915113),
      _ = e.i(998198),
      g = e.i(47252);
    let C = (e) => {
        let { isPersonality: a, isUSorGBUser: n, user: i, text: r, abMyiqAb100Vs199: l } = e,
          m = (0, s.useTranslations)(),
          d = (0, u.useIsUsA1Campaign)(),
          { isUserRestoring: x } = (0, c.useCheckoutUserRestore)(),
          p = x || !i?.paymentInfo?.paynextAmountToPay,
          { priceForView: f } = (0, _.getPaymentPlanPrice)({
            paymentPlan: "v1_trial_1_99" === l || d ? "DEMO_PRICE_1_99" : "DEMO_PRICE",
            user: i,
          }),
          h = (0, _.getCalculatePriceForView)(f, i),
          y = "text-xs xs-m:text-sm";
        return a
          ? (0, t.jsx)("span", {
              dangerouslySetInnerHTML: {
                __html: (0, g.sanitizeTranslationHtml)(
                  m.raw(
                    n
                      ? "checkout_personality_page_timer_title_no_offer"
                      : "checkout_personality_page_timer_title",
                  ),
                ),
              },
              className: `${y} mr-1`,
            })
          : r
            ? (0, t.jsx)("span", {
                dangerouslySetInnerHTML: { __html: (0, g.sanitizeTranslationHtml)(r) },
                className: y,
              })
            : p
              ? (0, t.jsx)(o.Skeleton, { className: "h-7 w-20 rounded-lg" })
              : (0, t.jsx)("span", {
                  className: `${y} text-center`,
                  children: m.rich("checkout_page_timer_bar_title", {
                    total: i?.paymentInfo?.paynextAmountToPay || h,
                    span: (e) => (0, t.jsx)("span", { className: "font-bold text-primary", children: e }),
                  }),
                });
      },
      b = (0, n.default)(() => e.A(383526).then((e) => e.ButtonComponent), {
        loadableGenerated: { modules: [470280] },
      });
    e.s(
      [
        "default",
        0,
        (e) => {
          let {
              isPersonality: n,
              user: g,
              text: T,
              variant: w,
              abMyiqPromoPrice: k,
              abMyiqAb100Vs199: E,
              scrollTarget: S,
              isVisuallyHidden: j,
              rollbackUsRegion: v,
            } = e,
            P = (0, y.getIsMarketingSource)(),
            I = "promo_price" === k,
            M = (0, u.useIsUsA1Campaign)(),
            { isUserRestoring: A } = (0, c.useCheckoutUserRestore)(),
            R = (0, i.useLocale)(),
            N = (0, s.useTranslations)(),
            [U, G] = (0, r.useState)(),
            O = (0, h.useGlobalStore)((e) => e.checkoutTimerMins),
            B = (0, h.useGlobalStore)((e) => e.checkoutTimerSeconds),
            D = (0, h.useGlobalStore)((e) => e.checkoutTimerExpired),
            H = (0, h.useGlobalStore)((e) => e.checkoutTimerReady),
            V = (0, h.useGlobalStore)((e) => e.updateCheckoutTimer),
            $ = (0, h.useGlobalStore)((e) => e.initCheckoutTimer),
            L = (0, h.useGlobalStore)((e) => e.expireCheckoutTimer),
            q = (0, h.useGlobalStore)((e) => e.handleChangeGlobalStore),
            K = (0, h.useGlobalStore)((e) => e.setAutoScrolling),
            z = v
              ? (0, d.isUk)(g?.currency?.countryCode, (0, m.getClientCity)())
              : (0, d.isUsUk)(g?.currency?.countryCode, (0, m.getClientCity)()),
            F = ((0, x.isMyiqVariant)(w) || n) && z,
            Y = () => {
              let e = document.documentElement.clientWidth < 768,
                t = e ? -23 : -13,
                a = document.getElementById("header")?.getBoundingClientRect().top,
                i = window.scrollY && !e,
                s = window.scrollY > 0 && e;
              if (void 0 !== a) {
                if (F) return void G(Math.max(0, a + 65));
                a > t
                  ? G(a + 65)
                  : a < t &&
                    G(
                      ((0, x.isMyiqVariant)(w) || n) && i ? 50 : ((0, x.isMyiqVariant)(w) || n) && s ? 40 : 0,
                    );
              }
            },
            W = (e) => (e < 10 ? `0${e}` : e),
            J = (e) => {
              let t = document.querySelector(".first-cta.checkout-cta");
              if (!t) return;
              let a = t.getBoundingClientRect(),
                n = U || 0,
                i = a.top,
                s = a.bottom;
              q({
                isTimerOverlappingMainButton:
                  a.top < window.innerHeight && a.bottom > 0 && n + 65 > i && n < s && e,
              });
            },
            Q = () => {
              (K(!0, 750), (0, f.scrollToBlock)(S ?? "checkout-coupon-disclaimer"));
            };
          if (
            ((0, r.useLayoutEffect)(() => {
              let e,
                t = a.default.get(p.ECookieArg.CHECKOUT_TIMER_START);
              if (t) {
                let e = 600 - Math.floor((Date.now() - parseInt(t)) / 1e3);
                if (e <= 0)
                  return void (I && P
                    ? (a.default.set(p.ECookieArg.CHECKOUT_TIMER_START, Date.now().toString(), {
                        expires: 2 / 24,
                      }),
                      $(600))
                    : L());
                $(e);
              } else
                (a.default.set(p.ECookieArg.CHECKOUT_TIMER_START, Date.now().toString(), { expires: 2 / 24 }),
                  $(600));
              let n =
                ((e = setInterval(() => {
                  V();
                }, 1e3)),
                () => clearInterval(e));
              return () => n();
            }, [L, $, P, I]),
            (0, r.useEffect)(() => {
              0 !== O ||
                0 !== B ||
                D ||
                (I && P
                  ? (a.default.set(p.ECookieArg.CHECKOUT_TIMER_START, Date.now().toString(), {
                      expires: 2 / 24,
                    }),
                    $(600))
                  : L());
            }, [D, O, B, L, $, P, I]),
            (0, r.useEffect)(() => {
              Y();
              let e = () => {
                (Y(), J(!0));
              };
              return (
                window.addEventListener("scroll", e),
                () => {
                  window.removeEventListener("scroll", e);
                }
              );
            }, [F]),
            (0, r.useEffect)(() => {
              void 0 !== U && J(!0);
            }, [U, !0]),
            (D && !(I && P)) || j)
          )
            return null;
          if ((0, x.isMyiqVariant)(w)) {
            let { priceForView: e } = (0, _.getPaymentPlanPrice)({
                paymentPlan: I
                  ? "DEMO_PRICE_SPECIAL"
                  : "v1_trial_1_99" === E || M
                    ? "DEMO_PRICE_1_99"
                    : "DEMO_PRICE",
                user: g,
              }),
              a = g?.paymentInfo?.paynextAmountToPay || (0, _.getCalculatePriceForView)(e, g),
              n = H ? `${O}:${W(B)}` : "",
              i = (0, t.jsx)("span", {
                className: "text-[13px] leading-none xs-m:text-sm",
                children: N.rich(
                  z ? "checkout_page_timer_bar_title_no_offer" : "checkout_page_timer_bar_title",
                  {
                    total: g?.paymentInfo?.paynextAmountToPay || a,
                    span: (e) =>
                      (0, t.jsx)("span", { className: (0, l.cn)("font-bold text-primary"), children: e }),
                  },
                ),
              }),
              s = (0, t.jsx)("span", {
                className:
                  "whitespace-nowrap text-[13px] font-bold tabular-nums leading-none text-default-900 xs-m:text-sm",
                children: n,
              });
            return (0, t.jsx)("div", {
              id: "checkout-timer",
              style: void 0 !== U ? { transform: `translate3d(0, ${U}px, 0)` } : void 0,
              onClick: Q,
              role: "button",
              className: (0, l.cn)(
                "fixed left-0 right-0 top-0 z-[110] h-12 w-full border-b border-default-200 bg-white text-default-900",
                "transition-all duration-300 ease-in-out md:h-[52px]",
                F ? "translate-y-0" : "translate-y-10 md:translate-y-[52px]",
              ),
              children: (0, t.jsxs)("div", {
                className: "mx-auto flex h-full max-w-7xl items-center justify-center gap-1.5 px-4 md:px-6",
                children: [A ? (0, t.jsx)(o.Skeleton, { className: "h-4 w-52 rounded-md" }) : i, s],
              }),
            });
          }
          return (0, t.jsx)("div", {
            id: "checkout-timer",
            style: void 0 !== U ? { transform: `translate3d(0, ${U}px, 0)` } : void 0,
            className: (0, l.cn)(
              "fixed left-0 top-0 z-[110] flex h-[65px] w-full transform items-center justify-center text-black transition-all duration-300 ease-in-out",
              "translate-y-[65px]",
              "opacity-100",
              n ? "border-t-1 bg-zinc-100 shadow-small" : "border-b-1 bg-white",
              n && !F && "translate-y-10 md:translate-y-[52px]",
              F && "translate-y-0 md:translate-y-0",
            ),
            children: (0, t.jsxs)("div", {
              className: (0, l.cn)(
                "flex w-full max-w-7xl items-center gap-2 max-[1328px]:px-6 max-md:px-4 max-xs-sm:px-2",
                T ? "justify-between" : "justify-center",
              ),
              children: [
                (0, t.jsx)("div", {
                  className: (0, l.cn)(
                    "flex flex-col leading-[1.2] md:flex-row md:gap-2",
                    "justify-items-start",
                  ),
                  children: (0, t.jsxs)("p", {
                    onClick: () => Q(),
                    className: (0, l.cn)(
                      "cursor-pointer select-none text-base font-medium",
                      n ? "" : "flex flex-col gap-1",
                      T ? "items-start text-center" : "items-center",
                    ),
                    children: [
                      (0, t.jsx)(C, {
                        isPersonality: n,
                        isUSorGBUser: z,
                        user: g,
                        text: T,
                        abMyiqAb100Vs199: E,
                      }),
                      H &&
                        !z &&
                        (0, t.jsxs)("span", {
                          className: `w-fit ${!n ? "text-lg" : ""} font-bold`,
                          children: [O, ":", W(B)],
                        }),
                    ],
                  }),
                }),
                T &&
                  (0, t.jsx)(b, {
                    onClick: () => Q(),
                    className: `h-11 animate-pulse ${"ru" === R ? "max-w-[110px]" : "max-w-[101px]"} font-medium antialiased text-medium max-xs-l:text-xs md:text-base`,
                    text: N("btn_continue"),
                  }),
              ],
            }),
          });
        },
      ],
      236459,
    );
  },
  608187,
  function (e) {
    e.n(e.i(236459));
  },
  383526,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/0r2e08ojtfptg.js"].map((t) => e.l(t))).then(() => t(470280)));
  },
]);
