(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  902089,
  (s) => {
    "use strict";
    var t = s.i(843476),
      a = s.i(271645);
    s.i(330021);
    var i = s.i(437460);
    s.i(566594);
    var c = s.i(102241),
      n = s.i(705992);
    s.i(624879);
    var e = s.i(945931);
    s.i(329699);
    var l = s.i(197525);
    s.i(133467);
    var r = s.i(303513);
    s.i(698219);
    var o = s.i(341302);
    s.s([
      "default",
      0,
      (s) => {
        let { children: h, country: u, flagshipExperiments: j, serverUserData: m } = s;
        return (0, t.jsxs)("div", {
          className: "flex min-h-dvh flex-col items-start overflow-hidden text-base",
          children: [
            (0, t.jsx)(r.StatusBarComponent, {}),
            (0, t.jsx)(e.HeaderComponent, { userId: "" }),
            (0, t.jsx)(a.Suspense, {
              fallback: null,
              children: (0, t.jsx)(l.MobileMenuComponent, { sessionId: "" }),
            }),
            (0, t.jsx)(c.ErrorBoundary, { children: h }),
            (0, t.jsxs)(a.Suspense, {
              fallback: null,
              children: [
                (0, t.jsx)(n.FooterNewComponent, { sessionId: "", country: u }),
                (0, t.jsx)(o.SessionUtmComponent, {}),
              ],
            }),
            (0, t.jsx)(i.AnalyticTrackerComponent, {
              flagshipExperiments: j,
              serverUserData: m,
              scope: "static",
            }),
          ],
        });
      },
    ]);
  },
  360620,
  (s) => {
    s.v((t) =>
      Promise.all(
        [
          "static/chunks/1r8tiy6sa83nt.js",
          "static/chunks/3y0xpdojowr_c.js",
          "static/chunks/08alrqotmbxzt.js",
          "static/chunks/36uv7xsqdda6p.js",
          "static/chunks/107v7xzi3zld5.js",
        ].map((t) => s.l(t)),
      ).then(() => t(464901)),
    );
  },
  151820,
  (s) => {
    s.v((t) =>
      Promise.all(
        [
          "static/chunks/3y0xpdojowr_c.js",
          "static/chunks/107v7xzi3zld5.js",
          "static/chunks/2hiijma52v0_n.js",
          "static/chunks/08alrqotmbxzt.js",
          "static/chunks/36uv7xsqdda6p.js",
          "static/chunks/0cn5eu0-kbkpx.js",
        ].map((t) => s.l(t)),
      ).then(() => t(808245)),
    );
  },
  400639,
  (s) => {
    s.v((t) =>
      Promise.all(
        [
          "static/chunks/3bcacjw7v8rn9.js",
          "static/chunks/107v7xzi3zld5.js",
          "static/chunks/3y0xpdojowr_c.js",
          "static/chunks/08alrqotmbxzt.js",
          "static/chunks/36uv7xsqdda6p.js",
          "static/chunks/2hiijma52v0_n.js",
        ].map((t) => s.l(t)),
      ).then(() => t(542156)),
    );
  },
  472478,
  (s) => {
    s.v((t) => Promise.all(["static/chunks/06mw5krzi143p.js"].map((t) => s.l(t))).then(() => t(213595)));
  },
  344088,
  (s) => {
    s.v((t) => Promise.all(["static/chunks/1_supq7fwbe5o.js"].map((t) => s.l(t))).then(() => t(194025)));
  },
  597420,
  (s) => {
    s.v((t) => Promise.all(["static/chunks/12o5vdb11zuke.js"].map((t) => s.l(t))).then(() => t(108176)));
  },
  564257,
  (s) => {
    s.v((t) => Promise.all(["static/chunks/0cr6t9mhkby21.js"].map((t) => s.l(t))).then(() => t(699261)));
  },
  969773,
  (s) => {
    s.v((t) => Promise.all(["static/chunks/2e-9vwkyekykn.js"].map((t) => s.l(t))).then(() => t(3539)));
  },
]);
