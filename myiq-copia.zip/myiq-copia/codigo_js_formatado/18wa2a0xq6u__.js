(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  149268,
  (e) => {
    "use strict";
    let n,
      r = !1,
      i = !1;
    async function t() {
      var e;
      let n;
      return (
        await (null == (e = window.OneSignalDeferred)
          ? void 0
          : e.push((e) => {
              n = e.User.getTags();
            })),
        n
      );
    }
    async function o() {
      var e;
      let n;
      return (
        await (null == (e = window.OneSignalDeferred)
          ? void 0
          : e.push((e) => {
              n = e.User.getLanguage();
            })),
        n
      );
    }
    ("u" > typeof window &&
      ((window.OneSignalDeferred = window.OneSignalDeferred || []),
      ((n = document.createElement("script")).id = "onesignal-sdk"),
      (n.defer = !0),
      (n.src = "https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.page.js"),
      (n.onerror = () => {
        i = !0;
      }),
      document.head.appendChild(n)),
      e.s([
        "default",
        0,
        {
          login: function (e, n) {
            return new Promise((r, t) => {
              var o;
              if (i) return void t(Error("OneSignal script failed to load."));
              try {
                null == (o = window.OneSignalDeferred) ||
                  o.push((i) => {
                    i.login(e, n)
                      .then(() => r())
                      .catch((e) => t(e));
                  });
              } catch (e) {
                t(e);
              }
            });
          },
          logout: function () {
            return new Promise((e, n) => {
              var r;
              if (i) return void n(Error("OneSignal script failed to load."));
              try {
                null == (r = window.OneSignalDeferred) ||
                  r.push((r) => {
                    r.logout()
                      .then(() => e())
                      .catch((e) => n(e));
                  });
              } catch (e) {
                n(e);
              }
            });
          },
          init: (e) => {
            var n;
            return r
              ? Promise.reject("OneSignal is already initialized.")
              : e && e.appId
                ? document
                  ? ((null == (n = e.welcomeNotification) ? void 0 : n.disabled) !== void 0 &&
                      (e.welcomeNotification.disable = e.welcomeNotification.disabled),
                    new Promise((n, i) => {
                      var t;
                      null == (t = window.OneSignalDeferred) ||
                        t.push((t) => {
                          t.init(e)
                            .then(() => {
                              ((r = !0), n());
                            })
                            .catch(i);
                        });
                    }))
                  : Promise.reject("Document is not defined.")
                : Promise.reject("You need to provide your OneSignal appId.");
          },
          setConsentGiven: function (e) {
            return new Promise((n, r) => {
              var t;
              if (i) return void r(Error("OneSignal script failed to load."));
              try {
                null == (t = window.OneSignalDeferred) ||
                  t.push((i) => {
                    i.setConsentGiven(e)
                      .then(() => n())
                      .catch((e) => r(e));
                  });
              } catch (e) {
                r(e);
              }
            });
          },
          setConsentRequired: function (e) {
            return new Promise((n, r) => {
              var t;
              if (i) return void r(Error("OneSignal script failed to load."));
              try {
                null == (t = window.OneSignalDeferred) ||
                  t.push((i) => {
                    i.setConsentRequired(e)
                      .then(() => n())
                      .catch((e) => r(e));
                  });
              } catch (e) {
                r(e);
              }
            });
          },
          Slidedown: {
            promptPush: function (e) {
              return new Promise((n, r) => {
                var t;
                if (i) return void r(Error("OneSignal script failed to load."));
                try {
                  null == (t = window.OneSignalDeferred) ||
                    t.push((i) => {
                      i.Slidedown.promptPush(e)
                        .then(() => n())
                        .catch((e) => r(e));
                    });
                } catch (e) {
                  r(e);
                }
              });
            },
            promptPushCategories: function (e) {
              return new Promise((n, r) => {
                var t;
                if (i) return void r(Error("OneSignal script failed to load."));
                try {
                  null == (t = window.OneSignalDeferred) ||
                    t.push((i) => {
                      i.Slidedown.promptPushCategories(e)
                        .then(() => n())
                        .catch((e) => r(e));
                    });
                } catch (e) {
                  r(e);
                }
              });
            },
            promptSms: function (e) {
              return new Promise((n, r) => {
                var t;
                if (i) return void r(Error("OneSignal script failed to load."));
                try {
                  null == (t = window.OneSignalDeferred) ||
                    t.push((i) => {
                      i.Slidedown.promptSms(e)
                        .then(() => n())
                        .catch((e) => r(e));
                    });
                } catch (e) {
                  r(e);
                }
              });
            },
            promptEmail: function (e) {
              return new Promise((n, r) => {
                var t;
                if (i) return void r(Error("OneSignal script failed to load."));
                try {
                  null == (t = window.OneSignalDeferred) ||
                    t.push((i) => {
                      i.Slidedown.promptEmail(e)
                        .then(() => n())
                        .catch((e) => r(e));
                    });
                } catch (e) {
                  r(e);
                }
              });
            },
            promptSmsAndEmail: function (e) {
              return new Promise((n, r) => {
                var t;
                if (i) return void r(Error("OneSignal script failed to load."));
                try {
                  null == (t = window.OneSignalDeferred) ||
                    t.push((i) => {
                      i.Slidedown.promptSmsAndEmail(e)
                        .then(() => n())
                        .catch((e) => r(e));
                    });
                } catch (e) {
                  r(e);
                }
              });
            },
            addEventListener: function (e, n) {
              var r;
              null == (r = window.OneSignalDeferred) ||
                r.push((r) => {
                  r.Slidedown.addEventListener(e, n);
                });
            },
            removeEventListener: function (e, n) {
              var r;
              null == (r = window.OneSignalDeferred) ||
                r.push((r) => {
                  r.Slidedown.removeEventListener(e, n);
                });
            },
          },
          Notifications: {
            get permissionNative() {
              var a, l;
              return (
                (null == (l = null == (a = window.OneSignal) ? void 0 : a.Notifications)
                  ? void 0
                  : l.permissionNative) ?? "default"
              );
            },
            get permission() {
              var d, s;
              return (
                (null == (s = null == (d = window.OneSignal) ? void 0 : d.Notifications)
                  ? void 0
                  : s.permission) ?? !1
              );
            },
            setDefaultUrl: function (e) {
              return new Promise((n, r) => {
                var t;
                if (i) return void r(Error("OneSignal script failed to load."));
                try {
                  null == (t = window.OneSignalDeferred) ||
                    t.push((i) => {
                      i.Notifications.setDefaultUrl(e)
                        .then(() => n())
                        .catch((e) => r(e));
                    });
                } catch (e) {
                  r(e);
                }
              });
            },
            setDefaultTitle: function (e) {
              return new Promise((n, r) => {
                var t;
                if (i) return void r(Error("OneSignal script failed to load."));
                try {
                  null == (t = window.OneSignalDeferred) ||
                    t.push((i) => {
                      i.Notifications.setDefaultTitle(e)
                        .then(() => n())
                        .catch((e) => r(e));
                    });
                } catch (e) {
                  r(e);
                }
              });
            },
            isPushSupported: () =>
              ("u" > typeof PushSubscriptionOptions &&
                PushSubscriptionOptions.prototype.hasOwnProperty("applicationServerKey")) ||
              (window.safari && "u" > typeof window.safari.pushNotification) ||
              (window.top !== window &&
                "Apple Computer, Inc." === navigator.vendor &&
                "MacIntel" === navigator.platform),
            requestPermission: function () {
              return new Promise((e, n) => {
                var r;
                if (i) return void n(Error("OneSignal script failed to load."));
                try {
                  null == (r = window.OneSignalDeferred) ||
                    r.push((r) => {
                      r.Notifications.requestPermission()
                        .then(() => e())
                        .catch((e) => n(e));
                    });
                } catch (e) {
                  n(e);
                }
              });
            },
            addEventListener: function (e, n) {
              var r;
              null == (r = window.OneSignalDeferred) ||
                r.push((r) => {
                  r.Notifications.addEventListener(e, n);
                });
            },
            removeEventListener: function (e, n) {
              var r;
              null == (r = window.OneSignalDeferred) ||
                r.push((r) => {
                  r.Notifications.removeEventListener(e, n);
                });
            },
          },
          Session: {
            sendOutcome: function (e, n) {
              return new Promise((r, t) => {
                var o;
                if (i) return void t(Error("OneSignal script failed to load."));
                try {
                  null == (o = window.OneSignalDeferred) ||
                    o.push((i) => {
                      i.Session.sendOutcome(e, n)
                        .then(() => r())
                        .catch((e) => t(e));
                    });
                } catch (e) {
                  t(e);
                }
              });
            },
            sendUniqueOutcome: function (e) {
              return new Promise((n, r) => {
                var t;
                if (i) return void r(Error("OneSignal script failed to load."));
                try {
                  null == (t = window.OneSignalDeferred) ||
                    t.push((i) => {
                      i.Session.sendUniqueOutcome(e)
                        .then(() => n())
                        .catch((e) => r(e));
                    });
                } catch (e) {
                  r(e);
                }
              });
            },
          },
          User: {
            get onesignalId() {
              var u, c;
              return null == (c = null == (u = window.OneSignal) ? void 0 : u.User) ? void 0 : c.onesignalId;
            },
            get externalId() {
              var f, w;
              return null == (w = null == (f = window.OneSignal) ? void 0 : f.User) ? void 0 : w.externalId;
            },
            addAlias: function (e, n) {
              var r;
              null == (r = window.OneSignalDeferred) ||
                r.push((r) => {
                  r.User.addAlias(e, n);
                });
            },
            addAliases: function (e) {
              var n;
              null == (n = window.OneSignalDeferred) ||
                n.push((n) => {
                  n.User.addAliases(e);
                });
            },
            removeAlias: function (e) {
              var n;
              null == (n = window.OneSignalDeferred) ||
                n.push((n) => {
                  n.User.removeAlias(e);
                });
            },
            removeAliases: function (e) {
              var n;
              null == (n = window.OneSignalDeferred) ||
                n.push((n) => {
                  n.User.removeAliases(e);
                });
            },
            addEmail: function (e) {
              var n;
              null == (n = window.OneSignalDeferred) ||
                n.push((n) => {
                  n.User.addEmail(e);
                });
            },
            removeEmail: function (e) {
              var n;
              null == (n = window.OneSignalDeferred) ||
                n.push((n) => {
                  n.User.removeEmail(e);
                });
            },
            addSms: function (e) {
              var n;
              null == (n = window.OneSignalDeferred) ||
                n.push((n) => {
                  n.User.addSms(e);
                });
            },
            removeSms: function (e) {
              var n;
              null == (n = window.OneSignalDeferred) ||
                n.push((n) => {
                  n.User.removeSms(e);
                });
            },
            addTag: function (e, n) {
              var r;
              null == (r = window.OneSignalDeferred) ||
                r.push((r) => {
                  r.User.addTag(e, n);
                });
            },
            addTags: function (e) {
              var n;
              null == (n = window.OneSignalDeferred) ||
                n.push((n) => {
                  n.User.addTags(e);
                });
            },
            removeTag: function (e) {
              var n;
              null == (n = window.OneSignalDeferred) ||
                n.push((n) => {
                  n.User.removeTag(e);
                });
            },
            removeTags: function (e) {
              var n;
              null == (n = window.OneSignalDeferred) ||
                n.push((n) => {
                  n.User.removeTags(e);
                });
            },
            getTags: t,
            addEventListener: function (e, n) {
              var r;
              null == (r = window.OneSignalDeferred) ||
                r.push((r) => {
                  r.User.addEventListener(e, n);
                });
            },
            removeEventListener: function (e, n) {
              var r;
              null == (r = window.OneSignalDeferred) ||
                r.push((r) => {
                  r.User.removeEventListener(e, n);
                });
            },
            setLanguage: function (e) {
              var n;
              null == (n = window.OneSignalDeferred) ||
                n.push((n) => {
                  n.User.setLanguage(e);
                });
            },
            getLanguage: o,
            PushSubscription: {
              get id() {
                var v, p, g;
                return null ==
                  (g =
                    null == (p = null == (v = window.OneSignal) ? void 0 : v.User)
                      ? void 0
                      : p.PushSubscription)
                  ? void 0
                  : g.id;
              },
              get token() {
                var h, S, m;
                return null ==
                  (m =
                    null == (S = null == (h = window.OneSignal) ? void 0 : h.User)
                      ? void 0
                      : S.PushSubscription)
                  ? void 0
                  : m.token;
              },
              get optedIn() {
                var O, D, E;
                return null ==
                  (E =
                    null == (D = null == (O = window.OneSignal) ? void 0 : O.User)
                      ? void 0
                      : D.PushSubscription)
                  ? void 0
                  : E.optedIn;
              },
              optIn: function () {
                return new Promise((e, n) => {
                  var r;
                  if (i) return void n(Error("OneSignal script failed to load."));
                  try {
                    null == (r = window.OneSignalDeferred) ||
                      r.push((r) => {
                        r.User.PushSubscription.optIn()
                          .then(() => e())
                          .catch((e) => n(e));
                      });
                  } catch (e) {
                    n(e);
                  }
                });
              },
              optOut: function () {
                return new Promise((e, n) => {
                  var r;
                  if (i) return void n(Error("OneSignal script failed to load."));
                  try {
                    null == (r = window.OneSignalDeferred) ||
                      r.push((r) => {
                        r.User.PushSubscription.optOut()
                          .then(() => e())
                          .catch((e) => n(e));
                      });
                  } catch (e) {
                    n(e);
                  }
                });
              },
              addEventListener: function (e, n) {
                var r;
                null == (r = window.OneSignalDeferred) ||
                  r.push((r) => {
                    r.User.PushSubscription.addEventListener(e, n);
                  });
              },
              removeEventListener: function (e, n) {
                var r;
                null == (r = window.OneSignalDeferred) ||
                  r.push((r) => {
                    r.User.PushSubscription.removeEventListener(e, n);
                  });
              },
            },
          },
          Debug: {
            setLogLevel: function (e) {
              var n;
              null == (n = window.OneSignalDeferred) ||
                n.push((n) => {
                  n.Debug.setLogLevel(e);
                });
            },
          },
        },
      ]));
  },
]);
