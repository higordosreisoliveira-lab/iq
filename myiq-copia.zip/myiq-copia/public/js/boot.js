/* boot.js — runs on the real captured myIQ pages (served static).
 * The original myIQ scripts are stripped (they need myIQ's backend); this
 * restores the few things that matter: broken-image fallbacks (press logos,
 * figure photos and other media were not captured) and simple FAQ accordions.
 */
(function () {
  function wordmark(alt) {
    var s = document.createElement('span');
    s.textContent = alt;
    s.style.cssText =
      'display:inline-flex;align-items:center;justify-content:center;' +
      'font-weight:700;color:#9aa3af;font-size:15px;letter-spacing:.2px;' +
      'white-space:nowrap;line-height:1;';
    return s;
  }
  function avatar(alt) {
    var base = (alt || '?').trim();
    var letters = base.split(/\s+/).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase();
    var d = document.createElement('div');
    d.textContent = letters || '?';
    d.style.cssText =
      'display:flex;align-items:center;justify-content:center;width:100%;height:100%;' +
      'min-width:40px;min-height:40px;border-radius:9999px;background:#eef2f7;' +
      'color:#64748b;font-weight:700;font-size:14px;';
    return d;
  }
  function fixImage(img) {
    if (!img || img.dataset.fixed) return;
    img.dataset.fixed = '1';
    var alt = img.getAttribute('alt') || '';
    var src = img.getAttribute('src') || '';
    var isFigure = /figure|lincoln|napoleon|washington|einstein|curie|avatar|review|person|user/i.test(src + ' ' + alt);
    var replace = function () {
      var node = alt
        ? (isFigure ? avatar(alt) : wordmark(alt))
        : (function () { var e = document.createElement('span'); e.style.display = 'none'; return e; })();
      // copy sizing so layout is preserved
      try {
        node.style.height = node.style.height || '100%';
        if (img.width) node.style.minWidth = img.width + 'px';
      } catch (e) {}
      if (img.parentNode) img.parentNode.replaceChild(node, img);
    };
    img.addEventListener('error', replace, { once: true });
    // already failed (cached miss)
    if (img.complete && img.naturalWidth === 0) replace();
  }

  /* ---------- multi-language (client-side auto translation) ---------- */
  function getLang() {
    try {
      var p = location.pathname;
      if (p.indexOf('/pt-BR') === 0 || p.indexOf('/pt') === 0) return 'pt';
      var m = p.match(/^\/([a-z]{2})(\/|$)/);
      if (m && window.MYIQ_AUTO && hasLang(m[1])) return m[1];
      return localStorage.getItem('myiq_lang') || 'en';
    } catch (e) { return 'en'; }
  }
  function hasLang(code) {
    return (window.MYIQ_LANGS || []).some(function (l) { return l.code === code; });
  }
  function translate(lang) {
    if (!window.MYIQ_AUTO || lang === 'en') return;
    var dict = window.MYIQ_AUTO;
    var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
    var nodes = [], n;
    while ((n = walker.nextNode())) nodes.push(n);
    nodes.forEach(function (node) {
      if (node.parentNode && /^(SCRIPT|STYLE|NOSCRIPT)$/.test(node.parentNode.nodeName)) return;
      var key = node.nodeValue.trim();
      if (!key) return;
      var entry = dict[key];
      if (entry && entry[lang]) node.nodeValue = node.nodeValue.replace(key, entry[lang]);
    });
  }
  function injectLangPicker(current) {
    if (document.getElementById('myiq-lang-picker') || !window.MYIQ_LANGS) return;
    var wrap = document.createElement('div');
    wrap.id = 'myiq-lang-picker';
    wrap.style.cssText = 'position:fixed;right:14px;bottom:14px;z-index:2147483000;';
    var sel = document.createElement('select');
    sel.style.cssText = 'appearance:auto;border:1px solid #e2e8f0;background:#fff;color:#111827;font:500 13px Inter,system-ui,sans-serif;border-radius:9999px;padding:8px 12px;box-shadow:0 4px 16px rgba(0,0,0,.1);cursor:pointer;';
    window.MYIQ_LANGS.forEach(function (l) {
      var o = document.createElement('option'); o.value = l.code; o.textContent = l.label;
      if (l.code === current) o.selected = true; sel.appendChild(o);
    });
    sel.addEventListener('change', function () {
      var v = sel.value;
      try { localStorage.setItem('myiq_lang', v); } catch (e) {}
      if (v === 'pt') { location.href = '/pt-BR' + stripLang(location.pathname); return; }
      if (v === 'en') { location.href = stripLang(location.pathname) || '/'; return; }
      location.reload();
    });
    wrap.appendChild(sel); document.body.appendChild(wrap);
  }
  function stripLang(p) {
    return p.replace(/^\/pt-BR/, '').replace(/^\/[a-z]{2}(?=\/|$)/, '') || '/';
  }

  function run() {
    var imgs = document.images;
    for (var i = 0; i < imgs.length; i++) fixImage(imgs[i]);

    var lang = getLang();
    translate(lang);
    injectLangPicker(lang);

    document.querySelectorAll('[data-accordion-trigger]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var panel = btn.nextElementSibling;
        if (panel) panel.hidden = !panel.hidden;
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }
  // second pass after late layout
  window.addEventListener('load', run);
})();
