(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  210209,
  (e) => {
    "use strict";
    var t = e.i(360067);
    e.s([
      "getPayerNameFromCheckoutResult",
      0,
      (e) => {
        let t = ((e) => {
          let [t = "", ...a] = e
            .replace(/^[-_\s]+/, "")
            .trim()
            .split(/\s+/);
          return { firstName: t, lastName: a.join(" ") };
        })(e?.customer?.full_name || "");
        if (t.firstName) return t;
        let a = e?.payment_method?.details?.payer_info;
        return { firstName: (a?.first_name || "").trim(), lastName: (a?.last_name || "").trim() };
      },
      "getSuggestedCertificateName",
      0,
      (e) =>
        ((e) => {
          let a,
            n,
            r = (0, t.sanitizeNameInput)(e || "")
              .replace(/[^\p{L}\p{M}\s'-]/gu, "")
              .replace(/\s+/g, " ")
              .replace(/^[-\s]+/, "")
              .slice(0, 35)
              .trim();
          return r.length < 2
            ? ""
            : ((a = r === r.toLocaleUpperCase()),
              (n = r === r.toLocaleLowerCase()),
              a || n
                ? r.toLocaleLowerCase().replace(/(^|[\s'-])(\p{L})/gu, (e, t, a) => t + a.toLocaleUpperCase())
                : r);
        })([e?.firstName, e?.lastName].filter(Boolean).join(" ")),
    ]);
  },
  360067,
  (e) => {
    "use strict";
    let t = { value: /^[\p{L}\p{M}\s'][\p{L}\p{M}\s'-]*$/u, message: "error_name_format" },
      a = (e) => e.replace(/[\u200E\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g, "");
    e.s([
      "NAME_MAX_LENGTH",
      0,
      35,
      "emailPattern",
      0,
      {
        value:
          /^(?=.{1,311}$)([a-zA-Z0-9_](?:[a-zA-Z0-9_.+-]*(?:\.[a-zA-Z0-9_.+-]+)*[a-zA-Z0-9_])?@[a-zA-Z0-9]+(?:[.-][a-zA-Z0-9]+)*\.[a-zA-Z]{2,})$/,
        message: "error_email_format",
      },
      "getRequiredMessage",
      0,
      (e) => e("error_required_field"),
      "maxLengthPattern",
      0,
      (e, t) => ({ value: RegExp(`^.{2,${e}}$`), message: t("error_max_characters", { count: `${e}` }) }),
      "minLength2Pattern",
      0,
      { value: /^.{2,}$/, message: "error_min_2_characters" },
      "namePattern",
      0,
      t,
      "sanitizeNameInput",
      0,
      a,
      "validateName",
      0,
      (e, n) => {
        let r = a(e);
        return r && r.trim().length > 0 && !t.value.test(r)
          ? n("error_name_format")
          : r.length > 35
            ? n("error_max_characters", { count: "35" })
            : null;
      },
    ]);
  },
  218099,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(117595),
      n = e.i(618566),
      r = e.i(271645),
      s = e.i(985272),
      o = e.i(812384);
    e.i(842582);
    var i = e.i(76399);
    e.i(473189);
    var l = e.i(476880),
      m = e.i(715413),
      c = e.i(882345),
      u = e.i(49587),
      d = e.i(891133),
      p = e.i(523173),
      y = e.i(866897),
      _ = e.i(622963),
      g = e.i(86596),
      f = e.i(190899),
      h = e.i(210209);
    e.i(756503);
    var C = e.i(542516);
    e.i(470366);
    var v = e.i(504001),
      E = e.i(194613),
      I = e.i(202042);
    e.i(999126);
    var P = e.i(548248);
    let A = "ALREADY_SUBSCRIBED",
      x = new Set([
        "ar",
        "bg",
        "cs",
        "da",
        "de",
        "el",
        "en",
        "es",
        "et",
        "fi",
        "fil",
        "fr",
        "hr",
        "hu",
        "id",
        "is",
        "it",
        "ja",
        "ko",
        "lt",
        "lv",
        "ms",
        "mt",
        "nl",
        "nl-BE",
        "no",
        "pl",
        "pt",
        "ro",
        "ru",
        "sk",
        "sl",
        "sr",
        "sv",
        "th",
        "tr",
        "uk",
        "vi",
        "zh",
      ]);
    e.s(
      [
        "default",
        0,
        (e) => {
          let {
              locale: b,
              user: S,
              handleCheckoutSuccess: k,
              attributionData: N,
              containerId: M = "checkout-container",
              abMyiqPromoPrice: L,
              abMyiqAb100Vs199: R,
              abMyiqRevolutMonzoBlock: D,
              abMyiqBrazilMastercardOnly: w,
              isMarketingSource: U,
              isCheckoutTimerExpired: B = !1,
              reuseSession: T = !1,
              isPlanPickerFunnel: z = !1,
              planName: F,
              paynextPlanId: O,
              paymentsEnabled: V,
              onPaymentsBlocked: $,
              onProcessingChange: H,
              onPaymentSucceeded: j,
              onAlreadySubscribed: X,
            } = e,
            [, Y] = (0, r.useState)(null),
            Z = (0, r.useRef)(null),
            G = (0, r.useRef)(V);
          G.current = V;
          let K = (0, _.useModalStore)((e) => e.handleChangeModalStore),
            q = (0, r.useRef)(null),
            J = (0, r.useRef)(null),
            W = (0, r.useRef)(new Set()),
            Q = (0, r.useRef)(!1),
            { trigger: ee } = (0, o.useCreateUserSessionMutation)(),
            { deviceData: et } = (0, m.useBraintreeDataCollector)(),
            { getAttributionData: ea } = (0, i.useCollectParams)(),
            en = (0, g.useUserStore)((e) => e.handleChangeUserStore),
            [er, es] = (0, r.useState)(a.default.get(y.ECookieArg.PAYNEXT_SESSION)),
            eo = (0, I.usePathname)(),
            ei = (0, n.useSearchParams)(),
            el = async () => {
              S &&
                ee({
                  attributionData: (0, l.getPaymentAttributionData)(ea()) || {},
                  abMyiqRevolutMonzoBlock: "block" === D || "not_block" === D ? D : void 0,
                  ...(("v1_mastercard_only" === w || "control" === w) && { abMyiqBrazilMastercardOnly: w }),
                  ...(L && U && { abMyiqPromoPrice: L }),
                  ...("v1_trial_1_99" === R && { abMyiqAb100Vs199: R }),
                  ...((0, d.getIsUsA1Campaign)() && { isUsA1Campaign: !0 }),
                  ...((0, c.getIsBrCampaign)() && { isBrCampaign: !0 }),
                  ...((0, u.getIsRedesignFunnel)() && { redesignFunnel: !0 }),
                  isMarketingSource: !!U,
                  deviceData: "string" == typeof et ? et : JSON.stringify(et) || "",
                  userData: S,
                  planId: E.EPaynextPlanIds.SPLIT_TRIAL_TIMER_EXPIRED,
                  isCheckoutRefresh: !0,
                }).then((e) => {
                  if (e?.code === A) return void X?.();
                  if (e?.data) {
                    let t = e.data;
                    (en({
                      user: {
                        ...S,
                        paymentInfo: { ...t, paynextAmountPayment: t?.paynextAmountPayment?.toString() },
                      },
                    }),
                      es(t.paynextClientSessionId));
                  }
                });
            },
            em = async () => {
              S &&
                ee({
                  attributionData: (0, l.getPaymentAttributionData)(ea()) || {},
                  abMyiqRevolutMonzoBlock: "block" === D || "not_block" === D ? D : void 0,
                  ...(("v1_mastercard_only" === w || "control" === w) && { abMyiqBrazilMastercardOnly: w }),
                  ...(L && U && { abMyiqPromoPrice: L }),
                  ...("v1_trial_1_99" === R && { abMyiqAb100Vs199: R }),
                  ...((0, d.getIsUsA1Campaign)() && { isUsA1Campaign: !0 }),
                  ...((0, c.getIsBrCampaign)() && { isBrCampaign: !0 }),
                  ...((0, u.getIsRedesignFunnel)() && { redesignFunnel: !0 }),
                  isMarketingSource: !!U,
                  deviceData: "string" == typeof et ? et : JSON.stringify(et) || "",
                  userData: S,
                  isCheckoutRefresh: !0,
                }).then((e) => {
                  if (e?.code === A) return void X?.();
                  if (e?.data) {
                    let t = e.data;
                    (en({
                      user: {
                        ...S,
                        paymentInfo: { ...t, paynextAmountPayment: t?.paynextAmountPayment?.toString() },
                      },
                    }),
                      es(t.paynextClientSessionId));
                  }
                });
            };
          ((0, r.useEffect)(() => {
            if (!T) return;
            let e = S?.paymentInfo?.paynextClientSessionId;
            e && e !== er && es(e);
          }, [T, S?.paymentInfo?.paynextClientSessionId]),
            (0, r.useEffect)(() => {
              T ||
                (!z &&
                  S?.paymentInfo &&
                  ((S.paymentInfo?.paynextClientSessionExpiryDate &&
                    new Date(S.paymentInfo?.paynextClientSessionExpiryDate) < new Date()) ||
                    !er) &&
                  em());
            }, [S]),
            (0, r.useEffect)(() => {
              T || (!z && B && !Q.current && S && ((Q.current = !0), el()));
            }, [B, S]));
          let ec = (e, t) => {
              (0, v.trackClientEvents)({
                event: p.EAnalyticEvents.PURCHASE_ERROR,
                user: S,
                params: { error_code: e || "Error processing payment", ...(t && { detailed_message: t }) },
              });
            },
            eu = async () => {
              let e = {
                app_version: "v2",
                currency: S?.paymentInfo?.paynextAmountCurrency,
                email: S?.email,
                customer_id: S?.id,
                mixpanel_user_id: S?.id,
                user_id: S?.id,
                language: S?.locale,
                country: S?.currency?.countryCode,
                flow_type: "web_onboarding",
                plan_name: z && F ? F : "SPLIT_TRIAL",
                ...(z && { plan_picker_funnel: !0 }),
                paymentOrchestrator: "PayNext",
                paynextSessionId: S?.paymentInfo?.paynextClientSessionId,
                paynextPaymentCurrency: S?.paymentInfo?.paynextAmountCurrency,
                paynextPaymentAmount: Number(S?.paymentInfo?.paynextAmountPayment),
                displayedCurrency: S?.paymentInfo?.paynextAmountDisplayedCurrency,
                displayedAmount: S?.paymentInfo?.paynextAmountDisplayed,
                amount: Number(S?.paymentInfo?.paynextAmountPayment),
                supabase_user_id: S?.id || "",
                first_name: S?.paymentInfo?.firstName || "",
                last_name: S?.paymentInfo?.lastName || "",
                hostname: `${C.envClient.NEXT_PUBLIC_BILLING_HOSTNAME}`,
                sub_order_country: S?.currency?.countryCode || "",
                paynextPlanID: z && O ? O : E.EPaynextPlanIds.SPLIT_TRIAL,
                billing_weeks: S?.paymentInfo?.billing_weeks,
                billing_price: S?.paymentInfo?.billing_price,
                paynextSubscriptionId: S?.paymentInfo?.subscriptionId,
                ...N,
              };
              if (!er) return void ec("PayNext client session not found");
              if (!document.getElementById(M)) return void ec("Checkout container not found");
              let t = new s.PayNextCheckout(),
                a =
                  "v1_mastercard_only" === w
                    ? {
                        [s.PaymentMethod.CARD]: ["mastercard"],
                        [s.PaymentMethod.APPLE_PAY]: ["mastercard"],
                        [s.PaymentMethod.GOOGLE_PAY]: ["mastercard"],
                      }
                    : void 0;
              (await t.mount(M, {
                clientToken: er,
                environment: C.envClient.NEXT_PUBLIC_PAYNEXT_ENV,
                apiVersion: "1.0.0",
                locale: ((e) => {
                  if (x.has(e)) return e;
                  let t = e.split("-")[0].toLowerCase();
                  return x.has(t) ? t : "en";
                })(b),
                variant: "compact",
                ...(a && { acceptedCardNetworks: a }),
                ...("boolean" == typeof V && { paymentsEnabled: V }),
                returnUrl: `${C.envClient.NEXT_PUBLIC_APP_URL}${eo}?scroll=checkout`,
                styles: {
                  SubmitButton: {
                    iconSvg:
                      '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" aria-hidden="true" viewBox="0 0 20 20" class="inline h-5 w-5" focusable="false"><path fill-rule="evenodd" d="M10 1a4.5 4.5 0 0 0-4.5 4.5V9H5a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2h-.5V5.5A4.5 4.5 0 0 0 10 1m3 8V5.5a3 3 0 1 0-6 0V9z" clip-rule="evenodd"></path></svg>',
                  },
                },
                onCheckoutLoaded: (e) => {
                  if (((0, P.debugUtil)({ text: "PayNext form loaded", value: e }), e.success)) {
                    (0, v.trackClientEvents)({
                      event: p.EAnalyticEvents.PAYMENT_FORM_VIEWED,
                      user: S,
                      params: { paymentOrchestrator: "PayNext" },
                    });
                    let e = document.getElementById(M);
                    e &&
                      (e.addEventListener("click", (e) => {
                        let t = e.target;
                        if (!t) return;
                        let a = t.closest("button");
                        a &&
                          a instanceof HTMLElement &&
                          q.current !== a &&
                          ((q.current = a),
                          (0, v.trackClientEvents)({
                            event: p.EAnalyticEvents.PAGE_CLICKED,
                            user: S,
                            params: { page_name: "paymentMethodButtonClicked", payment_method: "card" },
                          }));
                      }),
                      "checkout" === ei.get("scroll") &&
                        "checkout-container" === M &&
                        setTimeout(() => {
                          let e = document.getElementById("checkout-coupon-disclaimer");
                          if (e) {
                            let t = e.getBoundingClientRect().top + window.scrollY;
                            window.scrollTo({ top: t - 30, behavior: "smooth" });
                          }
                        }, 100));
                  }
                },
                onCheckoutAttempt(t) {
                  (H?.(!0),
                    (0, v.trackClientEvents)({
                      event: p.EAnalyticEvents.PURCHASE_ATTEMPT,
                      user: S,
                      params: {
                        ...e,
                        payment_card_brand: t.cardType?.toUpperCase() || "",
                        payment_method_type: t.paymentMethod,
                      },
                    }));
                },
                onCheckoutBlocked: (e) => {
                  (H?.(!1),
                    (0, v.trackClientEvents)({
                      event: p.EAnalyticEvents.PAGE_CLICKED,
                      user: S,
                      params: { page_name: "paymentBlockedNoConsent", payment_method: e.paymentMethod },
                    }),
                    $?.(e));
                },
                onCheckoutComplete: (t) => {
                  var a;
                  (0, P.debugUtil)({ text: "PayNext Payment completed", value: t });
                  let n = t?.id;
                  if (!n) return;
                  if (W.current.has(n)) {
                    f.accessSessionStorageUtil.getItem("paymentId") !== n &&
                      K({ modalComponent: "payment-processed-other-tab", isModalVisible: !0 });
                    return;
                  }
                  (W.current.add(n),
                    f.accessSessionStorageUtil.setItem("paymentId", n),
                    j?.(),
                    J.current && J.current.postMessage({ type: "payment-completed", paymentId: n }),
                    (0, v.trackClientEvents)({
                      user: S,
                      event: p.EAnalyticEvents.PURCHASE_SUCCESS,
                      params: {
                        ...e,
                        payment_method_type: t?.payment_method?.type,
                        payment_card_brand: t?.payment_method?.details?.bin_data?.brand?.toUpperCase() || "",
                        payment_id: t?.id,
                        payment_processor: t?.processor?.type || "",
                      },
                    }));
                  let { firstName: r, lastName: s } = (0, h.getPayerNameFromCheckoutResult)(t),
                    o = t?.tax?.amount_tax || 0,
                    i = t?.tax?.amount_subtotal || 0,
                    l = t?.statement_descriptor || "";
                  k({
                    orderId: (a = {
                      payment: t,
                      paymentMethod:
                        t?.payment_method?.details?.bin_data?.brand?.toUpperCase() || t?.payment_method?.type,
                      paymentСardBrand: t?.payment_method?.details?.bin_data?.brand?.toUpperCase() || "",
                      paymentMethodType: t?.payment_method?.type,
                      processorMerchantId: t?.processor?.processor_merchant_id || "",
                      statementDescriptor: l,
                      paymentProcessor: t?.processor?.type || "",
                      currencyCode: t?.currency_code || "USD",
                      first6Digits: t?.payment_method?.details?.last4?.substring(0, 6) || "",
                      firstName: r,
                      lastName: s,
                      taxAmount: o,
                      taxAmountSubtotal: i,
                    }).payment.id,
                    payment: a.payment,
                    paymentMethod: a.paymentMethod,
                    paymentMethodType: a.paymentMethodType || "",
                    paymentСardBrand: a.paymentСardBrand || "",
                    paymentProcessor: a.paymentProcessor,
                    currencyCode: a.currencyCode,
                    first6Digits: a.first6Digits?.toString() || "",
                    processorMerchantId: a.processorMerchantId,
                    statementDescriptor: a.statementDescriptor,
                    firstName: a.firstName,
                    lastName: a.lastName,
                    attributionData: a.attributionData,
                    taxAmount: a.taxAmount,
                    taxAmountSubtotal: a.taxAmountSubtotal,
                  });
                },
                onCheckoutFail: (e) => {
                  (H?.(!1),
                    (0, P.debugUtil)({ text: "PayNext Payment failed", value: e }),
                    ec(e?.status_reason?.message || "Payment failed. Please try again."),
                    (e?.status_reason?.message.toLowerCase().includes("client_session_id") ||
                      e?.status_reason?.message.toLowerCase().includes("client session") ||
                      e?.status_reason?.message.toLowerCase().includes("invalid cl") ||
                      e?.status_reason?.message.toLowerCase().includes("transaction config")) &&
                      em(),
                    (0, v.trackClientEvents)({
                      event: p.EAnalyticEvents.PURCHASE_ERROR,
                      user: S,
                      params: {
                        amount: Number(S?.paymentInfo?.paynextAmountPayment),
                        currency: S?.paymentInfo?.paynextAmountCurrency,
                        paymentOrchestrator: "PayNext",
                        paynextAdviceCode: e?.status_reason?.advice_code || "",
                        paynextDeclineCode: e?.status_reason?.decline_code || "",
                        paynextSDKError: e?.status === "sdk_failed",
                        paynextDeclineMessage:
                          e?.status !== "sdk_failed" && e?.status_reason?.message
                            ? e.status_reason.message
                            : "SDK Initialisation Failed",
                      },
                    }));
                },
              }),
                (Z.current = t),
                "boolean" == typeof G.current && t.setPaymentsEnabled(G.current),
                Y(t));
            };
          return (
            (0, r.useEffect)(() => {
              J.current = new BroadcastChannel("payment-processing");
              let e = J.current;
              return (
                (e.onmessage = (e) => {
                  let { type: t, paymentId: a } = e.data;
                  "payment-completed" === t &&
                    a &&
                    (W.current.add(a),
                    f.accessSessionStorageUtil.getItem("paymentId") !== a &&
                      K({ modalComponent: "payment-processed-other-tab", isModalVisible: !0 }));
                }),
                () => {
                  e.close();
                }
              );
            }, [K]),
            (0, r.useEffect)(() => {
              if (er) {
                let e = S?.paymentInfo?.paynextClientSessionExpiryDate;
                (e && new Date(e) < new Date()) ||
                  eu().catch((e) => {
                    let t = document.getElementById(M);
                    (t && (t.innerHTML = ""),
                      eu().catch((t) => {
                        ec(
                          "Failed to load payment form. Please refresh the page",
                          t?.message || e?.message || String(t),
                        );
                      }));
                  });
              }
            }, [er]),
            (0, r.useEffect)(() => {
              if ("checkout" === ei.get("scroll") && "checkout-container" === M) {
                let e = document.getElementById(M);
                e && e.scrollIntoView({ behavior: "smooth", block: "center" });
              }
            }, [ei, M]),
            (0, r.useEffect)(() => {
              "boolean" == typeof V && Z.current?.setPaymentsEnabled(V);
            }, [V]),
            (0, t.jsx)("div", {
              id: "checkout-form-section",
              className: "w-full",
              children: (0, t.jsx)("div", {
                style: { display: "grid", gridAutoFlow: "row", zIndex: 0, width: "100%" },
                children: (0, t.jsx)("div", { className: "w-full text-left", id: M, style: { zIndex: 1 } }),
              }),
            })
          );
        },
      ],
      218099,
    );
  },
  149278,
  function (e) {
    e.n(e.i(218099));
  },
]);
