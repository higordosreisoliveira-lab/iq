(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  222375,
  (s) => {
    "use strict";
    var t = s.i(843476),
      e = s.i(271645),
      i = s.i(663615);
    s.i(608970);
    var n = s.i(372546);
    s.i(330021);
    var a = s.i(437460),
      l = s.i(725397),
      c = s.i(302433),
      o = s.i(705992);
    s.i(624879);
    var r = s.i(945931);
    s.i(329699);
    var u = s.i(197525);
    s.i(133467);
    var h = s.i(303513);
    s.i(698219);
    var m = s.i(341302),
      d = s.i(134404),
      j = s.i(202042);
    s.s([
      "default",
      0,
      (s) => {
        let {
            children: x,
            serverUserData: k,
            flagshipExperiments: p,
            country: v,
            city: C,
            showFunnelFooter: E,
            isRedesign: T,
            isUsRegularFunnel: P,
          } = s,
          R = (0, j.usePathname)(),
          S = !!T && (0, c.isRedesignFunnelPage)(R),
          f = (0, n.checkIsMyiqFunnelPage)(R) && E,
          b =
            R === d.EClientRoutes.START ||
            R === d.EClientRoutes.START_PERSONALITY ||
            R === d.EClientRoutes.START_LOVE ||
            R === d.EClientRoutes.START_AUTISM,
          w = (0, l.isUsUk)(v, C),
          _ = P ? (0, l.isUk)(v, C) : w;
        return (0, t.jsxs)("div", {
          className: (0, i.cn)("min-h-dvh text-base", {
            "overflow-x-clip": (0, n.isStaticPolicyPage)(R) || S,
            "overflow-hidden": !(0, n.isStaticPolicyPage)(R) && !S && !f,
            "!pt-10 md:!pt-[53px]":
              !S &&
              ((R === d.EClientRoutes.CHECKOUT_PERSONALITY && !w) ||
                R === d.EClientRoutes.CHECKOUT_DEPRESSION_FUNNEL ||
                R === d.EClientRoutes.CHECKOUT_ENNEAGRAM),
            "pt-10 md:pt-[52px]":
              !S && ((R === d.EClientRoutes.CHECKOUT && !_) || R === d.EClientRoutes.CHECKOUT_AUTISM),
            "flex w-full flex-col": S,
            "grid !grid-rows-[auto_1fr_auto] items-start": !S && (0, n.isStaticHeader)(R),
            "flex flex-col items-start": !S && (0, n.checkIsFooterExist)(R),
            "flex flex-col": !S && f,
            "select-none": (0, n.isDisablePageSelection)(R),
          }),
          children: [
            !S &&
              (0, t.jsxs)(t.Fragment, {
                children: [
                  (0, t.jsx)(h.StatusBarComponent, {}),
                  (0, t.jsx)(r.HeaderComponent, { userId: k.id || "", isOrganicOrGoogleSource: E }),
                  (0, t.jsx)(e.Suspense, {
                    fallback: null,
                    children: (0, t.jsx)(u.MobileMenuComponent, { sessionId: k.id || "" }),
                  }),
                ],
              }),
            f
              ? (0, t.jsx)("div", {
                  className: (0, i.cn)("flex w-full grow flex-col", !b && "min-h-dvh"),
                  children: x,
                })
              : x,
            S
              ? null
              : (0, n.checkIsFooterExist)(R)
                ? (0, t.jsx)(o.FooterNewComponent, { sessionId: k.id || "", country: v })
                : f
                  ? (0, t.jsx)(o.FooterNewComponent, { sessionId: k.id || "", country: v, withDistance: !1 })
                  : null,
            (0, t.jsx)(e.Suspense, { fallback: null, children: (0, t.jsx)(m.SessionUtmComponent, {}) }),
            (0, t.jsx)(a.AnalyticTrackerComponent, { flagshipExperiments: p, serverUserData: k }),
          ],
        });
      },
    ]);
  },
  360620,
  (s) => {
    s.v((t) =>
      Promise.all(
        [
          "static/chunks/1r8tiy6sa83nt.js",
          "static/chunks/3y0xpdojowr_c.js",
          "static/chunks/08alrqotmbxzt.js",
          "static/chunks/36uv7xsqdda6p.js",
          "static/chunks/107v7xzi3zld5.js",
        ].map((t) => s.l(t)),
      ).then(() => t(464901)),
    );
  },
  151820,
  (s) => {
    s.v((t) =>
      Promise.all(
        [
          "static/chunks/3y0xpdojowr_c.js",
          "static/chunks/107v7xzi3zld5.js",
          "static/chunks/2hiijma52v0_n.js",
          "static/chunks/08alrqotmbxzt.js",
          "static/chunks/36uv7xsqdda6p.js",
          "static/chunks/0cn5eu0-kbkpx.js",
        ].map((t) => s.l(t)),
      ).then(() => t(808245)),
    );
  },
  400639,
  (s) => {
    s.v((t) =>
      Promise.all(
        [
          "static/chunks/3bcacjw7v8rn9.js",
          "static/chunks/107v7xzi3zld5.js",
          "static/chunks/3y0xpdojowr_c.js",
          "static/chunks/08alrqotmbxzt.js",
          "static/chunks/36uv7xsqdda6p.js",
          "static/chunks/2hiijma52v0_n.js",
        ].map((t) => s.l(t)),
      ).then(() => t(542156)),
    );
  },
  472478,
  (s) => {
    s.v((t) => Promise.all(["static/chunks/06mw5krzi143p.js"].map((t) => s.l(t))).then(() => t(213595)));
  },
  344088,
  (s) => {
    s.v((t) => Promise.all(["static/chunks/1_supq7fwbe5o.js"].map((t) => s.l(t))).then(() => t(194025)));
  },
  597420,
  (s) => {
    s.v((t) => Promise.all(["static/chunks/12o5vdb11zuke.js"].map((t) => s.l(t))).then(() => t(108176)));
  },
  564257,
  (s) => {
    s.v((t) => Promise.all(["static/chunks/0cr6t9mhkby21.js"].map((t) => s.l(t))).then(() => t(699261)));
  },
  969773,
  (s) => {
    s.v((t) => Promise.all(["static/chunks/2e-9vwkyekykn.js"].map((t) => s.l(t))).then(() => t(3539)));
  },
]);
