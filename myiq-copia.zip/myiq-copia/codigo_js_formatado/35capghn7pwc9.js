(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  940588,
  (t) => {
    "use strict";
    var o = t.i(962607).domAnimation;
    t.s(["default", 0, o]);
  },
]);
