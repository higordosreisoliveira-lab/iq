(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  973924,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(948148),
      r = e.i(271645),
      i = e.i(663615),
      l = e.i(408110),
      n = e.i(812384);
    e.i(842582);
    var s = e.i(76399),
      c = e.i(715413),
      d = e.i(523173);
    e.i(934337);
    var o = e.i(599545);
    e.i(470366);
    var u = e.i(504001);
    e.i(80460);
    var x = e.i(998198),
      m = e.i(998978);
    e.i(118046);
    var p = e.i(112015);
    e.i(473189);
    var f = e.i(476880),
      h = e.i(823933);
    e.s([
      "default",
      0,
      (e) => {
        let { user: b, selectedPlan: g, onPlanChange: y, isMarketingSource: P, idSuffix: N = "" } = e,
          v = (0, a.useTranslations)(),
          { trigger: _ } = (0, n.useCreateUserSessionMutation)(),
          { deviceData: j } = (0, c.useBraintreeDataCollector)(),
          { getAttributionData: C } = (0, s.useCollectParams)(),
          [D, k] = (0, r.useState)(!1),
          S = (0, r.useRef)(!1),
          w = (0, r.useRef)(null),
          A = (0, r.useRef)(!1),
          [E, I] = (0, r.useState)({}),
          K = (0, r.useRef)(!1),
          R = () => ("string" == typeof j ? j : JSON.stringify(j) || ""),
          L = async (e) => {
            if (b && !S.current && w.current !== e) {
              ((S.current = !0), (w.current = e), k(!0));
              try {
                await _({
                  attributionData: (0, f.getPaymentAttributionData)(C()),
                  isMarketingSource: !!P,
                  deviceData: R(),
                  userData: b,
                  planId: e,
                });
              } finally {
                ((S.current = !1), k(!1));
              }
            }
          };
        ((0, r.useEffect)(() => {
          if (!b || A.current) return;
          A.current = !0;
          let e = (0, h.getPlanPickerConfig)(g);
          e && L(e.planId);
        }, [b]),
          (0, r.useEffect)(() => {
            if (!b || K.current) return;
            K.current = !0;
            let e = (0, f.getPaymentAttributionData)(C()),
              t = R();
            Promise.all(
              p.PLAN_PICKER_CONFIG.map((a) =>
                (0, l.getCheckoutSessionPriceFetcher)({
                  userData: b,
                  planId: a.planId,
                  attributionData: e,
                  isMarketingSource: !!P,
                  deviceData: t,
                })
                  .then((e) => ({ id: a.id, data: e }))
                  .catch(() => ({ id: a.id, data: null })),
              ),
            ).then((e) => {
              let t = {};
              for (let a of e) a.data && (t[a.id] = a.data);
              I(t);
            });
          }, [b]));
        let M = (e) => (0, x.getCalculatePriceForView)(e, b),
          T = (e) => (0, x.getPaymentPlanPrice)({ paymentPlan: e, user: b }).priceForView,
          F = (e) => {
            let t = E[e.id],
              a = t?.paynextAmountToPay ?? M(T(e.trialPriceKey)),
              r = t?.paynextAmountMonth ?? M(T(e.renewalPriceKey)),
              i = 10 ** (0, m.getCurrencyMinorUnits)(b?.currency?.currencyCode || "USD"),
              l = t?.paynextAmountDisplayed
                ? Number(t.paynextAmountDisplayed)
                : Math.round(T(e.trialPriceKey) * i),
              n = t?.billing_price ?? Math.round(T(e.renewalPriceKey) * i);
            return {
              trialStr: a,
              renewalStr: r,
              perDayStr: M(l / i / e.perDayDivisor),
              savePercent: (0, x.getSale)(n, l, !0),
            };
          },
          O = F((0, h.getPlanPickerConfig)(g) ?? p.PLAN_PICKER_CONFIG[0]);
        return (0, t.jsxs)("div", {
          id: `checkout-coupon-disclaimer${N}`,
          className: "flex flex-col gap-4",
          children: [
            (0, t.jsx)("div", {
              className: "flex flex-col gap-3",
              role: "radiogroup",
              "aria-label": v("payment_plan_selection_aria_label"),
              children: p.PLAN_PICKER_CONFIG.map((e) => {
                let a = g === e.id,
                  r = F(e);
                return (0, t.jsx)(
                  "button",
                  {
                    type: "button",
                    role: "radio",
                    "aria-checked": a,
                    disabled: D,
                    onClick: () =>
                      ((e) => {
                        if (S.current) return;
                        let t = (0, h.getPlanPickerConfig)(g),
                          a = (0, h.getPlanPickerConfig)(e);
                        ((0, u.trackClientEvents)({
                          event: d.EAnalyticEvents.PAYWALL_PLAN_SELECTED,
                          user: b,
                          params: {
                            plan_picker_funnel: !0,
                            plan_id: a?.planId ?? "",
                            previous_plan_id: t?.planId ?? "",
                            plan_name: a?.planName ?? "",
                            price: a ? F(a).trialStr : "",
                          },
                        }),
                          e !== g && a && (y(e), L(a.planId)));
                      })(e.id),
                    className: (0, i.cn)(
                      "relative w-full rounded-xl border-2 px-4 py-3 text-left transition-all duration-200 disabled:opacity-60",
                      a ? "border-green-custom bg-green-custom/5" : "border-zinc-200 bg-white",
                    ),
                    children: (0, t.jsxs)("div", {
                      className: "flex w-full items-center justify-between gap-4",
                      children: [
                        (0, t.jsxs)("div", {
                          className: "flex items-center gap-3",
                          children: [
                            (0, t.jsx)("span", {
                              className: (0, i.cn)(
                                "flex h-5 w-5 shrink-0 items-center justify-center rounded-full",
                                a ? "bg-green-custom" : "border-2 border-zinc-200 bg-white",
                              ),
                              children: a
                                ? (0, t.jsx)(o.IconCheckmark, { className: "h-3 w-3 text-white" })
                                : null,
                            }),
                            (0, t.jsxs)("div", {
                              className: "flex flex-col",
                              children: [
                                (0, t.jsx)("span", {
                                  className: "text-base font-semibold text-[#323a50]",
                                  children: v(e.labelKey),
                                }),
                                (0, t.jsxs)("div", {
                                  className: "flex flex-wrap items-center gap-2",
                                  children: [
                                    (0, t.jsx)("span", {
                                      className: "text-sm font-medium text-[#323a50]",
                                      children: r.trialStr,
                                    }),
                                    (0, t.jsx)("span", {
                                      className: "text-sm text-neutral-500 line-through",
                                      children: r.renewalStr,
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            e.badgeKey
                              ? (0, t.jsx)("span", {
                                  className:
                                    "hidden rounded-full border border-blue-600 bg-blue-50 px-2.5 py-1 text-xs font-semibold text-blue-600 xs-m:block",
                                  children: v(e.badgeKey),
                                })
                              : null,
                          ],
                        }),
                        (0, t.jsxs)("div", {
                          className: "shrink-0 text-right",
                          children: [
                            (0, t.jsx)("p", {
                              className: "text-base font-bold text-[#0D0D0E]",
                              children: r.perDayStr,
                            }),
                            (0, t.jsx)("p", {
                              className: "text-xs text-neutral-500",
                              children: v("plan_picker_per_day"),
                            }),
                          ],
                        }),
                      ],
                    }),
                  },
                  e.id,
                );
              }),
            }),
            (0, t.jsxs)("div", {
              className: "mb-4 flex items-center justify-between sm:mb-5",
              children: [
                (0, t.jsx)("p", {
                  className: "text-lg font-semibold text-[#0D0D0E]",
                  children: v("plan_picker_due_today_label"),
                }),
                (0, t.jsxs)("div", {
                  className: "flex flex-col items-end",
                  children: [
                    (0, t.jsxs)("div", {
                      className: "flex items-center justify-end gap-2",
                      children: [
                        (0, t.jsx)("span", {
                          className: "mt-px text-sm font-semibold text-neutral-500 line-through",
                          children: O.renewalStr,
                        }),
                        (0, t.jsx)("span", {
                          className: "text-lg font-bold text-[#0D0D0E]",
                          children: O.trialStr,
                        }),
                      ],
                    }),
                    (0, t.jsx)("span", {
                      className: "text-xs font-semibold text-blue-600",
                      children: v("checkout_page_you_save", { sale: O.savePercent }),
                    }),
                  ],
                }),
              ],
            }),
          ],
        });
      },
    ]);
  },
  380091,
  function (e) {
    e.n(e.i(973924));
  },
]);
