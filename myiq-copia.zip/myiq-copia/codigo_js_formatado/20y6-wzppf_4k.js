(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  80233,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/26av-htrry20s.js"].map((t) => e.l(t))).then(() => t(59133)));
  },
  265809,
  (e) => {
    e.v((t) =>
      Promise.all(
        [
          "static/chunks/3haxw6p7xnhfm.js",
          "static/chunks/107v7xzi3zld5.js",
          "static/chunks/1dnwp45ex2q2j.js",
          "static/chunks/3shgo-oc6cycz.js",
          "static/chunks/3qm1bwuz746es.js",
          "static/chunks/08alrqotmbxzt.js",
        ].map((t) => e.l(t)),
      ).then(() => t(949635)),
    );
  },
  570387,
  (e) => {
    e.v((t) =>
      Promise.all(
        [
          "static/chunks/37d-oq6dfyfqr.js",
          "static/chunks/3hrq2e3rg3wt3.js",
          "static/chunks/1j9mdc07lbjnu.css",
        ].map((t) => e.l(t)),
      ).then(() => t(998909)),
    );
  },
  136347,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/07pop3hg-9ffk.js"].map((t) => e.l(t))).then(() => t(97316)));
  },
  772621,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/0fjd-eq6xelzd.js"].map((t) => e.l(t))).then(() => t(366126)));
  },
  703719,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/3nac29od7rkcv.js"].map((t) => e.l(t))).then(() => t(783491)));
  },
  675467,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/2xg21gxes6g0t.js"].map((t) => e.l(t))).then(() => t(202969)));
  },
  643378,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/2wq16-b56jj1p.js"].map((t) => e.l(t))).then(() => t(608187)));
  },
  120077,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/1qbfv0goeuxed.js"].map((t) => e.l(t))).then(() => t(314307)));
  },
  852306,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/2sniuzg0xcb_4.js"].map((t) => e.l(t))).then(() => t(373432)));
  },
  615993,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/0aigbjl8b2daa.js"].map((t) => e.l(t))).then(() => t(380091)));
  },
  101210,
  (e) => {
    "use strict";
    var t = e.i(618566),
      s = e.i(271645);
    e.i(842582);
    var a = e.i(76399);
    e.i(122612);
    var i = e.i(225352),
      r = e.i(715413),
      n = e.i(523173),
      l = e.i(134404),
      c = e.i(157273),
      u = e.i(86596),
      o = e.i(60423);
    e.i(238275);
    var h = e.i(712470),
      m = e.i(812384),
      d = e.i(802774),
      p = e.i(504001);
    e.i(569311);
    var g = e.i(896855);
    e.i(56395);
    var v = e.i(178668),
      f = e.i(202042);
    e.s([
      "default",
      0,
      (e) => {
        let { marketingData: k, pushNotificationVersionQuery: S = "fallback" } = e,
          j = (0, f.useRouter)(),
          y = (0, s.useRef)(!1),
          C = (0, f.usePathname)(),
          P = (0, t.useSearchParams)(),
          E = (0, u.useUserStore)((e) => e.user),
          R = (0, u.useUserStore)((e) => e.handleChangeUserStore),
          { trigger: _ } = (0, h.useCreateSessionMutation)(),
          { trigger: I } = (0, m.useCreateUserSessionMutation)(),
          { trigger: q } = (0, m.useUpdateCheckoutSessionFraudSessionsMutation)(),
          { deviceData: w } = (0, r.useBraintreeDataCollector)(),
          { getAttributionData: x } = (0, a.useCollectParams)(),
          { finishUserRestore: b } = (0, i.useCheckoutUserRestore)(),
          U = async (e, t) => {
            let s = await e;
            s &&
              (R({ user: { sessions: s } }),
              t && (await q({ paynextClientSessionId: t, sessions: s }).catch(() => null)));
          };
        return (
          (0, s.useEffect)(() => {
            k &&
              !y.current &&
              E &&
              w &&
              ((E && !E.currency) ||
                (async () => {
                  ((y.current = !0),
                    o.accessLocalStorage.setItem(c.StorageKeys.MARKETING_USER_ID, k.id || E?.id || ""),
                    g.mixpanelClient.reset(),
                    g.mixpanelClient.identify(k.id || E?.id || ""));
                  let e = x(),
                    t = {
                      ...E,
                      ...k,
                      id: k.id || E?.id,
                      emailMarketing: "true",
                      paymentInfo: { ...E?.paymentInfo, customerId: k.id || E?.id },
                    };
                  if (
                    (R({ user: t }),
                    k.quiz_answers &&
                      o.accessLocalStorage.setItem(
                        c.StorageKeys.QUIZ_ANSWERS,
                        JSON.stringify(k.quiz_answers),
                      ),
                    !k.email)
                  )
                    return j.push(l.EClientRoutes.EMAIL);
                  let s = (0, v.createSessionsForClient)(d.stripeSessions).catch(() => null);
                  try {
                    let a = await I({
                      ...(e || {}),
                      deviceData: "string" == typeof w ? w : JSON.stringify(w) || "",
                      userData: t,
                    });
                    U(s, a?.data?.paynextClientSessionId);
                  } catch (t) {
                    let e = t?.message || "Error creating user session";
                    (0, p.trackClientEvents)({
                      event: n.EAnalyticEvents.CLIENT_SESSION_CREATE_ERROR,
                      user: E,
                      params: { error_code: e },
                    });
                  }
                  let a = k.isFreeVersion ? { verification_status: "complete" } : {};
                  if (
                    ((0, p.setPeopleAnalyticOnce)({
                      email_marketing: "true",
                      push_notification_version: S,
                      ...a,
                    }),
                    k.isFreeVersion)
                  )
                    (await _(t), j.replace(l.EClientRoutes.INTRODUCTION), j.refresh());
                  else if (k.email) {
                    let e = new URLSearchParams(P);
                    (e.delete("cid"),
                      e.delete("email"),
                      e.delete("i"),
                      e.delete("t"),
                      e.delete("ff"),
                      e.delete("r"),
                      e.delete("funnel"),
                      e.delete("quiz_answers"),
                      e.delete("rt"));
                    let t = e.toString() ? `${C}?${e.toString()}` : C;
                    (b(), j.push(t));
                  }
                })());
          }, [E, E?.currency, S, k, w, j, C, P]),
          null
        );
      },
    ]);
  },
  963075,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/29za4cq5k4cac.js"].map((t) => e.l(t))).then(() => t(149278)));
  },
]);
