(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  366784,
  (e) => {
    "use strict";
    e.s([
      "getArrowPlacement",
      0,
      (e, t) => {
        if (t.includes("-")) {
          let [, o] = t.split("-");
          return `${e}-${o}`;
        }
        return e;
      },
      "getShouldUseAxisPlacement",
      0,
      (e, t) => {
        if (t.includes("-")) {
          let [o] = t.split("-");
          if (o.includes(e)) return !1;
        }
        return !0;
      },
      "getTransformOrigins",
      0,
      (e) => {
        let t = {
          top: { originY: 1 },
          bottom: { originY: 0 },
          left: { originX: 1 },
          right: { originX: 0 },
          "top-start": { originX: 0, originY: 1 },
          "top-end": { originX: 1, originY: 1 },
          "bottom-start": { originX: 0, originY: 0 },
          "bottom-end": { originX: 1, originY: 0 },
          "right-start": { originX: 0, originY: 0 },
          "right-end": { originX: 0, originY: 1 },
          "left-start": { originX: 1, originY: 0 },
          "left-end": { originX: 1, originY: 1 },
        };
        return (null == t ? void 0 : t[e]) || {};
      },
      "toReactAriaPlacement",
      0,
      (e) =>
        ({
          top: "top",
          bottom: "bottom",
          left: "left",
          right: "right",
          "top-start": "top start",
          "top-end": "top end",
          "bottom-start": "bottom start",
          "bottom-end": "bottom end",
          "left-start": "left top",
          "left-end": "left bottom",
          "right-start": "right top",
          "right-end": "right bottom",
        })[e],
    ]);
  },
  150985,
  (e) => {
    "use strict";
    var t = new WeakMap(),
      o = [],
      n = e.i(366784),
      r = e.i(730610),
      l = e.i(271645),
      a = e.i(75540),
      i = e.i(655483),
      s = e.i(760835);
    e.s(
      [
        "useReactAriaPopover",
        0,
        function (e, c) {
          let {
              groupRef: u,
              triggerRef: d,
              popoverRef: p,
              showArrow: f,
              offset: m = 7,
              crossOffset: g = 0,
              scrollRef: b,
              shouldFlip: h,
              boundaryElement: v,
              isDismissable: w = !0,
              shouldCloseOnBlur: y = !0,
              shouldCloseOnScroll: x = !0,
              placement: E = "top",
              containerPadding: O,
              shouldCloseOnInteractOutside: P,
              isNonModal: T,
              isKeyboardDismissDisabled: L,
              updatePositionDeps: R = [],
              ...C
            } = e,
            A = null == T || T,
            k = "SubmenuTrigger" === C.trigger,
            { overlayProps: N, underlayProps: S } = (0, s.useAriaOverlay)(
              {
                isOpen: c.isOpen,
                onClose: c.close,
                shouldCloseOnBlur: y,
                isDismissable: w || k,
                isKeyboardDismissDisabled: L,
                shouldCloseOnInteractOutside:
                  P ||
                  ((e) => {
                    var t;
                    return !(null == (t = d.current) ? void 0 : t.contains(e));
                  }),
                disableOutsideEvents: !A,
              },
              p,
            ),
            {
              overlayProps: _,
              arrowProps: z,
              placement: M,
              updatePosition: H,
              triggerAnchorPoint: F,
            } = (0, r.useOverlayPosition)({
              ...C,
              shouldFlip: h,
              crossOffset: g,
              targetRef: d,
              overlayRef: p,
              isOpen: c.isOpen,
              scrollRef: b,
              boundaryElement: v,
              containerPadding: O,
              placement: (0, n.toReactAriaPlacement)(E),
              offset: f ? m + 3 : m,
              onClose: A && !k && x ? c.close : () => {},
            });
          return (
            (0, i.useSafeLayoutEffect)(() => {
              R.length && H();
            }, R),
            (0, l.useEffect)(() => {
              var e, n;
              if (c.isOpen && p.current)
                if (!A)
                  return (function (e) {
                    let n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : document.body,
                      r = new Set(e),
                      l = new Set(),
                      a = (e) => {
                        for (let t of e.querySelectorAll(
                          "[data-live-announcer], [data-react-aria-top-layer]",
                        ))
                          r.add(t);
                        let t = (e) => {
                            if (
                              r.has(e) ||
                              (e.parentElement &&
                                l.has(e.parentElement) &&
                                "row" !== e.parentElement.getAttribute("role"))
                            )
                              return NodeFilter.FILTER_REJECT;
                            for (let t of r) if (e.contains(t)) return NodeFilter.FILTER_SKIP;
                            return NodeFilter.FILTER_ACCEPT;
                          },
                          o = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, { acceptNode: t }),
                          n = t(e);
                        if ((n === NodeFilter.FILTER_ACCEPT && i(e), n !== NodeFilter.FILTER_REJECT)) {
                          let e = o.nextNode();
                          for (; null != e;) (i(e), (e = o.nextNode()));
                        }
                      },
                      i = (e) => {
                        var o;
                        let n = null != (o = t.get(e)) ? o : 0;
                        ("true" !== e.getAttribute("aria-hidden") || 0 !== n) &&
                          (0 === n && e.setAttribute("aria-hidden", "true"), l.add(e), t.set(e, n + 1));
                      };
                    (o.length && o[o.length - 1].disconnect(), a(n));
                    let s = new MutationObserver((e) => {
                      for (let t of e)
                        if (
                          "childList" === t.type &&
                          0 !== t.addedNodes.length &&
                          ![...r, ...l].some((e) => e.contains(t.target))
                        ) {
                          for (let e of t.removedNodes) e instanceof Element && (r.delete(e), l.delete(e));
                          for (let e of t.addedNodes)
                            (e instanceof HTMLElement || e instanceof SVGElement) &&
                            ("true" === e.dataset.liveAnnouncer || "true" === e.dataset.reactAriaTopLayer)
                              ? r.add(e)
                              : e instanceof Element && a(e);
                        }
                    });
                    s.observe(n, { childList: !0, subtree: !0 });
                    let c = {
                      visibleNodes: r,
                      hiddenNodes: l,
                      observe() {
                        s.observe(n, { childList: !0, subtree: !0 });
                      },
                      disconnect() {
                        s.disconnect();
                      },
                    };
                    return (
                      o.push(c),
                      () => {
                        for (let e of (s.disconnect(), l)) {
                          let o = t.get(e);
                          null != o &&
                            (1 === o ? (e.removeAttribute("aria-hidden"), t.delete(e)) : t.set(e, o - 1));
                        }
                        c === o[o.length - 1]
                          ? (o.pop(), o.length && o[o.length - 1].observe())
                          : o.splice(o.indexOf(c), 1);
                      }
                    );
                  })([null != (n = null == u ? void 0 : u.current) ? n : p.current]);
                else {
                  var r = null != (e = null == u ? void 0 : u.current) ? e : p.current;
                  let t = o[o.length - 1];
                  return t && !t.visibleNodes.has(r)
                    ? (t.visibleNodes.add(r),
                      () => {
                        t.visibleNodes.delete(r);
                      })
                    : void 0;
                }
            }, [A, c.isOpen, p, u]),
            {
              popoverProps: (0, a.mergeProps)(N, _),
              arrowProps: z,
              underlayProps: S,
              placement: M,
              triggerAnchorPoint: F,
            }
          );
        },
      ],
      150985,
    );
  },
  525098,
  (e) => {
    "use strict";
    var t = e.i(150985),
      o = e.i(620253),
      n = e.i(153930),
      r = e.i(429427),
      l = e.i(810815),
      a = e.i(37681),
      i = e.i(366784),
      s = e.i(273830),
      c = e.i(595494),
      u = e.i(854889),
      d = e.i(75540),
      p = e.i(271645);
    e.s([
      "usePopover",
      0,
      function (e) {
        var f, m, g;
        let b = (0, c.useProviderContext)(),
          [h, v] = (0, s.mapPropsVariants)(e, u.popover.variantKeys),
          {
            as: w,
            ref: y,
            children: x,
            state: E,
            triggerRef: O,
            scrollRef: P,
            defaultOpen: T,
            onOpenChange: L,
            isOpen: R,
            isNonModal: C = !0,
            shouldFlip: A = !0,
            containerPadding: k = 12,
            shouldBlockScroll: N = !1,
            isDismissable: S = !0,
            shouldCloseOnBlur: _,
            portalContainer: z,
            updatePositionDeps: M,
            dialogProps: H,
            placement: F = "top",
            triggerType: I = "dialog",
            showArrow: B = !1,
            offset: V = 7,
            crossOffset: W = 0,
            boundaryElement: Y,
            isKeyboardDismissDisabled: D,
            shouldCloseOnInteractOutside: X,
            shouldCloseOnScroll: $,
            triggerAnchorPoint: K,
            motionProps: U,
            className: j,
            classNames: q,
            onClose: J,
            ...G
          } = h,
          Q = (0, o.useDOMRef)(y),
          Z = (0, p.useRef)(null),
          ee = (0, p.useRef)(!1),
          et = O || Z,
          eo =
            null != (m = null != (f = e.disableAnimation) ? f : null == b ? void 0 : b.disableAnimation) && m,
          en = (0, n.useOverlayTriggerState)({
            isOpen: R,
            defaultOpen: T,
            onOpenChange: (e) => {
              (null == L || L(e), e || null == J || J());
            },
          }),
          er = E || en,
          {
            popoverProps: el,
            underlayProps: ea,
            placement: ei,
          } = (0, t.useReactAriaPopover)(
            {
              triggerRef: et,
              isNonModal: C,
              popoverRef: Q,
              placement: F,
              offset: V,
              scrollRef: P,
              isDismissable: S,
              shouldCloseOnBlur: _,
              boundaryElement: Y,
              crossOffset: W,
              shouldFlip: A,
              containerPadding: k,
              updatePositionDeps: M,
              isKeyboardDismissDisabled: D,
              shouldCloseOnScroll: $,
              shouldCloseOnInteractOutside: X,
              triggerAnchorPoint: K,
            },
            er,
          ),
          es = (0, p.useMemo)(
            () => (ei ? ((0, i.getShouldUseAxisPlacement)(ei, F) ? ei : F) : null),
            [ei, F],
          ),
          { triggerProps: ec } = (0, l.useOverlayTrigger)({ type: I }, er, et),
          { isFocusVisible: eu, isFocused: ed, focusProps: ep } = (0, r.useFocusRing)(),
          ef = (0, p.useMemo)(() => (0, u.popover)({ ...v }), [(0, d.objectToDeps)(v)]),
          em = (0, d.clsx)(null == q ? void 0 : q.base, j),
          eg = { "--trigger-anchor-point": K ? `${K.x}px ${K.y}px` : void 0 };
        (0, a.usePreventScroll)({ isDisabled: !(N && er.isOpen) });
        let eb = (0, p.useCallback)(
            function () {
              let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
              return {
                "data-slot": "content",
                "data-open": (0, d.dataAttr)(er.isOpen),
                "data-arrow": (0, d.dataAttr)(B),
                "data-placement": ei ? (0, i.getArrowPlacement)(ei, F) : void 0,
                className: ef.content({ class: (0, d.clsx)(null == q ? void 0 : q.content, e.className) }),
              };
            },
            [ef, er.isOpen, B, es, F, q, ei],
          ),
          eh = (0, p.useCallback)(
            (t) => {
              var o;
              let n;
              return (
                "touch" === t.pointerType &&
                ((null == e ? void 0 : e.backdrop) === "blur" ||
                  (null == e ? void 0 : e.backdrop) === "opaque")
                  ? (n = setTimeout(() => {
                      ee.current = !0;
                    }, 100))
                  : (ee.current = !0),
                null == (o = ec.onPress) || o.call(ec, t),
                () => {
                  clearTimeout(n);
                }
              );
            },
            [null == ec ? void 0 : ec.onPress],
          ),
          ev = (0, p.useCallback)(
            function () {
              let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
                { isDisabled: o, ...n } = e;
              return {
                "data-slot": "trigger",
                ...(0, d.mergeProps)({ "aria-haspopup": "dialog" }, ec, n),
                onPress: eh,
                isDisabled: o,
                className: ef.trigger({
                  class: (0, d.clsx)(null == q ? void 0 : q.trigger, e.className),
                  isTriggerDisabled: o,
                }),
                ref: (0, d.mergeRefs)(t, et),
              };
            },
            [er, ec, eh, et],
          ),
          ew = (0, p.useCallback)(
            function () {
              let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
              return {
                "data-slot": "backdrop",
                className: ef.backdrop({ class: null == q ? void 0 : q.backdrop }),
                onClick: (e) => {
                  ee.current ? (er.close(), (ee.current = !1)) : e.preventDefault();
                },
                ...ea,
                ...e,
              };
            },
            [ef, er.isOpen, q, ea],
          );
        return {
          state: er,
          Component: w || "div",
          children: x,
          classNames: q,
          showArrow: B,
          triggerRef: et,
          placement: es,
          isNonModal: C,
          popoverRef: Q,
          portalContainer: z,
          isOpen: er.isOpen,
          onClose: er.close,
          disableAnimation: eo,
          shouldBlockScroll: N,
          backdrop: null != (g = e.backdrop) ? g : "transparent",
          motionProps: U,
          getBackdropProps: ew,
          getPopoverProps: function () {
            let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return {
              ref: Q,
              ...(0, d.mergeProps)(el, G, e),
              style: (0, d.mergeProps)(el.style, G.style, e.style),
            };
          },
          getTriggerProps: ev,
          getDialogProps: function () {
            let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return {
              "data-slot": "base",
              "data-open": (0, d.dataAttr)(er.isOpen),
              "data-focus": (0, d.dataAttr)(ed),
              "data-arrow": (0, d.dataAttr)(B),
              "data-focus-visible": (0, d.dataAttr)(eu),
              "data-placement": ei ? (0, i.getArrowPlacement)(ei, F) : void 0,
              ...(0, d.mergeProps)(ep, H, e),
              className: ef.base({ class: (0, d.clsx)(em) }),
              style: { outline: "none", ...eg },
            };
          },
          getContentProps: eb,
        };
      },
    ]);
  },
  834276,
  (e) => {
    "use strict";
    var t = e.i(4816),
      o = e.i(368919);
    let n = { top: "top", bottom: "top", left: "left", right: "left" },
      r = { top: "bottom", bottom: "top", left: "right", right: "left" },
      l = { top: "left", left: "top" },
      a = { top: "height", left: "width" },
      i = { width: "totalWidth", height: "totalHeight" },
      s = {},
      c = "u" > typeof document ? window.visualViewport : null;
    function u(e) {
      var o, n, r, l, a;
      let i = 0,
        s = 0,
        u = 0,
        d = 0,
        p = 0,
        f = 0,
        m = {},
        g = (null != (o = null == c ? void 0 : c.scale) ? o : 1) > 1;
      if ("BODY" === e.tagName) {
        let t = document.documentElement;
        ((u = t.clientWidth),
          (d = t.clientHeight),
          (i = null != (n = null == c ? void 0 : c.width) ? n : u),
          (s = null != (r = null == c ? void 0 : c.height) ? r : d),
          (m.top = t.scrollTop || e.scrollTop),
          (m.left = t.scrollLeft || e.scrollLeft),
          c && ((p = c.offsetTop), (f = c.offsetLeft)));
      } else
        (({ width: i, height: s, top: p, left: f } = b(e, !1)),
          (m.top = e.scrollTop),
          (m.left = e.scrollLeft),
          (u = i),
          (d = s));
      return (
        (0, t.isWebKit)() &&
          ("BODY" === e.tagName || "HTML" === e.tagName) &&
          g &&
          ((m.top = 0),
          (m.left = 0),
          (p = null != (l = null == c ? void 0 : c.pageTop) ? l : 0),
          (f = null != (a = null == c ? void 0 : c.pageLeft) ? a : 0)),
        { width: i, height: s, totalWidth: u, totalHeight: d, scroll: m, top: p, left: f }
      );
    }
    function d(e, t, o, r, l, i, s) {
      var c;
      let u = null != (c = l.scroll[e]) ? c : 0,
        d = r[a[e]],
        p = r.scroll[n[e]] + i,
        f = d + r.scroll[n[e]] - i,
        m = t - u + s[e] - r[n[e]],
        g = t - u + o + s[e] - r[n[e]];
      return m < p ? p - m : g > f ? Math.max(f - g, p - m) : 0;
    }
    function p(e) {
      if (s[e]) return s[e];
      let [t, o] = e.split(" "),
        r = n[t] || "right",
        i = l[r];
      n[o] || (o = "center");
      let c = a[r],
        u = a[i];
      return (
        (s[e] = { placement: t, crossPlacement: o, axis: r, crossAxis: i, size: c, crossSize: u }),
        s[e]
      );
    }
    function f(e, t, n, l, a, s, c, u, d, p) {
      var f, m, g, b, h;
      let { placement: v, crossPlacement: w, axis: y, crossAxis: x, size: E, crossSize: O } = l,
        P = {};
      ((P[x] = null != (f = e[x]) ? f : 0),
        "center" === w
          ? (P[x] += ((null != (m = e[O]) ? m : 0) - (null != (g = n[O]) ? g : 0)) / 2)
          : w !== x && (P[x] += (null != (b = e[O]) ? b : 0) - (null != (h = n[O]) ? h : 0)),
        (P[x] += s));
      let T = e[x] - n[O] + d + p,
        L = e[x] + e[O] - d - p;
      if (((P[x] = (0, o.clamp)(P[x], T, L)), v === y)) {
        let o = u ? c[E] : t[i[E]];
        P[r[y]] = Math.floor(o - e[y] + a);
      } else P[y] = Math.floor(e[y] + e[E] + a);
      return P;
    }
    function m(e, t, o, n, l, a) {
      var i, s, c;
      let { placement: u, axis: d, size: p } = a;
      return u === d
        ? Math.max(
            0,
            o[d] -
              e[d] -
              (null != (i = e.scroll[d]) ? i : 0) +
              t[d] -
              (null != (s = n[d]) ? s : 0) -
              n[r[d]] -
              l,
          )
        : Math.max(
            0,
            e[p] + e[d] + e.scroll[d] - t[d] - o[d] - o[p] - (null != (c = n[d]) ? c : 0) - n[r[d]] - l,
          );
    }
    function g(e, t) {
      let { top: o, left: n, width: r, height: l } = e.getBoundingClientRect();
      return (
        t &&
          e instanceof e.ownerDocument.defaultView.HTMLElement &&
          ((r = e.offsetWidth), (l = e.offsetHeight)),
        { top: o, left: n, width: r, height: l }
      );
    }
    function b(e, t) {
      let { top: o, left: n, width: r, height: l } = g(e, t),
        { scrollTop: a, scrollLeft: i, clientTop: s, clientLeft: c } = document.documentElement;
      return { top: o + a - s, left: n + i - c, width: r, height: l };
    }
    function h(e, t, o) {
      let n,
        r = window.getComputedStyle(e);
      if ("fixed" === r.position) n = g(e, o);
      else {
        n = b(e, o);
        let r = b(t, o),
          l = window.getComputedStyle(t);
        ((r.top += (parseInt(l.borderTopWidth, 10) || 0) - t.scrollTop),
          (r.left += (parseInt(l.borderLeftWidth, 10) || 0) - t.scrollLeft),
          (n.top -= r.top),
          (n.left -= r.left));
      }
      return ((n.top -= parseInt(r.marginTop, 10) || 0), (n.left -= parseInt(r.marginLeft, 10) || 0), n);
    }
    function v(e) {
      let t = window.getComputedStyle(e);
      return (
        "none" !== t.transform ||
        /transform|perspective/.test(t.willChange) ||
        "none" !== t.filter ||
        "paint" === t.contain ||
        ("backdropFilter" in t && "none" !== t.backdropFilter) ||
        ("WebkitBackdropFilter" in t && "none" !== t.WebkitBackdropFilter)
      );
    }
    e.s([
      "calculatePosition",
      0,
      function (e) {
        var t, l, a, s;
        let c,
          {
            placement: g,
            targetNode: w,
            overlayNode: y,
            scrollNode: x,
            padding: E,
            shouldFlip: O,
            boundaryElement: P,
            offset: T,
            crossOffset: L,
            maxHeight: R,
            arrowSize: C = 0,
            arrowBoundaryOffset: A = 0,
          } = e,
          k =
            y instanceof HTMLElement
              ? (function (e) {
                  let t = e.offsetParent;
                  if (
                    (t &&
                      t === document.body &&
                      "static" === window.getComputedStyle(t).position &&
                      !v(t) &&
                      (t = document.documentElement),
                    null == t)
                  )
                    for (t = e.parentElement; t && !v(t);) t = t.parentElement;
                  return t || document.documentElement;
                })(y)
              : document.documentElement,
          N = k === document.documentElement,
          S = window.getComputedStyle(k).position,
          _ = N ? b(w, !1) : h(w, k, !1);
        if (!N) {
          let { marginTop: e, marginLeft: t } = window.getComputedStyle(w);
          ((_.top += parseInt(e, 10) || 0), (_.left += parseInt(t, 10) || 0));
        }
        let z = b(y, !0),
          M = {
            top: parseInt((c = window.getComputedStyle(y)).marginTop, 10) || 0,
            bottom: parseInt(c.marginBottom, 10) || 0,
            left: parseInt(c.marginLeft, 10) || 0,
            right: parseInt(c.marginRight, 10) || 0,
          };
        ((z.width += (null != (t = M.left) ? t : 0) + (null != (l = M.right) ? l : 0)),
          (z.height += (null != (a = M.top) ? a : 0) + (null != (s = M.bottom) ? s : 0)));
        let H = { top: x.scrollTop, left: x.scrollLeft, width: x.scrollWidth, height: x.scrollHeight },
          F = u(P),
          I = u(k),
          B = "BODY" === P.tagName ? b(k, !1) : h(k, P, !1);
        return (
          "HTML" === k.tagName && "BODY" === P.tagName && ((I.scroll.top = 0), (I.scroll.left = 0)),
          (function (e, t, l, a, s, c, u, g, b, h, v, w, y, x, E, O) {
            var P, T, L, R, C, A, k, N, S, _, z, M, H, F;
            let I,
              B,
              V,
              W = p(e),
              { size: Y, crossAxis: D, crossSize: X, placement: $, crossPlacement: K } = W,
              U = f(t, g, l, W, v, w, h, y, E, O),
              j = v,
              q = m(g, h, t, s, c + v, W);
            if (u && a[Y] > q) {
              let e = p(`${r[$]} ${K}`),
                o = f(t, g, l, e, v, w, h, y, E, O);
              m(g, h, t, s, c + v, e) > q && ((W = e), (U = o), (j = v));
            }
            let J = "bottom";
            "top" === W.axis
              ? "top" === W.placement
                ? (J = "top")
                : "bottom" === W.placement && (J = "bottom")
              : "top" === W.crossAxis &&
                ("top" === W.crossPlacement ? (J = "bottom") : "bottom" === W.crossPlacement && (J = "top"));
            let G = d(D, U[D], l[X], g, b, c, h);
            U[D] += G;
            let Q =
              ((C = U),
              (A = l.height),
              (k = J),
              (I = y ? h.height : g[i.height]),
              (B = null != C.top ? h.top + C.top : h.top + (I - (null != (N = C.bottom) ? N : 0) - A)),
              (V =
                "top" !== k
                  ? Math.max(
                      0,
                      g.height +
                        g.top +
                        (null != (S = g.scroll.top) ? S : 0) -
                        B -
                        ((null != (_ = s.top) ? _ : 0) + (null != (z = s.bottom) ? z : 0) + c),
                    )
                  : Math.max(
                      0,
                      B +
                        A -
                        (g.top + (null != (M = g.scroll.top) ? M : 0)) -
                        ((null != (H = s.top) ? H : 0) + (null != (F = s.bottom) ? F : 0) + c),
                    )),
              Math.min(g.height - 2 * c, V));
            (x && x < Q && (Q = x),
              (l.height = Math.min(l.height, Q)),
              (G = d(D, (U = f(t, g, l, W, j, w, h, y, E, O))[D], l[X], g, b, c, h)),
              (U[D] += G));
            let Z = {},
              ee = t[D] - U[D] - s[n[D]],
              et = ee + 0.5 * t[X],
              eo = E / 2 + O,
              en =
                "left" === n[D]
                  ? (null != (P = s.left) ? P : 0) + (null != (T = s.right) ? T : 0)
                  : (null != (L = s.top) ? L : 0) + (null != (R = s.bottom) ? R : 0),
              er = l[X] - en - E / 2 - O,
              el = t[D] + E / 2 - (U[D] + s[n[D]]),
              ea = t[D] + t[X] - E / 2 - (U[D] + s[n[D]]),
              ei = (0, o.clamp)(et, el, ea);
            ((Z[D] = (0, o.clamp)(ei, eo, er)),
              ({ placement: $, crossPlacement: K } = W),
              E ? (ee = Z[D]) : "right" === K ? (ee += t[X]) : "center" === K && (ee += t[X] / 2));
            let es = "left" === $ || "top" === $ ? l[Y] : 0,
              ec = { x: "top" === $ || "bottom" === $ ? ee : es, y: "left" === $ || "right" === $ ? ee : es };
            return {
              position: U,
              maxHeight: Q,
              arrowOffsetLeft: Z.left,
              arrowOffsetTop: Z.top,
              placement: $,
              triggerAnchorPoint: ec,
            };
          })(g, _, z, H, M, E, O, F, I, B, T, L, !!S && "static" !== S, R, C, A)
        );
      },
      "getRect",
      0,
      g,
    ]);
  },
  684609,
  (e) => {
    "use strict";
    var t = e.i(271645);
    let o = new WeakMap();
    e.s([
      "onCloseMap",
      0,
      o,
      "useCloseOnScroll",
      0,
      function (e) {
        let { triggerRef: n, isOpen: r, onClose: l } = e;
        (0, t.useEffect)(() => {
          if (!r || null === l) return;
          let e = (e) => {
            let t = e.target;
            if (
              !n.current ||
              (t instanceof Node && !t.contains(n.current)) ||
              e.target instanceof HTMLInputElement ||
              e.target instanceof HTMLTextAreaElement
            )
              return;
            let r = l || o.get(n.current);
            r && r();
          };
          return (
            window.addEventListener("scroll", e, !0),
            () => {
              window.removeEventListener("scroll", e, !0);
            }
          );
        }, [r, l, n]);
      },
    ]);
  },
  730610,
  854889,
  (e) => {
    "use strict";
    var t = e.i(834276),
      o = e.i(684609),
      n = e.i(271645),
      r = e.i(99544);
    function l(e) {
      let { ref: t, box: o, onResize: r } = e;
      (0, n.useEffect)(() => {
        let e = null == t ? void 0 : t.current;
        if (e)
          if (void 0 === window.ResizeObserver)
            return (
              window.addEventListener("resize", r, !1),
              () => {
                window.removeEventListener("resize", r, !1);
              }
            );
          else {
            let t = new window.ResizeObserver((e) => {
              e.length && r();
            });
            return (
              t.observe(e, { box: o }),
              () => {
                e && t.unobserve(e);
              }
            );
          }
      }, [r, t, o]);
    }
    var a = e.i(447650);
    let i = "u" > typeof document ? window.visualViewport : null;
    e.s(
      [
        "useOverlayPosition",
        0,
        function (e) {
          var s, c, u, d;
          let { direction: p } = (0, a.useLocale)(),
            {
              arrowSize: f,
              targetRef: m,
              overlayRef: g,
              arrowRef: b,
              scrollRef: h = g,
              placement: v = "bottom",
              containerPadding: w = 12,
              shouldFlip: y = !0,
              boundaryElement: x = "u" > typeof document ? document.body : null,
              offset: E = 0,
              crossOffset: O = 0,
              shouldUpdatePosition: P = !0,
              isOpen: T = !0,
              onClose: L,
              maxHeight: R,
              arrowBoundaryOffset: C = 0,
            } = e,
            [A, k] = (0, n.useState)(null),
            N = [
              P,
              v,
              g.current,
              m.current,
              null == b ? void 0 : b.current,
              h.current,
              w,
              y,
              x,
              E,
              O,
              T,
              p,
              R,
              C,
              f,
            ],
            S = (0, n.useRef)(null == i ? void 0 : i.scale);
          (0, n.useEffect)(() => {
            T && (S.current = null == i ? void 0 : i.scale);
          }, [T]);
          let _ = (0, n.useCallback)(() => {
            var e, o, n, r, l, a;
            if (
              !1 === P ||
              !T ||
              !g.current ||
              !m.current ||
              !x ||
              (null == i ? void 0 : i.scale) !== S.current
            )
              return;
            let s = null;
            if (h.current && h.current.contains(document.activeElement)) {
              let t = null == (e = document.activeElement) ? void 0 : e.getBoundingClientRect(),
                r = h.current.getBoundingClientRect();
              (s = { type: "top", offset: (null != (o = null == t ? void 0 : t.top) ? o : 0) - r.top })
                .offset >
                r.height / 2 &&
                ((s.type = "bottom"),
                (s.offset = (null != (n = null == t ? void 0 : t.bottom) ? n : 0) - r.bottom));
            }
            let c = g.current;
            !R &&
              g.current &&
              ((c.style.top = "0px"),
              (c.style.bottom = ""),
              (c.style.maxHeight =
                (null != (l = null == (r = window.visualViewport) ? void 0 : r.height)
                  ? l
                  : window.innerHeight) + "px"));
            let u = (0, t.calculatePosition)({
              placement:
                ((a = v),
                "rtl" === p
                  ? a.replace("start", "right").replace("end", "left")
                  : a.replace("start", "left").replace("end", "right")),
              overlayNode: g.current,
              targetNode: m.current,
              scrollNode: h.current || g.current,
              padding: w,
              shouldFlip: y,
              boundaryElement: x,
              offset: E,
              crossOffset: O,
              maxHeight: R,
              arrowSize:
                null != f ? f : (null == b ? void 0 : b.current) ? (0, t.getRect)(b.current, !0).width : 0,
              arrowBoundaryOffset: C,
            });
            if (u.position) {
              if (
                ((c.style.top = ""),
                (c.style.bottom = ""),
                (c.style.left = ""),
                (c.style.right = ""),
                Object.keys(u.position).forEach((e) => (c.style[e] = u.position[e] + "px")),
                (c.style.maxHeight = null != u.maxHeight ? u.maxHeight + "px" : ""),
                s && document.activeElement && h.current)
              ) {
                let e = document.activeElement.getBoundingClientRect(),
                  t = h.current.getBoundingClientRect(),
                  o = e[s.type] - t[s.type];
                h.current.scrollTop += o - s.offset;
              }
              k(u);
            }
          }, N);
          ((0, r.useLayoutEffect)(_, N),
            (d = _),
            (0, r.useLayoutEffect)(
              () => (
                window.addEventListener("resize", d, !1),
                () => {
                  window.removeEventListener("resize", d, !1);
                }
              ),
              [d],
            ),
            l({ ref: g, onResize: _ }),
            l({ ref: m, onResize: _ }));
          let z = (0, n.useRef)(!1);
          (0, r.useLayoutEffect)(() => {
            let e,
              t = () => {
                ((z.current = !0),
                  clearTimeout(e),
                  (e = setTimeout(() => {
                    z.current = !1;
                  }, 500)),
                  _());
              },
              o = () => {
                z.current && t();
              };
            return (
              null == i || i.addEventListener("resize", t),
              null == i || i.addEventListener("scroll", o),
              () => {
                (null == i || i.removeEventListener("resize", t),
                  null == i || i.removeEventListener("scroll", o));
              }
            );
          }, [_]);
          let M = (0, n.useCallback)(() => {
            z.current || null == L || L();
          }, [L, z]);
          return (
            (0, o.useCloseOnScroll)({ triggerRef: m, isOpen: T, onClose: L && M }),
            {
              overlayProps: {
                style: {
                  position: A ? "absolute" : "fixed",
                  top: A ? void 0 : 0,
                  left: A ? void 0 : 0,
                  zIndex: 1e5,
                  ...(null == A ? void 0 : A.position),
                  maxHeight: null != (s = null == A ? void 0 : A.maxHeight) ? s : "100vh",
                },
              },
              placement: null != (c = null == A ? void 0 : A.placement) ? c : null,
              triggerAnchorPoint: null != (u = null == A ? void 0 : A.triggerAnchorPoint) ? u : null,
              arrowProps: {
                "aria-hidden": "true",
                role: "presentation",
                style: {
                  left: null == A ? void 0 : A.arrowOffsetLeft,
                  top: null == A ? void 0 : A.arrowOffsetTop,
                },
              },
              updatePosition: _,
            }
          );
        },
      ],
      730610,
    );
    var s = e.i(52841),
      c = e.i(984898),
      u = e.i(779754),
      d = (0, c.tv)({
        slots: {
          base: [
            "z-0",
            "relative",
            "bg-transparent",
            "[transform-origin:var(--trigger-anchor-point)]",
            "before:content-['']",
            "before:hidden",
            "before:z-[-1]",
            "before:absolute",
            "before:rotate-45",
            "before:w-2.5",
            "before:h-2.5",
            "before:rounded-sm",
            "data-[arrow=true]:before:block",
            "data-[placement=top]:before:-bottom-[calc(theme(spacing.5)/4_-_1.5px)]",
            "data-[placement=top]:before:left-1/2",
            "data-[placement=top]:before:-translate-x-1/2",
            "data-[placement=top-start]:before:-bottom-[calc(theme(spacing.5)/4_-_1.5px)]",
            "data-[placement=top-start]:before:left-3",
            "data-[placement=top-end]:before:-bottom-[calc(theme(spacing.5)/4_-_1.5px)]",
            "data-[placement=top-end]:before:right-3",
            "data-[placement=bottom]:before:-top-[calc(theme(spacing.5)/4_-_1.5px)]",
            "data-[placement=bottom]:before:left-1/2",
            "data-[placement=bottom]:before:-translate-x-1/2",
            "data-[placement=bottom-start]:before:-top-[calc(theme(spacing.5)/4_-_1.5px)]",
            "data-[placement=bottom-start]:before:left-3",
            "data-[placement=bottom-end]:before:-top-[calc(theme(spacing.5)/4_-_1.5px)]",
            "data-[placement=bottom-end]:before:right-3",
            "data-[placement=left]:before:-right-[calc(theme(spacing.5)/4_-_2px)]",
            "data-[placement=left]:before:top-1/2",
            "data-[placement=left]:before:-translate-y-1/2",
            "data-[placement=left-start]:before:-right-[calc(theme(spacing.5)/4_-_3px)]",
            "data-[placement=left-start]:before:top-1/4",
            "data-[placement=left-end]:before:-right-[calc(theme(spacing.5)/4_-_3px)]",
            "data-[placement=left-end]:before:bottom-1/4",
            "data-[placement=right]:before:-left-[calc(theme(spacing.5)/4_-_2px)]",
            "data-[placement=right]:before:top-1/2",
            "data-[placement=right]:before:-translate-y-1/2",
            "data-[placement=right-start]:before:-left-[calc(theme(spacing.5)/4_-_3px)]",
            "data-[placement=right-start]:before:top-1/4",
            "data-[placement=right-end]:before:-left-[calc(theme(spacing.5)/4_-_3px)]",
            "data-[placement=right-end]:before:bottom-1/4",
            ...u.dataFocusVisibleClasses,
          ],
          content: [
            "z-10",
            "px-2.5",
            "py-1",
            "w-full",
            "inline-flex",
            "flex-col",
            "items-center",
            "justify-center",
            "box-border",
            "subpixel-antialiased",
            "outline-solid outline-transparent",
            "box-border",
          ],
          trigger: ["z-10"],
          backdrop: ["hidden"],
          arrow: [],
        },
        variants: {
          size: {
            sm: { content: "text-tiny" },
            md: { content: "text-small" },
            lg: { content: "text-medium" },
          },
          color: {
            default: { base: "before:bg-content1 before:shadow-small", content: "bg-content1" },
            foreground: { base: "before:bg-foreground", content: s.colorVariants.solid.foreground },
            primary: { base: "before:bg-primary", content: s.colorVariants.solid.primary },
            secondary: { base: "before:bg-secondary", content: s.colorVariants.solid.secondary },
            success: { base: "before:bg-success", content: s.colorVariants.solid.success },
            warning: { base: "before:bg-warning", content: s.colorVariants.solid.warning },
            danger: { base: "before:bg-danger", content: s.colorVariants.solid.danger },
          },
          radius: {
            none: { content: "rounded-none" },
            sm: { content: "rounded-small" },
            md: { content: "rounded-medium" },
            lg: { content: "rounded-large" },
            full: { content: "rounded-full" },
          },
          shadow: {
            none: { content: "shadow-none" },
            sm: { content: "shadow-small" },
            md: { content: "shadow-medium" },
            lg: { content: "shadow-large" },
          },
          backdrop: {
            transparent: {},
            opaque: { backdrop: "bg-overlay/50 backdrop-opacity-disabled" },
            blur: { backdrop: "backdrop-blur-sm backdrop-saturate-150 bg-overlay/30" },
          },
          triggerScaleOnOpen: {
            true: {
              trigger: ["aria-expanded:scale-[0.97]", "aria-expanded:opacity-70", "subpixel-antialiased"],
            },
            false: {},
          },
          disableAnimation: { true: { base: "animate-none" } },
          isTriggerDisabled: { true: { trigger: "opacity-disabled pointer-events-none" }, false: {} },
        },
        defaultVariants: {
          color: "default",
          radius: "lg",
          size: "md",
          shadow: "md",
          backdrop: "transparent",
          triggerScaleOnOpen: !0,
        },
        compoundVariants: [
          { backdrop: ["opaque", "blur"], class: { backdrop: "block w-full h-full fixed inset-0 -z-30" } },
        ],
      });
    e.s(["popover", 0, d], 854889);
  },
  810815,
  (e) => {
    "use strict";
    var t = e.i(684609),
      o = e.i(271645),
      n = e.i(673797);
    e.s([
      "useOverlayTrigger",
      0,
      function (e, r, l) {
        let a,
          { type: i } = e,
          { isOpen: s } = r;
        ((0, o.useEffect)(() => {
          l && l.current && t.onCloseMap.set(l.current, r.close);
        }),
          "menu" === i ? (a = !0) : "listbox" === i && (a = "listbox"));
        let c = (0, n.useId)();
        return {
          triggerProps: {
            "aria-haspopup": a,
            "aria-expanded": s,
            "aria-controls": s ? c : void 0,
            onPress: r.toggle,
          },
          overlayProps: { id: c },
        };
      },
    ]);
  },
  368919,
  (e) => {
    "use strict";
    e.s([
      "clamp",
      0,
      function (e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1 / 0,
          o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1 / 0;
        return Math.min(Math.max(e, t), o);
      },
    ]);
  },
]);
