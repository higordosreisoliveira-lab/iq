(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  256357,
  (e) => {
    "use strict";
    var t = e.i(843476);
    e.s([
      "default",
      0,
      (e) => {
        let { label: s } = e;
        return (0, t.jsxs)("div", {
          "aria-hidden": !s,
          className: "relative flex items-center justify-center",
          role: s ? "separator" : void 0,
          children: [
            (0, t.jsx)("span", { "aria-hidden": !0, className: "absolute inset-x-0 h-px bg-slate-200" }),
            s &&
              (0, t.jsx)("span", {
                className: "relative bg-white px-2 text-hp-body-sm text-grey-light",
                children: s,
              }),
          ],
        });
      },
    ]);
  },
  225951,
  function (e) {
    e.n(e.i(256357));
  },
]);
