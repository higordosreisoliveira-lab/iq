(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  666137,
  (t) => {
    "use strict";
    t.s([
      "BluredCertificate",
      0,
      "/images/certificate/blured-certificate.webp",
      "BluredCertificateLove",
      0,
      "/images/certificate/blured-certificate-love.webp",
      "ImgCertificateLogo",
      0,
      "/images/certificate/logo.png",
      "ImgLogoText",
      0,
      "/images/certificate/logo-text.png",
      "ImgLoveFunnelLogo",
      0,
      "/images/certificate/logo-love.png",
      "ImgPrintedCertificateReport",
      0,
      "/images/certificate/print-certificate.webp",
      "ImgSignature1",
      0,
      "/images/certificate/sign-1.png",
      "ImgSignature2",
      0,
      "/images/certificate/sign-2.png",
    ]);
  },
  734423,
  150763,
  (t) => {
    "use strict";
    let e = 3120 / 2160,
      l = `${((1 / e) * 100 + 10).toFixed(2)}%`;
    (t.s(
      [
        "ASPECT",
        0,
        e,
        "CONTAINER_PB",
        0,
        l,
        "FLUID_LG_CLASSES",
        0,
        {
          container: "lg:[container-type:inline-size]",
          frame: "lg:border-[length:2.03cqw]",
          badge: "lg:h-[15.25cqw] lg:w-[15.25cqw]",
          logo: "lg:h-[3.73cqw] lg:max-w-[13.56cqw]",
          title: "lg:mt-[2.03cqw] lg:text-[length:4.07cqw] lg:leading-[5.42cqw]",
          label: "lg:text-[length:1.86cqw]",
          value: "lg:text-[length:4.41cqw]",
          description: "lg:text-[length:1.61cqw]",
          footer: "lg:[gap:4.07cqw]",
          meta: "lg:[gap:3.39cqw] lg:text-[length:1.53cqw]",
          signatures: "lg:[gap:3.39cqw] lg:text-[length:1.36cqw]",
          signatureWide: "lg:w-[23.73cqw]",
          signatureNarrow: "lg:w-[16.95cqw]",
          signatureLine: "lg:h-[5.42cqw]",
        },
      ],
      150763,
    ),
      t.s([], 734423));
  },
  805418,
  (t) => {
    "use strict";
    var e = t.i(843476),
      l = t.i(657688),
      x = t.i(948148),
      i = t.i(663615),
      s = t.i(666137),
      a = t.i(51653);
    t.i(734423);
    var r = t.i(150763);
    t.s([
      "default",
      0,
      (t) => {
        let { isPaymentDetails: p, scrollTarget: g, onClick: c, className: m, isFluid: n } = t,
          d = (0, x.useTranslations)();
        return (0, e.jsxs)("div", {
          dir: "ltr",
          className: (0, i.cn)(
            "relative mx-auto -mb-10 w-[88%] origin-bottom cursor-pointer select-none pb-[80%] lg:-mb-0 lg:mt-0 lg:w-full",
            p ? "mt-3 lg:mt-0 lg:w-full lg:pb-[70%]" : "mt-6",
            n && r.FLUID_LG_CLASSES.container,
            m,
          ),
          onClick: () => {
            c ? c() : (0, a.scrollToBlock)(g ?? "checkout-coupon-disclaimer");
          },
          children: [
            (0, e.jsx)("div", {
              className: (0, i.cn)(
                "absolute bottom-[17%] left-[6%] right-[-7%] top-[7%] rounded border border-[rgba(14,27,43,.06)] bg-white shadow-[0_14px_28px_-10px_rgba(14,27,43,.25)] lg:bottom-[6%] lg:left-[6%] lg:right-[-6%] lg:top-[7%]",
                p && "lg:hidden",
              ),
              style: { transform: "rotate(4deg)" },
            }),
            (0, e.jsx)("div", {
              className: (0, i.cn)(
                "absolute rotate-[-1.5deg] overflow-hidden rounded-lg border-[1vw] border-white shadow-[0_18px_40px_-14px_rgba(14,27,43,.32),_0_2px_6px_rgba(14,27,43,.08)] min-[542px]:border-[6px]",
                p && "lg:rotate-0",
              ),
              style: { top: 0, left: 0, right: 0, aspectRatio: r.ASPECT },
              children: (0, e.jsx)("div", {
                className: (0, i.cn)(
                  "relative h-full w-full border-[1.85vw] border-blue-custom bg-white p-[4px]",
                  p
                    ? "xs-l:border-[7px] sm:border-[8px] lg:border-[8px]"
                    : "min-[542px]:border-[10px] lg:border-[12px]",
                  n && r.FLUID_LG_CLASSES.frame,
                ),
                children: (0, e.jsxs)("div", {
                  className: (0, i.cn)(
                    "relative flex h-full w-full flex-col border border-blue-custom px-[4%] py-[2.5%]",
                    p
                      ? "xs-l:px-4 xs-l:py-2 sm:px-4 sm:py-2 lg:px-[4%] lg:py-[2.5%]"
                      : "min-[542px]:px-6 min-[542px]:py-4 lg:px-[5%] lg:py-[3.5%]",
                  ),
                  children: [
                    (0, e.jsx)(l.default, {
                      src: s.ImgCertificateLogo,
                      alt: "myIQ badge",
                      width: 324,
                      height: 324,
                      priority: !0,
                      sizes: "(min-width: 542px) 90px, 14vw",
                      className: (0, i.cn)(
                        "absolute right-[4%] top-[4%] h-[13.3vw] w-[13.3vw] object-contain",
                        p
                          ? "xs-l:right-4 xs-l:top-2 xs-l:h-[52px] xs-l:w-[52px] sm:right-4 sm:top-2 sm:h-[54px] sm:w-[54px] lg:right-[4%] lg:top-[4%] lg:h-[50px] lg:w-[50px]"
                          : "min-[542px]:right-6 min-[542px]:top-4 min-[542px]:h-[72px] min-[542px]:w-[72px] lg:right-[4%] lg:top-[4%] lg:h-[90px] lg:w-[90px]",
                        n && r.FLUID_LG_CLASSES.badge,
                      ),
                    }),
                    (0, e.jsx)(l.default, {
                      src: s.ImgLogoText,
                      alt: "myIQ",
                      width: 324,
                      height: 90,
                      sizes: "(min-width: 542px) 80px, 13vw",
                      className: (0, i.cn)(
                        "h-[3.33vw] w-auto max-w-[13vw]",
                        p
                          ? "xs-l:h-[13px] xs-l:max-w-[50px] sm:h-[14px] sm:max-w-[52px] lg:h-[16px] lg:max-w-[58px]"
                          : "min-[542px]:h-[18px] min-[542px]:max-w-[65px] lg:h-[22px] lg:max-w-[80px]",
                        n && r.FLUID_LG_CLASSES.logo,
                      ),
                    }),
                    (0, e.jsx)("h3", {
                      className: (0, i.cn)(
                        "mt-2 text-[4.07vw] font-bold leading-tight text-blue-custom",
                        p
                          ? "xs-l:mt-2 xs-l:text-[16px] sm:text-[16px] lg:text-[16px]"
                          : "min-[542px]:mt-3 min-[542px]:text-[22px] lg:text-2xl",
                        n && r.FLUID_LG_CLASSES.title,
                      ),
                      children: d.rich("certificate_card_iq_test_title", {
                        span: (t) => (0, e.jsx)("span", { className: "text-dark-custom", children: t }),
                      }),
                    }),
                    (0, e.jsx)("div", {
                      className: (0, i.cn)(
                        "mt-[2.5%] text-[1.85vw] text-cert-grey",
                        p
                          ? "xs-l:mt-1 xs-l:text-[8px] sm:mt-1 sm:text-[8px] lg:text-[8px]"
                          : "min-[542px]:mt-2 min-[542px]:text-[10px] lg:mt-[2.5%] lg:text-[11px]",
                        n && r.FLUID_LG_CLASSES.label,
                      ),
                      children: d("certificate_card_proudly_presented_to"),
                    }),
                    (0, e.jsx)("div", {
                      className: (0, i.cn)(
                        "mt-[0.5%] text-[4.07vw] font-medium leading-tight text-dark-custom blur-[7px]",
                        p
                          ? "xs-l:mt-0.5 xs-l:text-[16px] sm:text-[16px] lg:text-[18px]"
                          : "min-[542px]:mt-0.5 min-[542px]:text-[22px] lg:mt-[0.5%] lg:text-[26px]",
                        n && r.FLUID_LG_CLASSES.value,
                      ),
                      children: "???? ?????",
                    }),
                    (0, e.jsx)("div", {
                      className: (0, i.cn)(
                        "mt-[2.5%] text-[1.85vw] text-cert-grey",
                        p
                          ? "xs-l:mt-1 xs-l:text-[8px] sm:mt-1 sm:text-[8px] lg:text-[8px]"
                          : "min-[542px]:mt-2 min-[542px]:text-[10px] lg:mt-[2.5%] lg:text-[11px]",
                        n && r.FLUID_LG_CLASSES.label,
                      ),
                      children: d("certificate_card_iq_test_subtitle"),
                    }),
                    (0, e.jsx)("div", {
                      className: (0, i.cn)(
                        "mt-[0.5%] text-[4.07vw] font-semibold leading-none text-blue-custom blur-[7px]",
                        p
                          ? "xs-l:mt-0.5 xs-l:text-[16px] sm:text-[16px] lg:text-[18px]"
                          : "min-[542px]:mt-0.5 min-[542px]:text-[22px] lg:mt-[0.5%] lg:text-[26px]",
                        n && r.FLUID_LG_CLASSES.value,
                      ),
                      children: "???",
                    }),
                    (0, e.jsx)("p", {
                      className: (0, i.cn)(
                        "mt-[2.5%] max-w-[78%] text-[1.57vw] leading-[1.35] text-cert-grey",
                        p
                          ? "xs-l:mt-1 xs-l:max-w-[75%] xs-l:text-[6px] xs-l:leading-[1.3] sm:mt-1 sm:text-[6px] lg:text-[7.5px]"
                          : "min-[542px]:mt-2 min-[542px]:max-w-[75%] min-[542px]:text-[8.5px] min-[542px]:leading-[1.3] lg:mt-[2.5%] lg:max-w-[75%] lg:text-[9.5px] lg:leading-[1.35]",
                        n && r.FLUID_LG_CLASSES.description,
                      ),
                      children: d("certificate_card_iq_on_paywall_description"),
                    }),
                    (0, e.jsxs)("div", {
                      className: (0, i.cn)(
                        "mt-auto flex flex-row items-end justify-between gap-3 pb-0",
                        p ? "lg:gap-3" : "lg:gap-6",
                        n && r.FLUID_LG_CLASSES.footer,
                      ),
                      children: [
                        (0, e.jsxs)("div", {
                          className: (0, i.cn)(
                            "flex gap-3 text-[1.15vw]",
                            p
                              ? "xs-l:gap-3 xs-l:text-[5px] sm:text-[5px] lg:gap-3 lg:text-[7px]"
                              : "min-[542px]:gap-4 min-[542px]:text-[7px] lg:gap-5 lg:text-[9px]",
                            n && r.FLUID_LG_CLASSES.meta,
                          ),
                          children: [
                            (0, e.jsxs)("div", {
                              children: [
                                (0, e.jsx)("div", {
                                  className: "text-cert-grey-light",
                                  children: d("certificate_card_date_of_receiving"),
                                }),
                                (0, e.jsx)("div", {
                                  className: "mt-0.5 font-medium text-dark-custom blur-[4px]",
                                  children: "24.04.2026",
                                }),
                              ],
                            }),
                            (0, e.jsxs)("div", {
                              children: [
                                (0, e.jsx)("div", {
                                  className: "text-cert-grey-light",
                                  children: d("certificate_card_certificate_id"),
                                }),
                                (0, e.jsx)("div", {
                                  className: "mt-0.5 font-medium text-dark-custom blur-[4px]",
                                  children: "429 479",
                                }),
                              ],
                            }),
                          ],
                        }),
                        (0, e.jsxs)("div", {
                          className: (0, i.cn)(
                            "mb-[0.8vw] flex gap-3 text-center text-[0.95vw] text-cert-grey-light",
                            p
                              ? "xs-l:mb-0 xs-l:gap-3 xs-l:text-[4px] sm:text-[4px] lg:gap-3 lg:text-[6px]"
                              : "min-[542px]:mb-0 min-[542px]:gap-4 min-[542px]:text-[6px] lg:gap-5 lg:text-[8px]",
                            n && r.FLUID_LG_CLASSES.signatures,
                          ),
                          children: [
                            (0, e.jsxs)("div", {
                              className: (0, i.cn)(
                                "w-[20vw]",
                                p
                                  ? "xs-l:w-[75px] sm:w-[78px] lg:w-[95px]"
                                  : "min-[542px]:w-[116px] lg:w-[140px]",
                                n && r.FLUID_LG_CLASSES.signatureWide,
                              ),
                              children: [
                                (0, e.jsx)("div", {
                                  className: (0, i.cn)(
                                    "flex h-[5vw] items-end border-b border-cert-grey-pale",
                                    p
                                      ? "xs-l:h-[18px] sm:h-[19px] lg:h-[22px]"
                                      : "min-[542px]:h-[24px] lg:h-[32px]",
                                    n && r.FLUID_LG_CLASSES.signatureLine,
                                  ),
                                  children: (0, e.jsx)(l.default, {
                                    src: s.ImgSignature1,
                                    alt: "Director of Assessments",
                                    width: 548,
                                    height: 192,
                                    sizes: "(min-width: 542px) 140px, 20vw",
                                    className: "h-full w-full object-bottom",
                                  }),
                                }),
                                (0, e.jsx)("div", {
                                  className: "mt-0.5",
                                  children: d("certificate_card_director_of_assessments"),
                                }),
                              ],
                            }),
                            (0, e.jsxs)("div", {
                              className: (0, i.cn)(
                                "w-[13vw]",
                                p
                                  ? "xs-l:w-[52px] sm:w-[55px] lg:w-[68px]"
                                  : "min-[542px]:w-[82px] lg:w-[100px]",
                                n && r.FLUID_LG_CLASSES.signatureNarrow,
                              ),
                              children: [
                                (0, e.jsx)("div", {
                                  className: (0, i.cn)(
                                    "flex h-[5vw] items-end border-b border-cert-grey-pale",
                                    p
                                      ? "xs-l:h-[18px] sm:h-[19px] lg:h-[22px]"
                                      : "min-[542px]:h-[24px] lg:h-[32px]",
                                    n && r.FLUID_LG_CLASSES.signatureLine,
                                  ),
                                  children: (0, e.jsx)(l.default, {
                                    src: s.ImgSignature2,
                                    alt: "Validation Officer",
                                    width: 799,
                                    height: 514,
                                    sizes: "(min-width: 542px) 100px, 13vw",
                                    className: "h-full w-full object-bottom",
                                  }),
                                }),
                                (0, e.jsx)("div", {
                                  className: "mt-0.5",
                                  children: d("certificate_card_validation_officer"),
                                }),
                              ],
                            }),
                          ],
                        }),
                      ],
                    }),
                  ],
                }),
              }),
            }),
          ],
        });
      },
    ]);
  },
  746398,
  function (t) {
    t.n(t.i(805418));
  },
]);
