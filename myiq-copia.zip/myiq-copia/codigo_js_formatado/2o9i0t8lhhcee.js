(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  117595,
  (t) => {
    "use strict";
    function e(t) {
      for (var e = 1; e < arguments.length; e++) {
        var r = arguments[e];
        for (var n in r) t[n] = r[n];
      }
      return t;
    }
    var r = (function t(r, n) {
      function i(t, i, o) {
        if ("u" > typeof document) {
          ("number" == typeof (o = e({}, n, o)).expires &&
            (o.expires = new Date(Date.now() + 864e5 * o.expires)),
            o.expires && (o.expires = o.expires.toUTCString()),
            (t = encodeURIComponent(t)
              .replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent)
              .replace(/[()]/g, escape)));
          var f = "";
          for (var u in o) o[u] && ((f += "; " + u), !0 !== o[u] && (f += "=" + o[u].split(";")[0]));
          return (document.cookie = t + "=" + r.write(i, t) + f);
        }
      }
      return Object.create(
        {
          set: i,
          get: function (t) {
            if ("u" > typeof document && (!arguments.length || t)) {
              for (
                var e = document.cookie ? document.cookie.split("; ") : [], n = {}, i = 0;
                i < e.length;
                i++
              ) {
                var o = e[i].split("="),
                  f = o.slice(1).join("=");
                try {
                  var u = decodeURIComponent(o[0]);
                  if (((n[u] = r.read(f, u)), t === u)) break;
                } catch (t) {}
              }
              return t ? n[t] : n;
            }
          },
          remove: function (t, r) {
            i(t, "", e({}, r, { expires: -1 }));
          },
          withAttributes: function (r) {
            return t(this.converter, e({}, this.attributes, r));
          },
          withConverter: function (r) {
            return t(e({}, this.converter, r), this.attributes);
          },
        },
        { attributes: { value: Object.freeze(n) }, converter: { value: Object.freeze(r) } },
      );
    })(
      {
        read: function (t) {
          return ('"' === t[0] && (t = t.slice(1, -1)), t.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent));
        },
        write: function (t) {
          return encodeURIComponent(t).replace(
            /%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g,
            decodeURIComponent,
          );
        },
      },
      { path: "/" },
    );
    t.s(["default", 0, r]);
  },
  808341,
  (t, e, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      cancelIdleCallback: function () {
        return f;
      },
      requestIdleCallback: function () {
        return o;
      },
    };
    for (var i in n) Object.defineProperty(r, i, { enumerable: !0, get: n[i] });
    let o =
        ("u" > typeof self && self.requestIdleCallback && self.requestIdleCallback.bind(window)) ||
        function (t) {
          let e = Date.now();
          return self.setTimeout(function () {
            t({
              didTimeout: !1,
              timeRemaining: function () {
                return Math.max(0, 50 - (Date.now() - e));
              },
            });
          }, 1);
        },
      f =
        ("u" > typeof self && self.cancelIdleCallback && self.cancelIdleCallback.bind(window)) ||
        function (t) {
          return clearTimeout(t);
        };
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (e.exports = r.default));
  },
  519083,
  (t, e, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      ESCAPE_REGEX: function () {
        return f;
      },
      htmlEscapeAttributeString: function () {
        return c;
      },
      htmlEscapeJsonString: function () {
        return s;
      },
    };
    for (var i in n) Object.defineProperty(r, i, { enumerable: !0, get: n[i] });
    let o = { "&": "\\u0026", ">": "\\u003e", "<": "\\u003c", "\u2028": "\\u2028", "\u2029": "\\u2029" },
      f = /[&><\u2028\u2029]/g,
      u = { "&": "&amp;", '"': "&quot;", "'": "&#39;", "<": "&lt;", ">": "&gt;" },
      a = /[&"'<>]/g;
    function s(t) {
      return t.replace(f, (t) => o[t]);
    }
    function c(t) {
      return t.replace(a, (t) => u[t]);
    }
  },
  479520,
  (t, e, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      default: function () {
        return m;
      },
      handleClientScriptLoad: function () {
        return y;
      },
      initScriptLoader: function () {
        return A;
      },
    };
    for (var i in n) Object.defineProperty(r, i, { enumerable: !0, get: n[i] });
    let o = t.r(555682),
      f = t.r(190809),
      u = t.r(843476),
      a = o._(t.r(174080)),
      s = f._(t.r(271645)),
      c = t.r(742732),
      l = t.r(922737),
      h = t.r(808341),
      p = t.r(519083),
      _ = new Map(),
      d = new Set(),
      g = (t) => {
        let {
            src: e,
            id: r,
            onLoad: n = () => {},
            onReady: i = null,
            dangerouslySetInnerHTML: o,
            children: f = "",
            strategy: u = "afterInteractive",
            onError: s,
            stylesheets: c,
          } = t,
          h = r || e;
        if (h && d.has(h)) return;
        if (_.has(e)) {
          (d.add(h), _.get(e).then(n, s));
          return;
        }
        let p = () => {
            (i && i(), d.add(h));
          },
          g = document.createElement("script"),
          y = new Promise((t, e) => {
            (g.addEventListener("load", function (e) {
              (t(), n && n.call(this, e), p());
            }),
              g.addEventListener("error", function (t) {
                e(t);
              }));
          }).catch(function (t) {
            s && s(t);
          });
        (o
          ? ((g.innerHTML = o.__html || ""), p())
          : f
            ? ((g.textContent = "string" == typeof f ? f : Array.isArray(f) ? f.join("") : ""), p())
            : e && ((g.src = e), _.set(e, y)),
          (0, l.setAttributesFromProps)(g, t),
          "worker" === u && g.setAttribute("type", "text/partytown"),
          g.setAttribute("data-nscript", u),
          c &&
            ((t) => {
              if (a.default.preinit)
                return t.forEach((t) => {
                  a.default.preinit(t, { as: "style" });
                });
              if ("u" > typeof window) {
                let e = document.head;
                t.forEach((t) => {
                  let r = document.createElement("link");
                  ((r.type = "text/css"), (r.rel = "stylesheet"), (r.href = t), e.appendChild(r));
                });
              }
            })(c),
          document.body.appendChild(g));
      };
    function y(t) {
      let { strategy: e = "afterInteractive" } = t;
      "lazyOnload" === e
        ? window.addEventListener("load", () => {
            (0, h.requestIdleCallback)(() => g(t));
          })
        : g(t);
    }
    function A(t) {
      (t.forEach(y),
        [
          ...document.querySelectorAll('[data-nscript="beforeInteractive"]'),
          ...document.querySelectorAll('[data-nscript="beforePageRender"]'),
        ].forEach((t) => {
          let e = t.id || t.getAttribute("src");
          d.add(e);
        }));
    }
    function E(t) {
      let {
          id: e,
          src: r = "",
          onLoad: n = () => {},
          onReady: i = null,
          strategy: o = "afterInteractive",
          onError: f,
          stylesheets: l,
          ..._
        } = t,
        {
          updateScripts: y,
          scripts: A,
          getIsSsr: E,
          appDir: m,
          nonce: I,
        } = (0, s.useContext)(c.HeadManagerContext);
      I = _.nonce || I;
      let T = (0, s.useRef)(!1);
      (0, s.useEffect)(() => {
        let t = e || r;
        T.current || (i && t && d.has(t) && i(), (T.current = !0));
      }, [i, e, r]);
      let M = (0, s.useRef)(!1);
      if (
        ((0, s.useEffect)(() => {
          if (!M.current) {
            if ("afterInteractive" === o) g(t);
            else
              "lazyOnload" === o &&
                ("complete" === document.readyState
                  ? (0, h.requestIdleCallback)(() => g(t))
                  : window.addEventListener("load", () => {
                      (0, h.requestIdleCallback)(() => g(t));
                    }));
            M.current = !0;
          }
        }, [t, o]),
        ("beforeInteractive" === o || "worker" === o) &&
          (y
            ? ((A[o] = (A[o] || []).concat([
                { id: e, src: r, onLoad: n, onReady: i, onError: f, ..._, nonce: I },
              ])),
              y(A))
            : E && E()
              ? d.add(e || r)
              : E && !E() && g({ ...t, nonce: I })),
        m)
      ) {
        if (
          (l &&
            l.forEach((t) => {
              a.default.preinit(t, { as: "style" });
            }),
          "beforeInteractive" === o)
        )
          if (!r)
            return (
              _.dangerouslySetInnerHTML &&
                ((_.children = _.dangerouslySetInnerHTML.__html), delete _.dangerouslySetInnerHTML),
              (0, u.jsx)("script", {
                nonce: I,
                dangerouslySetInnerHTML: {
                  __html: `(self.__next_s=self.__next_s||[]).push(${(0, p.htmlEscapeJsonString)(JSON.stringify([0, { ..._, id: e }]))})`,
                },
              })
            );
          else
            return (
              a.default.preload(
                r,
                _.integrity
                  ? { as: "script", integrity: _.integrity, nonce: I, crossOrigin: _.crossOrigin }
                  : { as: "script", nonce: I, crossOrigin: _.crossOrigin },
              ),
              (0, u.jsx)("script", {
                nonce: I,
                dangerouslySetInnerHTML: {
                  __html: `(self.__next_s=self.__next_s||[]).push(${(0, p.htmlEscapeJsonString)(JSON.stringify([r, { ..._, id: e }]))})`,
                },
              })
            );
        "afterInteractive" === o &&
          r &&
          a.default.preload(
            r,
            _.integrity
              ? { as: "script", integrity: _.integrity, nonce: I, crossOrigin: _.crossOrigin }
              : { as: "script", nonce: I, crossOrigin: _.crossOrigin },
          );
      }
      return null;
    }
    Object.defineProperty(E, "__nextScript", { value: !0 });
    let m = E;
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (e.exports = r.default));
  },
  467034,
  (t, e, r) => {
    var n = {
        872: function (t, e) {
          "use strict";
          ((e.byteLength = function (t) {
            var e = a(t),
              r = e[0],
              n = e[1];
            return ((r + n) * 3) / 4 - n;
          }),
            (e.toByteArray = function (t) {
              var e,
                r,
                o = a(t),
                f = o[0],
                u = o[1],
                s = new i(((f + u) * 3) / 4 - u),
                c = 0,
                l = u > 0 ? f - 4 : f;
              for (r = 0; r < l; r += 4)
                ((e =
                  (n[t.charCodeAt(r)] << 18) |
                  (n[t.charCodeAt(r + 1)] << 12) |
                  (n[t.charCodeAt(r + 2)] << 6) |
                  n[t.charCodeAt(r + 3)]),
                  (s[c++] = (e >> 16) & 255),
                  (s[c++] = (e >> 8) & 255),
                  (s[c++] = 255 & e));
              return (
                2 === u &&
                  ((e = (n[t.charCodeAt(r)] << 2) | (n[t.charCodeAt(r + 1)] >> 4)), (s[c++] = 255 & e)),
                1 === u &&
                  ((e =
                    (n[t.charCodeAt(r)] << 10) |
                    (n[t.charCodeAt(r + 1)] << 4) |
                    (n[t.charCodeAt(r + 2)] >> 2)),
                  (s[c++] = (e >> 8) & 255),
                  (s[c++] = 255 & e)),
                s
              );
            }),
            (e.fromByteArray = function (t) {
              for (var e, n = t.length, i = n % 3, o = [], f = 0, u = n - i; f < u; f += 16383)
                o.push(
                  (function (t, e, n) {
                    for (var i, o = [], f = e; f < n; f += 3)
                      ((i = ((t[f] << 16) & 0xff0000) + ((t[f + 1] << 8) & 65280) + (255 & t[f + 2])),
                        o.push(r[(i >> 18) & 63] + r[(i >> 12) & 63] + r[(i >> 6) & 63] + r[63 & i]));
                    return o.join("");
                  })(t, f, f + 16383 > u ? u : f + 16383),
                );
              return (
                1 === i
                  ? o.push(r[(e = t[n - 1]) >> 2] + r[(e << 4) & 63] + "==")
                  : 2 === i &&
                    o.push(
                      r[(e = (t[n - 2] << 8) + t[n - 1]) >> 10] + r[(e >> 4) & 63] + r[(e << 2) & 63] + "=",
                    ),
                o.join("")
              );
            }));
          for (
            var r = [],
              n = [],
              i = "u" > typeof Uint8Array ? Uint8Array : Array,
              o = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
              f = 0,
              u = o.length;
            f < u;
            ++f
          )
            ((r[f] = o[f]), (n[o.charCodeAt(f)] = f));
          function a(t) {
            var e = t.length;
            if (e % 4 > 0) throw Error("Invalid string. Length must be a multiple of 4");
            var r = t.indexOf("=");
            -1 === r && (r = e);
            var n = r === e ? 0 : 4 - (r % 4);
            return [r, n];
          }
          ((n[45] = 62), (n[95] = 63));
        },
        230: function (t, e, r) {
          "use strict";
          var n = r(872),
            i = r(321),
            o =
              "function" == typeof Symbol && "function" == typeof Symbol.for
                ? Symbol.for("nodejs.util.inspect.custom")
                : null;
          function f(t) {
            if (t > 0x7fffffff) throw RangeError('The value "' + t + '" is invalid for option "size"');
            var e = new Uint8Array(t);
            return (Object.setPrototypeOf(e, u.prototype), e);
          }
          function u(t, e, r) {
            if ("number" == typeof t) {
              if ("string" == typeof e)
                throw TypeError('The "string" argument must be of type string. Received type number');
              return c(t);
            }
            return a(t, e, r);
          }
          function a(t, e, r) {
            if ("string" == typeof t) {
              var n = t,
                i = e;
              if ((("string" != typeof i || "" === i) && (i = "utf8"), !u.isEncoding(i)))
                throw TypeError("Unknown encoding: " + i);
              var o = 0 | p(n, i),
                a = f(o),
                s = a.write(n, i);
              return (s !== o && (a = a.slice(0, s)), a);
            }
            if (ArrayBuffer.isView(t)) return l(t);
            if (null == t)
              throw TypeError(
                "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " +
                  typeof t,
              );
            if (
              C(t, ArrayBuffer) ||
              (t && C(t.buffer, ArrayBuffer)) ||
              ("u" > typeof SharedArrayBuffer &&
                (C(t, SharedArrayBuffer) || (t && C(t.buffer, SharedArrayBuffer))))
            )
              return (function (t, e, r) {
                var n;
                if (e < 0 || t.byteLength < e) throw RangeError('"offset" is outside of buffer bounds');
                if (t.byteLength < e + (r || 0)) throw RangeError('"length" is outside of buffer bounds');
                return (
                  Object.setPrototypeOf(
                    (n =
                      void 0 === e && void 0 === r
                        ? new Uint8Array(t)
                        : void 0 === r
                          ? new Uint8Array(t, e)
                          : new Uint8Array(t, e, r)),
                    u.prototype,
                  ),
                  n
                );
              })(t, e, r);
            if ("number" == typeof t)
              throw TypeError('The "value" argument must not be of type number. Received type number');
            var c = t.valueOf && t.valueOf();
            if (null != c && c !== t) return u.from(c, e, r);
            var _ = (function (t) {
              if (u.isBuffer(t)) {
                var e = 0 | h(t.length),
                  r = f(e);
                return (0 === r.length || t.copy(r, 0, 0, e), r);
              }
              return void 0 !== t.length
                ? "number" != typeof t.length ||
                  (function (t) {
                    return t != t;
                  })(t.length)
                  ? f(0)
                  : l(t)
                : "Buffer" === t.type && Array.isArray(t.data)
                  ? l(t.data)
                  : void 0;
            })(t);
            if (_) return _;
            if (
              "u" > typeof Symbol &&
              null != Symbol.toPrimitive &&
              "function" == typeof t[Symbol.toPrimitive]
            )
              return u.from(t[Symbol.toPrimitive]("string"), e, r);
            throw TypeError(
              "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " +
                typeof t,
            );
          }
          function s(t) {
            if ("number" != typeof t) throw TypeError('"size" argument must be of type number');
            if (t < 0) throw RangeError('The value "' + t + '" is invalid for option "size"');
          }
          function c(t) {
            return (s(t), f(t < 0 ? 0 : 0 | h(t)));
          }
          function l(t) {
            for (var e = t.length < 0 ? 0 : 0 | h(t.length), r = f(e), n = 0; n < e; n += 1)
              r[n] = 255 & t[n];
            return r;
          }
          ((e.Buffer = u),
            (e.SlowBuffer = function (t) {
              return (+t != t && (t = 0), u.alloc(+t));
            }),
            (e.INSPECT_MAX_BYTES = 50),
            (e.kMaxLength = 0x7fffffff),
            (u.TYPED_ARRAY_SUPPORT = (function () {
              try {
                var t = new Uint8Array(1),
                  e = {
                    foo: function () {
                      return 42;
                    },
                  };
                return (
                  Object.setPrototypeOf(e, Uint8Array.prototype),
                  Object.setPrototypeOf(t, e),
                  42 === t.foo()
                );
              } catch (t) {
                return !1;
              }
            })()),
            !u.TYPED_ARRAY_SUPPORT &&
              "u" > typeof console &&
              "function" == typeof console.error &&
              console.error(
                "This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support.",
              ),
            Object.defineProperty(u.prototype, "parent", {
              enumerable: !0,
              get: function () {
                if (u.isBuffer(this)) return this.buffer;
              },
            }),
            Object.defineProperty(u.prototype, "offset", {
              enumerable: !0,
              get: function () {
                if (u.isBuffer(this)) return this.byteOffset;
              },
            }),
            (u.poolSize = 8192),
            (u.from = function (t, e, r) {
              return a(t, e, r);
            }),
            Object.setPrototypeOf(u.prototype, Uint8Array.prototype),
            Object.setPrototypeOf(u, Uint8Array),
            (u.alloc = function (t, e, r) {
              return (s(t), t <= 0)
                ? f(t)
                : void 0 !== e
                  ? "string" == typeof r
                    ? f(t).fill(e, r)
                    : f(t).fill(e)
                  : f(t);
            }),
            (u.allocUnsafe = function (t) {
              return c(t);
            }),
            (u.allocUnsafeSlow = function (t) {
              return c(t);
            }));
          function h(t) {
            if (t >= 0x7fffffff)
              throw RangeError("Attempt to allocate Buffer larger than maximum size: 0x7fffffff bytes");
            return 0 | t;
          }
          function p(t, e) {
            if (u.isBuffer(t)) return t.length;
            if (ArrayBuffer.isView(t) || C(t, ArrayBuffer)) return t.byteLength;
            if ("string" != typeof t)
              throw TypeError(
                'The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' +
                  typeof t,
              );
            var r = t.length,
              n = arguments.length > 2 && !0 === arguments[2];
            if (!n && 0 === r) return 0;
            for (var i = !1; ;)
              switch (e) {
                case "ascii":
                case "latin1":
                case "binary":
                  return r;
                case "utf8":
                case "utf-8":
                  return v(t).length;
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                  return 2 * r;
                case "hex":
                  return r >>> 1;
                case "base64":
                  return R(t).length;
                default:
                  if (i) return n ? -1 : v(t).length;
                  ((e = ("" + e).toLowerCase()), (i = !0));
              }
          }
          function _(t, e, r) {
            var i,
              o,
              f,
              u = !1;
            if (
              ((void 0 === e || e < 0) && (e = 0),
              e > this.length ||
                ((void 0 === r || r > this.length) && (r = this.length), r <= 0 || (r >>>= 0) <= (e >>>= 0)))
            )
              return "";
            for (t || (t = "utf8"); ;)
              switch (t) {
                case "hex":
                  return (function (t, e, r) {
                    var n = t.length;
                    ((!e || e < 0) && (e = 0), (!r || r < 0 || r > n) && (r = n));
                    for (var i = "", o = e; o < r; ++o) i += w[t[o]];
                    return i;
                  })(this, e, r);
                case "utf8":
                case "utf-8":
                  return A(this, e, r);
                case "ascii":
                  return (function (t, e, r) {
                    var n = "";
                    r = Math.min(t.length, r);
                    for (var i = e; i < r; ++i) n += String.fromCharCode(127 & t[i]);
                    return n;
                  })(this, e, r);
                case "latin1":
                case "binary":
                  return (function (t, e, r) {
                    var n = "";
                    r = Math.min(t.length, r);
                    for (var i = e; i < r; ++i) n += String.fromCharCode(t[i]);
                    return n;
                  })(this, e, r);
                case "base64":
                  return (
                    (i = this),
                    (o = e),
                    (f = r),
                    0 === o && f === i.length ? n.fromByteArray(i) : n.fromByteArray(i.slice(o, f))
                  );
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                  return (function (t, e, r) {
                    for (var n = t.slice(e, r), i = "", o = 0; o < n.length; o += 2)
                      i += String.fromCharCode(n[o] + 256 * n[o + 1]);
                    return i;
                  })(this, e, r);
                default:
                  if (u) throw TypeError("Unknown encoding: " + t);
                  ((t = (t + "").toLowerCase()), (u = !0));
              }
          }
          function d(t, e, r) {
            var n = t[e];
            ((t[e] = t[r]), (t[r] = n));
          }
          function g(t, e, r, n, i) {
            var o;
            if (0 === t.length) return -1;
            if (
              ("string" == typeof r
                ? ((n = r), (r = 0))
                : r > 0x7fffffff
                  ? (r = 0x7fffffff)
                  : r < -0x80000000 && (r = -0x80000000),
              (o = r *= 1) != o && (r = i ? 0 : t.length - 1),
              r < 0 && (r = t.length + r),
              r >= t.length)
            )
              if (i) return -1;
              else r = t.length - 1;
            else if (r < 0)
              if (!i) return -1;
              else r = 0;
            if (("string" == typeof e && (e = u.from(e, n)), u.isBuffer(e)))
              return 0 === e.length ? -1 : y(t, e, r, n, i);
            if ("number" == typeof e) {
              if (((e &= 255), "function" == typeof Uint8Array.prototype.indexOf))
                if (i) return Uint8Array.prototype.indexOf.call(t, e, r);
                else return Uint8Array.prototype.lastIndexOf.call(t, e, r);
              return y(t, [e], r, n, i);
            }
            throw TypeError("val must be string, number or Buffer");
          }
          function y(t, e, r, n, i) {
            var o,
              f = 1,
              u = t.length,
              a = e.length;
            if (
              void 0 !== n &&
              ("ucs2" === (n = String(n).toLowerCase()) ||
                "ucs-2" === n ||
                "utf16le" === n ||
                "utf-16le" === n)
            ) {
              if (t.length < 2 || e.length < 2) return -1;
              ((f = 2), (u /= 2), (a /= 2), (r /= 2));
            }
            function s(t, e) {
              return 1 === f ? t[e] : t.readUInt16BE(e * f);
            }
            if (i) {
              var c = -1;
              for (o = r; o < u; o++)
                if (s(t, o) === s(e, -1 === c ? 0 : o - c)) {
                  if ((-1 === c && (c = o), o - c + 1 === a)) return c * f;
                } else (-1 !== c && (o -= o - c), (c = -1));
            } else
              for (r + a > u && (r = u - a), o = r; o >= 0; o--) {
                for (var l = !0, h = 0; h < a; h++)
                  if (s(t, o + h) !== s(e, h)) {
                    l = !1;
                    break;
                  }
                if (l) return o;
              }
            return -1;
          }
          ((u.isBuffer = function (t) {
            return null != t && !0 === t._isBuffer && t !== u.prototype;
          }),
            (u.compare = function (t, e) {
              if (
                (C(t, Uint8Array) && (t = u.from(t, t.offset, t.byteLength)),
                C(e, Uint8Array) && (e = u.from(e, e.offset, e.byteLength)),
                !u.isBuffer(t) || !u.isBuffer(e))
              )
                throw TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');
              if (t === e) return 0;
              for (var r = t.length, n = e.length, i = 0, o = Math.min(r, n); i < o; ++i)
                if (t[i] !== e[i]) {
                  ((r = t[i]), (n = e[i]));
                  break;
                }
              return r < n ? -1 : +(n < r);
            }),
            (u.isEncoding = function (t) {
              switch (String(t).toLowerCase()) {
                case "hex":
                case "utf8":
                case "utf-8":
                case "ascii":
                case "latin1":
                case "binary":
                case "base64":
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                  return !0;
                default:
                  return !1;
              }
            }),
            (u.concat = function (t, e) {
              if (!Array.isArray(t)) throw TypeError('"list" argument must be an Array of Buffers');
              if (0 === t.length) return u.alloc(0);
              if (void 0 === e) for (r = 0, e = 0; r < t.length; ++r) e += t[r].length;
              var r,
                n = u.allocUnsafe(e),
                i = 0;
              for (r = 0; r < t.length; ++r) {
                var o = t[r];
                if ((C(o, Uint8Array) && (o = u.from(o)), !u.isBuffer(o)))
                  throw TypeError('"list" argument must be an Array of Buffers');
                (o.copy(n, i), (i += o.length));
              }
              return n;
            }),
            (u.byteLength = p),
            (u.prototype._isBuffer = !0),
            (u.prototype.swap16 = function () {
              var t = this.length;
              if (t % 2 != 0) throw RangeError("Buffer size must be a multiple of 16-bits");
              for (var e = 0; e < t; e += 2) d(this, e, e + 1);
              return this;
            }),
            (u.prototype.swap32 = function () {
              var t = this.length;
              if (t % 4 != 0) throw RangeError("Buffer size must be a multiple of 32-bits");
              for (var e = 0; e < t; e += 4) (d(this, e, e + 3), d(this, e + 1, e + 2));
              return this;
            }),
            (u.prototype.swap64 = function () {
              var t = this.length;
              if (t % 8 != 0) throw RangeError("Buffer size must be a multiple of 64-bits");
              for (var e = 0; e < t; e += 8)
                (d(this, e, e + 7), d(this, e + 1, e + 6), d(this, e + 2, e + 5), d(this, e + 3, e + 4));
              return this;
            }),
            (u.prototype.toString = function () {
              var t = this.length;
              return 0 === t ? "" : 0 == arguments.length ? A(this, 0, t) : _.apply(this, arguments);
            }),
            (u.prototype.toLocaleString = u.prototype.toString),
            (u.prototype.equals = function (t) {
              if (!u.isBuffer(t)) throw TypeError("Argument must be a Buffer");
              return this === t || 0 === u.compare(this, t);
            }),
            (u.prototype.inspect = function () {
              var t = "",
                r = e.INSPECT_MAX_BYTES;
              return (
                (t = this.toString("hex", 0, r)
                  .replace(/(.{2})/g, "$1 ")
                  .trim()),
                this.length > r && (t += " ... "),
                "<Buffer " + t + ">"
              );
            }),
            o && (u.prototype[o] = u.prototype.inspect),
            (u.prototype.compare = function (t, e, r, n, i) {
              if ((C(t, Uint8Array) && (t = u.from(t, t.offset, t.byteLength)), !u.isBuffer(t)))
                throw TypeError(
                  'The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof t,
                );
              if (
                (void 0 === e && (e = 0),
                void 0 === r && (r = t ? t.length : 0),
                void 0 === n && (n = 0),
                void 0 === i && (i = this.length),
                e < 0 || r > t.length || n < 0 || i > this.length)
              )
                throw RangeError("out of range index");
              if (n >= i && e >= r) return 0;
              if (n >= i) return -1;
              if (e >= r) return 1;
              if (((e >>>= 0), (r >>>= 0), (n >>>= 0), (i >>>= 0), this === t)) return 0;
              for (
                var o = i - n, f = r - e, a = Math.min(o, f), s = this.slice(n, i), c = t.slice(e, r), l = 0;
                l < a;
                ++l
              )
                if (s[l] !== c[l]) {
                  ((o = s[l]), (f = c[l]));
                  break;
                }
              return o < f ? -1 : +(f < o);
            }),
            (u.prototype.includes = function (t, e, r) {
              return -1 !== this.indexOf(t, e, r);
            }),
            (u.prototype.indexOf = function (t, e, r) {
              return g(this, t, e, r, !0);
            }),
            (u.prototype.lastIndexOf = function (t, e, r) {
              return g(this, t, e, r, !1);
            }));
          function A(t, e, r) {
            r = Math.min(t.length, r);
            for (var n = [], i = e; i < r;) {
              var o,
                f,
                u,
                a,
                s = t[i],
                c = null,
                l = s > 239 ? 4 : s > 223 ? 3 : s > 191 ? 2 : 1;
              if (i + l <= r)
                switch (l) {
                  case 1:
                    s < 128 && (c = s);
                    break;
                  case 2:
                    (192 & (o = t[i + 1])) == 128 && (a = ((31 & s) << 6) | (63 & o)) > 127 && (c = a);
                    break;
                  case 3:
                    ((o = t[i + 1]),
                      (f = t[i + 2]),
                      (192 & o) == 128 &&
                        (192 & f) == 128 &&
                        (a = ((15 & s) << 12) | ((63 & o) << 6) | (63 & f)) > 2047 &&
                        (a < 55296 || a > 57343) &&
                        (c = a));
                    break;
                  case 4:
                    ((o = t[i + 1]),
                      (f = t[i + 2]),
                      (u = t[i + 3]),
                      (192 & o) == 128 &&
                        (192 & f) == 128 &&
                        (192 & u) == 128 &&
                        (a = ((15 & s) << 18) | ((63 & o) << 12) | ((63 & f) << 6) | (63 & u)) > 65535 &&
                        a < 1114112 &&
                        (c = a));
                }
              (null === c
                ? ((c = 65533), (l = 1))
                : c > 65535 && ((c -= 65536), n.push(((c >>> 10) & 1023) | 55296), (c = 56320 | (1023 & c))),
                n.push(c),
                (i += l));
            }
            var h = n,
              p = h.length;
            if (p <= 4096) return String.fromCharCode.apply(String, h);
            for (var _ = "", d = 0; d < p;) _ += String.fromCharCode.apply(String, h.slice(d, (d += 4096)));
            return _;
          }
          function E(t, e, r) {
            if (t % 1 != 0 || t < 0) throw RangeError("offset is not uint");
            if (t + e > r) throw RangeError("Trying to access beyond buffer length");
          }
          function m(t, e, r, n, i, o) {
            if (!u.isBuffer(t)) throw TypeError('"buffer" argument must be a Buffer instance');
            if (e > i || e < o) throw RangeError('"value" argument is out of bounds');
            if (r + n > t.length) throw RangeError("Index out of range");
          }
          function I(t, e, r, n, i, o) {
            if (r + n > t.length || r < 0) throw RangeError("Index out of range");
          }
          function T(t, e, r, n, o) {
            return (
              (e *= 1),
              (r >>>= 0),
              o || I(t, e, r, 4, 34028234663852886e22, -34028234663852886e22),
              i.write(t, e, r, n, 23, 4),
              r + 4
            );
          }
          function M(t, e, r, n, o) {
            return (
              (e *= 1),
              (r >>>= 0),
              o || I(t, e, r, 8, 17976931348623157e292, -17976931348623157e292),
              i.write(t, e, r, n, 52, 8),
              r + 8
            );
          }
          ((u.prototype.write = function (t, e, r, n) {
            if (void 0 === e) ((n = "utf8"), (r = this.length), (e = 0));
            else if (void 0 === r && "string" == typeof e) ((n = e), (r = this.length), (e = 0));
            else if (isFinite(e))
              ((e >>>= 0),
                isFinite(r) ? ((r >>>= 0), void 0 === n && (n = "utf8")) : ((n = r), (r = void 0)));
            else throw Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
            var i,
              o,
              f,
              u,
              a,
              s,
              c,
              l,
              h = this.length - e;
            if (((void 0 === r || r > h) && (r = h), (t.length > 0 && (r < 0 || e < 0)) || e > this.length))
              throw RangeError("Attempt to write outside buffer bounds");
            n || (n = "utf8");
            for (var p = !1; ;)
              switch (n) {
                case "hex":
                  return (function (t, e, r, n) {
                    r = Number(r) || 0;
                    var i = t.length - r;
                    n ? (n = Number(n)) > i && (n = i) : (n = i);
                    var o = e.length;
                    n > o / 2 && (n = o / 2);
                    for (var f = 0; f < n; ++f) {
                      var u,
                        a = parseInt(e.substr(2 * f, 2), 16);
                      if ((u = a) != u) break;
                      t[r + f] = a;
                    }
                    return f;
                  })(this, t, e, r);
                case "utf8":
                case "utf-8":
                  return ((i = e), (o = r), S(v(t, this.length - i), this, i, o));
                case "ascii":
                  return ((f = e), (u = r), S(U(t), this, f, u));
                case "latin1":
                case "binary":
                  return (function (t, e, r, n) {
                    return S(U(e), t, r, n);
                  })(this, t, e, r);
                case "base64":
                  return ((a = e), (s = r), S(R(t), this, a, s));
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                  return (
                    (c = e),
                    (l = r),
                    S(
                      (function (t, e) {
                        for (var r, n, i = [], o = 0; o < t.length && !((e -= 2) < 0); ++o)
                          ((n = (r = t.charCodeAt(o)) >> 8), i.push(r % 256), i.push(n));
                        return i;
                      })(t, this.length - c),
                      this,
                      c,
                      l,
                    )
                  );
                default:
                  if (p) throw TypeError("Unknown encoding: " + n);
                  ((n = ("" + n).toLowerCase()), (p = !0));
              }
          }),
            (u.prototype.toJSON = function () {
              return { type: "Buffer", data: Array.prototype.slice.call(this._arr || this, 0) };
            }),
            (u.prototype.slice = function (t, e) {
              var r = this.length;
              ((t = ~~t),
                (e = void 0 === e ? r : ~~e),
                t < 0 ? (t += r) < 0 && (t = 0) : t > r && (t = r),
                e < 0 ? (e += r) < 0 && (e = 0) : e > r && (e = r),
                e < t && (e = t));
              var n = this.subarray(t, e);
              return (Object.setPrototypeOf(n, u.prototype), n);
            }),
            (u.prototype.readUIntLE = function (t, e, r) {
              ((t >>>= 0), (e >>>= 0), r || E(t, e, this.length));
              for (var n = this[t], i = 1, o = 0; ++o < e && (i *= 256);) n += this[t + o] * i;
              return n;
            }),
            (u.prototype.readUIntBE = function (t, e, r) {
              ((t >>>= 0), (e >>>= 0), r || E(t, e, this.length));
              for (var n = this[t + --e], i = 1; e > 0 && (i *= 256);) n += this[t + --e] * i;
              return n;
            }),
            (u.prototype.readUInt8 = function (t, e) {
              return ((t >>>= 0), e || E(t, 1, this.length), this[t]);
            }),
            (u.prototype.readUInt16LE = function (t, e) {
              return ((t >>>= 0), e || E(t, 2, this.length), this[t] | (this[t + 1] << 8));
            }),
            (u.prototype.readUInt16BE = function (t, e) {
              return ((t >>>= 0), e || E(t, 2, this.length), (this[t] << 8) | this[t + 1]);
            }),
            (u.prototype.readUInt32LE = function (t, e) {
              return (
                (t >>>= 0),
                e || E(t, 4, this.length),
                (this[t] | (this[t + 1] << 8) | (this[t + 2] << 16)) + 0x1000000 * this[t + 3]
              );
            }),
            (u.prototype.readUInt32BE = function (t, e) {
              return (
                (t >>>= 0),
                e || E(t, 4, this.length),
                0x1000000 * this[t] + ((this[t + 1] << 16) | (this[t + 2] << 8) | this[t + 3])
              );
            }),
            (u.prototype.readIntLE = function (t, e, r) {
              ((t >>>= 0), (e >>>= 0), r || E(t, e, this.length));
              for (var n = this[t], i = 1, o = 0; ++o < e && (i *= 256);) n += this[t + o] * i;
              return (n >= (i *= 128) && (n -= Math.pow(2, 8 * e)), n);
            }),
            (u.prototype.readIntBE = function (t, e, r) {
              ((t >>>= 0), (e >>>= 0), r || E(t, e, this.length));
              for (var n = e, i = 1, o = this[t + --n]; n > 0 && (i *= 256);) o += this[t + --n] * i;
              return (o >= (i *= 128) && (o -= Math.pow(2, 8 * e)), o);
            }),
            (u.prototype.readInt8 = function (t, e) {
              return ((t >>>= 0), e || E(t, 1, this.length), 128 & this[t])
                ? -((255 - this[t] + 1) * 1)
                : this[t];
            }),
            (u.prototype.readInt16LE = function (t, e) {
              ((t >>>= 0), e || E(t, 2, this.length));
              var r = this[t] | (this[t + 1] << 8);
              return 32768 & r ? 0xffff0000 | r : r;
            }),
            (u.prototype.readInt16BE = function (t, e) {
              ((t >>>= 0), e || E(t, 2, this.length));
              var r = this[t + 1] | (this[t] << 8);
              return 32768 & r ? 0xffff0000 | r : r;
            }),
            (u.prototype.readInt32LE = function (t, e) {
              return (
                (t >>>= 0),
                e || E(t, 4, this.length),
                this[t] | (this[t + 1] << 8) | (this[t + 2] << 16) | (this[t + 3] << 24)
              );
            }),
            (u.prototype.readInt32BE = function (t, e) {
              return (
                (t >>>= 0),
                e || E(t, 4, this.length),
                (this[t] << 24) | (this[t + 1] << 16) | (this[t + 2] << 8) | this[t + 3]
              );
            }),
            (u.prototype.readFloatLE = function (t, e) {
              return ((t >>>= 0), e || E(t, 4, this.length), i.read(this, t, !0, 23, 4));
            }),
            (u.prototype.readFloatBE = function (t, e) {
              return ((t >>>= 0), e || E(t, 4, this.length), i.read(this, t, !1, 23, 4));
            }),
            (u.prototype.readDoubleLE = function (t, e) {
              return ((t >>>= 0), e || E(t, 8, this.length), i.read(this, t, !0, 52, 8));
            }),
            (u.prototype.readDoubleBE = function (t, e) {
              return ((t >>>= 0), e || E(t, 8, this.length), i.read(this, t, !1, 52, 8));
            }),
            (u.prototype.writeUIntLE = function (t, e, r, n) {
              if (((t *= 1), (e >>>= 0), (r >>>= 0), !n)) {
                var i = Math.pow(2, 8 * r) - 1;
                m(this, t, e, r, i, 0);
              }
              var o = 1,
                f = 0;
              for (this[e] = 255 & t; ++f < r && (o *= 256);) this[e + f] = (t / o) & 255;
              return e + r;
            }),
            (u.prototype.writeUIntBE = function (t, e, r, n) {
              if (((t *= 1), (e >>>= 0), (r >>>= 0), !n)) {
                var i = Math.pow(2, 8 * r) - 1;
                m(this, t, e, r, i, 0);
              }
              var o = r - 1,
                f = 1;
              for (this[e + o] = 255 & t; --o >= 0 && (f *= 256);) this[e + o] = (t / f) & 255;
              return e + r;
            }),
            (u.prototype.writeUInt8 = function (t, e, r) {
              return ((t *= 1), (e >>>= 0), r || m(this, t, e, 1, 255, 0), (this[e] = 255 & t), e + 1);
            }),
            (u.prototype.writeUInt16LE = function (t, e, r) {
              return (
                (t *= 1),
                (e >>>= 0),
                r || m(this, t, e, 2, 65535, 0),
                (this[e] = 255 & t),
                (this[e + 1] = t >>> 8),
                e + 2
              );
            }),
            (u.prototype.writeUInt16BE = function (t, e, r) {
              return (
                (t *= 1),
                (e >>>= 0),
                r || m(this, t, e, 2, 65535, 0),
                (this[e] = t >>> 8),
                (this[e + 1] = 255 & t),
                e + 2
              );
            }),
            (u.prototype.writeUInt32LE = function (t, e, r) {
              return (
                (t *= 1),
                (e >>>= 0),
                r || m(this, t, e, 4, 0xffffffff, 0),
                (this[e + 3] = t >>> 24),
                (this[e + 2] = t >>> 16),
                (this[e + 1] = t >>> 8),
                (this[e] = 255 & t),
                e + 4
              );
            }),
            (u.prototype.writeUInt32BE = function (t, e, r) {
              return (
                (t *= 1),
                (e >>>= 0),
                r || m(this, t, e, 4, 0xffffffff, 0),
                (this[e] = t >>> 24),
                (this[e + 1] = t >>> 16),
                (this[e + 2] = t >>> 8),
                (this[e + 3] = 255 & t),
                e + 4
              );
            }),
            (u.prototype.writeIntLE = function (t, e, r, n) {
              if (((t *= 1), (e >>>= 0), !n)) {
                var i = Math.pow(2, 8 * r - 1);
                m(this, t, e, r, i - 1, -i);
              }
              var o = 0,
                f = 1,
                u = 0;
              for (this[e] = 255 & t; ++o < r && (f *= 256);)
                (t < 0 && 0 === u && 0 !== this[e + o - 1] && (u = 1),
                  (this[e + o] = (((t / f) | 0) - u) & 255));
              return e + r;
            }),
            (u.prototype.writeIntBE = function (t, e, r, n) {
              if (((t *= 1), (e >>>= 0), !n)) {
                var i = Math.pow(2, 8 * r - 1);
                m(this, t, e, r, i - 1, -i);
              }
              var o = r - 1,
                f = 1,
                u = 0;
              for (this[e + o] = 255 & t; --o >= 0 && (f *= 256);)
                (t < 0 && 0 === u && 0 !== this[e + o + 1] && (u = 1),
                  (this[e + o] = (((t / f) | 0) - u) & 255));
              return e + r;
            }),
            (u.prototype.writeInt8 = function (t, e, r) {
              return (
                (t *= 1),
                (e >>>= 0),
                r || m(this, t, e, 1, 127, -128),
                t < 0 && (t = 255 + t + 1),
                (this[e] = 255 & t),
                e + 1
              );
            }),
            (u.prototype.writeInt16LE = function (t, e, r) {
              return (
                (t *= 1),
                (e >>>= 0),
                r || m(this, t, e, 2, 32767, -32768),
                (this[e] = 255 & t),
                (this[e + 1] = t >>> 8),
                e + 2
              );
            }),
            (u.prototype.writeInt16BE = function (t, e, r) {
              return (
                (t *= 1),
                (e >>>= 0),
                r || m(this, t, e, 2, 32767, -32768),
                (this[e] = t >>> 8),
                (this[e + 1] = 255 & t),
                e + 2
              );
            }),
            (u.prototype.writeInt32LE = function (t, e, r) {
              return (
                (t *= 1),
                (e >>>= 0),
                r || m(this, t, e, 4, 0x7fffffff, -0x80000000),
                (this[e] = 255 & t),
                (this[e + 1] = t >>> 8),
                (this[e + 2] = t >>> 16),
                (this[e + 3] = t >>> 24),
                e + 4
              );
            }),
            (u.prototype.writeInt32BE = function (t, e, r) {
              return (
                (t *= 1),
                (e >>>= 0),
                r || m(this, t, e, 4, 0x7fffffff, -0x80000000),
                t < 0 && (t = 0xffffffff + t + 1),
                (this[e] = t >>> 24),
                (this[e + 1] = t >>> 16),
                (this[e + 2] = t >>> 8),
                (this[e + 3] = 255 & t),
                e + 4
              );
            }),
            (u.prototype.writeFloatLE = function (t, e, r) {
              return T(this, t, e, !0, r);
            }),
            (u.prototype.writeFloatBE = function (t, e, r) {
              return T(this, t, e, !1, r);
            }),
            (u.prototype.writeDoubleLE = function (t, e, r) {
              return M(this, t, e, !0, r);
            }),
            (u.prototype.writeDoubleBE = function (t, e, r) {
              return M(this, t, e, !1, r);
            }),
            (u.prototype.copy = function (t, e, r, n) {
              if (!u.isBuffer(t)) throw TypeError("argument should be a Buffer");
              if (
                (r || (r = 0),
                n || 0 === n || (n = this.length),
                e >= t.length && (e = t.length),
                e || (e = 0),
                n > 0 && n < r && (n = r),
                n === r || 0 === t.length || 0 === this.length)
              )
                return 0;
              if (e < 0) throw RangeError("targetStart out of bounds");
              if (r < 0 || r >= this.length) throw RangeError("Index out of range");
              if (n < 0) throw RangeError("sourceEnd out of bounds");
              (n > this.length && (n = this.length), t.length - e < n - r && (n = t.length - e + r));
              var i = n - r;
              if (this === t && "function" == typeof Uint8Array.prototype.copyWithin)
                this.copyWithin(e, r, n);
              else if (this === t && r < e && e < n) for (var o = i - 1; o >= 0; --o) t[o + e] = this[o + r];
              else Uint8Array.prototype.set.call(t, this.subarray(r, n), e);
              return i;
            }),
            (u.prototype.fill = function (t, e, r, n) {
              if ("string" == typeof t) {
                if (
                  ("string" == typeof e
                    ? ((n = e), (e = 0), (r = this.length))
                    : "string" == typeof r && ((n = r), (r = this.length)),
                  void 0 !== n && "string" != typeof n)
                )
                  throw TypeError("encoding must be a string");
                if ("string" == typeof n && !u.isEncoding(n)) throw TypeError("Unknown encoding: " + n);
                if (1 === t.length) {
                  var i,
                    o = t.charCodeAt(0);
                  (("utf8" === n && o < 128) || "latin1" === n) && (t = o);
                }
              } else "number" == typeof t ? (t &= 255) : "boolean" == typeof t && (t = Number(t));
              if (e < 0 || this.length < e || this.length < r) throw RangeError("Out of range index");
              if (r <= e) return this;
              if (
                ((e >>>= 0), (r = void 0 === r ? this.length : r >>> 0), t || (t = 0), "number" == typeof t)
              )
                for (i = e; i < r; ++i) this[i] = t;
              else {
                var f = u.isBuffer(t) ? t : u.from(t, n),
                  a = f.length;
                if (0 === a) throw TypeError('The value "' + t + '" is invalid for argument "value"');
                for (i = 0; i < r - e; ++i) this[i + e] = f[i % a];
              }
              return this;
            }));
          var b = /[^+/0-9A-Za-z-_]/g;
          function v(t, e) {
            e = e || 1 / 0;
            for (var r, n = t.length, i = null, o = [], f = 0; f < n; ++f) {
              if ((r = t.charCodeAt(f)) > 55295 && r < 57344) {
                if (!i) {
                  if (r > 56319 || f + 1 === n) {
                    (e -= 3) > -1 && o.push(239, 191, 189);
                    continue;
                  }
                  i = r;
                  continue;
                }
                if (r < 56320) {
                  ((e -= 3) > -1 && o.push(239, 191, 189), (i = r));
                  continue;
                }
                r = (((i - 55296) << 10) | (r - 56320)) + 65536;
              } else i && (e -= 3) > -1 && o.push(239, 191, 189);
              if (((i = null), r < 128)) {
                if ((e -= 1) < 0) break;
                o.push(r);
              } else if (r < 2048) {
                if ((e -= 2) < 0) break;
                o.push((r >> 6) | 192, (63 & r) | 128);
              } else if (r < 65536) {
                if ((e -= 3) < 0) break;
                o.push((r >> 12) | 224, ((r >> 6) & 63) | 128, (63 & r) | 128);
              } else if (r < 1114112) {
                if ((e -= 4) < 0) break;
                o.push((r >> 18) | 240, ((r >> 12) & 63) | 128, ((r >> 6) & 63) | 128, (63 & r) | 128);
              } else throw Error("Invalid code point");
            }
            return o;
          }
          function U(t) {
            for (var e = [], r = 0; r < t.length; ++r) e.push(255 & t.charCodeAt(r));
            return e;
          }
          function R(t) {
            return n.toByteArray(
              (function (t) {
                if ((t = (t = t.split("=")[0]).trim().replace(b, "")).length < 2) return "";
                for (; t.length % 4 != 0;) t += "=";
                return t;
              })(t),
            );
          }
          function S(t, e, r, n) {
            for (var i = 0; i < n && !(i + r >= e.length) && !(i >= t.length); ++i) e[i + r] = t[i];
            return i;
          }
          function C(t, e) {
            return (
              t instanceof e ||
              (null != t &&
                null != t.constructor &&
                null != t.constructor.name &&
                t.constructor.name === e.name)
            );
          }
          var w = (function () {
            for (var t = "0123456789abcdef", e = Array(256), r = 0; r < 16; ++r)
              for (var n = 16 * r, i = 0; i < 16; ++i) e[n + i] = t[r] + t[i];
            return e;
          })();
        },
        321: function (t, e) {
          ((e.read = function (t, e, r, n, i) {
            var o,
              f,
              u = 8 * i - n - 1,
              a = (1 << u) - 1,
              s = a >> 1,
              c = -7,
              l = r ? i - 1 : 0,
              h = r ? -1 : 1,
              p = t[e + l];
            for (
              l += h, o = p & ((1 << -c) - 1), p >>= -c, c += u;
              c > 0;
              o = 256 * o + t[e + l], l += h, c -= 8
            );
            for (f = o & ((1 << -c) - 1), o >>= -c, c += n; c > 0; f = 256 * f + t[e + l], l += h, c -= 8);
            if (0 === o) o = 1 - s;
            else {
              if (o === a) return f ? NaN : (1 / 0) * (p ? -1 : 1);
              ((f += Math.pow(2, n)), (o -= s));
            }
            return (p ? -1 : 1) * f * Math.pow(2, o - n);
          }),
            (e.write = function (t, e, r, n, i, o) {
              var f,
                u,
                a,
                s = 8 * o - i - 1,
                c = (1 << s) - 1,
                l = c >> 1,
                h = 5960464477539062e-23 * (23 === i),
                p = n ? 0 : o - 1,
                _ = n ? 1 : -1,
                d = +(e < 0 || (0 === e && 1 / e < 0));
              for (
                isNaN((e = Math.abs(e))) || e === 1 / 0
                  ? ((u = +!!isNaN(e)), (f = c))
                  : ((f = Math.floor(Math.log(e) / Math.LN2)),
                    e * (a = Math.pow(2, -f)) < 1 && (f--, (a *= 2)),
                    f + l >= 1 ? (e += h / a) : (e += h * Math.pow(2, 1 - l)),
                    e * a >= 2 && (f++, (a /= 2)),
                    f + l >= c
                      ? ((u = 0), (f = c))
                      : f + l >= 1
                        ? ((u = (e * a - 1) * Math.pow(2, i)), (f += l))
                        : ((u = e * Math.pow(2, l - 1) * Math.pow(2, i)), (f = 0)));
                i >= 8;
                t[r + p] = 255 & u, p += _, u /= 256, i -= 8
              );
              for (f = (f << i) | u, s += i; s > 0; t[r + p] = 255 & f, p += _, f /= 256, s -= 8);
              t[r + p - _] |= 128 * d;
            }));
        },
      },
      i = {};
    function o(t) {
      var e = i[t];
      if (void 0 !== e) return e.exports;
      var r = (i[t] = { exports: {} }),
        f = !0;
      try {
        (n[t](r, r.exports, o), (f = !1));
      } finally {
        f && delete i[t];
      }
      return r.exports;
    }
    ((o.ab = "/ROOT/node_modules/next/dist/compiled/buffer/"), (e.exports = o(230)));
  },
  3303,
  (t, e, r) => {
    e.exports = t.r(479520);
  },
  879568,
  276394,
  480408,
  (t) => {
    "use strict";
    var e = t.i(866897),
      r = t.i(562942),
      n = t.i(924254);
    let i = {
      getCookie: (t) => {
        if ("u" < typeof document) return null;
        let e = document.cookie.match(RegExp("(^|; )" + t + "=([^;]*)"));
        return e ? decodeURIComponent(e[2]) : null;
      },
      getFbcCookie: () => i.getCookie("_fbc"),
      getFbpCookie: () => i.getCookie("_fbp"),
    };
    t.s(["cookieUtil", 0, i], 276394);
    let o = {
      collectAttributionData: (t) => {
        let e = t || new URLSearchParams(window.location.search);
        return Object.fromEntries(
          Object.entries({
            referral_domain: e.get(r.UTM_PARAMS.MYIQ_UTM_REFERRAL_DOMAIN) || void 0,
            utm_source: e.get(r.UTM_PARAMS.MYIQ_UTM_SOURCE) || void 0,
            utm_medium: e.get(r.UTM_PARAMS.MYIQ_UTM_MEDIUM) || void 0,
            utm_campaign_id: e.get(r.UTM_PARAMS.MYIQ_UTM_CAMPAIGN_ID) || e.get("utm_cid") || void 0,
            utm_campaign: e.get(r.UTM_PARAMS.MYIQ_UTM_CAMPAIGN) || void 0,
            utm_adgroup_id:
              e.get(r.UTM_PARAMS.MYIQ_UTM_ADGROUP_ID) ||
              e.get(r.UTM_PARAMS.MYIQ_UTM_ADSET_ID) ||
              e.get("utm_agid") ||
              void 0,
            utm_adgroup:
              e.get(r.UTM_PARAMS.MYIQ_UTM_ADGROUP) ||
              e.get(r.UTM_PARAMS.MYIQ_UTM_ADSET) ||
              e.get("utm_ag") ||
              void 0,
            utm_ad_id: e.get(r.UTM_PARAMS.MYIQ_UTM_AD_ID) || e.get("utm_aid") || void 0,
            utm_ad_name: e.get(r.UTM_PARAMS.MYIQ_UTM_AD_NAME) || void 0,
            utm_term: e.get(r.UTM_PARAMS.MYIQ_UTM_TERM) || void 0,
            utm_target_id: e.get(r.UTM_PARAMS.MYIQ_UTM_TARGET_ID) || void 0,
            utm_content_id: e.get(r.UTM_PARAMS.MYIQ_UTM_CONTENT_ID) || void 0,
            utm_content: e.get(r.UTM_PARAMS.MYIQ_UTM_CONTENT) || void 0,
            wbraid: e.get(r.UTM_PARAMS.MYIQ_UTM_WBRAID) || void 0,
            initial_current_url: e.get(r.UTM_PARAMS.INITIAL_CURRENT_URL) || void 0,
            gclid: e.get(r.UTM_PARAMS.MYIQ_UTM_GCLID) || void 0,
            fbclid: e.get(r.UTM_PARAMS.MYIQ_UTM_FBCLID) || void 0,
            kwai_click_id: e.get(r.UTM_PARAMS.MYIQ_UTM_CLICK_ID) || void 0,
            fbc: i.getFbcCookie() || void 0,
            fbp: i.getFbpCookie() || void 0,
          }).filter((t) => {
            let [e, r] = t;
            return void 0 !== r;
          }),
        );
      },
      readAttributionData: () => {
        let t = n.accessCookie.getItem(e.ECookieArg.ATTRIBUTION_STORAGE_KEY);
        if (!t) return null;
        try {
          return JSON.parse(t);
        } catch {
          return (n.accessCookie.removeItem(e.ECookieArg.ATTRIBUTION_STORAGE_KEY), null);
        }
      },
      saveAttributionData: (t) => {
        try {
          let r = o.readAttributionData(),
            i = { ...r, ...t };
          (Object.keys(i).some((t) => i[t]) || !r) &&
            n.accessCookie.setItem(e.ECookieArg.ATTRIBUTION_STORAGE_KEY, JSON.stringify(i));
        } catch (t) {
          console.error("Failed to save attribution data:", t);
        }
      },
      formatForPaymentMetadata: (t) => {
        if (!t) return {};
        let e = {};
        return (
          Object.entries(t).forEach((t) => {
            let [r, n] = t;
            null != n && (e[r] = "string" == typeof n || "number" == typeof n ? n : String(n));
          }),
          e
        );
      },
      formatForMixpanel: (t) => {
        if (!t) return {};
        let e = {};
        return (
          Object.entries(t).forEach((t) => {
            let [r, n] = t;
            null != n && (e[`attr_${r}`] = "string" == typeof n || "number" == typeof n ? n : String(n));
          }),
          e
        );
      },
      formatForMixpanelRegister: (t) => {
        if (!t) return {};
        let e = {};
        return (
          Object.entries(t).forEach((t) => {
            let [r, n] = t;
            null != n && (e[`${r}`] = "string" == typeof n || "number" == typeof n ? n : String(n));
          }),
          e
        );
      },
      initializeAttribution: () => {
        let t = o.collectAttributionData();
        return (o.saveAttributionData(t), t);
      },
    };
    (t.s(["attributionUtil", 0, o], 480408), t.s([], 879568));
  },
  866897,
  (t) => {
    "use strict";
    var e,
      r =
        (((e = {}).USER = "token"),
        (e.SESSION_DATA = "session_data"),
        (e.PROFILE_DATA = "profile_data"),
        (e.BILLING_DATA = "billing_data"),
        (e.LOCALE = "NEXT_LOCALE"),
        (e.SESSION_ID = "session-id"),
        (e.FRIEND_DATA = "friend-data"),
        (e.MARKETING_AD = "marketing_ad"),
        (e.USER_EMAIL = "user_email"),
        (e.COUNTRY = "x-country"),
        (e.APP_RETURNING_CUSTOMER = "myiq_app_returning_customer"),
        (e.CITY = "x-city"),
        (e.CONFIRM_CODE = "confirm-code"),
        (e.REFRESH_TOKEN = "refresh_token"),
        (e.BILLING_SESSION = "billing_session"),
        (e.GOOGLE_AUTH_PATH = "google_auth_path"),
        (e.SOCIAL_SIGNUP_INTENT = "social_signup_intent"),
        (e.SOCIAL_SIGNUP_EMAIL = "social_signup_email"),
        (e.ATTRIBUTION_STORAGE_KEY = "attribution_data"),
        (e.PAYNEXT_SESSION = "paynext-session"),
        (e.ACCESS_TO_CANCELLATION = "access_to_cancellation"),
        (e.CANCELLATION_SESSION = "cancellation_session"),
        (e.ACCESS_TO_DELETE_ACCOUNT = "access_to_delete_account"),
        (e.DELETE_ACCOUNT_SESSION = "delete_account_session"),
        (e.BRAIN_TRAINING_PARAM = "brain_training_param"),
        (e.CHECKOUT_TIMER_START = "checkout_timer_start"),
        (e.PLAN_PICKER_FUNNEL = "plan_picker_funnel"),
        (e.US_A1_CAMPAIGN = "us_a1_campaign"),
        (e.BR_CAMPAIGN = "br_campaign"),
        (e.BT_FUNNEL = "bt_funnel"),
        (e.SHOW_FUNNEL_FOOTER = "show_funnel_footer"),
        (e.GOOGLE_TRAFFIC = "google_traffic"),
        (e.UTM_SOURCE = "utm_source"),
        (e.PERSONALITY_FUNNEL_VARIANT = "personality_funnel_variant"),
        (e.TEST_TRAFFIC = "test_traffic"),
        (e.LEGACY_FUNNEL = "legacy_funnel"),
        (e.PLAYGROUND_FUNNEL = "playground_funnel"),
        (e.COOKIE_CONSENT = "cookie_consent"),
        (e.SELECTED_HERO_ID = "selected_hero_id"),
        e);
    t.s(["ECookieArg", () => r]);
  },
  562942,
  (t) => {
    "use strict";
    var e,
      r =
        (((e = {}).ID = "5808a8650adceaed7faf15dbf2c819476dc6e5545515d9736443d3fb0d25e39e"),
        (e.MYIQ_OWN_PARAM = "myiq"),
        (e.MYIQ_PARAM_ID = "id"),
        (e.MYIQ_PREVENT_PARAM_GOOGLE = "sm"),
        (e.MYIQ_PREVENT_PARAM_GOOGLE_VALUE = "c3RyaWN0TW9kZQ"),
        (e.MYIQ_PARAM = "e"),
        (e.MYIQ_PARAM_GOOGLE = "g"),
        (e.MYIQ_PARAM_TIKTOK = "t"),
        (e.MYIQ_PARAM_APPLOVIN = "al"),
        (e.MYIQ_UTM_USER_TOKEN = "user_token"),
        (e.INITIAL_CURRENT_URL = "initial_current_url"),
        (e.MYIQ_BRAIN_TRAINING = "bt"),
        (e.MYIQ_UTM = "utm_tag"),
        (e.MYIQ_UTM_REFERRAL_DOMAIN = "referral_domain"),
        (e.MYIQ_UTM_SOURCE = "utm_source"),
        (e.MYIQ_UTM_MEDIUM = "utm_medium"),
        (e.MYIQ_UTM_CAMPAIGN = "utm_campaign"),
        (e.MYIQ_UTM_CAMPAIGN_ID = "utm_campaign_id"),
        (e.MYIQ_UTM_ADGROUP_ID = "utm_adgroup_id"),
        (e.MYIQ_UTM_ADGROUP = "utm_adgroup"),
        (e.MYIQ_UTM_AD_ID = "utm_ad_id"),
        (e.MYIQ_UTM_TERM = "utm_term"),
        (e.MYIQ_UTM_GCLID = "gclid"),
        (e.MYIQ_UTM_FBCLID = "fbclid"),
        (e.MYIQ_UTM_CLICK_ID = "click_id"),
        (e.MYIQ_UTM_AD_NAME = "utm_ad_name"),
        (e.MYIQ_UTM_TARGET_ID = "utm_target_id"),
        (e.MYIQ_UTM_WBRAID = "wbraid"),
        (e.MYIQ_UTM_ADSET_ID = "utm_adset_id"),
        (e.MYIQ_UTM_ADSET = "utm_adset"),
        (e.MYIQ_UTM_CONTENT_ID = "utm_content_id"),
        (e.MYIQ_UTM_CONTENT = "utm_content"),
        (e.MYIQ_UTM_FBC = "fbc"),
        (e.MYIQ_UTM_FBP = "fbp"),
        (e.MYIQ_UTM_SOURCE_ID = "utm_source_id"),
        e);
    t.s(["UTM_PARAMS", () => r]);
  },
  924254,
  (t) => {
    "use strict";
    t.s([
      "accessCookie",
      0,
      {
        getItem: (t) => {
          {
            let e = document.cookie.split(";").find((e) => e.trim().startsWith(`${t}=`));
            if (!e) return null;
            let r = e.trim().slice(t.length + 1);
            try {
              return decodeURIComponent(r);
            } catch {
              return r;
            }
          }
        },
        setItem: (t, e, r) => {
          {
            let n = r?.session ? "" : "; max-age=2592000";
            document.cookie = `${t}=${encodeURIComponent(e)}; path=/${n}`;
          }
        },
        removeItem: (t) => {
          document.cookie = `${t}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
        },
      },
    ]);
  },
  725397,
  (t) => {
    "use strict";
    var e;
    (((e = {}).US_UK = "US_UK"), (e.EU_EEA = "EU_EEA"), (e.TIER_2 = "TIER_2"), (e.REST = "REST"));
    let r = new Set(["LONDON", "CARDIFF"]),
      n = (t, e) => t?.toUpperCase() === "GB" && r.has((e ?? "").trim().toUpperCase()),
      i = new Set([
        "AT",
        "BE",
        "BG",
        "HR",
        "CY",
        "CZ",
        "DK",
        "EE",
        "FI",
        "FR",
        "DE",
        "GR",
        "HU",
        "IE",
        "IT",
        "LV",
        "LT",
        "LU",
        "MT",
        "NL",
        "PL",
        "PT",
        "RO",
        "SK",
        "SI",
        "ES",
        "SE",
        "IS",
        "LI",
        "NO",
      ]),
      o = new Set(["JP", "AU", "CA", "BR", "KR", "NZ", "SG"]);
    t.s([
      "EU_EEA_COUNTRIES",
      0,
      i,
      "getBillingCycleDays",
      0,
      (t) => (t?.toUpperCase() === "BR" ? 30 : 28),
      "isGb",
      0,
      (t) => t?.toUpperCase() === "GB",
      "isUk",
      0,
      n,
      "isUs",
      0,
      (t) => t?.toUpperCase() === "US",
      "isUsOrAnyUk",
      0,
      (t) => {
        let e = t?.toUpperCase();
        return "US" === e || "GB" === e;
      },
      "isUsUk",
      0,
      (t, e) => {
        let r;
        return (
          "US_UK" ==
          ((r = t?.toUpperCase())
            ? "US" === r || n(r, e)
              ? "US_UK"
              : i.has(r)
                ? "EU_EEA"
                : o.has(r)
                  ? "TIER_2"
                  : "REST"
            : "REST")
        );
      },
    ]);
  },
]);
