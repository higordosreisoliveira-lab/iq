(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  702761,
  (e) => {
    "use strict";
    e.s([
      "CORRECT_ANSWERS",
      0,
      {
        7: "A",
        8: "F",
        9: "B",
        10: "A",
        11: "C",
        12: "A",
        13: "F",
        14: "F",
        15: "E",
        16: "F",
        17: "E",
        18: "A",
        19: "E",
        20: "C",
        21: "D",
        22: "A",
        23: "A",
        24: "D",
        25: "C",
        26: "F",
        27: "E",
        28: "E",
        29: "B",
        30: "C",
        31: "D",
      },
    ]);
  },
  245588,
  (e) => {
    "use strict";
    var t = e.i(157273),
      s = e.i(60423);
    e.s([
      "clearQuizAnswersFromLocalStorage",
      0,
      () => {
        s.accessLocalStorage.removeItem(t.StorageKeys.QUIZ_ANSWERS);
      },
      "getQuizAnswersFromLocalStorage",
      0,
      () => {
        let e = s.accessLocalStorage.getItem(t.StorageKeys.QUIZ_ANSWERS);
        return e ? JSON.parse(e) : null;
      },
    ]);
  },
  224033,
  895106,
  (e) => {
    "use strict";
    let t = (e) => {
      let { baseId: t, userAnswer: s, correctAnswer: r } = e;
      if (!t || t < 1 || t > 100) return null;
      let a = `abq${t}`,
        i = `aba${t}-${s}`,
        n = r ? `aba${t}-${r}` : i;
      return { questionImageId: a, userAnswerImageId: i, correctAnswerImageId: n };
    };
    e.s(["generateRetakeQuizAnswerImages", 0, t], 895106);
    var s = e.i(157273),
      r = e.i(60423),
      a = e.i(278718);
    e.i(245588);
    let i = (e, t) => {
      let s = t - e.reduce((e, t) => e + (t.timeSpent || 0), 0);
      return s > 0
        ? ((e, t) => {
            if (t <= 0 || 0 === e.length) return e;
            let s = e.map((e, t) => t);
            for (let e = s.length - 1; e > 0; e--) {
              let t = Math.floor(Math.random() * (e + 1));
              [s[e], s[t]] = [s[t], s[e]];
            }
            let r = [...e],
              a = t,
              i = 0;
            for (; a > 0 && i < s.length;) {
              let e = s[i],
                t = Math.min(Math.floor(3 * Math.random()) + 1, a);
              ((r[e] = { ...r[e], timeSpent: (r[e].timeSpent || 0) + t }), (a -= t), i++);
            }
            if (a > 0) {
              let e = Math.floor(a / r.length),
                t = a % r.length;
              r.forEach((s, a) => {
                r[a] = { ...s, timeSpent: (s.timeSpent || 0) + e + +(a < t) };
              });
            }
            return r;
          })(e, s)
        : e;
    };
    e.s(
      [
        "saveQuizAnswersToLocalStorage",
        0,
        (e) => {
          let { userAnswers: n, questionTimes: u, totalSpentTime: o, isProfile: l, isABQuiz: d } = e,
            c = n
              .filter((e) => void 0 !== e.userAnswer)
              .map((e) => {
                let s = { id: e.id, baseId: e.baseId, userAnswer: e.userAnswer, timeSpent: u?.[e.id] || 0 },
                  r = d
                    ? t({ baseId: e.baseId, userAnswer: e.userAnswer, correctAnswer: e.correctAnswer })
                    : (0, a.generateQuizAnswerImages)({
                        baseId: e.baseId,
                        userAnswer: e.userAnswer,
                        correctAnswer: e.correctAnswer,
                      }) || t({ baseId: e.baseId, userAnswer: e.userAnswer, correctAnswer: e.correctAnswer });
                return r
                  ? {
                      ...s,
                      questionImageId: r.questionImageId,
                      userAnswerImageId: r.userAnswerImageId,
                      correctAnswerImageId: r.correctAnswerImageId,
                    }
                  : s;
              }),
            m = void 0 !== o ? i(c, o) : c;
          if (l) return m;
          r.accessLocalStorage.setItem(s.StorageKeys.QUIZ_ANSWERS, JSON.stringify(m));
        },
        "synchronizeQuestionTimes",
        0,
        i,
      ],
      224033,
    );
  },
  83488,
  (e) => {
    "use strict";
    var t,
      s,
      r = (((t = {}).BASE = "retake-iq-base"), (t.ADVANCED = "retake-iq-advanced"), t),
      a =
        (((s = {}).NOT_STARTED = "not_started"),
        (s.IN_PROGRESS = "in_progress"),
        (s.FINISHED = "finished"),
        s);
    e.s(["ERetakeQuizStatus", () => a, "ERetakeQuizTestType", () => r]);
  },
  491965,
  (e) => {
    "use strict";
    var t = e.i(83488);
    let s = (e, t) => (e?.retake_quiz_data || {})[t];
    e.s([
      "getCurrentQuestionIdFromAnswers",
      0,
      (e) => (e && 0 !== e.length ? Math.max(...e.map((e) => e.id)) + 1 : 1),
      "getRetakeQuizTestData",
      0,
      s,
      "getSecondsPassedFromAnswers",
      0,
      (e) => (e && 0 !== e.length ? e.reduce((e, t) => e + (t.timeSpent || 0), 0) : 0),
      "getTestInProgress",
      0,
      (e) => {
        let s = Object.entries(e?.retake_quiz_data || {}).find((e) => {
          let [s, r] = e;
          return r.status === t.ERetakeQuizStatus.IN_PROGRESS;
        });
        return s ? s[0] : null;
      },
      "isTestFinished",
      0,
      (e, r) => {
        let a = s(e, r);
        return a?.status === t.ERetakeQuizStatus.FINISHED;
      },
      "updateTestData",
      0,
      (e, t, s) => ({ ...e, [t]: { ...(e[t] || {}), ...s } }),
    ]);
  },
  571083,
  (e) => {
    "use strict";
    var t = e.i(224033);
    e.s([
      "synchronizeRetakeQuizAnswers",
      0,
      (e, s) => {
        let r = Object.values(e);
        return (0, t.synchronizeQuestionTimes)(r, s);
      },
    ]);
  },
  31799,
  (e) => {
    "use strict";
    var t = e.i(768834),
      s = e.i(579473),
      r = e.i(60423);
    let a = "retake-quiz-storage",
      i = {
        currentTestType: null,
        currentQuestionId: null,
        userAnswers: null,
        secondsPassed: 0,
        isTimerPaused: !1,
        _hasHydrated: !1,
        isTestCompleted: !1,
        previousIQScore: null,
        newIQScore: null,
      },
      n = (0, t.create)()(
        (0, s.persist)(
          (e, t) => ({
            ...i,
            handleChangeRetakeQuizStore: (t) => e((e) => ({ ...e, ...t })),
            clearRetakeQuizStore: () => {
              let s = t()._hasHydrated;
              e({ ...i, _hasHydrated: s });
            },
            setHasHydrated: (t) => e({ _hasHydrated: t }),
          }),
          {
            name: a,
            onRehydrateStorage: () => (e) => {
              e?.setHasHydrated(!0);
            },
          },
        ),
      );
    e.s([
      "clearRetakeQuizFromLocalStorage",
      0,
      () => {
        r.accessLocalStorage.removeItem(a);
      },
      "useRetakeQuizStore",
      0,
      n,
    ]);
  },
  264267,
  (e) => {
    "use strict";
    var t = e.i(843476);
    e.s([
      "svgImage",
      0,
      (e, s) => {
        let r = "number" == typeof s ? { width: s, height: s } : s,
          a = (s) => {
            let { style: a, onError: i, ...n } = s;
            return (0, t.jsx)("img", {
              src: e,
              alt: "",
              width: r?.width,
              height: r?.height,
              ...n,
              style: a,
              onError: (t) => {
                let s, r;
                ((r = Number((s = t.currentTarget).dataset.retry ?? 0) + 1) > 2 ||
                  ((s.dataset.retry = String(r)),
                  setTimeout(() => {
                    s.src = `${e}${e.includes("?") ? "&" : "?"}retry=${r}`;
                  }, 1e3 * r),
                  0)) &&
                  i?.(t);
              },
            });
          };
        return ((a.src = e), a);
      },
    ]);
  },
  946504,
  (e) => {
    "use strict";
    var t = e.i(843476),
      s = e.i(948148),
      r = e.i(271645),
      a = e.i(335889),
      i = e.i(742214);
    e.i(238275);
    var n = e.i(712470),
      u = e.i(134404),
      o = e.i(491965),
      l = e.i(571083),
      d = e.i(31799),
      c = e.i(622963),
      m = e.i(202042);
    (e.s([], 461068),
      e.i(461068),
      e.s(
        [
          "RetakeQuizModalQuitComponent",
          0,
          (e) => {
            let { user: g, isFromPurchase: h } = e,
              S = (0, s.useTranslations)(),
              { trigger: A } = (0, n.usePatchUserMutation)(),
              w = (0, m.useRouter)(),
              { handleCloseModalStore: I } = (0, c.useModalStore)(),
              p = (0, d.useRetakeQuizStore)((e) => e.handleChangeRetakeQuizStore),
              [_, R] = (0, r.useState)(!1);
            (0, r.useEffect)(
              () => (
                p({ isTimerPaused: !0 }),
                () => {
                  p({ isTimerPaused: !1 });
                }
              ),
              [p],
            );
            let f = async () => {
              if ((R(!0), !g?.email)) return;
              let e = d.useRetakeQuizStore.getState().currentTestType,
                t = d.useRetakeQuizStore.getState().userAnswers || {},
                s = d.useRetakeQuizStore.getState().secondsPassed,
                r = (0, l.synchronizeRetakeQuizAnswers)(t, s),
                a = g?.retake_quiz_data || {},
                i = (0, o.updateTestData)(a, e, { answers: r, secondsPassed: s }),
                n = await A({ email: g.email, userInfo: { retake_quiz_data: i } });
              n?.data && (I(), w.push(`${u.EClientRoutes.REPORT}?section=iq_test_retake`));
            };
            return (0, t.jsxs)(i.ModalContent, {
              className:
                "!m-0 flex max-w-md flex-col items-center gap-5 rounded-b-none p-6 max-md:overflow-auto sm:rounded-lg",
              children: [
                (0, t.jsxs)("div", {
                  className: "text-center",
                  children: [
                    (0, t.jsx)("h2", {
                      className: "mb-2 text-xl font-semibold text-gray-900",
                      children: S("retake_iq_modal_quit_title"),
                    }),
                    (0, t.jsx)("p", {
                      className: "text-sm text-gray-600",
                      children: S("retake_iq_modal_quit_description"),
                    }),
                  ],
                }),
                (0, t.jsxs)("div", {
                  className: "mt-auto flex w-full flex-col gap-2.5",
                  children: [
                    (0, t.jsx)(a.Button, {
                      onPress: f,
                      disableRipple: !0,
                      fullWidth: !0,
                      className:
                        "h-12 !whitespace-normal rounded-xl bg-green-custom font-semibold text-white text-medium md:text-base",
                      variant: "flat",
                      isLoading: _,
                      children: S("btn_exit"),
                    }),
                    !h &&
                      (0, t.jsx)(a.Button, {
                        disableRipple: !0,
                        onPress: () => {
                          (I(), p({ isTimerPaused: !1 }));
                        },
                        fullWidth: !0,
                        className:
                          "h-12 whitespace-pre-wrap rounded-xl bg-[#EFF2FD] font-semibold text-[#121620] text-medium md:text-base",
                        variant: "flat",
                        isDisabled: _,
                        children: S("retake_iq_report_block_answers_card_cta_continue"),
                      }),
                  ],
                }),
              ],
            });
          },
        ],
        946504,
      ));
  },
  607899,
  function (e) {
    e.n(e.i(946504));
  },
]);
