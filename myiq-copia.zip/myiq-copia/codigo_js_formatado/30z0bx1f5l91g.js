(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  882983,
  (e) => {
    "use strict";
    var t = e.i(265840),
      i = e.i(271645),
      s = e.i(273830),
      r = e.i(620253),
      a = e.i(75540),
      l = e.i(843476),
      o = (0, s.forwardRef)((e, s) => {
        let { as: o, children: _, className: n, ...u } = e,
          { slots: d, classNames: T, bodyId: m, setBodyMounted: c } = (0, t.useModalContext)(),
          S = (0, r.useDOMRef)(s);
        return (
          (0, i.useEffect)(() => (c(!0), () => c(!1)), [c]),
          (0, l.jsx)(o || "div", {
            ref: S,
            className: d.body({ class: (0, a.clsx)(null == T ? void 0 : T.body, n) }),
            id: m,
            ...u,
            children: _,
          })
        );
      });
    ((o.displayName = "HeroUI.ModalBody"), e.s(["ModalBody", 0, o], 882983));
  },
  642055,
  (e) => {
    "use strict";
    var t = e.i(134404),
      i = e.i(190899);
    let s = "previousPath",
      r = [t.EClientRoutes.START_TRIVIA, t.EClientRoutes.QUIZ_TRIVIA];
    e.s([
      "navigateBackFromTrivia",
      0,
      (e) => {
        let a;
        e.replace(
          (a = i.accessSessionStorageUtil.getItem(s) || "") && !r.includes(a)
            ? a
            : t.EClientRoutes.BASE_PROFILE,
        );
      },
      "savePreviousPath",
      0,
      (e) => {
        i.accessSessionStorageUtil.setItem(s, e);
      },
    ]);
  },
  476643,
  408241,
  (e) => {
    "use strict";
    var t = e.i(768834),
      i = e.i(579473),
      s = e.i(265832);
    let r = {
        timeLeft: s.TIMER_DURATION,
        streak: 0,
        maxStreak: 0,
        earnedXPCurrentLevel: 0,
        correctAnswers: 0,
        currentQuestionIdx: 0,
        isTestCompleted: !1,
        streakMilestonesReached: { streak3: !1, streak5: !1, streak10: !1 },
        hearts: s.HEARTS_CONFIG.INITIAL_HEARTS,
        currentCognitiveSkill: "working-memory",
        currentLevel: 1,
        cognitiveSkillName: "generic",
        questionTimes: [],
        questionStartTime: null,
        fiftyFiftyUses: s.POWER_UPS_CONFIG.INITIAL_FIFTY_FIFTY_USES,
        extraTimeUses: s.POWER_UPS_CONFIG.INITIAL_EXTRA_TIME_USES,
        usedFiftyFiftyOnQuestion: null,
        usedExtraTimeOnQuestion: null,
        disabledAnswers: [],
        achivedXPBoostId: null,
        fiftyFiftyRefillAt: null,
        extraTimeRefillAt: null,
        heartsRefillAt: null,
        progressSaved: !1,
        skillBoosts: { logic: 0, visual: 0, memory: 0 },
        showLevelUpConfetti: !1,
        completionSoundPlayed: !1,
        givenAnswers: [],
        dailyProgress: { date: null, levelsCompleted: 0, dailyTargetsCompleted: 0 },
      },
      a = (0, t.create)()(
        (0, i.persist)(
          (0, i.devtools)(
            (e) => ({
              ...r,
              handleTriviaTestStore: (t) => e((e) => ({ ...e, ...t })),
              resetTriviaTestStore: () => e(r),
              clearStorage: () => {
                (e(r), localStorage.removeItem("trivia-test-storage"));
              },
            }),
            { enabled: !1 },
          ),
          {
            name: "trivia-test-storage",
            partialize: (e) => ({
              currentQuestionIdx: e.currentQuestionIdx,
              streak: e.streak,
              maxStreak: e.maxStreak,
              earnedXPCurrentLevel: e.earnedXPCurrentLevel,
              correctAnswers: e.correctAnswers,
              isTestCompleted: e.isTestCompleted,
              streakMilestonesReached: e.streakMilestonesReached,
              hearts: e.hearts,
              currentCognitiveSkill: e.currentCognitiveSkill,
              currentLevel: e.currentLevel,
              cognitiveSkillName: e.cognitiveSkillName,
              questionTimes: e.questionTimes,
              questionStartTime: e.questionStartTime,
              fiftyFiftyUses: e.fiftyFiftyUses,
              extraTimeUses: e.extraTimeUses,
              usedFiftyFiftyOnQuestion: e.usedFiftyFiftyOnQuestion,
              usedExtraTimeOnQuestion: e.usedExtraTimeOnQuestion,
              disabledAnswers: e.disabledAnswers,
              fiftyFiftyRefillAt: e.fiftyFiftyRefillAt,
              extraTimeRefillAt: e.extraTimeRefillAt,
              heartsRefillAt: e.heartsRefillAt,
              skillBoosts: e.skillBoosts,
              achivedXPBoostId: e.achivedXPBoostId,
              givenAnswers: e.givenAnswers,
              dailyProgress: e.dailyProgress,
              completionSoundPlayed: e.completionSoundPlayed,
            }),
          },
        ),
      );
    (e.s(["useTriviaTestStore", 0, a], 408241), e.s([], 476643));
  },
  556767,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(948148),
      s = e.i(271645),
      r = e.i(61482),
      a = e.i(642055),
      l = e.i(712470),
      o = e.i(946684),
      _ = e.i(134404),
      n = e.i(157273),
      u = e.i(428460);
    e.i(568267);
    var d = e.i(154692),
      T = e.i(190899);
    e.i(476643);
    var m = e.i(408241),
      c = e.i(622963),
      S = e.i(86596),
      p = e.i(202042);
    e.i(317197);
    var f = e.i(231529);
    (e.s([], 212328),
      e.i(212328),
      e.s(
        [
          "GameQuitModalComponent",
          0,
          (e) => {
            let { onKeepLearning: I, isTriviaTest: E } = e,
              A = (0, i.useTranslations)(),
              v = (0, p.useRouter)(),
              { handleChangeModalStore: R } = (0, c.useModalStore)(),
              O = (0, S.useUserStore)((e) => e.user),
              { data: y } = (0, o.useGetProfileQuery)(O?.email || ""),
              U = y?.data?.user_info || O,
              g = (0, m.useTriviaTestStore)((e) => e.handleTriviaTestStore),
              { trigger: N } = (0, l.usePatchUserMutation)(),
              [x, C] = (0, s.useState)(!1),
              P = () => {
                R({ isModalVisible: !1, modalComponent: null });
              },
              L = async () => {
                if ((C(!0), E)) {
                  if (!U) return;
                  let e = u.useOptimisticXPStore.getState().xp,
                    {
                      hearts: t,
                      currentLevel: i,
                      currentCognitiveSkill: s,
                      fiftyFiftyUses: l,
                      extraTimeUses: o,
                      fiftyFiftyRefillAt: d,
                      extraTimeRefillAt: c,
                    } = m.useTriviaTestStore.getState(),
                    S = (0, r.createProgressPayload)({
                      existingData: U,
                      skillId: s,
                      state: {
                        hearts: t,
                        fiftyFiftyUses: l,
                        extraTimeUses: o,
                        fiftyFiftyRefillAt: d,
                        extraTimeRefillAt: c,
                      },
                      isCompleted: !1,
                      currentLevel: i,
                    });
                  (await N({ email: U.email || "", userInfo: { trivia_test_data: S, total_xp: e } }),
                    g({ progressSaved: !0 }),
                    P(),
                    T.accessSessionStorageUtil.getItem(n.StorageKeys.FROM_MOTIVATION_PATH) ===
                    _.EClientRoutes.REPORT
                      ? (T.accessSessionStorageUtil.removeItem(n.StorageKeys.FROM_MOTIVATION_PATH),
                        v.push(_.EClientRoutes.REPORT))
                      : (0, a.navigateBackFromTrivia)(v));
                } else (P(), v.push(_.EClientRoutes.BASE_PROFILE));
              };
            return (0, t.jsx)(f.ModalBodyComponent, {
              title: A("game_quit_modal_title"),
              subtitle: A("game_quit_modal_description"),
              children: (0, t.jsxs)("div", {
                className: "mt-auto flex flex-col gap-2.5",
                children: [
                  (0, t.jsx)(d.ButtonComponent, {
                    onClick: () => {
                      (P(), I && I());
                    },
                    isDisabled: x,
                    size: "sm",
                    children: A("game_quit_modal_keep_learning"),
                  }),
                  (0, t.jsx)(d.ButtonComponent, {
                    onClick: L,
                    isLoading: x,
                    variant: "default",
                    size: "sm",
                    children: A("game_quit_modal_exit"),
                  }),
                ],
              }),
            });
          },
        ],
        556767,
      ));
  },
  727908,
  function (e) {
    e.n(e.i(556767));
  },
  317197,
  231529,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(882983),
      s = e.i(742214),
      r = e.i(663615);
    e.i(680460);
    var a = e.i(885944);
    (e.s([], 317197),
      e.s(
        [
          "ModalBodyComponent",
          0,
          (e) => {
            let {
              children: l,
              title: o,
              subtitle: _,
              className: n = "",
              bodyClassName: u,
              titleClassName: d,
            } = e;
            return (0, t.jsx)(s.ModalContent, {
              className: n,
              children: (0, t.jsxs)(i.ModalBody, {
                className: (0, r.cn)(
                  "flex h-full w-full flex-col gap-5 p-5 antialiased md:p-6 [@media(max-height:580px)]:gap-3 [@media(max-height:580px)]:p-4",
                  u,
                ),
                children: [
                  (o || _) &&
                    (0, t.jsx)(a.ModalHeaderComponent, { title: o, subtitle: _, titleClassName: d }),
                  l,
                ],
              }),
            });
          },
        ],
        231529,
      ));
  },
  265832,
  (e) => {
    "use strict";
    e.s([
      "ANIMATION_CONFIG",
      0,
      { COIN_ANIMATION_DURATION: 1200, MIN_INTERVAL_DURATION: 16, NOTIFICATION_DELAY: 1200 },
      "AVERAGE_TIME_FOR_SKILL_BOOST",
      0,
      8e3,
      "DAILY_FULL_COMPLETION_KEYS",
      0,
      [
        "trivia_daily_full_0",
        "trivia_daily_full_1",
        "trivia_daily_full_2",
        "trivia_daily_full_3",
        "trivia_daily_full_4",
        "trivia_daily_full_5",
        "trivia_daily_full_6",
        "trivia_daily_full_7",
      ],
      "DAILY_NOT_FULL_COMPLETION_KEYS",
      0,
      [
        "trivia_daily_more_0",
        "trivia_daily_more_1",
        "trivia_daily_more_2",
        "trivia_daily_more_3",
        "trivia_daily_more_4",
        "trivia_daily_more_5",
        "trivia_daily_more_6",
        "trivia_daily_more_7",
      ],
      "DAILY_PROGRESS_SETS",
      0,
      5,
      "HEARTS_CONFIG",
      0,
      {
        INITIAL_HEARTS: 3,
        PURCHASED_HEARTS: 5,
        HEARTS_LOSS_PER_WRONG_ANSWER: 1,
        HEARTS_ANIMATION_DELAY: 700,
        HEARTS_ANIMATION_DURATION: 600,
      },
      "LEVEL_COMPLETED_BONUS",
      0,
      10,
      "MOVE_TO_TEST_COMPLETION_DELAY",
      0,
      400,
      "PLAY_COIN_REWARD_SOUND_AFTER_DELAY",
      0,
      500,
      "POWER_UPS_CONFIG",
      0,
      { INITIAL_FIFTY_FIFTY_USES: 3, INITIAL_EXTRA_TIME_USES: 3, EXTRA_TIME_SECONDS: 30, REFILL_TIME: 18e5 },
      "SKILL_BOOST_SCORE",
      0,
      0.3,
      "STREAK_BONUS_XP",
      0,
      { STREAK_3: 10, STREAK_5: 20, STREAK_10: 50 },
      "STREAK_MILESTONES",
      0,
      { STREAK_3: 3, STREAK_5: 5, STREAK_10: 10 },
      "TIMER_DURATION",
      0,
      20,
      "TIME_UNTIL_NEXT_TEST",
      0,
      18e5,
      "TRIVIA_COMPLETE_SCREEN_SUBTITLE_KEYS",
      0,
      [
        "trivia_complete_subtitle_0",
        "trivia_complete_subtitle_1",
        "trivia_complete_subtitle_2",
        "trivia_complete_subtitle_3",
        "trivia_complete_subtitle_4",
        "trivia_complete_subtitle_5",
        "trivia_complete_subtitle_6",
        "trivia_complete_subtitle_7",
      ],
      "XP_BOOST_CONFIG",
      0,
      [
        { id: 1, xp: 90, powerUp: 2, timeUp: 0, cutOff: 0 },
        { id: 2, xp: 200, powerUp: 3, timeUp: 1, cutOff: 0 },
        { id: 3, xp: 450, powerUp: 4, timeUp: 1, cutOff: 1 },
        { id: 4, xp: 800, powerUp: 5, timeUp: 2, cutOff: 1 },
        { id: 5, xp: 1400, powerUp: 7, timeUp: 3, cutOff: 2 },
        { id: 6, xp: 2200, powerUp: 10, timeUp: 4, cutOff: 3 },
        { id: 7, xp: 3200, powerUp: 12, timeUp: 5, cutOff: 4 },
        { id: 8, xp: 4500, powerUp: 15, timeUp: 6, cutOff: 5 },
        { id: 9, xp: 6500, powerUp: 18, timeUp: 8, cutOff: 6 },
        { id: 10, xp: 9e3, powerUp: 22, timeUp: 10, cutOff: 8 },
        { id: 11, xp: 13e3, powerUp: 27, timeUp: 12, cutOff: 10 },
        { id: 12, xp: 18e3, powerUp: 35, timeUp: 15, cutOff: 12 },
      ],
      "XP_PER_CORRECT_ANSWER",
      0,
      10,
    ]);
  },
  428460,
  (e) => {
    "use strict";
    var t = e.i(768834),
      i = e.i(579473);
    let s = (0, t.create)()(
      (0, i.persist)(
        (0, i.devtools)((e) => ({ xp: 0, setXP: (t) => e({ xp: t }), resetXP: () => e({ xp: 0 }) })),
        { name: "optimisticXP", version: 1 },
      ),
    );
    e.s(["useOptimisticXPStore", 0, s]);
  },
  190899,
  (e) => {
    "use strict";
    e.s([
      "accessSessionStorageUtil",
      0,
      {
        getItem: (e) => {
          try {
            return sessionStorage.getItem(e);
          } catch {
            return null;
          }
        },
        setItem: (e, t) => {
          try {
            sessionStorage.setItem(e, t);
          } catch {
            return;
          }
        },
        removeItem: (e) => {
          try {
            sessionStorage.removeItem(e);
          } catch {
            return;
          }
        },
      },
    ]);
  },
]);
