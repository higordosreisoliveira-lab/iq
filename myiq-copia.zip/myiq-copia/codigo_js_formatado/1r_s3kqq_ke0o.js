(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  728298,
  (e, t, r) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "useRouterBFCache", {
        enumerable: !0,
        get: function () {
          return l;
        },
      }));
    let n = e.r(271645);
    function l(e, t, r) {
      let [l, u] = (0, n.useState)(() => ({ tree: e, cacheNode: t, stateKey: r, next: null }));
      if (l.tree === e) return l;
      let a = { tree: e, cacheNode: t, stateKey: r, next: null },
        o = 1,
        d = l,
        s = a;
      for (; null !== d && o < 1;) {
        if (d.stateKey === r) {
          s.next = d.next;
          break;
        }
        {
          o++;
          let e = { tree: d.tree, cacheNode: d.cacheNode, stateKey: d.stateKey, next: null };
          ((s.next = e), (s = e));
        }
        d = d.next;
      }
      return (u(a), a);
    }
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  347257,
  (e, t, r) => {
    "use strict";
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "ClientPageRoot", {
        enumerable: !0,
        get: function () {
          return s;
        },
      }));
    let n = e.r(843476),
      l = e.r(8372),
      u = e.r(271645),
      a = e.r(33906),
      o = e.r(261994),
      d = e.r(15783);
    function s(e) {
      let t,
        r,
        { Component: s, serverProvidedParams: i } = e;
      if (null !== i) ((t = i.searchParams), (r = i.params));
      else {
        let e = (0, u.use)(l.LayoutRouterContext);
        ((r = null !== e ? e.parentParams : {}),
          (t = (0, a.urlSearchParamsToParsedUrlQuery)((0, u.use)(o.SearchParamsContext))));
      }
      let c = (0, d.createClientSearchParams)(t),
        f = (0, d.createClientParams)(r);
      return (0, n.jsx)(s, { params: f, searchParams: c });
    }
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  92825,
  (e, t, r) => {
    "use strict";
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "ClientSegmentRoot", {
        enumerable: !0,
        get: function () {
          return o;
        },
      }));
    let n = e.r(843476),
      l = e.r(8372),
      u = e.r(271645),
      a = e.r(15783);
    function o(e) {
      let t,
        { Component: r, slots: o, serverProvidedParams: d } = e;
      if (null !== d) t = d.params;
      else {
        let e = (0, u.use)(l.LayoutRouterContext);
        t = null !== e ? e.parentParams : {};
      }
      let s = (0, a.createClientParams)(t);
      return (0, n.jsx)(r, { ...o, params: s });
    }
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  768017,
  (e, t, r) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "HTTPAccessFallbackBoundary", {
        enumerable: !0,
        get: function () {
          return i;
        },
      }));
    let n = e.r(190809),
      l = e.r(843476),
      u = n._(e.r(271645)),
      a = e.r(590373),
      o = e.r(754394),
      d = e.r(8372);
    class s extends u.default.Component {
      constructor(e) {
        (super(e), (this.state = { triggeredStatus: void 0, previousPathname: e.pathname }));
      }
      componentDidCatch() {}
      static getDerivedStateFromError(e) {
        if ((0, o.isHTTPAccessFallbackError)(e))
          return { triggeredStatus: (0, o.getAccessFallbackHTTPStatus)(e) };
        throw e;
      }
      static getDerivedStateFromProps(e, t) {
        return e.pathname !== t.previousPathname && t.triggeredStatus
          ? { triggeredStatus: void 0, previousPathname: e.pathname }
          : { triggeredStatus: t.triggeredStatus, previousPathname: e.pathname };
      }
      render() {
        let { notFound: e, forbidden: t, unauthorized: r, children: n } = this.props,
          { triggeredStatus: u } = this.state,
          a = {
            [o.HTTPAccessErrorStatus.NOT_FOUND]: e,
            [o.HTTPAccessErrorStatus.FORBIDDEN]: t,
            [o.HTTPAccessErrorStatus.UNAUTHORIZED]: r,
          };
        if (u) {
          let d = u === o.HTTPAccessErrorStatus.NOT_FOUND && e,
            s = u === o.HTTPAccessErrorStatus.FORBIDDEN && t,
            i = u === o.HTTPAccessErrorStatus.UNAUTHORIZED && r;
          return d || s || i
            ? (0, l.jsxs)(l.Fragment, {
                children: [(0, l.jsx)("meta", { name: "robots", content: "noindex" }), !1, a[u]],
              })
            : n;
        }
        return n;
      }
    }
    function i(e) {
      let { notFound: t, forbidden: r, unauthorized: n, children: o } = e,
        i = (0, a.useUntrackedPathname)(),
        c = (0, u.useContext)(d.MissingSlotContext);
      return t || r || n
        ? (0, l.jsx)(s, {
            pathname: i,
            notFound: t,
            forbidden: r,
            unauthorized: n,
            missingSlots: c,
            children: o,
          })
        : (0, l.jsx)(l.Fragment, { children: o });
    }
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  722976,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      InstantValidationBoundaryContext: function () {
        return u;
      },
      PlaceValidationBoundaryBelowThisLevel: function () {
        return a;
      },
      RenderValidationBoundaryAtThisLevel: function () {
        return o;
      },
      SlotMarker: function () {
        return d;
      },
    };
    for (var l in n) Object.defineProperty(r, l, { enumerable: !0, get: n[l] });
    let u = null,
      a = null,
      o = null,
      d = null;
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  877694,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      InstantValidationBoundaryContext: function () {
        return u.InstantValidationBoundaryContext;
      },
      PlaceValidationBoundaryBelowThisLevel: function () {
        return u.PlaceValidationBoundaryBelowThisLevel;
      },
      RenderValidationBoundaryAtThisLevel: function () {
        return u.RenderValidationBoundaryAtThisLevel;
      },
      SlotMarker: function () {
        return u.SlotMarker;
      },
    };
    for (var l in n) Object.defineProperty(r, l, { enumerable: !0, get: n[l] });
    let u = e.r(722976);
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  339756,
  (e, t, r) => {
    "use strict";
    (e.i(247167), Object.defineProperty(r, "__esModule", { value: !0 }));
    var n = {
      LoadingBoundaryProvider: function () {
        return C;
      },
      default: function () {
        return T;
      },
    };
    for (var l in n) Object.defineProperty(r, l, { enumerable: !0, get: n[l] });
    let u = e.r(555682),
      a = e.r(190809),
      o = e.r(843476),
      d = a._(e.r(271645)),
      s = u._(e.r(174080)),
      i = e.r(8372),
      c = e.r(201244),
      f = e.r(972383),
      p = e.r(491915),
      y = e.r(358442),
      m = e.r(768017);
    e.r(877694);
    let b = e.r(270725),
      _ = e.r(728298);
    e.r(174180);
    let h = e.r(261994),
      P = e.r(33906),
      v = e.r(595871);
    s.default.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
    function g(e, t, r) {
      let n = e.getClientRects();
      if (0 === n.length) return 0;
      let l = 1 / 0;
      for (let e = 0; e < n.length; e++) {
        let t = n[e];
        t.top < l && (l = t.top);
      }
      return l >= r() && l <= t ? 1 : 2;
    }
    d.default.Component;
    let j = function (e) {
      let t = d.default.useRef(null);
      return (
        (0, d.useLayoutEffect)(
          () => {
            let { focusAndScrollRef: r, cacheNode: n } = e,
              l = r.forceScroll ? r.scrollRef : n.scrollRef;
            if (null === l || !l.current) return;
            let u = null,
              a = r.hashFragment;
            if (a) {
              var o;
              if (
                null ===
                (u =
                  "top" === (o = a)
                    ? document.body
                    : (document.getElementById(o) ?? document.getElementsByName(o)[0] ?? null))
              ) {
                ((l.current = !1), (r.onlyHashChange = !1), (r.hashFragment = null));
                return;
              }
            } else u = t.current;
            if (null === u) return;
            let d = !1;
            ((0, p.disableSmoothScrollDuringRouteTransition)(
              () => {
                let e = document.documentElement,
                  t = null,
                  r = null,
                  n = null,
                  o = () => {
                    var r, l;
                    let u, a;
                    return (
                      null === n &&
                        ((r = e),
                        (l = t),
                        (n =
                          !Number.isFinite(
                            (a = Number.parseFloat((u = getComputedStyle(r).scrollPaddingTop))),
                          ) || a < 0
                            ? 0
                            : u.endsWith("px")
                              ? a
                              : u.endsWith("%")
                                ? (a / 100) * l
                                : 0)),
                      n
                    );
                  };
                (a || ((t = e.clientHeight), 0 !== (r = g(u, t, o)))) &&
                  (((d = !0), (l.current = !1), a)
                    ? u.scrollIntoView()
                    : 1 !== r && ((e.scrollTop = 0), 2 === g(u, t, o) && u.scrollIntoView()));
              },
              { dontForceLayout: !0, onlyHashChange: r.onlyHashChange },
            ),
              d && ((r.onlyHashChange = !1), (r.hashFragment = null)));
          },
          void 0,
        ),
        (0, o.jsx)(d.Fragment, { ref: t, children: e.children })
      );
    };
    function O(e) {
      let { children: t, cacheNode: r } = e,
        n = (0, d.useContext)(i.GlobalLayoutRouterContext);
      if (!n)
        throw Object.defineProperty(
          Error("invariant global layout router not mounted"),
          "__NEXT_ERROR_CODE",
          { value: "E473", enumerable: !1, configurable: !0 },
        );
      return (0, o.jsx)(j, { focusAndScrollRef: n.focusAndScrollRef, cacheNode: r, children: t });
    }
    function x(e) {
      let t,
        { tree: r, segmentPath: n, debugNameContext: l, cacheNode: u, params: a, url: s, isActive: f } = e,
        p = (0, d.useContext)(i.GlobalLayoutRouterContext);
      if (((0, d.useContext)(h.NavigationPromisesContext), !p))
        throw Object.defineProperty(
          Error("invariant global layout router not mounted"),
          "__NEXT_ERROR_CODE",
          { value: "E473", enumerable: !1, configurable: !0 },
        );
      let y = null !== u ? u : (0, d.use)(c.unresolvedThenable),
        m = null !== y.prefetchRsc ? y.prefetchRsc : y.rsc,
        b = (0, d.useDeferredValue)(y.rsc, m);
      if ((0, v.isDeferredRsc)(b)) {
        let e = (0, d.use)(b);
        (null === e && (0, d.use)(c.unresolvedThenable), (t = e));
      } else (null === b && (0, d.use)(c.unresolvedThenable), (t = b));
      let _ = t;
      return (0, o.jsx)(i.LayoutRouterContext.Provider, {
        value: {
          parentTree: r,
          parentCacheNode: y,
          parentSegmentPath: n,
          parentParams: a,
          parentLoadingData: null,
          debugNameContext: l,
          url: s,
          isActive: f,
        },
        children: _,
      });
    }
    function C(e) {
      let { loading: t, children: r } = e,
        n = (0, d.use)(i.LayoutRouterContext);
      return null === n
        ? r
        : (0, o.jsx)(i.LayoutRouterContext.Provider, {
            value: {
              parentTree: n.parentTree,
              parentCacheNode: n.parentCacheNode,
              parentSegmentPath: n.parentSegmentPath,
              parentParams: n.parentParams,
              parentLoadingData: t,
              debugNameContext: n.debugNameContext,
              url: n.url,
              isActive: n.isActive,
            },
            children: r,
          });
    }
    function R(e) {
      let { name: t, loading: r, children: n } = e;
      if (null !== r) {
        let e = r[0],
          l = r[1],
          u = r[2];
        return (0, o.jsx)(d.Suspense, {
          name: t,
          fallback: (0, o.jsxs)(o.Fragment, { children: [l, u, e] }),
          children: n,
        });
      }
      return (0, o.jsx)(o.Fragment, { children: n });
    }
    function T(e) {
      let {
          parallelRouterKey: t,
          error: r,
          errorStyles: n,
          errorScripts: l,
          templateStyles: u,
          templateScripts: a,
          template: s,
          notFound: p,
          forbidden: h,
          unauthorized: v,
          segmentViewBoundaries: g,
        } = e,
        j = (0, d.useContext)(i.LayoutRouterContext);
      if (!j)
        throw Object.defineProperty(
          Error("invariant expected layout router to be mounted"),
          "__NEXT_ERROR_CODE",
          { value: "E56", enumerable: !1, configurable: !0 },
        );
      let {
          parentTree: C,
          parentCacheNode: T,
          parentSegmentPath: S,
          parentParams: M,
          parentLoadingData: E,
          url: N,
          isActive: F,
          debugNameContext: A,
        } = j,
        B = C[0],
        D = null === S ? [t] : S.concat([B, t]),
        L = C[1][t],
        H = T.slots;
      (void 0 === L || null === H) && (0, d.use)(c.unresolvedThenable);
      let w = L[0],
        k = H[t] ?? null,
        U = (0, b.createRouterCacheKey)(w, !0),
        V = (0, _.useRouterBFCache)(L, k, U),
        I = [];
      do {
        let e = V.tree,
          t = V.cacheNode,
          d = V.stateKey,
          c = e[0],
          b = M;
        if (Array.isArray(c)) {
          let e = c[0],
            t = c[1],
            r = c[2],
            n = (0, P.getParamValueFromCacheKey)(t, r);
          null !== n && (b = { ...M, [e]: n });
        }
        let _ = (function (e) {
            if ("/" === e) return "/";
            if ("string" == typeof e)
              if ("(__SLOT__)" === e) return;
              else return e + "/";
            return e[1] + "/";
          })(c),
          g = _ ?? A,
          j = void 0 === _ ? void 0 : A,
          C = (0, o.jsxs)(O, {
            cacheNode: t,
            children: [
              (0, o.jsx)(f.ErrorBoundary, {
                errorComponent: r,
                errorStyles: n,
                errorScripts: l,
                children: (0, o.jsx)(R, {
                  name: j,
                  loading: E,
                  children: (0, o.jsx)(m.HTTPAccessFallbackBoundary, {
                    notFound: p,
                    forbidden: h,
                    unauthorized: v,
                    children: (0, o.jsxs)(y.RedirectBoundary, {
                      children: [
                        (0, o.jsx)(x, {
                          url: N,
                          tree: e,
                          params: b,
                          cacheNode: t,
                          segmentPath: D,
                          debugNameContext: g,
                          isActive: F && d === U,
                        }),
                        null,
                      ],
                    }),
                  }),
                }),
              }),
              null,
            ],
          }),
          T = (0, o.jsxs)(i.TemplateContext.Provider, { value: C, children: [u, a, s] }, d);
        (I.push(T), (V = V.next));
      } while (null !== V);
      return I;
    }
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  837457,
  (e, t, r) => {
    "use strict";
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function () {
          return o;
        },
      }));
    let n = e.r(190809),
      l = e.r(843476),
      u = n._(e.r(271645)),
      a = e.r(8372);
    function o() {
      let e = (0, u.useContext)(a.TemplateContext);
      return (0, l.jsx)(l.Fragment, { children: e });
    }
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  806831,
  (e, t, r) => {
    "use strict";
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "createRenderParamsFromClient", {
        enumerable: !0,
        get: function () {
          return l;
        },
      }));
    let n = new WeakMap();
    function l(e) {
      let t = n.get(e);
      if (t) return t;
      let r = Promise.resolve(e);
      return (n.set(e, r), r);
    }
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  797689,
  (e, t, r) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "createRenderParamsFromClient", {
        enumerable: !0,
        get: function () {
          return n;
        },
      }));
    let n = e.r(806831).createRenderParamsFromClient;
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  793504,
  (e, t, r) => {
    "use strict";
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "createRenderSearchParamsFromClient", {
        enumerable: !0,
        get: function () {
          return l;
        },
      }));
    let n = new WeakMap();
    function l(e) {
      let t = n.get(e);
      if (t) return t;
      let r = Promise.resolve(e);
      return (n.set(e, r), r);
    }
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  266996,
  (e, t, r) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "createRenderSearchParamsFromClient", {
        enumerable: !0,
        get: function () {
          return n;
        },
      }));
    let n = e.r(793504).createRenderSearchParamsFromClient;
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  15783,
  (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", { value: !0 });
    var n = {
      createClientParams: function () {
        return u.createRenderParamsFromClient;
      },
      createClientSearchParams: function () {
        return a.createRenderSearchParamsFromClient;
      },
    };
    for (var l in n) Object.defineProperty(r, l, { enumerable: !0, get: n[l] });
    let u = e.r(797689),
      a = e.r(266996);
    ("function" == typeof r.default || ("object" == typeof r.default && null !== r.default)) &&
      void 0 === r.default.__esModule &&
      (Object.defineProperty(r.default, "__esModule", { value: !0 }),
      Object.assign(r.default, r),
      (t.exports = r.default));
  },
  27201,
  (e, t, r) => {
    "use strict";
    (Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "IconMark", {
        enumerable: !0,
        get: function () {
          return l;
        },
      }));
    let n = e.r(843476),
      l = () => ("u" > typeof window ? null : (0, n.jsx)("meta", { name: "«nxt-icon»" }));
  },
  491915,
  (e, t, r) => {
    "use strict";
    function n(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
      if (t.onlyHashChange) return void e();
      let r = document.documentElement;
      if ("smooth" !== r.dataset.scrollBehavior) return void e();
      let n = r.style.scrollBehavior;
      ((r.style.scrollBehavior = "auto"),
        t.dontForceLayout || r.getClientRects(),
        e(),
        (r.style.scrollBehavior = n));
    }
    (e.i(247167),
      Object.defineProperty(r, "__esModule", { value: !0 }),
      Object.defineProperty(r, "disableSmoothScrollDuringRouteTransition", {
        enumerable: !0,
        get: function () {
          return n;
        },
      }));
  },
]);
