// Checkout Controller for myIQ
document.addEventListener("DOMContentLoaded", () => {
  const isCheckout = document.getElementById("checkout-view");
  if (!isCheckout) return;

  // Countdown timer (15 minutes)
  let timeLeft = 14 * 60 + 59;
  const timerBanner = document.getElementById("checkout-timer");
  
  if (timerBanner) {
    setInterval(() => {
      if (timeLeft > 0) {
        timeLeft--;
        const mins = Math.floor(timeLeft / 60);
        const secs = timeLeft % 60;
        timerBanner.textContent = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
      }
    }, 1000);
  }

  // Retrieve user test preliminary score preview if available
  const savedResult = localStorage.getItem("myiq_test_result");
  if (savedResult) {
    try {
      const res = JSON.parse(savedResult);
      const scorePreview = document.getElementById("checkout-preview-score");
      if (scorePreview) {
        scorePreview.textContent = `IQ ${res.score}`;
      }
    } catch (e) {}
  }

  // Payment method switching (Card, Pix, PayPal)
  const tabCard = document.getElementById("tab-card");
  const tabPix = document.getElementById("tab-pix");
  const tabPaypal = document.getElementById("tab-paypal");
  const formCard = document.getElementById("payment-form-card");
  const formPix = document.getElementById("payment-form-pix");
  const formPaypal = document.getElementById("payment-form-paypal");

  function setPaymentTab(activeTab, activeForm) {
    [tabCard, tabPix, tabPaypal].forEach(tab => {
      if (tab) {
        tab.classList.remove("border-blue-custom", "bg-blue-50", "text-blue-custom", "font-semibold");
        tab.classList.add("border-slate-200", "bg-white", "text-slate-600");
      }
    });
    [formCard, formPix, formPaypal].forEach(form => {
      if (form) form.classList.add("hidden");
    });

    if (activeTab) {
      activeTab.classList.add("border-blue-custom", "bg-blue-50", "text-blue-custom", "font-semibold");
      activeTab.classList.remove("border-slate-200", "bg-white", "text-slate-600");
    }
    if (activeForm) {
      activeForm.classList.remove("hidden");
    }
  }

  if (tabCard) tabCard.addEventListener("click", () => setPaymentTab(tabCard, formCard));
  if (tabPix) tabPix.addEventListener("click", () => setPaymentTab(tabPix, formPix));
  if (tabPaypal) tabPaypal.addEventListener("click", () => setPaymentTab(tabPaypal, formPaypal));

  // Card Number live formatting (xxxx xxxx xxxx xxxx)
  const cardNumInput = document.getElementById("card-number");
  if (cardNumInput) {
    cardNumInput.addEventListener("input", (e) => {
      let val = e.target.value.replace(/\D/g, '').substring(0, 16);
      val = val.replace(/(\d{4})(?=\d)/g, '$1 ');
      e.target.value = val;
    });
  }

  // Card Expiry formatting (MM/YY)
  const cardExpInput = document.getElementById("card-exp");
  if (cardExpInput) {
    cardExpInput.addEventListener("input", (e) => {
      let val = e.target.value.replace(/\D/g, '').substring(0, 4);
      if (val.length >= 2) {
        val = val.substring(0, 2) + '/' + val.substring(2);
      }
      e.target.value = val;
    });
  }

  // Handle Complete Purchase
  const submitButtons = document.querySelectorAll(".btn-submit-order");
  submitButtons.forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      const emailInput = document.getElementById("checkout-email");
      const emailVal = emailInput ? emailInput.value.trim() : "user@example.com";

      if (emailInput && !emailVal.includes("@")) {
        alert("Please enter a valid email address.");
        emailInput.focus();
        return;
      }

      btn.disabled = true;
      btn.innerHTML = `<span class="inline-flex items-center gap-2"><svg class="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path></svg> Processing payment...</span>`;

      // Save user session
      const userSession = {
        email: emailVal,
        plan: "trial_0.99",
        subscribedAt: new Date().toISOString(),
        active: true
      };
      localStorage.setItem("myiq_user_session", JSON.stringify(userSession));

      setTimeout(() => {
        const isPt = window.location.pathname.includes('/pt-BR');
        window.location.href = isPt ? '/pt-BR/dashboard' : '/dashboard';
      }, 1500);
    });
  });
});
