(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  461745,
  (e) => {
    "use strict";
    var t = e.i(843476),
      n = e.i(948148),
      i = e.i(335889);
    e.i(570908);
    var s = e.i(871290),
      a = e.i(523173),
      o = e.i(134404);
    e.i(756503);
    var r = e.i(542516);
    e.i(470366);
    var l = e.i(504001),
      d = e.i(202042);
    (e.s([], 252977),
      e.i(252977),
      e.s(
        [
          "ActionButtonsComponent",
          0,
          (e) => {
            let { name: u = "action-btn", user: c } = e,
              C = (0, n.useTranslations)(),
              m = (0, d.usePathname)();
            return (0, t.jsxs)("div", {
              className: `hidden ${m !== o.EClientRoutes.CHECKOUT && m !== o.EClientRoutes.CHECKOUT_PROMO ? "gap-3 lg:flex" : ""} col-span-auto lg:flex-1 lg:justify-end`,
              children: [
                (0, s.isShownSignInButton)(m) &&
                  (0, t.jsx)(i.Button, {
                    as: d.Link,
                    href: o.EClientRoutes.SIGN_IN,
                    onPress: () => {
                      (0, l.trackClientEvents)({
                        event: a.EAnalyticEvents.PAGE_CLICKED,
                        params: { page_name: "loginButtonClicked" },
                        sessionId: c?.id,
                      });
                    },
                    className:
                      "hover:opacity-1 hidden h-12 gap-3 rounded-xl border-1 border-green-custom text-base font-medium text-green-custom hover:bg-green-custom hover:text-white lg:inline-flex",
                    size: "md",
                    radius: "sm",
                    variant: "bordered",
                    prefetch: !0,
                    children: C("btn_login"),
                  }),
                m !== o.EClientRoutes.CHECKOUT &&
                  m !== o.EClientRoutes.CHECKOUT_PROMO &&
                  !r.envClient.NEXT_PUBLIC_QUIZ_DISABLED &&
                  (0, t.jsx)(i.Button, {
                    name: u,
                    as: d.Link,
                    href: o.EClientRoutes.START,
                    onPress: () => {
                      (0, l.trackClientEvents)({
                        event: a.EAnalyticEvents.PAGE_CLICKED,
                        params: { page_name: "startCertifiedTestButtonClicked", page_title: "Start" },
                        user: c,
                        sessionId: c?.id,
                      });
                    },
                    className: "h-12 gap-3 rounded-xl bg-green-custom text-base font-medium text-white",
                    size: "md",
                    radius: "sm",
                    variant: "shadow",
                    prefetch: !0,
                    children: C("btn_start_test"),
                  }),
              ],
            });
          },
        ],
        461745,
      ));
  },
  213595,
  function (e) {
    e.n(e.i(461745));
  },
]);
