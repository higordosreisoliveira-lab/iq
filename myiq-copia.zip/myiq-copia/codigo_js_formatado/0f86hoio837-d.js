(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  985272,
  (e) => {
    "use strict";
    let t;
    var a = Object.defineProperty,
      r = (e, t, r) => {
        let i;
        return (i = "symbol" != typeof t ? t + "" : t) in e
          ? a(e, i, { enumerable: !0, configurable: !0, writable: !0, value: r })
          : (e[i] = r);
      };
    let i = null,
      n = null;
    class o extends Error {
      constructor(e, t = !0, a = !1) {
        const i =
          a && "u" > typeof window
            ? (function () {
                let e = navigator.connection || navigator.mozConnection || navigator.webkitConnection,
                  t = {
                    online: navigator.onLine,
                    documentHidden: document.hidden,
                    userAgent: navigator.userAgent,
                    timestamp: new Date().toISOString(),
                  };
                return (
                  e &&
                    ((t.connectionType = e.type),
                    (t.effectiveType = e.effectiveType),
                    (t.downlink = e.downlink),
                    (t.rtt = e.rtt),
                    (t.saveData = e.saveData)),
                  navigator.onLine
                    ? document.hidden
                      ? (t.likelyCause = "background_tab")
                      : e?.effectiveType === "slow-2g" || e?.effectiveType === "2g"
                        ? (t.likelyCause = "slow_connection")
                        : e?.downlink !== void 0 && e.downlink < 0.5 && (t.likelyCause = "poor_bandwidth")
                    : (t.likelyCause = "offline"),
                  t
                );
              })()
            : null;
        (super(
          i
            ? `${e} [${(function (e) {
                let t = [];
                return (
                  e.likelyCause && t.push(`cause=${e.likelyCause}`),
                  t.push(`online=${e.online}`),
                  t.push(`hidden=${e.documentHidden}`),
                  e.effectiveType && t.push(`net=${e.effectiveType}`),
                  void 0 !== e.downlink && t.push(`downlink=${e.downlink}Mbps`),
                  void 0 !== e.rtt && t.push(`rtt=${e.rtt}ms`),
                  t.join(", ")
                );
              })(i)}]`
            : e,
        ),
          r(this, "retryable"),
          r(this, "diagnostics"),
          (this.retryable = t),
          (this.name = "SDKLoadError"),
          (this.diagnostics = i));
      }
    }
    let s = "PayNextSDK";
    function l() {
      return typeof window > "u" ? null : window[s];
    }
    function c(e) {
      return new Promise((t) => setTimeout(t, e));
    }
    async function _() {
      let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 5e3,
        t = Math.ceil(e / 50);
      for (let e = 0; e < t; e++) {
        let e = l();
        if (e) return e;
        await c(50);
      }
      throw new o("PayNextSDK not found in window after waiting", !0, !0);
    }
    async function u(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
        a = e?.toLowerCase(),
        r =
          (a?.includes("develop") || a?.includes("staging") || a?.includes("preview")
            ? "develop"
            : "production") == "develop"
            ? "https://cdn-sdk-dev.paynext.com/index.cdn.js"
            : "https://cdn-sdk.paynext.com/index.cdn.js";
      try {
        return (
          l() ||
          (await new Promise((e, t) => {
            let a = document.querySelector(`script[src="${r}"]`);
            if (a) {
              if (l()) return void e();
              let r = setTimeout(() => {
                  (a.removeEventListener("load", i),
                    a.removeEventListener("error", n),
                    t(new o("Existing SDK script loading timeout", !0, !0)));
                }, 15e3),
                i = () => {
                  (clearTimeout(r), a.removeEventListener("load", i), a.removeEventListener("error", n), e());
                },
                n = () => {
                  (clearTimeout(r),
                    a.removeEventListener("load", i),
                    a.removeEventListener("error", n),
                    t(new o("Existing SDK script failed to load", !0, !0)));
                };
              return (a.addEventListener("load", i), void a.addEventListener("error", n));
            }
            let i = setTimeout(() => {
                (s(), t(new o("SDK script loading timeout", !0, !0)));
              }, 15e3),
              n = document.createElement("script");
            ((n.src = r),
              (n.crossOrigin = "anonymous"),
              (n.async = !0),
              n.setAttribute("data-paynext-sdk", "true"));
            let s = () => {
              (clearTimeout(i), (n.onload = null), (n.onerror = null));
            };
            ((n.onload = () => {
              (s(), e());
            }),
              (n.onerror = (e) => {
                (console.error("[PayNext CDN] Script load error:", e), s());
                try {
                  n.parentNode && n.parentNode.removeChild(n);
                } catch (e) {
                  console.warn("[PayNext CDN] Failed to remove script:", e);
                }
                t(new o("Failed to load SDK script from CDN", !0, !0));
              }));
            try {
              document.head.appendChild(n);
            } catch {
              (s(), t(new o("Failed to append script to document", !1)));
            }
          }),
          await _(5e3))
        );
      } catch (a) {
        if ((!(a instanceof o) || a.retryable) && t < 5)
          return (
            console.warn(`[PayNext CDN] Load attempt ${t} failed, retrying in 1500ms...`, a),
            await c(1500 * t),
            u(e, t + 1)
          );
        throw (console.error(`[PayNext CDN] Failed to load SDK after ${t} attempts:`, a), a);
      }
    }
    async function d(e) {
      if (n) return n;
      if (i) return i;
      if (typeof window > "u") throw new o("PayNext SDK can only be loaded in browser environment", !1);
      let t = l();
      return t
        ? (n = t)
        : (i = (async () => {
            try {
              let t = await u(e);
              return ((n = t), typeof window > "u" || (window[s] = t), t);
            } catch (e) {
              throw ((i = null), e);
            }
          })());
    }
    class f {
      constructor() {
        (r(this, "cdnInstance", null),
          r(this, "initPromise", null),
          r(this, "isDestroyed", !1),
          r(this, "errorBoundary", null));
      }
      setErrorHandler(e) {
        this.errorBoundary = e;
      }
      handleError(e, t) {
        if ((console.error(`[PayNext SDK Error - ${t}]: ${e.message}`, e), this.errorBoundary))
          try {
            this.errorBoundary(e);
          } catch (e) {
            console.error("[PayNext SDK] Error in custom error handler:", e);
          }
      }
      async initialize(e) {
        if (this.isDestroyed) throw new o("Cannot initialize destroyed SDK instance", !1);
        return (
          this.initPromise ||
            (this.initPromise = (async () => {
              try {
                let t = await d(e);
                if (!t || !t.PayNextCheckout)
                  throw new o("PayNextCheckout not found in loaded SDK module", !1);
                try {
                  this.cdnInstance = new t.PayNextCheckout();
                } catch (e) {
                  throw new o(
                    `Failed to instantiate PayNextCheckout: ${e instanceof Error ? e.message : "Unknown error"}`,
                    !1,
                  );
                }
              } catch (e) {
                throw ((this.initPromise = null), e);
              }
            })()),
          this.initPromise
        );
      }
      assertReady() {
        if (this.isDestroyed) throw new o("SDK instance has been destroyed", !1);
        if (!this.initPromise) throw new o("SDK initialization not started", !1);
        if (!this.cdnInstance) throw new o("SDK instance not created", !1);
      }
      async mount(e, t) {
        try {
          if (!e || "string" != typeof e) throw new o("Invalid containerId provided", !1);
          if (!t || !t.environment) throw new o("Invalid config provided", !1);
          if (!document.getElementById(e)) throw new o(`Container element with id "${e}" not found`, !1);
          (await this.initialize(t.environment), this.assertReady(), await this.cdnInstance.mount(e, t));
        } catch (t) {
          let e = t instanceof o ? t : new o(t instanceof Error ? t.message : "Unknown mount error", !0);
          throw (this.handleError(e, "mount"), e);
        }
      }
      update(e) {
        try {
          if (this.isDestroyed) return void console.warn("[PayNext SDK] update called on destroyed instance");
          if (!this.cdnInstance) return void console.warn("[PayNext SDK] update called before mount");
          "function" == typeof this.cdnInstance.update
            ? this.cdnInstance.update(e)
            : console.warn(
                "[PayNext SDK] update() is not supported by the loaded CDN bundle; a newer SDK version is required",
              );
        } catch (t) {
          let e = t instanceof Error ? t : Error(String(t));
          this.handleError(e, "update");
        }
      }
      setPaymentsEnabled(e) {
        try {
          if (this.isDestroyed)
            return void console.warn("[PayNext SDK] setPaymentsEnabled called on destroyed instance");
          if (!this.cdnInstance)
            return void console.warn("[PayNext SDK] setPaymentsEnabled called before mount");
          "function" == typeof this.cdnInstance.setPaymentsEnabled && this.cdnInstance.setPaymentsEnabled(e);
        } catch (t) {
          let e = t instanceof Error ? t : Error(String(t));
          this.handleError(e, "setPaymentsEnabled");
        }
      }
      async unmount() {
        try {
          if (this.isDestroyed) return void console.warn("[PayNext SDK] Instance already destroyed");
          if (!this.cdnInstance) return void console.warn("[PayNext SDK] No instance to unmount");
          try {
            "function" == typeof this.cdnInstance.unmount && (await this.cdnInstance.unmount());
          } catch (t) {
            let e = t instanceof Error ? t : Error(String(t));
            this.handleError(e, "unmount");
          }
          ((this.cdnInstance = null), (this.initPromise = null));
        } catch (t) {
          let e = t instanceof Error ? t : Error(String(t));
          this.handleError(e, "unmount");
        }
      }
      static async preload(e) {
        try {
          await d(e);
        } catch (e) {
          throw (console.error("[PayNext SDK] Preload failed:", e), e);
        }
      }
    }
    f.preload;
    var p =
      (((t = p || {}).PAYPAL = "PAYPAL"),
      (t.APPLE_PAY = "APPLEPAY"),
      (t.GOOGLE_PAY = "GPAY"),
      (t.CARD = "CARD"),
      (t.VENMO = "VENMO"),
      (t.CASHAPP = "CASHAPP"),
      (t.AMAZONPAY = "AMAZONPAY"),
      (t.PIX_AUTOMATICO = "PIX_AUTOMATICO"),
      (t.UPI = "UPI"),
      (t.BLIK = "BLIK"),
      t);
    e.s(["PayNextCheckout", 0, f, "PaymentMethod", 0, p]);
  },
  804751,
  (e) => {
    "use strict";
    (e.i(985789), e.i(48859), e.i(529730), e.i(785817), e.i(526199), e.i(818660), e.s([]));
  },
  985789,
  (e) => {
    "use strict";
    var t = e.i(217255),
      a = e.i(946684),
      r = e.i(818660);
    e.s([
      "useIsTriviaHeartsCooldownActive",
      0,
      () => {
        let e = (0, t.useSession)().data?.user?.email,
          { data: i } = (0, a.useGetProfileQuery)(e || ""),
          n = i?.data?.user_info,
          { testStatus: o } = (0, r.useProfileTriviaService)(n || null),
          s = "completed" !== o && n?.trivia_test_data?.hearts === 0;
        return "completed" === o || s;
      },
    ]);
  },
  48859,
  (e) => {
    "use strict";
    var t = e.i(271645),
      a = e.i(727540),
      r = e.i(265832);
    e.i(476643);
    var i = e.i(408241);
    e.s([
      "getRefillTimeRemaining",
      0,
      (e) => {
        if (!e) return "";
        let t = e - (0, a.getCurrentDateTimeUTC)().toJSDate().getTime();
        if (t <= 0) return "";
        let r = Math.floor(t / 6e4),
          i = Math.floor((t % 6e4) / 1e3);
        return r > 0 ? `${r}m ${i}s` : `${i}s`;
      },
      "usePowerUpRefill",
      0,
      () => {
        let e = (0, i.useTriviaTestStore)((e) => e.fiftyFiftyUses),
          n = (0, i.useTriviaTestStore)((e) => e.extraTimeUses),
          o = (0, i.useTriviaTestStore)((e) => e.fiftyFiftyRefillAt),
          s = (0, i.useTriviaTestStore)((e) => e.extraTimeRefillAt),
          l = (0, i.useTriviaTestStore)((e) => e.handleTriviaTestStore);
        (0, t.useEffect)(() => {
          let t = () => {
            let t = (0, a.getCurrentDateTimeUTC)().toJSDate().getTime();
            (o &&
              t >= o &&
              0 === e &&
              l({ fiftyFiftyUses: r.POWER_UPS_CONFIG.INITIAL_FIFTY_FIFTY_USES, fiftyFiftyRefillAt: null }),
              s &&
                t >= s &&
                0 === n &&
                l({ extraTimeUses: r.POWER_UPS_CONFIG.INITIAL_EXTRA_TIME_USES, extraTimeRefillAt: null }));
          };
          t();
          let i = setInterval(t, 1e3);
          return () => clearInterval(i);
        }, [o, s, e, n, l]);
      },
    ]);
  },
  529730,
  (e) => {
    "use strict";
    var t = e.i(271645),
      a = e.i(985272),
      r = e.i(946684),
      i = e.i(523173),
      n = e.i(622963),
      o = e.i(428460),
      s = e.i(86596),
      l = e.i(915113),
      c = e.i(265832);
    e.i(470366);
    var _ = e.i(504001),
      u = e.i(998198),
      d = e.i(785817),
      f = e.i(526199);
    e.i(476643);
    var p = e.i(408241);
    e.s([
      "useTriviaGameBar",
      0,
      (e) => {
        let { abMyiqTriviaPopupUpsell: m } = e,
          T = (0, s.useUserStore)((e) => e.user),
          { data: I } = (0, r.useGetProfileQuery)(T?.email || ""),
          y = I?.data?.user_info || T,
          E = (0, n.useModalStore)((e) => e.handleChangeModalStore),
          A = (0, p.useTriviaTestStore)((e) => e.handleTriviaTestStore),
          S = (0, p.useTriviaTestStore)((e) => e.achivedXPBoostId),
          h = (0, p.useTriviaTestStore)((e) => e.hearts),
          { xp: P } = (0, o.useOptimisticXPStore)(),
          b = P || y?.total_xp || 0,
          { handlePurchase: v } = (0, f.useTriviaPurchase)({ userData: y, type: "hearts", isInGame: !0 }),
          R = c.XP_BOOST_CONFIG.filter((e) => b >= e.xp),
          w = R[R.length - 1] || null,
          g = y?.trivia_test_data?.achivedXPBoostId,
          C = void 0 === g || g === S;
        return (
          (0, t.useEffect)(() => {
            void 0 !== g && g !== S && A({ achivedXPBoostId: g });
          }, [g, S, A]),
          (0, t.useEffect)(() => {
            if (!C || !w || w.id === S || null === S) return;
            let e = window.setTimeout(
              () => {
                E({
                  isModalVisible: !0,
                  modalComponent: "trivia-achieved-bonus",
                  modalProps: { achivedXP: w },
                });
              },
              (0, d.getAnswerFeedbackMs)("correct"),
            );
            return () => window.clearTimeout(e);
          }, [C, S, w, E]),
          {
            hearts: h,
            xp: b,
            handleAddHearts: () => {
              E({
                isModalVisible: !0,
                modalComponent: "trivia-purchase",
                modalProps: {
                  onBuyHearts: v,
                  isRequired: !1,
                  type: "hearts",
                  onClose: () => {
                    (0, _.trackClientEvents)({
                      event: i.EAnalyticEvents.TRIVIA_ADD_ON_SKIP_CLICKED,
                      params: { skip_option: "Close Button" },
                    });
                  },
                },
              });
            },
            handleClose: () => {
              (0, _.trackClientEvents)({
                event: i.EAnalyticEvents.TRIVIA_TEST_CLOSE_BUTTON_CLICKED,
                user: T,
              });
              let e = y?.paymentInfo?.paymentMethodType === a.PaymentMethod.PAYPAL;
              if (
                "trivia_exit_popup_bundle_added" === m &&
                (0, l.getIsMarketingSource)() &&
                !e &&
                !T?.hasBoughtTriviaPopup
              ) {
                let { priceForView: e } = (0, u.getPaymentPlanPrice)({
                  paymentPlan: "BUY_TRIVIA_UPSELL_EXIT",
                  user: y || null,
                });
                E({
                  isModalVisible: !0,
                  modalComponent: "brain-training-confirm-purchase",
                  modalProps: {
                    paymentPlan: "BUY_TRIVIA_UPSELL_EXIT",
                    price: (0, u.getCalculatePriceForView)(e, y || null),
                  },
                });
                return;
              }
              E({ isModalVisible: !0, modalComponent: "game-quit", modalProps: { isTriviaTest: !0 } });
            },
            handleOpenXp: () => {
              E({ isModalVisible: !0, modalComponent: "trivia-xp-bonus", modalProps: { displayXP: b } });
            },
          }
        );
      },
    ]);
  },
  785817,
  361582,
  239512,
  (e) => {
    "use strict";
    var t = e.i(271645);
    let a = ["A", "B", "C", "D"],
      r = "--ds-semantic-opacity-disabled-content",
      i = "0.38",
      n = ["fifty-fifty", "extra-time"],
      o = {
        aboutHearts: "trivia_purchase_about_to_purchase_hearts",
        aboutPowerUp: "trivia_purchase_about_to_purchase_powerup",
        back: "trivia_purchase_back",
        bestValue: "trivia_purchase_best_value",
        buttonFor: "trivia_purchase_button_for",
        clickConfirm: "trivia_purchase_confirm_click_confirm",
        close: "trivia_purchase_close",
        confirm: "trivia_purchase_disclaimer_button_confirm",
        confirmTitle: "trivia_purchase_confirm_title",
        disclaimerCharged: "trivia_purchase_disclaimer_charged",
        disclaimerRefill30: "trivia_purchase_disclaimer_refill_30",
        disclaimerRefillIn: "trivia_purchase_disclaimer_refill_in",
        heartsTextRequired: "trivia_purchase_hearts_subtitle_required",
        heartsTitleRequired: "trivia_purchase_hearts_title_ran_out",
        selectPackage: "trivia_purchase_select_package",
        wait30: "trivia_purchase_wait_30_min",
        waitRefill: "trivia_purchase_wait_refill",
      },
      s = {
        "extra-time": {
          action: "trivia_purchase_button_get",
          buttonLabel: "trivia_purchase_extra_time_button_label",
          name: "trivia_purchase_extra_time_name",
          text: "trivia_purchase_extra_time_subtitle",
          title: "trivia_purchase_extra_time_title",
        },
        "fifty-fifty": {
          action: "trivia_purchase_button_get",
          buttonLabel: "trivia_purchase_fifty_fifty_button_label",
          name: "trivia_power_up_fifty_fifty_label",
          text: "trivia_purchase_fifty_fifty_subtitle",
          title: "trivia_purchase_fifty_fifty_title",
        },
        hearts: {
          action: "trivia_purchase_button_buy",
          buttonLabel: "trivia_purchase_hearts_button_label",
          name: "trivia_purchase_hearts_item_label",
          text: "trivia_purchase_hearts_subtitle_optional",
          title: "trivia_purchase_hearts_title_get_more",
        },
      },
      l = ["ArrowRight", "ArrowDown"],
      c = ["ArrowLeft", "ArrowUp"];
    e.s(
      [
        "TRIVIA_ANSWER_LETTERS",
        0,
        a,
        "TRIVIA_CONFETTI",
        0,
        [
          { left: "4%", rotate: 18, tone: "brand", top: "6%" },
          { left: "12%", rotate: -32, tone: "accent", top: "18%" },
          { left: "20%", rotate: 54, tone: "warning", top: "9%" },
          { left: "27%", rotate: -12, tone: "danger", top: "27%" },
          { left: "34%", rotate: 40, tone: "brand-muted", top: "4%" },
          { left: "41%", rotate: -48, tone: "brand", top: "21%" },
          { left: "48%", rotate: 24, tone: "accent", top: "12%" },
          { left: "55%", rotate: -20, tone: "warning", top: "31%" },
          { left: "62%", rotate: 62, tone: "danger", top: "7%" },
          { left: "69%", rotate: -36, tone: "brand-muted", top: "24%" },
          { left: "76%", rotate: 10, tone: "brand", top: "14%" },
          { left: "83%", rotate: -58, tone: "accent", top: "5%" },
          { left: "90%", rotate: 30, tone: "warning", top: "19%" },
          { left: "8%", rotate: -44, tone: "danger", top: "38%" },
          { left: "17%", rotate: 16, tone: "brand", top: "47%" },
          { left: "30%", rotate: -26, tone: "accent", top: "41%" },
          { left: "44%", rotate: 50, tone: "brand-muted", top: "52%" },
          { left: "58%", rotate: -8, tone: "warning", top: "44%" },
          { left: "72%", rotate: 36, tone: "danger", top: "36%" },
          { left: "86%", rotate: -40, tone: "brand", top: "49%" },
          { left: "92%", rotate: 22, tone: "accent", top: "33%" },
          { left: "24%", rotate: -60, tone: "warning", top: "58%" },
          { left: "51%", rotate: 14, tone: "brand", top: "62%" },
          { left: "79%", rotate: -18, tone: "brand-muted", top: "60%" },
        ],
        "TRIVIA_DISABLED_OPACITY_FALLBACK",
        0,
        i,
        "TRIVIA_DISABLED_OPACITY_TOKEN",
        0,
        r,
        "TRIVIA_GAME_HEADER_KEYS",
        0,
        {
          addHearts: "trivia_hearts_badge_add_hearts",
          close: "trivia_purchase_close",
          xpAmount: "trivia_xp_bonus_modal_xp_amount",
        },
        "TRIVIA_GAME_IDS",
        0,
        { questionTitle: "trivia-question-title" },
        "TRIVIA_HEARTS_DEPLETED_MODAL_DELAY",
        0,
        200,
        "TRIVIA_PLAY_KEYS",
        0,
        {
          correct: "trivia_feedback_correct",
          correctLabel: "trivia_answers_modal_correct_label",
          correctTag: "trivia_answers_modal_correct_badge",
          inARow: "trivia_feedback_in_a_row",
          questionNumber: "trivia_answers_modal_question_n",
          timesUp: "trivia_feedback_times_up",
          xpAmount: "trivia_xp_bonus_modal_xp_amount",
        },
        "TRIVIA_POWER_UPS",
        0,
        n,
        "TRIVIA_POWER_UP_CONTENT",
        0,
        {
          "extra-time": {
            icon: "timer",
            labelKey: "trivia_power_up_extra_time_label",
            outKey: "trivia_purchase_extra_time_title",
          },
          "fifty-fifty": {
            icon: "split",
            labelKey: "trivia_power_up_fifty_fifty_label",
            outKey: "trivia_purchase_fifty_fifty_title",
          },
        },
        "TRIVIA_SHOP_DEFAULT_PACKAGE_INDEX",
        0,
        1,
        "TRIVIA_SHOP_KEYS",
        0,
        o,
        "TRIVIA_SHOP_KIND_KEYS",
        0,
        s,
        "TRIVIA_SHOP_NEXT_KEYS",
        0,
        l,
        "TRIVIA_SHOP_PREVIOUS_KEYS",
        0,
        c,
        "TRIVIA_TIMER_URGENT_SECONDS",
        0,
        5,
        "TRIVIA_TIMER_WARNING_SECONDS",
        0,
        10,
        "TRIVIA_XP_BURST_COUNT",
        0,
        5,
      ],
      361582,
    );
    var _ = e.i(265832);
    let u = (e) => String(e).padStart(2, "0"),
      d = (e, t, a) => e(s[t].buttonLabel, { amount: String(a) }),
      f = (e, t, a) =>
        l.includes(e)
          ? (t + 1) % a
          : c.includes(e)
            ? (t - 1 + a) % a
            : "Home" === e
              ? 0
              : "End" === e
                ? a - 1
                : null;
    e.s(
      [
        "formatDelta",
        0,
        (e) => (e > 0 ? `+${e}` : `${e}`),
        "formatTimer",
        0,
        (e) => {
          let t = Math.max(0, Math.ceil(e));
          return `${u(Math.floor(t / 60))}:${u(t % 60)}`;
        },
        "getAmountLabel",
        0,
        d,
        "getAnswerLetter",
        0,
        (e) => a[e] ?? "",
        "getAnswerResult",
        0,
        (e) =>
          e.isAnswered ? (e.isCorrect ? "correct" : null === e.selectedAnswer ? "times-up" : "wrong") : null,
        "getAnswerStates",
        0,
        (e, t, a, r) =>
          e.map((e) =>
            a.isAnswered
              ? e === t
                ? "correct"
                : e === a.selectedAnswer
                  ? "wrong"
                  : "disabled"
              : r.includes(e)
                ? "disabled"
                : "idle",
          ),
        "getConfirmText",
        0,
        (e, t, a) => {
          let r = { amount: String(a.amount), price: a.price },
            i = "hearts" === t ? e(o.aboutHearts, r) : e(o.aboutPowerUp, { ...r, powerUpName: e(s[t].name) });
          return `${i} ${e(o.clickConfirm)}`;
        },
        "getCtaLabel",
        0,
        (e, t, a) => [e(s[t].action), d(e, t, a.amount), e(o.buttonFor), a.price].join(" "),
        "getDisclaimer",
        0,
        (e, t, a, r, i) => {
          let n = e(o.disclaimerCharged, { button: a, price: r });
          if ("hearts" === t) return n;
          let s = i ? e(o.disclaimerRefillIn, { time: i }) : e(o.disclaimerRefill30);
          return `${n} ${s}`;
        },
        "getNextAnswerIndex",
        0,
        (e, t, r) => {
          let i = r.map((e, t) => t).filter((e) => "disabled" !== r[e]);
          if (0 === i.length) return null;
          let n = Math.max(0, i.indexOf(t));
          if ("ArrowDown" === e || "ArrowRight" === e) return i[(n + 1) % i.length];
          if ("ArrowUp" === e || "ArrowLeft" === e) return i[(n - 1 + i.length) % i.length];
          if ("Home" === e) return i[0];
          if ("End" === e) return i[i.length - 1];
          let o = a.indexOf(e.toUpperCase());
          return i.includes(o) ? o : null;
        },
        "getPlayFeedback",
        0,
        (e, t) => ("correct" !== e ? e : t >= _.STREAK_MILESTONES.STREAK_3 ? "streak" : "correct"),
        "getPowerUpViews",
        0,
        (e) =>
          n.map((t) => {
            let a = "fifty-fifty" === t;
            return {
              count: a ? e.fiftyFiftyUses : e.extraTimeUses,
              isDisabled: e.isAnswered || (a ? e.isFiftyFiftyUsed : e.isExtraTimeUsed),
              kind: t,
            };
          }),
        "getPurchaseText",
        0,
        (e, t, a) => e("hearts" === t && a ? o.heartsTextRequired : s[t].text),
        "getPurchaseTitle",
        0,
        (e, t, a) => e("hearts" === t && a ? o.heartsTitleRequired : s[t].title),
        "getRovingIndex",
        0,
        f,
        "getTimerPercent",
        0,
        (e, t) => (t > 0 ? Math.max(0, Math.min(100, (e / t) * 100)) : 0),
        "getTimerTone",
        0,
        (e) => (e <= 0 ? "up" : e <= 5 ? "urgent" : e <= 10 ? "warning" : "rest"),
        "getWaitLabel",
        0,
        (e, t, a, r) => {
          if ("hearts" === t) return r ? e(o.waitRefill, { time: r }) : a ? e(o.wait30) : void 0;
        },
      ],
      239512,
    );
    let p = (e) => getComputedStyle(document.documentElement).getPropertyValue(e).trim(),
      m = (e) => {
        let t = p(`--ds-semantic-motion-${e}`);
        return t.endsWith("ms") ? parseFloat(t) : 1e3 * parseFloat(t) || 0;
      },
      T = (e) => parseFloat(p(`--ds-primitive-dimension-size-${e}`)) || 0,
      I = () => {
        let e = m("instant"),
          t = m("fast"),
          a = m("slow");
        return {
          gainCountMs: 2 * a,
          gainFlashMs: 3 * a,
          lossCountMs: 0,
          lossDelayMs: t,
          lossFlashMs: 3 * a,
          lossFloat: "none",
          xpCountMs: 2 * a + 5 * e,
          xpDelayMs: t + a + t + a,
          xpFlashMs: 3 * a,
          xpFloat: !0,
        };
      },
      y = (e) => {
        let t = e.getBoundingClientRect();
        return { height: t.height, width: t.width, x: t.left + t.width / 2, y: t.top + t.height / 2 };
      },
      E = (e, t) => {
        e.animate(
          [
            { opacity: 0, translate: `0 ${T(8)}px` },
            { opacity: 1, translate: "0 0" },
          ],
          { duration: t, fill: "both" },
        );
      };
    e.s(
      [
        "getAnswerFeedbackMs",
        0,
        (e) => {
          let t = I();
          return "correct" === e
            ? t.xpDelayMs + Math.max(t.xpCountMs, t.xpFlashMs)
            : t.lossDelayMs + t.lossFlashMs;
        },
        "getBarMotion",
        0,
        I,
        "useAnswerMotion",
        0,
        (e, a, n) => {
          let o = (0, t.useRef)(a);
          (0, t.useEffect)(() => {
            let t,
              s,
              l,
              c,
              _,
              u = e.current,
              d = o.current;
            if (
              ((o.current = a),
              !u || d || !a || window.matchMedia("(prefers-reduced-motion: reduce)").matches)
            )
              return;
            let f = u.querySelector(`[data-motion-row="${n}"]`);
            if ("correct" === a) {
              let e = f?.querySelector('[data-motion="answer-tag"]');
              e &&
                ((e, t) => {
                  let a = e.querySelector('[data-motion="xp-icon"]');
                  if (!a) return;
                  let r = m("fast"),
                    i = m("slow"),
                    n = y(t),
                    o = y(a),
                    s = o.x - n.x,
                    l = o.y - n.y,
                    c = T(32),
                    _ = i + r + i,
                    u = m("instant") / 1.5;
                  (E(t, r),
                    Array.from({ length: 5 }).forEach((e, t) => {
                      var d;
                      let f,
                        p,
                        m = (Math.PI / 180) * (-150 + (120 * t) / 4),
                        T = Math.cos(m) * c,
                        I = Math.sin(m) * c;
                      ((f = a.cloneNode(!0)).removeAttribute("data-motion"),
                        Object.assign(f.style, {
                          height: `${o.height}px`,
                          left: `${n.x - o.width / 2}px`,
                          margin: "0",
                          pointerEvents: "none",
                          position: "fixed",
                          top: `${n.y - o.height / 2}px`,
                          width: `${o.width}px`,
                          zIndex: "var(--ds-primitive-layer-toast)",
                        }),
                        document.body.appendChild(f),
                        (d = [
                          { opacity: 0, translate: "0 0" },
                          { offset: (0.6 * i) / _, opacity: 1, translate: `${0.9 * T}px ${0.9 * I}px` },
                          { offset: i / _, opacity: 1, translate: `${T}px ${I}px` },
                          { offset: (i + r) / _, opacity: 1, translate: `${T}px ${I}px` },
                          { offset: 0.9, opacity: 1, translate: `${0.92 * s}px ${0.92 * l}px` },
                          { opacity: 0, translate: `${s}px ${l}px` },
                        ]),
                        ((p = f.animate(d, { fill: "both", delay: r + t * u, duration: _ })).onfinish = () =>
                          f.remove()),
                        (p.oncancel = () => f.remove()));
                    }));
                })(u, e);
              return;
            }
            ((t = m("slow")),
              (s = { delay: m("fast"), duration: 2 * t, fill: "backwards" }),
              u.querySelectorAll('[data-motion="answer-tag"]').forEach((e) => E(e, t)),
              f &&
                ((l = p(r) || i),
                f.animate([{ opacity: l }, { opacity: 1 }], { delay: t, duration: t, fill: "backwards" })),
              u
                .querySelectorAll('[data-motion="tag-heart"]')
                .forEach((e) =>
                  e.animate(
                    [
                      { opacity: 1 },
                      { offset: 0.5, opacity: 1 },
                      { offset: 0.6, opacity: 0 },
                      { opacity: 0 },
                    ],
                    s,
                  ),
                ),
              u
                .querySelectorAll('[data-motion="tag-crack"]')
                .forEach((e) =>
                  e.animate(
                    [
                      { opacity: 0 },
                      { offset: 0.5, opacity: 0 },
                      { offset: 0.6, opacity: 1 },
                      { opacity: 1 },
                    ],
                    s,
                  ),
                ),
              (c = u.querySelector('[data-motion="hearts-icon"]')),
              (_ = u.querySelector('[data-motion="hearts-crack"]')),
              c?.animate(
                [{ opacity: 1 }, { offset: 0.15, opacity: 0 }, { offset: 0.75, opacity: 0 }, { opacity: 1 }],
                { duration: 3 * t },
              ),
              _?.animate(
                [{ opacity: 0 }, { offset: 0.15, opacity: 1 }, { offset: 0.75, opacity: 1 }, { opacity: 0 }],
                { duration: 3 * t },
              ));
          }, [e, a, n]);
        },
        "useConfettiMotion",
        0,
        (e) => {
          (0, t.useEffect)(() => {
            let t = e.current;
            if (!t || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
            let a = m("instant"),
              r = m("slow"),
              i = 3 * T(96),
              n = [
                { opacity: 0, rotate: "-200deg", translate: `0 -${i}px` },
                { offset: 0.15, opacity: 1 },
                { offset: 0.7, rotate: "12deg", translate: `0 ${T(4)}px` },
                { opacity: 1, rotate: "0deg", translate: "0 0" },
              ],
              o = Array.from(t.querySelectorAll('[data-motion="confetti"]')).map((e, t) =>
                e.animate(n, { delay: (t * a) / 5, duration: 2 * r, fill: "backwards" }),
              );
            return () => o.forEach((e) => e.cancel());
          }, [e]);
        },
        "useCountUpMs",
        0,
        function (e, a) {
          let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
            [i, n] = (0, t.useState)(e),
            o = (0, t.useRef)(e);
          return (
            (0, t.useEffect)(() => {
              let t = o.current;
              if (t === e) return;
              let i = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
              if (i || a <= 0) {
                let t = window.setTimeout(
                  () => {
                    ((o.current = e), n(e));
                  },
                  i ? 0 : r,
                );
                return () => window.clearTimeout(t);
              }
              let s = 0,
                l = 0,
                c = (r) => {
                  l || (l = r);
                  let i = Math.min(1, (r - l) / a),
                    _ = Math.round(t + (e - t) * (1 - (1 - i) * (1 - i)));
                  ((o.current = _), n(_), i < 1 && (s = requestAnimationFrame(c)));
                },
                _ = window.setTimeout(() => {
                  s = requestAnimationFrame(c);
                }, r);
              return () => {
                (window.clearTimeout(_), cancelAnimationFrame(s));
              };
            }, [e, a, r]),
            i
          );
        },
        "useDeltaPulse",
        0,
        (e) => {
          let a = (0, t.useRef)(e),
            [r, i] = (0, t.useState)({ delta: 0, pulse: 0 });
          return (
            (0, t.useEffect)(() => {
              let t = e - a.current;
              ((a.current = e), 0 !== t && i((e) => ({ delta: t, pulse: e.pulse + 1 })));
            }, [e]),
            r
          );
        },
        "useFloat",
        0,
        function (e, a) {
          let r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
            i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "up";
          (0, t.useEffect)(() => {
            let t = e.current;
            if (!a || !t || "none" === i || window.matchMedia("(prefers-reduced-motion: reduce)").matches)
              return;
            let n = T(8) * ("up" === i ? -1 : 1);
            t.animate(
              [
                { opacity: 0, translate: "0 0" },
                { offset: 0.2, opacity: 1, translate: `0 ${n / 2}px` },
                { offset: 0.8, opacity: 1, translate: `0 ${n}px` },
                { opacity: 0, translate: `0 ${n}px` },
              ],
              { delay: r, duration: 3 * m("slow"), fill: "both" },
            );
          }, [e, a, r, i]);
        },
        "useRovingRadio",
        0,
        (e, a, r) => {
          let i = (0, t.useRef)([]);
          return {
            onKeyDown: (t) => {
              let n = f(t.key, a, e);
              null !== n && (t.preventDefault(), r(n), i.current[n]?.focus());
            },
            setRef: (e) => (t) => {
              i.current[e] = t;
            },
          };
        },
      ],
      785817,
    );
  },
  526199,
  (e) => {
    "use strict";
    var t = e.i(271645),
      a = e.i(903354),
      r = e.i(712470),
      i = e.i(812384),
      n = e.i(821652),
      o = e.i(715413),
      s = e.i(134404),
      l = e.i(622963),
      c = e.i(265832);
    e.i(80460);
    var _ = e.i(973654),
      u = e.i(194613),
      d = e.i(202042);
    e.i(476643);
    var f = e.i(408241);
    e.s([
      "useTriviaPurchase",
      0,
      (e) => {
        let { userData: p, type: m, skillId: T, onSuccess: I, isInGame: y = !1 } = e,
          E = (0, d.useRouter)(),
          A = (0, f.useTriviaTestStore)((e) => e.handleTriviaTestStore),
          S = (0, f.useTriviaTestStore)((e) => e.hearts),
          h = (0, f.useTriviaTestStore)((e) => e.fiftyFiftyUses),
          P = (0, f.useTriviaTestStore)((e) => e.extraTimeUses),
          b = (0, l.useModalStore)((e) => e.handleChangeModalStore),
          v = (0, t.useRef)(S),
          R = (0, t.useRef)(h),
          w = (0, t.useRef)(P),
          g = (0, t.useRef)(p),
          { trigger: C } = (0, n.useCreatePaynextPaymentMutation)(),
          { trigger: O } = (0, r.usePatchUserMutation)(),
          { trigger: x } = (0, i.useCreateUserSessionMutation)(),
          { deviceData: N } = (0, o.useBraintreeDataCollector)();
        ((0, t.useEffect)(() => {
          v.current = S;
        }, [S]),
          (0, t.useEffect)(() => {
            R.current = h;
          }, [h]),
          (0, t.useEffect)(() => {
            w.current = P;
          }, [P]),
          (0, t.useEffect)(() => {
            g.current = p;
          }, [p]));
        let L = (e, t) => {
            let a = { flow_type: "one_time_payment", mixpanel_user_id: t?.id };
            return "hearts" === m
              ? { ...a, hearts_package: e.id, hearts_count: e.hearts, price: e.price }
              : "fifty-fifty" === m
                ? { ...a, power_up_type: m, package_id: e.id, fifty_fifty_count: e.uses, price: e.price }
                : {
                    ...a,
                    power_up_type: m,
                    package_id: e.id,
                    extra_time_count: e.uses,
                    time_value: c.POWER_UPS_CONFIG.EXTRA_TIME_SECONDS,
                    price: e.price,
                  };
          },
          U = async (e, t, r, i, n, o) => {
            let l = (() => {
                switch (m) {
                  case "hearts":
                  default:
                    return _.EOffers.TRIVIA_CREDITS;
                  case "fifty-fifty":
                    return _.EOffers.TRIVIA_HINTS;
                  case "extra-time":
                    return _.EOffers.TRIVIA_TIME;
                }
              })(),
              c = (0, a.preparePaynextParams)({
                user: t,
                metadata: { amount: i?.amount, add_on_type: l, product_type: "trivia", currency: "USD" },
                offer: l,
              });
            (0, a.trackPaynextPurchaseSuccess)({ user: t, paynextParams: c, paymentData: i, planId: r });
            let u = v.current,
              d = R.current,
              p = w.current,
              S = f.useTriviaTestStore.getState().achivedXPBoostId,
              h = {
                ...t?.trivia_test_data,
                hearts: u,
                fiftyFiftyUses: d,
                extraTimeUses: p,
                ...(null !== S && { achivedXPBoostId: S }),
              };
            if ("hearts" === m) {
              let a = u + e.hearts;
              (A({ hearts: a, heartsRefillAt: null }),
                (h = {
                  ...h,
                  hearts: a,
                  completedAt: void 0,
                  ...(T && { [T]: { ...t?.trivia_test_data?.[T] } }),
                }));
            } else if ("fifty-fifty" === m) {
              let t = d + e.uses;
              (A({ fiftyFiftyUses: t, fiftyFiftyRefillAt: void 0 }),
                (h = { ...h, fiftyFiftyUses: t, fiftyFiftyRefillAt: void 0 }));
            } else {
              let t = p + e.uses;
              (A({ extraTimeUses: t, extraTimeRefillAt: void 0 }),
                (h = { ...h, extraTimeUses: t, extraTimeRefillAt: void 0 }));
            }
            (await O({ email: t?.email || "", userInfo: { trivia_test_data: h } }),
              n(!1),
              o(!1),
              b({ isModalVisible: !1, modalComponent: null }),
              "hearts" === m && (y ? I || E.refresh() : E.push(s.EClientRoutes.QUIZ_TRIVIA)),
              I && I());
          };
        return {
          handlePurchase: async (e, t, a) => {
            let r = g.current;
            if (!r || !r?.paymentInfo?.paynextCustomerId) return void t(!1);
            let i = ((e) => {
                if ("hearts" === m)
                  switch (e.id) {
                    case "small":
                      return u.EPaynextPlanIds.TRIVIA_HEARTS_OTP_5;
                    case "medium":
                      return u.EPaynextPlanIds.TRIVIA_HEARTS_OTP_20;
                    case "large":
                      return u.EPaynextPlanIds.TRIVIA_HEARTS_OTP_50;
                  }
                else if ("fifty-fifty" === m)
                  switch (e.id) {
                    case "fifty-fifty-small":
                    default:
                      return u.EPaynextPlanIds.TRIVIA_FIFTY_OTP_5;
                    case "fifty-fifty-medium":
                      return u.EPaynextPlanIds.TRIVIA_FIFTY_OTP_15;
                    case "fifty-fifty-large":
                      return u.EPaynextPlanIds.TRIVIA_FIFTY_OTP_40;
                  }
                else
                  switch (e.id) {
                    case "extra-time-small":
                    default:
                      return u.EPaynextPlanIds.TRIVIA_EXTRA_TIME_OTP_5;
                    case "extra-time-medium":
                      return u.EPaynextPlanIds.TRIVIA_EXTRA_TIME_OTP_15;
                    case "extra-time-large":
                      return u.EPaynextPlanIds.TRIVIA_EXTRA_TIME_OTP_40;
                  }
              })(e),
              n = {
                plan: { id: i },
                user: r,
                customer: { id: r.paymentInfo.paynextCustomerId },
                metadata: L(e, r),
              },
              o = await C(n);
            o.success && o.data
              ? await U(e, r, i, o.data, t, a)
              : (await x({
                  deviceData: "string" == typeof N ? N : JSON.stringify(N) || "",
                  userData: r,
                  planId: i,
                  metadata: L(e, r),
                }),
                b({
                  modalComponent: "card-updater",
                  isModalVisible: !0,
                  modalProps: {
                    user: r,
                    metadata: L(e, r),
                    paymentPlan: i,
                    handleCheckoutSuccess: async () => {
                      await U(e, r, i, o.data, t, a);
                    },
                    onClose: () => {
                      (t(!1), b({ isModalVisible: !1, modalComponent: null }));
                    },
                  },
                }));
          },
        };
      },
    ]);
  },
  818660,
  (e) => {
    "use strict";
    var t = e.i(271645),
      a = e.i(727540),
      r = e.i(265832);
    e.s([
      "useProfileTriviaService",
      0,
      function (e) {
        let i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "working-memory",
          [n, o] = (0, t.useState)(""),
          s = e?.trivia_test_data,
          l = s?.[i],
          c = l?.completedLevel || 0,
          _ = (function (e) {
            if (!e) return "notStarted";
            let t = (0, a.getCurrentDateTimeUTC)().toJSDate(),
              i = new Date(e);
            return t.getTime() - i.getTime() < r.TIME_UNTIL_NEXT_TEST ? "completed" : "notStarted";
          })(s?.completedAt);
        return (
          (0, t.useEffect)(() => {
            if (!s?.completedAt || "completed" !== _) return void o("");
            let e = () => {
              let e = (0, a.getCurrentDateTimeUTC)().toJSDate(),
                t =
                  new Date(new Date(s.completedAt).getTime() + r.TIME_UNTIL_NEXT_TEST).getTime() -
                  e.getTime();
              if (t <= 0) return void o("");
              let i = Math.floor(t / 36e5),
                n = Math.floor((t % 36e5) / 6e4),
                l = Math.floor((t % 6e4) / 1e3);
              o(i > 0 ? `${i}h ${n}m ${l}s` : n > 0 ? `${n}m ${l}s` : `${l}s`);
            };
            e();
            let t = setInterval(e, 1e3);
            return () => clearInterval(t);
          }, [s?.completedAt, _]),
          {
            testStatus: _,
            timeUntilNextTest: n,
            completedLevel: c || 1,
            nextLevel: c + 1,
            displayLevel: "completed" === _ ? c || 1 : c + 1,
          }
        );
      },
    ]);
  },
  476643,
  408241,
  (e) => {
    "use strict";
    var t = e.i(768834),
      a = e.i(579473),
      r = e.i(265832);
    let i = {
        timeLeft: r.TIMER_DURATION,
        streak: 0,
        maxStreak: 0,
        earnedXPCurrentLevel: 0,
        correctAnswers: 0,
        currentQuestionIdx: 0,
        isTestCompleted: !1,
        streakMilestonesReached: { streak3: !1, streak5: !1, streak10: !1 },
        hearts: r.HEARTS_CONFIG.INITIAL_HEARTS,
        currentCognitiveSkill: "working-memory",
        currentLevel: 1,
        cognitiveSkillName: "generic",
        questionTimes: [],
        questionStartTime: null,
        fiftyFiftyUses: r.POWER_UPS_CONFIG.INITIAL_FIFTY_FIFTY_USES,
        extraTimeUses: r.POWER_UPS_CONFIG.INITIAL_EXTRA_TIME_USES,
        usedFiftyFiftyOnQuestion: null,
        usedExtraTimeOnQuestion: null,
        disabledAnswers: [],
        achivedXPBoostId: null,
        fiftyFiftyRefillAt: null,
        extraTimeRefillAt: null,
        heartsRefillAt: null,
        progressSaved: !1,
        skillBoosts: { logic: 0, visual: 0, memory: 0 },
        showLevelUpConfetti: !1,
        completionSoundPlayed: !1,
        givenAnswers: [],
        dailyProgress: { date: null, levelsCompleted: 0, dailyTargetsCompleted: 0 },
      },
      n = (0, t.create)()(
        (0, a.persist)(
          (0, a.devtools)(
            (e) => ({
              ...i,
              handleTriviaTestStore: (t) => e((e) => ({ ...e, ...t })),
              resetTriviaTestStore: () => e(i),
              clearStorage: () => {
                (e(i), localStorage.removeItem("trivia-test-storage"));
              },
            }),
            { enabled: !1 },
          ),
          {
            name: "trivia-test-storage",
            partialize: (e) => ({
              currentQuestionIdx: e.currentQuestionIdx,
              streak: e.streak,
              maxStreak: e.maxStreak,
              earnedXPCurrentLevel: e.earnedXPCurrentLevel,
              correctAnswers: e.correctAnswers,
              isTestCompleted: e.isTestCompleted,
              streakMilestonesReached: e.streakMilestonesReached,
              hearts: e.hearts,
              currentCognitiveSkill: e.currentCognitiveSkill,
              currentLevel: e.currentLevel,
              cognitiveSkillName: e.cognitiveSkillName,
              questionTimes: e.questionTimes,
              questionStartTime: e.questionStartTime,
              fiftyFiftyUses: e.fiftyFiftyUses,
              extraTimeUses: e.extraTimeUses,
              usedFiftyFiftyOnQuestion: e.usedFiftyFiftyOnQuestion,
              usedExtraTimeOnQuestion: e.usedExtraTimeOnQuestion,
              disabledAnswers: e.disabledAnswers,
              fiftyFiftyRefillAt: e.fiftyFiftyRefillAt,
              extraTimeRefillAt: e.extraTimeRefillAt,
              heartsRefillAt: e.heartsRefillAt,
              skillBoosts: e.skillBoosts,
              achivedXPBoostId: e.achivedXPBoostId,
              givenAnswers: e.givenAnswers,
              dailyProgress: e.dailyProgress,
              completionSoundPlayed: e.completionSoundPlayed,
            }),
          },
        ),
      );
    (e.s(["useTriviaTestStore", 0, n], 408241), e.s([], 476643));
  },
  903354,
  (e) => {
    "use strict";
    var t = e.i(523173);
    e.i(756503);
    var a = e.i(542516);
    e.i(470366);
    var r = e.i(504001);
    e.s([
      "preparePaynextParams",
      0,
      (e) => {
        let { user: t, metadata: r, offer: i } = e;
        return {
          paymentOrchestrator: "PayNext",
          paynextSessionId: t?.paymentInfo?.paynextClientSessionId,
          paynextPaymentMethod: t?.paymentInfo?.paymentMethodType,
          paynextPaymentCurrency: t?.paymentInfo?.paynextAmountCurrency,
          displayedCurrency: t?.paymentInfo?.paynextAmountDisplayedCurrency,
          supabase_user_id: t?.id || "",
          first_name: t?.paymentInfo?.firstName || "",
          last_name: t?.paymentInfo?.lastName || "",
          hostname: `${a.envClient.NEXT_PUBLIC_BILLING_HOSTNAME}`,
          plan_name: i,
          sub_order_country: t?.currency?.countryCode || "",
          email: t?.email || "",
          ...r,
        };
      },
      "trackPaynextPurchaseAttempt",
      0,
      (e) => {
        let { user: a, paynextParams: i, offer: n } = e;
        (0, r.trackClientEvents)({
          event: t.EAnalyticEvents.PURCHASE_ATTEMPT,
          user: a,
          params: { ...i, flow_type: "one_time_payment", one_time_purchase_type: n },
        });
      },
      "trackPaynextPurchaseError",
      0,
      (e) => {
        let { user: a, paynextParams: i, offer: n, errorCode: o, errorMessage: s } = e;
        (0, r.trackClientEvents)({
          event: t.EAnalyticEvents.PURCHASE_ERROR,
          user: a,
          params: {
            ...i,
            flow_type: "one_time_payment",
            one_time_purchase_type: n,
            error_code: o,
            detailed_message: s,
          },
        });
      },
      "trackPaynextPurchaseSuccess",
      0,
      (e) => {
        let { user: a, paynextParams: i, offer: n, paymentData: o, planId: s } = e;
        (0, r.trackClientEvents)({
          event: t.EAnalyticEvents.PURCHASE_SUCCESS,
          user: a,
          params: {
            ...i,
            amount: o?.amount,
            flow_type: "one_time_payment",
            one_time_purchase_type: n,
            paynextSubscriptionId: a?.paymentInfo?.subscriptionId,
            paynextCustomerId: o?.customer?.id,
            paynextPaymentID: o?.id,
            paynextPlanID: s,
            paynextAmountUsd: o?.amount_usd,
            paynextPaymentAmount: o?.amount,
          },
        });
      },
    ]);
  },
  812384,
  408110,
  (e) => {
    "use strict";
    var t = e.i(954616),
      a = e.i(86596);
    e.i(682770);
    var r = e.i(934952),
      i = e.i(117595),
      n = e.i(866897),
      o = e.i(134404),
      s = e.i(157273),
      l = e.i(60423);
    e.i(756503);
    var c = e.i(542516);
    e.i(531122);
    var _ = e.i(81844);
    let u = async (e) => {
        let t = await _.httpInstance.post(o.EApiRoutes.CHECKOUT_SESSION, {
            json: ((e) => {
              if (!e.userData || e.userData.quiz_answers_additional?.length) return e;
              let t = l.accessLocalStorage.getItem(s.StorageKeys.MYIQ_NON_IMAGE_ANSWERS);
              if (!t) return e;
              try {
                let a = JSON.parse(t);
                if (Array.isArray(a) && a.length)
                  return { ...e, userData: { ...e.userData, quiz_answers_additional: a } };
              } catch {}
              return e;
            })(
              ((e) => {
                if (!e.userData || e.userData.quiz_answers?.length) return e;
                let t = l.accessLocalStorage.getItem(s.StorageKeys.QUIZ_ANSWERS);
                if (!t) return e;
                try {
                  let a = JSON.parse(t);
                  if (Array.isArray(a) && a.length)
                    return { ...e, userData: { ...e.userData, quiz_answers: a } };
                } catch {}
                return e;
              })(e),
            ),
            throwHttpErrors: !1,
          }),
          a = await t.json();
        return (
          a.success &&
            a.data?.paynextClientSessionId &&
            i.default.set(n.ECookieArg.PAYNEXT_SESSION, a.data?.paynextClientSessionId, {
              secure: "production" === c.envClient.NEXT_PUBLIC_APP_ENV,
              expires: 40 / 24,
              path: "/",
              sameSite: "lax",
            }),
          a
        );
      },
      d = async (e) => {
        let t = await _.httpInstance.post(o.EApiRoutes.CHECKOUT_SESSION, { json: e, throwHttpErrors: !1 });
        return (await t.json()).data ?? null;
      },
      f = async (e) =>
        (
          await _.httpInstance.post(o.EApiRoutes.CHECKOUT_SESSION_FRAUD_SESSIONS, {
            json: e,
            throwHttpErrors: !1,
          })
        ).json();
    (e.s(
      [
        "createUserSessionFetcher",
        0,
        u,
        "getCheckoutSessionPriceFetcher",
        0,
        d,
        "updateCheckoutSessionFraudSessionsFetcher",
        0,
        f,
      ],
      408110,
    ),
      e.s(
        [
          "useCreateUserSessionMutation",
          0,
          () => {
            let e = (0, a.useUserStore)((e) => e.handleChangeUserStore),
              i = (0, t.useMutation)({
                mutationFn: u,
                onSuccess(t) {
                  t.success
                    ? t.data &&
                      e({
                        user: {
                          paymentInfo: {
                            ...t.data,
                            paynextAmountPayment: t.data.paynextAmountPayment?.toString(),
                          },
                        },
                      })
                    : (0, r.customToast)(t?.error || "", "error");
                },
              });
            return { ...i, trigger: i.mutateAsync };
          },
          "useUpdateCheckoutSessionFraudSessionsMutation",
          0,
          () => {
            let e = (0, t.useMutation)({ mutationFn: f });
            return { ...e, trigger: e.mutateAsync };
          },
        ],
        812384,
      ));
  },
  821652,
  495585,
  (e) => {
    "use strict";
    var t = e.i(954616),
      a = e.i(134404);
    e.i(957215);
    var r = e.i(81844);
    let i = async (e, t) => {
      let { arg: a } = t,
        i = await r.apiInstance.post(e, { json: a, throwHttpErrors: !1 });
      return await i.json();
    };
    (e.s(["createPaynextPaymentFetcher", 0, i], 495585),
      e.s(
        [
          "useCreatePaynextPaymentMutation",
          0,
          () => {
            let e = (0, t.useMutation)({
              mutationKey: [a.EApiRoutes.PAYNEXT_PAYMENT],
              mutationFn: (e) => i(a.EApiRoutes.PAYNEXT_PAYMENT, { arg: e }),
            });
            return { ...e, trigger: e.mutateAsync };
          },
        ],
        821652,
      ));
  },
  265832,
  (e) => {
    "use strict";
    e.s([
      "ANIMATION_CONFIG",
      0,
      { COIN_ANIMATION_DURATION: 1200, MIN_INTERVAL_DURATION: 16, NOTIFICATION_DELAY: 1200 },
      "AVERAGE_TIME_FOR_SKILL_BOOST",
      0,
      8e3,
      "DAILY_FULL_COMPLETION_KEYS",
      0,
      [
        "trivia_daily_full_0",
        "trivia_daily_full_1",
        "trivia_daily_full_2",
        "trivia_daily_full_3",
        "trivia_daily_full_4",
        "trivia_daily_full_5",
        "trivia_daily_full_6",
        "trivia_daily_full_7",
      ],
      "DAILY_NOT_FULL_COMPLETION_KEYS",
      0,
      [
        "trivia_daily_more_0",
        "trivia_daily_more_1",
        "trivia_daily_more_2",
        "trivia_daily_more_3",
        "trivia_daily_more_4",
        "trivia_daily_more_5",
        "trivia_daily_more_6",
        "trivia_daily_more_7",
      ],
      "DAILY_PROGRESS_SETS",
      0,
      5,
      "HEARTS_CONFIG",
      0,
      {
        INITIAL_HEARTS: 3,
        PURCHASED_HEARTS: 5,
        HEARTS_LOSS_PER_WRONG_ANSWER: 1,
        HEARTS_ANIMATION_DELAY: 700,
        HEARTS_ANIMATION_DURATION: 600,
      },
      "LEVEL_COMPLETED_BONUS",
      0,
      10,
      "MOVE_TO_TEST_COMPLETION_DELAY",
      0,
      400,
      "PLAY_COIN_REWARD_SOUND_AFTER_DELAY",
      0,
      500,
      "POWER_UPS_CONFIG",
      0,
      { INITIAL_FIFTY_FIFTY_USES: 3, INITIAL_EXTRA_TIME_USES: 3, EXTRA_TIME_SECONDS: 30, REFILL_TIME: 18e5 },
      "SKILL_BOOST_SCORE",
      0,
      0.3,
      "STREAK_BONUS_XP",
      0,
      { STREAK_3: 10, STREAK_5: 20, STREAK_10: 50 },
      "STREAK_MILESTONES",
      0,
      { STREAK_3: 3, STREAK_5: 5, STREAK_10: 10 },
      "TIMER_DURATION",
      0,
      20,
      "TIME_UNTIL_NEXT_TEST",
      0,
      18e5,
      "TRIVIA_COMPLETE_SCREEN_SUBTITLE_KEYS",
      0,
      [
        "trivia_complete_subtitle_0",
        "trivia_complete_subtitle_1",
        "trivia_complete_subtitle_2",
        "trivia_complete_subtitle_3",
        "trivia_complete_subtitle_4",
        "trivia_complete_subtitle_5",
        "trivia_complete_subtitle_6",
        "trivia_complete_subtitle_7",
      ],
      "XP_BOOST_CONFIG",
      0,
      [
        { id: 1, xp: 90, powerUp: 2, timeUp: 0, cutOff: 0 },
        { id: 2, xp: 200, powerUp: 3, timeUp: 1, cutOff: 0 },
        { id: 3, xp: 450, powerUp: 4, timeUp: 1, cutOff: 1 },
        { id: 4, xp: 800, powerUp: 5, timeUp: 2, cutOff: 1 },
        { id: 5, xp: 1400, powerUp: 7, timeUp: 3, cutOff: 2 },
        { id: 6, xp: 2200, powerUp: 10, timeUp: 4, cutOff: 3 },
        { id: 7, xp: 3200, powerUp: 12, timeUp: 5, cutOff: 4 },
        { id: 8, xp: 4500, powerUp: 15, timeUp: 6, cutOff: 5 },
        { id: 9, xp: 6500, powerUp: 18, timeUp: 8, cutOff: 6 },
        { id: 10, xp: 9e3, powerUp: 22, timeUp: 10, cutOff: 8 },
        { id: 11, xp: 13e3, powerUp: 27, timeUp: 12, cutOff: 10 },
        { id: 12, xp: 18e3, powerUp: 35, timeUp: 15, cutOff: 12 },
      ],
      "XP_PER_CORRECT_ANSWER",
      0,
      10,
    ]);
  },
  715413,
  (e) => {
    "use strict";
    var t = e.i(271645);
    e.i(756503);
    var a = e.i(542516);
    let r = [
      "https://js.braintreegateway.com/web/3.133.0/js/client.min.js",
      "https://js.braintreegateway.com/web/3.133.0/js/data-collector.min.js",
    ];
    e.s([
      "useBraintreeDataCollector",
      0,
      () => {
        let [e, i] = (0, t.useState)(null),
          [n, o] = (0, t.useState)(!1),
          [s, l] = (0, t.useState)(null);
        return (
          (0, t.useEffect)(() => {
            if ("u" > typeof document)
              for (let e of r) {
                if (document.querySelector(`script[src="${e}"]`)) continue;
                let t = document.createElement("script");
                ((t.src = e), (t.async = !0), document.head.appendChild(t));
              }
            let e = null,
              t = null,
              n = Date.now(),
              s = () =>
                !!(window.braintree?.client && window.braintree?.dataCollector) &&
                (e && (clearInterval(e), (e = null)),
                t && (clearTimeout(t), (t = null)),
                o(!0),
                l(null),
                window.braintree?.client?.create(
                  { authorization: a.envClient.NEXT_PUBLIC_BRAINTREE_AUTHORIZATION || "" },
                  function (e, t) {
                    if (e) {
                      (i(""), o(!1));
                      return;
                    }
                    window?.braintree?.dataCollector?.create({ client: t }, function (e, t) {
                      (o(!1), e) ? i("") : i(t.deviceData);
                    });
                  },
                ),
                !0);
            if (!s())
              return (
                (e = setInterval(() => {
                  !s() && Date.now() - n >= 1e4 && (e && (clearInterval(e), (e = null)), i(""));
                }, 100)),
                (t = setTimeout(() => {
                  (e && (clearInterval(e), (e = null)), window.braintree || i(""));
                }, 1e4)),
                () => {
                  (e && clearInterval(e), t && clearTimeout(t));
                }
              );
          }, []),
          { deviceData: e, isCollecting: n, error: s }
        );
      },
    ]);
  },
  727540,
  (e) => {
    "use strict";
    var t = e.i(632729);
    e.s(["getCurrentDateTimeUTC", 0, () => t.DateTime.utc()]);
  },
  428460,
  (e) => {
    "use strict";
    var t = e.i(768834),
      a = e.i(579473);
    let r = (0, t.create)()(
      (0, a.persist)(
        (0, a.devtools)((e) => ({ xp: 0, setXP: (t) => e({ xp: t }), resetXP: () => e({ xp: 0 }) })),
        { name: "optimisticXP", version: 1 },
      ),
    );
    e.s(["useOptimisticXPStore", 0, r]);
  },
  190899,
  (e) => {
    "use strict";
    e.s([
      "accessSessionStorageUtil",
      0,
      {
        getItem: (e) => {
          try {
            return sessionStorage.getItem(e);
          } catch {
            return null;
          }
        },
        setItem: (e, t) => {
          try {
            sessionStorage.setItem(e, t);
          } catch {
            return;
          }
        },
        removeItem: (e) => {
          try {
            sessionStorage.removeItem(e);
          } catch {
            return;
          }
        },
      },
    ]);
  },
  915113,
  (e) => {
    "use strict";
    var t = e.i(117595),
      a = e.i(190899),
      r = e.i(866897),
      i = e.i(157273);
    let n = new Set([
      "DE",
      "RO",
      "IT",
      "CZ",
      "PL",
      "NL",
      "HU",
      "BE",
      "BG",
      "CH",
      "PT",
      "MT",
      "AT",
      "SE",
      "LT",
      "IS",
      "LU",
      "HR",
      "LV",
      "EE",
      "SK",
      "GR",
      "AE",
      "SA",
    ]);
    e.s([
      "getIsMarketingSource",
      0,
      () => {
        if ("DE" === (t.default.get(r.ECookieArg.COUNTRY) || "US")) return "";
        let e = a.accessSessionStorageUtil.getItem(i.StorageKeys.MARKETING_ID),
          n = a.accessSessionStorageUtil.getItem(i.StorageKeys.MARKETING_SOURCE);
        return e || n || "";
      },
      "getIsMarketingSourceForSpecificCountry",
      0,
      () => {
        let e = t.default.get(r.ECookieArg.COUNTRY) || "US";
        if (!n.has(e)) return "";
        let o = a.accessSessionStorageUtil.getItem(i.StorageKeys.MARKETING_ID),
          s = a.accessSessionStorageUtil.getItem(i.StorageKeys.MARKETING_SOURCE);
        return o || s || "";
      },
      "getIsPersonalityMarketingSource",
      0,
      () => !!a.accessSessionStorageUtil.getItem(i.StorageKeys.PERSONALITY_MARKETING_SOURCE),
    ]);
  },
  194613,
  (e) => {
    "use strict";
    e.i(756503);
    var t,
      a,
      r = e.i(542516),
      i =
        (((t = {}).SPLIT_TRIAL = "price_28ab40cd-1eb6-44c4-a11d-409cd7a8c59f"),
        (t.SPLIT_TRIAL_SECOND = "price_24a1725c-cbbe-4f34-9eca-876b9e7093da"),
        (t.SPLIT_TRIAL_PAYPAL = "price_31e0469d-6f9a-47be-b92e-c75e8556f8bc"),
        (t.SPLIT_TRIAL_CASHAPP = "price_a48b42ac-8ea2-457f-a781-99a8fede9a5d"),
        (t.SPLIT_TRIAL_PROMO_PRICE = "price_c1a24246-8ef8-4105-a614-c0a4b71178dd"),
        (t.TRIVIA_HEARTS_OTP_5 = "price_4e0bb9fb-d47b-44fc-92a2-f4a57b2920a8"),
        (t.TRIVIA_HEARTS_OTP_20 = "price_07b5b189-4240-4b4d-b635-32c16f31f888"),
        (t.TRIVIA_HEARTS_OTP_50 = "price_e271dce4-d347-411f-970f-a71cb2f78d97"),
        (t.TRIVIA_FIFTY_OTP_5 = "price_11d417ca-2d98-46a2-a591-2ac9e95c5f6b"),
        (t.TRIVIA_FIFTY_OTP_15 = "price_2de429d3-5b21-47c4-ab9b-2788a42b8183"),
        (t.TRIVIA_FIFTY_OTP_40 = "price_bce8ff41-3836-483d-9a21-c75d14d651f7"),
        (t.TRIVIA_EXTRA_TIME_OTP_5 = "price_cc0e09fe-22cd-4ff8-a0a4-005c4bdf8f0c"),
        (t.TRIVIA_EXTRA_TIME_OTP_15 = "price_67f3a405-5cd6-4851-90da-e1e81b36e934"),
        (t.TRIVIA_EXTRA_TIME_OTP_40 = "price_adecce61-6e20-4acd-8404-4bad3572ba29"),
        (t.DOWNGRADED_SUBSCRIPTION = "price_bf2864f3-4835-4ffc-a188-0284b4da920d"),
        (t.DOWNGRADED_SUBSCRIPTION_6_99 = "price_564c5f0f-4a71-4e37-b664-e3d0083251ad"),
        (t.DOWNGRADED_SUBSCRIPTION_9_99 = "price_a5dbadc4-ff56-4bad-bbb6-3b3376e6e6c6"),
        (t.PRINTED_CERTIFICATE_UPSELL = "price_94bdf33b-db92-4aff-bab4-2bb088dbb904"),
        (t.FAST_TRACK_REPORT_UNLOCK = "price_a34a46de-fca6-4175-8b3c-3a358b800070"),
        (t.BUY_TRIVIA_UPSELL_V3 = "price_f11cc629-4cf7-4224-9f5f-5d305fd8d370"),
        (t.BUY_TRIVIA_UPSELL_EXIT = "price_b0b581bd-d991-401b-bb68-38e8b4ffc9ea"),
        (t.SKIP_TRIAL_AB = "price_c466a672-e9a6-4f76-b0c4-389475ec3afd"),
        (t.SKIP_TRIAL_AB_V2 = "price_27971406-8be3-47b1-b8fc-e3bf5bef8de7"),
        (t.RETAKE_IQ_BASE = "price_16bd8029-114a-4032-a5d5-3758e45ff7cb"),
        (t.RETAKE_IQ_ADVANCED = "price_3198f7da-adf6-4720-a6c3-35ada36febf3"),
        (t.SPLIT_TRIAL_TIMER_EXPIRED = "price_b2ed6deb-b7ff-433b-a71c-08da6b9819b1"),
        (t.SPLIT_TRIAL_SECOND_EXPIRED = "price_bc127d58-a19b-4b5b-acae-5e680e598166"),
        (t.PLAN_PICKER_WEEKLY = "price_3877b33a-5505-4aa2-98a5-406002d21e99"),
        (t.PLAN_PICKER_MONTHLY = "price_25eb958a-86b7-4918-9e40-d0c9ae5417b5"),
        (t.PLAN_PICKER_QUARTERLY = "price_74eb2df1-146c-4d6e-b1b8-7b7a68537d36"),
        t),
      n =
        (((a = {}).SPLIT_TRIAL = "price_97cced15-887e-453e-9473-61e4aeab9219"),
        (a.SPLIT_TRIAL_SECOND = "price_becb0124-0330-4b26-8f9a-a14a5c704bd3"),
        (a.SPLIT_TRIAL_PAYPAL = "price_95321730-8959-454b-899c-75be62f284ac"),
        (a.SPLIT_TRIAL_CASHAPP = "price_8fcb11dd-4161-4dc7-bdef-6d567565c1bc"),
        (a.SPLIT_TRIAL_PROMO_PRICE = "price_4cf92053-5660-49a6-a2b8-1a442b46b5c0"),
        (a.TRIVIA_HEARTS_OTP_5 = "price_1a9e2116-fce9-4f06-9a1f-23dc7a8be283"),
        (a.TRIVIA_HEARTS_OTP_20 = "price_70829646-1a27-4044-b8b2-bb4e5a5cd398"),
        (a.TRIVIA_HEARTS_OTP_50 = "price_c684ed53-441e-4af5-8107-3c7ca577f971"),
        (a.TRIVIA_FIFTY_OTP_5 = "price_1928343b-22e6-4c58-a9e6-3922c278650c"),
        (a.TRIVIA_FIFTY_OTP_15 = "price_b277eb6a-c329-437f-85bb-3b370e0d84e1"),
        (a.TRIVIA_FIFTY_OTP_40 = "price_2d40f14d-9ea9-434a-986b-74f929a25de3"),
        (a.TRIVIA_EXTRA_TIME_OTP_5 = "price_6b06ba8e-9b0c-424a-9d9d-d669b2165786"),
        (a.TRIVIA_EXTRA_TIME_OTP_15 = "price_34771465-2aa9-4747-87d6-b62eb0e841db"),
        (a.TRIVIA_EXTRA_TIME_OTP_40 = "price_426595f3-e83b-4a55-bf2e-7c00389f551a"),
        (a.DOWNGRADED_SUBSCRIPTION = "price_bcddbded-fefc-4673-9179-f9830b8c9352"),
        (a.DOWNGRADED_SUBSCRIPTION_6_99 = "price_ba942205-783f-4936-9b5e-95ae3a172b7b"),
        (a.DOWNGRADED_SUBSCRIPTION_9_99 = "price_bd425670-dd91-45bc-afd9-c80975d3956e"),
        (a.PRINTED_CERTIFICATE_UPSELL = "price_02fa8dc7-1606-4bb8-8260-8491d31b0ee1"),
        (a.FAST_TRACK_REPORT_UNLOCK = "price_2218ce0c-1547-4235-a80f-1e59e298e5e6"),
        (a.BUY_TRIVIA_UPSELL_V3 = "price_a72859eb-603a-4c04-8a7b-86815cbba4eb"),
        (a.BUY_TRIVIA_UPSELL_EXIT = "price_498359c1-d083-41ee-a3ee-3ec769e913db"),
        (a.SKIP_TRIAL_AB = "price_2f9f67da-6c99-41b4-ac03-e4180a9cd0df"),
        (a.SKIP_TRIAL_AB_V2 = "price_4f7cc975-6e4e-4683-b4e7-fd320bf01b63"),
        (a.RETAKE_IQ_BASE = "price_7b75f6d6-5884-4690-a6e7-d59c9ad93e91"),
        (a.RETAKE_IQ_ADVANCED = "price_36b27094-d8bd-4297-9bd9-4b21caed26eb"),
        (a.SPLIT_TRIAL_TIMER_EXPIRED = "price_ec5a9c51-933a-45d3-ac6f-b64405797f03"),
        (a.SPLIT_TRIAL_SECOND_EXPIRED = "price_874b2f4c-33c6-4d2f-8eef-c5a20e265c3b"),
        (a.PLAN_PICKER_WEEKLY = "price_bcce7c71-aec4-4af8-8dea-6a14956a2b2e"),
        (a.PLAN_PICKER_MONTHLY = "price_dcae0301-9a8d-4986-95a0-90983f7809d9"),
        (a.PLAN_PICKER_QUARTERLY = "price_2425461b-cb08-44f2-86cd-f6fe17ccf2a5"),
        a);
    let o = "production" === r.envClient.NEXT_PUBLIC_PAYNEXT_ENV ? i : n;
    e.s(["EPaynextPlanIds", 0, o]);
  },
]);
