(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  963032,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("circle-alert", [
      ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
      ["line", { x1: "12", x2: "12", y1: "8", y2: "12", key: "1pkeuh" }],
      ["line", { x1: "12", x2: "12.01", y1: "16", y2: "16", key: "4dfq90" }],
    ]);
    e.s(["AlertCircle", 0, t], 963032);
  },
  979303,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(972520),
      l = e.i(618566),
      i = e.i(861745),
      r = e.i(271645),
      _ = e.i(266027);
    e.i(867107);
    var n = e.i(1693),
      c = e.i(523173),
      p = e.i(134404);
    e.i(267493);
    var s = e.i(605663);
    e.i(853754);
    var h = e.i(319970);
    e.i(924482);
    var o = e.i(20511);
    e.i(470366);
    var y = e.i(504001);
    let u = `${p.EClientRoutes.BASE_PROFILE}${p.EClientRoutes.HELP}`,
      d = `${p.EClientRoutes.TERMS}#subscription-services`,
      m = {
        cancel: p.EClientRoutes.CANCELLATION,
        help: p.EClientRoutes.HELP,
        plans: d,
        billing: d,
        cancellationTerms: d,
        refund: `${p.EClientRoutes.TERMS}#refund-policy`,
      },
      k = {
        nodes: [
          { type: "paragraph", key: "help_article_cancel_intro" },
          { type: "subheading", key: "help_article_cancel_portal_title" },
          { type: "paragraph", key: "help_article_cancel_portal_text" },
          {
            type: "button",
            key: "help_article_cancel_portal_button",
            href: p.EClientRoutes.CANCELLATION,
            variant: "primary",
          },
          { type: "subheading", key: "help_article_cancel_profile_title" },
          { type: "paragraph", key: "help_article_cancel_profile_text" },
          { type: "subheading", key: "help_article_cancel_after_title" },
          { type: "paragraph", key: "help_article_cancel_after_intro" },
          {
            type: "list",
            keys: [
              "help_article_cancel_after_item_1",
              "help_article_cancel_after_item_2",
              "help_article_cancel_after_item_3",
            ],
          },
          { type: "paragraph", key: "help_article_cancel_contact" },
        ],
      },
      g = {
        warningKey: "help_article_delete_warning",
        nodes: [
          { type: "subheading", key: "help_article_delete_vs_cancel_title" },
          { type: "paragraph", key: "help_article_delete_vs_cancel_text" },
          { type: "subheading", key: "help_article_delete_what_happens_title" },
          {
            type: "list",
            keys: [
              "delete_account_help_what_happens_item_1",
              "delete_account_help_what_happens_item_2",
              "delete_account_help_what_happens_item_3",
            ],
          },
          { type: "subheading", key: "help_article_delete_how_title" },
          { type: "paragraph", key: "help_article_delete_how_text" },
          {
            type: "button",
            key: "delete_account_help_cta_button",
            href: p.EClientRoutes.DELETE_ACCOUNT,
            variant: "danger",
          },
          { type: "paragraph", key: "help_article_delete_contact" },
        ],
      },
      x = [
        { type: "paragraph", key: "help_article_contact_intro" },
        { type: "subheading", key: "help_article_contact_help_center_title" },
        { type: "paragraph", key: "help_article_contact_help_center_text" },
        { type: "subheading", key: "help_article_contact_email_title" },
        { type: "paragraph", key: "help_article_contact_email_text" },
      ],
      E = [
        { type: "subheading", key: "help_article_contact_cancel_title" },
        { type: "paragraph", key: "help_article_contact_cancel_text" },
      ],
      C = {
        "how-do-i-cancel-my-subscription": k,
        "does-my-subscription-automatically-renew": {
          nodes: [
            { type: "paragraph", key: "help_article_renewal_intro" },
            { type: "subheading", key: "help_article_renewal_billing_title" },
            {
              type: "list",
              keys: ["help_article_renewal_billing_item_1", "help_article_renewal_billing_item_2"],
            },
            { type: "subheading", key: "help_article_renewal_details_title" },
            { type: "paragraph", key: "help_article_renewal_details_text" },
            { type: "subheading", key: "help_article_renewal_process_title" },
            { type: "paragraph", key: "help_article_renewal_process_text" },
            {
              type: "list",
              keys: [
                "help_article_renewal_process_item_1",
                "help_article_renewal_process_item_2",
                "help_article_renewal_process_item_3",
              ],
            },
            { type: "subheading", key: "help_article_important_to_know" },
            { type: "paragraph", key: "help_article_renewal_important_text" },
            { type: "subheading", key: "help_article_renewal_stop_title" },
            { type: "paragraph", key: "help_article_renewal_stop_text" },
          ],
        },
        "updating-email-address": {
          nodes: [
            { type: "paragraph", key: "help_article_email_intro" },
            { type: "subheading", key: "help_article_email_yourself_title" },
            {
              type: "list",
              keys: [
                "help_article_email_yourself_item_1",
                "help_article_email_yourself_item_2",
                "help_article_email_yourself_item_3",
                "help_article_email_yourself_item_4",
              ],
            },
            { type: "subheading", key: "help_article_email_support_title" },
            { type: "paragraph", key: "help_article_email_support_text" },
            { type: "subheading", key: "help_article_important_to_know" },
            { type: "paragraph", key: "help_article_email_important_text" },
          ],
        },
        "deleting-your-account": g,
        "contact-myiq-support": {
          nodes: [
            ...x,
            { type: "subheading", key: "help_article_contact_post_title" },
            { type: "paragraph", key: "help_article_contact_post_text" },
            ...E,
          ],
        },
        "contact-myiq-support-mx": { nodes: [...x, ...E] },
      },
      b = /[\p{L}\p{N}]+(?:-[\p{L}\p{N}]+)+/gu;
    var f = e.i(963032),
      w = e.i(948148),
      L = e.i(982363);
    e.i(791371);
    var A = e.i(642448),
      v = e.i(202042);
    e.i(382838);
    var T = e.i(342800);
    let j = (e) => {
      let { article: l, isProfile: r = !1, serverUser: _, userSubscriptionId: n } = e,
        p = (0, w.useTranslations)(),
        s = (0, i.useLocale)(),
        h = (0, L.createSupportMailtoLink)({
          userId: _?.id,
          subscriptionId: n,
          userEmail: _?.email,
          supportEmail: "help@myiq.com",
        }),
        o = {
          cancel: (e) => (0, t.jsx)(v.Link, { href: m.cancel, children: e }),
          help: (e) => (0, t.jsx)(v.Link, { href: r ? u : m.help, children: e }),
          plans: (e) => (0, t.jsx)(v.Link, { href: m.plans, children: e }),
          billing: (e) => (0, t.jsx)(v.Link, { href: m.billing, children: e }),
          cancellationTerms: (e) => (0, t.jsx)(v.Link, { href: m.cancellationTerms, children: e }),
          refund: (e) => (0, t.jsx)(v.Link, { href: m.refund, children: e }),
          email: (e) => (0, t.jsx)("a", { href: h, children: e }),
          b: (e) => (0, t.jsx)("strong", { children: e }),
        };
      return (0, t.jsxs)("div", {
        className: "flex flex-col gap-6",
        children: [
          l.warningKey &&
            (0, t.jsxs)("div", {
              className: "flex items-start gap-3 rounded-2xl bg-danger-custom/5 p-4",
              children: [
                (0, t.jsx)(f.AlertCircle, {
                  "aria-hidden": !0,
                  className: "mt-0.5 size-5 shrink-0 text-danger-custom",
                }),
                (0, t.jsx)("p", {
                  className: "text-hp-body-sm font-medium text-black-custom",
                  children: p(l.warningKey),
                }),
              ],
            }),
          (0, t.jsx)("div", {
            className: T.DEMO_STATIC_PAGE_PROSE_CLASS,
            children: l.nodes.map((e) => {
              switch (e.type) {
                case "subheading":
                  return (0, t.jsx)("h2", { children: p(e.key) }, e.key);
                case "paragraph":
                  return (0, t.jsx)("p", { children: p.rich(e.key, o) }, e.key);
                case "list":
                  return (0, t.jsx)(
                    "ul",
                    { children: e.keys.map((e) => (0, t.jsx)("li", { children: p.rich(e, o) }, e)) },
                    e.keys.join(),
                  );
                case "button":
                  return (0, t.jsx)(
                    "div",
                    {
                      className: "my-6",
                      children: (0, t.jsxs)(A.DemoButton, {
                        href: (0, v.getPathname)({ href: e.href, locale: s }),
                        variant: e.variant,
                        size: "lg",
                        className: "w-full !text-white !no-underline sm:w-fit",
                        onClick: () => {
                          e.href === m.cancel &&
                            (0, y.trackClientEvents)({
                              event: c.EAnalyticEvents.CANCEL_FLOW_CANCELLATION_PORTAL_CLICKED,
                            });
                        },
                        children: [
                          p(e.key),
                          "primary" === e.variant &&
                            (0, t.jsx)(a.ArrowRight, { "aria-hidden": !0, className: "rtl:rotate-180" }),
                        ],
                      }),
                    },
                    e.key,
                  );
              }
            }),
          }),
        ],
      });
    };
    var N = e.i(353527);
    e.s(
      [
        "default",
        0,
        (e) => {
          let u,
            {
              slug: d,
              isProfile: m = !1,
              header: k = (0, t.jsx)(o.DemoStaticHeaderComponent, {}),
              serverUser: g,
              userSubscriptionId: x,
            } = e,
            E = (0, i.useLocale)(),
            { data: f, isPending: w, isError: L } = (0, _.useQuery)((0, s.pageQueryOptions)(d, E)),
            A = C[d];
          return ((0, r.useEffect)(() => {
            ("how-do-i-cancel-my-subscription" === d &&
              (0, y.trackClientEvents)({ event: c.EAnalyticEvents.CANCEL_FLOW_HELP_CENTER_VIEWED }),
              ("contact-myiq-support" === d || "contact-myiq-support-mx" === d) &&
                (0, y.trackClientEvents)({ event: c.EAnalyticEvents.CANCEL_FLOW_CONTACT_SUPPORT_VIEWED }));
          }, [d]),
          (!L && f) || w)
            ? (0, t.jsxs)(t.Fragment, {
                children: [
                  k,
                  (0, t.jsx)("main", {
                    className: "flex flex-1 flex-col",
                    children: (0, t.jsx)(N.DemoStaticPageLayoutComponent, {
                      breadCrumbLabel: f?.title || "",
                      isProfile: m,
                      title: (u = f?.title || "").includes("<")
                        ? u
                        : u.replace(b, (e) => `<span class="whitespace-nowrap">${e}</span>`),
                      showBackToTop: !0,
                      showQuestionsCard: !1,
                      showToc: !1,
                      children: A
                        ? (0, t.jsx)(j, { article: A, isProfile: m, serverUser: g, userSubscriptionId: x })
                        : f?.sections?.map((e, l) =>
                            e?.blockType !== "textContent"
                              ? null
                              : (0, t.jsx)(
                                  "div",
                                  {
                                    children:
                                      e?.richDescription && e?.descriptionType === "richText"
                                        ? (0, t.jsx)(n.RichText, {
                                            linkAsButton:
                                              "how-do-i-cancel-my-subscription" === d
                                                ? [p.EClientRoutes.CANCELLATION]
                                                : [],
                                            linkAsButtonClassName:
                                              "w-full !rounded-full font-medium md:w-fit",
                                            linkAsButtonSize: "lg",
                                            buttonIcon: (0, t.jsx)(a.ArrowRight, {
                                              className: "h-[18px] w-[18px]",
                                            }),
                                            data: e?.richDescription,
                                            serverUser: g,
                                            userSubscriptionId: x,
                                            className: T.DEMO_STATIC_PAGE_PROSE_CLASS,
                                          })
                                        : (0, t.jsx)("p", {
                                            className: T.DEMO_STATIC_PAGE_PROSE_CLASS,
                                            children: e?.description,
                                          }),
                                  },
                                  l,
                                ),
                          ),
                    }),
                  }),
                  (0, t.jsx)(h.DemoFooterComponent, {}),
                ],
              })
            : (0, l.notFound)();
        },
      ],
      979303,
    );
  },
]);
