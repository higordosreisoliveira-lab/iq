(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  140962,
  171566,
  (_) => {
    "use strict";
    var e = _.i(271645);
    let t = (0, e.createContext)(!1);
    (_.s(
      ["RedesignSessionContext", 0, t, "useIsRedesignAuthenticated", 0, () => (0, e.useContext)(t)],
      171566,
    ),
      _.s([], 140962));
  },
  111353,
  (_) => {
    "use strict";
    var e = _.i(843476),
      t = _.i(271645);
    _.i(330021);
    var A = _.i(437460);
    _.i(566594);
    var a = _.i(102241);
    _.i(698219);
    var s = _.i(341302),
      i = _.i(134404),
      I = _.i(202042);
    _.i(140962);
    var E = _.i(171566);
    _.s([
      "default",
      0,
      (_) => {
        let { children: r, serverUserData: n, flagshipExperiments: o, isAuthenticated: R } = _,
          c = (0, I.usePathname)() === i.EClientRoutes.BASE ? "static" : "public";
        return (0, e.jsxs)("div", {
          className:
            "flex min-h-dvh w-full select-none flex-col bg-white [&_input]:select-text [&_textarea]:select-text",
          children: [
            (0, e.jsx)(E.RedesignSessionContext.Provider, {
              value: R,
              children: (0, e.jsx)(a.ErrorBoundary, { children: r }),
            }),
            (0, e.jsx)(t.Suspense, { fallback: null, children: (0, e.jsx)(s.SessionUtmComponent, {}) }),
            (0, e.jsx)(A.AnalyticTrackerComponent, { flagshipExperiments: o, serverUserData: n, scope: c }),
          ],
        });
      },
    ]);
  },
  331890,
  129466,
  (_) => {
    "use strict";
    var e = _.i(117595),
      t = _.i(948148),
      A = _.i(271645),
      a = _.i(266027),
      s = _.i(866897),
      i = _.i(134404);
    _.i(682770);
    var I = _.i(934952);
    _.i(531122);
    var E = _.i(81844);
    let r = async (_) => {
        try {
          let e = _ ? `${i.EApiRoutes.COUNTRY_DATA}/${_}` : i.EApiRoutes.COUNTRY_DATA,
            t = await E.httpInstance.get(e, { cache: "force-cache", next: { revalidate: 86400 } });
          return { data: (await t.json()).data, success: !0 };
        } catch {
          return { error: "error_smth_went_wrong", success: !1 };
        }
      },
      n = function (_) {
        let E = !(arguments.length > 1) || void 0 === arguments[1] || arguments[1],
          n = (0, t.useTranslations)(),
          o = _ || e.default.get(s.ECookieArg.COUNTRY),
          R = (0, a.useQuery)({
            queryKey: [i.EApiRoutes.COUNTRY_DATA, o || "auto"],
            queryFn: () => r(o),
            enabled: E,
          });
        return (
          (0, A.useEffect)(() => {
            R.data && !R.data.success && (0, I.customToast)(n("error_smth_went_wrong"), "error");
          }, [R.data, n]),
          R
        );
      };
    _.s(
      [
        "useGetCountryDataQuery",
        0,
        n,
        "useGetNeighborCountriesFromCountryData",
        0,
        function (_) {
          let e = !(arguments.length > 1) || void 0 === arguments[1] || arguments[1],
            { data: t, error: A, isLoading: a, refetch: s } = n(_, e);
          return {
            data: t?.data
              ? {
                  currentCountry: { code: t.data.currentCountry.code, names: t.data.currentCountry.names },
                  neighboringCountries: t.data.neighboringCountries,
                }
              : void 0,
            error: A,
            isLoading: a,
            refetch: s,
            success: t?.success,
          };
        },
      ],
      331890,
    );
    var o = _.i(60423),
      R = _.i(157273);
    _.s(
      [
        "getCountryDataFromLocalStorage",
        0,
        () => {
          let _ = o.accessLocalStorage.getItem(R.StorageKeys.COUNTRY_DATA);
          if (!_) return null;
          try {
            return JSON.parse(_);
          } catch {
            return null;
          }
        },
        "saveCountryDataToLocalStorage",
        0,
        (_) => {
          _ && o.accessLocalStorage.setItem(R.StorageKeys.COUNTRY_DATA, JSON.stringify(_));
        },
      ],
      129466,
    );
  },
  932880,
  (_) => {
    "use strict";
    var e,
      t,
      A = _.i(117595),
      a = _.i(618566),
      s = _.i(861745),
      i = _.i(271645),
      I = _.i(331890),
      E = _.i(59857),
      r = _.i(49587),
      n = _.i(866897),
      o = _.i(157273),
      R = _.i(86596),
      c = _.i(60423),
      l = _.i(129466),
      u = _.i(646162),
      T = _.i(302433),
      S = _.i(523173),
      M = _.i(134404),
      N = _.i(915113);
    _.i(756503);
    var O = _.i(846911);
    _.i(470366);
    var C = _.i(504001);
    _.i(569311);
    var L = _.i(896855),
      Y = _.i(202042),
      U =
        (((e = {}).FS_AB_MYIQ_START_PAGE_TEST = "fs_ab_myiq_start_page_test"),
        (e.AB_MYIQ_PAYWALL_BENEFITS_OPTIMIZATION = "ab_myiq_paywall_benefits_optimization"),
        (e.AB_MYIQ_SESSION_RECORDING = "ab_myiq_session_recording"),
        (e.AB_MYIQ_PROFILE_EVENTS = "ab_myiq_profile_events"),
        (e.AB_MYIQ_PRODUCT_ADD_QUIZ_AFTER_PAYWALL = "ab_myiq_product_add_quiz_after_paywall"),
        (e.AB_MYIQ_ADDED_PROFILE_EVENTS = "ab_myiq_added_profile_events"),
        (e.AB_MYIQ_FORMBRIKS_SURVEY_VARIANTS = "ab_myiq_formbricks_survey_variants"),
        (e.AB_MYIQ_QUIZ_COMPLETION_CTA_REMOVAL = "ab_myiq_quiz_completion_cta_removal"),
        (e.AB_MYIQ_PRINT_CERTIFICATE_UPSELL = "ab_myiq_print_certificate_upsell"),
        (e.AB_MYIQ_PRODUCT_FEEDBACK_WIDGET = "ab_myiq_product_feedback_widget"),
        (e.AB_MYIQ_TRIVIA_POPUP_UPSELL = "ab_myiq_trivia_popup_upsell"),
        (e.AB_MYIQ_REVOLUT_MONZO_BLOCK = "ab_myiq_revolut_monzo_block"),
        (e.AB_MYIQ_PROMO_PRICE = "ab_myiq_promo_price"),
        (e.AB_MYIQ_SPECIALIST_QUESTION_BEFORE_PAYWALL = "ab_myiq_specialist_question_before_paywall"),
        (e.AB_MYIQ_REFERRAL_EMAIL_PRODUCT = "ab_myiq_referral_email_product"),
        (e.AB_MYIQ_A_B_1_00_VS_1_99_1 = "ab_myiq_product_trial_1_00_vs_1_99"),
        (e.AB_MYIQ_PRODUCT_CANCEL_SUBS_DOWNGRADE_UPSELL_9_99 =
          "ab_myiq_product_cancel_subs_downgrade_upsell_9_99"),
        (e.AB_MYIQ_DESKTOP_PAYMENT_ABOVE_FOLD = "ab_myiq_desktop_payment_above_fold"),
        (e.AB_MYIQ_BRAZIL_MASTERCARD_ONLY = "ab_myiq_brazil_mastercard_only"),
        (e.AB_MYIQ_LOC_ITALIAN_PAYWALL = "ab_myiq_loc_italian_paywall"),
        (e.AB_MYIQ_LOC_ITALIAN_REPORT = "ab_myiq_loc_italian_report"),
        (e.AB_MYIQ_PAYWALL_LAYOUT = "ab_myiq_paywall_layout"),
        (e.AB_MYIQ_QUIZ_CHAOS_BLOCK_Q11_22 = "ab_myiq_quiz_chaos_block_q11_22"),
        (e.AB_MYIQ_REPORT_DELAYED_GENERATION = "ab_myiq_report_delayed_generation"),
        (e.AB_MYIQ_ANALYZING_AI_CHAT_MODAL = "ab_myiq_analyzing_ai_chat_modal"),
        (e.AB_MYIQ_ANALYZING_REPORT_OPTIN_QUESTION = "ab_myiq_analyzing_report_optin_question"),
        (e.AB_MYIQ_ANALYZING_NUMBER_RECALL_FOLLOWUP = "ab_myiq_analyzing_number_recall_followup"),
        (e.AB_MYIQ_QUIZ_TEXT_QS_CHAT_LAYOUT = "ab_myiq_quiz_text_qs_chat_layout"),
        (e.AB_MYIQ_START_PAGE_MEDIA_LOGOS = "ab_myiq_start_page_media_logos"),
        (e.AB_MYIQ_CANCELLATION_WHAT_YOU_LOSE = "ab_myiq_cancellation_what_you_lose"),
        (e.AB_MYIQ_POST_PAYMENT_PROCESSING_MODAL = "ab_myiq_post_payment_processing_modal"),
        (e.AB_MYIQ_QUIZ_OPENER_SWAP = "ab_myiq_quiz_opener_swap"),
        (e.AB_MYIQ_QUIZ_MIDRUN_SWAP = "ab_myiq_quiz_midrun_swap"),
        (e.AB_MYIQ_ANALYZING_LAST_STEPS_ORDER = "ab_myiq_analyzing_last_steps_order"),
        (e.AB_MYIQ_PAYWALL_FONT_OPTIMIZATION = "ab_myiq_paywall_font_optimization"),
        (e.AB_MYIQ_PAYWALL_BENEFITS_REDESIGN = "ab_myiq_paywall_benefits_redesign"),
        (e.AB_MYIQ_PAYWALL_SUMMARY_REDESIGN = "ab_myiq_paywall_summary_redesign"),
        (e.AB_MYIQ_QUIZ_HINT_ASSIST_COUNT = "ab_myiq_quiz_hint_assist_count"),
        (e.AB_MYIQ_SOCIAL_PILL_DESIGN = "ab_myiq_social_pill_design"),
        (e.AB_MYIQ_QUIZ_FEWER_OPTIONS = "ab_myiq_quiz_fewer_options"),
        (e.AB_MYIQ_QUIZ_PERCEPTION_QUESTIONS = "ab_myiq_quiz_perception_questions"),
        (e.AB_MYIQ_QUIZ_ALGEBRA_SHAPES_V2 = "ab_myiq_quiz_algebra_shapes_v2"),
        (e.AB_MYIQ_QUIZ_FLAG_TRIVIA = "ab_myiq_quiz_flag_trivia"),
        (e.AB_MYIQ_QUIZ_STROOP_COLOR_BLOCK = "ab_myiq_quiz_stroop_color_block"),
        (e.AB_MYIQ_QUIZ_MIRROR_WORDS = "ab_myiq_quiz_mirror_words"),
        (e.AB_MYIQ_QUIZ_COUNT_GRID_PLACEMENT = "ab_myiq_quiz_count_grid_placement"),
        (e.AB_MYIQ_QUIZ_ODD_ONE_OUT_MICROGAME = "ab_myiq_quiz_odd_one_out_microgame"),
        (e.AB_MYIQ_QUIZ_NUMBER_RECALL = "ab_myiq_quiz_number_recall"),
        (e.AB_MYIQ_QUIZ_MATHS_TRIVIA = "ab_myiq_quiz_maths_trivia"),
        (e.AB_MYIQ_QUIZ_OPTICAL_ILLUSION_NUMBERS = "ab_myiq_quiz_optical_illusion_numbers"),
        (e.AB_MYIQ_QUIZ_CLASSIC_ILLUSIONS_V2 = "ab_myiq_quiz_classic_illusions_v2"),
        (e.AB_MYIQ_QUIZ_VERBAL_ANALOGIES = "ab_myiq_quiz_verbal_analogies"),
        (e.AB_MYIQ_QUIZ_REACTION_TAP_GAME = "ab_myiq_quiz_reaction_tap_game"),
        (e.FS_AB_MYIQ_LOC_UKR_COPY = "ab_myiq_loc_ukr_copy"),
        (e.FS_AB_MYIQ_LOC_RUS_COPY = "ab_myiq_loc_rus_copy"),
        (e.FS_AB_MYIQ_LOC_SPA_COPY = "ab_myiq_loc_spa_copy"),
        (e.AB_MYIQ_LOCALIZATION_PORTUGUESE_PT = "ab_myiq_localization_portuguese_pt"),
        (e.AB_MYIQ_LOCALIZATION_BRAZILIAN_PORTUGUESE_PT_BR =
          "ab_myiq_localization_brazilian_portuguese_pt_br"),
        (e.AB_MYIQ_LOCALIZATION_FRENCH_FR = "ab_myiq_localization_french_fr"),
        (e.AB_MYIQ_BENEFIT_VERSION = "ab_myiq_benefit_version"),
        (e.AB_MYIQ_EMAIL_REMOVE_STATS_BLOCK = "ab_myiq_email_remove_stats_block"),
        (e.AB_MYIQ_EMAIL_SOCIAL_SIGNUP = "ab_myiq_email_social_signup"),
        (e.AB_NEW_MYIQ_START_HEADLINE_COPY = "ab_new_myiq_start_headline_copy"),
        (e.AB_NEW_MYIQ_START_PAGE_SOCIAL_PROOF_STATS = "ab_new_myiq_start_page_social_proof_stats"),
        (e.AB_NEW_MYIQ_START_PAGE_GENDER_STICKY_CTA = "ab_new_myiq_start_page_gender_sticky_cta"),
        (e.AB_MYIQ_NEW_HOMEPAGE_COMPACT_CAROUSEL = "ab_myiq_new_homepage_compact_carousel"),
        (e.AB_MYIQ_NEW_HOMEPAGE_CTA_COPY = "ab_myiq_new_homepage_cta_copy"),
        (e.AB_MYIQ_NEW_HOMEPAGE_START_SECTION = "ab_myiq_new_homepage_start_section"),
        e),
      P =
        (((t = {}).FT_MYIQ_PAYWALL = "ft_myiq_paywall"),
        (t.FT_MYIQ_FUNNEL = "ft_myiq_funnel"),
        (t.FT_MYIQ_REVIEWS = "ft_myiq_reviews"),
        (t.FT_MYIQ_REVIEW_PLATFORM_SPLIT = "ft_myiq_review_platform_split"),
        (t.FT_MYIQ_REPORT_NON_IMAGE_ANSWERS = "ft_myiq_report_non_image_answers"),
        (t.FT_COOKIE_BANNER = "ft_cookie_banner"),
        (t.FT_MEMORIZE_CONTINUE_ANALYTICS = "ft_memorize_continue_analytics"),
        (t.FT_MEMORIZE_CONTINUE_ANALYTICS_REDESIGN = "ft_memorize_continue_analytics_redesign"),
        (t.FT_MYIQ_REPORT_ONE_PAGE_V2 = "ft_myiq_report_one_page_v2"),
        (t.FT_MYIQ_ST_UPDATE = "ft_myiq_st_update"),
        t);
    let Q = [M.EClientRoutes.CANCELLATION, M.EClientRoutes.SIGN_IN, M.EClientRoutes.DELETE_ACCOUNT];
    (U.FS_AB_MYIQ_START_PAGE_TEST,
      U.AB_MYIQ_SESSION_RECORDING,
      U.AB_MYIQ_PROFILE_EVENTS,
      U.AB_MYIQ_QUIZ_COMPLETION_CTA_REMOVAL,
      U.AB_MYIQ_REVOLUT_MONZO_BLOCK,
      U.AB_MYIQ_LOC_ITALIAN_PAYWALL,
      U.AB_MYIQ_LOC_ITALIAN_REPORT,
      P.FT_MYIQ_PAYWALL,
      P.FT_MYIQ_FUNNEL,
      P.FT_MYIQ_REVIEWS,
      U.AB_MYIQ_SPECIALIST_QUESTION_BEFORE_PAYWALL,
      U.AB_MYIQ_REFERRAL_EMAIL_PRODUCT,
      U.AB_MYIQ_A_B_1_00_VS_1_99_1,
      U.AB_MYIQ_DESKTOP_PAYMENT_ABOVE_FOLD,
      U.AB_MYIQ_BRAZIL_MASTERCARD_ONLY,
      U.AB_MYIQ_START_PAGE_MEDIA_LOGOS,
      U.AB_MYIQ_PAYWALL_LAYOUT,
      U.AB_MYIQ_QUIZ_CHAOS_BLOCK_Q11_22,
      U.AB_MYIQ_REPORT_DELAYED_GENERATION,
      U.AB_MYIQ_ANALYZING_AI_CHAT_MODAL,
      U.AB_MYIQ_ANALYZING_REPORT_OPTIN_QUESTION,
      U.AB_MYIQ_QUIZ_TEXT_QS_CHAT_LAYOUT,
      U.AB_MYIQ_ANALYZING_NUMBER_RECALL_FOLLOWUP,
      U.AB_MYIQ_POST_PAYMENT_PROCESSING_MODAL,
      U.AB_MYIQ_QUIZ_OPENER_SWAP,
      U.AB_MYIQ_QUIZ_MIDRUN_SWAP,
      U.AB_MYIQ_ANALYZING_LAST_STEPS_ORDER,
      U.AB_MYIQ_PAYWALL_BENEFITS_OPTIMIZATION,
      U.AB_MYIQ_PAYWALL_FONT_OPTIMIZATION,
      U.AB_MYIQ_PAYWALL_BENEFITS_REDESIGN,
      U.AB_MYIQ_BENEFIT_VERSION,
      U.AB_MYIQ_PAYWALL_SUMMARY_REDESIGN,
      U.AB_MYIQ_ADDED_PROFILE_EVENTS,
      U.AB_MYIQ_FORMBRIKS_SURVEY_VARIANTS,
      U.AB_MYIQ_QUIZ_HINT_ASSIST_COUNT,
      U.AB_MYIQ_QUIZ_FEWER_OPTIONS,
      U.AB_MYIQ_QUIZ_PERCEPTION_QUESTIONS,
      U.AB_MYIQ_QUIZ_ALGEBRA_SHAPES_V2,
      U.AB_MYIQ_QUIZ_FLAG_TRIVIA,
      U.AB_MYIQ_QUIZ_STROOP_COLOR_BLOCK,
      U.AB_MYIQ_QUIZ_MIRROR_WORDS,
      U.AB_MYIQ_QUIZ_COUNT_GRID_PLACEMENT,
      U.AB_MYIQ_QUIZ_ODD_ONE_OUT_MICROGAME,
      U.AB_MYIQ_QUIZ_NUMBER_RECALL,
      U.AB_MYIQ_QUIZ_MATHS_TRIVIA,
      U.AB_MYIQ_QUIZ_OPTICAL_ILLUSION_NUMBERS,
      U.AB_MYIQ_QUIZ_CLASSIC_ILLUSIONS_V2,
      U.AB_MYIQ_QUIZ_VERBAL_ANALOGIES,
      U.AB_MYIQ_QUIZ_REACTION_TAP_GAME,
      U.FS_AB_MYIQ_LOC_UKR_COPY,
      U.FS_AB_MYIQ_LOC_RUS_COPY,
      U.FS_AB_MYIQ_LOC_SPA_COPY,
      U.AB_MYIQ_LOCALIZATION_PORTUGUESE_PT,
      U.AB_MYIQ_LOCALIZATION_BRAZILIAN_PORTUGUESE_PT_BR,
      U.AB_MYIQ_LOCALIZATION_FRENCH_FR,
      U.AB_MYIQ_EMAIL_REMOVE_STATS_BLOCK,
      U.AB_MYIQ_EMAIL_SOCIAL_SIGNUP,
      U.AB_NEW_MYIQ_START_HEADLINE_COPY,
      U.AB_NEW_MYIQ_START_PAGE_SOCIAL_PROOF_STATS,
      U.AB_NEW_MYIQ_START_PAGE_GENDER_STICKY_CTA,
      U.AB_MYIQ_NEW_HOMEPAGE_COMPACT_CAROUSEL,
      U.AB_MYIQ_NEW_HOMEPAGE_CTA_COPY,
      U.AB_MYIQ_NEW_HOMEPAGE_START_SECTION,
      P.FT_MYIQ_ST_UPDATE,
      _.s(
        [
          "default",
          0,
          (_) => {
            let { flagshipExperiments: e, serverUserData: t, scope: U = "public" } = _,
              P = (0, s.useLocale)(),
              g = (0, Y.usePathname)(),
              y = (0, a.useSearchParams)(),
              m = (0, i.useRef)(!1),
              B = (0, i.useRef)(!1),
              p = (0, i.useRef)(!1),
              d = (0, i.useRef)(!1),
              G = (0, i.useRef)(!1),
              D = (0, N.getIsMarketingSource)(),
              { user: b, handleChangeUserStore: f } = (0, R.useUserStore)(),
              [q, Z] = (0, i.useState)(() => R.useUserStore.persist?.hasHydrated() ?? !1);
            (0, i.useEffect)(() => R.useUserStore.persist.onFinishHydration(() => Z(!0)), []);
            let { data: v } = (0, I.useGetCountryDataQuery)(void 0, "public" === U && !b?.currency),
              K = b?.id || ("static" === U ? t.id : void 0),
              F = "static" === U ? !!K : !!b,
              W = "static" === U ? g === M.EClientRoutes.BASE : g !== M.EClientRoutes.BASE,
              V = async () => {
                let _ = navigator.language || navigator.languages?.[0] || "en";
                if (!F) return;
                let { ab_myiq_revolut_monzo_block: A, ab_myiq_paywall_layout: a, ...s } = e,
                  i = c.accessLocalStorage.getItem(o.StorageKeys.MARKETING_USER_ID);
                (g.includes(M.EClientRoutes.CANCELLATION) ||
                  g.includes(M.EClientRoutes.SIGN_IN) ||
                  (0, C.initPeopleAnalytic)(i || K || t.id || ""),
                  (0, C.setPeopleAnalyticOnce)({
                    app_version: "v2",
                    product_name: "myiq",
                    build_version: O.envServer.BUILD_VERSION || "unknown",
                    instance_region: O.envServer.INSTANCE_REGION || "non-set",
                    browser_language: _,
                    ...(("block" === A || "not_block" === A) && { ab_myiq_revolut_monzo_block: A }),
                    ...(D && { ab_myiq_paywall_layout: a }),
                    ...s,
                  }),
                  (0, C.setPeopleAnalytic)({
                    email_marketing: i ? "true" : "false",
                    Locale: P,
                    marketing_param: !!(0, N.getIsMarketingSource)(),
                    [T.REDESIGN_FUNNEL_PROPERTY]: (0, r.getIsRedesignFunnel)(),
                  }));
              };
            return (
              (0, i.useEffect)(() => {
                if (F) {
                  let _,
                    e = W
                      ? ((_) => {
                          switch (_) {
                            case M.EClientRoutes.BASE:
                              return S.EAnalyticEvents.MAIN_PAGE_VIEW;
                            case M.EClientRoutes.START:
                            case M.EClientRoutes.START_LOVE:
                            case M.EClientRoutes.START_PERSONALITY:
                            case M.EClientRoutes.START_CAREERS:
                            case M.EClientRoutes.START_ANXIETY:
                            case M.EClientRoutes.START_CONFIDENCE:
                            case M.EClientRoutes.START_STRENGTHS:
                            case M.EClientRoutes.START_ATTACHMENT:
                            case M.EClientRoutes.START_PSYCHOLOGICAL_ARCHETYPES:
                            case M.EClientRoutes.START_PROCRASTINATION:
                            case M.EClientRoutes.START_TIME_MANAGEMENT:
                            case M.EClientRoutes.START_ADHD:
                            case M.EClientRoutes.START_WORK:
                            case M.EClientRoutes.START_BURNOUT:
                            case M.EClientRoutes.START_EMOTIONAL:
                            case M.EClientRoutes.START_DEPRESSION:
                            case M.EClientRoutes.START_IMPOSTER_SYNDROME:
                            case M.EClientRoutes.START_ENNEAGRAM:
                              return S.EAnalyticEvents.FUNNEL_START_VIEW;
                            case M.EClientRoutes.CHECKOUT:
                            case M.EClientRoutes.EMAIL_VERIFICATION:
                            case M.EClientRoutes.CHECKOUT_LOVE:
                            case M.EClientRoutes.CHECKOUT_PERSONALITY:
                            case M.EClientRoutes.CHECKOUT_ENNEAGRAM:
                              return S.EAnalyticEvents.PAYWALL_VIEWED;
                            case M.EClientRoutes.CORRECT_EMAIL:
                              return S.EAnalyticEvents.VALIDATION_EMAIL_VIEWED;
                            case M.EClientRoutes.REPORT:
                              return S.EAnalyticEvents.REPORT_VIEWED;
                            case M.EClientRoutes.EMAIL:
                            case M.EClientRoutes.EMAIL_LOVE:
                            case M.EClientRoutes.EMAIL_PERSONALITY:
                            case M.EClientRoutes.EMAIL_ENNEAGRAM:
                              return S.EAnalyticEvents.EMAIL_VIEWED;
                            case M.EClientRoutes.QUIZ_ANALYZING:
                            case M.EClientRoutes.QUIZ_ANALYZING_LOVE:
                            case M.EClientRoutes.QUIZ_ANALYZING_PERSONALITY:
                            case M.EClientRoutes.QUIZ_ANALYZING_CAREERS:
                            case M.EClientRoutes.QUIZ_ANALYZING_ANXIETY:
                            case M.EClientRoutes.QUIZ_ANALYZING_CONFIDENCE:
                            case M.EClientRoutes.QUIZ_ANALYZING_STRENGTHS:
                            case M.EClientRoutes.QUIZ_ANALYZING_WORK:
                            case M.EClientRoutes.QUIZ_ANALYZING_BURNOUT:
                            case M.EClientRoutes.QUIZ_ANALYZING_EMOTIONAL:
                            case M.EClientRoutes.QUIZ_ANALYZING_DEPRESSION:
                            case M.EClientRoutes.QUIZ_ANALYZING_ADHD:
                            case M.EClientRoutes.QUIZ_ANALYZING_PROCRASTINATION:
                            case M.EClientRoutes.QUIZ_ANALYZING_TIME_MANAGEMENT:
                            case M.EClientRoutes.QUIZ_ANALYZING_IMPOSTER_SYNDROME:
                            case M.EClientRoutes.QUIZ_ANALYZING_PSYCHOLOGICAL_ARCHETYPES:
                            case M.EClientRoutes.QUIZ_ANALYZING_ATTACHMENT:
                            case M.EClientRoutes.QUIZ_ANALYZING_ENNEAGRAM:
                              return S.EAnalyticEvents.ANALYZING_VIEWED;
                          }
                          return null;
                        })(g)
                      : null;
                  (e !== S.EAnalyticEvents.PAYWALL_VIEWED && (d.current = !1),
                    e !== S.EAnalyticEvents.MAIN_PAGE_VIEW && (G.current = !1));
                  let t = (_ = b?.funnel || g).includes("love")
                      ? "love_language"
                      : _.includes("personality")
                        ? "personality"
                        : _.includes("enneagram")
                          ? "enneagram"
                          : "myiq",
                    a =
                      "true" === A.default.get(n.ECookieArg.BT_FUNNEL) && "myiq" === t && "en" === P
                        ? "myiq-bt"
                        : t,
                    s = (0, u.resolvePersonalityFunnel)(
                      a,
                      A.default.get(n.ECookieArg.PERSONALITY_FUNNEL_VARIANT),
                    ),
                    i =
                      g.includes(M.EClientRoutes.START) ||
                      g.includes(M.EClientRoutes.QUIZ) ||
                      g.includes(M.EClientRoutes.QUIZ_ANALYZING) ||
                      g.includes(M.EClientRoutes.EMAIL) ||
                      g.includes(M.EClientRoutes.CHECKOUT),
                    I = "true" === A.default.get(n.ECookieArg.PLAN_PICKER_FUNNEL),
                    r = "true" === A.default.get(n.ECookieArg.US_A1_CAMPAIGN),
                    R = "true" === A.default.get(n.ECookieArg.BR_CAMPAIGN),
                    l =
                      !!y.get("user_token") ||
                      (0, E.hasValidMarketingParams)({
                        cid: y.get("cid") ?? void 0,
                        i: y.get("i") ?? void 0,
                        t: y.get("t") ?? void 0,
                        email: y.get("email") ?? void 0,
                        ff: y.get("ff") ?? void 0,
                        r: y.get("r") ?? void 0,
                        funnel: y.get("funnel") ?? void 0,
                        quiz_answers: y.get("quiz_answers") ?? void 0,
                        rt: y.get("rt") ?? void 0,
                      }),
                    T = e === S.EAnalyticEvents.PAYWALL_VIEWED && (d.current || l || !b?.email),
                    O = e === S.EAnalyticEvents.MAIN_PAGE_VIEW && G.current;
                  if (m.current) {
                    let _, t;
                    if (
                      ((_ = Q.some((_) => g.includes(_))),
                      (t = c.accessLocalStorage.getItem(o.StorageKeys.MARKETING_USER_ID)),
                      !_ &&
                        !t &&
                        b?.id &&
                        L.mixpanelClient.peopleGetDistinctId() !== b.id &&
                        (0, C.initPeopleAnalytic)(b.id),
                      i && (0, C.setPeopleAnalytic)({ funnel: s }),
                      e)
                    )
                      switch (e) {
                        case S.EAnalyticEvents.PAYWALL_VIEWED:
                          if (T) break;
                          ((0, C.trackClientEvents)({
                            event: e,
                            sessionId: b?.id,
                            params: {
                              marketing_param: !!(0, N.getIsMarketingSource)(),
                              funnel: a,
                              paymentOrchestrator: "PayNext",
                              paynextSessionId: A.default.get(n.ECookieArg.PAYNEXT_SESSION),
                              ...(I && { plan_picker_funnel: !0 }),
                              ...(r && { us_a1_campaign: !0 }),
                              ...(R && { br_campaign: !0 }),
                            },
                          }),
                            (d.current = !0));
                          break;
                        case S.EAnalyticEvents.MAIN_PAGE_VIEW:
                          if (O) break;
                          ((0, C.trackClientEvents)({ event: e, sessionId: K, params: { funnel: a } }),
                            (G.current = !0));
                          break;
                        case S.EAnalyticEvents.EMAIL_VIEWED:
                          (0, C.trackClientEvents)({
                            event: e,
                            sessionId: K,
                            params: { marketing_param: !!(0, N.getIsMarketingSource)(), funnel: a },
                          });
                          break;
                        default:
                          (0, C.trackClientEvents)({ event: e, sessionId: K, params: { funnel: a } });
                      }
                  } else
                    ((m.current = !0),
                      e !== S.EAnalyticEvents.MAIN_PAGE_VIEW || O || (G.current = !0),
                      V().then(() => {
                        e &&
                          (T ||
                            O ||
                            (i && (0, C.setPeopleAnalytic)({ funnel: s }),
                            (0, C.trackClientEvents)({
                              event: e,
                              sessionId: K,
                              params: {
                                funnel: a,
                                ...(e === S.EAnalyticEvents.PAYWALL_VIEWED &&
                                  I && { plan_picker_funnel: !0 }),
                                ...(e === S.EAnalyticEvents.PAYWALL_VIEWED && r && { us_a1_campaign: !0 }),
                                ...(e === S.EAnalyticEvents.PAYWALL_VIEWED && R && { br_campaign: !0 }),
                              },
                            }),
                            e === S.EAnalyticEvents.PAYWALL_VIEWED && (d.current = !0)));
                      }));
                }
              }, [g, b?.id, b?.email, y]),
              (0, i.useEffect)(() => {
                q &&
                  v?.success &&
                  !B.current &&
                  ((B.current = !0),
                  (() => {
                    if (!v?.success || !v?.data?.currentCountry?.currency || p.current) return;
                    p.current = !0;
                    let _ = v.data.currentCountry.currency,
                      e = {
                        countryCode: _?.country_2code || "US",
                        currencyCode: _?.currency_code || "USD",
                        currencyForPay: _?.currency_card || "USD",
                        currencyCard: _?.currency_card || "USD",
                        currencyPaypal: ((_) => {
                          let { paypalCurrency: e, currencyCode: t } = _;
                          switch (t) {
                            case "AUD":
                            case "CAD":
                            case "GBP":
                            case "EUR":
                              return t;
                            default:
                              return e || "USD";
                          }
                        })({
                          paypalCurrency: _?.currency_paypal || "USD",
                          currencyCode: _?.currency_code || "USD",
                        }),
                        currencyWallet: _?.currency_wallet || "USD",
                        currencySymbol: _?.currency_symbol || "$",
                        symbolAtStart: _?.symbol_at_start ?? "TRUE",
                        usdExchangeRate: _?.usd_exchange_rate || 1,
                        eurExchangeRate: _?.eur_exchange_rate || 1,
                      };
                    f({
                      user: {
                        id: A.default.get(n.ECookieArg.SESSION_ID) || t.id,
                        currency: e,
                        locale: P,
                        ip: t.ip,
                        user_agent: t.user_agent,
                        operating_system: t.operating_system,
                      },
                    });
                  })());
              }, [q, v?.success]),
              (0, i.useEffect)(() => {
                v?.success && v?.data && (0, l.saveCountryDataToLocalStorage)(v?.data);
              }, [v]),
              null
            );
          },
        ],
        932880,
      ));
  },
  437460,
  698219,
  341302,
  (_) => {
    "use strict";
    var e = _.i(932880);
    _.s(["AnalyticTrackerComponent", () => e.default], 437460);
    var t = _.i(618566),
      A = _.i(271645),
      a = _.i(202042),
      s = _.i(157273),
      i = _.i(562942),
      I = _.i(190899),
      E = _.i(866897),
      r = _.i(429067),
      n = _.i(86596),
      o = _.i(924254);
    _.i(569311);
    var R = _.i(896855);
    (_.s([], 698219),
      _.s(
        [
          "SessionUtmComponent",
          0,
          () => {
            let _,
              e,
              c,
              l = (0, t.useSearchParams)(),
              u = (0, A.useRef)(!1),
              T = (0, n.useUserStore)((_) => _.user),
              S = (0, n.useUserStore)((_) => _.handleChangeUserStore);
            ((_ = (0, t.useSearchParams)()),
              (e = (0, a.usePathname)()),
              (c = _.get(i.UTM_PARAMS.MYIQ_PARAM_ID)),
              (0, A.useEffect)(() => {
                c &&
                  c === i.UTM_PARAMS.ID &&
                  (I.accessSessionStorageUtil.getItem(s.StorageKeys.MARKETING_ID) ||
                    I.accessSessionStorageUtil.setItem(s.StorageKeys.MARKETING_ID, c));
              }, [e, c]),
              I.accessSessionStorageUtil.getItem(s.StorageKeys.MARKETING_ID));
            let M = () =>
              (l.get(i.UTM_PARAMS.MYIQ_PREVENT_PARAM_GOOGLE) ||
                l.get(i.UTM_PARAMS.MYIQ_PREVENT_PARAM_GOOGLE.toUpperCase())) ===
              i.UTM_PARAMS.MYIQ_PREVENT_PARAM_GOOGLE_VALUE;
            l.get(i.UTM_PARAMS.MYIQ_PARAM) || l.get(i.UTM_PARAMS.MYIQ_PARAM.toUpperCase());
            let N =
                l.get(i.UTM_PARAMS.MYIQ_PARAM_GOOGLE) || l.get(i.UTM_PARAMS.MYIQ_PARAM_GOOGLE.toUpperCase()),
              O =
                l.get(i.UTM_PARAMS.MYIQ_PARAM_TIKTOK) || l.get(i.UTM_PARAMS.MYIQ_PARAM_TIKTOK.toUpperCase()),
              C =
                l.get(i.UTM_PARAMS.MYIQ_PARAM_APPLOVIN) ||
                l.get(i.UTM_PARAMS.MYIQ_PARAM_APPLOVIN.toUpperCase()),
              L =
                l.get(i.UTM_PARAMS.MYIQ_BRAIN_TRAINING) ||
                l.get(i.UTM_PARAMS.MYIQ_BRAIN_TRAINING.toUpperCase());
            (l.get(i.UTM_PARAMS.MYIQ_UTM_REFERRAL_DOMAIN),
              l.get(i.UTM_PARAMS.MYIQ_UTM_SOURCE),
              l.get(i.UTM_PARAMS.MYIQ_UTM_MEDIUM),
              l.get(i.UTM_PARAMS.MYIQ_UTM_CAMPAIGN),
              l.get(i.UTM_PARAMS.MYIQ_UTM_CAMPAIGN_ID),
              l.get(i.UTM_PARAMS.MYIQ_UTM_ADGROUP_ID) || l.get(i.UTM_PARAMS.MYIQ_UTM_ADSET_ID),
              l.get(i.UTM_PARAMS.MYIQ_UTM_AD_ID));
            let Y = l.get(i.UTM_PARAMS.MYIQ_UTM_SOURCE_ID);
            return (
              l.get(i.UTM_PARAMS.INITIAL_CURRENT_URL),
              l.get(i.UTM_PARAMS.MYIQ_UTM_USER_TOKEN),
              (0, A.useEffect)(() => {
                (0, r.getIsNativeApp)() &&
                  I.accessSessionStorageUtil.setItem(s.StorageKeys.MARKETING_SOURCE, "true");
                let _ = !!Y;
                if (
                  (_ &&
                    (_
                      ? (N &&
                          (I.accessSessionStorageUtil.setItem(s.StorageKeys.GOOGLE_PARAM, "true"),
                          I.accessSessionStorageUtil.removeItem(s.StorageKeys.TIKTOK_PARAM)),
                        O &&
                          (I.accessSessionStorageUtil.setItem(s.StorageKeys.TIKTOK_PARAM, "true"),
                          I.accessSessionStorageUtil.removeItem(s.StorageKeys.GOOGLE_PARAM)),
                        M() &&
                          (I.accessSessionStorageUtil.setItem(s.StorageKeys.GOOGLE_PARAM, "true"),
                          I.accessSessionStorageUtil.removeItem(s.StorageKeys.TIKTOK_PARAM)),
                        I.accessSessionStorageUtil.setItem(s.StorageKeys.MARKETING_SOURCE, "true"))
                      : I.accessSessionStorageUtil.removeItem(s.StorageKeys.MARKETING_SOURCE)),
                  "1" === Y &&
                    I.accessSessionStorageUtil.setItem(s.StorageKeys.PERSONALITY_MARKETING_SOURCE, "true"),
                  M())
                )
                  return I.accessSessionStorageUtil.removeItem(s.StorageKeys.MARKETING_SOURCE);
                let e = R.mixpanelClient.peopleGetProperty("initial_utm_source"),
                  t = R.mixpanelClient.peopleGetProperty("initial_utm_medium"),
                  A = R.mixpanelClient.peopleGetProperty("initial_utm_campaign"),
                  a = R.mixpanelClient.peopleGetProperty("user_token");
                (C && I.accessSessionStorageUtil.setItem(s.StorageKeys.APPLOVIN_PARAM, "true"),
                  L && o.accessCookie.setItem(E.ECookieArg.BRAIN_TRAINING_PARAM, "true"),
                  (e || t || A || a) &&
                    I.accessSessionStorageUtil.setItem(s.StorageKeys.MARKETING_SOURCE, "true"));
              }, []),
              (0, A.useEffect)(() => {
                let _ = !!Y;
                _ &&
                  T &&
                  !T?.isMarketingUser &&
                  !u.current &&
                  ((u.current = !0), S({ user: { isMarketingUser: !!_ } }));
              }, [T?.id, T?.isMarketingUser]),
              null
            );
          },
        ],
        341302,
      ));
  },
  330021,
  (_) => {
    "use strict";
    (_.i(932880), _.i(389634), _.s([]));
  },
  389634,
  (_) => {
    "use strict";
    var e = _.i(271645);
    _.i(470366);
    var t = _.i(504001);
    _.s([
      "default",
      0,
      (_) => {
        let { user: A, event: a, params: s } = _;
        return (
          (0, e.useEffect)(() => {
            A && (0, t.trackClientEvents)({ event: a, user: A, params: { ...s } });
          }, []),
          null
        );
      },
    ]);
  },
  59857,
  (_) => {
    "use strict";
    _.s([
      "hasValidMarketingParams",
      0,
      (_) =>
        !!_ &&
        ["cid", "i", "t", "email", "ff", "r", "funnel", "quiz_answers", "rt"].some((e) => {
          let t = _[e];
          return t && "" !== t.toString().trim();
        }),
    ]);
  },
  49587,
  302433,
  (_) => {
    "use strict";
    var e = _.i(117595),
      t = _.i(866897),
      A = _.i(134404);
    let a = [
        A.EClientRoutes.QUIZ,
        A.EClientRoutes.QUIZ_ANALYZING,
        A.EClientRoutes.EMAIL,
        A.EClientRoutes.CHECKOUT,
      ],
      s = (_) => "true" !== _;
    (_.s(
      [
        "REDESIGN_FUNNEL_PROPERTY",
        0,
        "redesign_funnel",
        "isRedesignFunnelPage",
        0,
        (_) => a.includes(_),
        "isRedesignFunnelRequest",
        0,
        s,
      ],
      302433,
    ),
      _.s(["getIsRedesignFunnel", 0, () => s(e.default.get(t.ECookieArg.LEGACY_FUNNEL))], 49587));
  },
  190899,
  (_) => {
    "use strict";
    _.s([
      "accessSessionStorageUtil",
      0,
      {
        getItem: (_) => {
          try {
            return sessionStorage.getItem(_);
          } catch {
            return null;
          }
        },
        setItem: (_, e) => {
          try {
            sessionStorage.setItem(_, e);
          } catch {
            return;
          }
        },
        removeItem: (_) => {
          try {
            sessionStorage.removeItem(_);
          } catch {
            return;
          }
        },
      },
    ]);
  },
  915113,
  (_) => {
    "use strict";
    var e = _.i(117595),
      t = _.i(190899),
      A = _.i(866897),
      a = _.i(157273);
    let s = new Set([
      "DE",
      "RO",
      "IT",
      "CZ",
      "PL",
      "NL",
      "HU",
      "BE",
      "BG",
      "CH",
      "PT",
      "MT",
      "AT",
      "SE",
      "LT",
      "IS",
      "LU",
      "HR",
      "LV",
      "EE",
      "SK",
      "GR",
      "AE",
      "SA",
    ]);
    _.s([
      "getIsMarketingSource",
      0,
      () => {
        if ("DE" === (e.default.get(A.ECookieArg.COUNTRY) || "US")) return "";
        let _ = t.accessSessionStorageUtil.getItem(a.StorageKeys.MARKETING_ID),
          s = t.accessSessionStorageUtil.getItem(a.StorageKeys.MARKETING_SOURCE);
        return _ || s || "";
      },
      "getIsMarketingSourceForSpecificCountry",
      0,
      () => {
        let _ = e.default.get(A.ECookieArg.COUNTRY) || "US";
        if (!s.has(_)) return "";
        let i = t.accessSessionStorageUtil.getItem(a.StorageKeys.MARKETING_ID),
          I = t.accessSessionStorageUtil.getItem(a.StorageKeys.MARKETING_SOURCE);
        return i || I || "";
      },
      "getIsPersonalityMarketingSource",
      0,
      () => !!t.accessSessionStorageUtil.getItem(a.StorageKeys.PERSONALITY_MARKETING_SOURCE),
    ]);
  },
]);
