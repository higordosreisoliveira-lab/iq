(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  882983,
  (e) => {
    "use strict";
    var t = e.i(265840),
      a = e.i(271645),
      r = e.i(273830),
      n = e.i(620253),
      i = e.i(75540),
      s = e.i(843476),
      o = (0, r.forwardRef)((e, r) => {
        let { as: o, children: l, className: u, ...d } = e,
          { slots: c, classNames: m, bodyId: p, setBodyMounted: h } = (0, t.useModalContext)(),
          g = (0, n.useDOMRef)(r);
        return (
          (0, a.useEffect)(() => (h(!0), () => h(!1)), [h]),
          (0, s.jsx)(o || "div", {
            ref: g,
            className: c.body({ class: (0, i.clsx)(null == m ? void 0 : m.body, u) }),
            id: p,
            ...d,
            children: l,
          })
        );
      });
    ((o.displayName = "HeroUI.ModalBody"), e.s(["ModalBody", 0, o], 882983));
  },
  985272,
  (e) => {
    "use strict";
    let t;
    var a = Object.defineProperty,
      r = (e, t, r) => {
        let n;
        return (n = "symbol" != typeof t ? t + "" : t) in e
          ? a(e, n, { enumerable: !0, configurable: !0, writable: !0, value: r })
          : (e[n] = r);
      };
    let n = null,
      i = null;
    class s extends Error {
      constructor(e, t = !0, a = !1) {
        const n =
          a && "u" > typeof window
            ? (function () {
                let e = navigator.connection || navigator.mozConnection || navigator.webkitConnection,
                  t = {
                    online: navigator.onLine,
                    documentHidden: document.hidden,
                    userAgent: navigator.userAgent,
                    timestamp: new Date().toISOString(),
                  };
                return (
                  e &&
                    ((t.connectionType = e.type),
                    (t.effectiveType = e.effectiveType),
                    (t.downlink = e.downlink),
                    (t.rtt = e.rtt),
                    (t.saveData = e.saveData)),
                  navigator.onLine
                    ? document.hidden
                      ? (t.likelyCause = "background_tab")
                      : e?.effectiveType === "slow-2g" || e?.effectiveType === "2g"
                        ? (t.likelyCause = "slow_connection")
                        : e?.downlink !== void 0 && e.downlink < 0.5 && (t.likelyCause = "poor_bandwidth")
                    : (t.likelyCause = "offline"),
                  t
                );
              })()
            : null;
        (super(
          n
            ? `${e} [${(function (e) {
                let t = [];
                return (
                  e.likelyCause && t.push(`cause=${e.likelyCause}`),
                  t.push(`online=${e.online}`),
                  t.push(`hidden=${e.documentHidden}`),
                  e.effectiveType && t.push(`net=${e.effectiveType}`),
                  void 0 !== e.downlink && t.push(`downlink=${e.downlink}Mbps`),
                  void 0 !== e.rtt && t.push(`rtt=${e.rtt}ms`),
                  t.join(", ")
                );
              })(n)}]`
            : e,
        ),
          r(this, "retryable"),
          r(this, "diagnostics"),
          (this.retryable = t),
          (this.name = "SDKLoadError"),
          (this.diagnostics = n));
      }
    }
    let o = "PayNextSDK";
    function l() {
      return typeof window > "u" ? null : window[o];
    }
    function u(e) {
      return new Promise((t) => setTimeout(t, e));
    }
    async function d() {
      let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 5e3,
        t = Math.ceil(e / 50);
      for (let e = 0; e < t; e++) {
        let e = l();
        if (e) return e;
        await u(50);
      }
      throw new s("PayNextSDK not found in window after waiting", !0, !0);
    }
    async function c(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
        a = e?.toLowerCase(),
        r =
          (a?.includes("develop") || a?.includes("staging") || a?.includes("preview")
            ? "develop"
            : "production") == "develop"
            ? "https://cdn-sdk-dev.paynext.com/index.cdn.js"
            : "https://cdn-sdk.paynext.com/index.cdn.js";
      try {
        return (
          l() ||
          (await new Promise((e, t) => {
            let a = document.querySelector(`script[src="${r}"]`);
            if (a) {
              if (l()) return void e();
              let r = setTimeout(() => {
                  (a.removeEventListener("load", n),
                    a.removeEventListener("error", i),
                    t(new s("Existing SDK script loading timeout", !0, !0)));
                }, 15e3),
                n = () => {
                  (clearTimeout(r), a.removeEventListener("load", n), a.removeEventListener("error", i), e());
                },
                i = () => {
                  (clearTimeout(r),
                    a.removeEventListener("load", n),
                    a.removeEventListener("error", i),
                    t(new s("Existing SDK script failed to load", !0, !0)));
                };
              return (a.addEventListener("load", n), void a.addEventListener("error", i));
            }
            let n = setTimeout(() => {
                (o(), t(new s("SDK script loading timeout", !0, !0)));
              }, 15e3),
              i = document.createElement("script");
            ((i.src = r),
              (i.crossOrigin = "anonymous"),
              (i.async = !0),
              i.setAttribute("data-paynext-sdk", "true"));
            let o = () => {
              (clearTimeout(n), (i.onload = null), (i.onerror = null));
            };
            ((i.onload = () => {
              (o(), e());
            }),
              (i.onerror = (e) => {
                (console.error("[PayNext CDN] Script load error:", e), o());
                try {
                  i.parentNode && i.parentNode.removeChild(i);
                } catch (e) {
                  console.warn("[PayNext CDN] Failed to remove script:", e);
                }
                t(new s("Failed to load SDK script from CDN", !0, !0));
              }));
            try {
              document.head.appendChild(i);
            } catch {
              (o(), t(new s("Failed to append script to document", !1)));
            }
          }),
          await d(5e3))
        );
      } catch (a) {
        if ((!(a instanceof s) || a.retryable) && t < 5)
          return (
            console.warn(`[PayNext CDN] Load attempt ${t} failed, retrying in 1500ms...`, a),
            await u(1500 * t),
            c(e, t + 1)
          );
        throw (console.error(`[PayNext CDN] Failed to load SDK after ${t} attempts:`, a), a);
      }
    }
    async function m(e) {
      if (i) return i;
      if (n) return n;
      if (typeof window > "u") throw new s("PayNext SDK can only be loaded in browser environment", !1);
      let t = l();
      return t
        ? (i = t)
        : (n = (async () => {
            try {
              let t = await c(e);
              return ((i = t), typeof window > "u" || (window[o] = t), t);
            } catch (e) {
              throw ((n = null), e);
            }
          })());
    }
    class p {
      constructor() {
        (r(this, "cdnInstance", null),
          r(this, "initPromise", null),
          r(this, "isDestroyed", !1),
          r(this, "errorBoundary", null));
      }
      setErrorHandler(e) {
        this.errorBoundary = e;
      }
      handleError(e, t) {
        if ((console.error(`[PayNext SDK Error - ${t}]: ${e.message}`, e), this.errorBoundary))
          try {
            this.errorBoundary(e);
          } catch (e) {
            console.error("[PayNext SDK] Error in custom error handler:", e);
          }
      }
      async initialize(e) {
        if (this.isDestroyed) throw new s("Cannot initialize destroyed SDK instance", !1);
        return (
          this.initPromise ||
            (this.initPromise = (async () => {
              try {
                let t = await m(e);
                if (!t || !t.PayNextCheckout)
                  throw new s("PayNextCheckout not found in loaded SDK module", !1);
                try {
                  this.cdnInstance = new t.PayNextCheckout();
                } catch (e) {
                  throw new s(
                    `Failed to instantiate PayNextCheckout: ${e instanceof Error ? e.message : "Unknown error"}`,
                    !1,
                  );
                }
              } catch (e) {
                throw ((this.initPromise = null), e);
              }
            })()),
          this.initPromise
        );
      }
      assertReady() {
        if (this.isDestroyed) throw new s("SDK instance has been destroyed", !1);
        if (!this.initPromise) throw new s("SDK initialization not started", !1);
        if (!this.cdnInstance) throw new s("SDK instance not created", !1);
      }
      async mount(e, t) {
        try {
          if (!e || "string" != typeof e) throw new s("Invalid containerId provided", !1);
          if (!t || !t.environment) throw new s("Invalid config provided", !1);
          if (!document.getElementById(e)) throw new s(`Container element with id "${e}" not found`, !1);
          (await this.initialize(t.environment), this.assertReady(), await this.cdnInstance.mount(e, t));
        } catch (t) {
          let e = t instanceof s ? t : new s(t instanceof Error ? t.message : "Unknown mount error", !0);
          throw (this.handleError(e, "mount"), e);
        }
      }
      update(e) {
        try {
          if (this.isDestroyed) return void console.warn("[PayNext SDK] update called on destroyed instance");
          if (!this.cdnInstance) return void console.warn("[PayNext SDK] update called before mount");
          "function" == typeof this.cdnInstance.update
            ? this.cdnInstance.update(e)
            : console.warn(
                "[PayNext SDK] update() is not supported by the loaded CDN bundle; a newer SDK version is required",
              );
        } catch (t) {
          let e = t instanceof Error ? t : Error(String(t));
          this.handleError(e, "update");
        }
      }
      setPaymentsEnabled(e) {
        try {
          if (this.isDestroyed)
            return void console.warn("[PayNext SDK] setPaymentsEnabled called on destroyed instance");
          if (!this.cdnInstance)
            return void console.warn("[PayNext SDK] setPaymentsEnabled called before mount");
          "function" == typeof this.cdnInstance.setPaymentsEnabled && this.cdnInstance.setPaymentsEnabled(e);
        } catch (t) {
          let e = t instanceof Error ? t : Error(String(t));
          this.handleError(e, "setPaymentsEnabled");
        }
      }
      async unmount() {
        try {
          if (this.isDestroyed) return void console.warn("[PayNext SDK] Instance already destroyed");
          if (!this.cdnInstance) return void console.warn("[PayNext SDK] No instance to unmount");
          try {
            "function" == typeof this.cdnInstance.unmount && (await this.cdnInstance.unmount());
          } catch (t) {
            let e = t instanceof Error ? t : Error(String(t));
            this.handleError(e, "unmount");
          }
          ((this.cdnInstance = null), (this.initPromise = null));
        } catch (t) {
          let e = t instanceof Error ? t : Error(String(t));
          this.handleError(e, "unmount");
        }
      }
      static async preload(e) {
        try {
          await m(e);
        } catch (e) {
          throw (console.error("[PayNext SDK] Preload failed:", e), e);
        }
      }
    }
    p.preload;
    var h =
      (((t = h || {}).PAYPAL = "PAYPAL"),
      (t.APPLE_PAY = "APPLEPAY"),
      (t.GOOGLE_PAY = "GPAY"),
      (t.CARD = "CARD"),
      (t.VENMO = "VENMO"),
      (t.CASHAPP = "CASHAPP"),
      (t.AMAZONPAY = "AMAZONPAY"),
      (t.PIX_AUTOMATICO = "PIX_AUTOMATICO"),
      (t.UPI = "UPI"),
      (t.BLIK = "BLIK"),
      t);
    e.s(["PayNextCheckout", 0, p, "PaymentMethod", 0, h]);
  },
  563921,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("arrow-right", [
      ["path", { d: "M5 12h14", key: "1ays0h" }],
      ["path", { d: "m12 5 7 7-7 7", key: "xquz4c" }],
    ]);
    e.s(["default", 0, t]);
  },
  972520,
  (e) => {
    "use strict";
    var t = e.i(563921);
    e.s(["ArrowRight", () => t.default]);
  },
  956677,
  (e) => {
    "use strict";
    var t = e.i(954616),
      a = e.i(134404);
    e.i(531122);
    var r = e.i(81844);
    let n = async (e) => {
        let t = await r.apiInstance.post(a.EServerRoutes.CUSTOMER_IO_EVENTS, {
          json: e,
          throwHttpErrors: !1,
        });
        return await t.json();
      },
      i = async (e) => {
        let t = await r.apiInstance.post(a.EServerRoutes.CUSTOMER_IO_IDENTIFY, {
          json: {
            ...e,
            attributes: { ...e.attributes, timezone: Intl.DateTimeFormat().resolvedOptions().timeZone },
          },
          throwHttpErrors: !1,
        });
        return await t.json();
      };
    e.s(
      [
        "useCustomerIoIdentifyMutation",
        0,
        () => {
          let e = (0, t.useMutation)({ mutationFn: i });
          return { ...e, trigger: e.mutateAsync };
        },
        "useCustomerIoSendEventMutation",
        0,
        () => {
          let e = (0, t.useMutation)({ mutationFn: n });
          return { ...e, trigger: e.mutateAsync };
        },
      ],
      956677,
    );
  },
  678296,
  118522,
  (e) => {
    "use strict";
    var t = e.i(954616),
      a = e.i(134404);
    e.i(682770);
    var r = e.i(934952);
    e.i(531122);
    var n = e.i(81844);
    let i = async (e) => {
      let t = await n.apiInstance.patch(`${a.EApiRoutes.PAYNEXT_CUSTOMER}`, { json: e, throwHttpErrors: !1 });
      return await t.json();
    };
    e.s(
      [
        "usePaynextCustomerUpdateMutation",
        0,
        () => {
          let e = (0, t.useMutation)({
            mutationKey: [a.EApiRoutes.PAYNEXT_CUSTOMER],
            mutationFn: (e) => i(e),
            onSuccess(e) {
              (!e.success || e?.error) &&
                (0, r.customToast)(e?.error || "Failed to update customer email", "error");
            },
          });
          return { ...e, trigger: e.mutateAsync };
        },
      ],
      678296,
    );
    var s = e.i(912598),
      o = e.i(86596);
    let l = async (e) => {
      let t = await n.apiInstance.get(
        `${a.EServerRoutes.AUTH_USER}?email=${encodeURIComponent(e.email)}&validationMode=${e.checkInDB}`,
        { throwHttpErrors: !1, timeout: 5e3 },
      );
      if (!t.ok) throw Error(`Failed to fetch validation: ${t.statusText}`);
      let r = await t.json();
      if (!r.status) throw Error("Invalid response structure. Missing status.");
      return r;
    };
    e.s(
      [
        "useEmailValidation",
        0,
        () => {
          let { handleChangeUserStore: e, user: n } = (0, o.useUserStore)(),
            i = (0, s.useQueryClient)(),
            u = (0, t.useMutation)({
              mutationFn: l,
              onSuccess(t) {
                (t.error && (0, r.customToast)(t?.error || "Email validation error", "error"),
                  t.success &&
                    n &&
                    (e({ user: { ...n, email_validation_status: t.status } }),
                    i.setQueryData([a.EApiRoutes.AUTH_USER, n.email], {
                      success: !0,
                      data: { ...n, email_validation_status: t.status },
                    })));
              },
            });
          return { ...u, trigger: u.mutateAsync };
        },
      ],
      118522,
    );
  },
  532262,
  (e) => {
    "use strict";
    var t = e.i(797982);
    e.s(["LangComponent", () => t.default]);
  },
  317197,
  231529,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(882983),
      r = e.i(742214),
      n = e.i(663615);
    e.i(680460);
    var i = e.i(885944);
    (e.s([], 317197),
      e.s(
        [
          "ModalBodyComponent",
          0,
          (e) => {
            let {
              children: s,
              title: o,
              subtitle: l,
              className: u = "",
              bodyClassName: d,
              titleClassName: c,
            } = e;
            return (0, t.jsx)(r.ModalContent, {
              className: u,
              children: (0, t.jsxs)(a.ModalBody, {
                className: (0, n.cn)(
                  "flex h-full w-full flex-col gap-5 p-5 antialiased md:p-6 [@media(max-height:580px)]:gap-3 [@media(max-height:580px)]:p-4",
                  d,
                ),
                children: [
                  (o || l) &&
                    (0, t.jsx)(i.ModalHeaderComponent, { title: o, subtitle: l, titleClassName: c }),
                  s,
                ],
              }),
            });
          },
        ],
        231529,
      ));
  },
  695996,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(861745),
      r = e.i(948148),
      n = e.i(271645),
      i = e.i(985272),
      s = e.i(712470),
      o = e.i(956677),
      l = e.i(954616),
      u = e.i(134404);
    e.i(531122);
    var d = e.i(81844);
    let c = "sign_in_page_email_error_attempts",
      m = async (e) => {
        let t = await d.apiInstance.post(`${u.EApiRoutes.EMAIL_CHANGE_REQUEST}`, {
          json: e,
          throwHttpErrors: !1,
        });
        return 429 === t.status ? { success: !1, error: c } : await t.json();
      },
      p = async (e) => {
        let t = await d.apiInstance.post(`${u.EApiRoutes.EMAIL_CHANGE_CONFIRM}`, {
          json: e,
          throwHttpErrors: !1,
        });
        return 429 === t.status ? { success: !1, error: c } : await t.json();
      };
    var h = e.i(574723),
      g = e.i(523173),
      y = e.i(622963),
      _ = e.i(678296),
      f = e.i(382963),
      v = e.i(118522),
      E = e.i(86596),
      x = e.i(386847),
      w = e.i(725397);
    e.i(470366);
    var C = e.i(504001),
      b = e.i(202042);
    e.i(682770);
    var I = e.i(934952);
    let S = "text-lg text-gray-900 sm:text-lg",
      N = ["username", "email"];
    e.i(568267);
    var A = e.i(154692);
    let P = (e) => {
        let {
            autoComplete: a,
            dir: r,
            errorMessage: n,
            helperText: i,
            id: s,
            inputMode: o = "text",
            inputRef: l,
            isDisabled: u = !1,
            isRequired: d = !1,
            label: c,
            maxLength: m,
            name: p,
            onChange: h,
            placeholder: g,
            value: y,
          } = e,
          _ = `${s}-message`,
          f = `${s}-helper`,
          v = [n && _, i && f].filter(Boolean).join(" ");
        return (0, t.jsxs)("div", {
          className: "flex w-full min-w-0 flex-col gap-1",
          children: [
            (0, t.jsxs)("div", {
              className: "relative",
              children: [
                (0, t.jsx)("input", {
                  "aria-describedby": v || void 0,
                  "aria-invalid": !!n,
                  "aria-required": d,
                  autoCapitalize: "none",
                  autoComplete: a,
                  className:
                    "peer h-14 w-full rounded-xl border border-gray-200 bg-white px-4 text-rd-body text-gray-900 outline-none transition-colors placeholder:text-transparent hover:border-gray-300 focus:border-primary disabled:cursor-not-allowed disabled:border-gray-200 disabled:bg-gray-50 disabled:text-gray-400 aria-[invalid=true]:border-danger rtl:text-right",
                  dir: r,
                  disabled: u,
                  id: s,
                  inputMode: o,
                  maxLength: m,
                  name: p,
                  onChange: (e) => {
                    h(e.target.value);
                  },
                  placeholder: g || " ",
                  ref: l,
                  type: "text",
                  value: y,
                }),
                (0, t.jsx)("label", {
                  className:
                    "pointer-events-none absolute start-4 top-1/2 max-w-[calc(100%-2rem)] -translate-y-1/2 truncate bg-white px-1 text-rd-body text-gray-500 transition-all peer-focus:top-0 peer-focus:text-rd-caption peer-focus:text-gray-500 peer-[:not(:placeholder-shown)]:top-0 peer-[:not(:placeholder-shown)]:text-rd-caption peer-disabled:bg-gray-50",
                  htmlFor: s,
                  children: d ? `${c} *` : c,
                }),
              ],
            }),
            n &&
              (0, t.jsx)("p", {
                className: "px-4 text-start text-rd-caption text-danger",
                id: _,
                children: n,
              }),
            i &&
              (0, t.jsx)("p", {
                className: "px-4 text-start text-rd-caption text-gray-500",
                id: f,
                children: i,
              }),
          ],
        });
      },
      T = (e) => {
        let {
            codeError: a,
            codeValue: n,
            isConfirming: i = !1,
            maskedEmail: s,
            onCancel: o,
            onChangeCode: l,
            onConfirm: u,
            onResend: d,
            resendState: c,
            resendTimeText: m,
          } = e,
          p = (0, r.useTranslations)(),
          h = n.length >= 6;
        return (0, t.jsxs)("form", {
          className: "flex flex-col gap-4",
          noValidate: !0,
          onSubmit: (e) => {
            (e.preventDefault(), h && !i && u());
          },
          children: [
            (0, t.jsx)("p", {
              className: "text-start text-rd-body-sm text-gray-600",
              children: p("profile_email_change_sent", { email: s }),
            }),
            (0, t.jsx)(P, {
              autoComplete: "one-time-code",
              errorMessage: a,
              id: "settings-code",
              inputMode: "numeric",
              isDisabled: i,
              label: p("otp_confirmation_code_label"),
              maxLength: 6,
              name: "code",
              onChange: l,
              value: n,
            }),
            (0, t.jsx)(A.ButtonComponent, {
              type: "submit",
              size: "sm",
              className: "h-14 max-w-full",
              isDisabled: !h || i,
              text: p("btn_confirm"),
              fullWidth: !0,
              isLoading: i,
            }),
            (0, t.jsx)(A.ButtonComponent, {
              type: "button",
              size: "sm",
              variant: "bordered",
              className: "h-14 w-full min-w-full border-green-custom bg-transparent text-green-custom",
              isDisabled: i,
              text: p("btn_cancel"),
              fullWidth: !0,
              onClick: o,
            }),
            "waiting" === c &&
              (0, t.jsx)("p", {
                "aria-live": "polite",
                className: "text-center text-rd-body-sm tabular-nums text-gray-500",
                children: p("otp_confirmation_request_new_code_in", { time: m }),
              }),
            "ready" === c &&
              (0, t.jsxs)("div", {
                "aria-live": "polite",
                className: "flex flex-col items-center gap-1 text-center",
                children: [
                  (0, t.jsx)("p", {
                    className: "text-rd-body-sm text-gray-500",
                    children: p("otp_confirmation_check_spam_tip"),
                  }),
                  (0, t.jsx)("button", {
                    className:
                      "text-rd-body-sm font-semibold text-green-custom disabled:cursor-not-allowed disabled:opacity-disabled",
                    disabled: i,
                    onClick: d,
                    type: "button",
                    children: p("otp_confirmation_request_new_code"),
                  }),
                ],
              }),
          ],
        });
      };
    e.i(203068);
    var M = e.i(532262);
    let D = (e) => {
      let { userEmail: a } = e;
      return (0, t.jsx)(M.LangComponent, {
        userEmail: a,
        placement: "bottom",
        theme: "light",
        triggerScaleOnOpen: !1,
        matchTriggerWidth: !0,
        className:
          "!h-14 !w-full !min-w-0 !rounded-xl !border-gray-200 bg-white !px-4 !text-gray-900 [&>span]:gap-2 [&>span]:text-rd-body data-[hover=true]:!border-gray-300 data-[hover=true]:!opacity-100 data-[focus-visible=true]:!border-primary data-[focus-visible=true]:outline-none",
        arrowClassName: "!text-gray-500",
        triggerIcon: (0, t.jsxs)("svg", {
          "aria-hidden": !0,
          className: "h-5 w-5 shrink-0 text-gray-500",
          fill: "none",
          stroke: "currentColor",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: 1.5,
          viewBox: "0 0 24 24",
          children: [
            (0, t.jsx)("circle", { cx: "12", cy: "12", r: "10" }),
            (0, t.jsx)("path", { d: "M2 12h20" }),
            (0, t.jsx)("path", {
              d: "M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10Z",
            }),
          ],
        }),
      });
    };
    var L = e.i(972520),
      R = e.i(630936),
      j = e.i(360067);
    let k = {
        ...{ same_email: "profile_email_change_same", email_exists: "validation_error_email_already" },
        [c]: "sign_in_page_email_error_attempts",
      },
      O = (e, t) =>
        t.trim()
          ? "username" === e
            ? j.namePattern.value.test(t)
              ? void 0
              : "error_name_format"
            : j.emailPattern.value.test(t)
              ? void 0
              : "error_email_format"
          : "error_required_field",
      K = (e, t) => e.username !== t && e.username.trim().length > 0,
      U = (e) => (e && k[e]) || "validation_error_email_incorrect",
      $ = (e) => {
        let a,
          {
            emailServerErrorKey: i,
            emailServerErrorToken: s,
            initialValues: o,
            isNameReadOnly: l,
            isSaving: u = !1,
            nameChanges: d,
            onEmailFieldEdited: c,
            onManageSubscription: m,
            onSubmit: p,
            showManageSubscription: h,
            userEmail: g,
          } = e,
          y = (0, r.useTranslations)(),
          [_, f] = (0, n.useState)(o),
          [v, E] = (0, n.useState)({}),
          [x, w] = (0, n.useState)(!1),
          C = (0, n.useRef)(null),
          b = (0, n.useRef)(null),
          I =
            (a = d) >= 2
              ? "profile_page_name_change_limit"
              : 1 === a
                ? "profile_page_name_change_one"
                : void 0,
          S = _.username !== o.username || _.email !== o.email || _.gender !== o.gender,
          T = v.email || i;
        (0, n.useEffect)(() => {
          i && b.current?.focus();
        }, [i, s]);
        let M = (e) => (t) => {
          let a = (0, j.sanitizeNameInput)(t);
          (f((t) => ({ ...t, [e]: a })),
            (x || v[e]) && E((t) => ({ ...t, [e]: O(e, a) })),
            "email" === e && c?.());
        };
        return (0, t.jsxs)("div", {
          className: "flex flex-col gap-4",
          children: [
            (0, t.jsx)(D, { userEmail: g }),
            (0, t.jsxs)("form", {
              className: "flex flex-col gap-4",
              noValidate: !0,
              onSubmit: (e) => {
                let t, a, r;
                if ((e.preventDefault(), !S || u)) return;
                let n =
                    ((t = {}),
                    (a = l ? void 0 : O("username", _.username)),
                    (r = O("email", _.email)),
                    a && (t.username = a),
                    r && (t.email = r),
                    t),
                  i = N.find((e) => !!n[e]);
                if ((E(n), w(!0), i)) {
                  let e;
                  return void ((e = "username" === i ? C.current : b.current), e?.focus());
                }
                p(_);
              },
              children: [
                (0, t.jsx)(P, {
                  autoComplete: "name",
                  errorMessage: v.username && y(v.username),
                  helperText: I && y(I),
                  id: "settings-username",
                  inputRef: C,
                  isDisabled: u || l,
                  isRequired: !0,
                  label: y("profile_page_name_modal_input"),
                  maxLength: 25,
                  name: "username",
                  onChange: M("username"),
                  placeholder: y("profile_page_name_modal_input_placeholder"),
                  value: _.username,
                }),
                (0, t.jsx)(P, {
                  autoComplete: "email",
                  dir: "ltr",
                  errorMessage: T && y(T),
                  id: "settings-email",
                  inputMode: "email",
                  inputRef: b,
                  isDisabled: u,
                  label: y("sign_in_page_email_input_title"),
                  name: "email",
                  onChange: M("email"),
                  placeholder: y("sign_in_page_email_input_placeholder"),
                  value: _.email,
                }),
                (0, t.jsx)(A.ButtonComponent, {
                  type: "submit",
                  size: "sm",
                  className: "h-14 max-w-full",
                  isDisabled: !S || u,
                  text: y("profile_update"),
                  fullWidth: !0,
                  isLoading: u,
                }),
                h &&
                  (0, t.jsxs)("button", {
                    type: "button",
                    onClick: m,
                    className:
                      "flex w-full items-center justify-center gap-1.5 text-center text-rd-body font-semibold text-green-custom transition-opacity active:opacity-disabled",
                    children: [
                      y("manage_subscription"),
                      (0, t.jsx)(L.ArrowRight, {
                        className: "size-4 flex-none",
                        strokeWidth: R.ICON_STROKE_WIDTH,
                        "aria-hidden": !0,
                      }),
                    ],
                  }),
              ],
            }),
          ],
        });
      };
    e.i(317197);
    var F = e.i(231529);
    (e.s([], 770172),
      e.i(770172),
      e.s(
        [
          "ProfileSettingsModalComponent",
          0,
          (e) => {
            let d,
              N,
              { user: A, country: P } = e,
              M = (0, r.useTranslations)(),
              D = (0, a.useLocale)(),
              L =
                A?.paymentInfo?.paymentMethodType !== i.PaymentMethod.PAYPAL &&
                !(0, w.isUsUk)(P, (0, x.getClientCity)());
            (0, h.useRequireUsername)(!0);
            let R = (0, b.useRouter)(),
              { data: j } = (0, f.useGetProfileQuery)(A?.email || ""),
              { handleChangeModalStore: O } = (0, y.useModalStore)(),
              B = j?.data?.user_info ? j?.data?.user_info : A,
              H = B?.email || A?.email || "",
              { trigger: z } = (0, f.useUpdateUserInDatabaseMutation)(),
              { trigger: G } = (0, v.useEmailValidation)(),
              { trigger: Y } = {
                ...(d = (0, l.useMutation)({
                  mutationKey: [u.EApiRoutes.EMAIL_CHANGE_REQUEST],
                  mutationFn: m,
                })),
                trigger: d.mutateAsync,
              },
              { trigger: V } = {
                ...(N = (0, l.useMutation)({
                  mutationKey: [u.EApiRoutes.EMAIL_CHANGE_CONFIRM],
                  mutationFn: p,
                })),
                trigger: N.mutateAsync,
              },
              { trigger: q } = (0, _.usePaynextCustomerUpdateMutation)(),
              { trigger: Z } = (0, o.useCustomerIoIdentifyMutation)(),
              { trigger: W } = (0, s.useCreateSessionMutation)(),
              [Q, X] = (0, n.useState)(B?.nameChanges || 0),
              [J, ee] = (0, n.useState)(!1),
              [et, ea] = (0, n.useState)(),
              [er, en] = (0, n.useState)(0),
              [ei, es] = (0, n.useState)("form"),
              [eo, el] = (0, n.useState)(""),
              [eu, ed] = (0, n.useState)(""),
              [ec, em] = (0, n.useState)(""),
              [ep, eh] = (0, n.useState)(),
              [eg, ey] = (0, n.useState)(!1),
              [e_, ef] = (0, n.useState)(0),
              [ev, eE] = (0, n.useState)(!1),
              { handleChangeUserStore: ex } = (0, E.useUserStore)(),
              ew = {
                username: A?.username || B?.username || "",
                email: B?.email || "",
                gender: B?.gender || "male",
              },
              eC = () => {
                (ef(60), eE(!0));
              };
            (0, n.useEffect)(() => {
              if (!ev || e_ <= 0) return;
              let e = setInterval(() => {
                ef((e) => (e <= 1 ? (eE(!1), 0) : e - 1));
              }, 1e3);
              return () => clearInterval(e);
            }, [ev, e_]);
            let eb = (e) => {
                (ea(e), en((e) => e + 1));
              },
              eI = async (e) => {
                (ee(!0), ea(void 0));
                try {
                  let t,
                    a = {},
                    r = ((t = B?.email || ""), e.email !== t);
                  if (
                    (K(e, ew.username) && ((a.nameChanges = Q + 1), (a.username = e.username)),
                    B.gender !== e.gender && (a.gender = e.gender),
                    Object.keys(a).length &&
                      (a.username || (a.username = B?.username),
                      await z({ email: H, userInfo: a }),
                      ex({ user: { email: H, username: e.username } }),
                      a?.nameChanges && X(a.nameChanges)),
                    r)
                  ) {
                    let t = e.email.toLowerCase().trim();
                    try {
                      let e = await G({ email: t, checkInDB: !0 });
                      if (e?.status === "exist") return void eb("validation_error_email_already");
                      if (e?.status !== "valid" && e?.status !== "development")
                        return void eb("validation_error_email_incorrect");
                      let a = await Y({ email: t, locale: D });
                      if (
                        ((0, C.trackClientEvents)({
                          event: g.EAnalyticEvents.PROFILE_SETTINGS_EMAIL_CHANGE_REQUESTED,
                          user: A,
                          params: {
                            email: t,
                            status: a.success ? "success" : "error",
                            error_code: a.error || "",
                          },
                        }),
                        !a.success)
                      )
                        return void eb(U(a.error));
                      (el(t),
                        ed(a.data?.maskedEmail || t),
                        em(""),
                        eh(void 0),
                        eC(),
                        es("code"),
                        (0, C.trackClientEvents)({
                          event: g.EAnalyticEvents.PROFILE_SETTINGS_EMAIL_VERIFICATION_VIEWED,
                          user: A,
                          params: { email: t },
                        }));
                    } catch {
                      eb("validation_error_email_incorrect");
                    }
                    return;
                  }
                  if (Object.keys(a).length) {
                    let t = [];
                    (K(e, ew.username) && t.push("name"), B.gender !== e.gender && t.push("gender"));
                    let a =
                      t.length > 1
                        ? M("profile_page_update_profile_success")
                        : "name" === t[0]
                          ? M("profile_page_update_name_success")
                          : "gender" === t[0]
                            ? M("profile_page_update_gender_success")
                            : M("profile_page_update_success");
                    ((0, I.customToast)(a, "success"), window.location.reload());
                  }
                } finally {
                  ee(!1);
                }
              },
              eS = async () => {
                if (!eg) {
                  (eh(void 0), ey(!0));
                  try {
                    let e = await V({ confirm_code: ec });
                    if (!e.success) {
                      let t;
                      ((0, C.trackClientEvents)({
                        event: g.EAnalyticEvents.PROFILE_SETTINGS_EMAIL_CODE_SUBMIT_CLICKED,
                        user: A,
                        params: { email: eo, status: "error", error_code: e.error || "" },
                      }),
                        eh((t = e.error) === c ? k[t] : "profile_email_change_code_invalid"),
                        ey(!1));
                      return;
                    }
                    let t = await q({ email: eo, currentEmail: H });
                    if (!t.success) {
                      ((0, C.trackClientEvents)({
                        event: g.EAnalyticEvents.PROFILE_SETTINGS_EMAIL_CODE_SUBMIT_CLICKED,
                        user: A,
                        params: { email: eo, status: "error", error_code: t.error || "swap_failed" },
                      }),
                        eh("validation_error_email_already"),
                        ey(!1));
                      return;
                    }
                    (0, C.trackClientEvents)({
                      event: g.EAnalyticEvents.PROFILE_SETTINGS_EMAIL_CODE_SUBMIT_CLICKED,
                      user: A,
                      params: { email: eo, status: "success" },
                    });
                    let a = B?.id || A?.id;
                    (a &&
                      ((0, C.initPeopleAnalytic)(a),
                      (0, C.setPeopleAnalytic)({ $email: eo, old_email: H, new_email: eo }),
                      await Z({ userId: a, email: eo, attributes: { old_email: H, new_email: eo } })),
                      await z({ email: eo, userInfo: { email: eo, username: B?.username } }),
                      ex({ user: { email: eo, username: B?.username } }),
                      await W({ id: B?.id, email: eo, subscriptionId: B?.subscriptionId }),
                      (0, I.customToast)(M("profile_page_update_email_success"), "success"),
                      window.location.reload());
                  } catch {
                    (eh("profile_email_change_code_invalid"), ey(!1));
                  }
                }
              },
              eN = async () => {
                if (ev || !eo) return;
                let e = await Y({ email: eo, locale: D });
                ((0, C.trackClientEvents)({
                  event: g.EAnalyticEvents.PROFILE_SETTINGS_EMAIL_RESEND_CODE_CLICKED,
                  user: A,
                  params: { email: eo, status: e.success ? "success" : "error", error_code: e.error || "" },
                }),
                  e.success ? (eh(void 0), eC()) : eh(U(e.error)));
              };
            if ("code" === ei)
              return (0, t.jsxs)(F.ModalBodyComponent, {
                bodyClassName: "gap-6 p-5 md:p-5",
                children: [
                  (0, t.jsx)("h2", {
                    className: `${S} text-start font-bold`,
                    children: M("profile_page_settings"),
                  }),
                  (0, t.jsx)(T, {
                    codeError: ep && M(ep),
                    codeValue: ec,
                    isConfirming: eg,
                    maskedEmail: eu,
                    onCancel: () => {
                      ((0, C.trackClientEvents)({
                        event: g.EAnalyticEvents.PROFILE_SETTINGS_EMAIL_EDIT_CLICKED,
                        user: A,
                        params: { email: eo },
                      }),
                        ea(void 0),
                        es("form"),
                        em(""),
                        eh(void 0));
                    },
                    onChangeCode: (e) => {
                      (em(e.trim()), eh(void 0));
                    },
                    onConfirm: eS,
                    onResend: eN,
                    resendState: ev ? "waiting" : "ready",
                    resendTimeText: `${Math.floor(e_ / 60)}:${(e_ % 60).toString().padStart(2, "0")}`,
                  }),
                ],
              });
            return (0, t.jsxs)(F.ModalBodyComponent, {
              bodyClassName: "gap-6 p-5 md:p-5",
              children: [
                (0, t.jsx)("h2", {
                  className: `${S} text-start font-bold`,
                  children: M("profile_page_settings"),
                }),
                (0, t.jsx)($, {
                  emailServerErrorKey: et,
                  emailServerErrorToken: er,
                  initialValues: ew,
                  isNameReadOnly: Q >= 2,
                  isSaving: J,
                  nameChanges: Q,
                  onEmailFieldEdited: () => ea(void 0),
                  onManageSubscription: () => {
                    ((0, C.trackClientEvents)({
                      event: g.EAnalyticEvents.PROFILE_SETTINGS_MANAGE_SUBS_CLICKED,
                      user: A,
                    }),
                      O({ isModalVisible: !1, modalComponent: null }),
                      R.push(u.EClientRoutes.CANCELLATION));
                  },
                  onSubmit: eI,
                  showManageSubscription: L,
                  userEmail: A?.email || "",
                }),
              ],
            });
          },
        ],
        695996,
      ));
  },
  463572,
  function (e) {
    e.n(e.i(695996));
  },
  630936,
  (e) => {
    "use strict";
    e.s(["ICON_STROKE_WIDTH", 0, 1.8]);
  },
  574723,
  (e) => {
    "use strict";
    var t = e.i(271645),
      a = e.i(622963),
      r = e.i(86596),
      n = e.i(202042),
      i = e.i(134404);
    e.s([
      "useRequireUsername",
      0,
      function () {
        let e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
          s = (0, n.useRouter)(),
          o = (0, n.usePathname)(),
          l = (0, r.useUserStore)((e) => e.user),
          u = l?.username,
          d = (0, a.useModalStore)((e) => e.handleChangeModalStore);
        return (
          (0, t.useEffect)(() => {
            void 0 !== u &&
              (u ||
                e ||
                o === i.EClientRoutes.REPORT ||
                o === i.EClientRoutes.CERTIFICATE ||
                d({
                  isModalVisible: !0,
                  modalComponent: "enter-name-certificate",
                  modalProps: { user: l, isClosable: !1 },
                }));
          }, [u, s, l, e]),
          { hasUsername: !!u, isLoading: void 0 === u, userName: u }
        );
      },
    ]);
  },
  386847,
  (e) => {
    "use strict";
    var t = e.i(117595),
      a = e.i(866897);
    e.s([
      "getClientCity",
      0,
      () => t.default.get(a.ECookieArg.CITY),
      "getClientCountry",
      0,
      () => t.default.get(a.ECookieArg.COUNTRY),
    ]);
  },
  360067,
  (e) => {
    "use strict";
    let t = { value: /^[\p{L}\p{M}\s'][\p{L}\p{M}\s'-]*$/u, message: "error_name_format" },
      a = (e) => e.replace(/[\u200E\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g, "");
    e.s([
      "NAME_MAX_LENGTH",
      0,
      35,
      "emailPattern",
      0,
      {
        value:
          /^(?=.{1,311}$)([a-zA-Z0-9_](?:[a-zA-Z0-9_.+-]*(?:\.[a-zA-Z0-9_.+-]+)*[a-zA-Z0-9_])?@[a-zA-Z0-9]+(?:[.-][a-zA-Z0-9]+)*\.[a-zA-Z]{2,})$/,
        message: "error_email_format",
      },
      "getRequiredMessage",
      0,
      (e) => e("error_required_field"),
      "maxLengthPattern",
      0,
      (e, t) => ({ value: RegExp(`^.{2,${e}}$`), message: t("error_max_characters", { count: `${e}` }) }),
      "minLength2Pattern",
      0,
      { value: /^.{2,}$/, message: "error_min_2_characters" },
      "namePattern",
      0,
      t,
      "sanitizeNameInput",
      0,
      a,
      "validateName",
      0,
      (e, r) => {
        let n = a(e);
        return n && n.trim().length > 0 && !t.value.test(n)
          ? r("error_name_format")
          : n.length > 35
            ? r("error_max_characters", { count: "35" })
            : null;
      },
    ]);
  },
]);
