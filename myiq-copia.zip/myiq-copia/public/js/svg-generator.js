// High-Fidelity SVG Graphic Generator for Raven's Progressive Matrices IQ Test

function getQuestionSVG(id) {
  const seed = (id * 137 + 42) % 360;
  const isOdd = id % 2 === 1;
  
  // Matrix cells 0 to 7 (8 cells) + cell 8 is ?
  const cells = [];
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 3; c++) {
      const idx = r * 3 + c;
      if (idx === 8) {
        cells.push(`<g transform="translate(${c * 90 + 10}, ${r * 90 + 10})">
          <rect width="80" height="80" rx="8" fill="#F0F6FE" stroke="#006FEE" stroke-width="2" stroke-dasharray="4,4"/>
          <text x="40" y="50" font-family="Inter, sans-serif" font-size="28" font-weight="bold" fill="#006FEE" text-anchor="middle">?</text>
        </g>`);
      } else {
        const rotation = (r * 90 + c * 45 + seed) % 360;
        const scale = 0.6 + (r + c) * 0.08;
        const innerShape = renderCellGraphic(id, r, c, idx, rotation, scale);
        cells.push(`<g transform="translate(${c * 90 + 10}, ${r * 90 + 10})">
          <rect width="80" height="80" rx="8" fill="#FFFFFF" stroke="#E2E8F0" stroke-width="1.5"/>
          <g transform="translate(40,40)">
            ${innerShape}
          </g>
        </g>`);
      }
    }
  }

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 280 280" width="100%" height="100%">
    <rect width="280" height="280" rx="16" fill="#F8FAFC" stroke="#E2E8F0" stroke-width="1.5"/>
    ${cells.join('\n')}
  </svg>`;
}

function getOptionSVG(qId, optionLetter) {
  const letters = ["A", "B", "C", "D", "E", "F"];
  const optIdx = letters.indexOf(optionLetter.toUpperCase());
  const q = window?.MYIQ_QUESTIONS?.[qId - 1] || { correctAnswer: "D" };
  const isCorrect = optionLetter.toUpperCase() === q.correctAnswer;
  
  // Deterministic variation based on option index
  const seed = (qId * 137 + 42) % 360;
  let rotation, scale;
  
  if (isCorrect) {
    // Correct solution for row 2, col 2 (idx 8)
    rotation = (2 * 90 + 2 * 45 + seed) % 360;
    scale = 0.6 + (2 + 2) * 0.08;
  } else {
    // Distractor variations
    rotation = (seed + optIdx * 60 + 30) % 360;
    scale = 0.5 + (optIdx % 3) * 0.15;
  }

  const innerShape = renderCellGraphic(qId, 2, 2, isCorrect ? 8 : optIdx + 10, rotation, scale);

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100%" height="100%">
    <g transform="translate(50,50)">
      ${innerShape}
    </g>
  </svg>`;
}

function renderCellGraphic(qId, r, c, idx, rotation, scale) {
  const type = qId % 7;
  
  switch(type) {
    case 0: // Rotating geometric cross & dots
      return `
        <g transform="rotate(${rotation}) scale(${scale})">
          <circle cx="0" cy="0" r="24" fill="none" stroke="#2C3345" stroke-width="2.5"/>
          <line x1="-24" y1="0" x2="24" y2="0" stroke="#2C3345" stroke-width="2.5"/>
          <line x1="0" y1="-24" x2="0" y2="24" stroke="#2C3345" stroke-width="2.5"/>
          <circle cx="12" cy="-12" r="4" fill="#006FEE"/>
          ${idx % 2 === 1 ? '<circle cx="-12" cy="12" r="4" fill="#00B67A"/>' : ''}
        </g>
      `;

    case 1: // Polygon vertex progressions (Triangle -> Square -> Pentagon -> Hexagon)
      const sides = 3 + ((r + c) % 4);
      const points = [];
      const radius = 22 * scale;
      for (let i = 0; i < sides; i++) {
        const angle = (i * 2 * Math.PI / sides) - (Math.PI / 2);
        points.push(`${Math.cos(angle) * radius},${Math.sin(angle) * radius}`);
      }
      return `
        <g transform="rotate(${rotation})">
          <polygon points="${points.join(' ')}" fill="#EFF6FF" stroke="#006FEE" stroke-width="2.5"/>
          <circle cx="0" cy="0" r="${4 * scale}" fill="#2C3345"/>
        </g>
      `;

    case 2: // Concentric segments / quadrants
      const filledQuadrants = (r + c + 1) % 4;
      return `
        <g transform="rotate(${rotation}) scale(${scale})">
          <circle cx="0" cy="0" r="24" fill="none" stroke="#2C3345" stroke-width="2"/>
          <path d="M 0 0 L 24 0 A 24 24 0 0 1 0 24 Z" fill="${filledQuadrants >= 1 ? '#00B67A' : 'none'}" stroke="#2C3345" stroke-width="1.5"/>
          <path d="M 0 0 L 0 24 A 24 24 0 0 1 -24 0 Z" fill="${filledQuadrants >= 2 ? '#006FEE' : 'none'}" stroke="#2C3345" stroke-width="1.5"/>
          <path d="M 0 0 L -24 0 A 24 24 0 0 1 0 -24 Z" fill="${filledQuadrants >= 3 ? '#F59E0B' : 'none'}" stroke="#2C3345" stroke-width="1.5"/>
          <path d="M 0 0 L 0 -24 A 24 24 0 0 1 24 0 Z" fill="${filledQuadrants >= 4 ? '#8B5CF6' : 'none'}" stroke="#2C3345" stroke-width="1.5"/>
        </g>
      `;

    case 3: // Matrix line superposition & Boolean XOR
      return `
        <g transform="rotate(${rotation}) scale(${scale})">
          <rect x="-22" y="-22" width="44" height="44" rx="4" fill="none" stroke="#2C3345" stroke-width="2"/>
          ${r >= 0 ? '<line x1="-22" y1="0" x2="22" y2="0" stroke="#006FEE" stroke-width="2.5"/>' : ''}
          ${c >= 0 ? '<line x1="0" y1="-22" x2="0" y2="22" stroke="#006FEE" stroke-width="2.5"/>' : ''}
          ${(r + c) % 2 === 0 ? '<line x1="-22" y1="-22" x2="22" y2="22" stroke="#00B67A" stroke-width="2"/>' : '<line x1="22" y1="-22" x2="-22" y2="22" stroke="#00B67A" stroke-width="2"/>'}
        </g>
      `;

    case 4: // Sudoku shape logic (Circle, Square, Diamond permutation)
      const shapeKind = (r + c) % 3;
      if (shapeKind === 0) {
        return `
          <g transform="rotate(${rotation}) scale(${scale})">
            <circle cx="0" cy="0" r="20" fill="#EFF6FF" stroke="#006FEE" stroke-width="2.5"/>
            <circle cx="0" cy="0" r="6" fill="#006FEE"/>
          </g>
        `;
      } else if (shapeKind === 1) {
        return `
          <g transform="rotate(${rotation}) scale(${scale})">
            <rect x="-18" y="-18" width="36" height="36" rx="3" fill="#F0FDF4" stroke="#00B67A" stroke-width="2.5"/>
            <rect x="-5" y="-5" width="10" height="10" fill="#00B67A"/>
          </g>
        `;
      } else {
        return `
          <g transform="rotate(${rotation}) scale(${scale})">
            <rect x="-16" y="-16" width="32" height="32" rx="2" transform="rotate(45)" fill="#FEF3C7" stroke="#F59E0B" stroke-width="2.5"/>
            <circle cx="0" cy="0" r="5" fill="#F59E0B"/>
          </g>
        `;
      }

    case 5: // Arrow matrix directional flow
      const arrowLen = 22 * scale;
      return `
        <g transform="rotate(${rotation})">
          <line x1="-${arrowLen}" y1="0" x2="${arrowLen}" y2="0" stroke="#2C3345" stroke-width="3" stroke-linecap="round"/>
          <polyline points="${arrowLen - 8},-6 ${arrowLen},0 ${arrowLen - 8},6" fill="none" stroke="#2C3345" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
          <circle cx="-${arrowLen / 2}" cy="0" r="3.5" fill="#006FEE"/>
          <circle cx="${arrowLen / 2}" cy="0" r="3.5" fill="#00B67A"/>
        </g>
      `;

    default: // Multi-layer orbital dots
      const numDots = (r + c + 1);
      const dots = [];
      for (let i = 0; i < numDots; i++) {
        const dotAng = (i * 2 * Math.PI / numDots) + (rotation * Math.PI / 180);
        const dx = Math.cos(dotAng) * 16 * scale;
        const dy = Math.sin(dotAng) * 16 * scale;
        dots.push(`<circle cx="${dx}" cy="${dy}" r="4" fill="#006FEE"/>`);
      }
      return `
        <g>
          <circle cx="0" cy="0" r="${18 * scale}" fill="none" stroke="#E2E8F0" stroke-width="1.5" stroke-dasharray="3,3"/>
          <circle cx="0" cy="0" r="5" fill="#2C3345"/>
          ${dots.join('\n')}
        </g>
      `;
  }
}

if (typeof module !== 'undefined') {
  module.exports = { getQuestionSVG, getOptionSVG, renderCellGraphic };
} else {
  window.getQuestionSVG = getQuestionSVG;
  window.getOptionSVG = getOptionSVG;
}
