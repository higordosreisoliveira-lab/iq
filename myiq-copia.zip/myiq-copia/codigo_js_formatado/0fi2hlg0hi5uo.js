(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  875143,
  (e) => {
    "use strict";
    var i = e.i(843476),
      a = e.i(861745),
      t = e.i(948148),
      s = e.i(266027);
    e.i(382838);
    var n = e.i(342800),
      r = e.i(353527),
      o = e.i(95301);
    e.i(867107);
    var c = e.i(1693),
      d = e.i(86596);
    e.i(267493);
    var u = e.i(605663);
    e.i(853754);
    var l = e.i(319970);
    e.i(924482);
    var m = e.i(20511);
    e.s([
      "default",
      0,
      (e) => {
        let { pageSlug: h } = e,
          g = (0, t.useTranslations)(),
          p = (0, a.useLocale)(),
          { data: b } = (0, s.useQuery)((0, u.pageQueryOptions)(h, p)),
          I = (0, d.useUserStore)((e) => e.user);
        return (0, i.jsxs)(i.Fragment, {
          children: [
            (0, i.jsx)(m.DemoStaticHeaderComponent, {}),
            (0, i.jsx)("main", {
              className: "flex flex-1 flex-col",
              children: (0, i.jsx)(r.DemoStaticPageLayoutComponent, {
                breadCrumbLabel: g("privacy_breadcrumb_label"),
                subtitle: g("static_page_privacy_subtitle"),
                title: b?.title || "",
                showBackToTop: !0,
                children: b?.sections?.map((e, a) =>
                  e?.blockType !== "textContent"
                    ? null
                    : (0, i.jsx)(
                        "div",
                        {
                          className: I?.subscriptionId ? "mb-20" : "",
                          children:
                            e?.richDescription && e?.descriptionType === "richText"
                              ? (0, i.jsx)(c.RichText, {
                                  disableTextAlign: !0,
                                  headingIdMap: o.privacyHeadingIdMap,
                                  data: e?.richDescription,
                                  className: n.DEMO_STATIC_PAGE_PROSE_CLASS,
                                })
                              : (0, i.jsx)("p", {
                                  className: n.DEMO_STATIC_PAGE_PROSE_CLASS,
                                  children: e?.description,
                                }),
                        },
                        a,
                      ),
                ),
              }),
            }),
            (0, i.jsx)(l.DemoFooterComponent, {}),
          ],
        });
      },
    ]);
  },
  95301,
  (e) => {
    "use strict";
    e.s([
      "privacyHeadingIdMap",
      0,
      [
        { headingNumber: 1, customId: "definitions" },
        { headingNumber: 2, customId: "introductionAndScope" },
        { headingNumber: 3, customId: "personalDataCollection" },
        { headingNumber: 4, customId: "dataProcessingAndUsage" },
        { headingNumber: 5, customId: "dataStorageAndSecurity" },
        { headingNumber: 6, customId: "analyticsAdvertising" },
        { headingNumber: 7, customId: "rightsAndChoices" },
        { headingNumber: 8, customId: "retentionAndDeletion" },
        { headingNumber: 9, customId: "internationalData" },
        { headingNumber: 10, customId: "childrensPrivacy" },
        { headingNumber: 11, customId: "changesPolicy" },
        { headingNumber: 12, customId: "legalInformation" },
      ],
    ]);
  },
]);
