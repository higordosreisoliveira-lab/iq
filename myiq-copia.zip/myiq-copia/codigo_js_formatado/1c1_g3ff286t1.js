(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  409835,
  (e) => {
    "use strict";
    let t = "u" > typeof HTMLElement && "inert" in HTMLElement.prototype,
      n = new WeakMap(),
      r = [];
    var o = e.i(37681),
      l = e.i(158825),
      i = e.i(271645);
    ("u" > typeof document && i.default.useLayoutEffect,
      i.default.useInsertionEffect,
      e.i(454453),
      "u" > typeof window && window.document && window.document.createElement);
    let a = new Map();
    "u" > typeof FinalizationRegistry &&
      new FinalizationRegistry((e) => {
        a.delete(e);
      });
    var s = e.i(207670),
      u = e.i(760835),
      c = e.i(984898),
      d = e.i(779754),
      f = (0, c.tv)({
        slots: {
          wrapper: [
            "flex",
            "w-screen",
            "h-[100dvh]",
            "fixed",
            "inset-0",
            "z-50",
            "overflow-x-auto",
            "justify-center",
            "h-(--visual-viewport-height)",
          ],
          base: [
            "flex",
            "flex-col",
            "relative",
            "bg-white",
            "z-50",
            "w-full",
            "box-border",
            "bg-content1",
            "outline-solid outline-transparent",
            "mx-1",
            "my-1",
            "sm:mx-6",
            "sm:my-16",
          ],
          backdrop: "z-50",
          header: "flex py-4 px-6 flex-initial text-large font-semibold",
          body: "flex flex-1 flex-col gap-3 px-6 py-2",
          footer: "flex flex-row gap-2 px-6 py-4 justify-end",
          closeButton: [
            "absolute",
            "appearance-none",
            "outline-solid outline-transparent",
            "select-none",
            "top-1",
            "end-1",
            "p-2",
            "text-foreground-500",
            "rounded-full",
            "hover:bg-default-100",
            "active:bg-default-200",
            "tap-highlight-transparent",
            ...d.dataFocusVisibleClasses,
          ],
        },
        variants: {
          size: {
            xs: { base: "max-w-xs" },
            sm: { base: "max-w-sm" },
            md: { base: "max-w-md" },
            lg: { base: "max-w-lg" },
            xl: { base: "max-w-xl" },
            "2xl": { base: "max-w-2xl" },
            "3xl": { base: "max-w-3xl" },
            "4xl": { base: "max-w-4xl" },
            "5xl": { base: "max-w-5xl" },
            full: { base: "my-0 mx-0 sm:mx-0 sm:my-0 max-w-full h-[100dvh] min-h-[100dvh] !rounded-none" },
          },
          radius: {
            none: { base: "rounded-none" },
            sm: { base: "rounded-small" },
            md: { base: "rounded-medium" },
            lg: { base: "rounded-large" },
          },
          placement: {
            auto: { wrapper: "items-end sm:items-center" },
            center: { wrapper: "items-center sm:items-center" },
            top: { wrapper: "items-start sm:items-start" },
            "top-center": { wrapper: "items-start sm:items-center" },
            bottom: { wrapper: "items-end sm:items-end" },
            "bottom-center": { wrapper: "items-end sm:items-center" },
          },
          shadow: {
            none: { base: "shadow-none" },
            sm: { base: "shadow-small" },
            md: { base: "shadow-medium" },
            lg: { base: "shadow-large" },
          },
          backdrop: {
            transparent: { backdrop: "hidden" },
            opaque: { backdrop: "bg-overlay/50 backdrop-opacity-disabled" },
            blur: { backdrop: "backdrop-blur-md backdrop-saturate-150 bg-overlay/30" },
          },
          scrollBehavior: {
            normal: { base: "overflow-y-hidden" },
            inside: { base: "max-h-[calc(100%_-_8rem)]", body: "overflow-y-auto" },
            outside: { wrapper: "items-start sm:items-start overflow-y-auto", base: "my-16" },
          },
          disableAnimation: {
            false: {
              wrapper: [
                "[--scale-enter:100%]",
                "[--scale-exit:100%]",
                "[--slide-enter:0px]",
                "[--slide-exit:80px]",
                "sm:[--scale-enter:100%]",
                "sm:[--scale-exit:103%]",
                "sm:[--slide-enter:0px]",
                "sm:[--slide-exit:0px]",
              ],
            },
          },
        },
        defaultVariants: {
          size: "md",
          radius: "lg",
          shadow: "sm",
          placement: "auto",
          backdrop: "opaque",
          scrollBehavior: "normal",
        },
        compoundVariants: [
          { backdrop: ["opaque", "blur"], class: { backdrop: "w-screen h-screen fixed inset-0" } },
        ],
      }),
      m = e.i(273830),
      p = e.i(595494),
      v = e.i(868319),
      g = e.i(429427),
      h = e.i(75540),
      b = e.i(620253),
      w = e.i(153930),
      y = e.i(265840),
      E = e.i(88653),
      x = e.i(843476),
      A = (0, m.forwardRef)((e, c) => {
        let { children: d, ...A } = e,
          C = (function (e) {
            var c, d, y;
            let E = (0, p.useProviderContext)(),
              [x, A] = (0, m.mapPropsVariants)(e, f.variantKeys),
              {
                ref: C,
                as: T,
                className: k,
                classNames: O,
                isOpen: L,
                defaultOpen: S,
                onOpenChange: P,
                motionProps: M,
                closeButton: D,
                isDismissable: N = !0,
                hideCloseButton: R = !1,
                shouldBlockScroll: H = !0,
                portalContainer: I,
                isKeyboardDismissDisabled: F = !1,
                onClose: W,
                ...B
              } = x,
              j = (0, b.useDOMRef)(C),
              _ = (0, i.useRef)(null),
              [z, V] = (0, i.useState)(!1),
              [K, U] = (0, i.useState)(!1),
              q =
                null !=
                  (d = null != (c = e.disableAnimation) ? c : null == E ? void 0 : E.disableAnimation) && d,
              $ = (0, i.useId)(),
              G = (0, i.useId)(),
              J = (0, i.useId)(),
              X = (0, w.useOverlayTriggerState)({
                isOpen: L,
                defaultOpen: S,
                onOpenChange: (e) => {
                  (null == P || P(e), e || null == W || W());
                },
              }),
              { modalProps: Z, underlayProps: Y } = (function () {
                let e =
                    arguments.length > 0 && void 0 !== arguments[0]
                      ? arguments[0]
                      : { shouldBlockScroll: !0 },
                  c = arguments.length > 1 ? arguments[1] : void 0,
                  d = arguments.length > 2 ? arguments[2] : void 0,
                  { overlayProps: f, underlayProps: m } = (0, u.useAriaOverlay)(
                    { ...e, isOpen: c.isOpen, onClose: c.close },
                    d,
                  );
                return (
                  (0, o.usePreventScroll)({ isDisabled: !c.isOpen || !e.shouldBlockScroll }),
                  (0, l.useOverlayFocusContain)(),
                  (0, i.useEffect)(() => {
                    if (c.isOpen && d.current) {
                      var e, o;
                      let l, i, a, s, u, c, f, m, p, v, g;
                      return (
                        (l = ((e) => {
                          var t;
                          return e && "window" in e && e.window === e
                            ? e
                            : (null != (t = null == e ? void 0 : e.ownerDocument) ? t : document)
                                .defaultView || window;
                        })((e = [d.current])[0])).Element,
                        (i = void 0),
                        (o = void 0),
                        (a = document.body),
                        (s = (null == i ? void 0 : i.shouldUseInert) && t),
                        (u = new Set(e)),
                        (c = new Set()),
                        (f = (e, t) => {
                          s && e instanceof l.HTMLElement
                            ? (e.inert = t)
                            : t
                              ? e.setAttribute("aria-hidden", "true")
                              : (e.removeAttribute("aria-hidden"),
                                e instanceof l.HTMLElement && (e.inert = !1));
                        }),
                        (m = (e) => {
                          for (let t of e.querySelectorAll(
                            "[data-live-announcer], [data-react-aria-top-layer]",
                          ))
                            u.add(t);
                          let t = (e) => {
                              if (
                                c.has(e) ||
                                u.has(e) ||
                                (e.parentElement &&
                                  c.has(e.parentElement) &&
                                  "row" !== e.parentElement.getAttribute("role"))
                              )
                                return NodeFilter.FILTER_REJECT;
                              for (let t of u) if (e.contains(t)) return NodeFilter.FILTER_SKIP;
                              return NodeFilter.FILTER_ACCEPT;
                            },
                            n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, { acceptNode: t }),
                            r = t(e);
                          if ((r === NodeFilter.FILTER_ACCEPT && p(e), r !== NodeFilter.FILTER_REJECT)) {
                            let e = n.nextNode();
                            for (; null != e;) (p(e), (e = n.nextNode()));
                          }
                        }),
                        (p = (e) => {
                          var t;
                          let r = null != (t = n.get(e)) ? t : 0;
                          ((s && e instanceof l.HTMLElement
                            ? e.inert
                            : "true" === e.getAttribute("aria-hidden")) &&
                            0 === r) ||
                            (0 === r && f(e, !0), c.add(e), n.set(e, r + 1));
                        }),
                        r.length && r[r.length - 1].disconnect(),
                        m(a),
                        (v = new MutationObserver((e) => {
                          for (let t of e)
                            if ("childList" === t.type && ![...u, ...c].some((e) => e.contains(t.target)))
                              for (let e of t.addedNodes)
                                (e instanceof HTMLElement || e instanceof SVGElement) &&
                                ("true" === e.dataset.liveAnnouncer || "true" === e.dataset.reactAriaTopLayer)
                                  ? u.add(e)
                                  : e instanceof Element && m(e);
                        })).observe(a, { childList: !0, subtree: !0 }),
                        (g = {
                          visibleNodes: u,
                          hiddenNodes: c,
                          observe() {
                            v.observe(a, { childList: !0, subtree: !0 });
                          },
                          disconnect() {
                            v.disconnect();
                          },
                        }),
                        r.push(g),
                        () => {
                          for (let e of (v.disconnect(), c)) {
                            let t = n.get(e);
                            null != t && (1 === t ? (f(e, !1), n.delete(e)) : n.set(e, t - 1));
                          }
                          g === r[r.length - 1]
                            ? (r.pop(), r.length && r[r.length - 1].observe())
                            : r.splice(r.indexOf(g), 1);
                        }
                      );
                    }
                  }, [c.isOpen, d]),
                  {
                    modalProps: (function () {
                      for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                      let r = { ...t[0] };
                      for (let e = 1; e < t.length; e++) {
                        let n = t[e];
                        for (let e in n) {
                          let t = r[e],
                            o = n[e];
                          "function" == typeof t &&
                          "function" == typeof o &&
                          "o" === e[0] &&
                          "n" === e[1] &&
                          e.charCodeAt(2) >= 65 &&
                          90 >= e.charCodeAt(2)
                            ? (r[e] = (function () {
                                for (var e = arguments.length, t = Array(e), n = 0; n < e; n++)
                                  t[n] = arguments[n];
                                return function () {
                                  for (var e = arguments.length, n = Array(e), r = 0; r < e; r++)
                                    n[r] = arguments[r];
                                  for (let e of t) "function" == typeof e && e(...n);
                                };
                              })(t, o))
                            : ("className" === e || "UNSAFE_className" === e) &&
                                "string" == typeof t &&
                                "string" == typeof o
                              ? (r[e] = (0, s.default)(t, o))
                              : "id" === e && t && o
                                ? (r.id = (function (e, t) {
                                    if (e === t) return e;
                                    let n = a.get(e);
                                    if (n) return (n.forEach((e) => (e.current = t)), t);
                                    let r = a.get(t);
                                    return r ? (r.forEach((t) => (t.current = e)), e) : t;
                                  })(t, o))
                                : (r[e] = void 0 !== o ? o : t);
                        }
                      }
                      return r;
                    })(f),
                    underlayProps: m,
                  }
                );
              })({ isDismissable: N, shouldBlockScroll: H, isKeyboardDismissDisabled: F }, X, j),
              { buttonProps: Q } = (0, v.useAriaButton)({ onPress: X.close }, _),
              { isFocusVisible: ee, focusProps: et } = (0, g.useFocusRing)(),
              en = (0, h.clsx)(null == O ? void 0 : O.base, k),
              er = (0, i.useMemo)(() => f({ ...A, disableAnimation: q }), [(0, h.objectToDeps)(A), q]),
              eo = (0, i.useCallback)(
                function () {
                  let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                  return { className: er.backdrop({ class: null == O ? void 0 : O.backdrop }), ...Y, ...e };
                },
                [er, O, Y],
              );
            return {
              Component: T || "section",
              slots: er,
              domRef: j,
              headerId: G,
              bodyId: J,
              motionProps: M,
              classNames: O,
              isDismissable: N,
              closeButton: D,
              hideCloseButton: R,
              portalContainer: I,
              shouldBlockScroll: H,
              backdrop: null != (y = e.backdrop) ? y : "opaque",
              isOpen: X.isOpen,
              onClose: X.close,
              disableAnimation: q,
              setBodyMounted: U,
              setHeaderMounted: V,
              getDialogProps: function () {
                var t;
                let n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                  r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
                return {
                  ref: (0, h.mergeRefs)(r, j),
                  ...(0, h.mergeProps)(Z, B, n),
                  className: er.base({ class: (0, h.clsx)(en, n.className) }),
                  id: $,
                  "data-open": (0, h.dataAttr)(X.isOpen),
                  "data-dismissable": (0, h.dataAttr)(N),
                  "aria-modal": (0, h.dataAttr)(!0),
                  "data-placement": null != (t = null == e ? void 0 : e.placement) ? t : "right",
                  "aria-labelledby": z ? G : void 0,
                  "aria-describedby": K ? J : void 0,
                };
              },
              getBackdropProps: eo,
              getCloseButtonProps: () => ({
                role: "button",
                tabIndex: 0,
                "aria-label": "Close",
                "data-focus-visible": (0, h.dataAttr)(ee),
                className: er.closeButton({ class: null == O ? void 0 : O.closeButton }),
                ...(0, h.mergeProps)(Q, et),
              }),
            };
          })({ ...A, ref: c }),
          T = (0, x.jsx)(l.Overlay, { portalContainer: C.portalContainer, children: d });
        return (0, x.jsx)(y.ModalProvider, {
          value: C,
          children:
            C.disableAnimation && C.isOpen
              ? T
              : (0, x.jsx)(E.AnimatePresence, { children: C.isOpen ? T : null }),
        });
      });
    ((A.displayName = "HeroUI.Modal"), e.s(["Modal", 0, A], 409835));
  },
  37681,
  (e) => {
    "use strict";
    let t;
    var n = e.i(99544),
      r = e.i(4816);
    function o() {
      for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
      return function () {
        for (var e = arguments.length, n = Array(e), r = 0; r < e; r++) n[r] = arguments[r];
        for (let e of t) "function" == typeof e && e(...n);
      };
    }
    function l(e, t) {
      if (!e) return !1;
      let n = window.getComputedStyle(e),
        r = /(auto|scroll)/.test(n.overflow + n.overflowX + n.overflowY);
      return (r && t && (r = e.scrollHeight !== e.clientHeight || e.scrollWidth !== e.clientWidth), r);
    }
    function i(e, t) {
      let n = e;
      for (l(n, t) && (n = n.parentElement); n && !l(n, t);) n = n.parentElement;
      return n || document.scrollingElement || document.documentElement;
    }
    let a = new Set(["checkbox", "radio", "range", "color", "file", "image", "button", "submit", "reset"]);
    function s(e) {
      return (
        (e instanceof HTMLInputElement && !a.has(e.type)) ||
        e instanceof HTMLTextAreaElement ||
        (e instanceof HTMLElement && e.isContentEditable)
      );
    }
    let u = "u" > typeof document && window.visualViewport,
      c = 0;
    function d(e, t, n) {
      let r = e.style[t];
      return (
        (e.style[t] = n),
        () => {
          e.style[t] = r;
        }
      );
    }
    function f(e, t, n, r) {
      return (
        e.addEventListener(t, n, r),
        () => {
          e.removeEventListener(t, n, r);
        }
      );
    }
    function m(e, t) {
      t || !u ? p(e) : u.addEventListener("resize", () => p(e), { once: !0 });
    }
    function p(e) {
      let t = document.scrollingElement || document.documentElement,
        n = e;
      for (; n && n !== t;) {
        let e = i(n);
        if (e !== document.documentElement && e !== document.body && e !== n) {
          let t = e.getBoundingClientRect(),
            r = n.getBoundingClientRect();
          if (r.top < t.top || r.bottom > t.top + n.clientHeight) {
            let n = t.bottom;
            u && (n = Math.min(n, u.offsetTop + u.height));
            let o = r.top - t.top - ((n - t.top) / 2 - r.height / 2);
            e.scrollTo({
              top: Math.max(0, Math.min(e.scrollHeight - e.clientHeight, e.scrollTop + o)),
              behavior: "smooth",
            });
          }
        }
        n = e.parentElement;
      }
    }
    e.s(
      [
        "usePreventScroll",
        0,
        function () {
          let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
            { isDisabled: a } = e;
          (0, n.useLayoutEffect)(() => {
            if (!a) {
              let e, n, a, u, p, v;
              return (
                1 == ++c &&
                  (t = (0, r.isIOS)()
                    ? ((n = !1),
                      ((a = document.createElement("style")).textContent = `
@layer {
  * {
    overscroll-behavior: contain;
  }
}`.trim()),
                      document.head.prepend(a),
                      (u = HTMLElement.prototype.focus),
                      (HTMLElement.prototype.focus = function (e) {
                        let t = null != document.activeElement && s(document.activeElement);
                        (u.call(this, { ...e, preventScroll: !0 }), (e && e.preventScroll) || m(this, t));
                      }),
                      (p = o(
                        f(
                          document,
                          "touchstart",
                          (t) => {
                            let r = t.target;
                            ((e = l(r) ? r : i(r, !0)), (n = !1));
                            let o = r.ownerDocument.defaultView.getSelection();
                            (o && !o.isCollapsed && o.containsNode(r, !0) && (n = !0),
                              "selectionStart" in r &&
                                "selectionEnd" in r &&
                                r.selectionStart < r.selectionEnd &&
                                r.ownerDocument.activeElement === r &&
                                (n = !0));
                          },
                          { passive: !1, capture: !0 },
                        ),
                        f(
                          document,
                          "touchmove",
                          (t) => {
                            if (2 !== t.touches.length && !n) {
                              if (!e || e === document.documentElement || e === document.body)
                                return void t.preventDefault();
                              e.scrollHeight === e.clientHeight &&
                                e.scrollWidth === e.clientWidth &&
                                t.preventDefault();
                            }
                          },
                          { passive: !1, capture: !0 },
                        ),
                        f(
                          document,
                          "blur",
                          (e) => {
                            let t = e.target,
                              n = e.relatedTarget;
                            if (n && s(n)) (n.focus({ preventScroll: !0 }), m(n, s(t)));
                            else if (!n) {
                              var r;
                              let e = null == (r = t.parentElement) ? void 0 : r.closest("[tabindex]");
                              null == e || e.focus({ preventScroll: !0 });
                            }
                          },
                          !0,
                        ),
                      )),
                      () => {
                        (p(), a.remove(), (HTMLElement.prototype.focus = u));
                      })
                    : o(
                        (v = window.innerWidth - document.documentElement.clientWidth) > 0 &&
                          ("scrollbarGutter" in document.documentElement.style
                            ? d(document.documentElement, "scrollbarGutter", "stable")
                            : d(document.documentElement, "paddingRight", `${v}px`)),
                        d(document.documentElement, "overflow", "hidden"),
                      )),
                () => {
                  0 == --c && t();
                }
              );
            }
          }, [a]);
        },
      ],
      37681,
    );
  },
  4816,
  760835,
  (e) => {
    "use strict";
    function t(e) {
      var t;
      if ("u" < typeof window || null == window.navigator) return !1;
      let n = null == (t = window.navigator.userAgentData) ? void 0 : t.brands;
      return (Array.isArray(n) && n.some((t) => e.test(t.brand))) || e.test(window.navigator.userAgent);
    }
    function n(e) {
      var t;
      return (
        "u" > typeof window &&
        null != window.navigator &&
        e.test(
          (null == (t = window.navigator.userAgentData) ? void 0 : t.platform) || window.navigator.platform,
        )
      );
    }
    function r(e) {
      let t = null;
      return () => (null == t && (t = e()), t);
    }
    let o = r(function () {
        return n(/^Mac/i);
      }),
      l = r(function () {
        return n(/^iPhone/i);
      }),
      i = r(function () {
        return n(/^iPad/i) || (o() && navigator.maxTouchPoints > 1);
      }),
      a = r(function () {
        return l() || i();
      });
    r(function () {
      return o() || a();
    });
    let s = r(function () {
        return t(/AppleWebKit/i) && !u();
      }),
      u = r(function () {
        return t(/Chrome/i);
      });
    (r(function () {
      return t(/Android/i);
    }),
      r(function () {
        return t(/Firefox/i);
      }),
      e.s(["isIOS", 0, a, "isMac", 0, o, "isWebKit", 0, s], 4816));
    var c = e.i(370864),
      d = e.i(616231),
      f = e.i(110514),
      m = e.i(934203),
      p = e.i(271645);
    function v(e, t) {
      if (e.button > 0) return !1;
      if (e.target) {
        let t = e.target.ownerDocument;
        if (!t || !t.documentElement.contains(e.target) || e.target.closest("[data-react-aria-top-layer]"))
          return !1;
      }
      return !!t.current && !e.composedPath().includes(t.current);
    }
    var g = [];
    e.s(
      [
        "useAriaOverlay",
        0,
        function (e, t) {
          let {
            disableOutsideEvents: n = !0,
            isDismissable: r = !1,
            isKeyboardDismissDisabled: o = !1,
            isOpen: l,
            onClose: i,
            shouldCloseOnBlur: a,
            shouldCloseOnInteractOutside: s,
          } = e;
          (0, p.useEffect)(() => {
            if (l && !g.includes(t))
              return (
                g.push(t),
                () => {
                  let e = g.indexOf(t);
                  e >= 0 && g.splice(e, 1);
                }
              );
          }, [l, t]);
          let u = () => {
            g[g.length - 1] === t && i && i();
          };
          !(function (e) {
            let { ref: t, onInteractOutside: n, isDisabled: r, onInteractOutsideStart: o } = e,
              l = (0, p.useRef)({ isPointerDown: !1, ignoreEmulatedMouseEvents: !1 }),
              i = (0, f.useEffectEvent)((e) => {
                n && v(e, t) && (o && o(e), (l.current.isPointerDown = !0));
              }),
              a = (0, f.useEffectEvent)((e) => {
                n && n(e);
              });
            (0, p.useEffect)(() => {
              let e = l.current;
              if (r) return;
              let n = t.current,
                o = (0, m.getOwnerDocument)(n);
              if ("u" > typeof PointerEvent) {
                let n = (n) => {
                  (e.isPointerDown && v(n, t) && a(n), (e.isPointerDown = !1));
                };
                return (
                  o.addEventListener("pointerdown", i, !0),
                  o.addEventListener("click", n, !0),
                  () => {
                    (o.removeEventListener("pointerdown", i, !0), o.removeEventListener("click", n, !0));
                  }
                );
              }
            }, [t, r, i, a]);
          })({
            isDisabled: !(r && l),
            onInteractOutside:
              r && l
                ? (e) => {
                    (!s || s(e.target)) &&
                      (g[g.length - 1] === t && n && (e.stopPropagation(), e.preventDefault()), u());
                  }
                : void 0,
            onInteractOutsideStart: (e) => {
              (!s || s(e.target)) &&
                (g[g.length - 1] === t && n && (e.stopPropagation(), e.preventDefault()),
                "pressEnd" !==
                  (function (e) {
                    let t = e.current;
                    if (!t) return "unknown";
                    let n = (t.getAttribute("role") || "").toLowerCase(),
                      r = t.getAttribute("aria-modal");
                    return ("dialog" === n || "alertdialog" === n) &&
                      (null === r || "true" === r.toLowerCase())
                      ? "pressEnd"
                      : ["listbox", "menu", "tree", "grid", "combobox"].includes(n)
                        ? "pressStart"
                        : "unknown";
                  })(t) && u());
            },
            ref: t,
          });
          let { focusWithinProps: h } = (0, d.useFocusWithin)({
            isDisabled: !a,
            onBlurWithin: (e) => {
              !(!e.relatedTarget || (0, c.isElementInChildOfActiveScope)(e.relatedTarget)) &&
                (!s || s(e.relatedTarget)) &&
                u();
            },
          });
          return {
            overlayProps: {
              onKeyDown: (e) => {
                "Escape" !== e.key ||
                  o ||
                  e.nativeEvent.isComposing ||
                  (e.stopPropagation(), e.preventDefault(), u());
              },
              ...h,
            },
            underlayProps: {
              onPointerDown: (e) => {
                e.target === e.currentTarget && e.preventDefault();
              },
            },
          };
        },
      ],
      760835,
    );
  },
  153930,
  (e) => {
    "use strict";
    var t = e.i(271645),
      n = e.i(335190);
    e.s([
      "useOverlayTriggerState",
      0,
      function (e) {
        let [r, o] = (0, n.useControlledState)(e.isOpen, e.defaultOpen || !1, e.onOpenChange),
          l = (0, t.useCallback)(() => {
            o(!0);
          }, [o]),
          i = (0, t.useCallback)(() => {
            o(!1);
          }, [o]),
          a = (0, t.useCallback)(() => {
            o(!r);
          }, [o, r]);
        return { isOpen: r, setOpen: o, open: l, close: i, toggle: a };
      },
    ]);
  },
  335190,
  (e) => {
    "use strict";
    e.i(247167);
    var t = e.i(271645);
    e.s([
      "useControlledState",
      0,
      function (e, n, r) {
        let [o, l] = (0, t.useState)(e || n),
          i = (0, t.useRef)(void 0 !== e),
          a = void 0 !== e;
        (0, t.useEffect)(() => {
          (i.current, (i.current = a));
        }, [a]);
        let s = a ? e : o,
          u = (0, t.useCallback)(
            function (e) {
              for (var t = arguments.length, n = Array(t > 1 ? t - 1 : 0), o = 1; o < t; o++)
                n[o - 1] = arguments[o];
              let i = function (e) {
                for (var t = arguments.length, n = Array(t > 1 ? t - 1 : 0), o = 1; o < t; o++)
                  n[o - 1] = arguments[o];
                (r && !Object.is(s, e) && r(e, ...n), a || (s = e));
              };
              "function" == typeof e
                ? l(function (t) {
                    for (var r = arguments.length, o = Array(r > 1 ? r - 1 : 0), l = 1; l < r; l++)
                      o[l - 1] = arguments[l];
                    let u = e(a ? s : t, ...o);
                    return (i(u, ...n), a) ? t : u;
                  })
                : (a || l(e), i(e, ...n));
            },
            [a, s, r],
          );
        return [s, u];
      },
    ]);
  },
  475254,
  (e) => {
    "use strict";
    var t = e.i(271645);
    let n = (e) => {
        let t = e.replace(/^([A-Z])|[\s-_]+(\w)/g, (e, t, n) => (n ? n.toUpperCase() : t.toLowerCase()));
        return t.charAt(0).toUpperCase() + t.slice(1);
      },
      r = function () {
        for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
        return t
          .filter((e, t, n) => !!e && "" !== e.trim() && n.indexOf(e) === t)
          .join(" ")
          .trim();
      };
    var o = {
      xmlns: "http://www.w3.org/2000/svg",
      width: 24,
      height: 24,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round",
    };
    let l = (0, t.forwardRef)((e, n) => {
      let {
        color: l = "currentColor",
        size: i = 24,
        strokeWidth: a = 2,
        absoluteStrokeWidth: s,
        className: u = "",
        children: c,
        iconNode: d,
        ...f
      } = e;
      return (0, t.createElement)(
        "svg",
        {
          ref: n,
          ...o,
          width: i,
          height: i,
          stroke: l,
          strokeWidth: s ? (24 * Number(a)) / Number(i) : a,
          className: r("lucide", u),
          ...(!c &&
            !((e) => {
              for (let t in e) if (t.startsWith("aria-") || "role" === t || "title" === t) return !0;
            })(f) && { "aria-hidden": "true" }),
          ...f,
        },
        [
          ...d.map((e) => {
            let [n, r] = e;
            return (0, t.createElement)(n, r);
          }),
          ...(Array.isArray(c) ? c : [c]),
        ],
      );
    });
    e.s(
      [
        "default",
        0,
        (e, o) => {
          let i = (0, t.forwardRef)((i, a) => {
            let { className: s, ...u } = i;
            return (0, t.createElement)(l, {
              ref: a,
              iconNode: o,
              className: r(
                `lucide-${n(e)
                  .replace(/([a-z0-9])([A-Z])/g, "$1-$2")
                  .toLowerCase()}`,
                `lucide-${e}`,
                s,
              ),
              ...u,
            });
          });
          return ((i.displayName = n(e)), i);
        },
      ],
      475254,
    );
  },
  841947,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("x", [
      ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
      ["path", { d: "m6 6 12 12", key: "d8bk6v" }],
    ]);
    e.s(["default", 0, t]);
  },
  37727,
  (e) => {
    "use strict";
    var t = e.i(841947);
    e.s(["X", () => t.default]);
  },
  749652,
  (e) => {
    "use strict";
    e.s([
      "resolveElements",
      0,
      function (e, t, n) {
        if (null == e) return [];
        if (e instanceof EventTarget) return [e];
        if ("string" == typeof e) {
          let r = document;
          t && (r = t.current);
          let o = n?.[e] ?? r.querySelectorAll(e);
          return o ? Array.from(o) : [];
        }
        return Array.from(e).filter((e) => null != e);
      },
    ]);
  },
]);
