(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  460849,
  (e) => {
    "use strict";
    var t = e.i(75540);
    e.s([
      "mergeRefs",
      0,
      function () {
        for (var e = arguments.length, a = Array(e), n = 0; n < e; n++) a[n] = arguments[n];
        return (e) => {
          a.forEach((a) =>
            (function (e, a) {
              if (null != e) {
                if ((0, t.isFunction)(e)) return void e(a);
                try {
                  e.current = a;
                } catch {
                  throw Error(`Cannot assign value '${a}' to ref '${e}'`);
                }
              }
            })(a, e),
          );
        };
      },
    ]);
  },
  655483,
  (e) => {
    "use strict";
    var t = e.i(271645),
      a = (null == globalThis ? void 0 : globalThis.document) ? t.useLayoutEffect : t.useEffect;
    e.s(["useSafeLayoutEffect", 0, a]);
  },
  641711,
  (e, t, a) => {
    "use strict";
    function n(e) {
      return (n =
        "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
          ? function (e) {
              return typeof e;
            }
          : function (e) {
              return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype
                ? "symbol"
                : typeof e;
            })(e);
    }
    Object.defineProperty(a, "__esModule", { value: !0 });
    var i,
      r = "basil",
      s = "https://js.stripe.com",
      o = "".concat(s, "/").concat(r, "/stripe.js"),
      l = /^https:\/\/js\.stripe\.com\/v3\/?(\?.*)?$/,
      c = /^https:\/\/js\.stripe\.com\/(v3|[a-z]+)\/stripe\.js(\?.*)?$/,
      u =
        "loadStripe.setLoadParameters was called but an existing Stripe.js script already exists in the document; existing script parameters will be used",
      d = function () {
        for (var e = document.querySelectorAll('script[src^="'.concat(s, '"]')), t = 0; t < e.length; t++) {
          var a,
            n = e[t];
          if (((a = n.src), l.test(a) || c.test(a))) return n;
        }
        return null;
      },
      p = function (e) {
        var t = e && !e.advancedFraudSignals ? "?advancedFraudSignals=false" : "",
          a = document.createElement("script");
        a.src = "".concat(o).concat(t);
        var n = document.head || document.body;
        if (!n) throw Error("Expected document.body not to be null. Stripe.js requires a <body> element.");
        return (n.appendChild(a), a);
      },
      _ = function (e, t) {
        e && e._registerWrapper && e._registerWrapper({ name: "stripe-js", version: "7.9.0", startTime: t });
      },
      m = null,
      g = null,
      b = null,
      S = function (e, t, a) {
        if (null === e) return null;
        var n,
          i = t[0].match(/^pk_test/),
          s = 3 === (n = e.version) ? "v3" : n;
        i &&
          s !== r &&
          console.warn(
            "Stripe.js@"
              .concat(s, " was loaded on the page, but @stripe/stripe-js@")
              .concat("7.9.0", " expected Stripe.js@")
              .concat(
                r,
                ". This may result in unexpected behavior. For more information, see https://docs.stripe.com/sdks/stripejs-versioning",
              ),
          );
        var o = e.apply(void 0, t);
        return (_(o, a), o);
      },
      y = function (e) {
        var t =
          "invalid load parameters; expected object of shape\n\n    {advancedFraudSignals: boolean}\n\nbut received\n\n    ".concat(
            JSON.stringify(e),
            "\n",
          );
        if (null === e || "object" !== n(e)) throw Error(t);
        if (1 === Object.keys(e).length && "boolean" == typeof e.advancedFraudSignals) return e;
        throw Error(t);
      },
      E = !1,
      f = function () {
        for (var e, t = arguments.length, a = Array(t), n = 0; n < t; n++) a[n] = arguments[n];
        E = !0;
        var r = Date.now();
        return ((e = i),
        null !== m
          ? m
          : (m = new Promise(function (t, a) {
              if ("u" < typeof window || "u" < typeof document) return void t(null);
              if ((window.Stripe && e && console.warn(u), window.Stripe)) return void t(window.Stripe);
              try {
                var n,
                  i = d();
                (i && e
                  ? console.warn(u)
                  : i
                    ? i &&
                      null !== b &&
                      null !== g &&
                      (i.removeEventListener("load", b),
                      i.removeEventListener("error", g),
                      null == (n = i.parentNode) || n.removeChild(i),
                      (i = p(e)))
                    : (i = p(e)),
                  (b = function () {
                    window.Stripe ? t(window.Stripe) : a(Error("Stripe.js not available"));
                  }),
                  (g = function (e) {
                    a(Error("Failed to load Stripe.js", { cause: e }));
                  }),
                  i.addEventListener("load", b),
                  i.addEventListener("error", g));
              } catch (e) {
                a(e);
                return;
              }
            })).catch(function (e) {
              return ((m = null), Promise.reject(e));
            })).then(function (e) {
          return S(e, a, r);
        });
      };
    ((f.setLoadParameters = function (e) {
      if (!(
        E &&
        i &&
        Object.keys(y(e)).reduce(function (t, a) {
          var n;
          return t && e[a] === (null == (n = i) ? void 0 : n[a]);
        }, !0)
      )) {
        if (E) throw Error("You cannot change load parameters after calling loadStripe");
        i = y(e);
      }
    }),
      (a.loadStripe = f));
  },
  709275,
  (e, t, a) => {
    t.exports = e.r(641711);
  },
  455711,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("brain", [
      ["path", { d: "M12 18V5", key: "adv99a" }],
      ["path", { d: "M15 13a4.17 4.17 0 0 1-3-4 4.17 4.17 0 0 1-3 4", key: "1e3is1" }],
      ["path", { d: "M17.598 6.5A3 3 0 1 0 12 5a3 3 0 1 0-5.598 1.5", key: "1gqd8o" }],
      ["path", { d: "M17.997 5.125a4 4 0 0 1 2.526 5.77", key: "iwvgf7" }],
      ["path", { d: "M18 18a4 4 0 0 0 2-7.464", key: "efp6ie" }],
      ["path", { d: "M19.967 17.483A4 4 0 1 1 12 18a4 4 0 1 1-7.967-.517", key: "1gq6am" }],
      ["path", { d: "M6 18a4 4 0 0 1-2-7.464", key: "k1g0md" }],
      ["path", { d: "M6.003 5.125a4 4 0 0 0-2.526 5.77", key: "q97ue3" }],
    ]);
    e.s(["Brain", 0, t], 455711);
  },
  248256,
  (e) => {
    "use strict";
    let t = (0, e.i(475254).default)("globe", [
      ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
      ["path", { d: "M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20", key: "13o1zl" }],
      ["path", { d: "M2 12h20", key: "9i4pu4" }],
    ]);
    e.s(["Globe", 0, t], 248256);
  },
  841977,
  (e) => {
    "use strict";
    e.s([
      "BONUS_POINTS",
      0,
      { under_ten: 5, under_seven: 7, under_five: 10 },
      "CORRECT_ANSWER_MIN_COUNT",
      0,
      15,
      "EASY_QUESTION_POINTS",
      0,
      0.87,
      "FIVE_MINUTES",
      0,
      300,
      "FOUR_MINUTES",
      0,
      240,
      "HARD_QUESTION_POINTS",
      0,
      1.12,
      "MINIMAL_IQ_SCORE",
      0,
      105,
      "MINUTE_SECONDS",
      0,
      60,
      "SEVEN_MINUTES",
      0,
      420,
      "TEN_MINUTES",
      0,
      600,
      "WARNING_THRESHOLD",
      0,
      10,
    ]);
  },
  339386,
  643449,
  (e) => {
    "use strict";
    var t = e.i(157273),
      a = e.i(60423);
    (e.s(["DEFAULT_DISPLAY_DURATION_SECONDS", 0, 5], 643449),
      e.s(
        [
          "buildNonImageQuizAnswers",
          0,
          (e) => {
            let { allQuestions: t, additionalAnswers: a, questionTimes: n } = e,
              i = [...t].sort((e, t) => e.id - t.id),
              r = 0;
            return i.reduce((e, t) => {
              if ("icons" in t) return (r++, e);
              if (!("questionKey" in t && t.questionKey && t.correctAnswer)) return e;
              let i = a[t.id];
              if (void 0 === i) return e;
              let s = !!(t.memorizationSequence && t.memorizationAskedPosition);
              return (
                e.push({
                  questionKey: t.questionKey,
                  position: t.id,
                  precedingImageCount: r,
                  userAnswer: i,
                  correctAnswer: t.correctAnswer,
                  isCorrect: i === t.correctAnswer,
                  timeSpent: n?.[t.id] || 0,
                  ...(s
                    ? {
                        memorization: {
                          sequence: t.memorizationSequence,
                          askedPosition: t.memorizationAskedPosition,
                          shownSeconds: t.memorizationDurationSeconds ?? 5,
                        },
                      }
                    : {}),
                }),
                e
              );
            }, []);
          },
          "getNonImageQuizAnswersFromLocalStorage",
          0,
          () => {
            let e = a.accessLocalStorage.getItem(t.StorageKeys.MYIQ_NON_IMAGE_ANSWERS);
            if (!e) return null;
            try {
              let t = JSON.parse(e);
              return Array.isArray(t) ? t : null;
            } catch {
              return null;
            }
          },
          "saveNonImageQuizAnswersToLocalStorage",
          0,
          (e) => {
            0 !== e.length &&
              a.accessLocalStorage.setItem(t.StorageKeys.MYIQ_NON_IMAGE_ANSWERS, JSON.stringify(e));
          },
        ],
        339386,
      ));
  },
  245588,
  (e) => {
    "use strict";
    var t = e.i(157273),
      a = e.i(60423);
    e.s([
      "clearQuizAnswersFromLocalStorage",
      0,
      () => {
        a.accessLocalStorage.removeItem(t.StorageKeys.QUIZ_ANSWERS);
      },
      "getQuizAnswersFromLocalStorage",
      0,
      () => {
        let e = a.accessLocalStorage.getItem(t.StorageKeys.QUIZ_ANSWERS);
        return e ? JSON.parse(e) : null;
      },
    ]);
  },
  821652,
  495585,
  (e) => {
    "use strict";
    var t = e.i(954616),
      a = e.i(134404);
    e.i(957215);
    var n = e.i(81844);
    let i = async (e, t) => {
      let { arg: a } = t,
        i = await n.apiInstance.post(e, { json: a, throwHttpErrors: !1 });
      return await i.json();
    };
    (e.s(["createPaynextPaymentFetcher", 0, i], 495585),
      e.s(
        [
          "useCreatePaynextPaymentMutation",
          0,
          () => {
            let e = (0, t.useMutation)({
              mutationKey: [a.EApiRoutes.PAYNEXT_PAYMENT],
              mutationFn: (e) => i(a.EApiRoutes.PAYNEXT_PAYMENT, { arg: e }),
            });
            return { ...e, trigger: e.mutateAsync };
          },
        ],
        821652,
      ));
  },
  230470,
  (e) => {
    "use strict";
    var t = e.i(954616),
      a = e.i(266027),
      n = e.i(912598),
      i = e.i(86596),
      r = e.i(984061),
      s = e.i(134404);
    e.i(682770);
    var o = e.i(934952),
      l = e.i(117595),
      c = e.i(866897);
    e.i(877045);
    var u = e.i(28639);
    e.i(756503);
    var d = e.i(542516),
      p = e.i(558268);
    let _ = () => ({
        source: "client-log",
        pathname: window.location.pathname,
        href: window.location.href,
        user_agent: window.navigator.userAgent,
      }),
      m = new p.Logger();
    e.i(531122);
    var g = e.i(81844);
    let b = async (e) => {
        try {
          let e = await g.apiInstance.get("cancellation/billing-status", {
            headers: (0, u.getCancellationSessionHeaders)(),
            throwHttpErrors: !1,
          });
          return await e.json();
        } catch (e) {
          return { success: !1, error: e?.message || "Failed to get billing status" };
        }
      },
      S = async (e) => {
        try {
          let t = await g.apiInstance.post(s.EApiRoutes.SUBSCRIPTION, { json: e, throwHttpErrors: !1 });
          return await t.json();
        } catch (e) {
          return { success: !1, error: e?.message || "error_smth_went_wrong" };
        }
      },
      y = async (e) => {
        let t, a;
        ((t = "Cancel subscription requested"),
          (a = { type: "subscription_cancel_clicked", email: e.email, isBillingOnly: e.isBillingOnly }),
          m.info(t, { ..._(), ...a }));
        try {
          let t = await g.apiInstance.post("cancellation/cancel", {
            json: e,
            headers: (0, u.getCancellationSessionHeaders)(),
            throwHttpErrors: !1,
          });
          return await t.json();
        } catch (n) {
          let t, a;
          return (
            (t = "Cancel subscription network/fetch failed"),
            (a = { type: "subscription_cancel_network_failed", email: e.email, error: n?.message }),
            m.error(t, { ..._(), ...a }),
            { success: !1, error: n?.message || "Failed to cancel subscription" }
          );
        }
      },
      E = async (e) => {
        try {
          let t = !!l.default.get(c.ECookieArg.PAYNEXT_SESSION),
            a = await g.apiInstance.post(`${s.EApiRoutes.SUBSCRIPTION}/check-status`, {
              json: { ...e, hasPaynextSession: t },
              throwHttpErrors: !1,
            }),
            n = await a.json();
          return (
            n.success &&
              n.data?.paynextSession?.id &&
              (l.default.get(c.ECookieArg.PAYNEXT_SESSION) ||
                l.default.set(c.ECookieArg.PAYNEXT_SESSION, n.data.paynextSession.id, {
                  secure: "production" === d.envClient.NEXT_PUBLIC_APP_ENV,
                  expires: 40 / 24,
                  path: "/",
                  sameSite: "lax",
                })),
            n
          );
        } catch (e) {
          return { success: !1, error: e?.message || "Failed to check subscription status" };
        }
      },
      f = async (e) => {
        try {
          let t = await g.apiInstance.post("cancellation/downgrade", {
            json: e,
            headers: (0, u.getCancellationSessionHeaders)(),
            throwHttpErrors: !1,
          });
          return await t.json();
        } catch (e) {
          return { success: !1, error: e?.message || "Failed to downgrade subscription" };
        }
      },
      h = (e) =>
        (e.activeSubscriptions?.length ?? 0) > 0 ||
        (e.allSubscriptions?.length ?? 0) > 0 ||
        (e.paynextSubscription?.activeSubscriptions?.length ?? 0) > 0 ||
        (e.paynextSubscription?.allSubscriptions?.length ?? 0) > 0 ||
        !!e.isCancelled ||
        !!e.isDowngraded ||
        !!e.isPaynextSubscribed;
    e.s(
      [
        "useCancelSubscriptionMutation",
        0,
        () => {
          let { user: e, handleChangeUserStore: a } = (0, i.useUserStore)(),
            l = (0, n.useQueryClient)(),
            c = (0, t.useMutation)({
              mutationKey: [s.EApiRoutes.SUBSCRIPTION, "cancel"],
              mutationFn: (e) => y(e),
              onSuccess(t) {
                t.success
                  ? ((0, r.saveCancellationCompletedAt)(e?.email),
                    t.data &&
                      (a({
                        user: {
                          ...e,
                          nextBillingDate: t.data.nextBillingDate || void 0,
                          billingSubscriptionData: {
                            ...e?.billingSubscriptionData,
                            isAllInactive: !0,
                            isScheduledForCancellation: t.data.isScheduledForCancellation,
                            isSubscribed: !1,
                            isCancelled: !0,
                          },
                          isPaynextSubscribed: !1,
                        },
                      }),
                      l.setQueryData([s.EApiRoutes.SUBSCRIPTION, "billing-status", e?.email], {
                        success: !0,
                        data: {
                          email: e?.email,
                          isSubscribed: !1,
                          isAllInactive: !0,
                          isScheduledForCancellation: t.data.isScheduledForCancellation,
                          isCancelled: !0,
                          isPaynextSubscribed: !1,
                          nextBillingDate: t.data.nextBillingDate || void 0,
                        },
                      })))
                  : (0, o.customToast)(t?.error || "", "error");
              },
            });
          return { ...c, trigger: c.mutateAsync };
        },
        "useCreatePaynextSubscriptionMutation",
        0,
        () => {
          let e = (0, t.useMutation)({ mutationKey: [s.EApiRoutes.SUBSCRIPTION], mutationFn: (e) => S(e) });
          return { ...e, trigger: e.mutateAsync };
        },
        "useDowngradeSubscriptionMutation",
        0,
        () => {
          let { user: e, handleChangeUserStore: a } = (0, i.useUserStore)(),
            r = (0, n.useQueryClient)(),
            l = (0, t.useMutation)({
              mutationKey: [s.EApiRoutes.SUBSCRIPTION, "downgrade"],
              mutationFn: (e) => f(e),
              onSuccess(t) {
                t.success
                  ? t.data &&
                    (a({
                      user: {
                        ...e,
                        billingSubscriptionData: { ...e?.billingSubscriptionData, isDowngraded: !0 },
                        paynextSubscription: void 0,
                      },
                    }),
                    r.setQueryData([s.EApiRoutes.SUBSCRIPTION, "billing-status", e?.email], (e) =>
                      e?.data ? { ...e, data: { ...e.data, isDowngraded: !0 } } : e,
                    ))
                  : (0, o.customToast)(t?.error || "", "error");
              },
            });
          return { ...l, trigger: l.mutateAsync };
        },
        "useGetBillingStatusQuery",
        0,
        (e) => {
          let { user: t, handleChangeUserStore: n } = (0, i.useUserStore)(),
            r = t?.email || e?.serverEmail;
          return (0, a.useQuery)({
            initialData: e?.initialData,
            queryKey: [s.EApiRoutes.SUBSCRIPTION, "billing-status", r],
            queryFn: async () => {
              if (
                t?.billingSubscriptionData &&
                t?.paynextSubscription &&
                h({
                  activeSubscriptions: t.billingSubscriptionData.activeSubscriptions,
                  paynextSubscription: t.paynextSubscription,
                  isCancelled: t.billingSubscriptionData.isCancelled,
                  isDowngraded: t.billingSubscriptionData.isDowngraded,
                  isPaynextSubscribed: t.isPaynextSubscribed,
                })
              )
                return {
                  success: !0,
                  data: {
                    email: t.email,
                    activeSubscriptions: t.billingSubscriptionData.activeSubscriptions,
                    isSubscribed: t.billingSubscriptionData.isSubscribed,
                    isAllInactive: t.billingSubscriptionData.isAllInactive,
                    isScheduledForCancellation: t.billingSubscriptionData.isScheduledForCancellation,
                    isCancelled: t.billingSubscriptionData.isCancelled,
                    isDowngraded: t.billingSubscriptionData.isDowngraded,
                    isPaynextSubscribed: t.isPaynextSubscribed,
                    nextBillingDate: t.nextBillingDate,
                    paynextSubscription: t.paynextSubscription,
                    activePaynextPlanMonthlyAmountCents:
                      t.billingSubscriptionData.activePaynextPlanMonthlyAmountCents,
                    activePaynextPlanPriceCurrency: t.billingSubscriptionData.activePaynextPlanPriceCurrency,
                  },
                  fromCache: !0,
                };
              let e = await b(t?.email || "");
              return (
                e.success &&
                  e.data &&
                  h(e.data) &&
                  n({
                    user: {
                      ...t,
                      billingSubscriptionData: {
                        activeSubscriptions: e.data.activeSubscriptions,
                        isSubscribed: e.data.isSubscribed,
                        isAllInactive: e.data.isAllInactive,
                        isScheduledForCancellation: e.data.isScheduledForCancellation,
                        isCancelled: e.data.isCancelled,
                        isDowngraded: e.data.isDowngraded,
                        activePaynextPlanMonthlyAmountCents: e.data.activePaynextPlanMonthlyAmountCents,
                        activePaynextPlanPriceCurrency: e.data.activePaynextPlanPriceCurrency,
                      },
                      email: t?.email,
                      isPaynextSubscribed: e.data.isPaynextSubscribed,
                      nextBillingDate: e.data.nextBillingDate || void 0,
                      paynextSubscription: e.data.paynextSubscription,
                    },
                  }),
                {
                  ...e,
                  data: e.data ? { ...e.data, email: t?.email || e.data.email } : e.data,
                  fromCache: !1,
                }
              );
            },
            enabled: !!r && e?.enabled !== !1,
            refetchInterval: (e) => {
              let t = e.state.data?.data;
              return !(t && h(t)) && !(e.state.dataUpdateCount >= 10) && 2500;
            },
            refetchIntervalInBackground: !1,
          });
        },
        "useRefreshTokenMutation",
        0,
        () => {
          let e = (0, t.useMutation)({ mutationFn: E });
          return { ...e, trigger: e.mutateAsync };
        },
      ],
      230470,
    );
  },
  934337,
  194693,
  597521,
  171946,
  703085,
  492669,
  70224,
  19309,
  106502,
  327293,
  230268,
  779450,
  492810,
  216933,
  513833,
  178281,
  358551,
  339998,
  12326,
  482527,
  707945,
  (e) => {
    "use strict";
    var t,
      a,
      n,
      i,
      r,
      s,
      o,
      l,
      c,
      u,
      d,
      p,
      _,
      m,
      g,
      b,
      S,
      y,
      E,
      f,
      h,
      I,
      C,
      P,
      A,
      R,
      T,
      v,
      w,
      x,
      N,
      L,
      k,
      O = e.i(271645);
    function M() {
      return (M = Object.assign.bind()).apply(null, arguments);
    }
    function D() {
      return (D = Object.assign.bind()).apply(null, arguments);
    }
    function U() {
      return (U = Object.assign.bind()).apply(null, arguments);
    }
    function B() {
      return (B = Object.assign.bind()).apply(null, arguments);
    }
    function F() {
      return (F = Object.assign.bind()).apply(null, arguments);
    }
    function j() {
      return (j = Object.assign.bind()).apply(null, arguments);
    }
    function z() {
      return (z = Object.assign.bind()).apply(null, arguments);
    }
    function K() {
      return (K = Object.assign.bind()).apply(null, arguments);
    }
    function q() {
      return (q = Object.assign.bind()).apply(null, arguments);
    }
    function V() {
      return (V = Object.assign.bind()).apply(null, arguments);
    }
    function Y() {
      return (Y = Object.assign.bind()).apply(null, arguments);
    }
    function Q() {
      return (Q = Object.assign.bind()).apply(null, arguments);
    }
    function G() {
      return (G = Object.assign.bind()).apply(null, arguments);
    }
    function H() {
      return (H = Object.assign.bind()).apply(null, arguments);
    }
    function W() {
      return (W = Object.assign.bind()).apply(null, arguments);
    }
    function X() {
      return (X = Object.assign.bind()).apply(null, arguments);
    }
    function $() {
      return ($ = Object.assign.bind()).apply(null, arguments);
    }
    function J() {
      return (J = Object.assign.bind()).apply(null, arguments);
    }
    function Z() {
      return (Z = Object.assign.bind()).apply(null, arguments);
    }
    function ee() {
      return (ee = Object.assign.bind()).apply(null, arguments);
    }
    (e.s(
      [
        "default",
        0,
        (e) =>
          O.createElement(
            "svg",
            M({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 15 14" }, e),
            t ||
              (t = O.createElement("path", {
                fill: "#fff",
                d: "m5.938 1.094.687-.688c.313-.281.781-.281 1.063 0L13.78 6.47c.281.312.281.781 0 1.062l-6.094 6.094c-.28.281-.75.281-1.062 0l-.688-.688a.814.814 0 0 1 0-1.093L9.72 8.25H.75A.72.72 0 0 1 0 7.5v-1a.74.74 0 0 1 .75-.75h8.969L5.938 2.187c-.282-.312-.313-.78 0-1.093",
              })),
          ),
      ],
      194693,
    ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              D({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 8 12" }, e),
              a ||
                (a = O.createElement("path", {
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 1.667,
                  d: "m1.5 11 5-5-5-5",
                })),
            ),
        ],
        597521,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              U({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 25 24" }, e),
              n ||
                (n = O.createElement("path", {
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M5.5 12h14m-7-7 7 7-7 7",
                })),
            ),
        ],
        171946,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              B({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 48 48" }, e),
              i ||
                (i = O.createElement("path", {
                  fill: "#CFD8DC",
                  d: "M5 38V14h38v24c0 2.2-1.8 4-4 4H9c-2.2 0-4-1.8-4-4",
                })),
              r ||
                (r = O.createElement("path", {
                  fill: "#F44336",
                  d: "M43 10v6H5v-6c0-2.2 1.8-4 4-4h30c2.2 0 4 1.8 4 4",
                })),
              s ||
                (s = O.createElement(
                  "g",
                  { fill: "#B71C1C" },
                  O.createElement("circle", { cx: 33, cy: 10, r: 3 }),
                  O.createElement("circle", { cx: 15, cy: 10, r: 3 }),
                )),
              o ||
                (o = O.createElement("path", {
                  fill: "#B0BEC5",
                  d: "M33 3c-1.1 0-2 .9-2 2v5c0 1.1.9 2 2 2s2-.9 2-2V5c0-1.1-.9-2-2-2M15 3c-1.1 0-2 .9-2 2v5c0 1.1.9 2 2 2s2-.9 2-2V5c0-1.1-.9-2-2-2",
                })),
              l ||
                (l = O.createElement("path", {
                  fill: "#90A4AE",
                  d: "M13 20h4v4h-4zm6 0h4v4h-4zm6 0h4v4h-4zm6 0h4v4h-4zm-18 6h4v4h-4zm6 0h4v4h-4zm6 0h4v4h-4zm6 0h4v4h-4zm-18 6h4v4h-4zm6 0h4v4h-4zm6 0h4v4h-4zm6 0h4v4h-4z",
                })),
            ),
        ],
        703085,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              F({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 18 13" }, e),
              c ||
                (c = O.createElement("path", {
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2.333,
                  d: "m1.31 6.8 4.95 4.95 9.899-9.9",
                })),
            ),
        ],
        492669,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              j(
                {
                  xmlns: "http://www.w3.org/2000/svg",
                  fill: "none",
                  stroke: "currentColor",
                  strokeWidth: 1.5,
                  "aria-hidden": "true",
                  className:
                    "checkmark-thin_svg__text-blue-600 checkmark-thin_svg__min-h-6 checkmark-thin_svg__min-w-6 checkmark-thin_svg__max-h-6 checkmark-thin_svg__max-w-6",
                  "data-slot": "icon",
                  viewBox: "0 0 24 24",
                },
                e,
              ),
              u ||
                (u = O.createElement("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  d: "m4.5 12.75 6 6 9-13.5",
                })),
            ),
        ],
        70224,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              z({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24" }, e),
              d ||
                (d = O.createElement("path", {
                  fill: "currentColor",
                  fillRule: "evenodd",
                  d: "M3.172 5.172C2 6.343 2 8.229 2 12s0 5.657 1.172 6.828S6.229 20 10 20h4c3.771 0 5.657 0 6.828-1.172S22 15.771 22 12s0-5.657-1.172-6.828S17.771 4 14 4h-4C6.229 4 4.343 4 3.172 5.172M18.576 7.52a.75.75 0 0 1-.096 1.056l-2.196 1.83c-.887.74-1.605 1.338-2.24 1.746-.66.425-1.303.693-2.044.693s-1.384-.269-2.045-.693c-.634-.408-1.352-1.007-2.239-1.745L5.52 8.577a.75.75 0 0 1 .96-1.153l2.16 1.799c.933.777 1.58 1.315 2.128 1.667.529.34.888.455 1.233.455s.704-.114 1.233-.455c.547-.352 1.195-.89 2.128-1.667l2.159-1.8a.75.75 0 0 1 1.056.097",
                  clipRule: "evenodd",
                })),
            ),
        ],
        19309,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              K(
                {
                  xmlns: "http://www.w3.org/2000/svg",
                  width: "1em",
                  height: "1em",
                  fill: "none",
                  "aria-hidden": "true",
                  style: { fontSize: 20, lineHeight: 20, float: "left" },
                  viewBox: "0 0 24 24",
                },
                e,
              ),
              p || (p = O.createElement("path", { fill: "#f25022", d: "M0 0h10.931v10.931H0z" })),
              _ || (_ = O.createElement("path", { fill: "#7fba00", d: "M12.069 0H23v10.931H12.069z" })),
              m || (m = O.createElement("path", { fill: "#00a4ef", d: "M0 12.069h10.931V23H0z" })),
              g || (g = O.createElement("path", { fill: "#ffb900", d: "M12.069 12.069H23V23H12.069z" })),
            ),
        ],
        106502,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              q({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24" }, e),
              b ||
                (b = O.createElement("path", {
                  fill: "currentColor",
                  d: "m11.4 18.161 7.396-7.396a10.3 10.3 0 0 1-3.326-2.234 10.3 10.3 0 0 1-2.235-3.327L5.839 12.6c-.577.577-.866.866-1.114 1.184a6.6 6.6 0 0 0-.749 1.211c-.173.364-.302.752-.56 1.526l-1.362 4.083a1.06 1.06 0 0 0 1.342 1.342l4.083-1.362c.775-.258 1.162-.387 1.526-.56q.647-.308 1.211-.749c.318-.248.607-.537 1.184-1.114m9.448-9.448a3.932 3.932 0 0 0-5.561-5.561l-.887.887.038.111a8.75 8.75 0 0 0 2.092 3.32 8.75 8.75 0 0 0 3.431 2.13z",
                })),
            ),
        ],
        327293,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              V({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24" }, e),
              S ||
                (S = O.createElement("path", {
                  fill: "none",
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M5 12h14m-7-7v14",
                })),
            ),
        ],
        230268,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              Y({ xmlns: "http://www.w3.org/2000/svg", fill: "currentColor", viewBox: "0 0 20 20" }, e),
              y ||
                (y = O.createElement("path", {
                  fillRule: "evenodd",
                  d: "M10 15.27 16.18 18l-1.64-7.03L19 7.24l-7.19-.61L10 0 8.19 6.63 1 7.24l4.46 3.73L3.82 18z",
                  clipRule: "evenodd",
                })),
            ),
        ],
        779450,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              Q({ xmlns: "http://www.w3.org/2000/svg", "aria-hidden": "true", viewBox: "0 0 24 24" }, e),
              E ||
                (E = O.createElement("path", {
                  fill: "currentColor",
                  d: "M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z",
                })),
            ),
        ],
        492810,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              G({ xmlns: "http://www.w3.org/2000/svg", fill: "#0d766e", viewBox: "0 0 24 24" }, e),
              f ||
                (f = O.createElement("path", {
                  d: "M19.965 8.521Q20 8.26 20 8c0-2.379-2.143-4.288-4.521-3.965C14.786 2.802 13.466 2 12 2s-2.786.802-3.479 2.035C6.138 3.712 4 5.621 4 8q0 .26.035.521C2.802 9.215 2 10.535 2 12s.802 2.785 2.035 3.479A4 4 0 0 0 4 16c0 2.379 2.138 4.283 4.521 3.965C9.214 21.198 10.534 22 12 22s2.786-.802 3.479-2.035C17.857 20.283 20 18.379 20 16q0-.26-.035-.521C21.198 14.785 22 13.465 22 12s-.802-2.785-2.035-3.479m-9.01 7.895-3.667-3.714 1.424-1.404 2.257 2.286 4.327-4.294 1.408 1.42z",
                })),
            ),
        ],
        216933,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              H({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 32 32" }, e),
              h ||
                (h = O.createElement("path", {
                  fill: "#0758B4",
                  d: "M14.333 22.056a.5.5 0 0 0-.506-.142 2.147 2.147 0 0 1-2.569-1.219 3.1 3.1 0 0 0-2.678-1.92 2 2 0 0 1-.657-.151.5.5 0 0 0-.66.283l-3.775 9.926a.5.5 0 0 0 .636.647l3.936-1.415 2.001 3.674A.5.5 0 0 0 10.5 32l.034-.001a.5.5 0 0 0 .433-.322l3.465-9.104a.5.5 0 0 0-.099-.517m14.179 6.776-3.775-9.925a.5.5 0 0 0-.66-.283 2 2 0 0 1-.662.152 3.13 3.13 0 0 0-1.608.58c-.476.335-.845.8-1.064 1.339a2.115 2.115 0 0 1-2.566 1.221.5.5 0 0 0-.609.657l3.465 9.105a.5.5 0 0 0 .433.321L21.5 32a.5.5 0 0 0 .439-.261l2-3.674 3.937 1.415a.5.5 0 0 0 .636-.648",
                })),
              I ||
                (I = O.createElement("path", {
                  fill: "#4294FF",
                  d: "M26.989 9.136a2.07 2.07 0 0 1-.689-2.095 3.04 3.04 0 0 0-.49-2.538 3.12 3.12 0 0 0-2.323-1.279 2.13 2.13 0 0 1-1.818-1.298 3.1 3.1 0 0 0-1.913-1.77 3.14 3.14 0 0 0-2.63.313 2.16 2.16 0 0 1-2.253 0 3.145 3.145 0 0 0-3.78.36c-.33.307-.59.68-.761 1.097a2.13 2.13 0 0 1-1.823 1.299 3.12 3.12 0 0 0-2.32 1.278 3.04 3.04 0 0 0-.487 2.543 2.07 2.07 0 0 1-.696 2.095 3.05 3.05 0 0 0 .006 4.723 2.07 2.07 0 0 1 .688 2.095 3.04 3.04 0 0 0 .49 2.538 3.12 3.12 0 0 0 2.324 1.279 2.13 2.13 0 0 1 1.818 1.298 3.1 3.1 0 0 0 1.912 1.77 3.14 3.14 0 0 0 2.63-.313 2.16 2.16 0 0 1 2.252 0 3.146 3.146 0 0 0 3.781-.36c.33-.307.59-.68.762-1.097a2.13 2.13 0 0 1 1.822-1.299 3.12 3.12 0 0 0 2.32-1.278 3.04 3.04 0 0 0 .488-2.543 2.07 2.07 0 0 1 .695-2.094 3.05 3.05 0 0 0-.006-4.724",
                })),
              C ||
                (C = O.createElement("path", {
                  fill: "#FDFEFF",
                  d: "M16 19a7.5 7.5 0 1 0 0-15 7.5 7.5 0 0 0 0 15",
                })),
              P ||
                (P = O.createElement("path", {
                  fill: "#0758B4",
                  d: "M20.38 10.182a.5.5 0 0 0-.403-.34l-2.439-.355-1.09-2.208a.52.52 0 0 0-.896 0l-1.09 2.209-2.438.354a.5.5 0 0 0-.278.853l1.765 1.72-.416 2.427a.5.5 0 0 0 .724.527L16 14.223l2.18 1.146a.5.5 0 0 0 .726-.527l-.417-2.428 1.765-1.72a.5.5 0 0 0 .127-.512z",
                })),
            ),
        ],
        513833,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              W(
                {
                  xmlns: "http://www.w3.org/2000/svg",
                  fill: "none",
                  stroke: "currentColor",
                  viewBox: "0 0 24 24",
                },
                e,
              ),
              A ||
                (A = O.createElement("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "m9 5 7 7-7 7",
                })),
            ),
        ],
        178281,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              X({ xmlns: "http://www.w3.org/2000/svg", width: 80, height: 78, fill: "none" }, e),
              R ||
                (R = O.createElement("path", {
                  fill: "currentColor",
                  fillRule: "evenodd",
                  d: "M52.865 48.96c-14.623 0-26.433-11.858-26.433-26.433 0 14.575-11.857 26.432-26.432 26.432 14.575 0 26.432 11.81 26.432 26.386 0-14.575 11.81-26.386 26.433-26.386M80 62.597c-8.014 0-14.482-6.514-14.482-14.481 0 7.967-6.514 14.481-14.481 14.481 7.967 0 14.481 6.468 14.481 14.482A14.46 14.46 0 0 1 80 62.597m-8.342-44.054c-9.748 0-17.622-7.873-17.622-17.621 0 9.748-7.873 17.621-17.621 17.621 9.748 0 17.621 7.874 17.621 17.622 0-9.748 7.874-17.622 17.622-17.622",
                  clipRule: "evenodd",
                })),
            ),
        ],
        358551,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              $({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24" }, e),
              T ||
                (T = O.createElement("path", {
                  fill: "currentColor",
                  d: "M9 3V1h6v2zm2 11h2V8h-2zm1 8q-1.85 0-3.488-.712T5.65 19.35t-1.937-2.863T3 13t.713-3.488T5.65 6.65t2.863-1.937T12 4q1.55 0 2.975.5t2.675 1.45l1.4-1.4 1.4 1.4-1.4 1.4Q20 8.6 20.5 10.025T21 13q0 1.85-.713 3.488T18.35 19.35q-1.225 1.225-2.863 1.938T12 22m0-2q2.9 0 4.95-2.05T19 13t-2.05-4.95T12 6 7.05 8.05 5 13t2.05 4.95T12 20m0-7",
                })),
            ),
        ],
        339998,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              J({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24" }, e),
              v ||
                (v = O.createElement("path", {
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M3 11h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zm0 0a9 9 0 1 1 18 0m0 0v5a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2z",
                })),
              w ||
                (w = O.createElement("path", {
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M21 16v2a4 4 0 0 1-4 4h-5",
                })),
            ),
        ],
        12326,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              Z({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24" }, e),
              x || (x = O.createElement("circle", { cx: 12, cy: 6, r: 4, fill: "currentColor" })),
              N ||
                (N = O.createElement("path", {
                  fill: "currentColor",
                  d: "M20 17.5c0 2.485 0 4.5-8 4.5s-8-2.015-8-4.5S7.582 13 12 13s8 2.015 8 4.5",
                })),
            ),
        ],
        482527,
      ),
      e.s(
        [
          "default",
          0,
          (e) =>
            O.createElement(
              "svg",
              ee({ xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 44 44" }, e),
              L || (L = O.createElement("path", { fill: "#FC3F1D", d: "M0 0h44v44H0z" })),
              k ||
                (k = O.createElement("path", {
                  fill: "#fff",
                  d: "M22.952 24.29c1.339 2.933 1.785 3.953 1.785 7.477v4.67h-4.783v-7.875L10.931 8.938h4.99zM28.85 8.938 23 22.233h4.862l5.866-13.295z",
                })),
            ),
        ],
        707945,
      ),
      e.s([], 934337));
  },
  842582,
  76399,
  (e) => {
    "use strict";
    var t = e.i(618566),
      a = e.i(271645);
    e.i(879568);
    var n = e.i(480408),
      i = e.i(866897),
      r = e.i(924254),
      s = e.i(5117);
    (e.s(
      [
        "useCollectParams",
        0,
        () => {
          let e,
            o = (0, t.useSearchParams)(),
            [l, c] = (0, a.useState)(null),
            [u, d] = (0, a.useState)(!1),
            p = () => {
              let e = o ? new URLSearchParams(o.toString()) : void 0,
                t = n.attributionUtil.collectAttributionData(e);
              (0, s.getClientAnalyticsConsent)().allowed && n.attributionUtil.saveAttributionData(t);
              let a = n.attributionUtil.readAttributionData() ?? t;
              return (c(a), d(!0), a);
            },
            _ = () => l || n.attributionUtil.readAttributionData();
          return (
            (0, a.useEffect)(() => {
              u || p();
            }, [o, u]),
            {
              attributionData: _(),
              isInitialized: u,
              initializeAttribution: p,
              getAttributionMetadata: () => {
                let e = _();
                return n.attributionUtil.formatForPaymentMetadata(e);
              },
              clearAttribution: () => {
                (r.accessCookie.removeItem(i.ECookieArg.ATTRIBUTION_STORAGE_KEY), c(null));
              },
              hasAttribution: null !== (e = _()) && Object.keys(e).length > 0,
              getAttributionData: _,
            }
          );
        },
      ],
      76399,
    ),
      e.s([], 842582));
  },
  893826,
  798254,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(271645),
      n = e.i(225352);
    (e.s([], 798254),
      e.s(
        [
          "default",
          0,
          (e) => {
            let { isUserRestoring: i, children: r } = e,
              [s, o] = (0, a.useState)(!1),
              l = (0, a.useCallback)(() => o(!0), []),
              c = (0, a.useMemo)(() => ({ isUserRestoring: i && !s, finishUserRestore: l }), [i, s, l]);
            return (0, t.jsx)(n.CheckoutUserRestoreContext.Provider, { value: c, children: r });
          },
        ],
        893826,
      ));
  },
  225352,
  (e) => {
    "use strict";
    var t = e.i(271645);
    let a = (0, t.createContext)({ isUserRestoring: !1, finishUserRestore: () => void 0 });
    e.s(["CheckoutUserRestoreContext", 0, a, "useCheckoutUserRestore", 0, () => (0, t.useContext)(a)]);
  },
  122612,
  (e) => {
    "use strict";
    (e.i(893826), e.i(798254), e.s([]));
  },
  118046,
  174956,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(455711),
      n = e.i(248256),
      i = e.i(948148);
    (e.i(934337), e.i(703085));
    let r = (e) =>
        (0, t.jsx)("strong", {
          className: "font-semibold text-light-black-custom md:font-normal md:text-inherit",
          children: e,
        }),
      s = [
        (0, t.jsx)(n.Globe, { className: "h-5 w-5" }, "globe"),
        (0, t.jsx)(a.Brain, { className: "h-5 w-5" }, "brain"),
      ];
    (e.s(
      [
        "BENEFITS_REDESIGN_ICONS",
        0,
        s,
        "SUCCESS_NOTICE_MIN_VISIBLE_MS",
        0,
        2e3,
        "usePaymentDetailsList",
        0,
        (e) => {
          let { variant: t, isBrainTrain: a, isBenefitsRedesign: n } = e,
            s = (0, i.useTranslations)();
          switch (t) {
            case "myiq":
              if (a)
                return [
                  { title: s("checkout_page_payment_list_1_no_precise") },
                  { title: s("checkout_page_payment_list_3") },
                  { title: s("bt_checkout_payment_list_improve") },
                ];
              return n
                ? [
                    { title: s.rich("ab_myiq_paywall_benefits_redesign_list_2", { b: r }) },
                    { title: s.rich("ab_myiq_paywall_benefits_redesign_list_3", { b: r }) },
                  ]
                : [
                    { title: s("checkout_page_payment_list_2") },
                    { title: s("checkout_page_payment_list_3") },
                  ];
            case "personality":
              return [
                { title: s("checkout_personality_page_payment_details_1_b") },
                { title: s("checkout_personality_page_payment_details_2_b") },
                { title: s("checkout_personality_page_payment_details_3_b") },
              ];
            case "love_language":
              return [
                { title: s("upsell_page_step_2_2_what_you_will_get_2") },
                { title: s("actionable_strategies") },
                { title: s("with_step_by_step_guidance") },
              ];
            case "depression":
              return [
                { title: s("checkout_depression_checkmark_1") },
                { title: s("checkout_depression_checkmark_2") },
              ];
            case "autism":
              return [
                { title: s("checkout_autism_page_benefits_title_1") },
                { title: s("checkout_autism_page_benefits_title_2") },
                { title: s("checkout_autism_page_benefits_title_3") },
              ];
            case "enneagram":
              return [
                { title: "Discover your exact Enneagram type out of 9" },
                { title: "Understand your core strengths and blind spots" },
                { title: "Learn how your type affects your relationships and career" },
              ];
            default:
              return [];
          }
        },
      ],
      174956,
    ),
      e.i(112015),
      e.i(557213),
      e.s([], 118046));
  },
  112015,
  557213,
  (e) => {
    "use strict";
    var t,
      a = e.i(194613),
      n = (((t = {}).WEEKLY = "weekly"), (t.MONTHLY = "monthly"), (t.QUARTERLY = "quarterly"), t);
    e.s(["EPlanPickerPlan", () => n], 557213);
    let i = [
        {
          id: n.WEEKLY,
          planId: a.EPaynextPlanIds.PLAN_PICKER_WEEKLY,
          planName: "PLAN_PICKER_WEEKLY",
          labelKey: "plan_picker_weekly_label",
          trialPriceKey: "PLAN_PICKER_WEEKLY_TRIAL",
          renewalPriceKey: "PLAN_PICKER_WEEKLY_RENEWAL",
          perDayDivisor: 7,
          disclaimerKey: "plan_picker_disclaimer_weekly",
        },
        {
          id: n.MONTHLY,
          planId: a.EPaynextPlanIds.PLAN_PICKER_MONTHLY,
          planName: "PLAN_PICKER_MONTHLY",
          labelKey: "plan_picker_monthly_label",
          trialPriceKey: "PLAN_PICKER_MONTHLY_TRIAL",
          renewalPriceKey: "PLAN_PICKER_MONTHLY_RENEWAL",
          perDayDivisor: 28,
          disclaimerKey: "plan_picker_disclaimer_month",
          badgeKey: "plan_picker_monthly_badge",
        },
        {
          id: n.QUARTERLY,
          planId: a.EPaynextPlanIds.PLAN_PICKER_QUARTERLY,
          planName: "PLAN_PICKER_QUARTERLY",
          labelKey: "plan_picker_quarterly_label",
          trialPriceKey: "PLAN_PICKER_QUARTERLY_TRIAL",
          renewalPriceKey: "PLAN_PICKER_QUARTERLY_RENEWAL",
          perDayDivisor: 84,
          disclaimerKey: "plan_picker_disclaimer_quarter",
        },
      ],
      r = n.MONTHLY;
    e.s(["DEFAULT_PLAN_PICKER_PLAN", 0, r, "PLAN_PICKER_CONFIG", 0, i], 112015);
  },
  185595,
  266278,
  (e) => {
    "use strict";
    var t = e.i(843476),
      a = e.i(861745),
      n = e.i(948148),
      i = e.i(271645),
      r = e.i(663615),
      s = e.i(926654),
      o = e.i(339386),
      l = e.i(245588);
    e.i(842582);
    var c = e.i(76399);
    e.i(122612);
    var u = e.i(225352);
    e.i(473189);
    var d = e.i(476880),
      p = e.i(352883),
      _ = e.i(891133),
      m = e.i(350635),
      g = e.i(263970),
      b = e.i(622963);
    e.i(910661);
    var S = e.i(642871),
      y = e.i(86596),
      E = e.i(322062),
      f = e.i(386847),
      h = e.i(725397),
      I = e.i(841977);
    e.i(238275);
    var C = e.i(712470);
    e.i(495585);
    var P = e.i(821652),
      A = e.i(230470),
      R = e.i(382963),
      T = e.i(523173),
      v = e.i(134404);
    e.i(568267);
    var w = e.i(154692);
    e.i(470366);
    var x = e.i(504001);
    e.i(491877);
    var N = e.i(758535),
      L = e.i(202042),
      k = e.i(584735),
      O = e.i(915113);
    e.i(80460);
    var M = e.i(998198),
      D = e.i(19576);
    let U = (e) => {
      let { user: i, isChecked: s, onChange: o, hasError: l, isDisabled: c } = e,
        u = (0, n.useTranslations)(),
        d = (0, n.useFormatter)(),
        p = (0, a.useLocale)(),
        _ = "rtl" === (0, D.getLocaleDirection)(p),
        m = i?.currency?.countryCode === "US",
        g = !!(0, O.getIsMarketingSource)(),
        { priceForView: b } = (0, M.getPaymentPlanPrice)({ paymentPlan: "DEMO_PRICE", user: i }),
        { priceForView: S } = (0, M.getPaymentPlanPrice)({ paymentPlan: "MONTH_PRICE", user: i }),
        y = i?.paymentInfo?.paynextAmountToPay || (0, M.getCalculatePriceForView)(b, i),
        E = i?.paymentInfo?.paynextAmountMonth || (0, M.getCalculatePriceForView)(S, i),
        f = d.dateTime(new Date(Date.now() + 6048e5), { day: "numeric", month: "long", year: "numeric" }),
        h = !!l && !s;
      return (0, t.jsxs)("div", {
        id: "checkout-consent-gate",
        className: "relative -mt-2 mb-4 flex flex-col gap-1.5",
        children: [
          (0, t.jsxs)(k.Checkbox, {
            "data-nr": "checkout-consent-checkbox",
            isSelected: s,
            onValueChange: o,
            isDisabled: c,
            radius: "sm",
            classNames: {
              base: "m-0 w-full max-w-full items-start gap-2 p-0",
              wrapper: (0, r.cn)("mt-0.5", h && "before:border-danger"),
              label: (0, r.cn)("text-sm font-normal text-default-600", h && "text-danger"),
            },
            children: [
              g
                ? u("email_page_consent_billing", { trialPrice: y, monthlyPrice: E })
                : u("email_page_consent_billing_trial_end_date", {
                    trialPrice: y,
                    monthlyPrice: E,
                    trialEndDate: f,
                  }),
              g || m ? ` ${u("price_excludes_tax")}` : "",
            ],
          }),
          h &&
            (0, t.jsx)("svg", {
              xmlns: "http://www.w3.org/2000/svg",
              xmlnsXlink: "http://www.w3.org/1999/xlink",
              "aria-hidden": "true",
              role: "img",
              className: (0, r.cn)(
                "absolute top-8 animate-bounce text-danger",
                _ ? "-right-[2px]" : "-left-[2px]",
              ),
              width: "24",
              height: "24",
              viewBox: "0 0 100 100",
              children: (0, t.jsx)("path", {
                fill: "currentColor",
                d: "M78.016 49.132L51.961 12.714a2.52 2.52 0 0 0-2.043-1.051h-.006a2.52 2.52 0 0 0-2.048 1.059L21.977 49.14a2.51 2.51 0 0 0-.183 2.612a2.51 2.51 0 0 0 2.236 1.361h12.183l-.001 32.709a2.514 2.514 0 0 0 2.516 2.515l22.541-.001a2.515 2.515 0 0 0 2.516-2.517V53.114h12.187c.94 0 1.803-.53 2.237-1.367a2.51 2.51 0 0 0-.193-2.615",
              }),
            }),
        ],
      });
    };
    e.i(118046);
    var B = e.i(112015),
      F = e.i(174956),
      j = e.i(823933);
    let z = (e) => {
      let { user: i } = e,
        r = (0, n.useTranslations)(),
        s = (0, a.useLocale)(),
        { priceForView: o, TRIAL_PERIOD_DAYS: l } = (0, M.getPaymentPlanPrice)({
          paymentPlan: "MONTH_PRICE",
          user: i,
        }),
        c = i?.paymentInfo?.paynextAmountMonth || (0, M.getCalculatePriceForView)(o, i),
        u = new Date();
      u.setDate(u.getDate() + l);
      let d = u.toLocaleDateString(s, { year: "numeric", month: "short", day: "numeric" });
      return (0, t.jsxs)("div", {
        className: "mt-3 text-center",
        "data-nr": "checkout-payment-success-notice",
        children: [
          (0, t.jsx)("p", {
            className: "text-base font-semibold text-[#0D0D0E]",
            children: r("checkout_page_payment_success_title"),
          }),
          (0, t.jsx)("p", {
            className: "mt-1 text-sm text-default-600",
            children: r("checkout_page_payment_success_renewal", { date: d, price: c }),
          }),
        ],
      });
    };
    var K = e.i(770703);
    let q = (0, K.default)(() => e.A(615993), { loadableGenerated: { modules: [380091] } }),
      V = (0, K.default)(() => e.A(852306), { loadableGenerated: { modules: [373432] } });
    (e.s([], 185595),
      e.s(
        [
          "CheckoutFormSectionComponent",
          0,
          (e) => {
            let k,
              O,
              {
                user: M,
                isMarketingSource: D,
                variant: K,
                friendEncodedData: Y,
                abMyiqPromoPrice: Q,
                abMyiqAb100Vs199: G,
                containerId: H,
                abMyiqRevolutMonzoBlock: W,
                abMyiqProductFeedbackWidget: X,
                abMyiqPrintCertificateUpsell: $,
                isSecondaryForm: J,
                ftMyiqReviewPlatformSplit: Z,
                isPlanPickerFunnel: ee,
                abMyiqBrazilMastercardOnly: et,
                idSuffix: ea = "",
                selectedPlan: en,
                onPlanChange: ei,
                abMyiqPostPaymentProcessingModal: er,
                isConsentGateHidden: es,
              } = e,
              eo = (0, n.useTranslations)(),
              el = (0, a.useLocale)(),
              ec = (0, L.useRouter)(),
              eu = (0, g.useGlobalStore)((e) => e.checkoutTimerExpired),
              ed = "promo_price" === Q && D,
              ep = eu && !ed && "personality" !== K,
              e_ = (0, S.useQuizStore)((e) => e.secondsPassed),
              em = (0, S.useQuizStore)((e) => e.sectionsResult),
              eg = (0, S.useQuizStore)((e) => e.userScore),
              eb = (0, S.useQuizStore)((e) => e.percentScoreResult),
              eS = (0, m.useDepressionFunnelStore)((e) => e.result),
              ey = (0, S.useQuizStore)((e) => e.handleChangeQuizStore),
              { getAttributionMetadata: eE } = (0, c.useCollectParams)(),
              ef = (0, y.useUserStore)((e) => e.handleChangeUserStore),
              eh = (0, E.useUserSupportContextStore)((e) => e.handleChangeUserSupportContext),
              { isUserRestoring: eI } = (0, u.useCheckoutUserRestore)(),
              [eC, eP] = (0, i.useState)(!1),
              [eA, eR] = (0, i.useState)(!J),
              [eT, ev] = (0, i.useState)(!1),
              [ew, ex] = (0, i.useState)(B.DEFAULT_PLAN_PICKER_PLAN),
              eN = en ?? ew,
              eL = M?.currency?.countryCode,
              ek = (0, h.isUsUk)(eL, (0, f.getClientCity)()),
              eO = ek && !es,
              eM = ek && !D && !ee,
              [eD, eU] = (0, i.useState)(!1),
              [eB, eF] = (0, i.useState)(!1),
              [ej, ez] = (0, i.useState)(!1),
              [eK, eq] = (0, i.useState)(!1),
              eV = (0, b.useModalStore)((e) => e.modalComponent),
              eY = (0, b.useModalStore)((e) => e.handleChangeModalStore);
            (0, i.useEffect)(() => {
              "v1_processing_waiting_modal" === er &&
                (eK
                  ? eY({ modalComponent: "post-payment-processing", isModalVisible: !0 })
                  : "post-payment-processing" === eV && eY({ modalComponent: null, isModalVisible: !1 }));
            }, [eK, er]);
            let eQ = (0, j.getPlanPickerPlanId)(eN),
              eG = (0, j.getPlanPickerPlanName)(eN),
              { trigger: eH } = (0, A.useRefreshTokenMutation)(),
              { trigger: eW } = (0, R.useUpdateUserInDatabaseMutation)(),
              { trigger: eX } = (0, C.useCreateSessionMutation)(),
              { trigger: e$ } = (0, P.useCreatePaynextPaymentMutation)(),
              { trigger: eJ } = (0, A.useCreatePaynextSubscriptionMutation)(),
              eZ = async () => {
                (ev(!0), ec.replace(v.EClientRoutes.SIGN_IN));
              },
              e0 = async () => {
                await eH({
                  user: M,
                  abMyiqRevolutMonzoBlock: W,
                  abMyiqBrazilMastercardOnly: et,
                  ...(Q && D ? { abMyiqPromoPrice: Q } : {}),
                  ...("v1_trial_1_99" === G ? { abMyiqAb100Vs199: G } : {}),
                  ...((0, _.getIsUsA1Campaign)() ? { isUsA1Campaign: !0 } : {}),
                })
                  .then((e) => {
                    let t = !!e?.data?.isSubscribed;
                    (eP(t),
                      (0, x.trackClientEvents)({
                        event: T.EAnalyticEvents.CHECKOUT_SUBSCRIPTION_STATUS,
                        user: M,
                        params: { is_subscribed: t, subscription_status: e?.data?.subscriptionStatus || "" },
                      }));
                  })
                  .finally(() => eR(!1));
              };
            (0, i.useEffect)(() => {
              J || eI || (M && (M?.email ? e0() : (ec.replace(v.EClientRoutes.START), ec.refresh())));
            }, [M?.email, eI]);
            let e1 = eA || eI;
            return (0, t.jsx)(s.Skeleton, {
              isLoaded: !e1,
              className: (0, r.cn)("min-h-[136px] w-full rounded-large", !ee && "mt-[1rem]"),
              children:
                e1 || eC
                  ? (0, t.jsxs)("div", {
                      className:
                        "flex h-full w-full flex-col items-center justify-center rounded-large bg-default-100 p-4 text-center text-default-700",
                      children: [
                        (0, t.jsx)("strong", {
                          className: "mx-auto",
                          children: eo("checkout_page_you_are_subscribed"),
                        }),
                        (0, t.jsx)(w.ButtonComponent, {
                          text: eo("btn_go_further"),
                          onClick: eZ,
                          className: "mt-2 w-full",
                          isLoading: eT,
                        }),
                      ],
                    })
                  : ((k = eE()),
                    (O = { ...(0, d.getMixpanelFallbackMetadata)(), ...k }),
                    (0, t.jsxs)(t.Fragment, {
                      children: [
                        ee &&
                          (0, t.jsx)(q, {
                            user: M,
                            selectedPlan: eN,
                            onPlanChange: ei ?? ex,
                            isMarketingSource: D,
                            idSuffix: ea,
                          }),
                        eO &&
                          (0, t.jsx)(U, {
                            user: M,
                            isChecked: eB,
                            onChange: (e) => {
                              (eF(e), e && ez(!1));
                            },
                            hasError: ej,
                            isDisabled: eK,
                          }),
                        (0, t.jsx)(
                          N.CheckoutFormComponent,
                          {
                            attributionData: O,
                            handleCheckoutSuccess: (e) => {
                              let t = (0, l.getQuizAnswersFromLocalStorage)(),
                                a = (0, o.getNonImageQuizAnswersFromLocalStorage)();
                              (M?.email &&
                                M?.id &&
                                eh({
                                  email: M.email,
                                  userId: M.id,
                                  subscriptionId: e.payment?.subscription?.id || null,
                                }),
                                (0, p.onCheckoutSuccess)({
                                  data: e,
                                  isMarketingSource: D,
                                  user: M,
                                  triggerUpdateUser: eW,
                                  variant: K,
                                  router: ec,
                                  results: M?.results || {
                                    userScore: eg || I.MINIMAL_IQ_SCORE,
                                    spentTime: e_,
                                    sectionsResult: em,
                                    percentScoreResult: eb,
                                  },
                                  depressionResult: eS,
                                  friendEncodedData: Y,
                                  quizAnswers: t,
                                  nonImageQuizAnswers: a,
                                  triggerCreateSession: eX,
                                  triggerCreatePaynextPayment: e$,
                                  triggerCreatePaynextSubscription: eJ,
                                  abMyiqPromoPrice: Q,
                                  abMyiqAb100Vs199: G,
                                  abMyiqRevolutMonzoBlock: W,
                                  abMyiqBrazilMastercardOnly: et,
                                  handleChangeUserStore: ef,
                                  handleChangeQuizStore: ey,
                                  clearQuizAnswersFromLocalStorage: l.clearQuizAnswersFromLocalStorage,
                                  abMyiqProductFeedbackWidget: X,
                                  abMyiqPrintCertificateUpsell: $,
                                  taxAmount: e.taxAmount,
                                  taxAmountSubtotal: e.taxAmountSubtotal,
                                  ftMyiqReviewPlatformSplit: Z,
                                  checkoutTimerExpired: ep,
                                  isPlanPickerFunnel: ee,
                                  planPickerPlanId: ee ? e.payment?.subscription?.plan?.id || eQ : void 0,
                                  planPickerPlanName: ee ? eG : void 0,
                                  successNoticeMinVisibleMs: eM ? F.SUCCESS_NOTICE_MIN_VISIBLE_MS : 0,
                                }));
                            },
                            locale: el,
                            user: M,
                            containerId: H,
                            abMyiqPromoPrice: Q,
                            abMyiqAb100Vs199: G,
                            abMyiqRevolutMonzoBlock: W,
                            abMyiqBrazilMastercardOnly: et,
                            isMarketingSource: D,
                            isCheckoutTimerExpired: ep,
                            reuseSession: J,
                            isPlanPickerFunnel: ee,
                            planName: ee ? eG : void 0,
                            paynextPlanId: ee ? eQ : void 0,
                            paymentsEnabled: eO ? eB : void 0,
                            onPaymentsBlocked: () => {
                              (ez(!0),
                                (() => {
                                  let e = document.getElementById("checkout-consent-gate");
                                  if (!e) return;
                                  let { top: t, bottom: a } = e.getBoundingClientRect();
                                  (t >= 0 && a <= window.innerHeight) ||
                                    e.scrollIntoView({ behavior: "smooth", block: "center" });
                                })());
                            },
                            onProcessingChange: eq,
                            onPaymentSucceeded: eM ? () => eU(!0) : void 0,
                            onAlreadySubscribed: e0,
                          },
                          ee ? M?.paymentInfo?.paynextClientSessionId : void 0,
                        ),
                        eD && (0, t.jsx)(z, { user: M }),
                        ee && (0, t.jsx)(V, { user: M, selectedPlan: eN }),
                      ],
                    })),
            });
          },
        ],
        266278,
      ));
  },
  473189,
  823933,
  (e) => {
    "use strict";
    (e.i(476880), e.i(352883));
    var t = e.i(112015);
    let a = (e) => t.PLAN_PICKER_CONFIG.find((t) => t.id === e);
    (e.s(
      [
        "getPlanPickerConfig",
        0,
        a,
        "getPlanPickerPlanId",
        0,
        (e) => a(e)?.planId ?? "",
        "getPlanPickerPlanName",
        0,
        (e) => a(e)?.planName ?? "",
      ],
      823933,
    ),
      e.s([], 473189));
  },
  476880,
  882345,
  (e) => {
    "use strict";
    e.i(569311);
    var t = e.i(896855);
    let a = () =>
      Object.fromEntries(
        Object.entries({
          utm_campaign: t.mixpanelClient.peopleGetProperty("utm_campaign"),
          utm_campaign_id: t.mixpanelClient.peopleGetProperty("utm_campaign_id"),
          utm_source: t.mixpanelClient.peopleGetProperty("utm_source"),
          utm_medium: t.mixpanelClient.peopleGetProperty("utm_medium"),
          utm_adgroup_id:
            t.mixpanelClient.peopleGetProperty("utm_adgroup_id") ||
            t.mixpanelClient.peopleGetProperty("utm_adset_id"),
          utm_adgroup:
            t.mixpanelClient.peopleGetProperty("utm_adgroup") ||
            t.mixpanelClient.peopleGetProperty("utm_adset"),
          utm_ad_id: t.mixpanelClient.peopleGetProperty("utm_ad_id"),
          utm_term: t.mixpanelClient.peopleGetProperty("utm_term"),
          utm_content: t.mixpanelClient.peopleGetProperty("utm_content"),
          gclid: t.mixpanelClient.peopleGetProperty("gclid"),
          fbclid: t.mixpanelClient.peopleGetProperty("fbclid"),
          kwai_click_id: t.mixpanelClient.peopleGetProperty("kwai_click_id"),
          referral_domain: t.mixpanelClient.peopleGetProperty("referral_domain"),
          utm_ad_name: t.mixpanelClient.peopleGetProperty("utm_ad_name"),
          utm_target_id: t.mixpanelClient.peopleGetProperty("utm_target_id"),
          wbraid: t.mixpanelClient.peopleGetProperty("wbraid"),
          utm_content_id: t.mixpanelClient.peopleGetProperty("utm_content_id"),
        }).filter((e) => {
          let [t, a] = e;
          return null != a;
        }),
      );
    e.s(
      [
        "getMixpanelFallbackMetadata",
        0,
        a,
        "getPaymentAttributionData",
        0,
        (e) => {
          let t = {};
          for (let [e, n] of Object.entries(a())) t[e] = String(n);
          return { ...t, ...(e || {}) };
        },
      ],
      476880,
    );
    var n = e.i(117595);
    (e.i(618566), e.i(271645));
    var i = e.i(866897);
    e.s(
      [
        "getIsBrCampaign",
        0,
        () =>
          "true" === n.default.get(i.ECookieArg.BR_CAMPAIGN) ||
          "1" === new URLSearchParams(window.location.search).get("br"),
      ],
      882345,
    );
  },
  352883,
  (e) => {
    "use strict";
    e.i(879568);
    var t = e.i(480408),
      a = e.i(882345),
      n = e.i(49587),
      i = e.i(891133),
      r = e.i(523173),
      s = e.i(429067),
      o = e.i(279816);
    e.i(756503);
    var l = e.i(542516);
    e.i(470366);
    var c = e.i(504001);
    e.i(569311);
    var u = e.i(896855),
      d = e.i(194613),
      p = e.i(476880);
    let _ = async (e) => {
      let {
          data: _,
          isMarketingSource: m,
          user: g,
          router: b,
          variant: S,
          friendEncodedData: y = "",
          quizAnswers: E = null,
          nonImageQuizAnswers: f = null,
          triggerCreateSession: h,
          triggerCreatePaynextSubscription: I,
          abMyiqPromoPrice: C,
          abMyiqAb100Vs199: P,
          abMyiqRevolutMonzoBlock: A,
          abMyiqBrazilMastercardOnly: R,
          abMyiqProductFeedbackWidget: T,
          abMyiqPrintCertificateUpsell: v,
          handleChangeUserStore: w,
          clearQuizAnswersFromLocalStorage: x,
          handleChangeQuizStore: N,
          ftMyiqReviewPlatformSplit: L,
          checkoutTimerExpired: k,
          results: O,
          depressionResult: M,
          isPlanPickerFunnel: D,
          planPickerPlanId: U,
          planPickerPlanName: B,
          successNoticeMinVisibleMs: F = 0,
        } = e,
        j = Date.now(),
        z = "promo_price" === C && !!m,
        K = {
          app_version: "v2",
          currency: g?.paymentInfo?.paynextAmountCurrency,
          email: g?.email,
          customer_id: g?.id,
          mixpanel_user_id: g?.id,
          payment_id: _.payment.id,
          payment_card_brand: _?.paymentСardBrand,
          payment_method_type: _?.paymentMethodType,
          user_id: g?.id,
          language: g?.locale,
          country: g?.currency?.countryCode,
          payment_processor: _.paymentProcessor,
          flow_type: "web_onboarding",
          error_code: "",
          funnel: g?.funnel,
          plan_name: D && B ? B : z ? "SPLIT_TRIAL_PROMO_PRICE" : "SPLIT_TRIAL",
          ...(D && { plan_picker_funnel: !0 }),
          ...((0, n.getIsRedesignFunnel)() && { redesign_funnel: !0 }),
          paymentOrchestrator: "PayNext",
          amount: Number(g?.paymentInfo?.paynextAmountPayment),
          paynextSessionId: g?.paymentInfo?.paynextClientSessionId,
          paynextPaymentMethod: _?.paymentMethodType,
          attributionData: _.attributionData,
          paynextPaymentCardBrand: _?.paymentСardBrand,
          paynextPaymentCurrency: g?.paymentInfo?.paynextAmountCurrency,
          paynextPaymentAmount: Number(g?.paymentInfo?.paynextAmountPayment),
          paynextSubscriptionId: g?.paymentInfo?.subscriptionId,
          displayedCurrency: g?.paymentInfo?.paynextAmountDisplayedCurrency,
          displayedAmount: g?.paymentInfo?.paynextAmountDisplayed,
          supabase_user_id: g?.id || "",
          first_name: g?.paymentInfo?.firstName || "",
          last_name: g?.paymentInfo?.lastName || "",
          hostname: `${l.envClient.NEXT_PUBLIC_BILLING_HOSTNAME}`,
          sub_order_country: g?.currency?.countryCode || "",
          paynextPlanID:
            D && U ? U : z ? d.EPaynextPlanIds.SPLIT_TRIAL_PROMO_PRICE : d.EPaynextPlanIds.SPLIT_TRIAL,
          billing_weeks: g?.paymentInfo?.billing_weeks,
          billing_price: g?.paymentInfo?.billing_price,
        },
        q = g?.funnel || "myiq",
        V = "depression" === q ? "depression_funnel" : q,
        Y = g?.test_result || {},
        Q = {
          ...Y,
          [V]: {
            ...Y[V],
            status: "analyzed",
            result: "depression" === q ? (M ?? Y[V]?.result ?? null) : Y[V]?.result || null,
            answers: Y[V]?.answers || {},
          },
        },
        G = _.payment,
        H = t.attributionUtil.readAttributionData()?.kwai_click_id,
        W = await I({
          userInfo: {
            ...(!g?.mainFunnel &&
              (() => {
                switch (S) {
                  case "personality":
                    return {
                      personality_quiz: "analyzed",
                      love_quiz: null,
                      funnel: "personality",
                      quiz: null,
                      mainFunnel: "personality",
                    };
                  case "love_language":
                    return {
                      personality_quiz: null,
                      love_quiz: "analyzed",
                      funnel: "love_language",
                      quiz: null,
                      mainFunnel: "love_language",
                    };
                  case "autism":
                    return {
                      personality_quiz: null,
                      love_quiz: null,
                      autism_quiz: "analyzed",
                      funnel: "autism",
                      quiz: null,
                      mainFunnel: "autism",
                    };
                  case "enneagram":
                    return {
                      personality_quiz: null,
                      love_quiz: null,
                      enneagram_quiz: "analyzed",
                      funnel: "enneagram",
                      quiz: null,
                      mainFunnel: "enneagram",
                    };
                  default:
                    return {
                      personality_quiz: null,
                      love_quiz: null,
                      funnel: "myiq",
                      quiz: "analyzed",
                      mainFunnel: "myiq",
                    };
                }
              })()),
            ...g,
            results: O ?? g?.results,
            firstName: _.firstName,
            lastName: _.lastName,
            isMarketingSource: !!m,
            email_validation_status: "skipped",
            ...(E && E.length > 0 ? { quiz_answers: E } : {}),
            ...(f && f.length > 0 ? { quiz_answers_additional: f } : {}),
            paymentInfo: {
              ...g?.paymentInfo,
              id: G.id,
              paynextCustomerId: G.customer.id,
              paymentMethodType: _.paymentMethodType,
              paymentСardBrand: _.paymentСardBrand,
              currencyCode: _.currencyCode,
              paymentProcessor: _.paymentProcessor,
              paymentProcessorId: _.processorMerchantId,
              statementDescriptor: _.statementDescriptor,
              taxAmount: _.taxAmount,
              taxAmountSubtotal: _.taxAmountSubtotal,
            },
          },
          subscription: { id: G?.subscription?.id || "" },
          testResult: Q,
          friendEncodedData: y,
          ...(m && C ? { abMyiqPromoPrice: C } : {}),
          ...("v1_trial_1_99" === P ? { abMyiqAb100Vs199: P } : {}),
          ...((0, i.getIsUsA1Campaign)() ? { isUsA1Campaign: !0 } : {}),
          ...((0, a.getIsBrCampaign)() ? { isBrCampaign: !0 } : {}),
          ...(D && U ? { planPickerPlanId: U } : {}),
          checkoutTimerExpired: k,
          metadata: {
            ...K,
            plan_name: k ? "SPLIT_TRIAL_SECOND_EXPIRED" : "SPLIT_TRIAL_SECOND",
            paynextPlanID: k
              ? d.EPaynextPlanIds.SPLIT_TRIAL_SECOND_EXPIRED
              : d.EPaynextPlanIds.SPLIT_TRIAL_SECOND,
            flow_type: "second_payment",
            ...("block" === A || "not_block" === A ? { ab_myiq_revolut_monzo_block: A } : {}),
            ...("v1_mastercard_only" === R || "control" === R ? { ab_myiq_brazil_mastercard_only: R } : {}),
            ...(0, p.getMixpanelFallbackMetadata)(),
            ...(H && { kwai_click_id: H }),
          },
        });
      (W.success
        ? (0, s.markNativeReturningCustomer)()
        : (0, c.trackClientEvents)({
            user: g,
            event: r.EAnalyticEvents.SUBSCRIPTION_CREATE_ERROR,
            params: { error_message: JSON.stringify(W.error) },
          }),
        (0, c.trackClientEvents)({
          user: g,
          event: r.EAnalyticEvents.SUBSCRIPTION_PURCHASED_SUCCESS,
          params: {
            ...K,
            paynextCustomerId: G.customer.id,
            paynextPaymentID: G.id,
            paynextAmountUsd: G.amount_usd,
            paynextPaymentAmount: G.amount,
            amount: G.amount,
            ab_myiq_promo_price: C,
            isMarketingSource: !!m,
          },
        }),
        (0, c.setPeopleAnalytic)({
          user_token: g?.userToken,
          referral: y,
          payment_method_type: _.paymentMethodType,
          payment_card_brand: _.paymentСardBrand,
          funnel: g?.funnel,
          ab_myiq_product_feedback_widget: T,
          ab_myiq_print_certificate_upsell: v,
          ft_myiq_review_platform_split: L,
        }),
        "production" === l.envClient.NEXT_PUBLIC_APP_ENV && u.mixpanelClient.startSessionRecording(),
        await h(g),
        (0, c.setPeopleAnalytic)({ email_validation_status: "skipped" }),
        w({
          user: {
            email_validation_status: "skipped",
            billingSubscriptionData: void 0,
            isPaynextSubscribed: !0,
            nextBillingDate: void 0,
            paynextSubscription: void 0,
            paymentInfo: {
              ...g?.paymentInfo,
              paynextCustomerId: G.customer.id,
              paymentMethodType: _.paymentMethodType,
              paymentProcessor: _.paymentProcessor,
              paymentProcessorId: _.processorMerchantId,
              statementDescriptor: _.statementDescriptor,
              taxAmount: _.taxAmount,
              taxAmountSubtotal: _.taxAmountSubtotal,
            },
          },
        }));
      let X = F - (Date.now() - j);
      (X > 0 && (await new Promise((e) => setTimeout(e, X))),
        b.replace((0, o.getReportLink)(S)),
        b.refresh(),
        N({ userScore: null, spentTime: 0, sectionsResult: null, percentScoreResult: null }),
        x());
    };
    e.s(["onCheckoutSuccess", 0, _]);
  },
  49587,
  302433,
  (e) => {
    "use strict";
    var t = e.i(117595),
      a = e.i(866897),
      n = e.i(134404);
    let i = [
        n.EClientRoutes.QUIZ,
        n.EClientRoutes.QUIZ_ANALYZING,
        n.EClientRoutes.EMAIL,
        n.EClientRoutes.CHECKOUT,
      ],
      r = (e) => "true" !== e;
    (e.s(
      [
        "REDESIGN_FUNNEL_PROPERTY",
        0,
        "redesign_funnel",
        "isRedesignFunnelPage",
        0,
        (e) => i.includes(e),
        "isRedesignFunnelRequest",
        0,
        r,
      ],
      302433,
    ),
      e.s(["getIsRedesignFunnel", 0, () => r(t.default.get(a.ECookieArg.LEGACY_FUNNEL))], 49587));
  },
  891133,
  (e) => {
    "use strict";
    var t = e.i(117595),
      a = e.i(618566),
      n = e.i(271645),
      i = e.i(866897);
    let r = "us_a1";
    e.s([
      "getIsUsA1Campaign",
      0,
      () =>
        "true" === t.default.get(i.ECookieArg.US_A1_CAMPAIGN) ||
        new URLSearchParams(window.location.search).get("p") === r,
      "useIsUsA1Campaign",
      0,
      () => {
        let e = (0, a.useSearchParams)();
        return (0, n.useMemo)(
          () => "true" === t.default.get(i.ECookieArg.US_A1_CAMPAIGN) || e.get("p") === r,
          [e],
        );
      },
    ]);
  },
  877045,
  28639,
  (e) => {
    "use strict";
    var t = e.i(117595),
      a = e.i(866897),
      n = e.i(157273),
      i = e.i(190899);
    let r = () => {
        i.accessSessionStorageUtil.removeItem(n.StorageKeys.CANCELLATION_STORAGE_SESSION);
      },
      s = () => {
        let e = i.accessSessionStorageUtil.getItem(n.StorageKeys.CANCELLATION_STORAGE_SESSION);
        if (!e) return null;
        let t = ((e) => {
          try {
            return JSON.parse(e);
          } catch {
            return null;
          }
        })(e);
        return t?.token && t.expiresAt > Date.now() ? t.token : (r(), null);
      };
    (e.s(
      [
        "getCancellationSessionHeaders",
        0,
        () => {
          let e = s();
          return e ? { "X-Cancellation-Session": e } : {};
        },
        "getCancellationStorageSession",
        0,
        s,
        "grantCancellationAccess",
        0,
        (e) => {
          if (
            (t.default.set(a.ECookieArg.ACCESS_TO_CANCELLATION, "true", { expires: 1 / 24 }),
            (navigator.cookieEnabled && "true" === t.default.get(a.ECookieArg.ACCESS_TO_CANCELLATION)) || !e)
          )
            return;
          let r = { token: e, expiresAt: Date.now() + 33e5 };
          i.accessSessionStorageUtil.setItem(n.StorageKeys.CANCELLATION_STORAGE_SESSION, JSON.stringify(r));
        },
        "revokeCancellationAccess",
        0,
        () => {
          (t.default.remove(a.ECookieArg.ACCESS_TO_CANCELLATION), r());
        },
      ],
      28639,
    ),
      e.s([], 877045));
  },
  279816,
  (e) => {
    "use strict";
    var t = e.i(134404);
    e.s([
      "getReportLink",
      0,
      (e) => {
        switch (e) {
          case "love_language":
            return t.EClientRoutes.REPORT_LOVE;
          case "personality":
            return t.EClientRoutes.REPORT_PERSONALITY;
          case "careers":
            return t.EClientRoutes.REPORT_CAREERS;
          case "work":
            return t.EClientRoutes.REPORT_WORK;
          case "burnout":
            return t.EClientRoutes.REPORT_BURNOUT;
          case "emotional":
            return t.EClientRoutes.REPORT_EMOTIONAL;
          case "depression":
            return t.EClientRoutes.REPORT_DEPRESSION_FUNNEL;
          case "time_management":
            return t.EClientRoutes.REPORT_TIME_MANAGEMENT;
          case "adhd":
            return t.EClientRoutes.REPORT_ADHD;
          case "attachment":
            return t.EClientRoutes.REPORT_ATTACHMENT;
          case "imposter_syndrome":
            return t.EClientRoutes.REPORT_IMPOSTER_SYNDROME;
          case "procrastination":
            return t.EClientRoutes.REPORT_PROCRASTINATION;
          case "psychological_archetypes":
            return t.EClientRoutes.REPORT_PSYCHOLOGICAL_ARCHETYPES;
          case "anxiety":
            return t.EClientRoutes.REPORT_ANXIETY;
          case "confidence":
            return t.EClientRoutes.REPORT_CONFIDENCE;
          case "strengths":
            return t.EClientRoutes.REPORT_STRENGTHS;
          case "autism":
            return t.EClientRoutes.REPORT_AUTISM;
          case "enneagram":
            return t.EClientRoutes.REPORT_ENNEAGRAM;
          default:
            return t.EClientRoutes.REPORT;
        }
      },
    ]);
  },
  350635,
  (e) => {
    "use strict";
    var t = e.i(768834),
      a = e.i(579473);
    let n = { result: null, completionSeconds: null },
      i = (0, t.create)()(
        (0, a.devtools)(
          (0, a.persist)(
            (e) => ({
              ...n,
              setDepressionResult: (t, a) => e({ result: t, completionSeconds: a }),
              resetDepressionResult: () => e(n),
            }),
            { name: "depression-funnel", storage: (0, a.createJSONStorage)(() => localStorage) },
          ),
          { name: "depression-funnel" },
        ),
      );
    e.s(["useDepressionFunnelStore", 0, i]);
  },
  263970,
  (e) => {
    "use strict";
    var t = e.i(768834),
      a = e.i(579473);
    e.i(756503);
    var n = e.i(542516);
    let i = (0, t.create)()(
      (0, a.devtools)(
        (e, t) => ({
          isMobileMenuVisible: !1,
          isFooterBannerVisible: !1,
          activeFunnel: null,
          checkoutTimerMins: 6,
          checkoutTimerSeconds: 59,
          checkoutTimerExpired: !1,
          checkoutTimerReady: !1,
          isTimerOverlappingMainButton: !1,
          isAutoScrolling: !1,
          isPaymentFormExpanded: !1,
          isPaymentFormLostVisibility: !1,
          isPaymentFormOpened: !1,
          checkoutReachedLastBullet: !1,
          checkoutScrolledPastLastBullet: !1,
          handleChangeGlobalStore: (t) => e((e) => ({ ...e, ...t })),
          updateCheckoutTimer: () => {
            let { checkoutTimerMins: a, checkoutTimerSeconds: n, checkoutTimerExpired: i } = t();
            i ||
              (0 === n
                ? a > 0
                  ? e({ checkoutTimerMins: a - 1, checkoutTimerSeconds: 59 * !!a })
                  : e({ checkoutTimerMins: 1, checkoutTimerSeconds: 0 })
                : e({ checkoutTimerSeconds: n - 1 }));
          },
          initCheckoutTimer: (t) => {
            e({
              checkoutTimerMins: Math.floor(t / 60),
              checkoutTimerSeconds: t % 60,
              checkoutTimerExpired: !1,
              checkoutTimerReady: !0,
            });
          },
          expireCheckoutTimer: () =>
            e({
              checkoutTimerExpired: !0,
              checkoutTimerMins: 0,
              checkoutTimerSeconds: 0,
              checkoutTimerReady: !0,
            }),
          setAutoScrolling: function (t) {
            let a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1e3;
            (e({ isAutoScrolling: t }),
              t &&
                setTimeout(() => {
                  e({ isAutoScrolling: !1 });
                }, a));
          },
        }),
        { enabled: "production" !== n.envClient.NEXT_PUBLIC_NODE_ENV },
      ),
    );
    e.s(["useGlobalStore", 0, i]);
  },
  910661,
  642871,
  (e) => {
    "use strict";
    var t = e.i(768834),
      a = e.i(579473);
    e.i(756503);
    var n = e.i(542516);
    let i = {
        userScore: null,
        spentTime: 0,
        secondsPassed: 0,
        isQuizFinished: !1,
        sectionsResult: null,
        percentScoreResult: null,
        accuracyResult: null,
        isShowTestimonials: !1,
        showScienceBased: !1,
        isLoadingPageBeforeQuizTest: !0,
        timerResetKey: 0,
        currentQuestionIndex: 1,
        totalQuestions: 31,
        motivationalPercentages: null,
        userAnswers: null,
        additionalAnswers: null,
        questionTimes: null,
        currentQuestionId: null,
        showResultButton: !1,
        isShowMotivation: !1,
        quizHeaderQuestionCountVisible: !1,
        quizPaginationTopRightOnly: !1,
        quizTimerFrozen: !1,
      },
      r = (0, t.create)()(
        (0, a.persist)(
          (0, a.devtools)(
            (e) => ({
              ...i,
              handleChangeQuizStore: (t) => e((e) => ({ ...e, ...t })),
              resetQuizStore: () => e(i),
            }),
            { enabled: "production" !== n.envClient.NEXT_PUBLIC_NODE_ENV },
          ),
          {
            name: "quiz",
            version: 1,
            partialize: (e) => ({
              secondsPassed: e.secondsPassed,
              timerResetKey: e.timerResetKey,
              currentQuestionIndex: e.currentQuestionIndex,
              totalQuestions: e.totalQuestions,
              isQuizFinished: e.isQuizFinished,
              accuracyResult: e.accuracyResult,
              userAnswers: e.userAnswers,
              additionalAnswers: e.additionalAnswers,
              questionTimes: e.questionTimes,
              currentQuestionId: e.currentQuestionId,
              showResultButton: e.showResultButton,
              isShowMotivation: e.isShowMotivation,
            }),
          },
        ),
      );
    (e.s(
      [
        "fullResetQuizStore",
        0,
        () => {
          r.getState().resetQuizStore();
        },
        "useQuizStore",
        0,
        r,
      ],
      642871,
    ),
      e.s([], 910661));
  },
  322062,
  (e) => {
    "use strict";
    var t = e.i(768834),
      a = e.i(579473);
    let n = { email: null, userId: null, subscriptionId: null },
      i = (0, t.create)()(
        (0, a.persist)(
          (e) => ({
            ...n,
            handleChangeUserSupportContext: (t) =>
              e((e) => ({
                email: t.email ?? e.email,
                userId: t.userId ?? e.userId,
                subscriptionId: t.subscriptionId ?? e.subscriptionId,
              })),
            clearUserSupportContext: () => e(n),
          }),
          { name: "user_support_context", version: 1 },
        ),
      );
    e.s(["useUserSupportContextStore", 0, i]);
  },
  190899,
  (e) => {
    "use strict";
    e.s([
      "accessSessionStorageUtil",
      0,
      {
        getItem: (e) => {
          try {
            return sessionStorage.getItem(e);
          } catch {
            return null;
          }
        },
        setItem: (e, t) => {
          try {
            sessionStorage.setItem(e, t);
          } catch {
            return;
          }
        },
        removeItem: (e) => {
          try {
            sessionStorage.removeItem(e);
          } catch {
            return;
          }
        },
      },
    ]);
  },
  386847,
  (e) => {
    "use strict";
    var t = e.i(117595),
      a = e.i(866897);
    e.s([
      "getClientCity",
      0,
      () => t.default.get(a.ECookieArg.CITY),
      "getClientCountry",
      0,
      () => t.default.get(a.ECookieArg.COUNTRY),
    ]);
  },
  915113,
  (e) => {
    "use strict";
    var t = e.i(117595),
      a = e.i(190899),
      n = e.i(866897),
      i = e.i(157273);
    let r = new Set([
      "DE",
      "RO",
      "IT",
      "CZ",
      "PL",
      "NL",
      "HU",
      "BE",
      "BG",
      "CH",
      "PT",
      "MT",
      "AT",
      "SE",
      "LT",
      "IS",
      "LU",
      "HR",
      "LV",
      "EE",
      "SK",
      "GR",
      "AE",
      "SA",
    ]);
    e.s([
      "getIsMarketingSource",
      0,
      () => {
        if ("DE" === (t.default.get(n.ECookieArg.COUNTRY) || "US")) return "";
        let e = a.accessSessionStorageUtil.getItem(i.StorageKeys.MARKETING_ID),
          r = a.accessSessionStorageUtil.getItem(i.StorageKeys.MARKETING_SOURCE);
        return e || r || "";
      },
      "getIsMarketingSourceForSpecificCountry",
      0,
      () => {
        let e = t.default.get(n.ECookieArg.COUNTRY) || "US";
        if (!r.has(e)) return "";
        let s = a.accessSessionStorageUtil.getItem(i.StorageKeys.MARKETING_ID),
          o = a.accessSessionStorageUtil.getItem(i.StorageKeys.MARKETING_SOURCE);
        return s || o || "";
      },
      "getIsPersonalityMarketingSource",
      0,
      () => !!a.accessSessionStorageUtil.getItem(i.StorageKeys.PERSONALITY_MARKETING_SOURCE),
    ]);
  },
  491877,
  758535,
  (e) => {
    "use strict";
    let t = (0, e.i(770703).default)(() => e.A(963075), {
      loadableGenerated: { modules: [149278] },
      ssr: !1,
    });
    (e.s(["CheckoutFormComponent", 0, t], 758535), e.i(56395), e.s([], 491877));
  },
  56395,
  178668,
  (e) => {
    "use strict";
    let t,
      a = "u" > typeof crypto && crypto.randomUUID && crypto.randomUUID.bind(crypto),
      n = new Uint8Array(16),
      i = [];
    for (let e = 0; e < 256; ++e) i.push((e + 256).toString(16).slice(1));
    let r = function (e, r, s) {
      if (a && !r && !e) return a();
      let o =
        (e = e || {}).random ??
        e.rng?.() ??
        (function () {
          if (!t) {
            if ("u" < typeof crypto || !crypto.getRandomValues)
              throw Error(
                "crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported",
              );
            t = crypto.getRandomValues.bind(crypto);
          }
          return t(n);
        })();
      if (o.length < 16) throw Error("Random bytes length must be >= 16");
      if (((o[6] = (15 & o[6]) | 64), (o[8] = (63 & o[8]) | 128), r)) {
        if ((s = s || 0) < 0 || s + 16 > r.length)
          throw RangeError(`UUID byte range ${s}:${s + 15} is out of buffer bounds`);
        for (let e = 0; e < 16; ++e) r[s + e] = o[e];
        return r;
      }
      return (function (e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return (
          i[e[t + 0]] +
          i[e[t + 1]] +
          i[e[t + 2]] +
          i[e[t + 3]] +
          "-" +
          i[e[t + 4]] +
          i[e[t + 5]] +
          "-" +
          i[e[t + 6]] +
          i[e[t + 7]] +
          "-" +
          i[e[t + 8]] +
          i[e[t + 9]] +
          "-" +
          i[e[t + 10]] +
          i[e[t + 11]] +
          i[e[t + 12]] +
          i[e[t + 13]] +
          i[e[t + 14]] +
          i[e[t + 15]]
        ).toLowerCase();
      })(o);
    };
    var s = e.i(709275),
      o = e.i(190899);
    e.i(756503);
    var l = e.i(542516);
    e.i(999126);
    var c = e.i(548248);
    let u = async (e) => {
        try {
          await d();
          let t = [];
          for (let a of e) {
            let e = await (0, s.loadStripe)(a.key),
              n = await e?.createRadarSession();
            n?.radarSession?.id &&
              (t.push({ stripeRadarSessionId: n?.radarSession?.id, name: a.name }),
              o.accessSessionStorageUtil.setItem(a.name, n.radarSession.id));
          }
          let a = Object.assign({}, ...t.map((e) => ({ [e.name]: e.stripeRadarSessionId }))),
            n = p();
          return (
            (0, c.debugUtil)({ text: "createSessionsForClient", value: { ...a, ...n } }),
            { ...a, ...n }
          );
        } catch (t) {
          let e = t?.response?.body?.error?.message || t?.message || "Something went wrong";
          throw ((0, c.debugUtil)({ text: "createSessionsForClient error", value: t }), Error(e));
        }
      },
      d = async () => {
        try {
          return new Promise((e, t) => {
            if (window.Stripe) e();
            else {
              let a = "stripe-js-script",
                n = document.getElementById(a);
              if (n)
                (n.addEventListener("load", () => {
                  window.Stripe ? e() : t(Error("Stripe.js failed to load."));
                }),
                  n.addEventListener("error", () => {
                    t(Error("Stripe.js failed to load."));
                  }));
              else {
                let n = document.createElement("script");
                ((n.id = a),
                  (n.src = "https://js.stripe.com/v3/"),
                  (n.async = !0),
                  (n.onload = () => {
                    window.Stripe ? e() : t(Error("Stripe.js failed to load."));
                  }),
                  (n.onerror = () => t(Error("Stripe.js failed to load."))),
                  document.head.appendChild(n));
              }
            }
          });
        } catch (e) {
          (0, c.debugUtil)({ text: "loadStripeClient error", value: e });
          return;
        }
      },
      p = () => {
        let e = r(),
          t = document.createElement("script");
        ((t.id = "paypal-script"),
          (t.src = `https://c.paypal.com/da/r/fb.js?f=${e}&s=${l.envClient.NEXT_PUBLIC_PAY_PAL_MERCHANT_ID}_checkout-page&sandbox=false`),
          document.body.appendChild(t));
        let a = document.createElement("script");
        ((a.id = "paypal-fraudnet-script"),
          (a.src = "https://c.paypal.com/da/r/fb.js"),
          document.body.appendChild(a));
        let n = { paypal_session_id: e, paypal_client_metadata_id: e };
        return (
          Object.entries(n).forEach((e) => {
            let [t, a] = e;
            o.accessSessionStorageUtil.setItem(t, a);
          }),
          n
        );
      };
    (e.s(["createSessionsForClient", 0, u], 178668), e.s([], 56395));
  },
  194613,
  (e) => {
    "use strict";
    e.i(756503);
    var t,
      a,
      n = e.i(542516),
      i =
        (((t = {}).SPLIT_TRIAL = "price_28ab40cd-1eb6-44c4-a11d-409cd7a8c59f"),
        (t.SPLIT_TRIAL_SECOND = "price_24a1725c-cbbe-4f34-9eca-876b9e7093da"),
        (t.SPLIT_TRIAL_PAYPAL = "price_31e0469d-6f9a-47be-b92e-c75e8556f8bc"),
        (t.SPLIT_TRIAL_CASHAPP = "price_a48b42ac-8ea2-457f-a781-99a8fede9a5d"),
        (t.SPLIT_TRIAL_PROMO_PRICE = "price_c1a24246-8ef8-4105-a614-c0a4b71178dd"),
        (t.TRIVIA_HEARTS_OTP_5 = "price_4e0bb9fb-d47b-44fc-92a2-f4a57b2920a8"),
        (t.TRIVIA_HEARTS_OTP_20 = "price_07b5b189-4240-4b4d-b635-32c16f31f888"),
        (t.TRIVIA_HEARTS_OTP_50 = "price_e271dce4-d347-411f-970f-a71cb2f78d97"),
        (t.TRIVIA_FIFTY_OTP_5 = "price_11d417ca-2d98-46a2-a591-2ac9e95c5f6b"),
        (t.TRIVIA_FIFTY_OTP_15 = "price_2de429d3-5b21-47c4-ab9b-2788a42b8183"),
        (t.TRIVIA_FIFTY_OTP_40 = "price_bce8ff41-3836-483d-9a21-c75d14d651f7"),
        (t.TRIVIA_EXTRA_TIME_OTP_5 = "price_cc0e09fe-22cd-4ff8-a0a4-005c4bdf8f0c"),
        (t.TRIVIA_EXTRA_TIME_OTP_15 = "price_67f3a405-5cd6-4851-90da-e1e81b36e934"),
        (t.TRIVIA_EXTRA_TIME_OTP_40 = "price_adecce61-6e20-4acd-8404-4bad3572ba29"),
        (t.DOWNGRADED_SUBSCRIPTION = "price_bf2864f3-4835-4ffc-a188-0284b4da920d"),
        (t.DOWNGRADED_SUBSCRIPTION_6_99 = "price_564c5f0f-4a71-4e37-b664-e3d0083251ad"),
        (t.DOWNGRADED_SUBSCRIPTION_9_99 = "price_a5dbadc4-ff56-4bad-bbb6-3b3376e6e6c6"),
        (t.PRINTED_CERTIFICATE_UPSELL = "price_94bdf33b-db92-4aff-bab4-2bb088dbb904"),
        (t.FAST_TRACK_REPORT_UNLOCK = "price_a34a46de-fca6-4175-8b3c-3a358b800070"),
        (t.BUY_TRIVIA_UPSELL_V3 = "price_f11cc629-4cf7-4224-9f5f-5d305fd8d370"),
        (t.BUY_TRIVIA_UPSELL_EXIT = "price_b0b581bd-d991-401b-bb68-38e8b4ffc9ea"),
        (t.SKIP_TRIAL_AB = "price_c466a672-e9a6-4f76-b0c4-389475ec3afd"),
        (t.SKIP_TRIAL_AB_V2 = "price_27971406-8be3-47b1-b8fc-e3bf5bef8de7"),
        (t.RETAKE_IQ_BASE = "price_16bd8029-114a-4032-a5d5-3758e45ff7cb"),
        (t.RETAKE_IQ_ADVANCED = "price_3198f7da-adf6-4720-a6c3-35ada36febf3"),
        (t.SPLIT_TRIAL_TIMER_EXPIRED = "price_b2ed6deb-b7ff-433b-a71c-08da6b9819b1"),
        (t.SPLIT_TRIAL_SECOND_EXPIRED = "price_bc127d58-a19b-4b5b-acae-5e680e598166"),
        (t.PLAN_PICKER_WEEKLY = "price_3877b33a-5505-4aa2-98a5-406002d21e99"),
        (t.PLAN_PICKER_MONTHLY = "price_25eb958a-86b7-4918-9e40-d0c9ae5417b5"),
        (t.PLAN_PICKER_QUARTERLY = "price_74eb2df1-146c-4d6e-b1b8-7b7a68537d36"),
        t),
      r =
        (((a = {}).SPLIT_TRIAL = "price_97cced15-887e-453e-9473-61e4aeab9219"),
        (a.SPLIT_TRIAL_SECOND = "price_becb0124-0330-4b26-8f9a-a14a5c704bd3"),
        (a.SPLIT_TRIAL_PAYPAL = "price_95321730-8959-454b-899c-75be62f284ac"),
        (a.SPLIT_TRIAL_CASHAPP = "price_8fcb11dd-4161-4dc7-bdef-6d567565c1bc"),
        (a.SPLIT_TRIAL_PROMO_PRICE = "price_4cf92053-5660-49a6-a2b8-1a442b46b5c0"),
        (a.TRIVIA_HEARTS_OTP_5 = "price_1a9e2116-fce9-4f06-9a1f-23dc7a8be283"),
        (a.TRIVIA_HEARTS_OTP_20 = "price_70829646-1a27-4044-b8b2-bb4e5a5cd398"),
        (a.TRIVIA_HEARTS_OTP_50 = "price_c684ed53-441e-4af5-8107-3c7ca577f971"),
        (a.TRIVIA_FIFTY_OTP_5 = "price_1928343b-22e6-4c58-a9e6-3922c278650c"),
        (a.TRIVIA_FIFTY_OTP_15 = "price_b277eb6a-c329-437f-85bb-3b370e0d84e1"),
        (a.TRIVIA_FIFTY_OTP_40 = "price_2d40f14d-9ea9-434a-986b-74f929a25de3"),
        (a.TRIVIA_EXTRA_TIME_OTP_5 = "price_6b06ba8e-9b0c-424a-9d9d-d669b2165786"),
        (a.TRIVIA_EXTRA_TIME_OTP_15 = "price_34771465-2aa9-4747-87d6-b62eb0e841db"),
        (a.TRIVIA_EXTRA_TIME_OTP_40 = "price_426595f3-e83b-4a55-bf2e-7c00389f551a"),
        (a.DOWNGRADED_SUBSCRIPTION = "price_bcddbded-fefc-4673-9179-f9830b8c9352"),
        (a.DOWNGRADED_SUBSCRIPTION_6_99 = "price_ba942205-783f-4936-9b5e-95ae3a172b7b"),
        (a.DOWNGRADED_SUBSCRIPTION_9_99 = "price_bd425670-dd91-45bc-afd9-c80975d3956e"),
        (a.PRINTED_CERTIFICATE_UPSELL = "price_02fa8dc7-1606-4bb8-8260-8491d31b0ee1"),
        (a.FAST_TRACK_REPORT_UNLOCK = "price_2218ce0c-1547-4235-a80f-1e59e298e5e6"),
        (a.BUY_TRIVIA_UPSELL_V3 = "price_a72859eb-603a-4c04-8a7b-86815cbba4eb"),
        (a.BUY_TRIVIA_UPSELL_EXIT = "price_498359c1-d083-41ee-a3ee-3ec769e913db"),
        (a.SKIP_TRIAL_AB = "price_2f9f67da-6c99-41b4-ac03-e4180a9cd0df"),
        (a.SKIP_TRIAL_AB_V2 = "price_4f7cc975-6e4e-4683-b4e7-fd320bf01b63"),
        (a.RETAKE_IQ_BASE = "price_7b75f6d6-5884-4690-a6e7-d59c9ad93e91"),
        (a.RETAKE_IQ_ADVANCED = "price_36b27094-d8bd-4297-9bd9-4b21caed26eb"),
        (a.SPLIT_TRIAL_TIMER_EXPIRED = "price_ec5a9c51-933a-45d3-ac6f-b64405797f03"),
        (a.SPLIT_TRIAL_SECOND_EXPIRED = "price_874b2f4c-33c6-4d2f-8eef-c5a20e265c3b"),
        (a.PLAN_PICKER_WEEKLY = "price_bcce7c71-aec4-4af8-8dea-6a14956a2b2e"),
        (a.PLAN_PICKER_MONTHLY = "price_dcae0301-9a8d-4986-95a0-90983f7809d9"),
        (a.PLAN_PICKER_QUARTERLY = "price_2425461b-cb08-44f2-86cd-f6fe17ccf2a5"),
        a);
    let s = "production" === n.envClient.NEXT_PUBLIC_PAYNEXT_ENV ? i : r;
    e.s(["EPaynextPlanIds", 0, s]);
  },
]);
