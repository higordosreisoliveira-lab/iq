// Cancellation Portal Controller
document.addEventListener("DOMContentLoaded", () => {
  const isCancelPage = document.getElementById("cancellation-portal-view");
  if (!isCancelPage) return;

  const authSection = document.getElementById("cancel-auth-section");
  const manageSection = document.getElementById("cancel-manage-section");
  const successSection = document.getElementById("cancel-success-section");

  const emailInput = document.getElementById("cancel-email-input");
  const btnLookup = document.getElementById("btn-lookup-subscription");
  const btnConfirmCancel = document.getElementById("btn-confirm-cancel");
  const btnKeepDiscount = document.getElementById("btn-keep-discount");

  if (btnLookup) {
    btnLookup.addEventListener("click", (e) => {
      e.preventDefault();
      const email = emailInput ? emailInput.value.trim() : "";
      if (!email || !email.includes("@")) {
        alert("Please enter a valid email address.");
        return;
      }

      btnLookup.disabled = true;
      btnLookup.innerHTML = `<span class="inline-flex items-center gap-2"><svg class="animate-spin h-5 w-5" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path></svg> Searching...</span>`;

      setTimeout(() => {
        if (authSection) authSection.classList.add("hidden");
        if (manageSection) manageSection.classList.remove("hidden");
      }, 700);
    });
  }

  if (btnConfirmCancel) {
    btnConfirmCancel.addEventListener("click", () => {
      if (manageSection) manageSection.classList.add("hidden");
      if (successSection) successSection.classList.remove("hidden");

      // Mark user subscription as cancelled
      const session = localStorage.getItem("myiq_user_session");
      if (session) {
        try {
          const s = JSON.parse(session);
          s.active = false;
          s.cancelledAt = new Date().toISOString();
          localStorage.setItem("myiq_user_session", JSON.stringify(s));
        } catch (e) {}
      }
    });
  }

  if (btnKeepDiscount) {
    btnKeepDiscount.addEventListener("click", () => {
      alert("Discount applied! Your monthly fee is now reduced by 50% ($14.99 / R$ 59.99/mo). Your benefits remain active.");
      const isPt = window.location.pathname.includes('/pt-BR');
      window.location.href = isPt ? '/pt-BR/dashboard' : '/dashboard';
    });
  }
});
