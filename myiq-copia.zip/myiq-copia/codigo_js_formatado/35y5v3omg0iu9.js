(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  656979,
  (e) => {
    "use strict";
    var t = e.i(843476),
      n = e.i(88653),
      o = e.i(962607),
      a = e.i(444113),
      i = e.i(824511),
      r = e.i(117595),
      s = e.i(37727),
      l = e.i(948148),
      d = e.i(271645),
      c = e.i(663615),
      u = e.i(866897),
      m = e.i(134404);
    e.i(568267);
    var h = e.i(154692),
      f = e.i(5117);
    e.i(470366);
    var p = e.i(506032),
      g = e.i(202042);
    e.s([
      "default",
      0,
      () => {
        let e = (0, l.useTranslations)(),
          [x, w] = (0, d.useState)(!1),
          v = (0, d.useRef)(null);
        ((0, d.useEffect)(() => {
          let e = r.default.get(u.ECookieArg.COUNTRY),
            t = !!r.default.get(u.ECookieArg.COOKIE_CONSENT);
          w((0, f.isAnalyticsGatedRegion)(e) && !t);
        }, []),
          (0, d.useEffect)(() => {
            let e = document.documentElement;
            if (!x || !v.current) return void e.style.setProperty("--cookie-consent-h", "0px");
            let t = v.current,
              n = () => e.style.setProperty("--cookie-consent-h", `${t.offsetHeight}px`);
            n();
            let o = new ResizeObserver(n);
            return (
              o.observe(t),
              () => {
                (o.disconnect(), e.style.setProperty("--cookie-consent-h", "0px"));
              }
            );
          }, [x]));
        let b = (e) => {
          (r.default.set(u.ECookieArg.COOKIE_CONSENT, e, {
            expires: (0, f.getConsentExpiresDays)(e),
            sameSite: "lax",
          }),
            e === f.COOKIE_CONSENT_VALUE.ACCEPTED
              ? (0, p.grantAnalyticsConsent)()
              : (0, p.revokeAnalyticsConsent)(),
            w(!1));
        };
        return (0, t.jsx)(a.LazyMotion, {
          features: o.domAnimation,
          children: (0, t.jsx)(n.AnimatePresence, {
            children:
              x &&
              (0, t.jsxs)(t.Fragment, {
                children: [
                  (0, t.jsx)(i.m.div, {
                    initial: { opacity: 0 },
                    animate: { opacity: 1 },
                    exit: { opacity: 0 },
                    transition: { duration: 0.25, ease: "easeOut" },
                    onClick: () => w(!1),
                    className: "fixed inset-0 z-[199] bg-[#0B0C27]/60 backdrop-blur-sm md:hidden",
                  }),
                  (0, t.jsxs)(i.m.div, {
                    ref: v,
                    id: "cookie-consent-banner",
                    initial: { opacity: 0, y: 24 },
                    animate: { opacity: 1, y: 0 },
                    exit: { opacity: 0, y: 24 },
                    transition: { duration: 0.25, ease: "easeOut" },
                    className: (0, c.cn)(
                      "fixed inset-x-4 bottom-4 z-[200] rounded-2xl border border-[#101828]/[0.08] bg-white p-6 shadow-2xl",
                      "md:inset-x-0 md:bottom-0 md:rounded-none md:border-x-0 md:border-b-0 md:border-t md:bg-white/95 md:py-3 md:shadow-[0_-8px_24px_rgba(16,24,40,0.06)] md:backdrop-blur-lg md:backdrop-saturate-150",
                    ),
                    children: [
                      (0, t.jsx)("button", {
                        type: "button",
                        "aria-label": "Close",
                        onClick: () => w(!1),
                        className: "absolute right-3 top-3 text-[#52525B] md:hidden",
                        children: (0, t.jsx)(s.X, { className: "h-5 w-5" }),
                      }),
                      (0, t.jsxs)("div", {
                        className:
                          "flex flex-col items-center gap-4 text-center md:flex-row md:items-center md:gap-6 md:text-left",
                        children: [
                          (0, t.jsxs)("div", {
                            className: "w-full flex-1 text-sm leading-snug",
                            children: [
                              (0, t.jsx)("p", {
                                className:
                                  "mb-2 whitespace-pre-line text-base font-semibold text-gray-900 xs-sm:whitespace-normal",
                                children: e("cookie_consent_title"),
                              }),
                              (0, t.jsxs)("p", {
                                className: "break-words text-[#52525B]",
                                children: [
                                  e("cookie_consent_text"),
                                  " ",
                                  e.rich("cookie_consent_learn_more", {
                                    policy: (e) =>
                                      (0, t.jsx)(g.Link, {
                                        href: m.EClientRoutes.COOKIE,
                                        className: "text-gray underline",
                                        children: e,
                                      }),
                                  }),
                                ],
                              }),
                            ],
                          }),
                          (0, t.jsxs)("div", {
                            className: "flex w-full flex-col-reverse gap-2.5 md:w-80 md:flex-row",
                            children: [
                              (0, t.jsx)(h.ButtonComponent, {
                                text: e("cookie_consent_reject"),
                                size: "sm",
                                variant: "bordered",
                                className:
                                  "h-12 min-w-0 text-base hover:bg-green-custom hover:text-white md:h-8 md:grow md:basis-0 md:text-sm",
                                onClick: () => b(f.COOKIE_CONSENT_VALUE.REJECTED),
                              }),
                              (0, t.jsx)(h.ButtonComponent, {
                                text: e("cookie_consent_accept"),
                                size: "sm",
                                variant: "bordered",
                                className:
                                  "h-12 min-w-0 text-base hover:bg-green-custom hover:text-white md:h-8 md:grow md:basis-0 md:text-sm",
                                onClick: () => b(f.COOKIE_CONSENT_VALUE.ACCEPTED),
                              }),
                            ],
                          }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
          }),
        });
      },
    ]);
  },
  81295,
  (e) => {
    "use strict";
    var t = e.i(843476),
      n = e.i(770703),
      o = e.i(217255),
      a = e.i(861745),
      i = e.i(271645),
      r = e.i(663615),
      s = e.i(409835),
      l = e.i(926654),
      d = e.i(134404),
      c = e.i(86596),
      u = e.i(622963),
      m = e.i(202042),
      h = e.i(19576),
      f = e.i(429067);
    e.i(238275);
    var p = e.i(712470),
      g = e.i(382963),
      x = e.i(523173),
      w = e.i(297989);
    e.i(470366);
    var v = e.i(504001);
    e.i(80460);
    var b = e.i(973654),
      y = e.i(948148),
      C = e.i(742214);
    e.i(568267);
    var k = e.i(154692);
    e.i(680460);
    var S = e.i(885944);
    let E = (e) => {
        let { onLeaveReview: n, onSkipReview: o, isLoading: a, user: i } = e,
          r = (0, y.useTranslations)();
        return (0, t.jsxs)(C.ModalContent, {
          className:
            "grid max-h-[calc(100*var(--vh,1vh))] w-[calc(100%-24px)] max-w-[430px] gap-4 rounded-lg p-6 sm:w-[calc(100%-32px)] landscape:overflow-y-auto",
          children: [
            (0, t.jsx)("div", {
              className: "grid justify-items-center gap-2 text-center [&_svg]:w-[82px]",
              children: (0, t.jsx)(S.ModalHeaderComponent, {
                title: r("checkout_promo_page_loving_experience"),
                subtitle: r(
                  i?.isSpecialPromo
                    ? "checkout_promo_page_ask_a_review_reddit"
                    : "checkout_promo_page_ask_a_review",
                ),
              }),
            }),
            (0, t.jsxs)("div", {
              className: "flex flex-col items-center gap-3",
              children: [
                (0, t.jsx)(k.ButtonComponent, {
                  size: "sm",
                  fullWidth: !0,
                  text: r("checkout_promo_page_leave_a_review"),
                  target: "_blank",
                  opt: { isLoading: a, onClick: n },
                }),
                (0, t.jsx)(k.ButtonComponent, {
                  size: "sm",
                  variant: "default",
                  fullWidth: !0,
                  text: r("checkout_promo_page_skip_review"),
                  opt: { onClick: o },
                }),
              ],
            }),
          ],
        });
      },
      A = (e) => {
        let { sessionId: n } = e,
          o = (0, u.useModalStore)((e) => e.isOpenAskModalFromBanner),
          a = (0, u.useModalStore)((e) => e.linkToRedirectAfterReviewModal),
          r = (0, w.useReviewStore)((e) => e.handleChangeReviewStore),
          s = (0, u.useModalStore)((e) => e.handleChangeModalStore),
          l = (0, u.useModalStore)((e) => e.modalProps),
          h = l?.redirectRoute || d.EClientRoutes.GAMES,
          [y, C] = (0, i.useState)(!1),
          k = (0, m.useRouter)(),
          S = (0, c.useUserStore)((e) => e.user),
          A = (0, c.useUserStore)((e) => e.handleChangeUserStore),
          { trigger: j } = (0, g.useUpdateUserInDatabaseMutation)(),
          { trigger: _ } = (0, p.useCreateSessionMutation)(),
          M = async (e) => {
            (await _(S), k.replace(e), k.refresh());
          },
          L = async () => {
            await j({
              email: S?.email || "",
              userInfo: {
                ...S,
                isPromoVersion: S?.isPromoVersion || "false",
                onTimePayments: [b.EOffers.SKIP],
              },
            }).then(async () => {
              (await M(d.EClientRoutes.BASE_PROFILE), C(!1), s({ isModalVisible: !1 }));
            });
          },
          P = async (e) => {
            "left" === e
              ? (o
                  ? await j({
                      email: S?.email || "",
                      userInfo: {
                        ...S,
                        isPromoVersion: S?.isPromoVersion || "false",
                        onTimePayments: [b.EOffers.SKIP],
                      },
                    }).then(async () => {
                      await M(d.EClientRoutes.BASE_PROFILE);
                    })
                  : a &&
                    (await j({
                      email: S?.email || "",
                      userInfo: {
                        ...S,
                        isPromoVersion: S?.isPromoVersion || "false",
                        onTimePayments: [b.EOffers.SKIP],
                      },
                    }).then(async () => {
                      await M(a);
                    })),
                s({ isModalVisible: !1 }))
              : await T();
          },
          T = async () => {
            if ((C(!0), S?.isSpecialPromo)) {
              (O(), await L());
              return;
            }
            O(S?.review_link);
            let e = S?.funnel || "myiq",
              t = S?.test_result || {},
              n = {
                ...t,
                [e]: {
                  ...t[e],
                  status: "analyzed",
                  result: t[e]?.result || null,
                  answers: t[e]?.answers || {},
                },
              };
            (await j({
              email: S?.email || "",
              userInfo: {
                ...S,
                isPromoVersion: S?.isPromoVersion || "false",
                isProductFeedbackModalShown: !0,
              },
              testResult: n,
            }).then(async () => {
              (A({ user: { isProductFeedbackModalShown: !0 } }),
                await _(S).then(() => {
                  let e = S?.review_link,
                    t = !!e?.includes("reviews.io");
                  e && t
                    ? (k.refresh(),
                      k.replace(d.EClientRoutes.REPORT),
                      window.history.pushState(null, "", d.EClientRoutes.REPORT),
                      (0, f.requestNativeStoreReview)() || window.open(e, "_blank", "noopener,noreferrer"))
                    : (k.replace(h),
                      window.history.pushState(null, "", h),
                      (0, f.requestNativeStoreReview)() ? k.push(h) : k.push(e || h));
                }));
            }),
              C(!1),
              s({ isModalVisible: !1 }));
          },
          O = (e) => {
            (0, v.trackClientEvents)({
              event: x.EAnalyticEvents.PAGE_CLICKED,
              params: {
                page_name: "leaveAReviewButtonClicked",
                page_title: "Checkout promo",
                ...(e ? { review_link: e } : {}),
              },
              sessionId: n,
            });
          };
        return (
          (0, i.useEffect)(() => {
            r({ isViewedReviewModal: !0 });
          }, []),
          (0, t.jsx)(E, {
            onLeaveReview: () => {
              P("right");
            },
            isLoading: y,
            onSkipReview: () => {
              P("left");
            },
            user: S,
          })
        );
      },
      j = (0, n.default)(() => e.A(242788).then((e) => e.WriteAReviewModalComponent), {
        loadableGenerated: { modules: [409632] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "708px", width: "100%" } }),
      }),
      _ = (0, n.default)(() => e.A(827836).then((e) => e.CongratulationsIntroModalComponent), {
        loadableGenerated: { modules: [658353] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "225px", width: "100%" } }),
      }),
      M = (0, n.default)(() => e.A(649712).then((e) => e.ProfileSettingsModalComponent), {
        loadableGenerated: { modules: [463572] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "225px", width: "100%" } }),
      }),
      L = (0, n.default)(() => e.A(871619).then((e) => e.CardUpdaterModalComponent), {
        loadableGenerated: { modules: [657997] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "225px", width: "100%" } }),
      }),
      P = (0, n.default)(() => e.A(277784).then((e) => e.AdblockWarningModalComponent), {
        loadableGenerated: { modules: [223196] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "225px", width: "100%" } }),
      }),
      T = (0, n.default)(() => e.A(875101).then((e) => e.GameQuitModalComponent), {
        loadableGenerated: { modules: [727908] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "225px", width: "100%" } }),
      }),
      O = (0, n.default)(() => e.A(691482).then((e) => e.RetakeQuizModalQuitComponent), {
        loadableGenerated: { modules: [607899] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "300px", width: "100%" } }),
      }),
      R = (0, n.default)(() => e.A(527980).then((e) => e.WarningFewerQuestionsModalComponent), {
        loadableGenerated: { modules: [952331] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "300px", width: "100%" } }),
      }),
      I = (0, n.default)(() => e.A(899130).then((e) => e.TriviaPurchaseModalComponent), {
        loadableGenerated: { modules: [335769] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "225px", width: "100%" } }),
      }),
      N = (0, n.default)(() => e.A(72812).then((e) => e.TriviaXPBonusModalComponent), {
        loadableGenerated: { modules: [734280] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "225px", width: "100%" } }),
      }),
      K = (0, n.default)(() => e.A(954146).then((e) => e.TriviaAchivedBonusModalComponent), {
        loadableGenerated: { modules: [158503] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "225px", width: "100%" } }),
      }),
      G = (0, n.default)(() => e.A(160974).then((e) => e.ReportFeedbackModalComponent), {
        loadableGenerated: { modules: [284533] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "225px", width: "100%" } }),
      }),
      z = (0, n.default)(() => e.A(726396), {
        loadableGenerated: { modules: [195013] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "300px", width: "100%" } }),
      }),
      V = (0, n.default)(() => e.A(495679).then((e) => e.RetakeIQPurchaseModalComponent), {
        loadableGenerated: { modules: [72575] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "270px", width: "100%" } }),
      }),
      B = (0, n.default)(() => e.A(155273).then((e) => e.PaymentProcessedOtherTabModalComponent), {
        loadableGenerated: { modules: [228632] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "225px", width: "100%" } }),
      }),
      U = (0, n.default)(() => e.A(602160).then((e) => e.PostPaymentProcessingModalComponent), {
        loadableGenerated: { modules: [889900] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "225px", width: "100%" } }),
      }),
      D = (0, n.default)(() => e.A(254941).then((e) => e.PrintedCertificateSuccessModalComponent), {
        loadableGenerated: { modules: [39869] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "225px", width: "100%" } }),
      }),
      F = (0, n.default)(() => e.A(368531).then((e) => e.PrintedCertificateConfirmModalComponent), {
        loadableGenerated: { modules: [833323] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "225px", width: "100%" } }),
      }),
      H = (0, n.default)(() => e.A(397269).then((e) => e.FastTrackConfirmModalComponent), {
        loadableGenerated: { modules: [250096] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "225px", width: "100%" } }),
      }),
      W = (0, n.default)(() => e.A(356372).then((e) => e.EnterNameCertificateModalComponent), {
        loadableGenerated: { modules: [739939] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "225px", width: "100%" } }),
      }),
      q = (0, n.default)(() => e.A(466157).then((e) => e.CheckoutPaymentModalComponent), {
        loadableGenerated: { modules: [775494] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "500px", width: "100%" } }),
      }),
      Q = (0, n.default)(() => e.A(470633).then((e) => e.PaywallExitModalComponent), {
        loadableGenerated: { modules: [827627] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "420px", width: "100%" } }),
      }),
      $ = (0, n.default)(() => e.A(599518).then((e) => e.InAppBrowserDetectedModalComponent), {
        loadableGenerated: { modules: [556098] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "225px", width: "100%" } }),
      }),
      X = (0, n.default)(() => e.A(342885).then((e) => e.CertificateEmailSentModalComponent), {
        loadableGenerated: { modules: [498487] },
        ssr: !1,
        loading: () => (0, t.jsx)(l.Skeleton, { isLoaded: !1, style: { height: "420px", width: "100%" } }),
      });
    e.s(
      [
        "default",
        0,
        () => {
          let e = (0, c.useUserStore)((e) => e.user),
            n = (0, a.useLocale)(),
            l = "rtl" === (0, h.getLocaleDirection)(n),
            f = (0, m.usePathname)(),
            p = (0, u.useModalStore)((e) => e.isModalVisible),
            g = (0, u.useModalStore)((e) => e.modalComponent),
            x = (0, u.useModalStore)((e) => e.handleChangeModalStore),
            w = (0, u.useModalStore)((e) => e.modalProps),
            v = "ask-a-review" === g,
            b = "congratulations-intro" === g,
            y = "card-updater" === g,
            C = "adblock-warning" === g,
            k = "game-quit" === g,
            S = "retake-quiz-modal-quit" === g,
            E = "warning-fewer-questions" === g,
            J = "trivia-purchase" === g,
            Y = "trivia-xp-bonus" === g,
            Z = "trivia-achieved-bonus" === g,
            ee = "report-feedback" === g,
            et = "cancellation-downgrade-offer" === g,
            en = "retake-iq-purchase" === g,
            eo = "payment-processed-other-tab" === g,
            ea = "post-payment-processing" === g,
            ei = "printed-certificate-success" === g,
            er = "printed-certificate-confirm" === g,
            es = "fast-track-confirm" === g,
            el = "enter-name-certificate" === g,
            ed = "checkout-payment" === g,
            ec = "paywall-exit" === g,
            eu = "certificate-email-sent" === g,
            em = w?.paymentPlan === "BUY_TRIVIA_UPSELL_EXIT",
            eh =
              b ||
              w?.isDailyStreakFirst ||
              S ||
              E ||
              J ||
              ee ||
              et ||
              en ||
              Z ||
              eo ||
              ea ||
              ec ||
              ei ||
              er ||
              es,
            ef = v || k || S || E || eo || ea || J || et || eo;
          return (
            (0, i.useEffect)(() => {
              if (!p) return;
              let e = () => {
                let e = 0.01 * window.innerHeight;
                document.documentElement.style.setProperty("--vh", `${e}px`);
              };
              e();
              let t = () => e(),
                n = () => setTimeout(e, 100);
              return (
                window.addEventListener("resize", t),
                window.addEventListener("orientationchange", n),
                () => {
                  (window.removeEventListener("resize", t),
                    window.removeEventListener("orientationchange", n));
                }
              );
            }, [p]),
            (0, i.useEffect)(() => {
              k && f !== d.EClientRoutes.QUIZ_TRIVIA && x({ isModalVisible: !1, modalComponent: null });
            }, [f, k]),
            (0, i.useEffect)(() => {
              ea &&
                !f.startsWith(d.EClientRoutes.CHECKOUT) &&
                x({ isModalVisible: !1, modalComponent: null });
            }, [f, ea]),
            (0, t.jsxs)(s.Modal, {
              isDismissable:
                !(b || w?.isDailyStreakFirst) &&
                !k &&
                !S &&
                !E &&
                !C &&
                !J &&
                !ee &&
                !en &&
                !Z &&
                !eo &&
                !ea &&
                !ei &&
                !er &&
                !es &&
                !el &&
                !y &&
                !ed &&
                !ec &&
                !0,
              isKeyboardDismissDisabled:
                !!(b || w?.isDailyStreakFirst) ||
                !!k ||
                !!S ||
                !!E ||
                !!C ||
                !!J ||
                !!ee ||
                !!en ||
                !!eo ||
                !!ea ||
                !!y ||
                !!ed ||
                !!ec ||
                !1,
              isOpen: p,
              onOpenChange: (e) => {
                e || (w?.onClose && w?.onClose(), x({ isModalVisible: !1, modalComponent: null }));
              },
              hideCloseButton: eh,
              shouldBlockScroll: ef,
              placement: ea ? "bottom-center" : "center",
              scrollBehavior: "inside",
              motionProps: {
                variants: {
                  enter: { opacity: 1, y: 0, transition: { duration: 0.1, ease: [0.4, 0, 0.2, 1] } },
                  exit: { opacity: 0, transition: { duration: 0, ease: [0.4, 0, 1, 1] } },
                },
              },
              classNames: {
                backdrop: `h-full w-full xs-m:w-screen ${E || eo || ea || ee ? "[backdrop-filter:blur(4px)]  !bg-opacity-40  bg-blue-950 !z-[120]" : J ? "!z-[120] !bg-[color-mix(in_srgb,var(--ds-semantic-color-state-layer-on-light)_40%,transparent)]" : Y || Z || k || em || ec || 0 ? "[backdrop-filter:blur(6px)] !z-[120]" : ed ? "[backdrop-filter:blur(8px)] !bg-black-custom !bg-opacity-40 !z-[115]" : b ? "!backdrop-blur-md !bg-[#0D182FCC] !bg-opacity-80 !z-[120]" : "!z-[120] !bg-overlay/60"}`,
                wrapper: (0, r.cn)(
                  "!z-[150] h-full xs-m:h-[calc(100dvh)] !w-full xs-m:!w-screen overflow-hidden",
                ),
                closeButton: (0, r.cn)(
                  "absolute top-2 z-10 [&_svg]:w-4 [&_svg]:h-4 [&_svg]:outline-none",
                  l ? "left-2 right-auto" : "right-2 left-auto",
                  ed && "top-3.5",
                ),
                base: (0, r.cn)(
                  "!max-h-[90dvh] mx-3 rounded-lg [&_*]:-webkit-tap-highlight-color-transparent outline-none focus:outline-none [&_*]:outline-none [&_*]:focus:outline-none [&_*]:active:outline-none",
                  eu && "max-w-[400px] overflow-hidden rounded-[var(--ds-semantic-radius-sheet)]",
                  J &&
                    "max-w-[var(--ds-primitive-dimension-container-form)] overflow-hidden rounded-[var(--ds-semantic-radius-sheet)] bg-[var(--ds-semantic-color-surface-page)] [box-shadow:var(--ds-semantic-elevation-overlay)]",
                ),
              },
              children: [
                "write-a-review" === g && (0, t.jsx)(j, {}),
                v && (0, t.jsx)(A, { sessionId: e?.id }),
                b && (0, t.jsx)(_, {}),
                (0, t.jsx)(o.SessionProvider, {
                  children: "profile-settings" === g && (0, t.jsx)(M, { ...w }),
                }),
                y && (0, t.jsx)(L, { ...w }),
                C && (0, t.jsx)(P, { ...w }),
                k && (0, t.jsx)(T, { ...w }),
                S && (0, t.jsx)(O, { ...w }),
                E && (0, t.jsx)(R, { ...w }),
                J && (0, t.jsx)(I, { ...w }),
                Y && (0, t.jsx)(N, { ...w }),
                Z && (0, t.jsx)(K, { ...w }),
                ee && (0, t.jsx)(G, { ...w }),
                et && (0, t.jsx)(z, { ...w }),
                en && (0, t.jsx)(V, { ...w }),
                eo && (0, t.jsx)(B, {}),
                ea && (0, t.jsx)(U, {}),
                ei && (0, t.jsx)(D, {}),
                er && (0, t.jsx)(F, { ...w }),
                es && (0, t.jsx)(H, { ...w }),
                el && (0, t.jsx)(W, { ...w }),
                ed && (0, t.jsx)(q, {}),
                ec && (0, t.jsx)(Q, {}),
                "in-app-browser-detected" === g && (0, t.jsx)($, { ...w }),
                eu && (0, t.jsx)(X, { ...w }),
              ],
            })
          );
        },
      ],
      81295,
    );
  },
  154283,
  (e) => {
    "use strict";
    var t = e.i(843476),
      n = e.i(271645),
      o = (e, t, n, o, a, i, r, s) => {
        let l = document.documentElement,
          d = ["light", "dark"];
        function c(t) {
          var n;
          ((Array.isArray(e) ? e : [e]).forEach((e) => {
            let n = "class" === e,
              o = n && i ? a.map((e) => i[e] || e) : a;
            n ? (l.classList.remove(...o), l.classList.add(i && i[t] ? i[t] : t)) : l.setAttribute(e, t);
          }),
            (n = t),
            s && d.includes(n) && (l.style.colorScheme = n));
        }
        if (o) c(o);
        else
          try {
            let e = localStorage.getItem(t) || n,
              o =
                r && "system" === e
                  ? window.matchMedia("(prefers-color-scheme: dark)").matches
                    ? "dark"
                    : "light"
                  : e;
            c(o);
          } catch (e) {}
      },
      a = ["light", "dark"],
      i = "(prefers-color-scheme: dark)",
      r = "u" < typeof window,
      s = n.createContext(void 0),
      l = (e) =>
        n.useContext(s) ? n.createElement(n.Fragment, null, e.children) : n.createElement(c, { ...e }),
      d = ["light", "dark"],
      c = (e) => {
        let {
            forcedTheme: t,
            disableTransitionOnChange: o = !1,
            enableSystem: r = !0,
            enableColorScheme: l = !0,
            storageKey: c = "theme",
            themes: p = d,
            defaultTheme: g = r ? "system" : "light",
            attribute: x = "data-theme",
            value: w,
            children: v,
            nonce: b,
            scriptProps: y,
          } = e,
          [C, k] = n.useState(() => m(c, g)),
          [S, E] = n.useState(() => ("system" === C ? f() : C)),
          A = w ? Object.values(w) : p,
          j = n.useCallback(
            (e) => {
              let t = e;
              if (!t) return;
              "system" === e && r && (t = f());
              let n = w ? w[t] : t,
                i = o ? h(b) : null,
                s = document.documentElement,
                d = (e) => {
                  "class" === e
                    ? (s.classList.remove(...A), n && s.classList.add(n))
                    : e.startsWith("data-") && (n ? s.setAttribute(e, n) : s.removeAttribute(e));
                };
              if ((Array.isArray(x) ? x.forEach(d) : d(x), l)) {
                let e = a.includes(g) ? g : null,
                  n = a.includes(t) ? t : e;
                s.style.colorScheme = n;
              }
              null == i || i();
            },
            [b],
          ),
          _ = n.useCallback(
            (e) => {
              let t = "function" == typeof e ? e(C) : e;
              k(t);
              try {
                localStorage.setItem(c, t);
              } catch (e) {}
            },
            [C],
          ),
          M = n.useCallback(
            (e) => {
              (E(f(e)), "system" === C && r && !t && j("system"));
            },
            [C, t],
          );
        (n.useEffect(() => {
          let e = window.matchMedia(i);
          return (e.addListener(M), M(e), () => e.removeListener(M));
        }, [M]),
          n.useEffect(() => {
            let e = (e) => {
              e.key === c && (e.newValue ? k(e.newValue) : _(g));
            };
            return (window.addEventListener("storage", e), () => window.removeEventListener("storage", e));
          }, [_]),
          n.useEffect(() => {
            j(null != t ? t : C);
          }, [t, C]));
        let L = n.useMemo(
          () => ({
            theme: C,
            setTheme: _,
            forcedTheme: t,
            resolvedTheme: "system" === C ? S : C,
            themes: r ? [...p, "system"] : p,
            systemTheme: r ? S : void 0,
          }),
          [C, _, t, S, r, p],
        );
        return n.createElement(
          s.Provider,
          { value: L },
          n.createElement(u, {
            forcedTheme: t,
            storageKey: c,
            attribute: x,
            enableSystem: r,
            enableColorScheme: l,
            defaultTheme: g,
            value: w,
            themes: p,
            nonce: b,
            scriptProps: y,
          }),
          v,
        );
      },
      u = n.memo((e) => {
        let {
            forcedTheme: t,
            storageKey: a,
            attribute: i,
            enableSystem: r,
            enableColorScheme: s,
            defaultTheme: l,
            value: d,
            themes: c,
            nonce: u,
            scriptProps: m,
          } = e,
          h = JSON.stringify([i, a, l, t, c, d, r, s]).slice(1, -1);
        return n.createElement("script", {
          ...m,
          suppressHydrationWarning: !0,
          nonce: "u" < typeof window ? u : "",
          dangerouslySetInnerHTML: { __html: `(${o.toString()})(${h})` },
        });
      }),
      m = (e, t) => {
        let n;
        if (!r) {
          try {
            n = localStorage.getItem(e) || void 0;
          } catch (e) {}
          return n || t;
        }
      },
      h = (e) => {
        let t = document.createElement("style");
        return (
          e && t.setAttribute("nonce", e),
          t.appendChild(
            document.createTextNode(
              "*,*::before,*::after{-webkit-transition:none!important;-moz-transition:none!important;-o-transition:none!important;-ms-transition:none!important;transition:none!important}",
            ),
          ),
          document.head.appendChild(t),
          () => {
            (window.getComputedStyle(document.body),
              setTimeout(() => {
                document.head.removeChild(t);
              }, 1));
          }
        );
      },
      f = (e) => (e || (e = window.matchMedia(i)), e.matches ? "dark" : "light"),
      p = e.i(595494);
    let g = new Set(["Arab", "Syrc", "Samr", "Mand", "Thaa", "Mend", "Nkoo", "Adlm", "Rohg", "Hebr"]),
      x = new Set([
        "ae",
        "ar",
        "arc",
        "bcc",
        "bqi",
        "ckb",
        "dv",
        "fa",
        "glk",
        "he",
        "ku",
        "mzn",
        "nqo",
        "pnb",
        "ps",
        "sd",
        "ug",
        "ur",
        "yi",
      ]);
    function w(e) {
      if (Intl.Locale) {
        let t = new Intl.Locale(e).maximize(),
          n = "function" == typeof t.getTextInfo ? t.getTextInfo() : t.textInfo;
        if (n) return "rtl" === n.direction;
        if (t.script) return g.has(t.script);
      }
      let t = e.split("-")[0];
      return x.has(t);
    }
    var v = e.i(454453);
    let b = Symbol.for("react-aria.i18n.locale");
    function y() {
      let e =
        ("u" > typeof window && window[b]) ||
        ("u" > typeof navigator && (navigator.language || navigator.userLanguage)) ||
        "en-US";
      try {
        Intl.DateTimeFormat.supportedLocalesOf([e]);
      } catch {
        e = "en-US";
      }
      return { locale: e, direction: w(e) ? "rtl" : "ltr" };
    }
    let C = y(),
      k = new Set();
    function S() {
      for (let e of ((C = y()), k)) e(C);
    }
    let E = n.default.createContext(null);
    function A(e) {
      let { locale: t, children: o } = e,
        a = n.default.useMemo(() => ({ locale: t, direction: w(t) ? "rtl" : "ltr" }), [t]);
      return n.default.createElement(E.Provider, { value: a }, o);
    }
    function j(e) {
      let { children: t } = e,
        o = (function () {
          let e = (0, v.useIsSSR)(),
            [t, o] = (0, n.useState)(C);
          return ((0, n.useEffect)(
            () => (
              0 === k.size && window.addEventListener("languagechange", S),
              k.add(o),
              () => {
                (k.delete(o), 0 === k.size && window.removeEventListener("languagechange", S));
              }
            ),
            [],
          ),
          e)
            ? { locale: "en-US", direction: "ltr" }
            : t;
        })();
      return n.default.createElement(E.Provider, { value: o }, t);
    }
    function _(e) {
      let { locale: t, children: o } = e;
      return t
        ? n.default.createElement(A, { locale: t, children: o })
        : n.default.createElement(j, { children: o });
    }
    var M = e.i(63209),
      L = e.i(846791);
    let P = null;
    function T(e) {
      var t;
      if ("u" < typeof window || null == window.navigator) return !1;
      let n = null == (t = window.navigator.userAgentData) ? void 0 : t.brands;
      return (Array.isArray(n) && n.some((t) => e.test(t.brand))) || e.test(window.navigator.userAgent);
    }
    function O(e) {
      var t;
      return (
        "u" > typeof window &&
        null != window.navigator &&
        e.test(
          (null == (t = window.navigator.userAgentData) ? void 0 : t.platform) || window.navigator.platform,
        )
      );
    }
    function R(e) {
      let t = null;
      return () => (null == t && (t = e()), t);
    }
    let I = R(function () {
        return O(/^Mac/i);
      }),
      N = R(function () {
        return O(/^iPhone/i);
      }),
      K = R(function () {
        return O(/^iPad/i) || (I() && navigator.maxTouchPoints > 1);
      }),
      G = R(function () {
        return N() || K();
      });
    R(function () {
      return I() || G();
    });
    let z = R(function () {
        return T(/AppleWebKit/i) && !V();
      }),
      V = R(function () {
        return T(/Chrome/i);
      });
    R(function () {
      return T(/Android/i);
    });
    let B = R(function () {
        return T(/Firefox/i);
      }),
      U = (0, n.createContext)({
        isNative: !0,
        open: function (e, t) {
          H(e, (e) => F(e, t));
        },
        useHref: (e) => e,
      });
    function D(e) {
      let { children: t, navigate: o, useHref: a } = e,
        i = (0, n.useMemo)(
          () => ({
            isNative: !1,
            open: (e, t, n, a) => {
              H(e, (e) => {
                var i, r;
                let s;
                ((i = e),
                (r = t),
                ((s = i.getAttribute("target")) && "_self" !== s) ||
                  i.origin !== location.origin ||
                  i.hasAttribute("download") ||
                  r.metaKey ||
                  r.ctrlKey ||
                  r.altKey ||
                  r.shiftKey)
                  ? F(e, t)
                  : o(n, a);
              });
            },
            useHref: a || ((e) => e),
          }),
          [o, a],
        );
      return n.default.createElement(U.Provider, { value: i }, t);
    }
    function F(e, t) {
      var n, o;
      let a = !(arguments.length > 2) || void 0 === arguments[2] || arguments[2],
        { metaKey: i, ctrlKey: r, altKey: s, shiftKey: l } = t;
      B() &&
        (null == (o = window.event) || null == (n = o.type) ? void 0 : n.startsWith("key")) &&
        "_blank" === e.target &&
        (I() ? (i = !0) : (r = !0));
      let d =
        z() && I() && !K() && 1
          ? new KeyboardEvent("keydown", {
              keyIdentifier: "Enter",
              metaKey: i,
              ctrlKey: r,
              altKey: s,
              shiftKey: l,
            })
          : new MouseEvent("click", {
              metaKey: i,
              ctrlKey: r,
              altKey: s,
              shiftKey: l,
              bubbles: !0,
              cancelable: !0,
            });
      if (
        ((F.isOpening = a),
        (function () {
          if (null == P) {
            P = !1;
            try {
              document.createElement("div").focus({
                get preventScroll() {
                  return ((P = !0), !0);
                },
              });
            } catch {}
          }
          return P;
        })())
      )
        e.focus({ preventScroll: !0 });
      else {
        let t = (function (e) {
          let t = e.parentNode,
            n = [],
            o = document.scrollingElement || document.documentElement;
          for (; t instanceof HTMLElement && t !== o;)
            ((t.offsetHeight < t.scrollHeight || t.offsetWidth < t.scrollWidth) &&
              n.push({ element: t, scrollTop: t.scrollTop, scrollLeft: t.scrollLeft }),
              (t = t.parentNode));
          return (
            o instanceof HTMLElement &&
              n.push({ element: o, scrollTop: o.scrollTop, scrollLeft: o.scrollLeft }),
            n
          );
        })(e);
        (e.focus(),
          (function (e) {
            for (let { element: t, scrollTop: n, scrollLeft: o } of e)
              ((t.scrollTop = n), (t.scrollLeft = o));
          })(t));
      }
      (e.dispatchEvent(d), (F.isOpening = !1));
    }
    function H(e, t) {
      if (e instanceof HTMLAnchorElement) t(e);
      else if (e.hasAttribute("data-href")) {
        let n = document.createElement("a");
        ((n.href = e.getAttribute("data-href")),
          e.hasAttribute("data-target") && (n.target = e.getAttribute("data-target")),
          e.hasAttribute("data-rel") && (n.rel = e.getAttribute("data-rel")),
          e.hasAttribute("data-download") && (n.download = e.getAttribute("data-download")),
          e.hasAttribute("data-ping") && (n.ping = e.getAttribute("data-ping")),
          e.hasAttribute("data-referrer-policy") &&
            (n.referrerPolicy = e.getAttribute("data-referrer-policy")),
          e.appendChild(n),
          t(n),
          e.removeChild(n));
      }
    }
    F.isOpening = !1;
    var W = e.i(605344),
      q = (e) => {
        let {
            children: o,
            navigate: a,
            disableAnimation: i,
            useHref: r,
            disableRipple: s = !1,
            skipFramerMotionAnimations: l = i,
            reducedMotion: d = "never",
            validationBehavior: c,
            locale: u = "en-US",
            labelPlacement: m,
            defaultDates: h,
            createCalendar: f,
            spinnerVariant: g,
            ...x
          } = e,
          w = o;
        a && (w = (0, t.jsx)(D, { navigate: a, useHref: r, children: w }));
        let v = (0, n.useMemo)(
          () => (
            i && l && (L.MotionGlobalConfig.skipAnimations = !0),
            {
              createCalendar: f,
              defaultDates: h,
              disableAnimation: i,
              disableRipple: s,
              validationBehavior: c,
              labelPlacement: m,
              spinnerVariant: g,
            }
          ),
          [f, null == h ? void 0 : h.maxDate, null == h ? void 0 : h.minDate, i, s, c, m, g],
        );
        return (0, t.jsx)(p.ProviderContext, {
          value: v,
          children: (0, t.jsx)(_, {
            locale: u,
            children: (0, t.jsx)(M.MotionConfig, {
              reducedMotion: d,
              children: (0, t.jsx)(W.OverlayProvider, { ...x, children: w }),
            }),
          }),
        });
      };
    e.s(
      [
        "default",
        0,
        (e) => {
          let { children: n, locale: o = "en" } = e;
          return (0, t.jsx)(q, {
            locale: o,
            children: (0, t.jsx)(l, {
              defaultTheme: "light",
              attribute: "class",
              disableTransitionOnChange: !0,
              children: n,
            }),
          });
        },
      ],
      154283,
    );
  },
]);
