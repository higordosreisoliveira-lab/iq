(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  605500,
  (e, t, i) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(i, "__esModule", { value: !0 }),
      Object.defineProperty(i, "Image", {
        enumerable: !0,
        get: function () {
          return w;
        },
      }));
    let r = e.r(555682),
      n = e.r(190809),
      a = e.r(843476),
      l = n._(e.r(271645)),
      o = r._(e.r(174080)),
      s = r._(e.r(325633)),
      u = e.r(908927),
      d = e.r(987690),
      c = e.r(918556),
      g = e.r(65856),
      m = r._(e.r(1948)),
      f = e.r(818581),
      p = {
        deviceSizes: [640, 1080, 1920],
        imageSizes: [16, 64, 128],
        qualities: [75],
        path: "/_next/image",
        loader: "default",
        dangerouslyAllowSVG: !1,
        unoptimized: !0,
      };
    function h(e, t, i, r, n, a, l) {
      let o = e?.src;
      e &&
        e["data-loaded-src"] !== o &&
        ((e["data-loaded-src"] = o),
        ("decode" in e ? e.decode() : Promise.resolve())
          .catch(() => {})
          .then(() => {
            if (e.parentElement && e.isConnected) {
              if (("empty" !== t && n(!0), i?.current)) {
                let t = new Event("load");
                Object.defineProperty(t, "target", { writable: !1, value: e });
                let r = !1,
                  n = !1;
                i.current({
                  ...t,
                  nativeEvent: t,
                  currentTarget: e,
                  target: e,
                  isDefaultPrevented: () => r,
                  isPropagationStopped: () => n,
                  persist: () => {},
                  preventDefault: () => {
                    ((r = !0), t.preventDefault());
                  },
                  stopPropagation: () => {
                    ((n = !0), t.stopPropagation());
                  },
                });
              }
              r?.current && r.current(e);
            }
          }));
    }
    function y(e) {
      return l.use ? { fetchPriority: e } : { fetchpriority: e };
    }
    "u" < typeof window && (globalThis.__NEXT_IMAGE_IMPORTED = !0);
    let b = "u" < typeof window ? l.useEffect : l.useLayoutEffect,
      _ = (0, l.forwardRef)((e, t) => {
        let {
            src: i,
            srcSet: r,
            sizes: n,
            height: o,
            width: s,
            decoding: u,
            className: d,
            style: c,
            fetchPriority: g,
            placeholder: m,
            loading: p,
            unoptimized: _,
            fill: v,
            onLoadRef: w,
            onLoadingCompleteRef: x,
            setBlurComplete: I,
            setShowAltText: j,
            sizesInput: P,
            onLoad: S,
            onError: C,
            ...E
          } = e,
          O = (0, l.useRef)(!1),
          R = (0, l.useRef)(null);
        b(() => {
          let { current: e } = O,
            { current: t } = R;
          e || null === t || (C && (t.src = t.src), t.complete && h(t, m, w, x, I, _, P), (O.current = !0));
        }, [i, m, w, x, C, _, P]);
        let M = (0, f.useMergedRef)(t, R);
        return (0, a.jsx)("img", {
          ...E,
          ...y(g),
          loading: p,
          width: s,
          height: o,
          decoding: u,
          "data-nimg": v ? "fill" : "1",
          className: d,
          style: c,
          sizes: n,
          srcSet: r,
          src: i,
          ref: M,
          onLoad: (e) => {
            h(e.currentTarget, m, w, x, I, _, P);
          },
          onError: (e) => {
            (j(!0), "empty" !== m && I(!0), C && C(e));
          },
        });
      });
    function v(e) {
      let { isAppRouter: t, imgAttributes: i } = e,
        r = {
          as: "image",
          imageSrcSet: i.srcSet,
          imageSizes: i.sizes,
          crossOrigin: i.crossOrigin,
          referrerPolicy: i.referrerPolicy,
          ...y(i.fetchPriority),
        };
      return t && o.default.preload
        ? (o.default.preload(i.src, r), null)
        : (0, a.jsx)(s.default, {
            children: (0, a.jsx)(
              "link",
              { rel: "preload", href: i.srcSet ? void 0 : i.src, ...r },
              "__nimg-" + i.src + i.srcSet + i.sizes,
            ),
          });
    }
    let w = (0, l.forwardRef)((e, t) => {
      let i = (0, l.useContext)(g.RouterContext),
        r = (0, l.useContext)(c.ImageConfigContext),
        n = (0, l.useMemo)(() => {
          let e = p || r || d.imageConfigDefault,
            t = [...e.deviceSizes, ...e.imageSizes].sort((e, t) => e - t),
            i = e.deviceSizes.sort((e, t) => e - t),
            n = e.qualities?.sort((e, t) => e - t);
          return {
            ...e,
            allSizes: t,
            deviceSizes: i,
            qualities: n,
            localPatterns: "u" < typeof window ? r?.localPatterns : e.localPatterns,
          };
        }, [r]),
        { onLoad: o, onLoadingComplete: s } = e,
        f = (0, l.useRef)(o);
      (0, l.useEffect)(() => {
        f.current = o;
      }, [o]);
      let h = (0, l.useRef)(s);
      (0, l.useEffect)(() => {
        h.current = s;
      }, [s]);
      let [y, b] = (0, l.useState)(!1),
        [w, x] = (0, l.useState)(!1),
        { props: I, meta: j } = (0, u.getImgProps)(e, {
          defaultLoader: m.default,
          imgConf: n,
          blurComplete: y,
          showAltText: w,
        });
      return (0, a.jsxs)(a.Fragment, {
        children: [
          (0, a.jsx)(_, {
            ...I,
            unoptimized: j.unoptimized,
            placeholder: j.placeholder,
            fill: j.fill,
            onLoadRef: f,
            onLoadingCompleteRef: h,
            setBlurComplete: b,
            setShowAltText: x,
            sizesInput: e.sizes,
            ref: t,
          }),
          j.preload ? (0, a.jsx)(v, { isAppRouter: !i, imgAttributes: I }) : null,
        ],
      });
    });
    ("function" == typeof i.default || ("object" == typeof i.default && null !== i.default)) &&
      void 0 === i.default.__esModule &&
      (Object.defineProperty(i.default, "__esModule", { value: !0 }),
      Object.assign(i.default, i),
      (t.exports = i.default));
  },
  670965,
  (e, t, i) => {
    "use strict";
    function r(e, t) {
      let i = e || 75;
      return t?.qualities?.length
        ? t.qualities.reduce((e, t) => (Math.abs(t - i) < Math.abs(e - i) ? t : e), t.qualities[0])
        : i;
    }
    (Object.defineProperty(i, "__esModule", { value: !0 }),
      Object.defineProperty(i, "findClosestQuality", {
        enumerable: !0,
        get: function () {
          return r;
        },
      }));
  },
  908927,
  (e, t, i) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(i, "__esModule", { value: !0 }),
      Object.defineProperty(i, "getImgProps", {
        enumerable: !0,
        get: function () {
          return u;
        },
      }));
    let r = e.r(543369),
      n = e.r(488143),
      a = e.r(987690),
      l = ["-moz-initial", "fill", "none", "scale-down", void 0];
    function o(e) {
      return void 0 !== e.default;
    }
    function s(e) {
      return void 0 === e
        ? e
        : "number" == typeof e
          ? Number.isFinite(e)
            ? e
            : NaN
          : "string" == typeof e && /^[0-9]+$/.test(e)
            ? parseInt(e, 10)
            : NaN;
    }
    function u(e, t) {
      var i;
      let u,
        d,
        c,
        {
          src: g,
          sizes: m,
          unoptimized: f = !1,
          priority: p = !1,
          preload: h = !1,
          loading: y,
          className: b,
          quality: _,
          width: v,
          height: w,
          fill: x = !1,
          style: I,
          overrideSrc: j,
          onLoad: P,
          onLoadingComplete: S,
          placeholder: C = "empty",
          blurDataURL: E,
          fetchPriority: O,
          decoding: R = "async",
          layout: M,
          objectFit: z,
          objectPosition: T,
          lazyBoundary: k,
          lazyRoot: U,
          ...A
        } = e,
        { imgConf: D, showAltText: $, blurComplete: N, defaultLoader: H } = t,
        L = D || a.imageConfigDefault;
      if ("allSizes" in L) u = L;
      else {
        let e = [...L.deviceSizes, ...L.imageSizes].sort((e, t) => e - t),
          t = L.deviceSizes.sort((e, t) => e - t),
          i = L.qualities?.sort((e, t) => e - t);
        u = { ...L, allSizes: e, deviceSizes: t, qualities: i };
      }
      if (void 0 === H)
        throw Object.defineProperty(
          Error(
            "images.loaderFile detected but the file is missing default export.\nRead more: https://nextjs.org/docs/messages/invalid-images-config",
          ),
          "__NEXT_ERROR_CODE",
          { value: "E163", enumerable: !1, configurable: !0 },
        );
      let q = A.loader || H;
      (delete A.loader, delete A.srcSet);
      let F = "__next_img_default" in q;
      if (F) {
        if ("custom" === u.loader)
          throw Object.defineProperty(
            Error(`Image with src "${g}" is missing "loader" prop.
Read more: https://nextjs.org/docs/messages/next-image-missing-loader`),
            "__NEXT_ERROR_CODE",
            { value: "E252", enumerable: !1, configurable: !0 },
          );
      } else {
        let e = q;
        q = (t) => {
          let { config: i, ...r } = t;
          return e(r);
        };
      }
      if (M) {
        "fill" === M && (x = !0);
        let e = {
          intrinsic: { maxWidth: "100%", height: "auto" },
          responsive: { width: "100%", height: "auto" },
        }[M];
        e && (I = { ...I, ...e });
        let t = { responsive: "100vw", fill: "100vw" }[M];
        t && !m && (m = t);
      }
      let B = "",
        W = s(v),
        G = s(w);
      if ((i = g) && "object" == typeof i && (o(i) || void 0 !== i.src)) {
        let e = o(g) ? g.default : g;
        if (!e.src)
          throw Object.defineProperty(
            Error(
              `An object should only be passed to the image component src parameter if it comes from a static image import. It must include src. Received ${JSON.stringify(e)}`,
            ),
            "__NEXT_ERROR_CODE",
            { value: "E460", enumerable: !1, configurable: !0 },
          );
        if (!e.height || !e.width)
          throw Object.defineProperty(
            Error(
              `An object should only be passed to the image component src parameter if it comes from a static image import. It must include height and width. Received ${JSON.stringify(e)}`,
            ),
            "__NEXT_ERROR_CODE",
            { value: "E48", enumerable: !1, configurable: !0 },
          );
        if (((d = e.blurWidth), (c = e.blurHeight), (E = E || e.blurDataURL), (B = e.src), !x))
          if (W || G) {
            if (W && !G) {
              let t = W / e.width;
              G = Math.round(e.height * t);
            } else if (!W && G) {
              let t = G / e.height;
              W = Math.round(e.width * t);
            }
          } else ((W = e.width), (G = e.height));
      }
      let V = !p && !h && ("lazy" === y || void 0 === y);
      ((!(g = "string" == typeof g ? g : B) || g.startsWith("data:") || g.startsWith("blob:")) &&
        ((f = !0), (V = !1)),
        u.unoptimized && (f = !0),
        F && !u.dangerouslyAllowSVG && g.split("?", 1)[0].endsWith(".svg") && (f = !0));
      let J = s(_),
        X = Object.assign(
          x
            ? {
                position: "absolute",
                height: "100%",
                width: "100%",
                left: 0,
                top: 0,
                right: 0,
                bottom: 0,
                objectFit: z,
                objectPosition: T,
              }
            : {},
          $ ? {} : { color: "transparent" },
          I,
        ),
        K =
          N || "empty" === C
            ? null
            : "blur" === C
              ? `url("data:image/svg+xml;charset=utf-8,${(0, n.getImageBlurSvg)({ widthInt: W, heightInt: G, blurWidth: d, blurHeight: c, blurDataURL: E || "", objectFit: X.objectFit })}")`
              : `url("${C}")`,
        Q = l.includes(X.objectFit) ? ("fill" === X.objectFit ? "100% 100%" : "cover") : X.objectFit,
        Y = K
          ? {
              backgroundSize: Q,
              backgroundPosition: X.objectPosition || "50% 50%",
              backgroundRepeat: "no-repeat",
              backgroundImage: K,
            }
          : {},
        Z = (function (e) {
          let { config: t, src: i, unoptimized: n, width: a, quality: l, sizes: o, loader: s } = e;
          if (n) {
            if (i.startsWith("/") && !i.startsWith("//")) {
              let e = (0, r.getDeploymentId)();
              if (i.includes("/_next/static/immutable") && !(0, r.getAssetToken)()) e = void 0;
              else if (e) {
                let t = i.indexOf("?");
                if (-1 !== t) {
                  let r = new URLSearchParams(i.slice(t + 1));
                  r.get("dpl") || (r.append("dpl", e), (i = i.slice(0, t) + "?" + r.toString()));
                } else i += `?dpl=${e}`;
              }
            }
            return { src: i, srcSet: void 0, sizes: void 0 };
          }
          let { widths: u, kind: d } = (function (e, t, i) {
              let { deviceSizes: r, allSizes: n } = e;
              if (i) {
                let e = /(^|\s)(1?\d?\d)vw/g,
                  t = [];
                for (let r; (r = e.exec(i));) t.push(parseInt(r[2]));
                if (t.length) {
                  let e = 0.01 * Math.min(...t);
                  return { widths: n.filter((t) => t >= r[0] * e), kind: "w" };
                }
                return { widths: n, kind: "w" };
              }
              return "number" != typeof t
                ? { widths: r, kind: "w" }
                : {
                    widths: [...new Set([t, 2 * t].map((e) => n.find((t) => t >= e) || n[n.length - 1]))],
                    kind: "x",
                  };
            })(t, a, o),
            c = u.length - 1;
          return {
            sizes: o || "w" !== d ? o : "100vw",
            srcSet: u
              .map((e, r) => `${s({ config: t, src: i, quality: l, width: e })} ${"w" === d ? e : r + 1}${d}`)
              .join(", "),
            src: s({ config: t, src: i, quality: l, width: u[c] }),
          };
        })({ config: u, src: g, unoptimized: f, width: W, quality: J, sizes: m, loader: q }),
        ee = V ? "lazy" : y;
      return {
        props: {
          ...A,
          loading: ee,
          fetchPriority: O,
          width: W,
          height: G,
          decoding: R,
          className: b,
          style: { ...X, ...Y },
          sizes: Z.sizes,
          srcSet: Z.srcSet,
          src: j || Z.src,
        },
        meta: { unoptimized: f, preload: h || p, placeholder: C, fill: x },
      };
    }
  },
  325633,
  (e, t, i) => {
    "use strict";
    (e.i(247167), Object.defineProperty(i, "__esModule", { value: !0 }));
    var r = {
      default: function () {
        return p;
      },
      defaultHead: function () {
        return c;
      },
    };
    for (var n in r) Object.defineProperty(i, n, { enumerable: !0, get: r[n] });
    let a = e.r(555682),
      l = e.r(190809),
      o = e.r(843476),
      s = l._(e.r(271645)),
      u = a._(e.r(898879)),
      d = e.r(742732);
    function c() {
      return [
        (0, o.jsx)("meta", { charSet: "utf-8" }, "charset"),
        (0, o.jsx)("meta", { name: "viewport", content: "width=device-width" }, "viewport"),
      ];
    }
    function g(e, t) {
      return "string" == typeof t || "number" == typeof t
        ? e
        : t.type === s.default.Fragment
          ? e.concat(
              s.default.Children.toArray(t.props.children).reduce(
                (e, t) => ("string" == typeof t || "number" == typeof t ? e : e.concat(t)),
                [],
              ),
            )
          : e.concat(t);
    }
    let m = ["name", "httpEquiv", "charSet", "itemProp"];
    function f(e) {
      let t, i, r, n;
      return e
        .reduce(g, [])
        .reverse()
        .concat(c().reverse())
        .filter(
          ((t = new Set()),
          (i = new Set()),
          (r = new Set()),
          (n = {}),
          (e) => {
            let a = !0,
              l = !1;
            if (e.key && "number" != typeof e.key && e.key.indexOf("$") > 0) {
              l = !0;
              let i = e.key.slice(e.key.indexOf("$") + 1);
              t.has(i) ? (a = !1) : t.add(i);
            }
            switch (e.type) {
              case "title":
              case "base":
                i.has(e.type) ? (a = !1) : i.add(e.type);
                break;
              case "meta":
                for (let t = 0, i = m.length; t < i; t++) {
                  let i = m[t];
                  if (e.props.hasOwnProperty(i))
                    if ("charSet" === i) r.has(i) ? (a = !1) : r.add(i);
                    else {
                      let t = e.props[i],
                        r = n[i] || new Set();
                      ("name" !== i || !l) && r.has(t) ? (a = !1) : (r.add(t), (n[i] = r));
                    }
                }
            }
            return a;
          }),
        )
        .reverse()
        .map((e, t) => {
          let i = e.key || t;
          return s.default.cloneElement(e, { key: i });
        });
    }
    let p = function (e) {
      let { children: t } = e,
        i = (0, s.useContext)(d.HeadManagerContext);
      return (0, o.jsx)(u.default, { reduceComponentsToState: f, headManager: i, children: t });
    };
    ("function" == typeof i.default || ("object" == typeof i.default && null !== i.default)) &&
      void 0 === i.default.__esModule &&
      (Object.defineProperty(i.default, "__esModule", { value: !0 }),
      Object.assign(i.default, i),
      (t.exports = i.default));
  },
  488143,
  (e, t, i) => {
    "use strict";
    function r(e) {
      let { widthInt: t, heightInt: i, blurWidth: r, blurHeight: n, blurDataURL: a, objectFit: l } = e,
        o = r ? 40 * r : t,
        s = n ? 40 * n : i,
        u = o && s ? `viewBox='0 0 ${o} ${s}'` : "";
      return `%3Csvg xmlns='http://www.w3.org/2000/svg' ${u}%3E%3Cfilter id='b' color-interpolation-filters='sRGB'%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3CfeColorMatrix values='1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 100 -1' result='s'/%3E%3CfeFlood x='0' y='0' width='100%25' height='100%25'/%3E%3CfeComposite operator='out' in='s'/%3E%3CfeComposite in2='SourceGraphic'/%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3C/filter%3E%3Cimage width='100%25' height='100%25' x='0' y='0' preserveAspectRatio='${u ? "none" : "contain" === l ? "xMidYMid" : "cover" === l ? "xMidYMid slice" : "none"}' style='filter: url(%23b);' href='${a}'/%3E%3C/svg%3E`;
    }
    (Object.defineProperty(i, "__esModule", { value: !0 }),
      Object.defineProperty(i, "getImageBlurSvg", {
        enumerable: !0,
        get: function () {
          return r;
        },
      }));
  },
  918556,
  (e, t, i) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(i, "__esModule", { value: !0 }),
      Object.defineProperty(i, "ImageConfigContext", {
        enumerable: !0,
        get: function () {
          return a;
        },
      }));
    let r = e.r(555682)._(e.r(271645)),
      n = e.r(987690),
      a = r.default.createContext(n.imageConfigDefault);
  },
  987690,
  (e, t, i) => {
    "use strict";
    Object.defineProperty(i, "__esModule", { value: !0 });
    var r = {
      VALID_LOADERS: function () {
        return a;
      },
      imageConfigDefault: function () {
        return l;
      },
    };
    for (var n in r) Object.defineProperty(i, n, { enumerable: !0, get: r[n] });
    let a = ["default", "imgix", "cloudinary", "akamai", "custom"],
      l = {
        deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
        imageSizes: [32, 48, 64, 96, 128, 256, 384],
        path: "/_next/image",
        loader: "default",
        loaderFile: "",
        domains: [],
        disableStaticImages: !1,
        minimumCacheTTL: 14400,
        formats: ["image/webp"],
        maximumDiskCacheSize: void 0,
        maximumRedirects: 3,
        maximumResponseBody: 5e7,
        dangerouslyAllowLocalIP: !1,
        dangerouslyAllowSVG: !1,
        contentSecurityPolicy: "script-src 'none'; frame-src 'none'; sandbox;",
        contentDispositionType: "attachment",
        localPatterns: void 0,
        remotePatterns: [],
        qualities: [75],
        unoptimized: !1,
        customCacheHandler: !1,
      };
  },
  794909,
  (e, t, i) => {
    "use strict";
    (e.i(247167), Object.defineProperty(i, "__esModule", { value: !0 }));
    var r = {
      default: function () {
        return d;
      },
      getImageProps: function () {
        return u;
      },
    };
    for (var n in r) Object.defineProperty(i, n, { enumerable: !0, get: r[n] });
    let a = e.r(555682),
      l = e.r(908927),
      o = e.r(605500),
      s = a._(e.r(1948));
    function u(e) {
      let { props: t } = (0, l.getImgProps)(e, {
        defaultLoader: s.default,
        imgConf: {
          deviceSizes: [640, 1080, 1920],
          imageSizes: [16, 64, 128],
          qualities: [75],
          path: "/_next/image",
          loader: "default",
          dangerouslyAllowSVG: !1,
          unoptimized: !0,
        },
      });
      for (let [e, i] of Object.entries(t)) void 0 === i && delete t[e];
      return { props: t };
    }
    let d = o.Image;
  },
  657688,
  (e, t, i) => {
    t.exports = e.r(794909);
  },
  1948,
  (e, t, i) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(i, "__esModule", { value: !0 }),
      Object.defineProperty(i, "default", {
        enumerable: !0,
        get: function () {
          return l;
        },
      }));
    let r = e.r(670965),
      n = e.r(543369);
    function a(e) {
      let { config: t, src: i, width: a, quality: l } = e,
        o = (0, n.getDeploymentId)();
      if (i.startsWith("/") && !i.startsWith("//"))
        if (i.includes("/_next/static/immutable") && !(0, n.getAssetToken)()) o = void 0;
        else {
          let e = i.indexOf("?");
          if (-1 !== e) {
            let t = new URLSearchParams(i.slice(e + 1)),
              r = t.get("dpl");
            if (r) {
              ((o = r), t.delete("dpl"));
              let n = t.toString();
              i = i.slice(0, e) + (n ? "?" + n : "");
            }
          }
        }
      if (
        i.startsWith("/") &&
        i.includes("?") &&
        t.localPatterns?.length === 1 &&
        "**" === t.localPatterns[0].pathname &&
        "" === t.localPatterns[0].search
      )
        throw Object.defineProperty(
          Error(`Image with src "${i}" is using a query string which is not configured in images.localPatterns.
Read more: https://nextjs.org/docs/messages/next-image-unconfigured-localpatterns`),
          "__NEXT_ERROR_CODE",
          { value: "E871", enumerable: !1, configurable: !0 },
        );
      let s = (0, r.findClosestQuality)(l, t);
      return `${t.path}?url=${encodeURIComponent(i)}&w=${a}&q=${s}${i.startsWith("/") && o ? `&dpl=${o}` : ""}`;
    }
    a.__next_img_default = !0;
    let l = a;
  },
  65856,
  (e, t, i) => {
    "use strict";
    (e.i(247167),
      Object.defineProperty(i, "__esModule", { value: !0 }),
      Object.defineProperty(i, "RouterContext", {
        enumerable: !0,
        get: function () {
          return r;
        },
      }));
    let r = e.r(555682)._(e.r(271645)).default.createContext(null);
  },
  898879,
  (e, t, i) => {
    "use strict";
    (Object.defineProperty(i, "__esModule", { value: !0 }),
      Object.defineProperty(i, "default", {
        enumerable: !0,
        get: function () {
          return o;
        },
      }));
    let r = e.r(271645),
      n = "u" < typeof window,
      a = n ? () => {} : r.useLayoutEffect,
      l = n ? () => {} : r.useEffect;
    function o(e) {
      let { headManager: t, reduceComponentsToState: i } = e;
      function o() {
        if (t && t.mountedInstances) {
          let e = r.Children.toArray(Array.from(t.mountedInstances).filter(Boolean));
          t.updateHead(i(e));
        }
      }
      return (
        n && (t?.mountedInstances?.add(e.children), o()),
        a(
          () => (
            t?.mountedInstances?.add(e.children),
            () => {
              t?.mountedInstances?.delete(e.children);
            }
          ),
        ),
        a(
          () => (
            t && (t._pendingUpdate = o),
            () => {
              t && (t._pendingUpdate = o);
            }
          ),
        ),
        l(
          () => (
            t && t._pendingUpdate && (t._pendingUpdate(), (t._pendingUpdate = null)),
            () => {
              t && t._pendingUpdate && (t._pendingUpdate(), (t._pendingUpdate = null));
            }
          ),
        ),
        null
      );
    }
  },
  66985,
  (e) => {
    "use strict";
    e.s([
      "ImgAE",
      0,
      "/images/ae.webp",
      "ImgAH",
      0,
      "/images/ah.webp",
      "ImgAvatar3",
      0,
      "/images/Avatar2.webp",
      "ImgCocoChanel",
      0,
      "/images/coco-chanelV21.webp",
      "ImgDB",
      0,
      "/images/db.webp",
      "ImgEP",
      0,
      "/images/ep.webp",
      "ImgEP2",
      0,
      "/images/ep2.webp",
      "ImgFK",
      0,
      "/images/fk.webp",
      "ImgFM",
      0,
      "/images/fm.webp",
      "ImgHiddenPerson",
      0,
      "/images/youIq1.webp",
      "ImgLDV",
      0,
      "/images/ldv.webp",
      "ImgMM",
      0,
      "/images/mm.webp",
      "ImgMM2",
      0,
      "/images/mm2.webp",
      "ImgNT",
      0,
      "/images/nt.webp",
      "ImgSH",
      0,
      "/images/sh.webp",
      "ImgSJ",
      0,
      "/images/sj.webp",
      "ImgWH",
      0,
      "/images/wh.webp",
    ]);
  },
  833012,
  (e) => {
    "use strict";
    var t = e.i(770703);
    let i = (0, t.default)(() => e.A(891265), { loadableGenerated: { modules: [746398] } });
    ((0, t.default)(() => e.A(237841), { loadableGenerated: { modules: [932607] } }),
      e.s(["IqCertificateComponent", 0, i]));
  },
  237841,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/28265pioo2_-v.js"].map((t) => e.l(t))).then(() => t(932607)));
  },
  891265,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/2myhua2pk8h3h.js"].map((t) => e.l(t))).then(() => t(746398)));
  },
  275356,
  (e) => {
    "use strict";
    var t = e.i(843476),
      i = e.i(833012),
      r = e.i(948148),
      n = e.i(271645),
      a = e.i(157273),
      l = e.i(190899),
      o = e.i(66985);
    let s = {
      option_1: o.ImgSJ,
      option_2: o.ImgAE,
      option_3: o.ImgEP,
      option_4: o.ImgWH,
      option_5: o.ImgAH,
      option_6: o.ImgMM,
      option_7: o.ImgLDV,
      option_8: o.ImgFK,
      option_9: o.ImgNT,
      option_10: o.ImgSH,
      option_11: o.ImgDB,
      option_12: o.ImgFM,
    };
    var u = e.i(657688),
      d = e.i(861745),
      c = e.i(663615),
      g = e.i(449496),
      m = e.i(47252),
      f = e.i(51653),
      p = e.i(263970);
    let h = (e) => {
        let { data: i, variant: n, index: a, scrollTarget: l } = e,
          o = (0, r.useTranslations)(),
          s = (0, d.useLocale)(),
          h = (0, p.useGlobalStore)((e) => e.setAutoScrolling);
        return (0, t.jsxs)("div", {
          onClick: () => void (h(!0, 750), (0, f.scrollToBlock)(l ?? "checkout-coupon-disclaimer")),
          className: (0, c.cn)(
            "text grid h-[var(--indicator-height)] min-w-0 flex-1 cursor-pointer select-none grid-rows-[auto_1fr] rounded-t-lg bg-white max-xs-m:h-[calc(var(--indicator-height)*0.9)]",
          ),
          style: { "--indicator-height": `${i.height}px` },
          children: [
            (0, t.jsxs)("div", {
              lang: "bg" === s ? "ru" : s,
              className: (0, c.cn)(
                `${"highlighted" === i.type ? "min-w-20" : ""} flex justify-center gap-1 hyphens-auto break-words py-2 text-center text-[14px] font-semibold leading-6 text-blue-500 xs-m:text-base sm:text-lg`,
                (0, g.isMyiqVariant)(n) ? "uppercase" : "px-1",
              ),
              children: [
                (0, g.isMyiqVariant)(n) && (0, t.jsx)("span", { className: "uppercase", children: o("iq") }),
                i.title,
              ],
            }),
            (0, t.jsxs)("div", {
              className: (0, c.cn)(
                "relative grid h-full grid-rows-[auto_1fr] gap-2 overflow-hidden rounded-t-lg",
                "highlighted" === i.type ? "bg-blue-highlight" : "bg-[#EAECF0]",
              ),
              children: [
                (0, t.jsx)("div", {
                  className: (0, c.cn)(
                    `px-2 text-center font-medium leading-none ${"highlighted" === i.type ? "text-white" : "text-black"} pt-3 text-sm`,
                  ),
                  dangerouslySetInnerHTML: { __html: (0, m.sanitizeTranslationHtml)(i.name || "") },
                }),
                (0, t.jsx)("div", {
                  className: (0, c.cn)(
                    `relative flex h-full w-full justify-center self-end overflow-hidden align-bottom ${2 !== a ? "max-xs-base:!h-[90%]" : ""}`,
                    i?.imageContainerClassName,
                  ),
                  children: (0, t.jsx)(u.default, {
                    src: i.imageUrl,
                    className: (0, c.cn)("object-contain object-bottom", i?.imageClassName),
                    alt: i.name || "Image",
                    fill: !0,
                    sizes: "(min-width: 1024px) 190px, 33vw",
                    priority: !0,
                    fetchPriority: "high",
                  }),
                }),
              ],
            }),
          ],
        });
      },
      y = (e) => {
        let { variant: i, scrollTarget: u, selectedHeroId: d } = e,
          c = ((e, t) => {
            let i = (0, r.useTranslations)(),
              [u, d] = (0, n.useState)(t);
            (0, n.useLayoutEffect)(() => {
              if (t) return;
              let e = l.accessSessionStorageUtil.getItem(a.StorageKeys.SELECTED_HERO_ID);
              e && s[e] && d(e);
            }, [e, t]);
            let c = u ? s[u] : void 0;
            switch (e) {
              case "myiq":
                return [
                  { type: "default", height: 236, title: "113", imageUrl: o.ImgCocoChanel },
                  {
                    type: "highlighted",
                    height: 255,
                    name: i("checkout_page_you"),
                    title: "???",
                    imageUrl: o.ImgHiddenPerson,
                  },
                  { type: "default", height: 276, title: "160", imageUrl: c ?? o.ImgSJ },
                ];
              case "personality":
                return [
                  {
                    type: "default",
                    height: 236,
                    title: i("personality_reformer"),
                    imageUrl: o.ImgCocoChanel,
                  },
                  {
                    type: "highlighted",
                    height: 255,
                    name: i("checkout_page_you"),
                    title: "???",
                    imageUrl: o.ImgHiddenPerson,
                  },
                  { type: "default", height: 276, title: i("personality_challenger"), imageUrl: o.ImgSJ },
                ];
              case "depression":
                return [
                  { type: "default", height: 236, title: "74%", imageUrl: o.ImgCocoChanel },
                  {
                    type: "highlighted",
                    height: 255,
                    name: i("checkout_page_you"),
                    title: "???",
                    imageUrl: o.ImgHiddenPerson,
                  },
                  { type: "default", height: 276, title: "42%", imageUrl: o.ImgSJ },
                ];
              case "autism":
                return [
                  {
                    type: "default",
                    height: 236,
                    title: i("report_autism_level_label_low"),
                    imageUrl: o.ImgHiddenPerson,
                  },
                  {
                    type: "highlighted",
                    height: 255,
                    name: i("checkout_page_you"),
                    title: "???",
                    imageUrl: o.ImgHiddenPerson,
                  },
                  {
                    type: "default",
                    height: 276,
                    title: i("report_autism_level_label_high"),
                    imageUrl: o.ImgHiddenPerson,
                  },
                ];
              case "enneagram":
                return [
                  { type: "default", height: 236, title: "Type 1", imageUrl: o.ImgCocoChanel },
                  {
                    type: "highlighted",
                    height: 255,
                    name: i("checkout_page_you"),
                    title: "???",
                    imageUrl: o.ImgHiddenPerson,
                  },
                  { type: "default", height: 276, title: "Type 8", imageUrl: o.ImgSJ },
                ];
              default:
                return [];
            }
          })(i, d);
        return (0, t.jsx)(t.Fragment, {
          children: c?.map((e, r) =>
            (0, t.jsx)(
              h,
              { data: e, variant: i, index: r, scrollTarget: u },
              e.name || `iq-comparison-item-${r}`,
            ),
          ),
        });
      };
    e.s(
      [
        "default",
        0,
        (e) => {
          let { variant: r, scrollTarget: n, showCertificateHero: a, selectedHeroId: l } = e;
          return a
            ? (0, t.jsx)(i.IqCertificateComponent, { scrollTarget: n })
            : (0, t.jsx)(y, { variant: r, scrollTarget: n, selectedHeroId: l });
        },
      ],
      275356,
    );
  },
  314307,
  function (e) {
    e.n(e.i(275356));
  },
]);
