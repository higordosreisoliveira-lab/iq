(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  943405,
  (e) => {
    "use strict";
    let t = (0, e.i(770703).default)(() => e.A(462668), { loadableGenerated: { modules: [194747] } });
    e.s(["TriviaAchivedBonusModalComponent", 0, t]);
  },
  158503,
  function (e) {
    e.n(e.i(943405));
  },
  462668,
  (e) => {
    e.v((t) => Promise.all(["static/chunks/3grmftgywyfpi.js"].map((t) => e.l(t))).then(() => t(194747)));
  },
]);
