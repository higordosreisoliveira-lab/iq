(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  320409,
  (t) => {
    "use strict";
    let s = (0, t.i(770703).default)(() => t.A(242466), { loadableGenerated: { modules: [107874] } });
    t.s(["TrustpilotCarouselComponent", 0, s]);
  },
  783491,
  function (t) {
    t.n(t.i(320409));
  },
  242466,
  (t) => {
    t.v((s) =>
      Promise.all(
        [
          "static/chunks/1268ak9wd3_bj.js",
          "static/chunks/3hrq2e3rg3wt3.js",
          "static/chunks/1j9mdc07lbjnu.css",
        ].map((s) => t.l(s)),
      ).then(() => s(107874)),
    );
  },
]);
