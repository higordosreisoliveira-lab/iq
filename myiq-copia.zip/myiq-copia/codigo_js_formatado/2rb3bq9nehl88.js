(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  861745,
  (e) => {
    "use strict";
    var t,
      r,
      i = e.i(271645);
    function s(e, t) {
      let r = t && t.cache ? t.cache : l,
        i = t && t.serializer ? t.serializer : h;
      return (
        t && t.strategy
          ? t.strategy
          : function (e, t) {
              var r, i;
              let s = 1 === e.length ? n : o;
              return ((r = t.cache.create()), (i = t.serializer), s.bind(this, e, r, i));
            }
      )(e, { cache: r, serializer: i });
    }
    function n(e, t, r, i) {
      let s = null == i || "number" == typeof i || "boolean" == typeof i ? i : r(i),
        n = t.get(s);
      return (void 0 === n && ((n = e.call(this, i)), t.set(s, n)), n);
    }
    function o(e, t, r) {
      let i = Array.prototype.slice.call(arguments, 3),
        s = r(i),
        n = t.get(s);
      return (void 0 === n && ((n = e.apply(this, i)), t.set(s, n)), n);
    }
    let h = function () {
      return JSON.stringify(arguments);
    };
    var a = class {
      constructor() {
        this.cache = Object.create(null);
      }
      get(e) {
        return this.cache[e];
      }
      set(e, t) {
        this.cache[e] = t;
      }
    };
    let l = {
        create: function () {
          return new a();
        },
      },
      u = {
        variadic: function (e, t) {
          var r, i;
          return ((r = t.cache.create()), (i = t.serializer), o.bind(this, e, r, i));
        },
        monadic: function (e, t) {
          var r, i;
          return ((r = t.cache.create()), (i = t.serializer), n.bind(this, e, r, i));
        },
      };
    class c extends Error {
      constructor(e, t) {
        let r = e;
        (t && (r += ": " + t), super(r), (this.code = e), t && (this.originalMessage = t));
      }
    }
    var m =
      (((t = m || {}).MISSING_MESSAGE = "MISSING_MESSAGE"),
      (t.MISSING_FORMAT = "MISSING_FORMAT"),
      (t.ENVIRONMENT_FALLBACK = "ENVIRONMENT_FALLBACK"),
      (t.INSUFFICIENT_PATH = "INSUFFICIENT_PATH"),
      (t.INVALID_MESSAGE = "INVALID_MESSAGE"),
      (t.INVALID_KEY = "INVALID_KEY"),
      (t.FORMATTING_ERROR = "FORMATTING_ERROR"),
      t);
    function f() {
      return {
        dateTime: {},
        number: {},
        message: {},
        relativeTime: {},
        pluralRules: {},
        list: {},
        displayNames: {},
      };
    }
    function p(e, t) {
      return s(e, {
        cache: {
          create: () => ({
            get: (e) => t[e],
            set(e, r) {
              t[e] = r;
            },
          }),
        },
        strategy: u.variadic,
      });
    }
    function g(e, t) {
      return p(function () {
        for (var t = arguments.length, r = Array(t), i = 0; i < t; i++) r[i] = arguments[i];
        return new e(...r);
      }, t);
    }
    function E(e) {
      return {
        getDateTimeFormat: g(Intl.DateTimeFormat, e.dateTime),
        getNumberFormat: g(Intl.NumberFormat, e.number),
        getPluralRules: g(Intl.PluralRules, e.pluralRules),
        getRelativeTimeFormat: g(Intl.RelativeTimeFormat, e.relativeTime),
        getListFormat: g(Intl.ListFormat, e.list),
        getDisplayNames: g(Intl.DisplayNames, e.displayNames),
      };
    }
    let b =
        /(?:[Eec]{1,6}|G{1,5}|[Qq]{1,5}|(?:[yYur]+|U{1,5})|[ML]{1,5}|d{1,2}|D{1,3}|F{1}|[abB]{1,5}|[hkHK]{1,2}|w{1,2}|W{1}|m{1,2}|s{1,2}|[zZOvVxX]{1,4})(?=([^']*'[^']*')*[^']*$)/g,
      H = /[\t-\r \x85\u200E\u200F\u2028\u2029]/i,
      y = /^\.(?:(0+)(\*)?|(#+)|(0+)(#+))$/g,
      B = /^(@+)?(\+|#+)?[rs]?$/g,
      d = /(\*)(0+)|(#+)(0+)|(0+)/g,
      T = /^(0+)$/;
    function A(e) {
      let t = {};
      return (
        "r" === e[e.length - 1]
          ? (t.roundingPriority = "morePrecision")
          : "s" === e[e.length - 1] && (t.roundingPriority = "lessPrecision"),
        e.replace(B, function (e, r, i) {
          return (
            "string" != typeof i
              ? ((t.minimumSignificantDigits = r.length), (t.maximumSignificantDigits = r.length))
              : "+" === i
                ? (t.minimumSignificantDigits = r.length)
                : "#" === r[0]
                  ? (t.maximumSignificantDigits = r.length)
                  : ((t.minimumSignificantDigits = r.length),
                    (t.maximumSignificantDigits = r.length + ("string" == typeof i ? i.length : 0))),
            ""
          );
        }),
        t
      );
    }
    function S(e) {
      switch (e) {
        case "sign-auto":
          return { signDisplay: "auto" };
        case "sign-accounting":
        case "()":
          return { currencySign: "accounting" };
        case "sign-always":
        case "+!":
          return { signDisplay: "always" };
        case "sign-accounting-always":
        case "()!":
          return { signDisplay: "always", currencySign: "accounting" };
        case "sign-except-zero":
        case "+?":
          return { signDisplay: "exceptZero" };
        case "sign-accounting-except-zero":
        case "()?":
          return { signDisplay: "exceptZero", currencySign: "accounting" };
        case "sign-never":
        case "+_":
          return { signDisplay: "never" };
      }
    }
    function I(e) {
      let t = S(e);
      return t || {};
    }
    let N =
      (((r = {})[(r.EXPECT_ARGUMENT_CLOSING_BRACE = 1)] = "EXPECT_ARGUMENT_CLOSING_BRACE"),
      (r[(r.EMPTY_ARGUMENT = 2)] = "EMPTY_ARGUMENT"),
      (r[(r.MALFORMED_ARGUMENT = 3)] = "MALFORMED_ARGUMENT"),
      (r[(r.EXPECT_ARGUMENT_TYPE = 4)] = "EXPECT_ARGUMENT_TYPE"),
      (r[(r.INVALID_ARGUMENT_TYPE = 5)] = "INVALID_ARGUMENT_TYPE"),
      (r[(r.EXPECT_ARGUMENT_STYLE = 6)] = "EXPECT_ARGUMENT_STYLE"),
      (r[(r.INVALID_NUMBER_SKELETON = 7)] = "INVALID_NUMBER_SKELETON"),
      (r[(r.INVALID_DATE_TIME_SKELETON = 8)] = "INVALID_DATE_TIME_SKELETON"),
      (r[(r.EXPECT_NUMBER_SKELETON = 9)] = "EXPECT_NUMBER_SKELETON"),
      (r[(r.EXPECT_DATE_TIME_SKELETON = 10)] = "EXPECT_DATE_TIME_SKELETON"),
      (r[(r.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE = 11)] = "UNCLOSED_QUOTE_IN_ARGUMENT_STYLE"),
      (r[(r.EXPECT_SELECT_ARGUMENT_OPTIONS = 12)] = "EXPECT_SELECT_ARGUMENT_OPTIONS"),
      (r[(r.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE = 13)] = "EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE"),
      (r[(r.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE = 14)] = "INVALID_PLURAL_ARGUMENT_OFFSET_VALUE"),
      (r[(r.EXPECT_SELECT_ARGUMENT_SELECTOR = 15)] = "EXPECT_SELECT_ARGUMENT_SELECTOR"),
      (r[(r.EXPECT_PLURAL_ARGUMENT_SELECTOR = 16)] = "EXPECT_PLURAL_ARGUMENT_SELECTOR"),
      (r[(r.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT = 17)] = "EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT"),
      (r[(r.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT = 18)] = "EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT"),
      (r[(r.INVALID_PLURAL_ARGUMENT_SELECTOR = 19)] = "INVALID_PLURAL_ARGUMENT_SELECTOR"),
      (r[(r.DUPLICATE_PLURAL_ARGUMENT_SELECTOR = 20)] = "DUPLICATE_PLURAL_ARGUMENT_SELECTOR"),
      (r[(r.DUPLICATE_SELECT_ARGUMENT_SELECTOR = 21)] = "DUPLICATE_SELECT_ARGUMENT_SELECTOR"),
      (r[(r.MISSING_OTHER_CLAUSE = 22)] = "MISSING_OTHER_CLAUSE"),
      (r[(r.INVALID_TAG = 23)] = "INVALID_TAG"),
      (r[(r.INVALID_TAG_NAME = 25)] = "INVALID_TAG_NAME"),
      (r[(r.UNMATCHED_CLOSING_TAG = 26)] = "UNMATCHED_CLOSING_TAG"),
      (r[(r.UNCLOSED_TAG = 27)] = "UNCLOSED_TAG"),
      r);
    function _(e) {
      return !!(e && "object" == typeof e && 0 === e.type);
    }
    function P(e) {
      return !!(e && "object" == typeof e && 1 === e.type);
    }
    let M = /[ \xA0\u1680\u2000-\u200A\u202F\u205F\u3000]/,
      L = {
        "001": ["H", "h"],
        419: ["h", "H", "hB", "hb"],
        AC: ["H", "h", "hb", "hB"],
        AD: ["H", "hB"],
        AE: ["h", "hB", "hb", "H"],
        AF: ["H", "hb", "hB", "h"],
        AG: ["h", "hb", "H", "hB"],
        AI: ["H", "h", "hb", "hB"],
        AL: ["h", "H", "hB"],
        AM: ["H", "hB"],
        AO: ["H", "hB"],
        AR: ["h", "H", "hB", "hb"],
        AS: ["h", "H"],
        AT: ["H", "hB"],
        AU: ["h", "hb", "H", "hB"],
        AW: ["H", "hB"],
        AX: ["H"],
        AZ: ["H", "hB", "h"],
        BA: ["H", "hB", "h"],
        BB: ["h", "hb", "H", "hB"],
        BD: ["h", "hB", "H"],
        BE: ["H", "hB"],
        BF: ["H", "hB"],
        BG: ["H", "hB", "h"],
        BH: ["h", "hB", "hb", "H"],
        BI: ["H", "h"],
        BJ: ["H", "hB"],
        BL: ["H", "hB"],
        BM: ["h", "hb", "H", "hB"],
        BN: ["hb", "hB", "h", "H"],
        BO: ["h", "H", "hB", "hb"],
        BQ: ["H"],
        BR: ["H", "hB"],
        BS: ["h", "hb", "H", "hB"],
        BT: ["h", "H"],
        BW: ["H", "h", "hb", "hB"],
        BY: ["H", "h"],
        BZ: ["H", "h", "hb", "hB"],
        CA: ["h", "hb", "H", "hB"],
        CC: ["H", "h", "hb", "hB"],
        CD: ["hB", "H"],
        CF: ["H", "h", "hB"],
        CG: ["H", "hB"],
        CH: ["H", "hB", "h"],
        CI: ["H", "hB"],
        CK: ["H", "h", "hb", "hB"],
        CL: ["h", "H", "hB", "hb"],
        CM: ["H", "h", "hB"],
        CN: ["H", "hB", "hb", "h"],
        CO: ["h", "H", "hB", "hb"],
        CP: ["H"],
        CR: ["h", "H", "hB", "hb"],
        CU: ["h", "H", "hB", "hb"],
        CV: ["H", "hB"],
        CW: ["H", "hB"],
        CX: ["H", "h", "hb", "hB"],
        CY: ["h", "H", "hb", "hB"],
        CZ: ["H"],
        DE: ["H", "hB"],
        DG: ["H", "h", "hb", "hB"],
        DJ: ["h", "H"],
        DK: ["H"],
        DM: ["h", "hb", "H", "hB"],
        DO: ["h", "H", "hB", "hb"],
        DZ: ["h", "hB", "hb", "H"],
        EA: ["H", "h", "hB", "hb"],
        EC: ["h", "H", "hB", "hb"],
        EE: ["H", "hB"],
        EG: ["h", "hB", "hb", "H"],
        EH: ["h", "hB", "hb", "H"],
        ER: ["h", "H"],
        ES: ["H", "hB", "h", "hb"],
        ET: ["hB", "hb", "h", "H"],
        FI: ["H"],
        FJ: ["h", "hb", "H", "hB"],
        FK: ["H", "h", "hb", "hB"],
        FM: ["h", "hb", "H", "hB"],
        FO: ["H", "h"],
        FR: ["H", "hB"],
        GA: ["H", "hB"],
        GB: ["H", "h", "hb", "hB"],
        GD: ["h", "hb", "H", "hB"],
        GE: ["H", "hB", "h"],
        GF: ["H", "hB"],
        GG: ["H", "h", "hb", "hB"],
        GH: ["h", "H"],
        GI: ["H", "h", "hb", "hB"],
        GL: ["H", "h"],
        GM: ["h", "hb", "H", "hB"],
        GN: ["H", "hB"],
        GP: ["H", "hB"],
        GQ: ["H", "hB", "h", "hb"],
        GR: ["h", "H", "hb", "hB"],
        GS: ["H", "h", "hb", "hB"],
        GT: ["h", "H", "hB", "hb"],
        GU: ["h", "hb", "H", "hB"],
        GW: ["H", "hB"],
        GY: ["h", "hb", "H", "hB"],
        HK: ["h", "hB", "hb", "H"],
        HN: ["h", "H", "hB", "hb"],
        HR: ["H", "hB"],
        HU: ["H", "h"],
        IC: ["H", "h", "hB", "hb"],
        ID: ["H"],
        IE: ["H", "h", "hb", "hB"],
        IL: ["H", "hB"],
        IM: ["H", "h", "hb", "hB"],
        IN: ["h", "H"],
        IO: ["H", "h", "hb", "hB"],
        IQ: ["h", "hB", "hb", "H"],
        IR: ["hB", "H"],
        IS: ["H"],
        IT: ["H", "hB"],
        JE: ["H", "h", "hb", "hB"],
        JM: ["h", "hb", "H", "hB"],
        JO: ["h", "hB", "hb", "H"],
        JP: ["H", "K", "h"],
        KE: ["hB", "hb", "H", "h"],
        KG: ["H", "h", "hB", "hb"],
        KH: ["hB", "h", "H", "hb"],
        KI: ["h", "hb", "H", "hB"],
        KM: ["H", "h", "hB", "hb"],
        KN: ["h", "hb", "H", "hB"],
        KP: ["h", "H", "hB", "hb"],
        KR: ["h", "H", "hB", "hb"],
        KW: ["h", "hB", "hb", "H"],
        KY: ["h", "hb", "H", "hB"],
        KZ: ["H", "hB"],
        LA: ["H", "hb", "hB", "h"],
        LB: ["h", "hB", "hb", "H"],
        LC: ["h", "hb", "H", "hB"],
        LI: ["H", "hB", "h"],
        LK: ["H", "h", "hB", "hb"],
        LR: ["h", "hb", "H", "hB"],
        LS: ["h", "H"],
        LT: ["H", "h", "hb", "hB"],
        LU: ["H", "h", "hB"],
        LV: ["H", "hB", "hb", "h"],
        LY: ["h", "hB", "hb", "H"],
        MA: ["H", "h", "hB", "hb"],
        MC: ["H", "hB"],
        MD: ["H", "hB"],
        ME: ["H", "hB", "h"],
        MF: ["H", "hB"],
        MG: ["H", "h"],
        MH: ["h", "hb", "H", "hB"],
        MK: ["H", "h", "hb", "hB"],
        ML: ["H"],
        MM: ["hB", "hb", "H", "h"],
        MN: ["H", "h", "hb", "hB"],
        MO: ["h", "hB", "hb", "H"],
        MP: ["h", "hb", "H", "hB"],
        MQ: ["H", "hB"],
        MR: ["h", "hB", "hb", "H"],
        MS: ["H", "h", "hb", "hB"],
        MT: ["H", "h"],
        MU: ["H", "h"],
        MV: ["H", "h"],
        MW: ["h", "hb", "H", "hB"],
        MX: ["h", "H", "hB", "hb"],
        MY: ["hb", "hB", "h", "H"],
        MZ: ["H", "hB"],
        NA: ["h", "H", "hB", "hb"],
        NC: ["H", "hB"],
        NE: ["H"],
        NF: ["H", "h", "hb", "hB"],
        NG: ["H", "h", "hb", "hB"],
        NI: ["h", "H", "hB", "hb"],
        NL: ["H", "hB"],
        NO: ["H", "h"],
        NP: ["H", "h", "hB"],
        NR: ["H", "h", "hb", "hB"],
        NU: ["H", "h", "hb", "hB"],
        NZ: ["h", "hb", "H", "hB"],
        OM: ["h", "hB", "hb", "H"],
        PA: ["h", "H", "hB", "hb"],
        PE: ["h", "H", "hB", "hb"],
        PF: ["H", "h", "hB"],
        PG: ["h", "H"],
        PH: ["h", "hB", "hb", "H"],
        PK: ["h", "hB", "H"],
        PL: ["H", "h"],
        PM: ["H", "hB"],
        PN: ["H", "h", "hb", "hB"],
        PR: ["h", "H", "hB", "hb"],
        PS: ["h", "hB", "hb", "H"],
        PT: ["H", "hB"],
        PW: ["h", "H"],
        PY: ["h", "H", "hB", "hb"],
        QA: ["h", "hB", "hb", "H"],
        RE: ["H", "hB"],
        RO: ["H", "hB"],
        RS: ["H", "hB", "h"],
        RU: ["H"],
        RW: ["H", "h"],
        SA: ["h", "hB", "hb", "H"],
        SB: ["h", "hb", "H", "hB"],
        SC: ["H", "h", "hB"],
        SD: ["h", "hB", "hb", "H"],
        SE: ["H"],
        SG: ["h", "hb", "H", "hB"],
        SH: ["H", "h", "hb", "hB"],
        SI: ["H", "hB"],
        SJ: ["H"],
        SK: ["H"],
        SL: ["h", "hb", "H", "hB"],
        SM: ["H", "h", "hB"],
        SN: ["H", "h", "hB"],
        SO: ["h", "H"],
        SR: ["H", "hB"],
        SS: ["h", "hb", "H", "hB"],
        ST: ["H", "hB"],
        SV: ["h", "H", "hB", "hb"],
        SX: ["H", "h", "hb", "hB"],
        SY: ["h", "hB", "hb", "H"],
        SZ: ["h", "hb", "H", "hB"],
        TA: ["H", "h", "hb", "hB"],
        TC: ["h", "hb", "H", "hB"],
        TD: ["h", "H", "hB"],
        TF: ["H", "h", "hB"],
        TG: ["H", "hB"],
        TH: ["H", "h"],
        TJ: ["H", "h"],
        TL: ["H", "hB", "hb", "h"],
        TM: ["H", "h"],
        TN: ["h", "hB", "hb", "H"],
        TO: ["h", "H"],
        TR: ["H", "hB"],
        TT: ["h", "hb", "H", "hB"],
        TW: ["hB", "hb", "h", "H"],
        TZ: ["hB", "hb", "H", "h"],
        UA: ["H", "hB", "h"],
        UG: ["hB", "hb", "H", "h"],
        UM: ["h", "hb", "H", "hB"],
        US: ["h", "hb", "H", "hB"],
        UY: ["h", "H", "hB", "hb"],
        UZ: ["H", "hB", "h"],
        VA: ["H", "h", "hB"],
        VC: ["h", "hb", "H", "hB"],
        VE: ["h", "H", "hB", "hb"],
        VG: ["h", "hb", "H", "hB"],
        VI: ["h", "hb", "H", "hB"],
        VN: ["H", "h"],
        VU: ["h", "H"],
        WF: ["H", "hB"],
        WS: ["h", "H"],
        XK: ["H", "hB", "h"],
        YE: ["h", "hB", "hb", "H"],
        YT: ["H", "hB"],
        ZA: ["H", "h", "hb", "hB"],
        ZM: ["h", "hb", "H", "hB"],
        ZW: ["H", "h"],
        "af-ZA": ["H", "h", "hB", "hb"],
        "ar-001": ["h", "hB", "hb", "H"],
        "ca-ES": ["H", "h", "hB"],
        "en-001": ["h", "hb", "H", "hB"],
        "en-HK": ["h", "hb", "H", "hB"],
        "en-IL": ["H", "h", "hb", "hB"],
        "en-MY": ["h", "hb", "H", "hB"],
        "es-BR": ["H", "h", "hB", "hb"],
        "es-ES": ["H", "h", "hB", "hb"],
        "es-GQ": ["H", "h", "hB", "hb"],
        "fr-CA": ["H", "h", "hB"],
        "gl-ES": ["H", "h", "hB"],
        "gu-IN": ["hB", "hb", "h", "H"],
        "hi-IN": ["hB", "h", "H"],
        "it-CH": ["H", "h", "hB"],
        "it-IT": ["H", "h", "hB"],
        "kn-IN": ["hB", "h", "H"],
        "ku-SY": ["H", "hB"],
        "ml-IN": ["hB", "h", "H"],
        "mr-IN": ["hB", "hb", "h", "H"],
        "pa-IN": ["hB", "hb", "h", "H"],
        "ta-IN": ["hB", "h", "hb", "H"],
        "te-IN": ["hB", "h", "H"],
        "zu-ZA": ["H", "hB", "hb", "h"],
      },
      v = RegExp(`^${M.source}*`),
      R = RegExp(`${M.source}*$`);
    function O(e, t) {
      return { start: e, end: t };
    }
    let w = !!Object.fromEntries,
      C = !!String.prototype.trimStart,
      F = !!String.prototype.trimEnd,
      D = w
        ? Object.fromEntries
        : function (e) {
            let t = {};
            for (let [r, i] of e) t[r] = i;
            return t;
          },
      G = C
        ? function (e) {
            return e.trimStart();
          }
        : function (e) {
            return e.replace(v, "");
          },
      U = F
        ? function (e) {
            return e.trimEnd();
          }
        : function (e) {
            return e.replace(R, "");
          },
      k = RegExp("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
    var V = class {
      constructor(e, t = {}) {
        ((this.message = e),
          (this.position = { offset: 0, line: 1, column: 1 }),
          (this.ignoreTag = !!t.ignoreTag),
          (this.locale = t.locale),
          (this.requiresOtherClause = !!t.requiresOtherClause),
          (this.shouldParseSkeletons = !!t.shouldParseSkeletons));
      }
      parse() {
        if (0 !== this.offset()) throw Error("parser can only be used once");
        if (this.message.length > 0) {
          let e = this.message.charCodeAt(0);
          if (35 !== e && 39 !== e && 60 !== e && 123 !== e && 125 !== e) {
            let e = (function (e) {
              if (0 === e.length) return null;
              let t = 1,
                r = 1;
              for (let i = 0; i < e.length;) {
                let s = e.charCodeAt(i);
                switch (s) {
                  case 35:
                  case 39:
                  case 60:
                  case 123:
                  case 125:
                    return null;
                }
                if (10 === s) (t++, (r = 1), i++);
                else if ((r++, s >= 55296 && s <= 56319 && i + 1 < e.length)) {
                  let t = e.charCodeAt(i + 1);
                  i += t >= 56320 && t <= 57343 ? 2 : 1;
                } else i++;
              }
              return { offset: e.length, line: t, column: r };
            })(this.message);
            if (e) {
              let t = this.clonePosition();
              return (
                (this.position = e),
                { val: [{ type: 0, value: this.message, location: O(t, this.clonePosition()) }], err: null }
              );
            }
          }
        }
        return this.parseMessage(0, "", !1);
      }
      parseMessage(e, t, r) {
        let i = [];
        for (; !this.isEOF();) {
          let s = this.char();
          if (123 === s) {
            let t = this.parseArgument(e, r);
            if (t.err) return t;
            i.push(t.val);
          } else if (125 === s && e > 0) break;
          else if (35 === s && ("plural" === t || "selectordinal" === t)) {
            let e = this.clonePosition();
            (this.bump(), i.push({ type: 7, location: O(e, this.clonePosition()) }));
          } else if (60 !== s || this.ignoreTag || 47 !== this.peek())
            if (60 === s && !this.ignoreTag && K(this.peek() || 0)) {
              let r = this.parseTag(e, t);
              if (r.err) return r;
              i.push(r.val);
            } else {
              let r = this.parseLiteral(e, t);
              if (r.err) return r;
              i.push(r.val);
            }
          else if (!r) return this.error(26, O(this.clonePosition(), this.clonePosition()));
          else break;
        }
        return { val: i, err: null };
      }
      parseTag(e, t) {
        let r = this.clonePosition();
        this.bump();
        let i = this.parseTagName();
        if ((this.bumpSpace(), this.bumpIf("/>")))
          return { val: { type: 0, value: `<${i}/>`, location: O(r, this.clonePosition()) }, err: null };
        if (!this.bumpIf(">")) return this.error(23, O(r, this.clonePosition()));
        {
          let s = this.parseMessage(e + 1, t, !0);
          if (s.err) return s;
          let n = s.val,
            o = this.clonePosition();
          if (!this.bumpIf("</")) return this.error(27, O(r, this.clonePosition()));
          {
            if (this.isEOF() || !K(this.char())) return this.error(23, O(o, this.clonePosition()));
            let e = this.clonePosition();
            return i !== this.parseTagName()
              ? this.error(26, O(e, this.clonePosition()))
              : (this.bumpSpace(), this.bumpIf(">"))
                ? { val: { type: 8, value: i, children: n, location: O(r, this.clonePosition()) }, err: null }
                : this.error(23, O(o, this.clonePosition()));
          }
        }
      }
      parseTagName() {
        var e;
        let t = this.offset();
        for (
          this.bump();
          !this.isEOF() &&
          (45 === (e = this.char()) ||
            46 === e ||
            (e >= 48 && e <= 57) ||
            95 === e ||
            (e >= 97 && e <= 122) ||
            (e >= 65 && e <= 90) ||
            183 == e ||
            (e >= 192 && e <= 214) ||
            (e >= 216 && e <= 246) ||
            (e >= 248 && e <= 893) ||
            (e >= 895 && e <= 8191) ||
            (e >= 8204 && e <= 8205) ||
            (e >= 8255 && e <= 8256) ||
            (e >= 8304 && e <= 8591) ||
            (e >= 11264 && e <= 12271) ||
            (e >= 12289 && e <= 55295) ||
            (e >= 63744 && e <= 64975) ||
            (e >= 65008 && e <= 65533) ||
            (e >= 65536 && e <= 983039));
        )
          this.bump();
        return this.message.slice(t, this.offset());
      }
      parseLiteral(e, t) {
        let r = this.clonePosition(),
          i = "";
        for (;;) {
          let r = this.tryParseQuote(t);
          if (r) {
            i += r;
            continue;
          }
          let s = this.tryParseUnquoted(e, t);
          if (s) {
            i += s;
            continue;
          }
          let n = this.tryParseLeftAngleBracket();
          if (n) {
            i += n;
            continue;
          }
          break;
        }
        return { val: { type: 0, value: i, location: O(r, this.clonePosition()) }, err: null };
      }
      tryParseLeftAngleBracket() {
        var e;
        return this.isEOF() ||
          60 !== this.char() ||
          (!this.ignoreTag && (K((e = this.peek() || 0)) || 47 === e))
          ? null
          : (this.bump(), "<");
      }
      tryParseQuote(e) {
        if (this.isEOF() || 39 !== this.char()) return null;
        switch (this.peek()) {
          case 39:
            return (this.bump(), this.bump(), "'");
          case 123:
          case 60:
          case 62:
          case 125:
            break;
          case 35:
            if ("plural" === e || "selectordinal" === e) break;
            return null;
          default:
            return null;
        }
        this.bump();
        let t = [this.char()];
        for (this.bump(); !this.isEOF();) {
          let e = this.char();
          if (39 === e)
            if (39 === this.peek()) (t.push(39), this.bump());
            else {
              this.bump();
              break;
            }
          else t.push(e);
          this.bump();
        }
        return String.fromCodePoint(...t);
      }
      tryParseUnquoted(e, t) {
        if (this.isEOF()) return null;
        let r = this.char();
        return 60 === r ||
          123 === r ||
          (35 === r && ("plural" === t || "selectordinal" === t)) ||
          (125 === r && e > 0)
          ? null
          : (this.bump(), String.fromCodePoint(r));
      }
      parseArgument(e, t) {
        let r = this.clonePosition();
        if ((this.bump(), this.bumpSpace(), this.isEOF())) return this.error(1, O(r, this.clonePosition()));
        if (125 === this.char()) return (this.bump(), this.error(2, O(r, this.clonePosition())));
        let i = this.parseIdentifierIfPossible().value;
        if (!i) return this.error(3, O(r, this.clonePosition()));
        if ((this.bumpSpace(), this.isEOF())) return this.error(1, O(r, this.clonePosition()));
        switch (this.char()) {
          case 125:
            return (
              this.bump(),
              { val: { type: 1, value: i, location: O(r, this.clonePosition()) }, err: null }
            );
          case 44:
            if ((this.bump(), this.bumpSpace(), this.isEOF()))
              return this.error(1, O(r, this.clonePosition()));
            return this.parseArgumentOptions(e, t, i, r);
          default:
            return this.error(3, O(r, this.clonePosition()));
        }
      }
      parseIdentifierIfPossible() {
        var e;
        let t = this.clonePosition(),
          r = this.offset(),
          i = ((e = this.message), (k.lastIndex = r), k.exec(e)[1] ?? ""),
          s = r + i.length;
        return (this.bumpTo(s), { value: i, location: O(t, this.clonePosition()) });
      }
      parseArgumentOptions(e, t, r, i) {
        let s = this.clonePosition(),
          n = this.parseIdentifierIfPossible().value,
          o = this.clonePosition();
        switch (n) {
          case "":
            return this.error(4, O(s, o));
          case "number":
          case "date":
          case "time": {
            this.bumpSpace();
            let e = null;
            if (this.bumpIf(",")) {
              this.bumpSpace();
              let t = this.clonePosition(),
                r = this.parseSimpleArgStyleIfPossible();
              if (r.err) return r;
              let i = U(r.val);
              if (0 === i.length) return this.error(6, O(this.clonePosition(), this.clonePosition()));
              e = { style: i, styleLocation: O(t, this.clonePosition()) };
            }
            let t = this.tryParseArgumentClose(i);
            if (t.err) return t;
            let s = O(i, this.clonePosition());
            if (e && e.style.startsWith("::")) {
              let t = G(e.style.slice(2));
              if ("number" === n) {
                let i = this.parseNumberSkeletonFromString(t, e.styleLocation);
                if (i.err) return i;
                return { val: { type: 2, value: r, location: s, style: i.val }, err: null };
              }
              {
                let i;
                if (0 === t.length) return this.error(10, s);
                let o = t;
                return (
                  this.locale &&
                    (o = (function (e, t) {
                      let r = "";
                      for (let i = 0; i < e.length; i++) {
                        let s = e.charAt(i);
                        if ("j" === s) {
                          let n = 0;
                          for (; i + 1 < e.length && e.charAt(i + 1) === s;) (n++, i++);
                          let o = 1 + (1 & n),
                            h = n < 2 ? 1 : 3 + (n >> 1),
                            a = (function (e) {
                              let t,
                                r = e.hourCycle;
                              if (
                                (void 0 === r && e.hourCycles && e.hourCycles.length && (r = e.hourCycles[0]),
                                r)
                              )
                                switch (r) {
                                  case "h24":
                                    return "k";
                                  case "h23":
                                    return "H";
                                  case "h12":
                                    return "h";
                                  case "h11":
                                    return "K";
                                  default:
                                    throw Error("Invalid hourCycle");
                                }
                              let i = e.language;
                              return (
                                "root" !== i && (t = e.maximize().region),
                                (L[t || ""] || L[i || ""] || L[`${i}-001`] || L["001"])[0]
                              );
                            })(t);
                          for (("H" == a || "k" == a) && (h = 0); h-- > 0;) r += "a";
                          for (; o-- > 0;) r = a + r;
                        } else "J" === s ? (r += "H") : (r += s);
                      }
                      return r;
                    })(t, this.locale)),
                  {
                    val: {
                      type: "date" === n ? 3 : 4,
                      value: r,
                      location: s,
                      style: {
                        type: 1,
                        pattern: o,
                        location: e.styleLocation,
                        parsedOptions: this.shouldParseSkeletons
                          ? ((i = {}),
                            o.replace(b, (e) => {
                              let t = e.length;
                              switch (e[0]) {
                                case "G":
                                  i.era = 4 === t ? "long" : 5 === t ? "narrow" : "short";
                                  break;
                                case "y":
                                  i.year = 2 === t ? "2-digit" : "numeric";
                                  break;
                                case "Y":
                                case "u":
                                case "U":
                                case "r":
                                  throw RangeError(
                                    "`Y/u/U/r` (year) patterns are not supported, use `y` instead",
                                  );
                                case "q":
                                case "Q":
                                  throw RangeError("`q/Q` (quarter) patterns are not supported");
                                case "M":
                                case "L":
                                  i.month = ["numeric", "2-digit", "short", "long", "narrow"][t - 1];
                                  break;
                                case "w":
                                case "W":
                                  throw RangeError("`w/W` (week) patterns are not supported");
                                case "d":
                                  i.day = ["numeric", "2-digit"][t - 1];
                                  break;
                                case "D":
                                case "F":
                                case "g":
                                  throw RangeError(
                                    "`D/F/g` (day) patterns are not supported, use `d` instead",
                                  );
                                case "E":
                                  i.weekday = 4 === t ? "long" : 5 === t ? "narrow" : "short";
                                  break;
                                case "e":
                                  if (t < 4)
                                    throw RangeError("`e..eee` (weekday) patterns are not supported");
                                  i.weekday = ["short", "long", "narrow", "short"][t - 3];
                                  break;
                                case "c":
                                  if (t < 4)
                                    throw RangeError("`c..ccc` (weekday) patterns are not supported");
                                  i.weekday = ["short", "long", "narrow", "short"][t - 3];
                                  break;
                                case "a":
                                  i.hour12 = !0;
                                  break;
                                case "b":
                                case "B":
                                  throw RangeError(
                                    "`b/B` (period) patterns are not supported, use `a` instead",
                                  );
                                case "h":
                                  ((i.hourCycle = "h12"), (i.hour = ["numeric", "2-digit"][t - 1]));
                                  break;
                                case "H":
                                  ((i.hourCycle = "h23"), (i.hour = ["numeric", "2-digit"][t - 1]));
                                  break;
                                case "K":
                                  ((i.hourCycle = "h11"), (i.hour = ["numeric", "2-digit"][t - 1]));
                                  break;
                                case "k":
                                  ((i.hourCycle = "h24"), (i.hour = ["numeric", "2-digit"][t - 1]));
                                  break;
                                case "j":
                                case "J":
                                case "C":
                                  throw RangeError(
                                    "`j/J/C` (hour) patterns are not supported, use `h/H/K/k` instead",
                                  );
                                case "m":
                                  i.minute = ["numeric", "2-digit"][t - 1];
                                  break;
                                case "s":
                                  i.second = ["numeric", "2-digit"][t - 1];
                                  break;
                                case "S":
                                case "A":
                                  throw RangeError(
                                    "`S/A` (second) patterns are not supported, use `s` instead",
                                  );
                                case "z":
                                  i.timeZoneName = t < 4 ? "short" : "long";
                                  break;
                                case "Z":
                                case "O":
                                case "v":
                                case "V":
                                case "X":
                                case "x":
                                  throw RangeError(
                                    "`Z/O/v/V/X/x` (timeZone) patterns are not supported, use `z` instead",
                                  );
                              }
                              return "";
                            }),
                            i)
                          : {},
                      },
                    },
                    err: null,
                  }
                );
              }
            }
            return {
              val: {
                type: "number" === n ? 2 : "date" === n ? 3 : 4,
                value: r,
                location: s,
                style: e?.style ?? null,
              },
              err: null,
            };
          }
          case "plural":
          case "selectordinal":
          case "select": {
            let s = this.clonePosition();
            if ((this.bumpSpace(), !this.bumpIf(","))) return this.error(12, O(s, { ...s }));
            this.bumpSpace();
            let o = this.parseIdentifierIfPossible(),
              h = 0;
            if ("select" !== n && "offset" === o.value) {
              if (!this.bumpIf(":")) return this.error(13, O(this.clonePosition(), this.clonePosition()));
              this.bumpSpace();
              let e = this.tryParseDecimalInteger(13, 14);
              if (e.err) return e;
              (this.bumpSpace(), (o = this.parseIdentifierIfPossible()), (h = e.val));
            }
            let a = this.tryParsePluralOrSelectOptions(e, n, t, o);
            if (a.err) return a;
            let l = this.tryParseArgumentClose(i);
            if (l.err) return l;
            let u = O(i, this.clonePosition());
            if ("select" === n)
              return { val: { type: 5, value: r, options: D(a.val), location: u }, err: null };
            return {
              val: {
                type: 6,
                value: r,
                options: D(a.val),
                offset: h,
                pluralType: "plural" === n ? "cardinal" : "ordinal",
                location: u,
              },
              err: null,
            };
          }
          default:
            return this.error(5, O(s, o));
        }
      }
      tryParseArgumentClose(e) {
        return this.isEOF() || 125 !== this.char()
          ? this.error(1, O(e, this.clonePosition()))
          : (this.bump(), { val: !0, err: null });
      }
      parseSimpleArgStyleIfPossible() {
        let e = 0,
          t = this.clonePosition();
        for (; !this.isEOF();)
          switch (this.char()) {
            case 39: {
              this.bump();
              let e = this.clonePosition();
              if (!this.bumpUntil("'")) return this.error(11, O(e, this.clonePosition()));
              this.bump();
              break;
            }
            case 123:
              ((e += 1), this.bump());
              break;
            case 125:
              if (!(e > 0)) return { val: this.message.slice(t.offset, this.offset()), err: null };
              e -= 1;
              break;
            default:
              this.bump();
          }
        return { val: this.message.slice(t.offset, this.offset()), err: null };
      }
      parseNumberSkeletonFromString(e, t) {
        let r = [];
        try {
          r = (function (e) {
            if (0 === e.length) throw Error("Number skeleton cannot be empty");
            let t = e.split(H).filter((e) => e.length > 0),
              r = [];
            for (let e of t) {
              let t = e.split("/");
              if (0 === t.length) throw Error("Invalid number skeleton");
              let [i, ...s] = t;
              for (let e of s) if (0 === e.length) throw Error("Invalid number skeleton");
              r.push({ stem: i, options: s });
            }
            return r;
          })(e);
        } catch {
          return this.error(7, t);
        }
        return {
          val: {
            type: 0,
            tokens: r,
            location: t,
            parsedOptions: this.shouldParseSkeletons
              ? (function (e) {
                  let t = {};
                  for (let r of e) {
                    switch (r.stem) {
                      case "percent":
                      case "%":
                        t.style = "percent";
                        continue;
                      case "%x100":
                        ((t.style = "percent"), (t.scale = 100));
                        continue;
                      case "currency":
                        ((t.style = "currency"), (t.currency = r.options[0]));
                        continue;
                      case "group-off":
                      case ",_":
                        t.useGrouping = !1;
                        continue;
                      case "precision-integer":
                      case ".":
                        t.maximumFractionDigits = 0;
                        continue;
                      case "measure-unit":
                      case "unit":
                        ((t.style = "unit"), (t.unit = r.options[0].replace(/^(.*?)-/, "")));
                        continue;
                      case "compact-short":
                      case "K":
                        ((t.notation = "compact"), (t.compactDisplay = "short"));
                        continue;
                      case "compact-long":
                      case "KK":
                        ((t.notation = "compact"), (t.compactDisplay = "long"));
                        continue;
                      case "scientific":
                        t = {
                          ...t,
                          notation: "scientific",
                          ...r.options.reduce((e, t) => ({ ...e, ...I(t) }), {}),
                        };
                        continue;
                      case "engineering":
                        t = {
                          ...t,
                          notation: "engineering",
                          ...r.options.reduce((e, t) => ({ ...e, ...I(t) }), {}),
                        };
                        continue;
                      case "notation-simple":
                        t.notation = "standard";
                        continue;
                      case "unit-width-narrow":
                        ((t.currencyDisplay = "narrowSymbol"), (t.unitDisplay = "narrow"));
                        continue;
                      case "unit-width-short":
                        ((t.currencyDisplay = "code"), (t.unitDisplay = "short"));
                        continue;
                      case "unit-width-full-name":
                        ((t.currencyDisplay = "name"), (t.unitDisplay = "long"));
                        continue;
                      case "unit-width-iso-code":
                        t.currencyDisplay = "symbol";
                        continue;
                      case "scale":
                        t.scale = parseFloat(r.options[0]);
                        continue;
                      case "rounding-mode-floor":
                        t.roundingMode = "floor";
                        continue;
                      case "rounding-mode-ceiling":
                        t.roundingMode = "ceil";
                        continue;
                      case "rounding-mode-down":
                        t.roundingMode = "trunc";
                        continue;
                      case "rounding-mode-up":
                        t.roundingMode = "expand";
                        continue;
                      case "rounding-mode-half-even":
                        t.roundingMode = "halfEven";
                        continue;
                      case "rounding-mode-half-down":
                        t.roundingMode = "halfTrunc";
                        continue;
                      case "rounding-mode-half-up":
                        t.roundingMode = "halfExpand";
                        continue;
                      case "integer-width":
                        if (r.options.length > 1)
                          throw RangeError("integer-width stems only accept a single optional option");
                        r.options[0].replace(d, function (e, r, i, s, n, o) {
                          if (r) t.minimumIntegerDigits = i.length;
                          else if (s && n) throw Error("We currently do not support maximum integer digits");
                          else if (o) throw Error("We currently do not support exact integer digits");
                          return "";
                        });
                        continue;
                    }
                    if (T.test(r.stem)) {
                      t.minimumIntegerDigits = r.stem.length;
                      continue;
                    }
                    if (y.test(r.stem)) {
                      if (r.options.length > 1)
                        throw RangeError("Fraction-precision stems only accept a single optional option");
                      r.stem.replace(y, function (e, r, i, s, n, o) {
                        return (
                          "*" === i
                            ? (t.minimumFractionDigits = r.length)
                            : s && "#" === s[0]
                              ? (t.maximumFractionDigits = s.length)
                              : n && o
                                ? ((t.minimumFractionDigits = n.length),
                                  (t.maximumFractionDigits = n.length + o.length))
                                : ((t.minimumFractionDigits = r.length),
                                  (t.maximumFractionDigits = r.length)),
                          ""
                        );
                      });
                      let e = r.options[0];
                      "w" === e
                        ? (t = { ...t, trailingZeroDisplay: "stripIfInteger" })
                        : e && (t = { ...t, ...A(e) });
                      continue;
                    }
                    if (B.test(r.stem)) {
                      t = { ...t, ...A(r.stem) };
                      continue;
                    }
                    let e = S(r.stem);
                    e && (t = { ...t, ...e });
                    let i = (function (e) {
                      let t;
                      if (
                        ("E" === e[0] && "E" === e[1]
                          ? ((t = { notation: "engineering" }), (e = e.slice(2)))
                          : "E" === e[0] && ((t = { notation: "scientific" }), (e = e.slice(1))),
                        t)
                      ) {
                        let r = e.slice(0, 2);
                        if (
                          ("+!" === r
                            ? ((t.signDisplay = "always"), (e = e.slice(2)))
                            : "+?" === r && ((t.signDisplay = "exceptZero"), (e = e.slice(2))),
                          !T.test(e))
                        )
                          throw Error("Malformed concise eng/scientific notation");
                        t.minimumIntegerDigits = e.length;
                      }
                      return t;
                    })(r.stem);
                    i && (t = { ...t, ...i });
                  }
                  return t;
                })(r)
              : {},
          },
          err: null,
        };
      }
      tryParsePluralOrSelectOptions(e, t, r, i) {
        let s = !1,
          n = [],
          o = new Set(),
          { value: h, location: a } = i;
        for (;;) {
          if (0 === h.length) {
            let e = this.clonePosition();
            if ("select" !== t && this.bumpIf("=")) {
              let t = this.tryParseDecimalInteger(16, 19);
              if (t.err) return t;
              ((a = O(e, this.clonePosition())), (h = this.message.slice(e.offset, this.offset())));
            } else break;
          }
          if (o.has(h)) return this.error("select" === t ? 21 : 20, a);
          ("other" === h && (s = !0), this.bumpSpace());
          let i = this.clonePosition();
          if (!this.bumpIf("{"))
            return this.error("select" === t ? 17 : 18, O(this.clonePosition(), this.clonePosition()));
          let l = this.parseMessage(e + 1, t, r);
          if (l.err) return l;
          let u = this.tryParseArgumentClose(i);
          if (u.err) return u;
          (n.push([h, { value: l.val, location: O(i, this.clonePosition()) }]),
            o.add(h),
            this.bumpSpace(),
            ({ value: h, location: a } = this.parseIdentifierIfPossible()));
        }
        return 0 === n.length
          ? this.error("select" === t ? 15 : 16, O(this.clonePosition(), this.clonePosition()))
          : this.requiresOtherClause && !s
            ? this.error(22, O(this.clonePosition(), this.clonePosition()))
            : { val: n, err: null };
      }
      tryParseDecimalInteger(e, t) {
        let r = 1,
          i = this.clonePosition();
        this.bumpIf("+") || (this.bumpIf("-") && (r = -1));
        let s = !1,
          n = 0;
        for (; !this.isEOF();) {
          let e = this.char();
          if (e >= 48 && e <= 57) ((s = !0), (n = 10 * n + (e - 48)), this.bump());
          else break;
        }
        let o = O(i, this.clonePosition());
        return s
          ? Number.isSafeInteger((n *= r))
            ? { val: n, err: null }
            : this.error(t, o)
          : this.error(e, o);
      }
      offset() {
        return this.position.offset;
      }
      isEOF() {
        return this.offset() === this.message.length;
      }
      clonePosition() {
        return { offset: this.position.offset, line: this.position.line, column: this.position.column };
      }
      char() {
        let e = this.position.offset;
        if (e >= this.message.length) throw Error("out of bound");
        let t = this.message.codePointAt(e);
        if (void 0 === t) throw Error(`Offset ${e} is at invalid UTF-16 code unit boundary`);
        return t;
      }
      error(e, t) {
        return { val: null, err: { kind: e, message: this.message, location: t } };
      }
      bump() {
        if (this.isEOF()) return;
        let e = this.char();
        10 === e
          ? ((this.position.line += 1), (this.position.column = 1), (this.position.offset += 1))
          : ((this.position.column += 1), (this.position.offset += e < 65536 ? 1 : 2));
      }
      bumpIf(e) {
        if (this.message.startsWith(e, this.offset())) {
          for (let t = 0; t < e.length; t++) this.bump();
          return !0;
        }
        return !1;
      }
      bumpUntil(e) {
        let t = this.offset(),
          r = this.message.indexOf(e, t);
        return r >= 0 ? (this.bumpTo(r), !0) : (this.bumpTo(this.message.length), !1);
      }
      bumpTo(e) {
        if (this.offset() > e)
          throw Error(
            `targetOffset ${e} must be greater than or equal to the current offset ${this.offset()}`,
          );
        for (e = Math.min(e, this.message.length); ;) {
          let t = this.offset();
          if (t === e) break;
          if (t > e) throw Error(`targetOffset ${e} is at invalid UTF-16 code unit boundary`);
          if ((this.bump(), this.isEOF())) break;
        }
      }
      bumpSpace() {
        for (
          var e;
          !this.isEOF() &&
          (((e = this.char()) >= 9 && e <= 13) ||
            32 === e ||
            133 === e ||
            (e >= 8206 && e <= 8207) ||
            8232 === e ||
            8233 === e);
        )
          this.bump();
      }
      peek() {
        if (this.isEOF()) return null;
        let e = this.char(),
          t = this.offset();
        return this.message.charCodeAt(t + (e >= 65536 ? 2 : 1)) ?? null;
      }
    };
    function K(e) {
      return (e >= 97 && e <= 122) || (e >= 65 && e <= 90);
    }
    function x(e) {
      let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
        r = new V(e, (t = { shouldParseSkeletons: !0, requiresOtherClause: !0, ...t })).parse();
      if (r.err) {
        let e = SyntaxError(N[r.err.kind]);
        throw ((e.location = r.err.location), (e.originalMessage = r.err.message), e);
      }
      return (
        t?.captureLocation ||
          (function e(t) {
            t.forEach((t) => {
              if ((delete t.location, 5 === t.type || 6 === t.type))
                for (let r in t.options) (delete t.options[r].location, e(t.options[r].value));
              else
                (2 === t.type && _(t.style)) || ((3 === t.type || 4 === t.type) && P(t.style))
                  ? delete t.style.location
                  : 8 === t.type && e(t.children);
            });
          })(r.val),
        r.val
      );
    }
    var Z = class extends Error {
        constructor(e, t, r) {
          (super(e), (this.code = t), (this.originalMessage = r));
        }
        toString() {
          return `[formatjs Error: ${this.code}] ${this.message}`;
        }
      },
      X = class extends Z {
        constructor(e, t, r, i) {
          super(
            `Invalid values for "${e}": "${t}". Options are "${Object.keys(r).join('", "')}"`,
            "INVALID_VALUE",
            i,
          );
        }
      },
      j = class extends Z {
        constructor(e, t, r) {
          super(`Value for "${e}" must be of type ${t}`, "INVALID_VALUE", r);
        }
      },
      Y = class extends Z {
        constructor(e, t) {
          super(
            `The intl string context variable "${e}" was not provided to the string "${t}"`,
            "MISSING_VALUE",
            t,
          );
        }
      };
    function $(e) {
      return {
        create: () => ({
          get: (t) => e[t],
          set(t, r) {
            e[t] = r;
          },
        }),
      };
    }
    var W = class e {
      constructor(t, r = e.defaultLocale, i, n) {
        if (
          ((this.formatterCache = { number: {}, dateTime: {}, pluralRules: {} }),
          (this.format = (e) => {
            let t = this.formatToParts(e);
            if (1 === t.length) return t[0].value;
            let r = t.reduce(
              (e, t) => (
                e.length && 0 === t.type && "string" == typeof e[e.length - 1]
                  ? (e[e.length - 1] += t.value)
                  : e.push(t.value),
                e
              ),
              [],
            );
            return r.length <= 1 ? r[0] || "" : r;
          }),
          (this.formatToParts = (e) =>
            (function e(t, r, i, s, n, o, h) {
              if (1 === t.length && 0 === t[0].type) return [{ type: 0, value: t[0].value }];
              let a = [];
              for (let l of t) {
                if (0 === l.type) {
                  a.push({ type: 0, value: l.value });
                  continue;
                }
                if (7 === l.type) {
                  "number" == typeof o && a.push({ type: 0, value: i.getNumberFormat(r).format(o) });
                  continue;
                }
                let { value: t } = l;
                if (!(n && t in n)) throw new Y(t, h);
                let u = n[t];
                if (1 === l.type) {
                  ((u && "string" != typeof u && "number" != typeof u && "bigint" != typeof u) ||
                    (u =
                      "string" == typeof u || "number" == typeof u || "bigint" == typeof u ? String(u) : ""),
                    a.push({ type: +("string" != typeof u), value: u }));
                  continue;
                }
                if (3 === l.type) {
                  let e =
                    "string" == typeof l.style
                      ? s.date[l.style]
                      : P(l.style)
                        ? l.style.parsedOptions
                        : void 0;
                  a.push({ type: 0, value: i.getDateTimeFormat(r, e).format(u) });
                  continue;
                }
                if (4 === l.type) {
                  let e =
                    "string" == typeof l.style
                      ? s.time[l.style]
                      : P(l.style)
                        ? l.style.parsedOptions
                        : s.time.medium;
                  a.push({ type: 0, value: i.getDateTimeFormat(r, e).format(u) });
                  continue;
                }
                if (2 === l.type) {
                  let e =
                    "string" == typeof l.style
                      ? s.number[l.style]
                      : _(l.style)
                        ? l.style.parsedOptions
                        : void 0;
                  if (e && e.scale) {
                    let t = e.scale || 1;
                    if ("bigint" == typeof u) {
                      if (!Number.isInteger(t))
                        throw TypeError(
                          `Cannot apply fractional scale ${t} to bigint value. Scale must be an integer when formatting bigint.`,
                        );
                      u *= BigInt(t);
                    } else u *= t;
                  }
                  a.push({ type: 0, value: i.getNumberFormat(r, e).format(u) });
                  continue;
                }
                if (8 === l.type) {
                  let { children: t, value: u } = l,
                    c = n[u];
                  if ("function" != typeof c) throw new j(u, "function", h);
                  let m = c(e(t, r, i, s, n, o).map((e) => e.value));
                  (Array.isArray(m) || (m = [m]),
                    a.push(...m.map((e) => ({ type: +("string" != typeof e), value: e }))));
                }
                if (5 === l.type) {
                  let t = u,
                    o =
                      (Object.prototype.hasOwnProperty.call(l.options, t) ? l.options[t] : void 0) ||
                      l.options.other;
                  if (!o) throw new X(l.value, u, Object.keys(l.options), h);
                  a.push(...e(o.value, r, i, s, n));
                  continue;
                }
                if (6 === l.type) {
                  let t = `=${u}`,
                    o = Object.prototype.hasOwnProperty.call(l.options, t) ? l.options[t] : void 0;
                  if (!o) {
                    if (!Intl.PluralRules)
                      throw new Z(
                        `Intl.PluralRules is not available in this environment.
Try polyfilling it using "@formatjs/intl-pluralrules"
`,
                        "MISSING_INTL_API",
                        h,
                      );
                    let e = "bigint" == typeof u ? Number(u) : u,
                      t = i.getPluralRules(r, { type: l.pluralType }).select(e - (l.offset || 0));
                    o =
                      (Object.prototype.hasOwnProperty.call(l.options, t) ? l.options[t] : void 0) ||
                      l.options.other;
                  }
                  if (!o) throw new X(l.value, u, Object.keys(l.options), h);
                  let c = "bigint" == typeof u ? Number(u) : u;
                  a.push(...e(o.value, r, i, s, n, c - (l.offset || 0)));
                  continue;
                }
              }
              return a.length < 2
                ? a
                : a.reduce((e, t) => {
                    let r = e[e.length - 1];
                    return (r && 0 === r.type && 0 === t.type ? (r.value += t.value) : e.push(t), e);
                  }, []);
            })(this.ast, this.locales, this.formatters, this.formats, e, void 0, this.message)),
          (this.resolvedOptions = () => ({
            locale: this.resolvedLocale?.toString() || Intl.NumberFormat.supportedLocalesOf(this.locales)[0],
          })),
          (this.getAst = () => this.ast),
          (this.locales = r),
          (this.resolvedLocale = e.resolveLocale(r)),
          "string" == typeof t)
        ) {
          if (((this.message = t), !e.__parse))
            throw TypeError("IntlMessageFormat.__parse must be set to process `message` of type `string`");
          const { ...r } = n || {};
          this.ast = e.__parse(t, { ...r, locale: this.resolvedLocale });
        } else this.ast = t;
        if (!Array.isArray(this.ast)) throw TypeError("A message must be provided as a String or AST.");
        ((this.formats = (function (e, t) {
          return t
            ? Object.keys(e).reduce(
                (r, i) => {
                  var s, n;
                  return (
                    (r[i] =
                      ((s = e[i]),
                      (n = t[i])
                        ? {
                            ...s,
                            ...n,
                            ...Object.keys(s).reduce((e, t) => ((e[t] = { ...s[t], ...n[t] }), e), {}),
                          }
                        : s)),
                    r
                  );
                },
                { ...e },
              )
            : e;
        })(e.formats, i)),
          (this.formatters =
            (n && n.formatters) ||
            (function () {
              let e =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : { number: {}, dateTime: {}, pluralRules: {} };
              return {
                getNumberFormat: s(
                  function () {
                    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    return new Intl.NumberFormat(...t);
                  },
                  { cache: $(e.number), strategy: u.variadic },
                ),
                getDateTimeFormat: s(
                  function () {
                    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    return new Intl.DateTimeFormat(...t);
                  },
                  { cache: $(e.dateTime), strategy: u.variadic },
                ),
                getPluralRules: s(
                  function () {
                    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    return new Intl.PluralRules(...t);
                  },
                  { cache: $(e.pluralRules), strategy: u.variadic },
                ),
              };
            })(this.formatterCache)));
      }
      static #e = (this.memoizedDefaultLocale = null);
      static get defaultLocale() {
        return (
          e.memoizedDefaultLocale ||
            (e.memoizedDefaultLocale = new Intl.NumberFormat().resolvedOptions().locale),
          e.memoizedDefaultLocale
        );
      }
      static #t = (this.resolveLocale = (e) => {
        if (void 0 === Intl.Locale) return;
        let t = Intl.NumberFormat.supportedLocalesOf(e);
        return new Intl.Locale(t.length > 0 ? t[0] : "string" == typeof e ? e : e[0]);
      });
      static #r = (this.__parse = x);
      static #i = (this.formats = {
        number: {
          integer: { maximumFractionDigits: 0 },
          currency: { style: "currency" },
          percent: { style: "percent" },
        },
        date: {
          short: { month: "numeric", day: "numeric", year: "2-digit" },
          medium: { month: "short", day: "numeric", year: "numeric" },
          long: { month: "long", day: "numeric", year: "numeric" },
          full: { weekday: "long", month: "long", day: "numeric", year: "numeric" },
        },
        time: {
          short: { hour: "numeric", minute: "numeric" },
          medium: { hour: "numeric", minute: "numeric", second: "numeric" },
          long: { hour: "numeric", minute: "numeric", second: "numeric", timeZoneName: "short" },
          full: { hour: "numeric", minute: "numeric", second: "numeric", timeZoneName: "short" },
        },
      });
    };
    function z() {
      let e;
      for (var t = arguments.length, r = Array(t), s = 0; s < t; s++) r[s] = arguments[s];
      let [n, o, h, a] = r;
      if (Array.isArray(o)) throw new c(m.INVALID_MESSAGE, void 0);
      if ("object" == typeof o) throw new c(m.INSUFFICIENT_PATH, void 0);
      if ("string" == typeof o) {
        let e = h || /'[{}<#|']/.test(o) ? void 0 : o;
        if (e) return e;
      }
      let { cache: l, formats: u, formatters: f, globalFormats: g, locale: E, timeZone: b } = a;
      f.getMessageFormat ||
        (f.getMessageFormat = p(function () {
          for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
          return new W(t[0], t[1], t[2], { formatters: f, ...t[3] });
        }, l.message));
      try {
        let t, r, i, s;
        e = f.getMessageFormat(
          o,
          E,
          ((t = W.formats.date),
          (r = W.formats.time),
          (i = { ...g?.dateTime, ...u?.dateTime }),
          (s = { date: { ...t, ...i }, time: { ...r, ...i }, number: { ...g?.number, ...u?.number } }),
          b &&
            ["date", "time"].forEach((e) => {
              let t = s[e];
              for (let [e, r] of Object.entries(t)) t[e] = { timeZone: b, ...r };
            }),
          s),
          {
            formatters: {
              ...f,
              getDateTimeFormat: (e, t) => f.getDateTimeFormat(e, { ...t, timeZone: t?.timeZone ?? b }),
            },
          },
        );
      } catch (e) {
        throw new c(m.INVALID_MESSAGE, void 0);
      }
      let H = e.format(h);
      return (0, i.isValidElement)(H) || Array.isArray(H) || "string" == typeof H ? H : String(H);
    }
    function q() {
      for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
      return t.filter(Boolean).join(".");
    }
    function J(e) {
      return q(e.namespace, e.key);
    }
    function Q(e) {
      console.error(e);
    }
    function ee(e, t, r, i) {
      let s = q(i, r);
      if (!t) throw Error(s);
      let n = t;
      return (
        r.split(".").forEach((t) => {
          let r = n[t];
          if (null == t || null == r) throw Error(s + ` (${e})`);
          n = r;
        }),
        n
      );
    }
    z.raw = !0;
    let et = {
      second: 1,
      seconds: 1,
      minute: 60,
      minutes: 60,
      hour: 3600,
      hours: 3600,
      day: 86400,
      days: 86400,
      week: 604800,
      weeks: 604800,
      month: 2628e3,
      months: 2628e3,
      quarter: 7884e3,
      quarters: 7884e3,
      year: 31536e3,
      years: 31536e3,
    };
    var er = e.i(843476);
    let ei = (0, i.createContext)(void 0);
    function es() {
      let e = (0, i.useContext)(ei);
      if (!e) throw Error(void 0);
      return e;
    }
    let en = !1,
      eo = "u" < typeof window;
    e.s(
      [
        "IntlProvider",
        0,
        function (e) {
          let {
              children: t,
              formats: r,
              getMessageFallback: s,
              locale: n,
              messages: o,
              now: h,
              onError: a,
              timeZone: l,
            } = e,
            u = (0, i.useContext)(ei),
            c = (0, i.useMemo)(() => u?.cache || f(), [n, u?.cache]),
            m = (0, i.useMemo)(() => u?.formatters || E(c), [c, u?.formatters]),
            p = (0, i.useMemo)(
              () => ({
                ...(function (e) {
                  let { formats: t, getMessageFallback: r, messages: i, onError: s, ...n } = e;
                  return {
                    ...n,
                    formats: t || void 0,
                    messages: i || void 0,
                    onError: s || Q,
                    getMessageFallback: r || J,
                  };
                })({
                  locale: n,
                  formats: void 0 === r ? u?.formats : r,
                  getMessageFallback: s || u?.getMessageFallback,
                  messages: void 0 === o ? u?.messages : o,
                  now: h || u?.now,
                  onError: a || u?.onError,
                  timeZone: l || u?.timeZone,
                }),
                formatters: m,
                cache: c,
              }),
              [c, r, m, s, n, o, h, a, u, l],
            );
          return (0, er.jsx)(ei.Provider, { value: p, children: t });
        },
        "useFormatter",
        0,
        function () {
          let { formats: e, formatters: t, locale: r, now: s, onError: n, timeZone: o } = es();
          return (0, i.useMemo)(
            () =>
              (function (e) {
                let {
                  _cache: t = f(),
                  _formatters: r = E(t),
                  formats: i,
                  locale: s,
                  onError: n = Q,
                  timeZone: o,
                } = e;
                function h(e) {
                  return (
                    e?.timeZone ||
                      (o ? (e = { ...e, timeZone: o }) : n(new c(m.ENVIRONMENT_FALLBACK, void 0))),
                    e
                  );
                }
                function a(e, t, r, i, s) {
                  let o;
                  try {
                    o = (function (e, t, r) {
                      let i;
                      if ("string" == typeof t) {
                        if (!(i = e?.[t])) {
                          let e = new c(m.MISSING_FORMAT, void 0);
                          throw (n(e), e);
                        }
                      } else i = t;
                      return (r && (i = { ...i, ...r }), i);
                    })(r, e, t);
                  } catch {
                    return s();
                  }
                  try {
                    return i(o);
                  } catch (e) {
                    return (n(new c(m.FORMATTING_ERROR, e.message)), s());
                  }
                }
                function l(e, t, n) {
                  return a(
                    t,
                    n,
                    i?.dateTime,
                    (t) => ((t = h(t)), r.getDateTimeFormat(s, t).format(e)),
                    () => String(e),
                  );
                }
                function u() {
                  return e.now ? e.now : (n(new c(m.ENVIRONMENT_FALLBACK, void 0)), new Date());
                }
                return {
                  dateTime: l,
                  number: function (e, t, n) {
                    return a(
                      t,
                      n,
                      i?.number,
                      (t) => r.getNumberFormat(s, t).format(e),
                      () => String(e),
                    );
                  },
                  relativeTime: function (e, t) {
                    try {
                      var i;
                      let n,
                        o,
                        h,
                        a = {};
                      (t instanceof Date || "number" == typeof t
                        ? (n = new Date(t))
                        : t &&
                          ((n = null != t.now ? new Date(t.now) : u()),
                          (o = t.unit),
                          (a.style = t.style),
                          (a.numberingSystem = t.numberingSystem)),
                        n || (n = u()));
                      let l = (new Date(e).getTime() - n.getTime()) / 1e3;
                      (o ||
                        (o =
                          (h = Math.abs(l)) < 60
                            ? "second"
                            : h < 3600
                              ? "minute"
                              : h < 86400
                                ? "hour"
                                : h < 604800
                                  ? "day"
                                  : h < 2628e3
                                    ? "week"
                                    : h < 31536e3
                                      ? "month"
                                      : "year"),
                        (a.numeric = "second" === o ? "auto" : "always"));
                      let c = ((i = o), Math.round(l / et[i]));
                      return r.getRelativeTimeFormat(s, a).format(c, o);
                    } catch (t) {
                      return (n(new c(m.FORMATTING_ERROR, t.message)), String(e));
                    }
                  },
                  list: function (e, t, n) {
                    let o = [],
                      h = new Map(),
                      l = 0;
                    for (let t of e) {
                      let e;
                      ("object" == typeof t ? ((e = String(l)), h.set(e, t)) : (e = String(t)),
                        o.push(e),
                        l++);
                    }
                    return a(
                      t,
                      n,
                      i?.list,
                      (e) => {
                        let t = r
                          .getListFormat(s, e)
                          .formatToParts(o)
                          .map((e) => ("literal" === e.type ? e.value : h.get(e.value) || e.value));
                        return h.size > 0 ? t : t.join("");
                      },
                      () => String(e),
                    );
                  },
                  dateTimeRange: function (e, t, n, o) {
                    return a(
                      n,
                      o,
                      i?.dateTime,
                      (i) => ((i = h(i)), r.getDateTimeFormat(s, i).formatRange(e, t)),
                      () => [l(e), l(t)].join(" – "),
                    );
                  },
                  displayName: function (e, t, n) {
                    return a(
                      t,
                      n,
                      i?.displayName,
                      (t) => r.getDisplayNames(s, t).of(e),
                      () => e,
                    );
                  },
                };
              })({ formats: e, locale: r, now: s, onError: n, timeZone: o, _formatters: t }),
            [e, t, s, r, n, o],
          );
        },
        "useLocale",
        0,
        function () {
          return es().locale;
        },
        "useMessages",
        0,
        function () {
          let e = es();
          if (!e.messages) throw Error(void 0);
          return e.messages;
        },
        "useTranslations",
        0,
        function (e) {
          return (function (e, t) {
            let {
                cache: r,
                formats: s,
                formatters: n,
                getMessageFallback: o,
                locale: h,
                onError: a,
                timeZone: l,
              } = es(),
              u = e["!"],
              f = "!" === t ? void 0 : t.slice(2);
            return (
              l || en || !eo || ((en = !0), a(new c(m.ENVIRONMENT_FALLBACK, void 0))),
              (0, i.useMemo)(() => {
                var e;
                let t;
                return (
                  (t = (function (e, t, r) {
                    try {
                      if (!t) throw Error(void 0);
                      let i = r ? ee(e, t, r) : t;
                      if (!i) throw Error(r);
                      return i;
                    } catch (e) {
                      return new c(m.MISSING_MESSAGE, e.message);
                    }
                  })(
                    (e = {
                      cache: r,
                      formatters: n,
                      getMessageFallback: o,
                      messages: u,
                      namespace: f,
                      onError: a,
                      formats: s,
                      locale: h,
                      timeZone: l,
                    }).locale,
                    e.messages,
                    e.namespace,
                  )),
                  (function (e) {
                    let {
                        cache: t,
                        formats: r,
                        formatters: s,
                        getMessageFallback: n = J,
                        locale: o,
                        messagesOrError: h,
                        namespace: a,
                        onError: l,
                        timeZone: u,
                      } = e,
                      f = h instanceof c;
                    function p(e, t, r, i) {
                      let s = new c(t, r);
                      return (l(s), i ?? n({ error: s, key: e, namespace: a }));
                    }
                    function g(e, g, E, b) {
                      let H;
                      if (f) {
                        if (!b) return (l(h), n({ error: h, key: e, namespace: a }));
                        H = b;
                      } else
                        try {
                          H = ee(o, h, e, a);
                        } catch (t) {
                          if (!b) return p(e, m.MISSING_MESSAGE, t.message, b);
                          H = b;
                        }
                      try {
                        let n,
                          h = q(a, e);
                        return z(
                          h,
                          H,
                          g
                            ? ((n = {}),
                              Object.keys(g).forEach((e) => {
                                let t,
                                  r = 0,
                                  s = g[e];
                                ((t =
                                  "function" == typeof s
                                    ? (t) => {
                                        let n = s(t);
                                        return (0, i.isValidElement)(n)
                                          ? (0, i.cloneElement)(n, { key: e + r++ })
                                          : n;
                                      }
                                    : s),
                                  (n[e] = t));
                              }),
                              n)
                            : g,
                          { cache: t, formatters: s, globalFormats: r, formats: E, locale: o, timeZone: u },
                        );
                      } catch (i) {
                        let t, r;
                        return (
                          i instanceof c
                            ? ((t = i.code), (r = i.originalMessage))
                            : ((t = m.FORMATTING_ERROR), (r = i.message)),
                          p(e, t, r, b)
                        );
                      }
                    }
                    function E(e, t, r, i) {
                      let s = g(e, t, r, i);
                      return "string" != typeof s ? p(e, m.INVALID_MESSAGE, void 0) : s;
                    }
                    return (
                      (E.rich = g),
                      (E.markup = (e, t, r, i) => g(e, t, r, i)),
                      (E.raw = (e) => {
                        if (f) return (l(h), n({ error: h, key: e, namespace: a }));
                        try {
                          return ee(o, h, e, a);
                        } catch (t) {
                          return p(e, m.MISSING_MESSAGE, t.message);
                        }
                      }),
                      (E.has = (e) => {
                        if (f) return !1;
                        try {
                          return (ee(o, h, e, a), !0);
                        } catch {
                          return !1;
                        }
                      }),
                      E
                    );
                  })({ ...e, messagesOrError: t })
                );
              }, [r, n, o, u, f, a, s, h, l])
            );
          })({ "!": es().messages }, e ? `!.${e}` : "!");
        },
      ],
      861745,
    );
  },
]);
