(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([
  "object" == typeof document ? document.currentScript : void 0,
  88653,
  359260,
  953285,
  160572,
  (e) => {
    "use strict";
    var t = e.i(843476),
      n = e.i(271645),
      r = e.i(231178),
      o = e.i(947414),
      i = e.i(674008),
      s = e.i(821476),
      a = e.i(772846),
      u = n,
      l = e.i(737806);
    function c(e, t) {
      if ("function" == typeof e) return e(t);
      null != e && (e.current = t);
    }
    function f() {
      for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
      return n.useCallback(
        (function () {
          for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
          return (e) => {
            let n = !1,
              r = t.map((t) => {
                let r = c(t, e);
                return (n || "function" != typeof r || (n = !0), r);
              });
            if (n)
              return () => {
                for (let e = 0; e < r.length; e++) {
                  let n = r[e];
                  "function" == typeof n ? n() : c(t[e], null);
                }
              };
          };
        })(...t),
        t,
      );
    }
    e.s(["useComposedRefs", 0, f], 359260);
    class d extends u.Component {
      getSnapshotBeforeUpdate(e) {
        let t = this.props.childRef.current;
        if ((0, a.isHTMLElement)(t) && e.isPresent && !this.props.isPresent && !1 !== this.props.pop) {
          let e = t.offsetParent,
            n = ((0, a.isHTMLElement)(e) && e.offsetWidth) || 0,
            r = ((0, a.isHTMLElement)(e) && e.offsetHeight) || 0,
            o = getComputedStyle(t),
            i = this.props.sizeRef.current;
          ((i.height = parseFloat(o.height)),
            (i.width = parseFloat(o.width)),
            (i.top = t.offsetTop),
            (i.left = t.offsetLeft),
            (i.right = n - i.width - i.left),
            (i.bottom = r - i.height - i.top),
            (i.direction = o.direction));
        }
        return null;
      }
      componentDidUpdate() {}
      render() {
        return this.props.children;
      }
    }
    function p(e) {
      let { children: n, isPresent: r, anchorX: o, anchorY: i, root: s, pop: a } = e,
        c = (0, u.useId)(),
        p = (0, u.useRef)(null),
        m = (0, u.useRef)({ width: 0, height: 0, top: 0, left: 0, right: 0, bottom: 0, direction: "ltr" }),
        { nonce: h } = (0, u.useContext)(l.MotionConfigContext),
        g = f(p, !1 !== a ? (n.props?.ref ?? n?.ref) : void 0);
      return (
        (0, u.useInsertionEffect)(() => {
          let { width: e, height: t, top: n, left: u, right: l, bottom: f, direction: d } = m.current;
          if (r || !1 === a || !p.current || !e || !t) return;
          let g = "rtl" === d,
            C = "left" === o ? (g ? `right: ${l}` : `left: ${u}`) : g ? `left: ${u}` : `right: ${l}`,
            y = "bottom" === i ? `bottom: ${f}` : `top: ${n}`;
          p.current.dataset.motionPopId = c;
          let v = document.createElement("style");
          h && (v.nonce = h);
          let x = s ?? document.head;
          return (
            x.appendChild(v),
            v.sheet &&
              v.sheet.insertRule(`
          [data-motion-pop-id="${c}"] {
            position: absolute !important;
            width: ${e}px !important;
            height: ${t}px !important;
            ${C}px !important;
            ${y}px !important;
          }
        `),
            () => {
              (p.current?.removeAttribute("data-motion-pop-id"), x.contains(v) && x.removeChild(v));
            }
          );
        }, [r]),
        (0, t.jsx)(d, {
          isPresent: r,
          childRef: p,
          sizeRef: m,
          pop: a,
          children: !1 === a ? n : u.cloneElement(n, { ref: g }),
        })
      );
    }
    e.s(["PopChild", 0, p], 953285);
    let m = (e) => {
      let {
          children: r,
          initial: a,
          isPresent: u,
          onExitComplete: l,
          custom: c,
          presenceAffectsLayout: f,
          mode: d,
          anchorX: m,
          anchorY: g,
          root: C,
        } = e,
        y = (0, o.useConstant)(h),
        v = (0, n.useId)(),
        x = (0, n.useRef)(u),
        M = (0, n.useRef)(l);
      (0, i.useIsomorphicLayoutEffect)(() => {
        ((x.current = u), (M.current = l));
      });
      let w = !0,
        S = (0, n.useMemo)(
          () => (
            (w = !1),
            {
              id: v,
              initial: a,
              isPresent: u,
              custom: c,
              onExitComplete: (e) => {
                for (let t of (y.set(e, !0), y.values())) if (!t) return;
                l && l();
              },
              register: (e) => (
                y.set(e, !1),
                () => {
                  (y.delete(e), x.current || y.size || M.current?.());
                }
              ),
            }
          ),
          [u, y, l],
        );
      return (
        f && w && (S = { ...S }),
        (0, n.useMemo)(() => {
          y.forEach((e, t) => y.set(t, !1));
        }, [u]),
        n.useEffect(() => {
          u || y.size || !l || l();
        }, [u]),
        (r = (0, t.jsx)(p, {
          pop: "popLayout" === d,
          isPresent: u,
          anchorX: m,
          anchorY: g,
          root: C,
          children: r,
        })),
        (0, t.jsx)(s.PresenceContext.Provider, { value: S, children: r })
      );
    };
    function h() {
      return new Map();
    }
    e.s(["PresenceChild", 0, m], 160572);
    var g = e.i(464978);
    let C = (e) => e.key || "";
    function y(e) {
      let t = [];
      return (
        n.Children.forEach(e, (e) => {
          (0, n.isValidElement)(e) && t.push(e);
        }),
        t
      );
    }
    e.s(
      [
        "AnimatePresence",
        0,
        (e) => {
          let {
              children: s,
              custom: a,
              initial: u = !0,
              onExitComplete: l,
              presenceAffectsLayout: c = !0,
              mode: f = "sync",
              propagate: d = !1,
              anchorX: p = "left",
              anchorY: h = "top",
              root: v,
            } = e,
            [x, M] = (0, g.usePresence)(d),
            w = (0, n.useMemo)(() => y(s), [s]),
            S = d && !x ? [] : w.map(C),
            P = (0, n.useRef)(!0),
            E = (0, n.useRef)(w),
            b = (0, o.useConstant)(() => new Map()),
            V = (0, n.useRef)(new Set()),
            [L, R] = (0, n.useState)(w),
            [T, j] = (0, n.useState)(w);
          (0, i.useIsomorphicLayoutEffect)(() => {
            ((P.current = !1), (E.current = w));
            for (let e = 0; e < T.length; e++) {
              let t = C(T[e]);
              S.includes(t) ? (b.delete(t), V.current.delete(t)) : !0 !== b.get(t) && b.set(t, !1);
            }
          }, [T, S.length, S.join("-")]);
          let A = [];
          if (w !== L) {
            let e = [...w];
            for (let t = 0; t < T.length; t++) {
              let n = T[t],
                r = C(n);
              S.includes(r) || (e.splice(t, 0, n), A.push(n));
            }
            return ("wait" === f && A.length && (e = A), j(y(e)), R(w), null);
          }
          let { forceRender: I } = (0, n.useContext)(r.LayoutGroupContext);
          return (0, t.jsx)(t.Fragment, {
            children: T.map((e) => {
              let n = C(e),
                r = (!d || !!x) && (w === T || S.includes(n));
              return (0, t.jsx)(
                m,
                {
                  isPresent: r,
                  initial: (!P.current || !!u) && void 0,
                  custom: a,
                  presenceAffectsLayout: c,
                  mode: f,
                  root: v,
                  onExitComplete: r
                    ? void 0
                    : () => {
                        if (V.current.has(n) || !b.has(n)) return;
                        (V.current.add(n), b.set(n, !0));
                        let e = !0;
                        (b.forEach((t) => {
                          t || (e = !1);
                        }),
                          e && (I?.(), j(E.current), d && M?.(), l && l()));
                      },
                  anchorX: p,
                  anchorY: h,
                  children: e,
                },
                n,
              );
            }),
          });
        },
      ],
      88653,
    );
  },
  464978,
  (e) => {
    "use strict";
    var t = e.i(271645),
      n = e.i(821476);
    e.s([
      "useIsPresent",
      0,
      function () {
        var e;
        return null === (e = (0, t.useContext)(n.PresenceContext)) || e.isPresent;
      },
      "usePresence",
      0,
      function () {
        let e = !(arguments.length > 0) || void 0 === arguments[0] || arguments[0],
          r = (0, t.useContext)(n.PresenceContext);
        if (null === r) return [!0, null];
        let { isPresent: o, onExitComplete: i, register: s } = r,
          a = (0, t.useId)();
        (0, t.useEffect)(() => {
          if (e) return s(a);
        }, [e]);
        let u = (0, t.useCallback)(() => e && i && i(a), [a, i, e]);
        return !o && i ? [!1, u] : [!0];
      },
    ]);
  },
  231178,
  (e) => {
    "use strict";
    let t = (0, e.i(271645).createContext)({});
    e.s(["LayoutGroupContext", 0, t]);
  },
  648070,
  (e) => {
    "use strict";
    let t = (0, e.i(271645).createContext)({ strict: !1 });
    e.s(["LazyContext", 0, t]);
  },
  737806,
  488800,
  798125,
  (e) => {
    "use strict";
    let t = (0, e.i(271645).createContext)({
      transformPagePoint: (e) => e,
      isStatic: !1,
      reducedMotion: "never",
    });
    e.s(["MotionConfigContext", 0, t], 737806);
    var n = e.i(83411);
    let r = new Set([
      "animate",
      "exit",
      "variants",
      "initial",
      "style",
      "values",
      "variants",
      "transition",
      "transformTemplate",
      "custom",
      "inherit",
      "onBeforeLayoutMeasure",
      "onAnimationStart",
      "onAnimationComplete",
      "onUpdate",
      "onDragStart",
      "onDrag",
      "onDragEnd",
      "onMeasureDragConstraints",
      "onDirectionLock",
      "onDragTransitionEnd",
      "_dragX",
      "_dragY",
      "onHoverStart",
      "onHoverEnd",
      "onViewportEnter",
      "onViewportLeave",
      "globalTapTarget",
      "propagate",
      "ignoreStrict",
      "viewport",
    ]);
    function o(e) {
      return (
        e.startsWith("while") ||
        (e.startsWith("drag") && "draggable" !== e) ||
        e.startsWith("layout") ||
        e.startsWith("onTap") ||
        e.startsWith("onPan") ||
        e.startsWith("onLayout") ||
        r.has(e)
      );
    }
    e.s(["isValidMotionProp", 0, o], 488800);
    let i = (e) => !o(e);
    function s(e) {
      "function" == typeof e && (i = (t) => (t.startsWith("on") ? !o(t) : e(t)));
    }
    try {
      s(
        (() => {
          let e = Error("Cannot find module '@emotion/is-prop-valid'");
          throw ((e.code = "MODULE_NOT_FOUND"), e);
        })().default,
      );
    } catch {}
    e.s(
      [
        "filterProps",
        0,
        function (e, t, r) {
          let s = {};
          for (let a in e)
            ("values" !== a || "object" != typeof e.values) &&
              !(0, n.isMotionValue)(e[a]) &&
              (i(a) || (!0 === r && o(a)) || (!t && !o(a)) || (e.draggable && a.startsWith("onDrag"))) &&
              (s[a] = e[a]);
          return s;
        },
        "loadExternalIsValidProp",
        0,
        s,
      ],
      798125,
    );
  },
  688291,
  582474,
  886549,
  911587,
  308576,
  830665,
  733871,
  (e) => {
    "use strict";
    var t = e.i(271645);
    let n = (0, t.createContext)({});
    e.s(["MotionContext", 0, n], 688291);
    var r = e.i(587576),
      o = e.i(732525);
    function i(e) {
      return Array.isArray(e) ? e.join(" ") : e;
    }
    e.s(
      [
        "useCreateMotionContext",
        0,
        function (e) {
          let { initial: s, animate: a } = (function (e, t) {
            if ((0, r.isControllingVariants)(e)) {
              let { initial: t, animate: n } = e;
              return {
                initial: !1 === t || (0, o.isVariantLabel)(t) ? t : void 0,
                animate: (0, o.isVariantLabel)(n) ? n : void 0,
              };
            }
            return !1 !== e.inherit ? t : {};
          })(e, (0, t.useContext)(n));
          return (0, t.useMemo)(() => ({ initial: s, animate: a }), [i(s), i(a)]);
        },
      ],
      582474,
    );
    var s = e.i(83411),
      a = e.i(130789),
      u = e.i(544947);
    let l = () => ({ style: {}, transform: {}, transformOrigin: {}, vars: {} });
    function c(e, t, n) {
      for (let r in t) (0, s.isMotionValue)(t[r]) || (0, a.isForcedMotionValue)(r, n) || (e[r] = t[r]);
    }
    e.s(["createHtmlRenderState", 0, l], 886549);
    var f = e.i(181261),
      d = e.i(399951);
    let p = () => ({ ...l(), attrs: {} });
    e.s(["createSvgRenderState", 0, p], 911587);
    var m = e.i(798125),
      h = e.i(944966);
    e.s(
      [
        "useRender",
        0,
        function (e, n, r, o, i) {
          let { latestValues: a } = o,
            g = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
            C = arguments.length > 6 ? arguments[6] : void 0,
            y = (
              (C ?? (0, h.isSVGComponent)(e))
                ? function (e, n, r, o) {
                    let i = (0, t.useMemo)(() => {
                      let t = p();
                      return (
                        (0, f.buildSVGAttrs)(t, n, (0, d.isSVGTag)(o), e.transformTemplate, e.style),
                        { ...t.attrs, style: { ...t.style } }
                      );
                    }, [n]);
                    if (e.style) {
                      let t = {};
                      (c(t, e.style, e), (i.style = { ...t, ...i.style }));
                    }
                    return i;
                  }
                : function (e, n) {
                    let r,
                      o,
                      i = {},
                      s =
                        ((r = e.style || {}),
                        c((o = {}), r, e),
                        Object.assign(
                          o,
                          (function (e, n) {
                            let { transformTemplate: r } = e;
                            return (0, t.useMemo)(() => {
                              let e = l();
                              return ((0, u.buildHTMLStyles)(e, n, r), Object.assign({}, e.vars, e.style));
                            }, [n]);
                          })(e, n),
                        ),
                        o);
                    return (
                      e.drag &&
                        !1 !== e.dragListener &&
                        ((i.draggable = !1),
                        (s.userSelect = s.WebkitUserSelect = s.WebkitTouchCallout = "none"),
                        (s.touchAction = !0 === e.drag ? "none" : `pan-${"x" === e.drag ? "y" : "x"}`)),
                      void 0 === e.tabIndex && (e.onTap || e.onTapStart || e.whileTap) && (i.tabIndex = 0),
                      (i.style = s),
                      i
                    );
                  }
            )(n, a, i, e),
            v = (0, m.filterProps)(n, "string" == typeof e, g),
            x = e !== t.Fragment ? { ...v, ...y, ref: r } : {},
            { children: M } = n,
            w = (0, t.useMemo)(() => ((0, s.isMotionValue)(M) ? M.get() : M), [M]);
          return (0, t.createElement)(e, { ...x, children: w });
        },
      ],
      308576,
    );
    var g = e.i(984049);
    (e.s(["scrapeHTMLMotionValuesFromProps", () => g.scrapeMotionValuesFromProps], 830665),
      e.s(
        [
          "resolveMotionValue",
          0,
          function (e) {
            return (0, s.isMotionValue)(e) ? e.get() : e;
          },
        ],
        733871,
      ));
  },
  821476,
  (e) => {
    "use strict";
    let t = (0, e.i(271645).createContext)(null);
    e.s(["PresenceContext", 0, t]);
  },
  513565,
  476948,
  (e) => {
    "use strict";
    var t = e.i(617218);
    let n = {
        animation: [
          "animate",
          "variants",
          "whileHover",
          "whileTap",
          "exit",
          "whileInView",
          "whileFocus",
          "whileDrag",
        ],
        exit: ["exit"],
        drag: ["drag", "dragControls"],
        focus: ["whileFocus"],
        hover: ["whileHover", "onHoverStart", "onHoverEnd"],
        tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
        pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
        inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
        layout: ["layout", "layoutId"],
      },
      r = !1;
    function o() {
      return (
        !(function () {
          if (r) return;
          let e = {};
          for (let t in n) e[t] = { isEnabled: (e) => n[t].some((t) => !!e[t]) };
          ((0, t.setFeatureDefinitions)(e), (r = !0));
        })(),
        (0, t.getFeatureDefinitions)()
      );
    }
    (e.s(["getInitializedFeatureDefinitions", 0, o], 476948),
      e.s(
        [
          "loadFeatures",
          0,
          function (e) {
            let n = o();
            for (let t in e) n[t] = { ...n[t], ...e[t] };
            (0, t.setFeatureDefinitions)(n);
          },
        ],
        513565,
      ));
  },
  321967,
  683640,
  104035,
  325522,
  (e) => {
    "use strict";
    let t = Symbol.for("motionComponentSymbol");
    e.s(["motionComponentSymbol", 0, t], 321967);
    var n = e.i(271645);
    e.s(
      [
        "useMotionRef",
        0,
        function (e, t, r) {
          let o = (0, n.useRef)(r);
          (0, n.useInsertionEffect)(() => {
            o.current = r;
          });
          let i = (0, n.useRef)(null);
          return (0, n.useCallback)(
            (n) => {
              (n && e.onMount?.(n), t && (n ? t.mount(n) : t.unmount()));
              let r = o.current;
              if ("function" == typeof r)
                if (n) {
                  let e = r(n);
                  "function" == typeof e && (i.current = e);
                } else i.current ? (i.current(), (i.current = null)) : r(n);
              else r && (r.current = n);
            },
            [t],
          );
        },
      ],
      683640,
    );
    let r = (0, n.createContext)({});
    (e.s(["SwitchLayoutGroupContext", 0, r], 104035),
      e.s(
        [
          "isRefObject",
          0,
          function (e) {
            return e && "object" == typeof e && Object.prototype.hasOwnProperty.call(e, "current");
          },
        ],
        325522,
      ));
  },
  907051,
  (e) => {
    "use strict";
    var t = e.i(843476),
      n = e.i(271645),
      r = e.i(231178),
      o = e.i(648070),
      i = e.i(737806),
      s = e.i(688291),
      a = e.i(582474),
      u = e.i(308576),
      l = e.i(944966),
      c = e.i(711805),
      f = e.i(501664),
      d = e.i(476948),
      p = e.i(513565),
      m = e.i(321967),
      h = e.i(683640),
      g = e.i(535043),
      C = e.i(821476),
      y = e.i(104035),
      v = e.i(325522),
      x = e.i(674008);
    function M(e) {
      let { forwardMotionProps: M = !1, type: w } =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
        S = arguments.length > 2 ? arguments[2] : void 0,
        P = arguments.length > 3 ? arguments[3] : void 0;
      S && (0, p.loadFeatures)(S);
      let E = w ? "svg" === w : (0, l.isSVGComponent)(e),
        b = E ? f.useSVGVisualState : c.useHTMLVisualState;
      function V(l, c) {
        let f,
          p = {
            ...(0, n.useContext)(i.MotionConfigContext),
            ...l,
            layoutId: (function (e) {
              let { layoutId: t } = e,
                o = (0, n.useContext)(r.LayoutGroupContext).id;
              return o && void 0 !== t ? o + "-" + t : t;
            })(l),
          },
          { isStatic: m } = p,
          w = (0, a.useCreateMotionContext)(l),
          S = b(l, m);
        if (!m && "u" > typeof window) {
          (0, n.useContext)(o.LazyContext).strict;
          let t = (function (e) {
            let { drag: t, layout: n } = (0, d.getInitializedFeatureDefinitions)();
            if (!t && !n) return {};
            let r = { ...t, ...n };
            return {
              MeasureLayout: t?.isEnabled(e) || n?.isEnabled(e) ? r.MeasureLayout : void 0,
              ProjectionNode: r.ProjectionNode,
            };
          })(p);
          ((f = t.MeasureLayout),
            (w.visualElement = (function (e, t, r, a, u, l) {
              let { visualElement: c } = (0, n.useContext)(s.MotionContext),
                f = (0, n.useContext)(o.LazyContext),
                d = (0, n.useContext)(C.PresenceContext),
                p = (0, n.useContext)(i.MotionConfigContext),
                m = p.reducedMotion,
                h = p.skipAnimations,
                M = (0, n.useRef)(null),
                w = (0, n.useRef)(!1);
              ((a = a || f.renderer),
                !M.current &&
                  a &&
                  ((M.current = a(e, {
                    visualState: t,
                    parent: c,
                    props: r,
                    presenceContext: d,
                    blockInitialAnimation: !!d && !1 === d.initial,
                    reducedMotionConfig: m,
                    skipAnimations: h,
                    isSVG: l,
                  })),
                  w.current && M.current && (M.current.manuallyAnimateOnMount = !0)));
              let S = M.current,
                P = (0, n.useContext)(y.SwitchLayoutGroupContext);
              S &&
                !S.projection &&
                u &&
                ("html" === S.type || "svg" === S.type) &&
                (function (e, t, n, r) {
                  let {
                    layoutId: o,
                    layout: i,
                    drag: s,
                    dragConstraints: a,
                    layoutScroll: u,
                    layoutRoot: l,
                    layoutAnchor: c,
                    layoutCrossfade: f,
                  } = t;
                  ((e.projection = new n(
                    e.latestValues,
                    t["data-framer-portal-id"]
                      ? void 0
                      : (function e(t) {
                          if (t) return !1 !== t.options.allowProjection ? t.projection : e(t.parent);
                        })(e.parent),
                  )),
                    e.projection.setOptions({
                      layoutId: o,
                      layout: i,
                      alwaysMeasureLayout: !!s || (a && (0, v.isRefObject)(a)),
                      visualElement: e,
                      animationType: "string" == typeof i ? i : "both",
                      initialPromotionConfig: r,
                      crossfade: f,
                      layoutScroll: u,
                      layoutRoot: l,
                      layoutAnchor: c,
                    }));
                })(M.current, r, u, P);
              let E = (0, n.useRef)(!1);
              (0, n.useInsertionEffect)(() => {
                S && E.current && S.update(r, d);
              });
              let b = r[g.optimizedAppearDataAttribute],
                V = (0, n.useRef)(
                  !!b &&
                    "u" > typeof window &&
                    !window.MotionHandoffIsComplete?.(b) &&
                    window.MotionHasOptimisedAnimation?.(b),
                );
              return (
                (0, x.useIsomorphicLayoutEffect)(() => {
                  ((w.current = !0),
                    S &&
                      ((E.current = !0),
                      (window.MotionIsMounted = !0),
                      S.updateFeatures(),
                      S.scheduleRenderMicrotask(),
                      V.current && S.animationState && S.animationState.animateChanges()));
                }),
                (0, n.useEffect)(() => {
                  S &&
                    (!V.current && S.animationState && S.animationState.animateChanges(),
                    V.current &&
                      (queueMicrotask(() => {
                        window.MotionHandoffMarkAsComplete?.(b);
                      }),
                      (V.current = !1)),
                    (S.enteringChildren = void 0));
                }),
                S
              );
            })(e, S, p, P, t.ProjectionNode, E)));
        }
        return (0, t.jsxs)(s.MotionContext.Provider, {
          value: w,
          children: [
            f && w.visualElement ? (0, t.jsx)(f, { visualElement: w.visualElement, ...p }) : null,
            (0, u.useRender)(e, l, (0, h.useMotionRef)(S, w.visualElement, c), S, m, M, E),
          ],
        });
      }
      V.displayName = `motion.${"string" == typeof e ? e : `create(${e.displayName ?? e.name ?? ""})`}`;
      let L = (0, n.forwardRef)(V);
      return ((L[m.motionComponentSymbol] = e), L);
    }
    e.s(
      [
        "createMotionProxy",
        0,
        function (e, t) {
          if ("u" < typeof Proxy) return M;
          let n = new Map(),
            r = (n, r) => M(n, r, e, t);
          return new Proxy((e, t) => r(e, t), {
            get: (o, i) => ("create" === i ? r : (n.has(i) || n.set(i, M(i, void 0, e, t)), n.get(i))),
          });
        },
      ],
      907051,
    );
  },
  711805,
  497044,
  501664,
  (e) => {
    "use strict";
    var t = e.i(830665),
      n = e.i(733871),
      r = e.i(587576),
      o = e.i(885983),
      i = e.i(386579),
      s = e.i(271645),
      a = e.i(688291),
      u = e.i(821476),
      l = e.i(947414);
    let c = (e) => (t, c) => {
      let f = (0, s.useContext)(a.MotionContext),
        d = (0, s.useContext)(u.PresenceContext),
        p = () =>
          (function (e, t, s, a) {
            let { scrapeMotionValuesFromProps: u, createRenderState: l } = e;
            return {
              latestValues: (function (e, t, s, a) {
                let u = {},
                  l = a(e, {});
                for (let e in l) u[e] = (0, n.resolveMotionValue)(l[e]);
                let { initial: c, animate: f } = e,
                  d = (0, r.isControllingVariants)(e),
                  p = (0, r.isVariantNode)(e);
                t &&
                  p &&
                  !d &&
                  !1 !== e.inherit &&
                  (void 0 === c && (c = t.initial), void 0 === f && (f = t.animate));
                let m = !!s && !1 === s.initial,
                  h = (m = m || !1 === c) ? f : c;
                if (h && "boolean" != typeof h && !(0, o.isAnimationControls)(h)) {
                  let t = Array.isArray(h) ? h : [h];
                  for (let n = 0; n < t.length; n++) {
                    let r = (0, i.resolveVariantFromProps)(e, t[n]);
                    if (r) {
                      let { transitionEnd: e, transition: t, ...n } = r;
                      for (let e in n) {
                        let t = n[e];
                        if (Array.isArray(t)) {
                          let e = m ? t.length - 1 : 0;
                          t = t[e];
                        }
                        null !== t && (u[e] = t);
                      }
                      for (let t in e) u[t] = e[t];
                    }
                  }
                }
                return u;
              })(t, s, a, u),
              renderState: l(),
            };
          })(e, t, f, d);
      return c ? p() : (0, l.useConstant)(p);
    };
    e.s(["makeUseVisualState", 0, c], 497044);
    var f = e.i(886549);
    let d = c({
      scrapeMotionValuesFromProps: t.scrapeHTMLMotionValuesFromProps,
      createRenderState: f.createHtmlRenderState,
    });
    e.s(["useHTMLVisualState", 0, d], 711805);
    var p = e.i(767926),
      p = p,
      m = e.i(911587);
    let h = c({
      scrapeMotionValuesFromProps: p.scrapeMotionValuesFromProps,
      createRenderState: m.createSvgRenderState,
    });
    e.s(["useSVGVisualState", 0, h], 501664);
  },
  947414,
  (e) => {
    "use strict";
    var t = e.i(271645);
    e.s([
      "useConstant",
      0,
      function (e) {
        let n = (0, t.useRef)(null);
        return (null === n.current && (n.current = e()), n.current);
      },
    ]);
  },
  674008,
  292936,
  (e) => {
    "use strict";
    var t = e.i(271645);
    let n = "u" > typeof window;
    e.s(["isBrowser", 0, n], 292936);
    let r = n ? t.useLayoutEffect : t.useEffect;
    e.s(["useIsomorphicLayoutEffect", 0, r], 674008);
  },
  138544,
  571164,
  (e) => {
    "use strict";
    let t = { current: null },
      n = { current: !1 };
    e.s(["hasReducedMotionListener", 0, n, "prefersReducedMotion", 0, t], 571164);
    let r = "u" > typeof window;
    e.s(
      [
        "initPrefersReducedMotion",
        0,
        function () {
          if (((n.current = !0), r))
            if (window.matchMedia) {
              let e = window.matchMedia("(prefers-reduced-motion)"),
                n = () => (t.current = e.matches);
              (e.addEventListener("change", n), n());
            } else t.current = !1;
        },
      ],
      138544,
    );
  },
  772846,
  642824,
  (e) => {
    "use strict";
    let t = (e) => "object" == typeof e && null !== e;
    (e.s(["isObject", 0, t], 642824),
      e.s(
        [
          "isHTMLElement",
          0,
          function (e) {
            return t(e) && "offsetHeight" in e && !("ownerSVGElement" in e);
          },
        ],
        772846,
      ));
  },
]);
